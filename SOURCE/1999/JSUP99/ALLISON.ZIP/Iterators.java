Interface Iterator
{
    boolean     hasNext();
    Object      next();
    void        remove();
}

Interface ListIterator
{
    void        add(Object o);
    boolean     hasNext();
    boolean     hasPrevious();
    Object      next();
    int         nextIndex();
    Object      previous();
    int         previousIndex();
    void        remove();
    void        set(Object o);
}

