Interface List extends Collection
{
   void         add(int index, Object element) 
   Object       get(int index) 
   int          indexOf(Object o) 
   int          lastIndexOf(Object o) 
   ListIterator listIterator() 
   ListIterator listIterator(int index) 
   Object       remove(int index) 
   Object       set(int index, Object element) 
   int          size() 
   List         subList(int fromIndex, int toIndex) 
}
