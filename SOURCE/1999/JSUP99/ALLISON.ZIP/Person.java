public class Person implements Comparable, Cloneable
{
    private String name;
    private int year;
    private int month;
    private int day;

    public Person(String name, int year, int month,
                  int day)
    {
        this.name = new String(name);
        this.year = year;
        this.month = month;
        this.day = day;
    }
    public String getName()
    {
        return name;
    }

    // Override Object methods:
    public Object clone()
    {
        try
        {
            Person p = (Person) super.clone();
            p.name = new String(name);
            return p;
        }
        catch (CloneNotSupportedException x)
        {
            // Can't happen
            throw new InternalError(x.toString());
        }
    }
    public boolean equals(Object o)
    {
        if (o instanceof Person)
        {
            Person p = (Person) o;
            return name.equals(p.name) &&
                year == p.year &&
                month == p.month &&
                day == p.day;
        }
        else
            return false;
    }
    public int hashCode()
    {
        int hval = name.hashCode() + year;
        hval = (hval << 4) + month;
        hval = (hval << 4) + day;
        return hval;
    }
    public String toString()
    {
        return '{' + name + ',' + month +
               '/' + day  + '/' + year  + '}';
    }

    // Implement Comparable:
    public int compareTo(Object o)
    {
        Person p = (Person)o;
        int result = name.compareTo(p.name);
        if (result == 0)
        {
            result = (year - p.year);
            result = result*16 + (month - p.month);
            result = result*16 + (day - p.day);
        }
        return result;
    }
}
