/*
 * Simulator.java
 *
 * Copyright (c) 1999 Peter Meehan
 *
 * Permission is granted to use this code without restriction as long as
 * this copyright notice appears in all source files
 *
 */

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;
import java.util.Random;
import java.util.StringTokenizer;

/**
 * Class to simulate a multiple process system.
 * Each process or subsystem is implemented as a separate thread which
 * emits status messages to a listening clients. Clients talk to Server
 * via sockets using a simple ASCII line-oriented protocol. This
 * protocol consists of simple status messages.
 * The simulation represents any complex system whose status can be
 * remotely monitored,
 * e.g. a communications network or automated factory.
 *
 * @author	Peter Meehan
 */

public class Simulator {

    // Typical control systems
    final static String SubSystemNames[] = { "Cooling",
					     "Hydraulics",
					     "Generator",
					     "Conveyor1",
					     "Conveyor2"};
    final static int SubSystemDelays[] = { 3,4,5,6,7 } ; // seconds
    Hashtable subSystems = new Hashtable(); // holds the individual subsystems
    ServerSocket serverSocket = null;

    /**
     * Wait for client connection then start subsystems.
     */

    Simulator() {

	/*
	 * create server socket and wait for client connections
	 */

	try {
	    serverSocket = new ServerSocket(4444); // create server socket
	} catch (IOException ioe) {
	    System.err.println("Cannot create server socket");
	    System.exit(-1);
	} catch (SecurityException se) {
	    System.err.println("Security Mgr disallowed socket creation");
	    System.exit(-1);
	}

	Socket client = null;
	try {
	    client = serverSocket.accept(); // wait for connection
        } catch (IOException ioe) {
	    System.err.println("Accept failed");
	} catch (SecurityException se) {
	    System.err.println("Security Mgr disallowed accept");
	}

        /*
         * Wrap socket in PrintWriter
         */
	PrintWriter writer = null;
        try {
	    writer = new PrintWriter(client.getOutputStream(),true);
        } catch (IOException ioe) {
	    System.err.println("Cannot get output stream" + ioe.getMessage());
        }

	/*
	 * Wrap inputstream in buffered reader
	 */
	InputStream is = null;
	try {
	    is = client.getInputStream();
	} catch (IOException ioe) {
	    System.err.println("getInputStream failed : io exception : " + 
			       ioe.getMessage());
	}
	InputStreamReader isr = new InputStreamReader(is);
	BufferedReader reader = new BufferedReader(isr);

        /*
	 * Create and start processes
	 */
        for (int i=0;i<SubSystemNames.length;i++) {
	    SubSystem subsys = new SubSystem(SubSystemNames[i],
					     SubSystemDelays[i],
					     writer);
            subSystems.put(SubSystemNames[i],subsys);
	    subsys.start();
	}
	
	/*
	 * Wait for kill commands
	 */
	String input = null;
	while (true) {
	    try {
		input = reader.readLine();
		System.out.println("Got " + input);
	    } catch (IOException ioe) {
		System.err.println("getInputStream failed : " + 
				   ioe.getMessage());
	    }
	    /*
	     * Parse command
	     */
	    StringTokenizer tokenizer = new StringTokenizer(input);
	    String command = tokenizer.nextToken();
	    if (command.equals("Kill")) {
		String target = tokenizer.nextToken();
		SubSystem subSystem = (SubSystem)subSystems.get(target);
		subSystems.remove(target);
		subSystem.terminate();
		if (subSystems.size() == 0) {
		    System.exit(0);
		}
	    }
	    else if (command.equals("Exit")) {
		System.exit(0);
	    }
	}
    }

    public static void main (String args[]) {
      	Simulator simulator = new Simulator();
    }
}

class SubSystem extends Thread {

    static final int OK = 0;
    static final int WARNING = 1;
    static final int FAIL = 2;
    static final int TERMINATED = 3;
    static String STATENAMES[] = { "OK","WARNING","FAILED","TERMINATED" };
    static final Random random = new Random(System.currentTimeMillis());

    private int delay = 0; // between status messages
    private int state = OK;
    private PrintWriter client = null;
    private String name = null;
    private boolean terminated = false;

    public SubSystem(String name,int delay,PrintWriter client) {
	this.name = name;
	this.client = client;
	this.delay = delay * 1000; // store delay as mS
    }

    public synchronized boolean externallyTerminated () {
	return terminated;
    }
    public synchronized void terminate () {
	terminated = true;
    }

    public void start () {
	System.out.println("Starting subsystem " + name);
	super.start();
    }
    public void run () {
	while (!externallyTerminated()) {
	    state = nextStateTransition(state);
	    sendStatusMessage(name,state,client);
	    try {
		sleep(delay);
	    } catch (InterruptedException e) {
	    }
	}
	sendStatusMessage(name,TERMINATED,client);
    }

    int nextStateTransition(int state) {
	int nextState = state;
	switch (state) {
	case OK:
	    if (random.nextFloat() < 0.3)
		nextState = WARNING;
	    else
		nextState = OK;
	    break;
	case WARNING:
	    if (random.nextFloat() < 0.3)
		nextState = FAIL;
	    else
		nextState = OK;
	    break;
	case FAIL:
	    nextState = state;
	    break;
	}
	return nextState;
    }

    synchronized void sendStatusMessage(String name,
					int state,
					PrintWriter writer) {
	StringBuffer buffer = new StringBuffer("Subsystem ");
	buffer.append(name);
	buffer.append(" ");
	try {
	    buffer.append(STATENAMES[state]);
	} catch (ArrayIndexOutOfBoundsException oobe) {
	    buffer.append("INCONSISTENT");
	}
	if (writer != null) 
	    writer.println(buffer.toString());
	System.out.println(buffer.toString());
    }
}

