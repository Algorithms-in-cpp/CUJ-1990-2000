/*
 * ClickCount.java
 *
 * Copyright (c) 1999 Peter Meehan
 *
 * Permission is granted to use this code without restriction as long as
 * this copyright notice appears in all source files
 *
 */

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class ClickCount extends JFrame {

    private int count = 0;
    final private JButton button = new JButton("Click");
    final private JLabel label = new JLabel("Count is : 0",SwingConstants.CENTER);
    final private GridLayout layout = new GridLayout(2,1);
    private Container contentPane = null;

    // The actionListener runs in the event thread
    class CountClicks implements ActionListener {
	public void actionPerformed(ActionEvent e) {
	    label.setText("Count is : " + ++count); // force cast to string
	}
    }

    // The contructor runs in the main thread
    public ClickCount() {
	super("User events in Swing");
	
	contentPane = getContentPane(); // components are added to contentPane
	contentPane.setLayout(layout); // place components in a column
	contentPane.add(button);
	contentPane.add(label);
	button.addActionListener(new CountClicks()); // register listener
    }

    // The main routine runs in the main thread
    static public void main(String args[]) {
	ClickCount click = new ClickCount(); // build interface
	click.pack(); // layout window and components, forcing their display
	click.show(); // make visible
	// from this point on all UI update must occur in the event thread
    }
}
	
	
	
