This has been tested on Windows NT 4 and 98 on JDK 1.2.2

The source files are:

ClickCount.java     -- source for simple Swing user eventhandling

SwingClient.java    -- source for MT client

Simulator.java      -- source for simulator


---
To compile: javac *.java

The ClickCount app is standalone: java ClickCount to run.

For the MT client start the simulator first: java Simulator,
then start the client: java SwingClient

