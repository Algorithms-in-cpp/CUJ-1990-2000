/*
 * SwingClient.java
 *
 * Copyright (c) 1999 Peter Meehan
 *
 * Permission is granted to use this code without restriction as long as
 * this copyright notice appears in all source files
 *
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.SwingUtilities;

/**
 * A status display client for the process simulator, implemented in Swing.
 * The client builds its UI then forks a thread to connect to and receive
 * messages from the Simulator server. Messages are then displayed in the
 * UI using Swing's invokeLater and invokeAndWait methods.
 */

public class SwingClient extends JFrame {

    /*
     * UI components
     */
    final JPanel panel = new JPanel();
    final JMenu fileMenu = new JMenu("File");
    final JMenuItem exit = new JMenuItem("Exit");
    final JMenuBar menuBar = new JMenuBar();
    final DefaultListModel listModel = new DefaultListModel();
    final JList list = new JList(listModel);
    final JScrollPane scroller = new JScrollPane(list);
    JOptionPane confirmationDialog;

    final Comms comms = new Comms(); // communications manager

    /**
     * A thread to manage communications with the Simulator. After opening
     * a socket to the simulator the thread reads and process messages
     * received on the socket.
     */
    class Comms extends Thread {

	Socket socket = null;
	BufferedReader reader = null;
	final ConfirmTerminateTask confirmTerminateTask
	    = new ConfirmTerminateTask(); // single task
	PrintWriter writer = null;
	Vector filter = new Vector(); 

	/** 
	 * A task to add a message to the status display list.
	 * It is designed to be created and invoked from a separate
	 * thread via SwingUtilities.invokeLater.
	 */
	class MessageTask implements Runnable {
	    String message;
	    /**
	     * Cache the message
	     */
	    MessageTask (String message) {
		this.message = message;
	    }
	    /**
	     * Add the message the list's model and ensure it is visible
	     */
	    public void run() {
		SwingClient.this.listModel.addElement(message);
		SwingClient.this.list.ensureIndexIsVisible(SwingClient.this.listModel.getSize()-1);
	    }
	}

	/** 
	 * A task to display an error message.
	 * It is designed to be created and invoked from a separate
	 * thread via SwingUtilities.invokeLater.
	 */
	class DisplayErrorTask implements Runnable {
	    private String message = null;
	    
	    /**
	     * Cache the error message
	     */
	    DisplayErrorTask(String message) {
		this.message = message;
	    }
	    
	    /**
	     * Display the message in an error dialog
	     */
	    public void run() {
		JOptionPane.showMessageDialog(SwingClient.this,
					      message,
					      "Alert",
					      JOptionPane.ERROR_MESSAGE);
	    }
	}

	/** 
	 * This class displays an option dialog to the user indicating
	 * failure of a particular subsystem. The user is prompted to
	 * terminate the subsystem and the task stores the user's 
	 * response.
	 * It is designed to be created and invoked from a separate
	 * thread via SwingUtilities.invokeAndWait.
	 */
	class ConfirmTerminateTask implements Runnable {
	    int result = JOptionPane.NO_OPTION;
	    String subSystem = null;

	    /**
	     * Store the subsystem name for display
	     */
	    public void setSubSystem(String subSystem) {
		this.subSystem = subSystem;
	    }
	    
	    /**
	     * Did the user request subsystem termination?
	     */
	    boolean terminateTask() {
		return (result == JOptionPane.YES_OPTION);
	    }
		
	    /**
	     * Build the complete message and display the option dialog.
	     * Store the user's choice.
	     */
	      
	    public void run() {
		StringBuffer buffer = new StringBuffer(subSystem);
		buffer.append(" has failed. Switch off?");
		result = 
		    JOptionPane.showConfirmDialog(SwingClient.this,
						  buffer.toString(),
						  "Subsystem Failure",
						  JOptionPane.YES_NO_OPTION);
	    }
	}

	/** 
	 * Establish socket communications with the simulator
	 */

	Comms() {
	    try {
		socket = new Socket("localhost",4444);
	    } catch (UnknownHostException uhe) {
		SwingUtilities.invokeLater(new DisplayErrorTask("Connection failed : Host unknown : " + uhe.getMessage()));
	    } catch (IOException ioe) {
		SwingUtilities.invokeLater(new DisplayErrorTask("Connection failed : io exception : " + ioe.getMessage()));
	    }
	    
	    if (socket == null)
		return;
	    /*
	     * Wrap inputstream in buffered reader
	     */
	    InputStream is = null;
	    try {
		is = socket.getInputStream();
	    } catch (IOException ioe) {
		SwingUtilities.invokeLater(new DisplayErrorTask("getInputStream failed : io exception : " + ioe.getMessage()));
	    }
	    InputStreamReader isr = new InputStreamReader(is);
	    reader = new BufferedReader(isr);

	    /*
	     * Wrap outputstream in PrintWriter
	     */
	    try {
		writer = new PrintWriter(socket.getOutputStream(),true);
	    } catch (IOException ioe) {
		SwingUtilities.invokeLater(new DisplayErrorTask("Get output stream" + ioe.getMessage()));
	    }
	}

	/**
	 * Check if a message relates to a terminated subsystem and
	 * discard if so, unless it is the actual termination message. 
	 * This check handles the race condition of simulator generated
	 * messages being displayed in the UI after the user has terminated
	 * the subsystem
	 */

	boolean discardMessage(String msg) {

	    try {
		/*
		 * Never discard terminate messages
		 */
		if (msg.indexOf("TERMINATED") != -1)
		    return false;
		/*
		 * Discard messages from terminated subsystems.
		 */
		for (Enumeration e = filter.elements();e.hasMoreElements();) {
		    if (msg.indexOf((String)e.nextElement()) != -1) 
			return true;
		}
	    } catch (NullPointerException npe) { // null message
		return true;
	    }
	    return false;
	}

	/**
	 * Continually read and process messages from the simulator.
	 */
	public void run() {
	    String input = null;
	    boolean keepRunning = true;
	    while (keepRunning) {
		try {
		    input = reader.readLine(); // get next message
		} catch (IOException ioe) {
		    /*
		     * Communications failure
		     */
		    SwingUtilities.invokeLater(new DisplayErrorTask("Communications failure\n" +
				"Simulator probably terminated\n" +
				"Details: " + ioe.getMessage()));
		    keepRunning = false;
		} catch (NullPointerException npe) {
		    /*
		     * Reader not initialized - should never occur as this
		     * error is caught in the constructor
		     */
		    keepRunning = false;
		}

		/*
		 * First check if message belongs to a terminated subsystem
		 */
		if (!discardMessage(input)) {
		    /*
		     * Add message to list
		     */
		    SwingUtilities.invokeLater(new MessageTask(input)); 
		    /*
		     * special treatment for failed subsystem
		     */
		    if (input.indexOf("FAIL") != -1) {
			/*
			 * Parse message to get the subsystem name
			 */
			StringTokenizer tokenizer = new StringTokenizer(input);
			tokenizer.nextToken();
			String subSystem = tokenizer.nextToken();
			/*
			 * Store subsystem name in task
			 */
			confirmTerminateTask.setSubSystem(subSystem);
			try {
			    // execute task and wait for result
			    SwingUtilities.invokeAndWait(confirmTerminateTask);
			} catch (InterruptedException ie) {
			    System.err.println("Confirm interrupted " + 
					       ie.getMessage());
			} catch (InvocationTargetException ite) {
			    System.err.println("Exception in confirmTerminate " + 
					       ite.getMessage());
			}
			/*
			 * If user requested termination send kill message
			 */
			if (confirmTerminateTask.terminateTask()) {
			    writer.println("Kill " + subSystem);
			    filter.add(subSystem);
			}
		    }
		}
	    }
	}

	/**
	 * Send exit message to simulator for cleaner termination
	 */
	public void exit() {
	    if (writer != null)
		writer.println("Exit");
	}
    }   

    /**
     * Build the user interface and start the communications thread
     */

    SwingClient() {
	super("Swing Multi-threading");
	buildUI();
	comms.start();
    }

    /**
     * Build the user interface and register the cell renderer with the
     * status display list component.
     */

    void buildUI() {

	/**
	 * A class to change the color of each status message
	 * in the list to reflect the seriousness of the status. 
	 * Messages are colored as follows:
	 *	OK - green
	 *	WARNING - orange
	 *	FAIL - red
	 *	TERMINATED - grey
	 */
	class StatusCellRenderer extends JLabel implements ListCellRenderer {

	    public Component getListCellRendererComponent(JList list,
							  Object value, 
							  int index,    
							  boolean isSelected,
							  boolean hasFocus) {
		String s = value.toString();
		setText(s);
		if (isSelected) {
		    setBackground(list.getSelectionBackground());
		    setForeground(list.getSelectionForeground());
		} else {
		    setBackground(list.getBackground());
		    if (s.indexOf("OK") != -1)
			setForeground(Color.green);
		    else if (s.indexOf("WARNING") != -1)
			setForeground(Color.orange);
		    else if (s.indexOf("FAIL") != -1) 
			setForeground(Color.red);
		    else
			setForeground(Color.lightGray);
		}
		setEnabled(list.isEnabled());
		setFont(list.getFont());
		return this;
	    }
	}

	/*
	 * menubar
	 */
	exit.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
		comms.exit();
		System.exit(0);
	    }
	});
	fileMenu.add(exit);
	menuBar.add(fileMenu);
	setJMenuBar(menuBar);

	/*
	 * main panel
	 */
	panel.setLayout(new BorderLayout());
	panel.add(scroller,"Center");
	list.setCellRenderer(new StatusCellRenderer());
	list.setBackground(Color.darkGray);
		
	getContentPane().add(panel);
    }

    /** 
     * Create an instance of SwingClient and show it
     */
    static public void main (String args[]) {
	SwingClient client = new SwingClient();
	client.pack();
	client.show();
    }
}

