//**************** "Client\Client.java" file ****************
//  Author: Petru Marginean; margineanp@micromodeling.com   *
//  Last update date: 10/01/1998                            *
//***********************************************************

package Client;

import Server.IServer;
import Server.Message;

//You should implement that interface to be able to receive notifications from server
interface INotifiable extends Runnable
{
        void onMessage(Message msg);
}

//That class is the abstract base class for a client applet
abstract public class Client extends java.applet.Applet implements INotifiable
{
    protected String APPLET_NAME;
    protected String m_displayName;
    protected String m_id;
    protected IServer m_server;
    protected boolean m_registered = false;

    public void run()
    {
        System.out.println("Start Look4Msg LOOP for " + m_displayName + 
            " with ID " + m_id);
        try
        {
            for (;;)
            {
                Message msg = m_server.ReadNextMessage(m_id);
                System.out.println(m_displayName + 
                    " has received the message:\n" + msg);
                if (msg.Code() == Message.END)
                    break;
                onMessage(msg);
            }
        }
        catch(Exception e)
        {
            m_registered = false;
            onMessage(new Message(APPLET_NAME, Message.INFO, e.toString()));
            e.printStackTrace();
        }
        System.out.println("End Look4Msg LOOP.");
    }

    protected void DoRegister() throws Exception
    {
        if (m_registered)
            throw new Exception("Already registered!");
        m_id = m_server.Register(m_displayName);
        m_registered = true;
        new Thread(this).start();
    }


    protected void DoUnregister() throws Exception
    {
        if (!m_registered)
            throw new Exception("Not registered!");
        m_server.Unregister(m_id);
        m_registered = false;
    }

        protected void Connect2Server(String serverID)
        {
        String fullServerName = "rmi://" + getCodeBase().getHost() + 
            "/" + serverID;
        try
        {
            System.out.print("Try to connect to server " + 
                fullServerName + "...");
            m_server = (IServer)java.rmi.Naming.lookup(fullServerName);
            System.out.println(" Done.");
        }
        catch (Exception e)
        {
            System.out.println("Exception occured: " + e);
            String errorMessage = "Error connecting to server " + 
                fullServerName;
            System.out.println(errorMessage);
            onMessage(new Message(APPLET_NAME, Message.INFO, errorMessage));
        }
        }

    public Client()
    {
        APPLET_NAME = getClass().toString();
    }
}
