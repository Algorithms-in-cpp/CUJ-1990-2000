//**************** "Client\Chat.java" file ******************
//  Author: Petru Marginean; margineanp@micromodeling.com   *
//  Last update date: 10/01/1998                            *
//***********************************************************

package Client;

import java.awt.Font;
import java.awt.Color;

import Server.IServer;
import Server.Message;

public class Chat extends Client implements java.awt.event.ActionListener, 
    java.awt.event.ItemListener 
{
    public void onMessage(Message msg)
    {
        switch (msg.Code())
        {
            case Message.MODIFY_CLIENTS:
                Refresh();
            case Message.NEW:
                //You can add code here for initialization
            case Message.RECONNECT:
                //You can add code here for reconnection case
            default:
                showStatus(msg.toString());
                m_receivedMsgBody.setText(msg.toString());
        }
    }

    public void start()
        {
        Connect2Server(getParameter("serverID"));
        EnableButtons();
        if (m_server != null)
            Refresh();
        }

    public void stop()
        {
        Unregister();
        }

    private void Register()
    {
        try
        {
            DoRegister();
            EnableButtons();
            Refresh();
        }
        catch(Exception e)
        {
            onMessage(new Message(APPLET_NAME, Message.INFO, e.toString()));
            System.out.println("Exception occured: " + e);
        }
    }
    
    private void Unregister()
    {
        try
        {
            DoUnregister();
            EnableButtons();
            Refresh();
            onMessage(new Message(APPLET_NAME, Message.INFO, 
                "You were unregistered successfully!"));
        }
        catch(Exception e)
        {
            onMessage(new Message(APPLET_NAME, Message.INFO, e.toString()));
            System.out.println("Exception occured: " + e);
        }
    }
    
    private void Send(String[] receivers, int code, String body)
    {
        String crtReceiver = null;
        for (int i = 0; i < receivers.length; i++)
            try
            {
                crtReceiver = receivers[i];
                m_server.PostMessage(crtReceiver, m_id, new Message(m_displayName, code, body));
            }
            catch(Exception e)
            {
                String message = "The message \"" + body + "\" could not be delivered to the client " + 
                    crtReceiver + "; " + e.toString();
                onMessage(new Message(APPLET_NAME, Message.INFO, message));
                System.out.println("Exception occured: " + e);
            }
    }

    public void actionPerformed(java.awt.event.ActionEvent ev)
    {
        if (ev.getActionCommand().equals("Refresh"))
            Refresh();
        if (ev.getActionCommand().equals(REGISTER))
        {
            String clientName = m_clientName.getText();
            if (clientName.length() != 0)
            {
                m_displayName = clientName;
                Register();
            }
            else
                onMessage(new Message(APPLET_NAME, Message.INFO, 
                    "Please type your display name!"));
        }
        if (ev.getActionCommand().equals(UNREGISTER))
                Unregister();
        String[] Targets = null;
        if (ev.getActionCommand().equals("Send to all"))
            Targets = m_clients.getItems();
        if (ev.getActionCommand().equals("Send"))
            Targets = m_clients.getSelectedItems();
        if (Targets != null)
            Send(Targets, Message.INFO, m_msgBody.getText());
    }

    public void itemStateChanged(java.awt.event.ItemEvent e)
    {
        if (!m_registered && e.getItemSelectable().equals(m_clients))
            m_clientName.setText(m_clients.getSelectedItem());
    }  

    private void Refresh()
    {
        try
        {
            m_clients.removeAll();
            String[] clients = m_server.GetClients();
            for (int i = 0; i < clients.length; i++)
                m_clients.addItem(clients[i]);
        }
        catch(Exception e)
        {
            onMessage(new Message(APPLET_NAME, Message.INFO, e.toString()));
            System.out.println("Exception occured: " + e);
        }
    }

    private void EnableButtons()
        {
            if (m_server != null)
            {
            //connected to server
                m_connect.setEnabled(true);
                m_refreshBtn.setEnabled(true);

                m_sendBtn.setEnabled(m_registered);
                m_send2AllBtn.setEnabled(m_registered);
            m_clientName.setEditable(!m_registered);
            m_connect.setLabel(!m_registered ? REGISTER : UNREGISTER);
                m_clientName.setFont(new Font("Dialog", 
                    m_registered ? Font.BOLD : Font.PLAIN , m_registered ? 13 : 11));
            }
            else
            {
            //not connected to server (and not registered)
                m_connect.setEnabled(false);
                m_refreshBtn.setEnabled(false);
                m_sendBtn.setEnabled(false);
                m_send2AllBtn.setEnabled(false);
            m_clientName.setEditable(false);
                m_clientName.setFont(new Font("Dialog", Font.PLAIN, 12));
            m_connect.setLabel(REGISTER);
            }
        }

    public void init()
        {
                // This code is automatically generated by Visual Cafe when you add
                // components to the visual environment. It instantiates and initializes
                // the components. To modify the code, only use code syntax that matches
                // what Visual Cafe can generate, or Visual Cafe may be unable to back
                // parse your Java file into its visual environment.
                //{{INIT_CONTROLS
                setLayout(null);
                setSize(480,310);
                setBackground(new Color(-16744256));
                m_clients = new java.awt.List(0,true);
                add(m_clients);
                m_clients.setBounds(300,36,168,108);
                m_clients.setFont(new Font("Dialog", Font.BOLD, 12));
                m_clients.setBackground(new Color(16777215));
                m_sendBtn = new java.awt.Button();
                m_sendBtn.setLabel("Send");
                m_sendBtn.setBounds(12,96,72,24);
                m_sendBtn.setBackground(new Color(12632256));
                add(m_sendBtn);
                m_sendBtn.setEnabled(false);
                m_send2AllBtn = new java.awt.Button();
                m_send2AllBtn.setLabel("Send to all");
                m_send2AllBtn.setBounds(108,96,72,24);
                m_send2AllBtn.setBackground(new Color(12632256));
                add(m_send2AllBtn);
                m_send2AllBtn.setEnabled(false);
                m_clientName = new java.awt.TextField();
                m_clientName.setBounds(12,36,168,24);
                m_clientName.setFont(new Font("Dialog", Font.PLAIN, 12));
                m_clientName.setBackground(new Color(16777215));
                add(m_clientName);
                label1 = new java.awt.Label("Your display name:");
                label1.setBounds(12,12,108,24);
                add(label1);
                label2 = new java.awt.Label("Your message body:");
                label2.setBounds(12,132,198,24);
                add(label2);
                m_refreshBtn = new java.awt.Button();
                m_refreshBtn.setLabel("Refresh");
                m_refreshBtn.setBounds(204,36,72,24);
                m_refreshBtn.setBackground(new Color(12632256));
                add(m_refreshBtn);
                m_refreshBtn.setEnabled(false);
                label3 = new java.awt.Label("Received message:");
                label3.setBounds(10,204,144,24);
                add(label3);
                label4 = new java.awt.Label("The others:");
                label4.setBounds(300,12,72,24);
                add(label4);
                m_connect = new java.awt.Button();
                m_connect.setLabel("Register");
                m_connect.setBounds(204,96,72,24);
                m_connect.setBackground(new Color(12632256));
                add(m_connect);
                m_connect.setEnabled(false);
                m_receivedMsgBody = new java.awt.TextArea(5,0);
                m_receivedMsgBody.setEditable(false);
                m_receivedMsgBody.setBounds(10,228,460,72);
                m_receivedMsgBody.setFont(new Font("Dialog", Font.BOLD, 12));
                m_receivedMsgBody.setBackground(new Color(16777215));
                add(m_receivedMsgBody);
                m_msgBody = new java.awt.TextArea(5,0);
                m_msgBody.setBounds(10,156,460,48);
                m_msgBody.setFont(new Font("Dialog", Font.BOLD, 12));
                m_msgBody.setBackground(new Color(16777215));
                add(m_msgBody);
                //}}
        m_sendBtn.addActionListener(this);
        m_send2AllBtn.addActionListener(this);
        m_refreshBtn.addActionListener(this);
        m_connect.addActionListener(this);

        m_clients.addItemListener(this);
        }

        //{{DECLARE_CONTROLS
        java.awt.Label label1;
        java.awt.Label label2;
        java.awt.Label label3;
        java.awt.Label label4;
        java.awt.List m_clients;
        java.awt.Button m_sendBtn;
        java.awt.Button m_send2AllBtn;
        java.awt.TextField m_clientName;
        java.awt.Button m_refreshBtn;
        java.awt.Button m_connect;
        java.awt.TextArea m_receivedMsgBody;
        java.awt.TextArea m_msgBody;
        //}}

    final static private String REGISTER = "Register";
    final static private String UNREGISTER = "Unregister";
}
