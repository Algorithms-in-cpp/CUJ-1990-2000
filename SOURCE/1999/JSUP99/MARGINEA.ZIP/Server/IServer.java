//**************** "Server\IServer.java" file ***************
//  Author: Petru Marginean; margineanp@micromodeling.com   *
//  Last update date: 10/01/1998                            *
//***********************************************************

package Server;

import java.rmi.*;

//This interface will be implemented by the class Server and will be available remotely
//to the clients
public interface IServer extends Remote
{
    //Allows anyone to find out information about the server
        public String[] GetClients() throws RemoteException;
    //Allows a client to logon to the server (and to obtain its signature, the ID)
        public String Register(String clientDisplayName) throws RemoteException, Exception;
    //Allows a client to logoff from the server
        public void Unregister(String clientID) throws RemoteException, Exception;
    //Allows a client to post a message for a certain client
    //The receiver is identified by displayName and the sender is identified by ID
        public void PostMessage(String receiverDisplayName, String senderID, 
            Message msg) throws RemoteException, Exception;
    //Will return right when a new message is available
        public Message ReadNextMessage(String receiverID) throws RemoteException, Exception;
}

