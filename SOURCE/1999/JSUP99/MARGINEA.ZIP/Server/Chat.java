//**************** "Server\Chat.java" file ******************
//  Author: Petru Marginean; margineanp@micromodeling.com   *
//  Last update date: 10/01/1998                            *
//***********************************************************

package Server;

public class Chat extends Server implements IServer
{
        public static void main(String[] argv)
        {
        if (argv.length != 1)
        {
                    System.out.println("Usage note:");
                    System.out.println("java Server.Chat <name>");
                    System.out.println("Where:");
                    System.out.println("<name> - " + 
                        "is the name of the remote chat server.");
            System.exit(0);
        }
                System.setSecurityManager(new java.rmi.RMISecurityManager());
                try
                {
                        Chat implementation = new Chat(argv[0]);
                        System.out.println("The server \"" + argv[0] + "\" is ready.");
                }
        catch (Exception e)
                {
                        System.out.println("Exception occurred: " + e);
                }
        }

    public Chat(String id) throws Exception
    {
        super(id);
    }
}
