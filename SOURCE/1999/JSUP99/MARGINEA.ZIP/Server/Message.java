//**************** "Server\Message.java" file ***************
//  Author: Petru Marginean; margineanp@micromodeling.com   *
//  Last update date: 10/01/1998                            *
//***********************************************************

package Server;

import java.io.*;

//Because that class is passed by value (as argument as well as return value)
//it must implement the Serializable interface
public class Message implements Serializable
{
    final static public int END = 0;
    final static public int INFO = 1;
    final static public int MODIFY_CLIENTS = 2;
    final static public int RECONNECT = 3;
    final static public int NEW = 4;

    private String m_SenderDisplayName;
    private String m_Body;
    private int m_Code;

    private void writeObject(ObjectOutputStream out)
        throws IOException
    {
        out.defaultWriteObject();
    }
    private void readObject(ObjectInputStream in)
        throws IOException, ClassNotFoundException
    {
        in.defaultReadObject();
    }

    public Message(String senderDisplayName, int code, String body)
    {
        m_SenderDisplayName = senderDisplayName;
        m_Body = body;
        m_Code = code;
    }
    public int Code()
    {
        return m_Code;
    }

    public String toString()
    {
        String code;
        switch(m_Code)
        {
            case END: 
                code = "END";
                break;
            case INFO: 
                code = "INFO";
                break;
            case MODIFY_CLIENTS: 
                code = "MODIFY_CLIENTS";
                break;
            case RECONNECT: 
                code = "RECONNECT";
                break;
            case NEW: 
                code = "NEW";
                break;
            default:
                code = "?";
        }
        
        return "from: " + m_SenderDisplayName + "\nbody: " + 
            m_Body + "\ncode: " + code;
    }
}
