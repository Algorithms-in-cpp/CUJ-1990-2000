//**************** "Server\Server.java" file ****************
//  Author: Petru Marginean; margineanp@micromodeling.com   *
//  Last update date: 10/01/1998                            *
//***********************************************************

package Server;

import java.util.Vector;

public class Server extends java.rmi.server.UnicastRemoteObject
    implements IServer
{
        private int m_crtClientID = 0;
        private Vector m_clientsList;
    private String m_id;

    public Server(String id) throws Exception
    {
        m_clientsList = new Vector();
                m_id = id;
                java.rmi.Naming.rebind(m_id, this);
    }

        public Message ReadNextMessage(String receiverID) throws Exception
        {
        //verify if the sender is one of our clients; authenticate
        int i = GetPosition(receiverID);
        ClientInfo crtCI = (ClientInfo)(m_clientsList.elementAt(i));
        Message msg;
        try
        {
            //PopMessage() will return just after a message is available 
            msg = crtCI.PopMessage();
        }
        catch(Exception e)
        {
            Unregister(receiverID);
            throw new Exception("You was unregistered; " + e);
        }
                return msg;
        }

        synchronized public void PostMessage(String receiverDisplayName,
            String senderID, Message msg) throws Exception
        {
        if (!m_id.equals(senderID))
            //verify if the sender is one of our registered clients (or the server itself)
            GetPosition(senderID);
        ClientInfo crtCI = GetClient(receiverDisplayName);
        crtCI.PushMessage(msg);
        }
        
        synchronized public String Register(String displayName)
            throws Exception
        {
        String newID;
            try
            {
                ClientInfo crtCI = GetClient(displayName);
            crtCI.m_ClientIsAlive = false;
            PostMessage(displayName, m_id, new Message(m_id, Message.INFO,
                "Server is verifying if you are alive"));
            crtCI.WaitNewRequest();
            if (crtCI.m_ClientIsAlive)
            {
                // Client is alive
                        System.out.println("Acknowledge.");
                PostMessage(displayName, m_id,
                    new Message(m_id, Message.INFO,
                        "Somebody tried to replace you but was REJECTED"));
                throw new Exception("Try to connect as an existent client");
            }
                System.out.println("Negative Acknowledge.");
            // Client crashed; replace it!
            // Change ID of ClientInfo with newID => that means the older client will be discarded
            newID = new Integer(m_crtClientID++).toString();
            crtCI.SetID(newID);
            PostMessage(displayName, m_id,
                new Message(m_id, Message.RECONNECT, "Welcome back, " +
                    displayName + "."));
                    System.out.println("The client already exists but seems to be hung up; it was replaced.");
            }
            catch(ClientNotFound e)
            {
            // New client
            if (m_clientsList.size() >= MaxClientsNumber())
                throw new Exception("Too many clients (" + MaxClientsNumber() + ").");
            NotifyAll(new Message(m_id, Message.MODIFY_CLIENTS, displayName + " joined to " + m_id));
            newID = new Integer(m_crtClientID++).toString();
            ClientInfo newCI = NewClient(displayName, newID);
            m_clientsList.addElement(newCI);
            PostMessage(displayName, m_id, new Message(m_id, Message.NEW,
                "Welcome, " + displayName + "."));
                System.out.println("\t=> reg. NEW " + newCI);
            }
        return newID;
        }

        synchronized public void Unregister(String id) throws Exception
        {
        int pos = GetPosition(id);
        ClientInfo crtCI = (ClientInfo)(m_clientsList.elementAt(pos));
        String displayName = crtCI.DisplayName();
        PostMessage(displayName, m_id, new Message(m_id, Message.END,
            "Bye " + displayName + "!"));
        m_clientsList.removeElementAt(pos);
        NotifyAll(new Message(m_id, Message.MODIFY_CLIENTS, displayName + " left " + m_id));
                System.out.println("\t<= unreg. " + crtCI);
        }

        synchronized public String[] GetClients()
        {
        String clientsNames[] = new String[m_clientsList.size()];
        for  (int i = 0; i < m_clientsList.size(); i++)
        {
            ClientInfo crtCI = (ClientInfo)(m_clientsList.elementAt(i));
            clientsNames[i] = crtCI.DisplayName();
        }
        return clientsNames;
        }

    protected ClientInfo NewClient(String displayName, String id)
    {
        return new ClientInfo(displayName, id);
    }
    
    protected int MaxClientsNumber()
    {
        return 20;
    }

    private ClientInfo GetClient(String displayName) throws ClientNotFound
    {
        for  (int i = 0; i < m_clientsList.size(); i++)
        {
            ClientInfo crtCI = (ClientInfo)(m_clientsList.elementAt(i));
            if (crtCI.equals(displayName))
               return crtCI;
        }
        throw new ClientNotFound("The client doesn't exist, DisplayName = " +
            displayName);
    }

    private void NotifyAll(Message msg)
    {
        for  (int i = 0; i < m_clientsList.size(); i++)
            try
            {
                PostMessage(((ClientInfo)m_clientsList.elementAt(i)).DisplayName(), m_id, msg);
            }
            catch(Exception e)
            {
                System.out.println("Exception occured: " + e);
            }
    }
    private int GetPosition(String id) throws ClientNotFound
    {
        for  (int i = 0; i < m_clientsList.size(); i++)
        {
            ClientInfo crtCI = (ClientInfo)(m_clientsList.elementAt(i));
            if (crtCI.ID().equals(id))
               return i;
        }
        throw new ClientNotFound("The client doesn't exist, ID = " + id);
    }
}

class ClientNotFound extends Exception
{
    public ClientNotFound(String msg)
    {
        super(msg);
    }
}

class ClientInfo
{
    private String m_displayName;
    private String m_id;
    private Vector m_pendingMsgQueue;

    boolean m_ClientIsAlive;

    public ClientInfo(String displayName, String id)
    {
        m_displayName = displayName;
        m_id = id;
        m_pendingMsgQueue = new Vector();
    }
    synchronized public Message PopMessage() throws Exception
    {
        //That method will signal that the client is still working and will wait until 
        //a new message is available
        //The server won't disconnect a client that doesn't stop to read his messages.
        m_ClientIsAlive = true;
        notify();

        if (m_pendingMsgQueue.isEmpty())
            //Wait unlimited time for someone to send a message for this client
            //The server can specify a timeout (for his own security) by override the WaitNewMessage() method
            WaitNewMessage();
        if (m_pendingMsgQueue.isEmpty())
            //If the queue is still empty that's because timeout (override WaitNewMessage())
            throw new Exception("Timeout.");
        Message oldestMsg = (Message)m_pendingMsgQueue.elementAt(0);
        m_pendingMsgQueue.removeElementAt(0);
        return oldestMsg;
    }
    synchronized void WaitNewRequest() throws InterruptedException
    {
                System.out.print("Pinging for maximum " + PingingTime() + " seconds for client " + m_displayName);
        wait(PingingTime() * 1000);
    }
    synchronized public void PushMessage(Message newMsg) throws Exception
    {
        //That method will signal that a new message is available
        if (m_pendingMsgQueue.size() < MaxPendingMsgNumber())
            m_pendingMsgQueue.addElement(newMsg);
        else
            throw new Exception("Too many messages (" + MaxPendingMsgNumber() + ") for " + 
                m_displayName + " client. Please try again.");
        notify();
    }
    synchronized void WaitNewMessage() throws InterruptedException
    {
        if (NoActivityTime() > 0)
            wait(NoActivityTime() * 1000);
        else
            wait();
    }
    
    protected int MaxPendingMsgNumber() { return 100; }
    protected int NoActivityTime() { return 5 * 60; /* "-1" means forever*/}
    protected int PingingTime() { return 5; }
    
    public String toString()
    {
        return "Client name: " + m_displayName;
    }
    public boolean equals(String otherName)
    {
        if (otherName.equals(m_displayName))
            return true;
        return false;
    }
    public boolean equals(ClientInfo otherCI)
    {
        if (otherCI.m_displayName.equals(m_displayName))
            return true;
        return false;
    }
    public String DisplayName()
    {
        return m_displayName;
    }
    public void SetID(String newID)
    {
        m_pendingMsgQueue = new Vector();
        m_id = newID;
    }
    public String ID()
    {
        return m_id;
    }
}
