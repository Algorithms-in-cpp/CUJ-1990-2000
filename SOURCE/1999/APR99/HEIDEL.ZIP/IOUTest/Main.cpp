#include "main.h"
#include "init.h"
#include "request.h"
#include "resultiou.h"

#include <iostream.h>
#include <assert.h>

const int MAX_STR_LENGTH = 256;

// Helper functions
ostream &
operator<<(ostream &os, const BSTR &bstr)
{
    assert( SysStringLen( bstr) < MAX_STR_LENGTH);

	char sz[ MAX_STR_LENGTH];
	wcstombs( sz, bstr, MAX_STR_LENGTH);

    os << sz;

    return os;
}

ostream &
operator<<(ostream &os, const VARIANT &v)
{
    VARIANT vAsBstr;
    ::VariantInit( &vAsBstr);
    if (SUCCEEDED(::VariantChangeType(&vAsBstr, const_cast< VARIANT *>( &v), 0, VT_BSTR)))
        os << vAsBstr.bstrVal;
    else
        os << "<unable to convert value>";
    ::VariantClear( &vAsBstr);

    return os;
}

// COM initialization
const Init init;

// Derived IOU class
class MyIOU : public ResultIOU
{
public:
	void ResultIOUComplete() 
	{
		VARIANT result = Redeem();
		cout << result << endl;
	}
};

void
main(int argc, char *argv[])
{
	bool notify = false;
    if( argc == 2 && stricmp( argv[1], "/asynch" ) == 0 )     
		notify = true;	
	
	MyIOU iou;
	Request request;
	if (!request.select(L"ADDRESS WHERE BUSINESS = 'HotData, Inc.'"))
		cout << Error::Description();
	else
		if (!request.send(notify, iou))
			cout << Error::Description();
		else
			if (!notify)
				iou.ResultIOUComplete();

    cout << "Press Enter to end..." << endl;
    cin.get();
}
