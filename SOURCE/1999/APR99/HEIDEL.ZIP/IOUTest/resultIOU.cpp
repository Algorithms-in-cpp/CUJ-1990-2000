#include "main.h"
#include "ResultIOU.h"

#include <assert.h>

ResultIOU::ResultIOU(IResultIOUReadable *pResultIOU)
    : pResultIOU_(pResultIOU)
{
    if (pResultIOU_)
        pResultIOU_->AddRef();
}

ResultIOU::ResultIOU(const ResultIOU& rhs)
    : pResultIOU_( 0)
{
    *this = rhs;
}

ResultIOU::~ResultIOU()
{
    if (pResultIOU_)
        pResultIOU_->Release();
}

ResultIOU&
ResultIOU::operator=(const ResultIOU& rhs)
{
    Close(rhs.pResultIOU_);

    return *this;
}

void 
ResultIOU::getErrorInfoParams( IUnknown *&pUnk, const IID *&riid) const
{ 
    pUnk = pResultIOU_; 
    riid = &IID_IResultIOUWriteable; 
}

void
ResultIOU::Close(IResultIOUReadable *pResultIOU)
{
	assert(pResultIOU);

    if (pResultIOU != pResultIOU_)
    {
        if (pResultIOU_)
        {
            pResultIOU_->Release();
            pResultIOU_ = 0;
        }
        if (pResultIOU_ = pResultIOU)
            pResultIOU_->AddRef();
    }
}

VARIANT
ResultIOU::Redeem()
{
	assert(pResultIOU_);

	VARIANT result;
	::VariantInit(&result);
	HRESULT hr = pResultIOU_->Redeem(&result);
    if (FAILED(hr))
	{
        Error::setError( *this, hr);
		::VariantClear(&result);
	}

	return result;
}

// Implement the rest of the IOU methods here...