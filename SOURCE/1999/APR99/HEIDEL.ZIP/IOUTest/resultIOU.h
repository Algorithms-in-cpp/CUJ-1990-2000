#ifndef RESULTIOU_H
#define RESULTIOU_H

#include "error.h"

struct IResultIOU;

class IOUSink;

class ResultIOU : public SupportsErrorInfo
{
friend IOUSink;

public:
    ResultIOU(IResultIOUReadable* pResultIOU=0);
    ResultIOU(const ResultIOU&);
    virtual ~ResultIOU();

    ResultIOU& operator=(const ResultIOU& rhs);
	VARIANT Redeem();

protected:
    virtual void getErrorInfoParams( IUnknown *&pUnk, const IID *&riid) const;
    virtual void ResultIOUComplete() {}

private:
    void Close(IResultIOUReadable* pResultIOU);

    IResultIOUReadable *pResultIOU_;

    friend class Request;
};

#endif
