#ifndef ERROR_H
#define ERROR_H

#include <windows.h>

class SupportsErrorInfo;

class Error
{
public:
    static void clearError();
    static bool setError( const SupportsErrorInfo &object, HRESULT hResult = S_OK);
    static HRESULT HResult()
            { return hResult_; }
    static GUID Guid() 
            { return guid_; }
    static const char* Description()
            { return szDescription_; }
    static const char* HResultText()
            { return szHResultText_; }
    static DWORD HelpContext() 
            { return dwHelpContext_; }
    static const char* HelpFile() 
            { return szHelpFile_; }
    static const char* HelpSource() 
            { return szHelpSource_; }

private:
    static HRESULT hResult_;
    static GUID guid_;
    static DWORD dwHelpContext_;
    enum { MAX_STRING_LEN = 256 };
    static char szDescription_[MAX_STRING_LEN];
    static char szHelpFile_[MAX_STRING_LEN];
    static char szHelpSource_[MAX_STRING_LEN];
    static char szHResultText_[MAX_STRING_LEN];

};

class SupportsErrorInfo
{
public:
    virtual bool checkErrors() 
        { return Error::setError( *this); }
protected:
    virtual void getErrorInfoParams( IUnknown *&pUnk, const IID *&riid) const = 0;
    friend class Error;
};

#endif