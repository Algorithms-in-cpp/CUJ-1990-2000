#include "main.h"
#include "request.h"
#include "IOUSink.h"

Request::Request()
    : pRequest_(0)
{
    // clear the global error object
    Error::clearError();

    HRESULT hr = ::CoCreateInstance(CLSID_Request, 0,
                                    CLSCTX_INPROC_SERVER,
                                    IID_IRequest,
                                    (void**)&pRequest_);

    if (FAILED(hr))
        Error::setError( *this, hr);
}

Request::~Request()
{
    if (pRequest_)
        pRequest_->Release();
}

void 
Request::getErrorInfoParams( IUnknown *&pUnk, const IID *&riid) const
{ 
    pUnk = pRequest_; 
    riid = &IID_IRequest; 
}

bool 
Request::select(BSTR selectStatement)
{
    assert(pRequest_);

    // clear the global error object
    Error::clearError();

    bool success = false;
    HRESULT hr = pRequest_->Select(selectStatement);
	return (SUCCEEDED(hr)) ? true : (Error::setError(*this, hr), false);
}

bool
Request::send(bool notify, ResultIOU& IOU)
{
    assert(pRequest_);

    // clear the global error object
    Error::clearError();

    bool success = false;
    IResultIOUReadable *pIOU = 0;
    HRESULT hr = pRequest_->Send(&pIOU);
    if (SUCCEEDED(hr))
    {
        IOU.Close(pIOU);
        if (notify)
        {
            IOUSink *pIOUSink = createAndConnectSink(pIOU);
            if (pIOUSink)
            {
                pIOUSink->setResultIOU(&IOU);
                success = true;
            }
        }
        else
            success = true;
		pIOU->Release();
    }
    else
        Error::setError( *this, hr);

    return success;
}

IOUSink* 
Request::createAndConnectSink(IResultIOUReadable *pIOU)
{
    IConnectionPointContainer *pcpc = 0;
    HRESULT hr = pIOU->QueryInterface(IID_IConnectionPointContainer,
                                        (void**)&pcpc);
    if (SUCCEEDED(hr))
    {
        IOUSink *ppes = new IOUSink;
        ppes->AddRef();
        IConnectionPoint *pcp = 0;
        hr = pcpc->FindConnectionPoint(IID_IResultNotifier, &pcp);
        if (SUCCEEDED(hr))
        {   
            DWORD dwReg = 0;
            pcp->Advise((IResultNotifier*)ppes, &dwReg);
            pcp->Release();
        }
        else
            Error::setError( *this, hr);

        ppes->Release();
        pcpc->Release();
        return ppes;
    }
    else
        Error::setError( *this, hr);
    return 0;
}
