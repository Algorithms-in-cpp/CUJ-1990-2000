// Event.h : Declaration of the Event

#ifndef __EVENT_H_
#define __EVENT_H_

class Event
{
public:
    Event(LPCTSTR name = 0);
	Event(const Event&);
    const Event& operator=(const Event&);
    ~Event();

	DWORD Wait() const;
	BOOL Signal() const;
	LPCTSTR Name() const;

private:
    HANDLE handle_;
	LPCTSTR name_;
};

#endif