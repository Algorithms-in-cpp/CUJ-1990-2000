// RefCountBase.h : Declaration of the RefCountBase

#ifndef __REFCOUNTBASE_H_
#define __REFCOUNTBASE_H_

class RefCountBase
{
public:
	void AddRef();
	void RemoveRef();

	void MarkUnshareable();
	bool IsShareable() const;
	bool IsShared() const;

protected:
	RefCountBase();
	RefCountBase(const RefCountBase& rhs);
	RefCountBase& operator=(const RefCountBase& rhs);
	virtual ~RefCountBase();

private:
	unsigned int count;
	bool shareable;
};

#endif