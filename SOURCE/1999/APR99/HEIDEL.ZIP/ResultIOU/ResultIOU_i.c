/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Jan 22 14:55:25 1999
 */
/* Compiler settings for ResultIOU.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IResultNotifier = {0x3A248150,0x41B9,0x11d2,{0xBB,0x27,0x00,0x60,0x08,0x92,0x6E,0x48}};


const IID IID_IResultIOUReadable = {0x41B6E980,0x62DA,0x11D2,{0xBB,0x30,0x00,0x60,0x08,0x92,0x6E,0x48}};


const IID IID_IResultIOUWriteable = {0xBF947990,0x41AC,0x11d2,{0xBB,0x27,0x00,0x60,0x08,0x92,0x6E,0x48}};


const IID IID_IRequest = {0x41B6E97F,0x62DA,0x11D2,{0xBB,0x30,0x00,0x60,0x08,0x92,0x6E,0x48}};


const IID LIBID_RESULTIOULib = {0x41B6E972,0x62DA,0x11D2,{0xBB,0x30,0x00,0x60,0x08,0x92,0x6E,0x48}};


const CLSID CLSID_Request = {0x4B5A9CF7,0x5880,0x11D2,{0xBB,0x2E,0x00,0x60,0x08,0x92,0x6E,0x48}};


const CLSID CLSID_ResultIOU = {0x41B6E981,0x62DA,0x11D2,{0xBB,0x30,0x00,0x60,0x08,0x92,0x6E,0x48}};


#ifdef __cplusplus
}
#endif

