#include "stdafx.h"
#include "request_.h"

#include <assert.h>
#include <process.h>
#include <errno.h>

#include "ResultIOU.h"
#include "result.h"

void __cdecl 
Request_::threadFunc_(void* thisObject)
{
	((Request_*)thisObject)->doRequest();
}

Request_::Request_()
: pResult_(0), selectStatement_(0), threadID_(0)
{
}

Request_::Request_(BSTR selectStatement, CResultIOU *pResult)
: pResult_(pResult), selectStatement_(selectStatement), threadID_(0)
{
}

const Request_&
Request_::operator=(const Request_& rhs)
{
    pResult_ = rhs.pResult_;
    selectStatement_ = rhs.selectStatement_;
    
    return *this;
}

Request_::~Request_()
{
}

void
Request_::Process()
{
	// Create the new thread...
    threadID_ = ::_beginthread(threadFunc_, 0, (void*)this);
    if (0 == threadID_) 
    {
		switch(errno) 
		{
			case EAGAIN:
				OutputDebugString("Request_::Process - Too many threads.");
			case EINVAL:
				OutputDebugString("Request_::Process - Invalid argument or stack size error.");
			default:
				OutputDebugString("Request_::Process - Unknown error.");
		}
		assert(0);
	}
}

void
Request_::doRequest()
{
    try {
        ::OutputDebugString("Processing request...\n");

        // Simulate processing the request
        ::Sleep(3000);
        
        // request complete, notify the IOU
		pResult_->put_Result(CComVariant("701 Brazos St."));
    }
    catch (...)
    {
		::OutputDebugString("Request_::doRequest - Error processing request");
    }
}

