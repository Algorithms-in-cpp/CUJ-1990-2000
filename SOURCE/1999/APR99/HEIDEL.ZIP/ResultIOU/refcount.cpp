#include "stdafx.h"
#include "refcount.h"

RefCount:: RefCount() 
: count(0), shareable(true)
{
}

RefCount:: RefCount(const RefCount& rhs)
 : count(0), shareable(true)
{
}

RefCount& 
RefCount::operator = (const RefCount& rhs)
{
	return *this;
}

RefCount::~RefCount()
{
}

void
RefCount::addRef()
{
	++count;
}

void
RefCount::removeRef()
{
	if (--count == 0)
		delete this;
}

bool
RefCount::isShareable() const
{
	return shareable;
}

void
RefCount::markUnshareable()
{
	shareable  = false;
}

bool
RefCount::isShared() const
{
	return count > 1;
}

