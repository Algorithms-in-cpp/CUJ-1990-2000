// Event.cpp : Implementation of Event class

// Event is a simple wrapper class for a Windows
// event object.

#include "stdafx.h"
#include "Event.h"

Event::Event(LPCTSTR name)
: name_(name ? name : "IOUEvent")
{
	handle_ = ::CreateEvent(NULL, FALSE, FALSE, name_);
}

Event::Event(const Event& rhs)
: name_(rhs.name_), handle_(rhs.handle_)
{
}

const Event& 
Event::operator=(const Event& rhs)
{
	name_ = rhs.name_;
	handle_ = rhs.handle_;

	return *this;
}

Event::~Event()
{
	::CloseHandle(handle_);
}

DWORD
Event::Wait() const
{
	return ::WaitForSingleObject(handle_, INFINITE);
}

BOOL
Event::Signal() const
{
	return ::SetEvent(handle_);
}

LPCTSTR
Event::Name() const
{
	return name_;
}
