// Refcount.h : Declaration of the RefCount

#ifndef __REFCOUNT_H_
#define __REFCOUNT_H_

class RefCount
{
public:
	void addRef();
	void removeRef();

	void markUnshareable();
	bool isShareable() const;
	bool isShared() const;

protected:
	RefCount();
	RefCount(const RefCount& rhs);
	RefCount& operator=(const RefCount& rhs);
	virtual ~RefCount();

private:
	unsigned int count;
	bool shareable;
};

#endif