/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Jan 22 14:55:25 1999
 */
/* Compiler settings for ResultIOU.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ResultIOU_h__
#define __ResultIOU_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IResultNotifier_FWD_DEFINED__
#define __IResultNotifier_FWD_DEFINED__
typedef interface IResultNotifier IResultNotifier;
#endif 	/* __IResultNotifier_FWD_DEFINED__ */


#ifndef __IResultIOUReadable_FWD_DEFINED__
#define __IResultIOUReadable_FWD_DEFINED__
typedef interface IResultIOUReadable IResultIOUReadable;
#endif 	/* __IResultIOUReadable_FWD_DEFINED__ */


#ifndef __IResultIOUWriteable_FWD_DEFINED__
#define __IResultIOUWriteable_FWD_DEFINED__
typedef interface IResultIOUWriteable IResultIOUWriteable;
#endif 	/* __IResultIOUWriteable_FWD_DEFINED__ */


#ifndef __IRequest_FWD_DEFINED__
#define __IRequest_FWD_DEFINED__
typedef interface IRequest IRequest;
#endif 	/* __IRequest_FWD_DEFINED__ */


#ifndef __Request_FWD_DEFINED__
#define __Request_FWD_DEFINED__

#ifdef __cplusplus
typedef class Request Request;
#else
typedef struct Request Request;
#endif /* __cplusplus */

#endif 	/* __Request_FWD_DEFINED__ */


#ifndef __ResultIOU_FWD_DEFINED__
#define __ResultIOU_FWD_DEFINED__

#ifdef __cplusplus
typedef class ResultIOU ResultIOU;
#else
typedef struct ResultIOU ResultIOU;
#endif /* __cplusplus */

#endif 	/* __ResultIOU_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IResultNotifier_INTERFACE_DEFINED__
#define __IResultNotifier_INTERFACE_DEFINED__

/* interface IResultNotifier */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IResultNotifier;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("3A248150-41B9-11d2-BB27-006008926E48")
    IResultNotifier : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RequestComplete( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IResultNotifierVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IResultNotifier __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IResultNotifier __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IResultNotifier __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IResultNotifier __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IResultNotifier __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IResultNotifier __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IResultNotifier __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RequestComplete )( 
            IResultNotifier __RPC_FAR * This);
        
        END_INTERFACE
    } IResultNotifierVtbl;

    interface IResultNotifier
    {
        CONST_VTBL struct IResultNotifierVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IResultNotifier_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IResultNotifier_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IResultNotifier_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IResultNotifier_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IResultNotifier_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IResultNotifier_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IResultNotifier_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IResultNotifier_RequestComplete(This)	\
    (This)->lpVtbl -> RequestComplete(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IResultNotifier_RequestComplete_Proxy( 
    IResultNotifier __RPC_FAR * This);


void __RPC_STUB IResultNotifier_RequestComplete_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IResultNotifier_INTERFACE_DEFINED__ */


#ifndef __IResultIOUReadable_INTERFACE_DEFINED__
#define __IResultIOUReadable_INTERFACE_DEFINED__

/* interface IResultIOUReadable */
/* [object][unique][helpstring][uuid] */ 


EXTERN_C const IID IID_IResultIOUReadable;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("41B6E980-62DA-11D2-BB30-006008926E48")
    IResultIOUReadable : public IUnknown
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Redeemable( 
            /* [retval][out] */ BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Redeem( 
            /* [retval][out] */ VARIANT __RPC_FAR *result) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Abort( void) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Aborted( 
            /* [retval][out] */ BOOL __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IResultIOUReadableVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IResultIOUReadable __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IResultIOUReadable __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IResultIOUReadable __RPC_FAR * This);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Redeemable )( 
            IResultIOUReadable __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Redeem )( 
            IResultIOUReadable __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *result);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Abort )( 
            IResultIOUReadable __RPC_FAR * This);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Aborted )( 
            IResultIOUReadable __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pVal);
        
        END_INTERFACE
    } IResultIOUReadableVtbl;

    interface IResultIOUReadable
    {
        CONST_VTBL struct IResultIOUReadableVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IResultIOUReadable_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IResultIOUReadable_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IResultIOUReadable_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IResultIOUReadable_get_Redeemable(This,pVal)	\
    (This)->lpVtbl -> get_Redeemable(This,pVal)

#define IResultIOUReadable_Redeem(This,result)	\
    (This)->lpVtbl -> Redeem(This,result)

#define IResultIOUReadable_Abort(This)	\
    (This)->lpVtbl -> Abort(This)

#define IResultIOUReadable_get_Aborted(This,pVal)	\
    (This)->lpVtbl -> get_Aborted(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IResultIOUReadable_get_Redeemable_Proxy( 
    IResultIOUReadable __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pVal);


void __RPC_STUB IResultIOUReadable_get_Redeemable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IResultIOUReadable_Redeem_Proxy( 
    IResultIOUReadable __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *result);


void __RPC_STUB IResultIOUReadable_Redeem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IResultIOUReadable_Abort_Proxy( 
    IResultIOUReadable __RPC_FAR * This);


void __RPC_STUB IResultIOUReadable_Abort_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IResultIOUReadable_get_Aborted_Proxy( 
    IResultIOUReadable __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pVal);


void __RPC_STUB IResultIOUReadable_get_Aborted_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IResultIOUReadable_INTERFACE_DEFINED__ */


#ifndef __IResultIOUWriteable_INTERFACE_DEFINED__
#define __IResultIOUWriteable_INTERFACE_DEFINED__

/* interface IResultIOUWriteable */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IResultIOUWriteable;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("BF947990-41AC-11d2-BB27-006008926E48")
    IResultIOUWriteable : public IUnknown
    {
    public:
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Result( 
            /* [in] */ VARIANT result) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IResultIOUWriteableVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IResultIOUWriteable __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IResultIOUWriteable __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IResultIOUWriteable __RPC_FAR * This);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Result )( 
            IResultIOUWriteable __RPC_FAR * This,
            /* [in] */ VARIANT result);
        
        END_INTERFACE
    } IResultIOUWriteableVtbl;

    interface IResultIOUWriteable
    {
        CONST_VTBL struct IResultIOUWriteableVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IResultIOUWriteable_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IResultIOUWriteable_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IResultIOUWriteable_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IResultIOUWriteable_put_Result(This,result)	\
    (This)->lpVtbl -> put_Result(This,result)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IResultIOUWriteable_put_Result_Proxy( 
    IResultIOUWriteable __RPC_FAR * This,
    /* [in] */ VARIANT result);


void __RPC_STUB IResultIOUWriteable_put_Result_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IResultIOUWriteable_INTERFACE_DEFINED__ */


#ifndef __IRequest_INTERFACE_DEFINED__
#define __IRequest_INTERFACE_DEFINED__

/* interface IRequest */
/* [object][unique][helpstring][uuid] */ 


EXTERN_C const IID IID_IRequest;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("41B6E97F-62DA-11D2-BB30-006008926E48")
    IRequest : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Send( 
            /* [retval][out] */ IResultIOUReadable __RPC_FAR *__RPC_FAR *resultIOU) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Select( 
            /* [in] */ BSTR selectStatement) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRequestVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IRequest __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IRequest __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IRequest __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Send )( 
            IRequest __RPC_FAR * This,
            /* [retval][out] */ IResultIOUReadable __RPC_FAR *__RPC_FAR *resultIOU);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Select )( 
            IRequest __RPC_FAR * This,
            /* [in] */ BSTR selectStatement);
        
        END_INTERFACE
    } IRequestVtbl;

    interface IRequest
    {
        CONST_VTBL struct IRequestVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRequest_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRequest_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRequest_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IRequest_Send(This,resultIOU)	\
    (This)->lpVtbl -> Send(This,resultIOU)

#define IRequest_Select(This,selectStatement)	\
    (This)->lpVtbl -> Select(This,selectStatement)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IRequest_Send_Proxy( 
    IRequest __RPC_FAR * This,
    /* [retval][out] */ IResultIOUReadable __RPC_FAR *__RPC_FAR *resultIOU);


void __RPC_STUB IRequest_Send_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IRequest_Select_Proxy( 
    IRequest __RPC_FAR * This,
    /* [in] */ BSTR selectStatement);


void __RPC_STUB IRequest_Select_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IRequest_INTERFACE_DEFINED__ */



#ifndef __RESULTIOULib_LIBRARY_DEFINED__
#define __RESULTIOULib_LIBRARY_DEFINED__

/* library RESULTIOULib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_RESULTIOULib;

EXTERN_C const CLSID CLSID_Request;

#ifdef __cplusplus

class DECLSPEC_UUID("4B5A9CF7-5880-11D2-BB2E-006008926E48")
Request;
#endif

EXTERN_C const CLSID CLSID_ResultIOU;

#ifdef __cplusplus

class DECLSPEC_UUID("41B6E981-62DA-11D2-BB30-006008926E48")
ResultIOU;
#endif
#endif /* __RESULTIOULib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
