// Result.h : Declaration of the CResultIOU

#ifndef __CRESULTIOU_H_
#define __CRESULTIOU_H_

#include "resource.h"       // main symbols
#include "refCountPtr.h"
#include "resultIOU_.h"
#include "request_.h"
#include "CPResultIOU.h"

/////////////////////////////////////////////////////////////////////////////
// CResultIOU
class ATL_NO_VTABLE CResultIOU : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CResultIOU, &CLSID_ResultIOU>,
	public IConnectionPointContainerImpl<CResultIOU>,
	public IResultIOUReadable,
    public IResultIOUWriteable,
    public CProxyIResultNotifier<CResultIOU>
{
public:
	CResultIOU() : result_(new ResultIOU_<_variant_t>)
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_RESULT)
DECLARE_NOT_AGGREGATABLE(CResultIOU)

BEGIN_COM_MAP(CResultIOU)
	COM_INTERFACE_ENTRY(IResultIOUReadable)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CResultIOU)
    CONNECTION_POINT_ENTRY(IID_IResultNotifier)
END_CONNECTION_POINT_MAP()


// IResultIOUReadable
public:
	STDMETHOD(get_Aborted)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(Abort)();
	STDMETHOD(Redeem)(/*[out, retval]*/ VARIANT* value);
	STDMETHOD(get_Redeemable)(/*[out, retval]*/ BOOL *pVal);

// IResultIOUWriteable
	STDMETHOD(put_Result)(VARIANT result);

    void Process(BSTR selectStatement_);

private:
    RefCountPtr< ResultIOU_<_variant_t> > result_;
    Request_ request_;
};

#endif //__RESULT_H_
