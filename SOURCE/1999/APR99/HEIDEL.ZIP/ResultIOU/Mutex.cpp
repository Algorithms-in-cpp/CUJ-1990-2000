// Mutex.cpp : Implementation of Mutex class

// Mutex is a simple wrapper class for a Windows
// Mutex object.

#include "stdafx.h"
#include "Mutex.h"

Mutex::Mutex(LPCTSTR name, bool acquire)
: name_(name ? name : "IOUMutex")
{
	handle_ = ::CreateMutex(NULL, acquire, name_);
}

Mutex::Mutex(const Mutex& rhs)
: name_(rhs.name_), handle_(rhs.handle_)
{
	Acquire();
}

const Mutex& 
Mutex::operator=(const Mutex& rhs)
{
	name_ = rhs.name_;
	handle_ = rhs.handle_;

	return *this;
}

Mutex::~Mutex()
{
	::ReleaseMutex(handle_);
}

DWORD
Mutex::Acquire() const
{
	return ::WaitForSingleObject(handle_, INFINITE);
}

BOOL
Mutex::Release() const
{
	return ::ReleaseMutex(handle_);
}

LPCTSTR
Mutex::Name() const
{
	return name_;
}
