
//////////////////////////////////////////////////////////////////////////////
// CProxyIResultNotifier
template <class T>
class CProxyIResultNotifier : public IConnectionPointImpl<T, &IID_IResultNotifier, CComDynamicUnkArray>
{
public:

//IResultNotifier : IDispatch
public:
	HRESULT Fire_RequestComplete()
	{
		T* pT = (T*)this;
		pT->Lock();
		HRESULT ret;
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				IResultNotifier* pIResultNotifier = reinterpret_cast<IResultNotifier*>(*pp);
				ret = pIResultNotifier->RequestComplete();
			}
			pp++;
		}
		pT->Unlock();
		return ret;
	}
};

