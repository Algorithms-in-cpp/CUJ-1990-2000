// Mutex.h : Declaration of the Mutex

#ifndef __MUTEX_H_
#define __MUTEX_H_

class Mutex
{
public:
    Mutex(LPCTSTR name = 0, bool acquire = false);
	Mutex(const Mutex& rhs);
    const Mutex& operator=(const Mutex& rhs);
    ~Mutex();

	DWORD Acquire() const;
	BOOL Release() const;
	LPCTSTR Name() const;

private:
    LPCTSTR name_;
	HANDLE handle_;
};

#endif