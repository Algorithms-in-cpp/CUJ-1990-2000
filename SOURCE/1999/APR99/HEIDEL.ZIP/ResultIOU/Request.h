// Request.h : Declaration of the CRequest

#ifndef __REQUEST_H_
#define __REQUEST_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CRequest
class ATL_NO_VTABLE CRequest : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CRequest, &CLSID_Request>,
	public IRequest
{
public:
	CRequest()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_REQUEST)
DECLARE_NOT_AGGREGATABLE(CRequest)

BEGIN_COM_MAP(CRequest)
	COM_INTERFACE_ENTRY(IRequest)
END_COM_MAP()

// IRequest
public:
	STDMETHOD(Select)(/*[in]*/ BSTR selectStatement);
	STDMETHOD(Send)(/*[out, retval]*/IResultIOUReadable ** resultIOU);

    BSTR selectStatement_;
};

#endif //__REQUEST_H_
