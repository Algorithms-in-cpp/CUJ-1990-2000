#include "stdafx.h"
#include "refcount.h"
#include "refcountptr.h"

class foo : public RefCount
{

};

refCountPtr<foo> fooPtr = new foo;
