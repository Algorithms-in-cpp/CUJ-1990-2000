// resultiou.h : Declaration of the resultiou

#ifndef __RESULTIOU__H_
#define __RESULTIOU__H_

#include "refcountbase.h"
#include "mutex.h"
#include "event.h"

template<class T>
class ResultIOU_ : public RefCountBase
{
public:
    ResultIOU_();
    virtual ~ResultIOU_();
	ResultIOU_(const ResultIOU_& rhs);
	ResultIOU_& operator=(const ResultIOU_& rhs);

    void Abort();
    T Redeem();
    bool Redeemable() const;
    bool Aborted() const;
    void Close(T t);

private:
    T t_;
	Event closedEvent_;
	Mutex mutex_;
    bool resultReady_;
    bool aborted_;
};

template<class T>
inline
ResultIOU_<T>::ResultIOU_()
: resultReady_(false), aborted_(false)
{
}

template<class T>
inline
ResultIOU_<T>::~ResultIOU_()
{
}

template<class T>
inline
ResultIOU_<T>::ResultIOU_(const ResultIOU_& rhs)
: resultReady_(rhs.resultReady_), aborted_(rhs.aborted_), t_(rhs.t_), closedEvent_(rhs.closedEvent_)
{
}

template<class T>
inline
ResultIOU_<T>&
ResultIOU_<T>::operator=(const ResultIOU_& rhs)
{
	resultReady_ = rhs.resultReady;
	aborted_ = rhs.aborted_;
	t_ = rhs.t_;
	closedEvent_ = rhs.closedEvent_;

	return *this;
}

template<class T>
inline
void ResultIOU_<T>::Abort()
{
	Mutex mutex(mutex_);

    // set result ready flag
    resultReady_ = true;
    
    // set aborted flag
    aborted_ = true;
}

template<class T>
inline
void ResultIOU_<T>::Close(T t)
{
	Mutex mutex(mutex_);

    if (aborted_)
        return;

    t_ = t;
    resultReady_ = true;

    // Signal threads blocked in _redeem().
	closedEvent_.Signal();

    mutex.Release();
}

template<class T>
inline
T ResultIOU_<T>::Redeem()
{
	Mutex mutex(mutex_);

    while (!resultReady_)
	{
		mutex.Release();
		closedEvent_.Wait();
	}

    return t_;
}

template<class T>
inline
bool ResultIOU_<T>::Redeemable() const
{
	Mutex mutex(mutex_);

    return resultReady_;
}


template<class T>
inline
bool ResultIOU_<T>::Aborted() const
{
	Mutex mutex(mutex_);

    return aborted_;
}

#endif