#include "stdafx.h"
#include "RefCountBase.h"

RefCountBase:: RefCountBase() 
: count(0), shareable(true)
{
}

RefCountBase:: RefCountBase(const RefCountBase& rhs)
 : count(0), shareable(true)
{
}

RefCountBase& 
RefCountBase::operator = (const RefCountBase& rhs)
{
	return *this;
}

RefCountBase::~RefCountBase()
{
}

void
RefCountBase::AddRef()
{
	++count;
}

void
RefCountBase::RemoveRef()
{
	if (--count == 0)
		delete this;
}

bool
RefCountBase::IsShareable() const
{
	return shareable;
}

void
RefCountBase::MarkUnshareable()
{
	shareable  = false;
}

bool
RefCountBase::IsShared() const
{
	return count > 1;
}

