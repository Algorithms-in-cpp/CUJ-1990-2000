#include "stdafx.h"
#include "refCountPtr.h"

template<class T>
void
refCountPtr<T>::init()
{
	if (pointee == 0)
		return;

	if (pointee->isShareable() == false)
		pointee = new T(*pointee);
}

template<class T>
refCountPtr<T>::refCountPtr(T* realptr)
: pointee(realptr)
{
	init();
}

template<class T>
refCountPtr<T>::refCountPtr(const refCountPtr& rhs)
: pointee(rhs.pointee)
{
	init();
}

template<class T>
refCountPtr<T>::~refCountPtr()
{
	if (pointee)
		pointee->removeRef();
}

template<class T>
refCountPtr<T>&
refCountPtr<T>::operator=(const refCountPtr& rhs)
{
	if (pointee != rhs.pointee)
	{
		if (pointee)
			pointee->removeRef();
		pointee = rhs.pointee;
		init();
	}
	return *this;
}

template<class T>
T*
refCountPtr<T>::operator->() const
{
	return pointee;
}

template<class T>
T&
refCountPtr<T>::operator*() const
{
	return *pointee;
}
