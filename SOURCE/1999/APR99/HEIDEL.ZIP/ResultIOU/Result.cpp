// Result.cpp : Implementation of CResultIOU
#include "stdafx.h"
#include "ResultIOU.h"
#include "Result.h"

/////////////////////////////////////////////////////////////////////////////
// CResultIOU

STDMETHODIMP 
CResultIOU::get_Redeemable(BOOL * pVal)
{
    *pVal = (result_->Redeemable()) ? -1 : 0;

	return S_OK;
}

STDMETHODIMP 
CResultIOU::Redeem(VARIANT * value)
{
    _variant_t value_(result_->Redeem());
    *value = value_.Detach();

    return S_OK;
}

STDMETHODIMP 
CResultIOU::Abort()
{
	result_->Abort();

	return S_OK;
}

STDMETHODIMP 
CResultIOU::put_Result(VARIANT result)
{
    result_->Close(_variant_t(result));
    
    // notify clients
    Fire_RequestComplete();

	return S_OK;
}

void
CResultIOU::Process(BSTR selectStatement)
{
    request_ = Request_(selectStatement, this);
    request_.Process();
}

STDMETHODIMP 
CResultIOU::get_Aborted(BOOL * pVal)
{
    *pVal = (result_->Aborted()) ? -1 : 0;

	return S_OK;
}
