// Request.cpp : Implementation of CRequest
#include "stdafx.h"
#include "ResultIOU.h"
#include "Request.h"
#include "Result.h"

/////////////////////////////////////////////////////////////////////////////
// CRequest
                        
STDMETHODIMP 
CRequest::Send(IResultIOUReadable ** resultIOU)
{
    HRESULT hResult;
    try
    {
        *resultIOU = 0;
        
        // Create the IOU
        CComObject<CResultIOU> *pResult;
	    CComObject<CResultIOU>::CreateInstance(&pResult);

        pResult->Process(selectStatement_);

        // Return the IOU
        hResult = pResult->QueryInterface(IID_IResultIOUReadable, (void**)resultIOU);
    }
    catch ( ... )
    {
        hResult = E_FAIL;
    }
	return hResult;
}

STDMETHODIMP 
CRequest::Select(BSTR selectStatement)
{
	// Store the select statement
    selectStatement_ = selectStatement;

	return S_OK;
}

