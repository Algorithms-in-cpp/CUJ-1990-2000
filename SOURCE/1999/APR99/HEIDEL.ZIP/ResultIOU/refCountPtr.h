
#ifndef __REFCOUNTPTR_H_
#define __REFCOUNTPTR_H_

template<class T>
class RefCountPtr
{
public:
	RefCountPtr(T* realPtr = 0);
	RefCountPtr(const RefCountPtr& rhs);
	~RefCountPtr();

	RefCountPtr& operator=(const RefCountPtr& rhs);
	T* operator->() const;
	T& operator*() const;

private:
	T* pointee;

	void Init();
};

template<class T>
inline
void
RefCountPtr<T>::Init()
{
	if (pointee == 0)
		return;

	if (pointee->IsShareable() == false)
		pointee = new T(*pointee);

	pointee->AddRef();
}

template<class T>
inline
RefCountPtr<T>::RefCountPtr(T* realptr)
: pointee(realptr)
{
	Init();
}

template<class T>
inline
RefCountPtr<T>::RefCountPtr(const RefCountPtr& rhs)
: pointee(rhs.pointee)
{
	Init();
}

template<class T>
inline
RefCountPtr<T>::~RefCountPtr()
{
	if (pointee)
		pointee->RemoveRef();
}

template<class T>
inline
RefCountPtr<T>&
RefCountPtr<T>::operator=(const RefCountPtr& rhs)
{
	if (pointee != rhs.pointee)
	{
		if (pointee)
			pointee->RemoveRef();
		pointee = rhs.pointee;
		init();
	}
	return *this;
}

template<class T>
inline
T*
RefCountPtr<T>::operator->() const
{
	return pointee;
}

template<class T>
inline
T&
RefCountPtr<T>::operator*() const
{
	return *pointee;
}

#endif