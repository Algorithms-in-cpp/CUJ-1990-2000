#ifndef businessObjectImpl_h
#define businessObjectImpl_h

#include "businessObject_s.hh"


class businessObjectImpl : public  _sk_businessObject 
{
	CORBA::String_var       m_objName;

public:
	businessObjectImpl(char *);
	virtual ~businessObjectImpl();

	char *  getName( );
};

#endif

