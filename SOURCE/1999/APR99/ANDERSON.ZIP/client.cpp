#include "AWSNames.h"

#include "businessObject_c.hh"

int main(int argc, char**argv) 
{
	CORBA::ORB_var		orb = CORBA::ORB_init(argc, argv);
	AWSNames			names( orb );


    CORBA::Object_ptr	objPtr; 
	businessObject_var	businessObject;

	try {
		objPtr = names.getObject( argv[1] );
	}
	catch(...) {
		cout << "Could not resolve object name." << endl;
		exit(1);
	}
	

	try {
		businessObject = businessObject::_narrow(objPtr);

		if (CORBA::is_nil(businessObject))
		{
			cout << "Narrow failed." << endl;
			exit(1);
		}
	}
	catch (CORBA::SystemException &) {
		cout << "Exception occurred in _narrow." << endl;
		exit(1);
	}

	try {
		cout << "Got Object " << businessObject->getName() << endl;
	}
	catch (...) {
		cout << "Exception occurred in getName." << endl;
		exit(1);
	}

	return 0;
}


