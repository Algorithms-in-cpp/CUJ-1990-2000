
#include "AWSServer.h"
#include "AWSNames.h"
#include "Utilities.h"


AWSServer*		AWSServer::m_serverInstance = NULL;


/**
 * Gets the current instance of the AWSServer.
 *
 * @returns The AWSServer instance.
 */
AWSServer* AWSServer::instance( )
{
	return m_serverInstance;
}

/**
 * Gets the current instance of the AWSServer.  If the
 * instance does not exist, it is created.
 *
 * @param argc			Number of arguments in argv.
 * @param argv			Command line arguments.
 * @param serverName	Name to be associated with the server process.
 * @param loadBalancing	The load-balancing object to be used in 
 *						conjunction with this server.
 *
 * @returns The AWSServer instance.
 */
AWSServer* AWSServer::instance(	int					&argc, 
								char				**argv, 
								const char			*serverName, 
								AWSLoadBalancing	*loadBalancing )
{
	if (m_serverInstance == NULL)
		m_serverInstance = new AWSServer( argc, argv, serverName, loadBalancing );

	return m_serverInstance;
}

/**
 * The constructor for the AWSServer class.  The command line arguments
 * are parsed to determine the action requested (i.e. run, bind, unbind).
 * The ORB and BOA are initialized.  If a load-balancing object was
 * given, it is initialized with the orb and boa, and object scoping is
 * set to local.  Any server objects created prior to this will, by default,
 * have a global scope and name clashes with other server processes
 * may cause load balancing to behave in unexpected ways.
 *
 * @param argc			Number of arguments in argv.
 * @param argv			Command line arguments.
 * @param serverName	Name to be associated with the server process.
 * @param loadBalancing	The load-balancing object to be used in 
 *						conjunction with this server.
 */
AWSServer::AWSServer(	int					&argc, 
						char				**argv, 
						const char			*serverName, 
						AWSLoadBalancing	*loadBalancing )
{
	Options		options( "run,bind,unbind" );

	options.parse( argc, argv );

	m_serverName	= CORBA::string_dup(serverName);
	m_loadBalancing	= NULL;

	if (loadBalancing != NULL)
		m_loadBalancing = (AWSLoadBalancing *)LoadBalancing::IAgent::_duplicate(loadBalancing);

	/*
	 * Check command line arguments for '-bind', '-unbind', and/or '-run'.
	 */
	m_bindObjects	= options.isFound( "bind" );
	m_runServer		= options.isFound( "run" );
	m_unbindObjects	= options.isFound( "unbind" );

	/*
	 * If no arguments were specified, set the default behavior based
	 * on whether or not Load Balancing is being used.
	 */
	if ( !(m_bindObjects || m_runServer || m_unbindObjects) )
	{
		/*
		 * Always run the server regardless of Load Balancing.
		 */
		m_runServer = 1;

		/* 
		 * If not using load balancing, bind names, run the server,
		 * and then unbind the names on shutdown.
		 */
		if (m_loadBalancing == NULL)
		{
			m_bindObjects	= 1;
			m_unbindObjects	= 1;
		}
	}


	/*
	 * Initialize the ORB and BOA.
	 */
	try 
	{    
		m_orb = CORBA::ORB_init(argc, argv);

		m_boa = m_orb->BOA_init(argc, argv);
	} 
	catch(const CORBA::Exception& e) 
	{
		cerr << e << endl;   

		exit(1);  
	}


	/*
	 * If load-balancing if being used...
	 */
	if (m_loadBalancing != NULL)
	{
		/*
		 * Make all objects transient
		 */
		m_boa->scope(CORBA::BOA::SCOPE_LOCAL);

		try
		{
			m_loadBalancing->initialize( m_orb, m_boa );

		}
		catch(...)
		{
			throw AWSServerException( AWSServerException::LOAD_BALANCING_INIT_FAILED );
		}
	}
}


/**
 * Destructor.  Release the load balancing object if one 
 * was being used.
 */
AWSServer::~AWSServer( )
{
	if (m_loadBalancing != NULL)
		m_loadBalancing->_release( );
}

/**
 * Makes an object available to the server process.
 * If a load balancing object was specified in the
 * constructor, then the object will be registered
 * with the primary load balancing object and will
 * not be bound in the Naming service.  Otherwise,
 * the object will be bound to the given object name
 * in the Naming service.
 *
 * @param obj		The object to be vended by the server.
 * @param objName	The name to be associated with the object.
 */
void AWSServer::addObject(CORBA::Object_ptr objPtr, const char* objName)
{
	/*
	 * Add object to the list of managed objects.
	 *
	 * Check for uniqueness of name??
	 */
	append( objPtr, objName );
}

/**
 * Makes the given object unavailable to the server.
 * It will be unregistered from the primary load balancing
 * object (if one exists), and destroyed.
 *
 * @param obj		Reference to the object to be removed.
 */
void AWSServer::removeObject(CORBA::Object_ptr objPtr)
{
	/*
	 * Deactivate the object from the boa.
	 */
	m_boa->deactivate_obj( objPtr );


	/*
	 * Remove it from the list of managed objects.
	 */
	remove( objPtr );


	/*
	 * If load balancing is used, unregister it.
	 */
	if (m_loadBalancing != NULL)
		m_loadBalancing->unregisterObject( objPtr );
}

/**
 * Invokes the server's main event loop.  The server will 
 * process incoming requests until shutdown.
 *
 * @see shutdown
 *
 * @raises ServerException Error.
 */
void AWSServer::run( )
{
	AWSNames		names( m_orb );

	CORBA::ULong	len = m_objectList.length();

	/*
	 * Bind all named objects.
	 */
	if (m_bindObjects)
	{
		/*
		 * Register each named object with the Naming Service.
		 * Ignore any errors.
		 */
		for (CORBA::ULong idx=0; idx < len; idx++) 
		{
			if (m_objectList[idx].name != (const char *)NULL)
			{
				try
				{
					names.reregisterObject( m_objectList[idx].name, m_objectList[idx].objRef );
				}
				catch(...)
				{
					// Ignore any errors
				}
			}
		}
	}

	/*
	 * If load balancing is being used, register the managed objects
	 * with the load-balancing object, otherwise, ready the objects
	 * in the boa.  Execute the main event loop.
	 */
	if (m_runServer)
	{
		/*
		 * If Load Balancing is being used, register all objects 
		 * with the Load Balancing object, otherwise, simply
		 * ready the objects in the boa.
		 */
		for (CORBA::ULong idx=0; idx < len; idx++) 
		{
			if ( m_loadBalancing != NULL )
				m_loadBalancing->registerObject( m_objectList[idx].objRef );

			else
			{
				try
				{
					m_boa->obj_is_ready( m_objectList[idx].objRef );
				}
				catch(...)
				{
					// Ignore any errors
				}
			}
		}

		/*
		 * Execute the main event loop
		 */
		try
		{
			m_boa->impl_is_ready( );

		}
		catch(const CORBA::SystemException sysEx)
		{
			throw AWSServerException( AWSServerException::SYSTEM_EXCEPTION );
		}
		catch(...)
		{
			throw AWSServerException( AWSServerException::UNKNOWN );
		}
	}


	/*
	 * Unbind all named objects.
	 */
	if (m_unbindObjects)
	{
		/*
		 * Unregister each named object from the Naming Service.
		 * Ignore any errors.
		 */
		for (CORBA::ULong idx=0; idx < len; idx++) 
		{
			if (m_objectList[idx].name != (const char *)NULL)
			{
				try
				{
					names.unregisterObject( m_objectList[idx].name );
				}
				catch(...)
				{ 
					// Ignore any errors
				}
			}
		}
	}
}


/**
 * Adds an object to the end of the list of objects
 * which are managed by this server.
 *
 * @param objPtr	The object to be added.
 * @param name		The name of the object (optional)
 */
void AWSServer::append(CORBA::Object_ptr objPtr, const char *name) 
{
	VISMutex_var	lock(m_objectListMtx);
		
	CORBA::ULong	len = m_objectList.length();

	/*
	 * Extend the length of the object list sequence
	 */
	m_objectList.length(len+1);

	/*
	 * Save the object name if one was given.
	 */
	if (name != NULL)
		m_objectList[len].name = CORBA::string_dup(name);

	else
		m_objectList[len].name = (const char *) NULL;

	/*
	 * Save the object reference.
	 */
	m_objectList[len].objRef = CORBA::Object::_duplicate(objPtr);
}

/**
 * Removes the given object from the list of managed objects.
 *
 * @param objPtr	The object to be removed.
 */
void AWSServer::remove(CORBA::Object_ptr objPtr) 
{
	VISMutex_var	lock(m_objectListMtx);

	CORBA::ULong	len = m_objectList.length();
	CORBA::ULong	idx;

	/*
	 * Locate the object in the object list sequence.
	 */
	for (idx=0; idx < len; idx++) 
	{
		if (m_objectList[idx].objRef == objPtr)
			break;
	}

	/*
	 * If the object was found...
	 */
	if ( idx < len) 
	{
		/*
		 * Move all object list elements up one position
		 * in the sequence.
		 */
		for ( CORBA::ULong i=idx; i < len-1; i++)
		{
			if (m_objectList[i+1].name != (const char *)NULL)
				m_objectList[i].name = CORBA::string_dup(m_objectList[i+1].name);
			else
				m_objectList[i].name = (const char *)NULL;

			m_objectList[i].objRef = CORBA::Object::_duplicate(m_objectList[i+1].objRef);
		}

		/*
		 * Null the last element in the sequence so that
		 * it will be released.
		 */
		m_objectList[i].name = (const char *)NULL;
		m_objectList[i].objRef = CORBA::Object::_nil();

		/*
		 * Sequence is now one element shorter.
		 */
		m_objectList.length(len-1);		
	}	
}

