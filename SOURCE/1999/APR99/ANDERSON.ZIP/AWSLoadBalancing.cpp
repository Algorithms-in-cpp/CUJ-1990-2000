
#include "AWSLoadBalancing.h"
#include "AWSNames.h"

#ifdef DEBUG
#include <time.h>
#endif

#ifdef HPUX
#include <sys/pstat.h>
#endif

/*
 * Programmer's Note
 * - The AWSServer must be instantiated before the server objects.
 * If not, the server objects will be global in scope and the
 * osagent will get confused by the multiple objects sharing 
 * the same name.
 */



/*
 * Used in the interceptor.
 */
static AWSLoadBalancing					*g_loadBalancingServer;

static VISServerInterceptorFactory_ptr	g_interceptorFactory = NULL;
static LoadBalancing::IProxy_var		g_proxyObject = NULL;

static CORBA::ORB_var					g_orb;


/**
 * Default constructor.  The given name is used as the
 * name of the proxy object which clients will resolve to.
 * This same name with an "LB" appended to it is the name
 * used by the LoadBalancing object to locate other
 * instances of the LoadBalancing object in other servers.
 *
 * @param name	Name client application will resolve to, and
 *				used to locate other load-balancing objects.
 */
AWSLoadBalancing::AWSLoadBalancing(const char *name)
	: _sk_IAgent( )
{
	char	workBuffer[ 512 ];

	strcpy( workBuffer, name );
	strcat( workBuffer, "_LB" );

	m_name					= CORBA::string_dup(name);
	m_lbName				= CORBA::string_dup(workBuffer);

	m_orb					= NULL;
	m_master				= NULL;

	m_repositoryId			= (const char *) NULL;

	/*
	 * Create a timer object which will update the master
	 * load-balancing server with load statistics.
	 */
	m_timer = new AWSLoadBalancingTimer( this );

	g_loadBalancingServer = this;

#ifdef DEBUG
	srand( (unsigned)time( NULL ) );

	m_timer->setUpdateInterval( 5 );
#endif
}

/**
 * Destructor.
 */
AWSLoadBalancing::~AWSLoadBalancing( )
{
	/*
	 * Kill the timer.
	 */
	m_timer->stop( );
	delete m_timer;


	/*
	 * Remove this server from the master load-balancing
	 * server's list of available servers.
	 */
	unregisterAgent( );

	/*
	 * Clean-up the Name Service if this is the master server.
	 */
	if (m_master->_is_local())
	{
		AWSNames	names( m_orb );

		try 
		{
			names.unregisterObject( m_lbName );
		}
		catch(...) { }

		try 
		{
			names.unregisterObject( m_name );
		}
		catch(...) { }
	}

}


/**
 * Initializes the load-balancing object.  The LB name created
 * in the constructor is used to find other instances of the
 * load-balancing object which may exist in other servers.
 * If no other instances are found, this instance become the
 * master server.
 *
 * @param orb	A reference to the orb.
 * @param boa	A reference to the boa.
 *
 * @raises LoadBalancingException MASTER_REGISTER_FAILED
 * @raises LoadBalancingException PROXY_REGISTER_FAILED
 */
void AWSLoadBalancing::initialize(CORBA::ORB_ptr orb, CORBA::BOA_ptr boa)
{
	m_orb = CORBA::ORB::_duplicate(orb);
	m_boa = CORBA::BOA::_duplicate(boa);

	g_orb = CORBA::ORB::_duplicate(orb);


	/*
	 * Initialize the reference to the master server.
	 * The LB name created in the constructor is used to find 
	 * other instances of the load-balancing object which may exist 
	 * in other servers. If no other instances are found, this 
	 * instance bind itself in the Naming Service as the master server.
	 *
	 * Because the getObject and reregisterObject methods can not be
	 * executed as an atomic operation, this retry logic had to be used.
	 * If the object name is not currently bound in the Naming Service
	 * or if the object it is bound to no longer exists, then this
	 * instance will bind itself to the object.  It will then go back
	 * and retrieve the object bound to the name in the naming service
	 * just in case some other process has overwritten the name in
	 * the mean time.  A short delay is inserted in order to try to
	 * further mitigate this timing problem.
	 *
	 * The mutex is required since another process could be starting
	 * up at the same time and register itself with this process
	 * before this process can add itself to the server list.
	 */
	{
		VISMutex_var lock(m_loadBalancingMtx);

		CORBA::Object_var	objVar;
		AWSNames			names( m_orb );

		m_master = NULL;

		while (m_master == NULL)
		{
			try
			{
				objVar = names.getObject( m_lbName );

				/*
				 * If the object exists, narrow the reference 
				 * to make sure it is of the proper type.
				 */
				if ( ! objVar->_non_existent() )
					m_master = IAgent::_narrow(objVar);

			}
			catch(...) 
			{ 
				m_master = NULL;
			}

			/*
			 * If the master could not be located, register this object
			 * in the Naming Service as the master server.
			 */
			if (m_master == NULL)
			{
				try
				{
					names.reregisterObject( m_lbName, (CORBA::Object_ptr)this );

					/*
					 * Wait for a little while before going back and checking
					 * for the master server in order to try to avoid a timing
					 * problem which occurs when two processes are 
					 * initializing at the same time.
					 */
					VISPortable::vsleep( 2 );
				}
				catch(...) 
				{ 
					throw LoadBalancingException( MASTER_REGISTER_FAILED );
				}
			}
		}


		/*
		 * If this is the master server, then create and bind the
		 * proxy object and install an interceptor factory.
		 */
		bindMaster( m_master->_is_local() );


		/*
		 * Register this server with the master server. If this process
		 * is the master server, add the server directly to the server
		 * list since registerAgent will acquire the mutex (i.e. this
		 * method will have to release the mutex) and there is a chance
		 * of another register request being processed before this
		 * server is added.
		 */
		if (m_master->_is_local())
			m_serverList.appendServer( this );

		else
			registerAgent( );
	}

	/*
	 * Start the timer updates
	 */
	m_timer->start( );

#ifdef DEBUG
	cout << "I am " << (m_master->_is_local()?"the master.":"a slave.") << endl;
#endif
}

/**
 * If this is the master load-balancing server, then bind the
 * name in the Naming Service, create and bind the proxy object
 * and install the interceptor.  Otherwise, destroy the
 * proxy and interceptor if they exist.
 *
 * @param isMaster	Boolean flag which indicates whether or not
 *					this process is to be the master server.
 */
void AWSLoadBalancing::bindMaster(int isMaster)
{
	if ( isMaster )
	{
		AWSNames	names( m_orb );

		/*
		 * Always bind the load-balancing name to this object.
		 */
		try
		{
			names.reregisterObject( m_lbName, (CORBA::Object_ptr)this );
		}
		catch(...) 
		{ 
			throw LoadBalancingException( MASTER_REGISTER_FAILED );
		}

		/*
		 * Create a proxy object and bind a name to it if it does
		 * not already exist.
		 *
		 * Note:This object does not need to be readied in the boa
		 * since no client will '_bind' to it.
		 */
		if (g_proxyObject == NULL)
		{
			CORBA::BOA::RegistrationScope	regScope = m_boa->scope();

			m_boa->scope(CORBA::BOA::SCOPE_GLOBAL);

			g_proxyObject = new LoadBalancingProxy( );

			try
			{
				names.reregisterObject( m_name, (CORBA::Object_ptr)g_proxyObject );
			}
			catch(...) 
			{ 
				throw LoadBalancingException( PROXY_REGISTER_FAILED );
			}

			m_boa->scope(regScope);
		}

		/*
		 * Create and register the interceptor factory if it does
		 * not already exist.
		 */
		if (g_interceptorFactory == NULL)
		{
			g_interceptorFactory = new LoadBalancingIntFactory( );

			VISChainServerIntercepFactory::add( g_interceptorFactory );
		}
	}
	else
	{
		/*
		 * Uninstall the interceptor factory and destroy the
		 * proxy object if they exist.  Note that since the
		 * proxy is stored as a _var, just setting it to
		 * null is all that needs to be done to release it.
		 */
		if ( g_interceptorFactory != NULL )
			VISChainServerIntercepFactory::remove( g_interceptorFactory );

		g_interceptorFactory	= NULL;
		g_proxyObject			= NULL;
	}

}

/**
 * Adds the given object to the list of local objects, and
 * registers it with the master load-balancing server.
 *
 * @param objPtr	The object to be registered.
 */
void AWSLoadBalancing::registerObject(CORBA::Object_ptr objPtr)
{
	/*
	 * If the repository id has not been defined yet,
	 * use this object to initialize it
	 */
	if (m_repositoryId == (const char *) NULL)
		m_repositoryId = CORBA::string_dup( objPtr->_repository_id( ) );


	/*
	 * Make sure that only one repository type is added
	 * to this load-balancing server and to the master server.
	 */
	if ( objPtr->_is_a( m_repositoryId ) )
	{
		/*
		 * Add object to the local list of managed objects
		 */
		m_objectList.addObject( objPtr );

		/*
		 * Register the object with the master server.
		 */
		m_master->registerObject( objPtr, this );
	}
}

/**
 * Defined in the idl.
 */
void AWSLoadBalancing::registerObject(
							CORBA::Object_ptr			objPtr,
							LoadBalancing::IAgent_ptr	agent)
{
	VISMutex_var lock(m_loadBalancingMtx);

	/*
	 * If the repository id has not been defined yet,
	 * use this object to initialize it
	 */
	if (m_repositoryId == (const char *) NULL)
		m_repositoryId = CORBA::string_dup( objPtr->_repository_id( ) );

	/*
	 * Make sure that only one repository type is added
	 * to a load-balancing server.
	 */
	if ( objPtr->_is_a( m_repositoryId ) )
		m_serverList.addObject( objPtr, agent );

	else
		throw LoadBalancingException( MIXED_INTERFACE_TYPES );

}

/**
 * Removes the given object from the list of local objects, 
 * and unregisters it with the master load-balancing server.
 *
 * @param objPtr	The object to be unregistered.
 */
void AWSLoadBalancing::unregisterObject(CORBA::Object_ptr objPtr)
{
	/*
	 * Remove object from the local list of managed objects
	 */
	m_objectList.removeObject( objPtr );

	/*
	 * Unregister the object with the master server.
	 */
	m_master->unregisterObject( objPtr, this );
}

/**
 * Defined in the idl.
 */
void AWSLoadBalancing::unregisterObject(
								CORBA::Object_ptr			objPtr,
								LoadBalancing::IAgent_ptr	server)
{
	/*
	 * Remove the object from the specified server.
	 */
	try
	{
		VISMutex_var lock(m_loadBalancingMtx);

		m_serverList.removeObject( objPtr, server );
	}
	catch(ServerList::ServerNotFound)
	{
		throw LoadBalancingException( SERVER_NOT_FOUND );
	}
}

/**
 * Removes 'this' server object from the master load-balancing
 * server.
 */
void AWSLoadBalancing::unregisterAgent( )
{
	m_master->unregisterAgent( this );
}

/**
 * Defined in the idl.
 */
void AWSLoadBalancing::unregisterAgent(LoadBalancing::IAgent_ptr server)
{
	/*
	 * Remove the given server from the server list.  This
	 * in turn will remove all of its registered objects.
	 * If the server is not found, ignore it.
	 */
	try
	{
		VISMutex_var lock(m_loadBalancingMtx);

		m_serverList.removeServer( server );
	}
	catch(ServerList::ServerNotFound)
	{
		// Ignore this error
	}

	/*
	 * Distribute a new list of servers.
	 */
	distributeServerList( );
}

/**
 * Registers this server process with the master server.
 */
void AWSLoadBalancing::registerAgent( )
{
	m_master->registerAgent( this );
}

/**
 * Defined in the idl.
 */
void AWSLoadBalancing::registerAgent(LoadBalancing::IAgent_ptr server)
{
	try
	{
		VISMutex_var lock(m_loadBalancingMtx);

		m_serverList.appendServer( server );
	}
	catch(...)
	{
		// Ignore this error
	}

	// Redistribute list of servers
	distributeServerList( );
}

/**
 * Creates a list of the server processes, and sends this
 * list to each of those servers.
 */
void AWSLoadBalancing::distributeServerList( )
{
	LoadBalancing::LBAgentList_var		serverList;
	ServerListIterator						*srvIter;
	Server									*srvObj;
	CORBA::ULong							srvCount;


	/*
	 * This only happens when the last server is shutdown.
	 * The server unregisters itself and because of the change
	 * to the list of servers, it distributes the updated
	 * list (which is empty).
	 */
	if (m_serverList.getCount() == 0) return;


	/*
	 * Build a  list of the servers
	 */
	serverList = new LoadBalancing::LBAgentList(5);

	serverList->length(0);	

	{
		VISMutex_var lock(m_loadBalancingMtx);

		srvCount	= 0;
		srvIter		= m_serverList.elements();

		while ( srvIter->hasMoreElements( ) )
		{
			srvObj = srvIter->nextElement( );

			serverList->length(srvCount+1);
			
			serverList[ srvCount ] = srvObj->getServerObject( );

			srvCount ++;
		}

		delete srvIter;
	}


	/*
	 * Usually this is an error condition but not always since 
	 * when the master server is stopped, it removes itself from 
	 * the server list and then, since it is/was the master, will 
	 * try to redistribute the new server list (from which it just 
	 * removed itself).
	 */
	if (!(*serverList)[0]->_is_local( )) return;


	/*
	 * Send the list of servers to all servers.  Use the constructed
	 * list of server rather than the server iterator just in case
	 * the server list is modified by the setAgentList method.
	 *
	 * Do not really need to distribute this list to the
	 * master server (i.e. the first server in the list).
	 */
	for(CORBA::ULong idx = 0; idx < serverList->length(); idx ++)
	{
		(*serverList)[idx]->setAgentList( *serverList );
	}
}


/**
 * Saves the list of registered servers which is distributed by
 * the master server whenever there is a change to the list.
 *
 * @param serverList	The new list of server processes.
 */
void AWSLoadBalancing::setAgentList(const LoadBalancing::LBAgentList& agentList)
{
	/*
	 * The first element in the list is always the master.
	 */
	m_master = LoadBalancing::IAgent::_duplicate(agentList[0]);


	/*
	 * Save the new list of server processes.  The old list is
	 * destroyed along with the registered objects (in the
	 * case of the master server) but that's ok since all servers
	 * will reregister their objects later.
	 * 
	 * Note that the agentList is guaranteed to have at least 
	 * one element (this process).
	 */
	{
		VISMutex_var lock(m_loadBalancingMtx);

		m_serverList.clear( );

		for(CORBA::ULong idx = 0; idx < agentList.length( ); idx ++)
		{
			m_serverList.appendServer( agentList[idx] );
		}
	}

	/*
	 * Always check the Name Service binds, proxy object,
	 * and interceptor.
	 */
	bindMaster( m_master->_is_local() );


	/*
	 * Always re-register the local objects with the master
	 * server.
	 */
	CORBA::Object_var	objVar;

	for(int i = 0; i < m_objectList.getObjectCount( ); i ++)
	{
		objVar = m_objectList.getObject( i );

		m_master->registerObject( objVar, this );
	}


	updateLoadFactor( );
}

/**
 * Picks an object from the set of Load Balanced objects.
 * This method is called by the locate interceptor, and
 * first obtains the load balancing mutex before invoking
 * the (virtual) method of select a particular object.  
 * If an object is successfully selected, it is tested
 * to ensure that the object still exists.
 *
 * @returns An object, or NULL if none could be selected.
 */
CORBA::Object_ptr AWSLoadBalancing::pickObject( )
{
	VISMutex_var		lock(m_loadBalancingMtx);

	CORBA::Object_var	objVar = NULL;

	/*
	 * Continue until an available object is found.  
	 */
	while (objVar == NULL)
	{
		/*
		 * Call the (virtual) method to select the
		 * next object.  Throws no exceptions
		 * but returns a null on any error.
		 */
		objVar = selectObject( );

		if (objVar == NULL) return NULL;

		/*
		 * If the object does not exist, 
		 * remove it and select again.
		 */
		if (objVar->_non_existent())
		{
			m_serverList.removeObject( objVar );

			objVar = NULL;
		}
	}

	return CORBA::Object::_duplicate( objVar );
}

/**
 * Defined in the idl.
 *
 * Do not lock the mutex m_loadBalancingMtx since this should 
 * already done by pickObject.
 */
CORBA::Object_ptr AWSLoadBalancing::selectObject()
{
	ServerListIterator		*srvIter;
	Server					*srvObj;
	Server					*minSrvObj;
	CORBA::Object_var		objVar;

	objVar = NULL;

	/*
	 * Find the server object with the smallest load
	 */
	minSrvObj	= NULL;
	srvIter		= m_serverList.elements();

	while ( srvIter->hasMoreElements( ) )
	{
		srvObj = srvIter->nextElement( );

		/*
		 * If the server has not updated load information
		 * within the specified time interval, then do not
		 * consider it.
		 */
		if (srvObj->getTimeSinceLastUpdate( ) < 2*m_timer->getUpdateInterval( ))
		{
			/*
			 * If no initial server is set or the load factor on
			 * this server is smaller than the minimum, save this
			 * server as the new minimum.
			 */
			if	(	(minSrvObj == NULL)
				||	(srvObj->getLoadFactor( ) < minSrvObj->getLoadFactor( )) 
				)
				minSrvObj = srvObj;
		}
	}

	delete srvIter;

	/*
	 * Get the next object from the chosen server
	 */
	if (minSrvObj != NULL)
		objVar = minSrvObj->selectObject( );


	return (objVar != NULL ? CORBA::Object::_duplicate( objVar ) : NULL);
}

/**
 * Defined in the idl.
 */
CORBA::Double AWSLoadBalancing::computeLoad( )
{
	CORBA::Double	load = 1.0;

#ifdef DEBUG
	load = (CORBA::Double) rand( );
#endif

#ifdef HPUX
	struct pst_dynamic	dyn;

	pstat_getdynamic( &dyn, sizeof(dyn), 1, 0 );

	load = dyn.psd_avg_1_min;
#endif

	return load;
}

/**
 * Obtains the current server loading factor and updates
 * this information in the master load-balancing server.
 * If the master server is not available, the master server
 * variable is re-initialized.
 */
void AWSLoadBalancing::updateLoadFactor( )
{
	/*
	 * Get the current load factor and send this information
	 * to the master server.
	 */
	CORBA::Double	load = computeLoad( );

	try
	{
		m_master->updateLoadFactor( load, this );
	}
	catch(LoadBalancingException &lbEx)
	{
		cerr << "Exception returned in updateLoadFactor." << endl;
	}
	catch(...)
	{
	}
}

/**
 * Checks the reference to the master agent to make sure
 * that the object still exists.  If it does not, it will
 * attempt to contact the new master agent or become
 * the master agent itself.  If this agent is the master
 * agent, then it will check for the existence of all of
 * the slave agents.
 */
void AWSLoadBalancing::pingMaster( )
{
	int		resendList;

	resendList = 0;

	/*
	 * Check the processes in the server list one by one until
	 * an existing one is found.  
	 */
	{
		VISMutex_var lock(m_loadBalancingMtx);

		/*
		 * If this is the master, ping all the other servers
		 * not just the master.
		 */
		if (m_master->_is_local())
		{
			LoadBalancing::IAgent_var	srvObjVar;
			int								idx;

			idx = 0;
			while ( idx < m_serverList.getCount() )
			{
				srvObjVar = m_serverList.getServerObject(idx)->getServerObject( );

				if (srvObjVar->_non_existent( ))
				{
					m_serverList.removeServer( srvObjVar );

					resendList = 1;
				}
				else
					idx ++;
			}

		}
		else
		{
			LoadBalancing::IAgent_var	master;

			master = m_master;

			// Really should be able to work from the serverList entirely
			// and not worry about m_master.
			while (master != NULL && master->_non_existent( ))
			{
				m_serverList.removeServer( master );
					
				master = NULL;
				if (m_serverList.getCount() > 0)
					master = m_serverList.getServerObject(0)->getServerObject( );
			}


			/*
			 * ERROR CONDITION.  Should never happen since at a minimum,
			 * this process should be in the server list.
			 */
			if ( master == NULL )
			{
				cerr << "No master servers available." << endl;
				return;
			}
		
			/*
			 * If the master server has changed and this process
			 * is now the new master server, then distribute the 
			 * server list to the other server processes.
			 */
			resendList = (master->_is_local() && master != m_master);
		}
	}


	if ( resendList )
	{
#ifdef DEBUG
	cout << "Master failed.  I am the new master." << endl;
#endif

		distributeServerList( );
	}
}

/**
 * Defined in the idl.
 */
void AWSLoadBalancing::updateLoadFactor(
							CORBA::Double				load,
							LoadBalancing::IAgent_ptr	server)
{
	VISMutex_var lock(m_loadBalancingMtx);

	/*
	 * Catch and ignore all errors.
	 */
	try
	{
		m_serverList.saveLoadFactor( load, server );
	}
	catch(ServerList::ServerNotFound)
	{
		// throw LoadBalancingException( SERVER_NOT_FOUND );
	}
	catch(...)
	{
	}
}

/**
 * Constructs a Server object which represents the given
 * load-balancing server object.
 *
 * @param srvObjPtr		A reference to the object which will
 *						be represented by this server instance.
 */
Server::Server(LoadBalancing::IAgent_ptr srvObjPtr) 
{
	m_serverObject	= LoadBalancing::IAgent::_duplicate( srvObjPtr );

	/*
	 * Get the host address from the IOR profile body.
	 */
	IOP::IOR			serverIOR;
	IIOP::ProfileBody	body;

	serverIOR = *VISUtil::to_ior( srvObjPtr );
	VISUtil::convert( serverIOR, body );

	m_hostAddr		= CORBA::string_dup( body.host );

	/*
	 * Initialize other member fields.
	 */
	m_loadFactor	= 0.0;
	m_lastUpdate	= 0l;

	m_nextObject	= 0;
}

/**
 * Destructor.
 */
Server::~Server( )
{
}


/**
 * Defined in the idl.
 */
void Server::setLoadFactor(CORBA::Double load)
{
	/*
	 * Save the load factor and update the timestamp.
	 */
	struct timeval	tv;

	VISPortable::vgettimeofday( &tv );

	m_lastUpdate	= tv.tv_sec;
	m_loadFactor	= load;
}

/**
 * Defined in the idl.
 */
CORBA::Double Server::getLoadFactor()
{
	return m_loadFactor;
}

/**
 * Defined in the idl.
 */
CORBA::ULong Server::getTimeSinceLastUpdate()
{
	struct timeval	tv;

	VISPortable::vgettimeofday( &tv );

	return (tv.tv_sec - m_lastUpdate);
}

/**
 * Defined in the idl.
 */
CORBA::Object_ptr Server::selectObject()
{
	CORBA::Object_var	objVar;

	/*
	 * Implements a round-robin selection algorithm.
	 */
	if (m_nextObject >= m_objectList.getObjectCount())
		m_nextObject = 0;

	/*
	 * Get the next object as identified by the index.
	 */
	objVar = m_objectList.getObject( m_nextObject );

	m_nextObject ++;

	if (objVar == NULL)
		throw ServerException( );

	return CORBA::Object::_duplicate( objVar );
}

/**
 * Returns the number of object contained in the
 * object array.
 *
 * @returns The number of objects.
 */
int Server::getObjectCount( ) 
{ 
	return m_objectList.getObjectCount(); 
}

/**
 * Returns a reference to the server object at the
 * given index position.
 *
 * @param ndx	Index position of the object to be returned.
 *
 * @returns An object reference.
 */
CORBA::Object_ptr Server::getObject(int ndx)
{
	CORBA::Object_var	objVar = NULL;

	objVar = m_objectList.getObject( ndx );

	return (objVar != NULL ? CORBA::Object::_duplicate( objVar ) : NULL);
}

/**
 * Returns a reference to the server object stored in
 * this Server instance.
 *
 * @returns	A reference to the stored server object.
 */
LoadBalancing::IAgent_ptr Server::getServerObject( )
{
	return LoadBalancing::IAgent::_duplicate( m_serverObject );
}

/**
 * Returns the address of the host which is represented
 * by this Server object.
 *
 * @returns The string representation of the host's ip address.
 */
const char *Server::getHostAddress( )
{
	return CORBA::string_dup( m_hostAddr );
}

/**
 * Compares the peer of the given server object with that of
 * the server object represented by this instance to determine
 * if they represent the same object.
 *
 * @returns true if the peers are the same, false otherwise.
 */
CORBA::Boolean Server::isEqual(LoadBalancing::IAgent_ptr otherServerObject)
{
	IOP::IOR	i1, i2;

	i1 = *VISUtil::to_ior(otherServerObject);
	i2 = *VISUtil::to_ior(m_serverObject);

	return (VISUtil::is_same_addr( i1, i2 ));
}

/**
 * Adds the given object to the list of objects associated
 * with this server instance.
 *
 * @param objPtr	Object to be added.
 */
void Server::addObject(CORBA::Object_ptr objPtr)
{
	m_objectList.addObject( objPtr );
}

/**
 * Removes the given object from the list of objects
 * associated with this server instance.
 *
 * @param objPtr	Object to be removed.
 */
void Server::removeObject(CORBA::Object_ptr objPtr)
{
	m_objectList.removeObject( objPtr );
}


ServerListIterator::ServerListIterator(ServerList *serverList)
{
	m_serverList	= serverList;
	m_nextElement	= 0;
}

ServerListIterator::~ServerListIterator( )
{
}

int ServerListIterator::hasMoreElements( )
{
	return (m_nextElement < m_serverList->getCount() ? 1 : 0);
}


Server*  ServerListIterator::nextElement( )
{
	Server		*srvObj;

	/*
	 * If there is a next server, get a reference to it
	 * and advance to the next element.
	 */
	if (m_nextElement < m_serverList->getCount())
	{
		srvObj = m_serverList->getServerObject( m_nextElement );

		m_nextElement ++;
	}
	else
		throw NoMoreElements( );

	return srvObj;
}


/**
 * Constructs a new instance of a server list object.  The
 * list will be initialized to the given length and be extended
 * (when necessary) by the given increment.
 *
 * @param listLength	The initial size of the list.
 * @param listIncrement	Number of elemenets added to the list
 *						when it needs to be extended.
 */
ServerList::ServerList(int listLength, int listIncrement)
{
	m_listCount		= 0;
	m_listLength	= (listLength > 0 ? listLength : 1);
	m_listIncrement	= (listIncrement > 0 ? listIncrement : 1);

	m_serverList = new Server *[ m_listLength ];
}

/**
 * Destructor.  Destroys all server objects in the list 
 * and deletes the server object array.
 */
ServerList::~ServerList( )
{
	for(int i = 0; i < m_listCount; i ++)
		delete m_serverList[ i ];

	delete [] m_serverList;
}

/**
 * Resets all entries in the server list.
 */
void ServerList::clear( )
{
	for(int i = 0; i < m_listCount; i ++)
	{
		delete m_serverList[ i ];

		m_serverList[ i ] = NULL;
	}

	m_listCount		= 0;
}

/**
 * Updates the load factor for the given load balancing server.
 *
 * @param load		The load factor to be saved.
 * @param lbObjPtr	The server object to which the load is associated.
 */
void ServerList::saveLoadFactor(CORBA::Double				load, 
								LoadBalancing::IAgent_ptr	lbObjPtr)
{
	int		idx = findServerIndex(lbObjPtr);

	// If the object was found...
	if (idx > -1)
		m_serverList[ idx ]->setLoadFactor( load );

	else
		throw ServerNotFound( );
}

/**
 * Removes the given server object from the list.
 *
 * @param lbObjPtr	The object to be removed.
 */
void ServerList::removeServer(LoadBalancing::IAgent_ptr lbObjPtr)
{
	int		idx = findServerIndex(lbObjPtr);

	// If the object was found...
	if (idx > -1)
	{
		// Delete the server object
		delete m_serverList[ idx ];

		// Adjust the other objects in the list
		for(int i = idx; i < m_listCount-1; i ++)
			m_serverList[ i ] = m_serverList[ i + 1 ];

		m_serverList[ m_listCount-1 ] = NULL;

		// One less item in the list
		m_listCount --;
	}
}

/**
 * Adds the given agent to the end of the server list.
 * If the list is full, it will be resized to handle
 * the new element.  No check for duplicates is made.
 *
 * @param lbObjPtr	A reference to the agent to be added.
 */
void ServerList::appendServer(LoadBalancing::IAgent_ptr lbObjPtr)
{
	int		idx = findServerIndex(lbObjPtr);

	// If the lb server was not found...
	if (idx < 0)
	{
		// If list is full, extend the list
		if (m_listCount == m_listLength)
		{
			Server	**tmpServerList;

			m_listLength += m_listIncrement;

			tmpServerList = new Server *[ m_listLength ];

			for(int i = 0; i < m_listCount; i ++)
				tmpServerList[ i ] = m_serverList[ i ];

			delete [] m_serverList;

			m_serverList = tmpServerList;
		}

		m_serverList[ m_listCount ] = new Server( lbObjPtr );

		m_listCount ++;
	}
}

/**
 * Removes the given object from the object list of the
 * given server.  The server object is located in the list
 * and, if found, the object is removed from the server.
 * If the object was the last one in that server's list,
 * the server is removed from the server list.
 *
 * @param objPtr	Object to be removed from the server's
 *					object list.
 * @param lbObjPtr	Server object from which the object
 *					is to be removed.
 */
void ServerList::removeObject(	CORBA::Object_ptr				objPtr, 
								LoadBalancing::IAgent_ptr	lbObjPtr)
{
	int		idx = findServerIndex(lbObjPtr);

	// If the object was found...
	if (idx > -1)
		m_serverList[ idx ]->removeObject( objPtr );
}

/**
 * Removes an object from the load-balancing server object
 * with which it is associated.  The object is removed from
 * each of the server objects.  Any server objects which
 * are empty after the removal are themselves removed.
 *
 * @param objPtr	Object to be removed.
 */
void ServerList::removeObject(CORBA::Object_ptr objPtr)
{
	int		idx;

	idx = 0;
	while ( idx < m_listCount )
	{
		m_serverList[ idx ]->removeObject( objPtr );

		idx ++;
	}
}


/**
 * Adds the given object to the object list of the
 * given server.  The server object is located in the list
 * and, if found, the object is added to the server.
 * If the server is not found, a Server object is created
 * for the server and added to the server list, and then
 * the object is added to the server.
 *
 * @param objPtr	Object to be added to the server's
 *					object list.
 * @param lbObjPtr	Server object to which the object
 *					is to be added.
 */
void ServerList::addObject(CORBA::Object_ptr				objPtr, 
						   LoadBalancing::IAgent_ptr	lbObjPtr)
{
	int		idx = findServerIndex(lbObjPtr);

	// If the server was found...
	if (idx > -1)
		m_serverList[ idx ]->addObject( objPtr );
}

/**
 * Gets a reference to the server object which occupies the
 * given position of the server list array.
 *
 * @param idx	Array index position.
 *
 * @returns A reference to the server object in the given positon,
 *			null if the index is invalid.
 */
Server* ServerList::getServerObject(int idx)
{
	Server*		srvObj;

	srvObj = NULL;
	if (idx < m_listCount)
		srvObj = m_serverList[ idx ];

	return srvObj;
}

/**
 * Returns the number of items current stored in the
 * server list.
 *
 * @returns Number of elements in the list.
 */
int ServerList::getCount( ) 
{ 
	return m_listCount; 
};

/**
 * Creates and returns an iterator object which can be 
 * used to list the servers contained in the server list.
 *
 * @returns An iterator object.
 */
ServerListIterator* ServerList::elements( )
{
	return new ServerListIterator( this );
}

/**
 * Utility function which finds a given server object in
 * the server list and returns its index. If the server
 * is not found, a -1 is returned.
 *
 * @param lbObjPtr	Server object to be located.
 *
 * @returns The index of the server object in the list
 *			if found, -1 otherwise.
 */
int ServerList::findServerIndex(LoadBalancing::IAgent_ptr lbObjPtr)
{
	int		idx;

	idx = m_listCount - 1;

	while (idx > -1 && ! m_serverList[ idx ]->isEqual(lbObjPtr))
		idx --;

	return idx;
}


/**
 * Constructs a new instance of an object list.  The
 * list will be initialized to the given length and be 
 * extended (when necessary) by the given increment.
 *
 * @param listLength	The initial size of the list.
 * @param listIncrement	Number of elemenets added to the list
 *						when it needs to be extended.
 */
ObjectList::ObjectList(int listLength, int listIncrement)
{
	m_listCount		= 0;
	m_listLength	= (listLength > 0 ? listLength : 1);
	m_listIncrement	= (listIncrement > 0 ? listIncrement : 1);

	m_objectList = new CORBA::Object_var [ m_listLength ];
}

/**
 * Destructor.  Destroys the object list array.  The objects
 * references are stored as Object_vars so the objects do
 * not need to be _released first.
 */
ObjectList::~ObjectList( )
{
	for(int i = 0; i < m_listCount; i ++)
		m_objectList[ i ] = NULL;

	delete [] m_objectList;
}

/**
 * Adds the given object to the end of the object list.
 * If the object array is full, it will be extended.
 * Duplicates object references will not be added.
 *
 * @param objPtr	Object to be added to the list.
 */
void ObjectList::addObject(CORBA::Object_ptr objPtr)
{
	int		idx;

	idx = findObjectIndex( objPtr );

	/*
	 * If the object was not found...
	 */
	if (idx < 0)
	{
		/*
		 * If list is full...
		 */
		if (m_listCount == m_listLength)
		{
			CORBA::Object_var	*tmpObjectList;

			m_listLength += m_listIncrement;

			/*
			 * Create a temporary object array.
			 */
			tmpObjectList = new CORBA::Object_var[ m_listLength ];

			/*
			 * Copy all of the existing object references
			 * to the temporary array
			 */
			for(int i = 0; i < m_listCount; i ++)
				tmpObjectList[ i ] = m_objectList[ i ];

			/*
			 * Get rid of the old array and save the new one.
			 */
			delete [] m_objectList;

			m_objectList = tmpObjectList;
		}

		/*
		 * Append the new object to the end of the array.
		 */
		m_objectList[ m_listCount ] = CORBA::Object::_duplicate( objPtr );
		m_listCount ++;
	}
}

/**
 * Removes the given object from the object array.
 *
 * @param objPtr	The object to be removed.
 */
void ObjectList::removeObject(CORBA::Object_ptr objPtr)
{
	int		idx;

	idx = findObjectIndex( objPtr );

	/*
	 * If the object was found...
	 */
	if (idx > -1)
	{
		/*
		 * Fill-in the gap left by the object which was
		 * removed.
		 */
		for(int i = idx; i < m_listCount-1; i ++)
			m_objectList[ i ] = m_objectList[ i + 1 ];

		/*
		 * Clear the last element in the array since it
		 * was moved to the m_listCount-2 position.
		 */
		m_objectList[ m_listCount-1 ] = NULL;

		m_listCount --;
	}
}

/**
 * Returns a reference to the object which occupies the
 * specified position in the object array.
 *
 * @param idx	An array index position
 *
 * @returns The object in the specified array position.
 */
CORBA::Object_ptr ObjectList::getObject(int idx)
{
	CORBA::Object_ptr		obj;

	obj = NULL;
	if (idx < m_listCount)
		obj = CORBA::Object::_duplicate( m_objectList[ idx ] );

	return obj;
}

/**
 * Returns the number of objects in the object list.
 *
 * @returns Number of objects.
 */
int ObjectList::getObjectCount( ) 
{ 
	return m_listCount; 
};

/**
 * Returns the index position of the given object.
 *
 * @param objPtr	The object to be located.
 *
 * @returns The array position of the object.  -1 if the
 *			object was not found.
 */
int ObjectList::findObjectIndex(CORBA::Object_ptr objPtr)
{
	int			idx;

	CORBA::String_var	obj1Ref(g_orb->object_to_string(objPtr));

	idx = m_listCount - 1;

	while (idx > -1)
	{
		CORBA::String_var	obj2Ref(g_orb->object_to_string(m_objectList[ idx ]));

		if ( strcmp( obj1Ref, obj2Ref ) == 0 )
			break;

		idx --;
	}

	return idx;
}


/**
 * Constructor for the AWSLoadBalancingTimer.  The constructor
 * accepts an optional parameter which defines the number
 * of seconds to delay between executions of the update method.
 * The default update interval is 60 seconds.
 *
 * @param lbInterface		Reference to the load-balancing object 
 *							being serviced by this timer.
 * @param pingInterval		Number of seconds between pings of the
 *							master server (default 5).
 * @param updateInterval	Number of seconds between load factor
 *							updates (default 60).
 */
AWSLoadBalancingTimer::AWSLoadBalancingTimer(
					AWSLoadBalancing	*lbObject,
					CORBA::ULong		pingInterval,
					CORBA::ULong		updateInterval)
{
	m_lbObject			= lbObject;

	m_updateInterval	= updateInterval;
	m_pingInterval		= pingInterval;
	

	struct timeval	tv;

	VISPortable::vgettimeofday( &tv );

	m_lastUpdate		= tv.tv_sec;
	m_lastPing			= tv.tv_sec;

	m_delay				= (m_updateInterval < m_pingInterval 
								? m_updateInterval : m_pingInterval);


	m_continue			= 1;
}

/**
 * Destructor.
 */
AWSLoadBalancingTimer::~AWSLoadBalancingTimer( ) 
{ 
}

/**
 * Starts the execution of the thread process.  It invokes
 * the 'run' method of the VISThread class which creates
 * a thread and invokes the 'begin' method.
 */
void AWSLoadBalancingTimer::start( )
{
	m_continue = 1;

	run(); 
}

/**
 * Resets the continuation flag which is used as the
 * return value of the startTimer method.  This flag
 * is used to control the main loop of the thread.
 * Returning a false will cause the main event loop to
 * exit.  Note that calling stop will not terminate
 * the loop immediately.
 *
 * @see startTimer.
 */
void AWSLoadBalancingTimer::stop( )
{
	m_continue = 0;
}

/**
 * Called by the VISThread class when its 'run' method
 * is invoked.  This method is the main event loop for
 * this timer class.  It sleeps for an interval of time
 * and then performs a load update and/or check to make
 * that the master server is still alive. This method will  
 * return only when requested by the continuation flag.
 *
 * @see update
 */
void AWSLoadBalancingTimer::begin() 
{
	while ( m_continue )
	{
		/*
		 * Suspend for the specified period of time.
		 */
		VISPortable::vsleep(m_delay);


		struct timeval	tv;

		VISPortable::vgettimeofday( &tv );


		/*
		 * Check to see if it is time to update the load factor.
		 */
		long	updateDelay;

		updateDelay = m_updateInterval - (tv.tv_sec - m_lastUpdate);

		if (updateDelay <= 0)
		{
			/*
			 * Perform an update.
			 */
			try
			{
				m_lbObject->updateLoadFactor( );
			}
			catch(...)
			{
				cerr << "Exception thrown by updateLoadFactor." << endl;

				// throw UpdateError( );
			}

			m_lastUpdate = tv.tv_sec;

			updateDelay = m_updateInterval;
		}


		/*
		 * Check to see if it is time to ping the master server.
		 */
		long	pingDelay;

		pingDelay = m_pingInterval - (tv.tv_sec - m_lastPing);

		if (pingDelay <= 0)
		{
			try
			{
				m_lbObject->pingMaster( );
			}
			catch(...)
			{
				cerr << "Exception thrown by pingMaster." << endl;
			}

			m_lastPing = tv.tv_sec;

			pingDelay = m_pingInterval;
		}


		/*
		 * Compute the delay until the next event.
		 */
		m_delay	= (updateDelay < pingDelay ? updateDelay : pingDelay);

	}
}    

/**
 * Returns the number of seconds between calls to the update
 * method.
 *
 * @returns Number of seconds between updates.
 */
int AWSLoadBalancingTimer::getUpdateInterval( )
{
	return m_updateInterval;
}


/**
 * Sets the number of seconds between calls to the update
 * method.
 *
 * @param interval Number of seconds between updates.
 */
void AWSLoadBalancingTimer::setUpdateInterval(int interval)
{
	if (interval > 0)
		m_updateInterval = interval;
}

/**
 * Initialize the static instance of the interceptor factory.
 */
LoadBalancingIntFactory	LoadBalancingIntFactory::m_interceptorFactory;


/**
 * Default constructor.  Initialize the interceptor reference.
 */
LoadBalancingIntFactory::LoadBalancingIntFactory( )
{
	m_interceptor = (LoadBalancingInterceptor *) NULL;
}

/**
 * Destructor.  Do not destroy the interceptor as it is
 * a _var and will be automatically released.
 */
LoadBalancingIntFactory::~LoadBalancingIntFactory( )
{
}

/**
 * Invoked by the orb to obtain an interceptor when 
 * a client request is received.  Only a single
 * interceptor is used by Load Balancing.  So, if that
 * instance has not been created, then create it.  
 * Otherwise, just return a duplicate of the previously 
 * created interceptor.
 *
 * @param fd	File descriptor
 * @param p		Tagged profile
 *
 * @returns A reference to an interceptor
 */
VISServerInterceptor *LoadBalancingIntFactory::create(int fd, const IOP::TaggedProfile& p)
{
	/*
	 * Create the interceptor if it does not already exist.
	 */
	if (m_interceptor == (LoadBalancingInterceptor *) NULL) 
		m_interceptor = new LoadBalancingInterceptor( );    

	/*
	 * Increment the reference count before returning the interceptor.
	 */
	return VISServerInterceptor::_duplicate(m_interceptor);  
}


/**
 * Invoked by the orb when a client locate request is received.
 * The repository id of the object key is checked.  If it equals
 * the id of the proxy object then this request was sent in 
 * response to a client binding to the load-balancing object.
 * One of the objects managed by the load-balancing server is
 * chosen and returned as the method value (and is inturn 
 * forwarded back to the client).
 *
 * This is the only method currently used by the load-balancing 
 * interceptor.
 *
 * @param req_id	The request id
 * @param objKey	The object key
 * @param closure	Closure data.
 *
 * @returns	The IOR of the object to which the request is to be
 *			forwarded, or NULL if default routing is to be used.
 */
IOP::IOR *LoadBalancingInterceptor::locate(	
								CORBA::ULong				/* req_id */,
								CORBA_OctetSequence *objKey	/* object_key */,			
								VISClosure&					/* closure */) 
{
	IOP::IOR		*retObjectIOR;
	char			*repId;
	char			*name;

	/*
	 * Initialize the return value.
	 */
	retObjectIOR = NULL;

	/*
	 * Extract the repository id from the key
	 */
	repId = NULL;
	if (VISUtil::is_persistent_key(*objKey))
		VISUtil::extract_persistent_key(*objKey, repId, name);

	/*
	 * If this is a locate request for a proxy object interface
	 * then respond with one of the load balancing objects.
	 * Otherwise, the request is for some other interface type,
	 * so let the orb handling dispatching the request.
	 */
	if (repId != NULL && g_proxyObject->_is_a( repId ))
	{
		CORBA::Object_var	objVar;

		objVar = g_loadBalancingServer->pickObject();

		/*
		 * If an object was successfully selected, convert
		 * the object reference to an IOR.
		 */
		if (objVar != NULL)
			retObjectIOR = VISUtil::to_ior(objVar);
	}

	return retObjectIOR;
}

/**
 * Not used.  Defined only for tracing requests. 
 */
void LoadBalancingInterceptor::locate_succeeded(	
									CORBA::ULong	/* req_id */,
									VISClosure&		/* closure */) 
{
}

/**
 * Not used.  Defined only for tracing requests. 
 */
void LoadBalancingInterceptor::locate_forwarded(	
									CORBA::ULong req_id /* req_id */,
									IOP::IOR&			/* forward_ior */,			
									VISClosure&			/* closure */) 
{
}	

/**
 * Not used.  Defined only for tracing requests. 
 */
IOP::IOR *LoadBalancingInterceptor::locate_failed(
							CORBA::ULong			/* req_id */,
							CORBA_OctetSequence *	/*object_key  */,			
							VISClosure&				/* closure */) 
{
	return 0;	
}

/**
 * Not used.  Defined only for tracing requests. 
 */
CORBA_MarshalInBuffer *LoadBalancingInterceptor::receive_request(
							GIOP::RequestHeader& 	/* hdr */,			
							CORBA::Object *& target	/* target */,
							CORBA_MarshalInBuffer *	/* buf */,			
							VISClosure&				/* closure */) 
{
	return 0;	
}

/**
 * Not used.  Defined only for tracing requests. 
 */
void LoadBalancingInterceptor::prepare_reply(
							const GIOP::RequestHeader&	/* hdr */,			
							GIOP::ReplyHeader&			/* reply hdr */,
							CORBA::Object_ptr			/* target */,			
							VISClosure&					/* closure */) 
{
}

/**
 * Not used.  Defined only for tracing requests. 
 */
CORBA_MarshalOutBuffer *LoadBalancingInterceptor::send_reply(
							const GIOP::RequestHeader&	/* reqHdr */,
							const GIOP::ReplyHeader& 	/* hdr */,			
							CORBA::Object_ptr			/* target */,
							CORBA_MarshalOutBuffer *	/* buf */,		
							CORBA::Environment&			/* env */,
							VISClosure&					/* closure */) 
{
	return 0;	
}

/**
 * Not used.  Defined only for tracing requests. 
 */
void LoadBalancingInterceptor::send_reply_failed(			
							const GIOP::RequestHeader&	/* reqHdr */,
							const GIOP::ReplyHeader& 	/* hdr */,			
							CORBA::Object_ptr			/* target */,
							const CORBA_Exception&		/* excep */,			
							VISClosure&					/* closure */) 
{
}			

/**
 * Not used.  Defined only for tracing requests. 
 */
void LoadBalancingInterceptor::request_completed(
							const GIOP::RequestHeader&	/*reqHdr*/,
							CORBA::Object_ptr 			/* target */,	 	        
							VISClosure&					/* closure */) 
{
}

/**
 * Not used.  Defined only for tracing requests. 
 */
void LoadBalancingInterceptor::exception_occurred(
							const GIOP::RequestHeader&	/*reqHdr*/,
							CORBA::Environment&			/* env */,	
							VISClosure&					/* closure */) 
{
}
	
/**
 * Not used.  Defined only for tracing requests. 
 */
void LoadBalancingInterceptor::shutdown(VISServerInterceptor::ShutdownReason reason) 
{
}

