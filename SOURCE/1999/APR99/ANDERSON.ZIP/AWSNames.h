#ifndef AWSNames_h
#define AWSNames_h

#include <corba.h>
#include <ctype.h>

#include "CosNaming_c.hh"


/**
 * Forward reference
 */
class NamePath;
class NamesIterator;



/**
 * This class encapsulates the functions of the CORBA Naming
 * Service.  Objects and contexts are represented as a sequence
 * of names in a string separated by the '/' character as in a 
 * Unix file system.  Names can either be relative to the current
 * context or absolute with respect to the root context. An
 * absolute path begins with a '/' while a relative path is 
 * specified with a leading "./" (e.g. "./a/b/c").
 *
 */
class AWSNames
{
private:
	CosNaming::NamingContext_var		m_rootContext;

	CosNaming::NamingContext_var		m_currentContext;
	NamePath							*m_currentPath;

	CORBA::ORB_var						m_orb;

	/**
	 * Returns a pointer to the object represented by the given name.
	 */
	CORBA::Object_ptr _resolve(NamePath &);

	/**
	 * Creates a new context.  All elements up to the last
	 * element must already exist.
	 */
	void createContext(const char *path);
	void createContext(NamePath &);


public:

	AWSNames(CORBA::ORB_ptr);
	AWSNames(AWSNames *);
	virtual ~AWSNames( );

	/**
	 * Checks to make sure all contexts in the given path
	 * exist and creates any which do not.
	 */
	void createPath(const char* path);

	/**
	 * Removes the context identified by the last element
	 * of the given path.
	 */
	void removePath(const char* path);

	/**
	 * Changes the context from which all relative paths
	 * are evaluated.
	 */
	void setPath(const char* path);
      
	/**
	 * Binds an object reference to a name in the Naming Service.
	 * An exception is thrown if the name already exists.
	 */
	void registerObject(const char* name, CORBA::Object_ptr obj);
      
	/**
	 * Binds an object reference to a name in the Naming Service.
	 * If the name already exists, it is re-bound to the new object.
	 */
	void reregisterObject(const char* name, CORBA::Object_ptr obj);

	/**
	 * Removes the binding which exists to the given name.
	 */
	void unregisterObject(const char* name);
      
	/**
	 * Returns a reference to the object identified by 
	 * the given name.
	 */
	CORBA::Object_ptr getObject(const char* name);

	/**
	 * Returns a reference to the orb used by this object.
	 */
	CORBA::ORB_ptr getORB( );

	/**
	 * Returns a reference to the current context.
	 */
	CosNaming::NamingContext_ptr getContext( );

	/**
	 * Creates and returns an iterator object which can
	 * be used to list the contents of the current context.
	 */
	NamesIterator* elements();
};


/**
 * Defines the types of elements returned by the Names iterator.
 *
 * @see NamesDescription
 * @see NamesIterator
 */
enum NamesType { NamesObject, NamesContext, NamesUnknown };


/**
 * Describes a single element returned by the Names iterator.
 *
 * @see NamesIterator
 */
struct NamesDescription 
{
  CORBA::String_var		name;
  CORBA::String_var		kind;
  NamesType				type;
};


/**
 * The NamesIterator is created by the elements method
 * of the AWSNames object and is used to iterate through
 * the contents of the current naming context.
 */
class NamesIterator
{
private:
	CosNaming::NamingContext_var		m_context;

	CosNaming::BindingList_var			m_bindList;
	CosNaming::BindingIterator_var		m_bindIterator;
	CORBA::ULong						m_batchSize;

	int									m_isEndOfList;
	CORBA::ULong						m_nextItem;

	NamesDescription					namesDesc;


public:
	NamesIterator(CosNaming::NamingContext_ptr);
	virtual ~NamesIterator( );

	/**
	 * Returns true if the nextElement has more elements 
	 * available.
	 */
	CORBA::Boolean hasMoreElements( );

	/**
	 * Returns a description of the next element.
	 */
	NamesDescription& nextElement( );

	/**
	 * Thrown when the application attempts to retrieve
	 * another element when there are no more available.
	 */
	class NoMoreElements { };
};


/**
 * The NamePath is a utility class which parses a
 * path string into its component elements and stores
 * these elements in CosNaming::Name variable.
 */
class NamePath
{
private:
	CosNaming::Name_var		m_name;
	int						m_isAbsolute;

public:
	NamePath(const char *);
	NamePath(NamePath &, int elementCount=-1);
	NamePath(NamePath&, NamePath&);
	virtual ~NamePath();

	/**
	 * Returns the CosNaming::Name associated with this NamePath.
	 */
	CosNaming::Name_ptr getCosName(NamePath *np = NULL);

	/**
	 * Returns the name value of an element of this NamePath.
	 */
	const char *getElementName(CORBA::ULong);
	
	/**
	 * Returns the kind value of an element of this NamePath. 
	 */
	const char *getElementKind(CORBA::ULong);

	/**
	 * Sets the kind value for the last element of this NamePath.
	 */
	void setKind(const char *);

	/**
	 * Returns the number of elements contained in this NamePath.
	 */
	CORBA::ULong getElementCount( );

	/**
	 * Returns true if this NamePath represents an absolute name.
	 */
	int isAbsolute( );
};

/**
 * The NamesException class defines the only exception 
 * which is raised by an AWSNames object.
 */
class NamesException : public CORBA::UserException 
{
public:
	/**
	 * Defines all possible exception reasons.
	 */
	enum ExceptionReason 
	{
			CORBA_SYSTEM,
			INVALID_OBJECT_NAME,
			INVALID_OBJECT_REFERENCE,
			CONTEXT_NOT_FOUND,
			CONTEXT_NOT_EMPTY,
			NOT_A_CONTEXT,
			OBJECT_NOT_FOUND,
			NAME_NOT_FOUND,
			NAME_ALREADY_EXISTS,
			COULD_NOT_NARROW,
			UNKNOWN
	};

private:
	ExceptionReason		m_reason;

public:
	/**
	 * Constructs a NameException with the given reason code.
	 *
	 * @param reason	Describes the exception
	 */
	NamesException(ExceptionReason reason)
	{
		m_reason = reason;
	}

	/**
	 * Gets the exception reason.
	 *
	 * @return The value of the exception reason field.
	 */
	ExceptionReason getReason( )
	{
		return m_reason;
	}
};



#endif
