#include "AWSServer.h"
#include "AWSLoadBalancing.h"
#include "businessObjectImpl.h"

int main(int argc, char**argv) 
{
	AWSLoadBalancing*	lb = new AWSLoadBalancing( "/MyFolder/MyObject" );
	AWSServer*			server = AWSServer::instance( argc, argv, "TestServer", lb );

	server->addObject( new businessObjectImpl( "Business Object 1" ) );
	server->addObject( new businessObjectImpl( "Business Object 2" ) );
	server->addObject( new businessObjectImpl( "Business Object 3" ) );

	try {
		server->run( );
	}
	catch(const AWSServerException &srvEx) {
		cerr << "Exception occurred during run: " << endl;
		cerr << srvEx << endl;
	}

	return 0;
}

