#ifndef AWSLoadBalancing_h
#define AWSLoadBalancing_h

#include <corba.h>

#include "LoadBalancing_s.hh"

#include "vcinter.h"
#include "vutil.h"
#include "vinit.h"
#include "vthread.h"
#include "vport.h"



/**
 * Forward reference
 */
class ObjectList;
class ServerList;
class LoadBalancingInterceptor;
class AWSLoadBalancing;


/**
 * The AWSLoadBalancingTimer class executes a task at
 * regular intervals of time through the use of a separate 
 * thread. The VISThread class provides the native thread
 * creation, and executes the method 'begin' when it is 'run'.
 */
class AWSLoadBalancingTimer : public VISThread
{
private:
	AWSLoadBalancing		*m_lbObject;

	CORBA::ULong			m_updateInterval;
	CORBA::ULong			m_pingInterval;
	CORBA::ULong			m_delay;

	long					m_lastUpdate;
	long					m_lastPing;

	CORBA::Boolean			m_continue;


public:
	AWSLoadBalancingTimer(	AWSLoadBalancing *, 
							CORBA::ULong pingInterval = 5,
							CORBA::ULong updateInterval = 60);
	virtual ~AWSLoadBalancingTimer( );

	/**
	 * Starts the execution of the thread process.  It invokes
	 * the 'run' method of the VISThread class which creates
	 * a thread and invokes the 'begin' method.
	 */
	virtual void start( );
    
	/**
	 * Resets the continuation flag which is used as the
	 * return value of the startTimer method.  This flag
	 * is used to control the main loop of the thread.
	 * Returning a false will cause the main event loop to
	 * exit.  Note that calling stop will not terminate
	 * the loop immediately.
	 *
	 * @see startTimer.
	 */
	void stop( );

	/**
	 * Called by the VISThread class when its 'run' method
	 * is invoked.  This method is the main event loop for
	 * this timer class.  It sleeps for a fixed intervals
	 * of time (as determined in the constructor) and then
	 * executes the update method.  This method will return 
	 * only when requested by the continuation flag.
	 *
	 * @see update
	 */
	void begin( );

	/**
	 * Sets the number of seconds between updates.
	 *
	 * @param  interval Number of seconds.
	 */
	void setUpdateInterval(int);

	/**
	 * Returns the number of seconds between updates.
	 *
	 * @returns Number of seconds.
	 */
	int getUpdateInterval( );

	/**
	 * An exception class thrown by the update method
	 * if an error occurs while updating the master server.
	 */
	class UpdateError { };
};



/**
 * Manages a list of objects.
 */
class ObjectList
{
private:
	CORBA::Object_var	*m_objectList;
	int					m_listCount;		// Number of elements used
	int					m_listLength;		// Number of elements in the array
	int					m_listIncrement;

	/**
	 * Locates the specified object in the list and returns
	 * the index position of that object.  If the object is
	 * not found, a -1 is returned.
	 */
	int findObjectIndex(CORBA::Object_ptr);


public:
	ObjectList(int listLength=5, int listIncrement=5);
	virtual ~ObjectList( );

	/**
	 * Adds an object to the end of the object list.
	 */
	void addObject(CORBA::Object_ptr);

	/**
	 * Removes an object from the object list.
	 */
	void removeObject(CORBA::Object_ptr);

	/**
	 * Returns the number of objects in the object list.
	 */
	int getObjectCount( );

	/**
	 * Returns a reference to the object residing in the
	 * specified position in the list.
	 */
	CORBA::Object_ptr getObject(int);
};


/**
 * Represents a CORBA server process.  Each CORBA server
 * which registers an object with the master load-balancing
 * server will have an instance of this class created
 * and placed in the ServerList.
 */
class Server
{
private:
	LoadBalancing::IAgent_var	m_serverObject;
	CORBA::String_var			m_hostAddr;

	ObjectList					m_objectList;

	CORBA::Double				m_loadFactor;
	long						m_lastUpdate;

	int							m_nextObject;

public:
	Server(LoadBalancing::IAgent_ptr srvObjPtr);
	virtual ~Server( );

	/**
	 * Gets the number of seconds since the load factor
	 * was last updated for this server.
	 */
	CORBA::ULong getTimeSinceLastUpdate();

	/**
	 * Associates a load factor with this server object.
	 */
	void setLoadFactor(CORBA::Double);

	/**
	 * Retrieves the last load factor saved with this server object.
	 */
	CORBA::Double getLoadFactor();

	/**
	 * Returns a reference to the next object associated with
	 * this server.  A round-robin selection algorithm is used.
	 */
	virtual CORBA::Object_ptr selectObject();

	/**
	 * Returns a reference to the peer object which is
	 * represented by this Server instance.
	 */
	LoadBalancing::IAgent_ptr getServerObject( );

	/**
	 * Returns the host address associated with this
	 * Server object.
	 */
	const char *getHostAddress( );

	/**
	 * Compares two server objects to determine if they
	 * reference the same peer.
	 */
	CORBA::Boolean isEqual(LoadBalancing::IAgent_ptr);

	/**
	 * Associates a new object with this Server instance.
	 */
	void addObject(CORBA::Object_ptr);

	/**
	 * Removes the given object from the list of objects
	 * associated with this Server instance.
	 */
	void removeObject(CORBA::Object_ptr);

	/**
	 * Returns the number of objects currently associated
	 * with this Server instance.
	 */
	int getObjectCount( );
	
	/**
	 * Returns a reference to the object at the given
	 * index position.
	 */
	CORBA::Object_ptr getObject(int ndx);

	/**
	 * Defines the exception type thrown by a Server object.
	 */
	class ServerException { };
};

/**
 * The ServerListIterator is used to sequentially list all
 * of the server object contained in a ServerList.  It is
 * created by the elements method in the ServerList element.
 */
class ServerListIterator
{
private:
	ServerList		*m_serverList;
	int				m_nextElement;

public:
	ServerListIterator(ServerList *);
	virtual ~ServerListIterator( );

	/**
	 * Used to determine if there are more elements to be
	 * returned by this iterator.
	 */
	int hasMoreElements( );

	/**
	 * Returns the next element in the iterator.
	 */
	Server* nextElement( );

	/**
	 * Thrown by nextElement if there are no more elements
	 * to be returned.
	 */
	class NoMoreElements { };
};

/**
 * Manages a list of Server objects.
 */
class ServerList
{
private:
	Server		**m_serverList;
	int			m_listCount;		// Number of elements used
	int			m_listLength;		// Number of elements in the array
	int			m_listIncrement;

	friend ServerListIterator::ServerListIterator(ServerList *);

	/**
	 * Locates the specified server object in the list and 
	 * returns the index position of that object.  If the 
	 * object is not found, a -1 is returned.
	 */
	int findServerIndex(LoadBalancing::IAgent_ptr);


public:
	ServerList(int listLength=5, int listIncrement=5);
	virtual ~ServerList( );

	/**
	 * Saves the loading factor with the given server object.
	 */
	void saveLoadFactor(CORBA::Double, LoadBalancing::IAgent_ptr);

	/**
	 * Adds an object to the list associated with the given
	 * server object.  A Server object is created if necessary.
	 */
	void addObject(CORBA::Object_ptr, LoadBalancing::IAgent_ptr);

	/**
	 * Removes an object from the list associated with the given
	 * server object.  If, as a result of the removal of the object,
	 * the object list for the server is empty, the Server is
	 * removed from the server list.
	 */
	void removeObject(CORBA::Object_ptr, LoadBalancing::IAgent_ptr);

	/**
	 * Removes an object from the server object to which is it
	 * associated.  The server list is scanned for all occurrences
	 * of the object and is removed from each list in which
	 * it appears.
	 */
	void removeObject(CORBA::Object_ptr);

	/**
	 * Removes all object associated with a given server object.
	 * The Server is also removed from the server list.
	 */
	void removeServer(LoadBalancing::IAgent_ptr);

	/**
	 * Adds an agent to the end of the agent list.
	 */
	void appendServer(LoadBalancing::IAgent_ptr);

	/**
	 * Returns the number of server in the server list.
	 */
	int getCount( );

	/**
	 * Returns a reference to the server object residing in the
	 * specified position in the list.
	 */
	Server* getServerObject(int);

	/**
	 * Removes all servers from the list.
	 */
	void clear( );

	/**
	 * Creates and returns an iterator which can be used to step
	 * through all of the server maintained by this ServerList.
	 */
	ServerListIterator* elements( );

	/**
	 * An exception class thrown when there is an attempt to
	 * access a Server object which does not exist.
	 */
	class ServerNotFound { };
};


/**
 * The main Load Balancing class.
 */
class AWSLoadBalancing : public _sk_LoadBalancing::_sk_IAgent
{
private:
	CORBA::ORB_var					m_orb;
	CORBA::BOA_var					m_boa;

	LoadBalancing::IAgent_var	m_master;
	AWSLoadBalancingTimer			*m_timer;

	ServerList						m_serverList;
	CORBA::String_var				m_name;
	CORBA::String_var				m_lbName;

	VISMutex						m_loadBalancingMtx;

	ObjectList						m_objectList;

	/*
	 * A Load Balancing server object can manage
	 * only a single type of object.  This type will
	 * be determined when the first object is added
	 * to the server.  The type is stored in this
	 * field and all other objects added to the
	 * server will be compared against this type.
	 */
	CORBA::String_var				m_repositoryId;

	void bindMaster(int);
	void distributeServerList( );

public:
	AWSLoadBalancing(const char *);
	virtual ~AWSLoadBalancing( );

	/**
	 * Initializes the Load Balancing server object.
	 * The server will either bind itself in the Naming
	 * Service as the master server or will register
	 * with the master server if one already exists.
	 */
	void initialize(CORBA::ORB_ptr, CORBA::BOA_ptr);


	/**
	 * Computes and returns the loading factor for the
	 * host machine on which this instance resides.
	 */
	virtual CORBA::Double computeLoad( );
	

	/**
	 * Updates the current load factor for the specified
	 * server in the master load balancing server's list.
	 */
	void updateLoadFactor( );
	void updateLoadFactor(CORBA::Double, LoadBalancing::IAgent_ptr);


	/**
	 * Checks for the existence of the master agent or the
	 * slaves agents if this is the master, and handles
	 * the case where it is no longer available.
	 */
	void pingMaster( );


	/**
	 * The register and unregister object methods make the given
	 * object available/unavailable to the load-balancing server
	 * for use when distributing requests.
	 *
	 * These methods should be invoked by the application code
	 * without specifying a value for the server parameter.
	 * This value will be filled-in by these methods when they
	 * are invoked on the primary load-balancing server.
	 */
	void registerObject(CORBA::Object_ptr);
	void registerObject(CORBA::Object_ptr, LoadBalancing::IAgent_ptr);

	void unregisterObject(CORBA::Object_ptr);
	void unregisterObject(CORBA::Object_ptr, LoadBalancing::IAgent_ptr);
      

	/**
	 * The register and unregister agent methods make the 
	 * current agent available/unavailable to the master
	 * agent.  A load-balancing server must register
	 * itself before attempting to register objects, and
	 * should unregister itself when it is shutdown.
	 */
	void registerAgent( );
 	void registerAgent(LoadBalancing::IAgent_ptr);

	void unregisterAgent( );
 	void unregisterAgent(LoadBalancing::IAgent_ptr);
   

	/**
	 * Called by the master agent when distributing lists of
	 * servers in the load-balancing group.
	 */
	void setAgentList(const LoadBalancing::LBAgentList& serverList);


	/**
	 * Invoked by the primary server when a locate request
	 * is received from a client process.
	 */
	CORBA::Object_ptr pickObject( );

	
	/**
	 * An overrideable method called by pickObject.  This method
	 * selects an object from the list of all objects 
	 */
	virtual CORBA::Object_ptr selectObject( );	
};


/**
 * The class which defines the proxy object bound in the
 * Naming Service and resolved by clients in order to obtain
 * a reference to one of the objects managed by the load
 * balancing server.
 */
class LoadBalancingProxy : public _sk_LoadBalancing::_sk_IProxy
{
public:
	LoadBalancingProxy( ) 
		: _sk_IProxy( "LoadBalancingProxy" )
	{
	}
};


/**
 * The factory class used by the orb to create the interceptor
 * when a client request is received.  Note that only a single
 * interceptor is used by load balancing.
 */
class LoadBalancingIntFactory : public VISServerInterceptorFactory
{
private:  
	static LoadBalancingIntFactory		m_interceptorFactory;

	VISServerInterceptor_var			m_interceptor;

public:
	LoadBalancingIntFactory( );
	virtual ~LoadBalancingIntFactory( );

	/**
	 * Invoked by the orb when an interceptor factory is needed.
	 * Only a single factory is used, so the statically created
	 * factory object is returned.
	 *
	 * @returns An interceptor.
	 */
	static LoadBalancingIntFactory *instance()
	{
		return &m_interceptorFactory;  
	}

	/**
	 * Invoked by the orb to obtain an interceptor when 
	 * a client request is received.
	 */
	VISServerInterceptor *create(int fd, const IOP::TaggedProfile& p);
};


/**
 * The interceptor class which is instantiated by the
 * load-balancing interceptor factory, and processes
 * the locate requests for the load balancing class.
 * None of the other methods define by VISServerInterceptor
 * are currently used.  The other methods are included
 * to allow for trace information to be displayed.
 */
class LoadBalancingInterceptor : public VISServerInterceptor
{
public:
	/*
	 * Invoked by the orb when a client locate request 
	 * is received.
	 *
	 * This is the only method currently used by the
	 * load-balancing interceptor.
	 */
	IOP::IOR *locate(	CORBA::ULong 			/* req_id */,
						CORBA_OctetSequence *	/* object_key */,			
						VISClosure&				/* closure */);

	/*
	 * Invoked if the locate succeeded.
	 */
	void locate_succeeded(	CORBA::ULong		/* req_id */,
							VISClosure&			/* closure */);

	/*
	 * Invoked if the locate is forwarded. If ior is changed, 
	 * that IOR is forwarded to client.
	 */
	void locate_forwarded(	CORBA::ULong		/* req_id */,
							IOP::IOR&			/* forward_ior */,			
							VISClosure&			/* closure */);

	/*
	 * Invoked if locate failed. If a non-null ior is returned 
	 * that IOR is forwarded to client.
	 */
	IOP::IOR *locate_failed(
						CORBA::ULong				/* req_id */,
						CORBA_OctetSequence *		/*object_key  */,			
						VISClosure&					/* closure */);

	/*
	 * Invoked when a request message is recived from client.
	 * If return value is "not null", that buffer is passed onto
	 * target. It also possible to change the hdr and forward the
	 * request to a different operation or to a different Object.
	 */
	CORBA_MarshalInBuffer *receive_request(
						GIOP::RequestHeader& 		/* hdr */,			
						CORBA::Object *& target		/* target */,
						CORBA_MarshalInBuffer *		/* buf */,			
						VISClosure&					/* closure */);

	/* 
	 * Invoked when the reply header is being prepared.
	 * Note that request_failed can be called.
	 */
	void prepare_reply(	const GIOP::RequestHeader&	/* hdr */,			
						GIOP::ReplyHeader&			/* reply hdr */,
						CORBA::Object_ptr			/* target */,			
						VISClosure&					/* closure */);

	/*
	 * Invoked by the orb when it is about to send a reply.
	 * If return value is "not null", that value is sent 
	 * to client. The env passed will contain any user 
	 * exceptions, if they were thrown.
	 */
	CORBA_MarshalOutBuffer *send_reply(
						const GIOP::RequestHeader&	/* reqHdr */,
						const GIOP::ReplyHeader& 	/* hdr */,			
						CORBA::Object_ptr			/* target */,
						CORBA_MarshalOutBuffer *	/* buf */,			
						CORBA::Environment&			/* env */,
						VISClosure&					/* closure */);

	/*
	 * Invoked by the orb if it was unable to send a reply
	 * due usually to a communications problem.
	 */
	void send_reply_failed(			
						const GIOP::RequestHeader&	/* reqHdr */,
						const GIOP::ReplyHeader& 	/* hdr */,			
						CORBA::Object_ptr			/* target */,
						const CORBA_Exception&		/* excep */,			
						VISClosure&					/* closure */);

	/*
	 * Invoked if the reply was sent successfully.
	 */
	void request_completed(
						const GIOP::RequestHeader&	/* reqHdr */,
						CORBA::Object_ptr 			/* target */,	 	        
						VISClosure&					/* closure */);

	/*
	 * Invoked when exception occured.
	 */
	void exception_occurred(
						const GIOP::RequestHeader&	hdr,
						CORBA::Environment&			env,			
						VISClosure&					/* closure */);

	/*
	 * Called when the connection is forcibly being shutdown
	 * by the orb (Adapter) since the connection limit has 
	 * been reached.
	 */
	void shutdown(VISServerInterceptor::ShutdownReason reason);
};



#endif

