#include <string.h>

#include "Utilities.h"


/**
 * Constructor which accepts a list of valid options.
 *
 * @param optionStr	A list of valid options separated by commas
 */
Options::Options(const char *optionStr)
{
	StringTokenizer		options(optionStr, ',');
	int					idx = 0;

	m_validCount	= options.getRemainingCount( );
	m_validOptions	= new validOptionStruct[ m_validCount ];

	while ( options.hasMoreElements( ) )
	{
		const char	*nextToken	= options.nextElement( );
		int			tokenLen	= strlen(nextToken);

		m_validOptions[ idx ].hasValue = (tokenLen > 0 && nextToken[tokenLen-1] == ':');

		m_validOptions[ idx ].name = new char[ strlen(nextToken) + 1 ];
		strcpy( m_validOptions[ idx ].name, nextToken );

		// Remove the semi-colon
		if (m_validOptions[ idx ].hasValue) 
			m_validOptions[ idx ].name[tokenLen-1] = '\0';

		idx ++;
	}
}

/**
 * Destructor.
 */
Options::~Options( )
{
	for(int i = 0; i < m_validCount; i ++)
	{
		delete [] m_validOptions[ i ].name;
	}
	delete [] m_validOptions;


	for(int j = 0; j < m_parsedCount; j ++)
	{
		delete [] m_parsedOptions[ j ].name;

		if (m_parsedOptions[ j ].value != NULL)
			delete [] m_parsedOptions[ j ].value;
	}
	delete [] m_parsedOptions;
}

/**
 * Parses the command line arguments and stores the
 * results for later retrieval.
 *
 * @param argc		Number of arguments in argv
 * @param argv		An array of strings
 * @param strict	Should an error be thrown on unknown options?
 */
void Options::parse(int argc, char **argv, int strict)
{
	m_parsedCount	= 0;
	m_parsedOptions	= new parsedOptionStruct[ argc ];

	int		idx;

	for(int i = 0; i < argc; i ++)
	{
		if (argv[i][0] == '-')
		{
			char	*name = &argv[i][1];

			idx = optionIndex( name );

			if ( idx >= 0 )
			{
				if ( m_validOptions[ idx ].hasValue && i >= argc-1 && strict )
					throw InvalidArg( );

				if	( ! m_validOptions[ idx ].hasValue
					|| (m_validOptions[ idx ].hasValue && i < argc-1) )
				{
					m_parsedOptions[ m_parsedCount ].name = new char[ strlen(name) + 1 ];
					strcpy( m_parsedOptions[ m_parsedCount ].name, name );

					m_parsedOptions[ m_parsedCount ].value = NULL;

					if (m_validOptions[ idx ].hasValue)
					{
						char	*value = argv[i+1];

						m_parsedOptions[ m_parsedCount ].value = new char[ strlen(value) + 1 ];
						strcpy( m_parsedOptions[ m_parsedCount ].value, value );

						i ++;
					}

					m_parsedCount ++;
				}
			}
			else
			{
				if ( strict )	throw InvalidArg( );
			}
		}
	}
}

/**
 * Searches the parsed options list for the specified option.
 *
 * @param name	Option name to be located
 *
 * @returns True if the option name is found, False otherwise.
 */
int Options::isFound(char *name)
{
	for(int i = 0; i < m_parsedCount; i ++)
		if (strcmp(m_parsedOptions[ i ].name, name) == 0)
			return 1;

	return 0;
}

/**
 * Searches the parsed options list for the specified option
 * and returns a boolean value indicating whether or not
 * the option has an associated value.
 *
 * @param name	Option name to be located
 *
 * @returns True if the option name is found and has a value,
 *			False otherwise.
 */
int Options::hasValue(char *name)
{
	for(int i = 0; i < m_parsedCount; i ++)
		if (strcmp(m_parsedOptions[ i ].name, name) == 0)
			return (m_parsedOptions[ i ].value != NULL ? 1 : 0);

	return 0;
}

/**
 * Gets the value associated with the given option name.
 *
 * @param name	Option name whose value is to be returned.
 *
 * @returns The option value, null if not found or the
 *			option has no value.
 */
const char *Options::getValue(char *name)
{
	for(int i = 0; i < m_parsedCount; i ++)
		if (strcmp(m_parsedOptions[ i ].name, name) == 0)
			return m_parsedOptions[ i ].value;

	return NULL;
}

/**
 * Private utility method to locate an option in the
 * parsed options list and return its array index position.
 *
 * @param name	Option to be located.
 *
 * @returns The option's array position; -1 if not found.
 */
int Options::optionIndex(char *name)
{
	for(int i = 0; i < m_validCount; i ++)
		if (strcmp(m_validOptions[ i ].name, name) == 0)
			return i;

	return -1;
}





/**
 * Constructor which makes a copy of the string to be tokenized,
 * and replaces all occurrences of the separator character
 * with a null.
 *
 * @param string	The string to be tokenized.
 * @param separator	The character which separates the tokens
 *					(default is a space ' ').
 */
StringTokenizer::StringTokenizer(const char *string, char separator)
{
	m_string = new char[ strlen(string) + 1 ];
	strcpy( m_string, string );

	m_nextToken = m_string;

	/*
	 * Replace all separator characters with a null
	 */
	char *p;

	for(p = m_string; *p != '\0'; p ++)
		if ( *p == separator )	*p = '\0';

	m_endToken = p+1;
}

/**
 * Destructor.  Deletes the tokenized string.
 */
StringTokenizer::~StringTokenizer( )
{
	delete[] m_string;
}

/**
 * Counts and returns the number of tokens which 
 * have not been returned by calls to nextElement.
 *
 * @returns Number of tokens remaining.
 */
int StringTokenizer::getRemainingCount( )
{
	const char	*nextToken = m_nextToken;
	int			tokenCount = 0;

	while ( nextToken != m_endToken )
	{
		tokenCount ++;

		nextToken += (strlen(nextToken) + 1);
	}

	return tokenCount;
}

/**
 * Returns true if there are more tokens in the
 * string to be returned.
 *
 * @returns True if the last token has not been returned.
 */
int StringTokenizer::hasMoreElements( )
{
	return (m_nextToken != m_endToken ? 1 : 0);
}

/**
 * Returns the next token in the string.  The token
 * index is advanced to the next token in preparation
 * of the next call to this method.
 *
 * @returns The next token in the string; null if
 *			there are no more tokens available.
 */
const char *StringTokenizer::nextElement( )
{
	const char *returnToken = NULL;

	if (m_nextToken != m_endToken)
	{
		returnToken = m_nextToken;

		m_nextToken += (strlen(m_nextToken) + 1);
	}

	return returnToken;
}


