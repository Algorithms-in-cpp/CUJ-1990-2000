
#ifndef Utilities_h
#define Utilities_h


/**
 * Options is a utility class which can be used
 * to parse an array of arguments such as from
 * the argv command line.
 * 
 * It provides a set of functions which can
 * be used to query and retrieve these values.
 */
class Options
{
private:
	struct validOptionStruct
	{
		char	*name;
		int		hasValue;
	};

	validOptionStruct	* m_validOptions;
	int					m_validCount;

	struct parsedOptionStruct
	{
		char	*name;
		char	*value;
	};

	parsedOptionStruct	* m_parsedOptions;
	int					m_parsedCount;

	int optionIndex(char *);

public:
	Options(const char *);
	virtual ~Options( );

	/**
	 * Prepares a new set of arguments.
	 */
	void parse(int, char **, int strict=0);

	/**
	 * Returns true if the specified argument was found.
	 */
	int isFound(char *);

	/**
	 * Returns true if the specified argument contains
	 * a value.
	 */
	int hasValue(char *);

	/**
	 * Returns the value of the given argument.
	 */
	const char *getValue(char *);

	/**
	 * An exception class thrown by 'parse'.
	 */
	class InvalidArg { };
};



/**
 * The StringTokenizer is a utility routine which
 * can be used to parse a string into a sequence
 * of token separated by a given character.
 */
class StringTokenizer
{
private:
	char	* m_string;
	char	* m_nextToken;
	char	* m_endToken;

public:
	StringTokenizer(const char *, char separator=' ');

	~StringTokenizer( );

	/**
	 * Returns the next token
	 */
	const char *nextElement( );

	/**
	 * Returns true if there are more tokens
	 * available.
	 */
	int hasMoreElements( );

	/**
	 * Returns the number of tokens which remain.
	 */
	int getRemainingCount( );
};



#endif

