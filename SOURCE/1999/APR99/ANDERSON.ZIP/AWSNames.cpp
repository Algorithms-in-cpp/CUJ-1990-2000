
#include "AWSNames.h"
#include "Utilities.h"

const char SEPARATOR = '/';

/**
 * Constuctor which initializes the root context from
 * the orb.
 *
 * @param orb	A reference to the orb
 */
AWSNames::AWSNames(CORBA::ORB_ptr orb)
{
	m_orb = CORBA::ORB::_duplicate(orb);


	/*
	 * Try to resolve the initialize reference to
	 * the Naming Service.
	 */
	CORBA::Object_var	objVar;

	try 
	{
		objVar = m_orb->resolve_initial_references("NameService");

		m_rootContext = CosNaming::NamingContext::_narrow(objVar);
	}
	catch(CORBA::INITIALIZE&)
	{
		throw NamesException( NamesException::UNKNOWN );
	}
	catch(CORBA::SystemException) 
	{
		throw NamesException( NamesException::CORBA_SYSTEM );
	}
	catch(CORBA::ORB::InvalidName)
	{
		throw NamesException( NamesException::INVALID_OBJECT_NAME );
	}
	catch(...)
	{
		throw NamesException( NamesException::UNKNOWN );
	}


	/*
	 * Check to make sure that a valid context was obtained.
	 */
	if (CORBA::is_nil(m_rootContext))
		throw NamesException( NamesException::COULD_NOT_NARROW );


	/*
	 * Initialize the current context to the root context.
	 */
	m_currentPath		= new NamePath( "/" );
	m_currentContext	= m_rootContext;
}

/**
 * Constuctor which initializes the AWSNames object from
 * an existing object.  The root context for the new object
 * is taken as the current context of the existing one.
 *
 * @param names		An existing AWSNames object from which the
 *					new object is to be created.
 */
AWSNames::AWSNames(AWSNames *names)
{
	/*
	 * Initialize the orb and the root context (from the
	 * existing object's current context).
	 */
	m_orb			= names->getORB( );
	m_rootContext	= names->getContext( );

	m_currentPath		= new NamePath( "/" );
	m_currentContext	= m_rootContext;
}

/**
 * Destructor.
 */
AWSNames::~AWSNames( )
{
	delete m_currentPath;
}

/**
 * Creates a context path based on the given text string path
 * description.  Elements in the path are created one at a time
 * until the entire path has been created or an error occurs
 * during the creation.
 *
 * Another approach would have been to _resolve each partial path
 * and then create it if it does not exist.  The only advantage to 
 * this approach is that more meaningful error messages could be
 * output (such as if an object exists whose name coincides with
 * the name of a partial path).
 *
 * @param path	A text description of the path to be created.
 */
void AWSNames::createPath(const char* path)
{
	NamePath		np( path );
	NamePath		*partialNP;

	/*
	 * Create each element of the given path one at a time.
	 */
	for(int i = 1; i <= np.getElementCount(); i ++)
	{
		partialNP = new NamePath(np, i);

		try 
		{
			createContext( *partialNP );
		}
		catch (CosNaming::NamingContext::AlreadyBound&) 
		{
			// Partial path already exists.  Ignore it and continue.
		}
		catch(...)
		{
			delete partialNP;

			throw NamesException( NamesException::UNKNOWN );
		}

		delete partialNP;
	}
}

/**
 * Deletes a naming context.  Only the last element in the
 * given path string will be destroyed.
 *
 * @param path	A text description of the context to be deleted.
 */
void AWSNames::removePath(const char* path)
{
 	CosNaming::NamingContext_var	thisContext;

	CORBA::Object_var				objVar;
	CosNaming::Name_var				thisName;

	NamePath						np( path );

	int								isDestroyed = 0;


	/*
	 * Do not allow the user to specify an empty path.  Although it
	 * might be useful to be able to delete the context ".", it would
	 * not be valid if the current context is the root context (i.e. "/"),
	 * and it would also result in the current AWSNames object becoming
	 * invalid since the naming context would have been destroyed.
	 * Destroying the current AWSNames context can still be done by
	 * specifying the full path to the context.
	 */
	if (np.getElementCount() == 0)	return;


	/*
	 * First resolve the name and destroy the context object
	 */
	thisName = np.getCosName( m_currentPath );

	try 
	{
		objVar = m_rootContext->resolve(thisName);
	}
	catch (CosNaming::NamingContext::NotFound& ) 
	{
		throw NamesException( NamesException::CONTEXT_NOT_FOUND );
	}
	catch (CosNaming::NamingContext::InvalidName& ) 
	{
		throw NamesException( NamesException::INVALID_OBJECT_NAME );
	}
	catch (CORBA::SystemException&) 
	{
		/*
		 * If we cannot locate the naming context, assume it does not exist.
		 * The name still needs to be unbound from the context.
		 */
		isDestroyed = 1;
	}
	catch (...) 
	{
		throw NamesException( NamesException::UNKNOWN );
	}


	/*
	 * If the context object was found, destroy it.
	 */
	if (! isDestroyed) 
	{
		// Narrow it to a naming context object
		try 
		{
			thisContext = CosNaming::NamingContext::_narrow(objVar);
		}
		catch (...) 
		{
			throw NamesException( NamesException::COULD_NOT_NARROW );
		}

		// Destroy the context
		try 
		{
			thisContext->destroy();
		}
		catch (CORBA::INV_OBJREF)
		{
			// Try to unbind the name
		}
		catch (CosNaming::NamingContext::NotEmpty& ) 
		{
			throw NamesException( NamesException::CONTEXT_NOT_EMPTY );
		}
	}

 
	/*
	 * Unbind the context name.
	 */
	try 
	{
		m_rootContext->unbind(thisName);
	}
	catch (...) 
	{
		throw NamesException( NamesException::UNKNOWN );
	}
}

/**
 * Changes the current path from which all relative paths
 * are resolved.
 *
 * @param path	An absolute or relative path description.
 */
void AWSNames::setPath(const char* path)
{
	CosNaming::NamingContext_var	thisContext;
	CORBA::Object_var				objVar;
	NamePath						np( path );

	CosNaming::Name_var				thisName;


	NamePath	newPath( np, *m_currentPath );

	/*
	 * Try to resolve the NamePath into an object reference.
	 */
	try
	{
		objVar = _resolve( newPath );
	}
	catch (CosNaming::NamingContext::NotFound& ) 
	{
		throw NamesException( NamesException::CONTEXT_NOT_FOUND );
	}
	catch (CosNaming::NamingContext::InvalidName& ) 
	{
		throw NamesException( NamesException::INVALID_OBJECT_NAME );
	}
	catch (CORBA::INV_OBJREF ) 
	{
		throw NamesException( NamesException::INVALID_OBJECT_REFERENCE );
	}
	catch (CORBA::SystemException& ) 
	{
		throw NamesException( NamesException::CORBA_SYSTEM );
	}
	catch (...) 
	{
		throw NamesException( NamesException::UNKNOWN );
	}


	if (! objVar )
		throw NamesException( NamesException::INVALID_OBJECT_REFERENCE );


	/*
	 * The resolve was successful, now narrow the reference 
	 * to a naming context.
	 */
	try 
	{
		thisContext = CosNaming::NamingContext::_narrow(objVar);
	}
	catch (...) 
	{
		throw NamesException( NamesException::COULD_NOT_NARROW );
	}


	// Success.  Save the new context as the current context
	m_currentContext = thisContext;

	delete m_currentPath;
	m_currentPath = new NamePath( newPath );
}

/**
 * Binds an object reference to the given name in the Naming Service.
 * The name can be given as either an absolute or relative path name.
 *
 * @param name		The name to be associated with the object
 * @param objPtr	An object reference
 */
void AWSNames::registerObject(const char *name, CORBA::Object_ptr objPtr)
{
	NamePath		np( name );

	if (np.getElementCount() == 0) return;


	/*
	 * Create the path to the object name
	 */
	NamePath		partialNP( np, np.getElementCount()-1 );

	try 
	{
		createContext( partialNP );
	}
	catch (CosNaming::NamingContext::AlreadyBound&) 
	{
		// Partial path already exists.  Continue.
	}
	catch(...)
	{
		throw NamesException( NamesException::UNKNOWN );
	}

	/*
	 * Path now exists (either because we just created it or 
	 * because it already existed).  Now try to bind the object
	 * to the given name.
	 */
	CosNaming::Name_var				thisName;

	thisName = np.getCosName( m_currentPath );

	try 
	{
		m_rootContext->bind(thisName, objPtr);
    }
	catch (CosNaming::NamingContext::NotFound& ) 
	{
		throw NamesException( NamesException::CONTEXT_NOT_FOUND );
	}
	catch (CosNaming::NamingContext::InvalidName& ) 
	{
		throw NamesException( NamesException::INVALID_OBJECT_NAME );
	}
    catch (CosNaming::NamingContext::AlreadyBound& ) 
	{
		throw NamesException( NamesException::NAME_ALREADY_EXISTS );
    }
	catch (CORBA::SystemException& ) 
	{
		throw NamesException( NamesException::CORBA_SYSTEM );
	}
	catch (...) 
	{
		throw NamesException( NamesException::UNKNOWN );
	}
}

/**
 * Removes an object binding from the Naming Service.  The name
 * can be either absolute or relative.
 *
 * @param name	The object name to be unbound.
 */
void AWSNames::unregisterObject(const char *name)
{
	NamePath				np( name );
	CosNaming::Name_var		thisName;


	if (np.getElementCount() == 0)	return;

	thisName = np.getCosName( m_currentPath );

	/*
	 * Unbind the name.
	 */
	try 
	{
		m_rootContext->unbind( thisName );
	}
	catch (CosNaming::NamingContext::NotFound& ) 
	{
		throw NamesException( NamesException::CONTEXT_NOT_FOUND );
	}
	catch (CosNaming::NamingContext::InvalidName& ) 
	{
		throw NamesException( NamesException::INVALID_OBJECT_NAME );
	}
	catch (CORBA::SystemException& ) 
	{
		throw NamesException( NamesException::CORBA_SYSTEM );
	}
	catch (...) 
	{
		throw NamesException( NamesException::UNKNOWN );
	}
}

/**
 * Binds an object reference to the given name in the Naming Service.
 * If the name is already bound, it will be re-bound to the given object.
 * The name can be given as either an absolute or relative path name.
 *
 * @param name		The name to be associated with the object
 * @param objPtr	An object reference
 */
void AWSNames::reregisterObject(const char *name, CORBA::Object_ptr objPtr)
{
	/*
	 * Unbind the name, and ignore a "not found" error
	 */
	try
	{
		unregisterObject( name );
	}
	catch(NamesException& )
	{
		// Name is not currently registered.  Continue.
	}
	catch(...)
	{
		throw;
	}


	/*
	 * Now try to bind it to the given object.
	 */
	try
	{
		registerObject(name, objPtr);
	}
	catch(...)
	{
		throw;
	}
}

/**
 * Resolves the given name in the Naming Service and
 * returns a reference to the associate object.  The
 * name can be either absolute or relative.
 *
 * @param name	The name to be resolved.
 *
 * @returns	A reference to the object associated with
 *			the given name.
 */
CORBA::Object_ptr AWSNames::getObject(const char *name)
{
	NamePath				np( name );

	CORBA::Object_ptr		objPtr;

	/*
	 * No object name given
	 */
	if (np.getElementCount() == 0)	
		throw NamesException( NamesException::INVALID_OBJECT_NAME );

	/*
	 * Resolve the object name.
	 */
	try
	{
		objPtr = _resolve( np );

	}
	catch (CosNaming::NamingContext::NotFound& ) 
	{
		throw NamesException( NamesException::OBJECT_NOT_FOUND );
	}
	catch (CosNaming::NamingContext::InvalidName& ) 
	{
		throw NamesException( NamesException::INVALID_OBJECT_NAME );
	}
	catch (CORBA::INV_OBJREF ) 
	{
		throw NamesException( NamesException::INVALID_OBJECT_REFERENCE );
	}
	catch (CORBA::SystemException& sysEx) 
	{
		throw NamesException( NamesException::CORBA_SYSTEM );
	}
	catch (...) 
	{
		throw NamesException( NamesException::UNKNOWN );
	}


	if (! objPtr )
		throw NamesException( NamesException::INVALID_OBJECT_REFERENCE );


	return objPtr;
}

/**
 * Returns a reference to this objects current context.
 *
 * @returns The current context.
 */
CosNaming::NamingContext_ptr AWSNames::getContext( )
{
	return CosNaming::NamingContext::_duplicate( m_currentContext );
}

/**
 * Returns a reference to the orb associated with this
 * AWSNames object.
 *
 * @returns	A reference to the orb.
 */
CORBA::ORB_ptr AWSNames::getORB( )
{
	return CORBA::ORB::_duplicate( m_orb );
}

/**
 * Creates and returns an iterator object which can be used
 * to list the contents of the current context.
 *
 * @returns	An iterator object.
 */
NamesIterator* AWSNames::elements( )
{
	return new NamesIterator( m_currentContext );
}

/**
 * Returns a reference to the object referenced by the given NamePath.
 *
 * @param np	The path and name of the object.
 *
 * @return A pointer to the named object.
 */
CORBA::Object_ptr AWSNames:: _resolve(NamePath& np) 
{
	CORBA::Object_ptr		objPtr;
 	CosNaming::Name_var		thisName;
		
	thisName = np.getCosName( m_currentPath );

	/* 
	 * If an empty name path was given, then return a reference
	 * to the root context, otherwise, try to resolve the name.
	 */
	if (thisName->length() == 0)
	{
		objPtr = (CORBA::Object_ptr) CosNaming::NamingContext::_duplicate(m_rootContext);
	}
	else
	{
		try 
		{
			objPtr = m_rootContext->resolve(thisName);
		}
		catch (...) 
		{
			throw;
		}
	}

	return objPtr;
}

/**
 * Creates and binds a new context to the given name string.
 * 
 * @param path		A sequence of names delineated by the separator
 *					character.
 */
void AWSNames::createContext(const char *path)
{
	NamePath		np( path );

	try
	{
		createContext( np );
	}
	catch(...)
	{
		throw;
	}
}

/**
 * Creates and binds a new context to the given NamePath.
 * 
 * @param np		The path and name of the new context.
 */
void AWSNames::createContext(NamePath& np)
{
	if (np.getElementCount() == 0)	return;


	CosNaming::Name_var		thisName;

	thisName = np.getCosName( m_currentPath );

	try 
	{
		m_rootContext->bind_new_context(thisName);
	}
	catch (...)
	{
		throw;
	}
}

/*********************************************************************/

/**
 * Constructs an iterator associated with the given naming context.
 *
 * @param nc	The Naming Context to which the iterator is to be
 *				associated.
 */
NamesIterator::NamesIterator(CosNaming::NamingContext_ptr nc)
{
	m_context = CosNaming::NamingContext::_duplicate(nc);

	m_batchSize	= 50;

	// Initialize the bind iterator
	m_context->list(m_batchSize, m_bindList.out(), m_bindIterator.out());

	m_nextItem = 0;

	m_isEndOfList = (m_bindList->length() == 0);
}

/**
 * Destroy the bind iterator.
 */
NamesIterator::~NamesIterator( )
{
	if (m_bindIterator != NULL)
		m_bindIterator->destroy();
}

/**
 * Used to determine if the iterator has more elements
 * which can be returned.
 *
 * @returns True if there are more elements in the iterator
 *			False otherwise.
 */
CORBA::Boolean NamesIterator::hasMoreElements( )
{
	return ! m_isEndOfList;
}

/**
 * Gets the next element in the iterator.
 *
 * @returns A description of the next element.
 *
 * @raises NoMoreElements There are no more elements to be returned.
 */
NamesDescription& NamesIterator::nextElement( )
{
	if (m_isEndOfList)
		throw NoMoreElements( );

	/*
	 * Determine the element type
	 */
	if (m_bindList[m_nextItem].binding_type==CosNaming::nobject) 
		namesDesc.type = NamesObject;

	else if (m_bindList[m_nextItem].binding_type==CosNaming::ncontext) 
		namesDesc.type = NamesContext;

	else 
		namesDesc.type = NamesUnknown;


	/*
	 * Set the element name and kind
	 */
	namesDesc.name = m_bindList[m_nextItem].binding_name[0].id;
	namesDesc.kind = m_bindList[m_nextItem].binding_name[0].kind;


	/*
	 * Advance index to the next item.  If at the end of the current
	 * batch of elements, retrieve another batch.
	 */
	m_nextItem ++;

	if (m_nextItem >= m_bindList->length())
	{
		m_isEndOfList = 1;  // Assume at the end of the list

		// If the iterator is null, then there are no more elements
		if ( m_bindIterator != NULL ) 
		{
			// Get the next batch
			if (m_bindIterator->next_n(m_batchSize, m_bindList.out()))
			{
				m_nextItem = 0;

				// Update the end of list flag
				m_isEndOfList = (m_bindList->length() == 0);
			}
		}
	}

	return namesDesc;
}


/*********************************************************************/

/**
 * Constructs an NamePath from the given path string.  The path
 * is decomposed into a sequence of name elements, where each
 * element is delineated by the SEPARATOR character.  Each element
 * is stored in a CosNaming::Name component.
 * 
 * @param path		A sequence of names delineated by the separator
 *					character.
 */
NamePath::NamePath(const char *path)
{
	StringTokenizer		st(path, SEPARATOR);


	/*
	 * Determine if this is a relative or absolute path specification
	 */
	const char *p;
	for (p = path; isspace(*p); p++);

	m_isAbsolute = (*p == SEPARATOR ? 1 : 0);


	CORBA::ULong	nameLength	= 0;

	m_name		= new CosNaming::Name( nameLength );

	while ( st.hasMoreElements() )
	{
		const char *	nextToken = st.nextElement();

		/*
		 * Do not allow empty path elements
		 */
		if (strlen(nextToken) > 0)
		{
			/*
			 * Strip any '.' path elements
			 */
			if (strcmp(nextToken, ".") != 0)
			{
				m_name->length(nameLength+1);

				m_name[nameLength].id   = CORBA::string_dup(nextToken);
				m_name[nameLength].kind = CORBA::string_dup("");

				nameLength ++;
			}
		}
	}
}

/** 
 * Constructs an NamePath from an existing NamePath.
 * The new object will contain only the first 'elementCount'
 * components from the existing object.
 *
 * @param np			An existing NamePath object.
 * @param elementCount	Number of elements to be copied.
 */
NamePath::NamePath(NamePath& np, int elementCount)
{
	m_isAbsolute = np.isAbsolute( );

	/*
	 * The elementCount must be greater than 0 and
	 * less than or equal to the number of elements
	 * in the given NameTreePath.
	 */
	CORBA::ULong	nameLength;

	if ( (elementCount < 0)	|| (elementCount > np.getElementCount( )) )
		nameLength = np.getElementCount( );

	else
		nameLength = elementCount;


	m_name		= new CosNaming::Name( nameLength );

	m_name->length( nameLength );

	for(CORBA::ULong i = 0; i < nameLength; i ++)
	{
		m_name[i].id   = CORBA::string_dup(np.getElementName(i));
		m_name[i].kind = CORBA::string_dup(np.getElementKind(i));
	}
}

/** 
 * Constructs an NamePath from two existing NamePaths.
 * The root NamePath will be used only if the other NamePath
 * is relative.
 *
 * @param np			An existing NamePath object.
 * @param rootPath		The root path used if np is relative.
 */
NamePath::NamePath(NamePath& np, NamePath& rootPath)
{
	/*
	 * The resulting NamePath will be absolute if either of
	 * the input NamePaths are absolute 
	 */
	m_isAbsolute = (np.isAbsolute( ) || rootPath.isAbsolute( ));


	CORBA::ULong		nameLength;
	const char			*elementName;
	CORBA::ULong		i;

	nameLength	= 0;
	m_name		= new CosNaming::Name( nameLength );

	m_name->length( nameLength );

	/*
	 * Use the root NamePath only if the other NamePath is relative.
	 */
	if ( !np.isAbsolute( ) )
	{
		for(i = 0; i < rootPath.getElementCount( ); i ++)
		{
			elementName = rootPath.getElementName(i);

			if ( strcmp( elementName, ".." ) == 0 )
			{
				if (nameLength > 0)
				{
					nameLength --;
					m_name->length( nameLength );
				}
			}
			else
			{
				m_name->length( nameLength+1 );

				m_name[nameLength].id   = CORBA::string_dup( rootPath.getElementName(i) );
				m_name[nameLength].kind = CORBA::string_dup( rootPath.getElementKind(i) );

				nameLength ++;
			}
		}
	}

	for(i = 0; i < np.getElementCount( ); i ++)
	{
		elementName = np.getElementName(i);

		if ( strcmp( elementName, ".." ) == 0 )
		{
			if (nameLength > 0)
			{
				nameLength --;
				m_name->length( nameLength );
			}
		}
		else
		{
			m_name->length( nameLength+1 );

			m_name[nameLength].id   = CORBA::string_dup( np.getElementName(i) );
			m_name[nameLength].kind = CORBA::string_dup( np.getElementKind(i) );

			nameLength ++;
		}
	}
}

/**
 * Destructor.
 */
NamePath::~NamePath()
{
}

/**
 * Sets the 'kind' field for the last component of the 
 * NamePath object.
 *
 * @param kind		The value of the kind field to be set.
 */
void NamePath::setKind(const char *kind)
{
	CORBA::ULong	elementIndex = getElementCount() - 1;

	if (elementIndex < 0)	return;

	CORBA::string_free( m_name[elementIndex].kind );

	m_name[elementIndex].kind = CORBA::string_dup( kind );
}

/**
 * Gets the name of the component identified by the given index.
 *
 * @param elementIndex		The index of the name to be returned.
 *
 * @return The name of the specified component.
 */
const char *NamePath::getElementName(CORBA::ULong elementIndex)
{
	if ((elementIndex < 0) || (elementIndex > getElementCount()))
		return NULL;

	return m_name[elementIndex].id;
}

/**
 * Gets the kind of the component identified by the given index.
 *
 * @param elementIndex		The index of the kind to be returned.
 *
 * @return The kind of the specified component.
 */
const char *NamePath::getElementKind(CORBA::ULong elementIndex)
{
	if ((elementIndex < 0) || (elementIndex > getElementCount()))
		return NULL;

	return m_name[elementIndex].kind;
}

/**
 * Returns the value of the 'absolute' flag.
 *
 * @return True if the path is absolute, False otherwise.
 */
int	NamePath::isAbsolute( )
{
	return m_isAbsolute;
}

/**
 * Gets the number of name components in the object.
 *
 * @return The number of components.
 */
CORBA::ULong NamePath::getElementCount( )
{
	CORBA::ULong		nameLength = m_name->length( );

	return nameLength;
}

/**
 * Returns a pointer to a CosNaming::Name object which
 * represents the current NamePath object relative to
 * the given NamePath object.
 *
 * @param np	The NamePath object to be used as the root 
 *				for the current NamePath object if needed.
 *
 * @return		A CosNaming::Name object.
 */
CosNaming::Name_ptr NamePath::getCosName(NamePath *np)
{
	CosNaming::Name_var		cosName;
	CORBA::ULong			nameLength;

	const char				*elementName;
	CORBA::ULong			i;


	nameLength	= 0;
	cosName		= new CosNaming::Name( nameLength );

	/*
	 * If this NamePath is relative, copy the path elements
	 * from the given NamePath argument.
	 */
	if (!isAbsolute( ) && np != NULL)
	{
		for(i = 0; i < np->getElementCount( ); i ++)
		{
			elementName = np->getElementName(i);

			if ( strcmp( elementName, ".." ) == 0 )
			{
				if (nameLength > 0)
				{
					nameLength --;
					cosName->length( nameLength );
				}
			}
			else
			{
				cosName->length( nameLength+1 );

				cosName[nameLength].id   = CORBA::string_dup( np->getElementName(i) );
				cosName[nameLength].kind = CORBA::string_dup( np->getElementKind(i) );

				nameLength ++;
			}
		}
	}

	/*
	 * Append the path elements from the current object.
	 */
	for(i = 0; i < m_name->length( ); i ++)
	{
		elementName = m_name[i].id;

		if ( strcmp( elementName, ".." ) == 0 )
		{
			if (nameLength > 0)
			{
				nameLength --;
				cosName->length( nameLength );
			}
		}
		else
		{
			cosName->length( nameLength+1 );

			cosName[nameLength].id   = CORBA::string_dup( m_name[i].id );
			cosName[nameLength].kind = CORBA::string_dup( m_name[i].kind );

			nameLength ++;
		}
	}

	return new CosNaming::Name( cosName );
}

