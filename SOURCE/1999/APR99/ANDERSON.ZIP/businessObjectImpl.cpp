#include "businessObjectImpl.h"

businessObjectImpl::businessObjectImpl(char *objName) 
	: _sk_businessObject( objName )
{
	m_objName = CORBA::string_dup(objName);
}

businessObjectImpl::~businessObjectImpl()
{
}

char * businessObjectImpl::getName()
{
	cout << m_objName << endl;

	return CORBA::string_dup(m_objName);
}

