#ifndef AWSServer_h
#define AWSServer_h

#include <corba.h>

#include "AWSServer_c.hh"
#include "AWSLoadBalancing.h"


/**
 * Forward references
 */
class SrvObjectIterator;


/**
 * The AWSServer class encapsulates the operations
 * necessary to create and manage a CORBA server.
 * These operations include binding and unbinding
 * objects names from the Naming Service, making
 * objects available to client processes, and
 * distributing client load across multiple server
 * processes (through the use of the LoadBalancing 
 * class).
 */
class AWSServer
{
private:
	static AWSServer		*m_serverInstance;

	CORBA::ORB_var			m_orb;
	CORBA::BOA_var			m_boa;

	CORBA::String_var		m_serverName;
	AWSLoadBalancing		*m_loadBalancing;

	CORBA::Boolean			m_bindObjects;
	CORBA::Boolean			m_unbindObjects;
	CORBA::Boolean			m_runServer;

	ObjectSeq				m_objectList;
	VISMutex				m_objectListMtx;

	void append(CORBA::Object_ptr, const char *objName = NULL);
	void remove(CORBA::Object_ptr);

protected:
	AWSServer(	int &, char **, const char *, 
				AWSLoadBalancing * lb = NULL);

public:
	static AWSServer* instance( );
	static AWSServer* instance(	int &, char **, const char *, 
								AWSLoadBalancing * lb = NULL );

	virtual ~AWSServer( );


	/**
	 * Adds an object to the server's list of managed objects.
	 */
	void addObject(CORBA::Object_ptr obj, const char* objName=NULL);

	/**
	 * Removes an object from the server's list of managed objects.
	 */
	void removeObject(CORBA::Object_ptr obj);

	/**
	 * Executes the server's main event loop and begins
	 * to process client requests.
	 */
	void run( );
};


/**
 * The AWSServerException class defines the only exception 
 * which is raised by an AWSServer object.
 */
class AWSServerException : public CORBA::UserException 
{
public:
	/**
	 * Defines all possible exception reasons.
	 */
	enum ExceptionReason 
	{
		LOAD_BALANCING_INIT_FAILED,
		SYSTEM_EXCEPTION,
		UNKNOWN
	};

private:
	ExceptionReason		m_reason;

public:
	/**
	 * Constructs a AWSServerException with the given reason code.
	 *
	 * @param reason	Describes the exception
	 */
	AWSServerException(ExceptionReason reason)
	{
		m_reason = reason;
	}

	/**
	 * Gets the exception reason.
	 *
	 * @return The value of the exception reason field.
	 */
	ExceptionReason getReason( )
	{
		return m_reason;
	}
};


#endif


