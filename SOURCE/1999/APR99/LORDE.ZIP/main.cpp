#include <TokenIter.h>
#include <WordIter.h>
#include <iostream>
#include <vector>
#include <algorithm>

using std::string;
using std::vector;
using std::copy;
using std::sort;
using std::for_each;
using std::count;
using std::min_element;
using std::cout;
using std::cin;
using std::endl;

void PrintString(const string& str)
{
        cout << '\"' << str << '\"' << endl;
}

void TokenIterTest()
{
        cout << "Testing the Token Iterator:" << endl << endl;

        string test1 = "A test#@of the#@token iterator#@"
                "template class.#@This#@token iterator#@test "
                "should use#@a token#@several times#@for the#@token count";
        
        // Explicit use.

        typedef TokenIter<TokenFinder> TkIter;

        TkIter ti(test1, TokenFinder("#@"));
        while (ti != TkIter())
        {
                PrintString(*ti);
                ++ti;
        }

        cin.get();
        cout << endl << "Using STL algorithms:" << endl;

        ti = test1;
        for_each(ti, TkIter(), PrintString);

        cin.get();

        cout << endl << "Minimum element:" << endl;
        TkIter pMinToken = min_element(ti, TkIter());
        PrintString(*pMinToken);

        string cntStr("token iterator");
        cout << endl << "There are " 
                 << count(ti, TkIter::EOS, string("token iterator")) 
                 << " occurrences of \"" << cntStr << '\"' << endl;


        cin.get();

        cout << endl << "Caching to a vector for better access:" << endl;
        ti = test1;
        vector<string> tokens;
        copy(ti, TkIter(test1.end()), std::back_inserter(tokens));

        for_each(tokens.begin(), tokens.end(), PrintString);

        cout << endl << endl;
}

void WordIterTest()
{
        cout << "Testing the Word Iterator" << endl;

        string test1 = "This is a test of the word iterator."
                "It should use a word several times  for the word count";
        
        // Explicit use.

        WordIter wi(test1);

        while (wi != WordIter())
        {
                PrintString(*wi);
                ++wi;
        }

        cin.get();
        cout << endl << "Using STL algorithms:" << endl;

        wi = test1;
        for_each(wi, WordIter(), PrintString());

        cin.get();

        cout << endl << "Minimum element:" << endl;

        WordIter pMinToken = min_element(wi, WordIter());
        PrintString(*pMinToken);

        string cntStr("word");
        cout << endl << "There are " 
                 << count(wi, WordIter::EOS, cntStr)
                 << " occurrences of \"" << cntStr << '\"' << endl;

        cin.get();

        cout << endl << "Caching to a vector for better access:" << endl;

        wi = test1;
        vector<string> sentence;
        copy(wi, WordIter(test1.end()), std::back_inserter(sentence));

        for_each(sentence.begin(), sentence.end(), PrintString);

        cout << endl << endl;
}

int main(int argc, char* argv[])
{
        TokenIterTest();
        WordIterTest();
        cin.get();
        return(0);
}

/* End of File */
