#ifndef TOKENFINDER_H
#define TOKENFINDER_H

//***************************************************************************
//
// TokenFinder class header.
//
// TokenFinder is a function object type that finds a token in a string, given 
// a delimiting string. It sets the start pointer to the beginning of the token,
// and the end pointer to one character past the end of the token.
//
//***************************************************************************

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string> 

class TokenFinder
{
public:
        TokenFinder() {}                // Default ctor - delimiter is end-of-string
        TokenFinder(const char* delim) : delimiter(delim) {}

        int operator()(const char*& start, const char*& end)
        {
                // end initially points to beginning of string
                char* dPos = 0;

                if (!delimiter.empty())
                {
                        // Skip leading delimiters to start of token 
                        dPos = strstr(end, delimiter.c_str());

                        while (dPos == end)
                        {
                                end += delimiter.size();
                                dPos = strstr(end, delimiter.c_str());
                        }
                }

                start = end;            // start of token found

                // Set end to just past end of token
                end = (dPos) ? dPos : end + strlen(start);

                // Return token length
                return (end - start);
        }

private:
        std::string delimiter;
};

#endif // #ifndef TOKENFINDER_H


/* End of File */
