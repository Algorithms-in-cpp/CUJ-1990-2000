#ifndef WORDITER_H
#define WORDITER_H
//****************************************************************************
//
// WordIter header.
//
// WordIter is a type definition that provides a word 
// iterator over a string.
//
// It is a specialisation of TokenIter, using WordFinder 
// to find the tokens.
// 
// WordFinder is a function object that finds a word token
// in a string, using white space as the token delimiter.
//
//*****************************************************************************

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TokenIter.h"

class WordFinder
{
public:
        typedef TokenIter<WordFinder> WIter;

        size_t operator()(const char*& start, const char*& end)
        {
                // Note: end initially points to beginning of string,
                // start is undefined

                // Skip whitespace up to next word

                while (isspace(*end))
                        ++end;

                start = end;

                // Skip non-whitespace to end of word

                while(*end != WIter::EndOfString && !isspace(*end))
                        ++end;

                return (end - start);
        }
};

// Define WordIter

typedef TokenIter<WordFinder>  WordIter;

#endif

/* End of File */
