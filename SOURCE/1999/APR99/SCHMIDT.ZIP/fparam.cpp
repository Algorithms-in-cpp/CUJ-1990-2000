class heat
    {
public:
    float sr(float);
    static float sr1(float);
    //
    //  #1
    static float func1(float k)
        {
        return (k + sr1(3.0));
        }
    //
    //  #2
    float func(float k)
        {
        return (k + sr(3.0));
        }
    //
    //  #3
    float 
    func(float (*fx)(float), float k)
        {
        return (k + fx(3.0));
        }
    //
    //  #4
    float 
    func(float (heat::*fx)(float), float k)
        {
        return (k + ((*this).*fx)(3.0));
        }
    //
    //  #5
    float 
    func(heat &that, float (heat::*fx)(float), 
        float k)
        {
        return (k + (that.*fx)(3.0));
        }
    };
     
int main()
    {
    heat obj;
    heat::func1(5.1);              // #1 
    obj.func(5.1);                 // #2 
    obj.func(heat::sr1, 5.1);      // #3 
    obj.func(&heat::sr, 5.1);      // #4 
    obj.func(obj, &heat::sr, 5.1); // #5 
    }

