// MortOutput.cpp
// Output Routines for CReport for Mortgage Amortization Schedule

#include "stdafx.h"
#include "MortCalc.h"
#include "MortCalcDlg.h"
#include "CLoanCalc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Define static class members

int CMortCalcDlg::month(1);
int CMortCalcDlg::year(1);

void CMortCalcDlg::vTitleLine(ostream &stream,void *data,int page_num)
{
	char temp[255];
	CLoanCalc *aLoan = (CLoanCalc *)data;

	
	sprintf(temp,"For a Loan of $ %.0f for %d Years at a Rate of %.2f and Payment of %.2f",
		aLoan->GetOrigAmount(),aLoan->GetNumYears(),aLoan->GetCurrentRate()*100,aLoan->GetPayment() );
	
	// end the table from the previous page
	stream << "</TABLE>" << endl;
	
	// Output the Page Header
	stream << "<H5 align=center> Page Number " << page_num << "</H3>" << endl;
	stream << "<H4 align=center> Amortization Schedule" << "</H2>" << endl;

	// Output the headers for this page's table

	stream << "<H4 align=center>" << temp <<  "</H2>" << endl;
	stream << "<TABLE border align=center cellspacing=4>" << endl;
	stream << "<TR align =right>" << endl;
	stream <<"<TH>" << "Payment" << "</TH>" << endl;
	stream << "<TH>" << "Principal" << "</TH>" << endl;
	stream << "<TH>" << "Interest" << "</TH>" << endl;
	stream << "<TH>" << "Amount Remaining" << "</TH>" << endl;
	stream << "</TR>" << endl;
}

void CMortCalcDlg::vPaymentLine(ostream &stream, void *data)
{
	LoanPayment *payment = (LoanPayment *)data;

	stream << "<TR align=right>" << endl;

	stream <<"<TD>" << "Year " << year << " Month " << month << "</TD>" <<endl;
	stream << "<TD>" << payment->dPrincipal << "</TD>" << endl;
	stream << "<TD>" << payment->dInterest << "</TD>" << endl;
	stream << "<TD>" << payment->dAmountRemaining << "</TD>" << endl;
	stream << "</TR>" << endl;
	month++;

	// Use static class members to keep track of the current month
	// and year.
	if (month == 12)
	{
		month = 1;
		year++;
	}

}

void CMortCalcDlg::vTotalLine(ostream &stream, void *data)
{
	CMortTotal *total = (CMortTotal *)data;

	stream << "<TR align=right>" << endl;
	stream <<"<TH>" << total->GetPaymentInfo() << "</TH>" <<endl;
	stream << "<TH>" << total->GetTotalPrincipal() << "</TH>" << endl;
	stream << "<TH>" << total->GetTotalInterest() << "</TH>" << endl;
	stream << "<TH>" << "" << "</TH>" << endl;
	stream << "</TR>" << endl;
}

void CMortCalcDlg::vFooterLine(ostream &stream, void *data, int page_num)
{
	// There is no Footer for this report
}
