// MortCalcDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MortCalc.h"
#include "MortCalcDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMortCalcDlg dialog

CMortCalcDlg::CMortCalcDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMortCalcDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMortCalcDlg)
	m_nLoanType = -1;
	m_dLoanAmount = 0.0;
	m_dRate = 0.0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMortCalcDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMortCalcDlg)
	DDX_Control(pDX, IDC_PRINT_BUTTON, m_cPrintButton);
	DDX_Control(pDX, IDC_LOAN_EDIT, m_cLoanEdit);
	DDX_Control(pDX, IDC_RATE_EDIT, m_cRateEdit);
	DDX_Radio(pDX, IDC_30_RADIO, m_nLoanType);
	DDX_Control(pDX, IDC_AMORT_EXPLORER, m_cWebBrowser);
	DDX_Text(pDX, IDC_LOAN_EDIT, m_dLoanAmount);
	DDX_Text(pDX, IDC_RATE_EDIT, m_dRate);
	DDV_MinMaxDouble(pDX, m_dRate, 0., 100.);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMortCalcDlg, CDialog)
	//{{AFX_MSG_MAP(CMortCalcDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_PRINT_BUTTON, OnPrintButton)
	ON_BN_CLICKED(IDOK, OnCalculate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMortCalcDlg message handlers

BOOL CMortCalcDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	m_nLoanType = 0;
	UpdateData(FALSE);

	m_cPrintButton.EnableWindow(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMortCalcDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMortCalcDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMortCalcDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMortCalcDlg::OnPrintButton() 
{
	// TODO: Add your control notification handler code here

	// This code sends the print message to the browser via COM
	LPDISPATCH lpDispatch = NULL;
	LPOLECOMMANDTARGET lpOleCommandTarget = NULL;
	lpDispatch = m_cWebBrowser.GetDocument();
	ASSERT(lpDispatch);

	lpDispatch->QueryInterface(IID_IOleCommandTarget,(void **)&lpOleCommandTarget);
	ASSERT(lpOleCommandTarget);

	lpDispatch->Release();

	lpOleCommandTarget->Exec(NULL,OLECMDID_PRINT,0,NULL,NULL);
	lpOleCommandTarget->Release();
}

void CMortCalcDlg::OnCalculate() 
{
	// TODO: Add your control notification handler code here
	
	// Get the current state of the radio buttons and edit controls
	UpdateData(TRUE);

	m_cPrintButton.EnableWindow(FALSE);
	month = 1;
	year = 1;
	m_dRate /= 100.0;

	// Set a member variable to tbe number of years of the loan
	if (m_nLoanType == 0)
		NumYears = 30;
	else
		NumYears = 15;

	// Create the output in a file
	if (CreateHtmlOutput())
	{
		// If creating the output file is successful load the file 
		// into the web browser
		COleVariant noArg;
		m_cWebBrowser.Navigate("file:\\\\c:\\Temp\\LoanOutput.htm",&noArg,
		&noArg,&noArg,&noArg);
	}

	
}

int CMortCalcDlg::CreateHtmlOutput()
{

	// Create the Loan with the parameters

	CLoanCalc *aLoan = new CLoanCalc(m_dRate,NumYears,12,m_dLoanAmount);

	// Create the loan schedule
	aLoan->CalcSchedule();

	// Get a pointer to the linked list
	LoanPayment *schedule = aLoan->GetSchedule();

	char filename[255];
	char temp[255];

	// Create structures for the totals
	CMortTotal *totalYear = new CMortTotal;
	CMortTotal *totalLoan = new CMortTotal;
	int CurrentPayment = 1;
	int CurrentYear = 1;

	sprintf(filename,"c:\\temp\\LoanOutput.htm");

	// Open up an output file for the html report

	ofstream fout(filename);

	if (!fout)
	{
		AfxMessageBox("Cannot create output file in C:\\TEMP",MB_OK|MB_ICONERROR);
		delete aLoan;
		delete totalYear;
		delete totalLoan;
		return 0;
	}

	fout.setf(ios::fixed);

	CReport MortReport(CMortCalcDlg::vTitleLine,3,
		CMortCalcDlg::vFooterLine,0,&fout,44);


	fout << "<HTML>" << endl;
	
	// Use a CSS Style Sheet to control the font of the table.

	fout << "<HEAD><STYLE> " << endl;
	fout << " TH,TD { font-size: 10pt;font-family: \"MS SANS Serif\"} " << endl;
	fout << "</STYLE> " << endl;
	fout << "</HEAD>" << endl;

	fout << "<BODY>" << endl;

	// Loop until the last one

	while (schedule->next != NULL)
	{
		
		// print the payment
		MortReport.vPrintLine(CMortCalcDlg::vPaymentLine,1,(void *)aLoan,
			(void *)schedule,(void *)NULL);

		// add this payment to the totals

		totalLoan->AddToTotal(schedule);
		totalYear->AddToTotal(schedule);
	
		if (CurrentPayment%12 == 0)
		{
			// this is the end of a year, print the total, clear the total
			// and increment the year

			sprintf(temp,"Total for Year %d",CurrentYear);
			totalYear->SetPaymentInfo(temp);
			MortReport.vPrintLine(CMortCalcDlg::vTotalLine,2,(void *)aLoan,
				(void *)totalYear,(void *)NULL);
			totalYear->Clear();
			CurrentYear++;
		}

		CurrentPayment++;
		schedule = schedule->next;
	}
	// print the final payment 
	MortReport.vPrintLine(CMortCalcDlg::vPaymentLine,1,(void *)aLoan,
		(void *)schedule,(void *)NULL);

	sprintf(temp,"Total for Year %d",CurrentYear);
	totalYear->SetPaymentInfo(temp);
	MortReport.vPrintLine(CMortCalcDlg::vTotalLine,2,(void *)aLoan,
		(void *)totalYear,(void *)NULL);
	
	// print the last year total
	totalLoan->AddToTotal(schedule);
	totalYear->AddToTotal(schedule);
	strcpy(temp,"Total for Loan");
	totalLoan->SetPaymentInfo(temp);

	// print the grand loan totals
	MortReport.vPrintLine(CMortCalcDlg::vTotalLine,2,(void *)aLoan,
		(void *)totalLoan,(void *)NULL);

	fout << "</TABLE></BODY></HTML>" << endl;
	fout << flush;

	delete aLoan;
	delete totalYear;
	delete totalLoan;
	return 1;

}

BEGIN_EVENTSINK_MAP(CMortCalcDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CMortCalcDlg)
	ON_EVENT(CMortCalcDlg, IDC_AMORT_EXPLORER, 259 /* DocumentComplete */, OnDocumentCompleteAmortExplorer, VTS_DISPATCH VTS_PVARIANT)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CMortCalcDlg::OnDocumentCompleteAmortExplorer(LPDISPATCH pDisp, VARIANT FAR* URL) 
{
	// This event is called when the docuement is completely
	// loaded into the WebBrowser.  Allow the user to use the print button.
	m_cPrintButton.EnableWindow(TRUE);
}
