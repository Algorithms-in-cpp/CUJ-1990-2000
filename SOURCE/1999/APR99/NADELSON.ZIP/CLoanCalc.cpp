
#include "stdafx.h"
#include "CLoanCalc.h"
#include <string.h>
#include <iostream.h>
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CLoanCalc::CLoanCalc(double current_rate,int num_years, int num_periods,
		double amount)

{
	dCurrentRate = current_rate;
	iNumYears = num_years;
	iNumPeriods = num_periods;
	dAmount = amount;
	pSchedule = NULL;
	dOrigAmount = amount;
}

CLoanCalc::~CLoanCalc()
{
	while (pSchedule != NULL)
	{
		LoanPayment *tempSched = pSchedule;
		pSchedule = pSchedule->next;
		delete tempSched;
	}
}

void CLoanCalc::CalcPayment()
{
	int iNumPayments = iNumYears*iNumPeriods;
	double dFactor = 0;

	for (int iPayment = 1; iPayment <= iNumPayments; iPayment++)
	{
		dFactor = dFactor + (1.0/pow(1.0 + (dCurrentRate)/
			(double)iNumPeriods,(double)iPayment));
	}
	dPayment = dAmount/dFactor;
}

void CLoanCalc::CalcSchedule()
{
	int iNumPayments = iNumYears*iNumPeriods;
	LoanPayment *newPayment;
	LoanPayment *currentPayment;

	CalcPayment();
	for (int iPayment = 1; iPayment <= iNumPayments; iPayment++)
	{
		newPayment = new LoanPayment;
		newPayment->iPeriod = iPayment;
		
		dPayment = GetPayment();
		newPayment->dPayment = dPayment;
		newPayment->dInterest = dAmount *(dCurrentRate/(double)iNumPeriods);
		newPayment->dPrincipal = dPayment - newPayment->dInterest;
		newPayment->dAmountRemaining = dAmount - newPayment->dPrincipal;
		dAmount = newPayment->dAmountRemaining;

		if (pSchedule == NULL)
		{
			pSchedule = newPayment;
			currentPayment = newPayment;
			currentPayment->next = NULL;
		}
		else
		{
			currentPayment->next = newPayment;
			currentPayment = currentPayment->next;
			currentPayment->next = NULL;
		}
	}
}
