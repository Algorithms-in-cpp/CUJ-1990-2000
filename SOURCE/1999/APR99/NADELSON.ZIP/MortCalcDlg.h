// MortCalcDlg.h : header file
//
//{{AFX_INCLUDES()
#include "webbrowser2.h"
//}}AFX_INCLUDES

#if !defined(AFX_MORTCALCDLG_H__BABA1AC8_9507_11D2_B1CE_00A0C923FE30__INCLUDED_)
#define AFX_MORTCALCDLG_H__BABA1AC8_9507_11D2_B1CE_00A0C923FE30__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "CReport.h"
#include "CLoanCalc.h"
#include <afxcoll.h>
#include <docobj.h>
#include <winspool.h>
/////////////////////////////////////////////////////////////////////////////
// CMortCalcDlg dialog


class CMortTotal
{
	double dTotalPrincipal;
	double dTotalInterest;
	char cPaymentInfo[512];

public:

	CMortTotal()
	{
		Clear();
	}

	void AddToTotal(LoanPayment *payment)
	{
		dTotalPrincipal += payment->dPrincipal;
		dTotalInterest += payment->dInterest;
	}
	void Clear()
	{
		dTotalPrincipal = 0.0;
		dTotalInterest = 0.0;
	}
	double GetTotalPrincipal()
	{
		return dTotalPrincipal;
	}
	double GetTotalInterest()
	{
		return dTotalInterest;
	}

	char *GetPaymentInfo()
	{
		return cPaymentInfo;
	}
	void SetPaymentInfo(char *text)
	{
		strcpy(cPaymentInfo,text);
	}


};

class CMortCalcDlg : public CDialog
{
// Construction
public:
	CMortCalcDlg(CWnd* pParent = NULL);	// standard constructor
	static void vTitleLine(ostream &stream,void *data,int page_num);
	static void vFooterLine(ostream &stream,void *data,int page_num);
	static void vPaymentLine(ostream &stream, void *data);
	static void vTotalLine(ostream &stream, void *data);
	

// Dialog Data
	//{{AFX_DATA(CMortCalcDlg)
	enum { IDD = IDD_MORTCALC_DIALOG };
	CButton	m_cPrintButton;
	CEdit	m_cLoanEdit;
	CEdit	m_cRateEdit;
	int		m_nLoanType;
	CWebBrowser2	m_cWebBrowser;
	double	m_dLoanAmount;
	double	m_dRate;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMortCalcDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMortCalcDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPrintButton();
	afx_msg void OnCalculate();
	afx_msg void OnDocumentCompleteAmortExplorer(LPDISPATCH pDisp, VARIANT FAR* URL);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int NumYears;
	int CreateHtmlOutput();
	static int year;
	static int month;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MORTCALCDLG_H__BABA1AC8_9507_11D2_B1CE_00A0C923FE30__INCLUDED_)
