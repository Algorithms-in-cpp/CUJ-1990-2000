// CLoanCalc.h : header file

#if !defined(_cloancalc_h)
#define _cloancalc_h


typedef struct LoanPayment
{
	int iPeriod;
	double dPayment;
	double dInterest;
	double dPrincipal;
	double dAmountRemaining;
	

	struct LoanPayment *next;
} LoanPayment;

class CLoanCalc
{
	double dCurrentRate;
	int iNumYears;
	int iNumPeriods;
	double dAmount;
	double dPayment;
	double dOrigAmount;

public:
	LoanPayment *pSchedule;

	CLoanCalc(double _current_rate,int _numyears, int numperiods,
		double amount);

	~CLoanCalc();

	void CalcPayment();
	void CalcSchedule();
	double GetPayment() 
	{
		return dPayment;
	}
	double GetCurrentRate()
	{
		return dCurrentRate;
	}
	int GetNumYears()
	{
		return iNumYears;
	}
	double GetAmount()
	{
		return dAmount;
	}
	LoanPayment *GetSchedule()
	{
		return pSchedule;
	}
	double GetOrigAmount()
	{
		return dOrigAmount;
	}


};

#endif