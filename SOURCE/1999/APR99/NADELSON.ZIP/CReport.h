#if !defined(_cReport_h)
#define _cReport_h

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Include file : CReport.h

#include <fstream.h>
#include <stdio.h>

class CReport
{
	int iLinesPerPage;
	int iLinesLeft;
	int iTitleLines;
	int iFooterLines;
	int iPageCount;
	// Function pointers for the title and footer functions
	void (*vTitlePrint)(ostream &,void *,int);
	void (*vFooterPrint)(ostream &,void *,int);
	// Data for the title and footer functions
	void *vTitleData;
	void *vFooterData;
	ostream *RepStream;
public:

	CReport(void _vTitlePrint(ostream &,void *,int), int _iTitleLines,
					void _vFooterPrint(ostream &,void *,int),int _iFooterLines,
					ostream *_RepStream,int _iLinesPerPage);
	void vPrintLine(void _vLinePrint(ostream &,void *),int _iLines,
		void *_vTitleData,void *_vData,void *_vFooterData);
	void vNewPage();
	void vPrintBlankLines(int _iLines);
	// vPrintFooter is overloaded to provide for the case where 
	// there is no data for the report.  It will print the title,
	// a NO DATA Message, and a blank footer
	void vPrintFooter();
	void vPrintFooter(void *_vTitleData, void *_vFooterData);

	// Used to reset the title length at runtime.
	// Used in the case that the title on one page is
	// different from another
	void vSetTitleLength(int _iLength)
	{
		iTitleLines = _iLength;
	}

	void vSetFooterLength(int _iLength)
	{
		iFooterLines = _iLength;
	}
	
	int get_iLinesLeft() 
	{ 
		return iLinesLeft; 
	}
	void set_iLinesLeft(int _iNum) 
	{ 
		iLinesLeft = _iNum; 
	}

	void set_PageCount(int _iNum)
	{
		iPageCount = _iNum;
	}
};


#endif // defined _creport_h