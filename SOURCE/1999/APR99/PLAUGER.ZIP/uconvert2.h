        // CLASS Fancier_codecvt
class Fancier_codecvt : public Mybase {
public:
    typedef wchar_t _E;
    typedef char _To;
    typedef mbstate_t _St;

    explicit Fancier_codecvt(size_t _R = 0)
        : Mybase(_R) {}

protected:
    virtual result do_in(_St& _State,
        const _To *_F1, const _To *_L1, const _To *& _Mid1,
        _E *_F2, _E *_L2, _E *& _Mid2) const
        {_Mid1 = _F1, _Mid2 = _F2;
        _St _Mystate = _State;
        result _Ans = ok;
        for (; ; )
            if (_Mid1 == _L1 || _Mid2 == _L2)
                break;
            else if (_Mid1 + 1 == _L1)
                {_Ans = partial;
                break; }
            else if (_Mystate == 0)
                {*_Mid2 = *_Mid1++ & 0xff;
                *_Mid2 |= *_Mid1++ << 8;
                if (*_Mid2 == 0xfffe)
                    _Ans = partial;
                else if (*_Mid2 == 0xfeff)
                    {_Ans = partial;
                    _Mystate = 1; }
                else
                    {++_Mid2;
                    _Ans = ok;
                    break; }}
            else
                {*_Mid2 = *_Mid1++ << 8;
                *_Mid2 |= *_Mid1++ & 0xff;
                if (*_Mid2 == 0xfffe)
                    _Ans = partial;
                else if (*_Mid2 == 0xfeff)
                    {_Ans = partial;
                    _Mystate = 0; }
                else
                    {++_Mid2;
                    _Ans = ok;
                    break; }}
        if (_Ans == partial)
            _Mid1 = _F1, _Mid2 = _F2;
        _State = _Mystate;
        return (_Ans); }

    virtual result do_out(_St& _State,
        const _E *_F1, const _E *_L1, const _E *& _Mid1,
        _To *_F2, _To *_L2, _To *& _Mid2) const
        {_Mid1 = _F1, _Mid2 = _F2;
        if (_Mid1 == _L1 || _Mid2 == _L2)
            return (ok);
        else if (_Mid2 + 1 == _L2)
            return (partial);
        else if (*_Mid1 == 0xfffe)
            {_State = 0;
            ++_Mid1;
            *_Mid2++ = 0xfe;
            *_Mid2++ = 0xff;
            return (ok); }
        else if (*_Mid1 == 0xfeff)
            {_State = 1;
            ++_Mid1;
            *_Mid2++ = 0xff;
            *_Mid2++ = 0xfe;
            return (ok); }
        else if (_State == 0)
            {*_Mid2++ = (unsigned char)*_Mid1;
            *_Mid2++ = (unsigned char)(*_Mid1++ >> 8);
            return (ok); }
        else
            {*_Mid2++ = (unsigned char)(*_Mid1 >> 8);
            *_Mid2++ = (unsigned char)*_Mid1++;
            return (ok); }}

    virtual result do_unshift(_St& _State,
        _To *_F2, _To *_L2, _To *& _Mid2) const
        {return (ok); }

    virtual int do_length(_St& _State, const _To *_F1,
        const _To *_L1, size_t _N2) const _THROW0()
        {return ((int)(_L1 - _F1) / 2); }

    virtual bool do_always_noconv() const _THROW0()
        {return (false); }

    virtual int do_max_length() const _THROW0()
        {return (2); }

    virtual int do_encoding() const _THROW0()
        {return (0); }
    };
