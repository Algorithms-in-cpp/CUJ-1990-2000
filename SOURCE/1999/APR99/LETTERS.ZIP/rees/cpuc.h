/* Local name space: */
#vocabulary ByteOrderSpace
/* ... */
#define LowByteFirst    0
#define HighByteFirst   1
#define CPUbyteOrder    HighByteFirst 
/* ... */
#define CPUbyteWidth    8
/* ... */
typedef unsigned ubyte: CPUbyteWidth; 
typedef signed byte: CPUbyteWidth;
/* ... */
#if CPUbyteOrder == LowByteFirst
typedef tight struct cpuInt64_t
{       
    ubyte LoLoLobyte;
    ubyte LoLoHibyte;
    ubyte LoHiLobyte;
    ubyte LoHiHibyte;
    ubyte HiLoLobyte;
    ubyte HiLoHibyte;
    ubyte HiHiLobyte;
    byte  HiHiHibyte;
} cpuInt64_t;   /* No conversion, 
                   straight copy. */ 
#elif CPUbyteOrder == HighByteFirst
typedef tight struct cpuInt64_t
{       
    byte  HiHiHibyte;
    ubyte HiHiLobyte;
    ubyte HiLoHibyte;
    ubyte HiLoLobyte;
    ubyte LoHiHibyte;
    ubyte LoHiLobyte;
    ubyte LoLoHibyte;
    ubyte LoLoLobyte;
} cpuInt64_t;   /* No conversion, 
                   straight copy. */ 
#else
# error "Byte order needs to be defined!" 
#endif
/* ... */
typedef straight byte tbyte;
typedef straight ubyte tubyte;
/* ... */
typedef tight struct invertInt64_t
{       
    tubyte tail[ 7 ];
    tbyte head;
} <=>   /* Couldn't think of 
           any better token. */ 
cpuInt64_t 
to_internal( struct invertInt64_t me ) 
{       
    cpuInt64_t result;
    result.HiHiHibyte = me.head;
    result.HiHiLobyte = me.tail[ 6 ];
    result.HiLoHibyte = me.tail[ 5 ];
    result.HiLoLobyte = me.tail[ 4 ];
    result.LoHiHibyte = me.tail[ 3 ];
    result.LoHiLobyte = me.tail[ 2 ];
    result.LoLoHibyte = me.tail[ 1 ];
    result.LoLoLobyte = me.tail[ 0 ];
    return result;
}
struct invertInt64_t 
to_external( cpuInt64_t me ) 
{       
    invertInt64_t result;
    result.head      = me.HiHiHibyte;
    result.tail[ 6 ] = me.HiHiLobyte;
    result.tail[ 5 ] = me.HiLoHibyte;
    result.tail[ 4 ] = me.HiLoLobyte;
    result.tail[ 3 ] = me.LoHiHibyte;
    result.tail[ 2 ] = me.LoHiLobyte;
    result.tail[ 1 ] = me.LoLoHibyte;
    result.tail[ 0 ] = me.LoLoLobyte;
    return result;
} invertInt64_t;
/* ... */
/* Revert name space: */
#seal ByteOrderSpace
/* Context is still ByteOrderSpace */ 
#definitions globalSpace    
/* CPU has 64 bit registers. */ 
typedef cpuInt64_t long;    
#context globalSpace
/* ... */
     


