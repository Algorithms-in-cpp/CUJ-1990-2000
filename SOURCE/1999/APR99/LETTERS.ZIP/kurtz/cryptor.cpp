//***********************************************
// File: Cryptor.CPP
// Copyright (c) 1998 by Warren Ward
// Permission is granted to use this source 
// code as long as this copyright notice appears
// in all source files that now include it.
//***********************************************
// OVERVIEW
// The Cryptor class in this file encrypts
// text and binary information. It uses stream
// encryption, based on Linear Feedback Shift
// Registers as pseudo-random number generators.
//
// MAJOR METHODS
//
// Set_Key()
// Set a new key for the encryption engine.
//
// Transform_Char()
// Encrypt a character using the current state
// of the encryption engine.
// 
// Transform_File()
// Encrypt a file in place, using the key passed
// in as a parameter.
// 
// Transform_String()
// Encrypt a string in place, using the key 
// passed in as a parameter.
//
// For additional information, see the article
// "Applying Stream Encryption" in C/C++ Users
// Journal (September 1998, p. 23).
//***********************************************

//***********************************************
// Development History
//***********************************************
// 20 December 1997 - Warren Ward
//
// 1. Developed basic class as child of Filter.
//		
//***********************************************
// 3 June 1998 - Warren Ward
//
// 1.	Collapsed class hierarchy into a single 
//		encryption class for CUJ article.
// 2.	Replaced single LFSR with stronger
//		triple-LFSR encryption algorithm.
// 3.	Adjusted file transform to work "in 
//		place", without leaving unencrypted 
//		copies behind.
//
//***********************************************
// 6 September 1998 - Warren Ward
//
// 1.	Corrected error in LFSR shift operation.
// 2.	Reinstated some of the comments removed 
//		for brevity in CUJ publication.
// 3.	Added main() to test the code and serve
//		as "how-to" examples.
//
//***********************************************

#include	"Cryptor.h"

//***********************************************
// CLASS IMPLEMENTATION
// Cryptor
//***********************************************

//***********************************************
// Cryptor::Cryptor
//***********************************************
// The constructor initializes Cryptor 
// properties. Do not change the feedback masks
// without consulting Bruce Schneier's Applied
// Cryptography (Addison Wesley).
//***********************************************
Cryptor::Cryptor():
	// Initialize the shift registers to non-zero 
	// values. If the shift register contains all 
	// 0's when the generator starts, it will not 
	// produce a usable sequence of bits. The 
	// numbers used here have no special features 
	// except for being non-zero.
	m_LFSR_A( 0x13579BDF ),
	m_LFSR_B( 0x2468ACE0 ),
	m_LFSR_C( 0xFDB97531 ),

	// Initialize the masks to magic numbers. 
	// These values are primitive polynomials mod 
	// 2, described in Applied Cryptography, 
	// second edition, by Bruce Schneier (New York: 
	// John Wiley and Sons, 1994). See Chapter 15: 
	// Random Sequence Generators and Stream 
	// Ciphers, particularly thediscussion on 
	// Linear Feedback Shift Registers.
	//
	// The primitive polynomials used here are:
	// Register A:	( 32, 7, 6, 2, 0 )
	// Register B:	( 31, 6, 0 )
	// Register C:	( 29, 2, 0 )
	//
	// The bits that must be set to "1" in the 
	// XOR masks are:
	// Register A:	( 31, 6, 5, 1 )
	// Register B:	( 30, 5 )
	// Register C:	( 28, 1 )
	//
	// Developer's Note
	// DO NOT CHANGE THESE NUMBERS WITHOUT 
	// REFERRING TO THE DISCUSSION IN SCHNEIER'S 
	// BOOK. They are some of very few 
	// near-32-bit values that will act as 
	// maximal-length random generators.
	m_Mask_A( 0x80000062 ), 
	m_Mask_B( 0x40000020 ), 
	m_Mask_C( 0x10000002 ), 

	// Set up LFSR "rotate" masks.
	// These masks limit the number of bits 
	// used in the shift registers. Each one 
	// provides the most-significant bit (MSB) 
	// when performing a "rotate" operation. Here 
	// are the shift register sizes and the byte 
	// mask needed to place a "1" bit in the MSB 
	// for Rotate-1, and a zero in the MSB for 
	// Rotate-0. All the shift registers are stored
	// in an unsigned 32-bit integer, but these 
	// masks effectively make the registers 32 
	// bits (A), 31 bits (B), and 29 bits (C).
	//
	//	Bit	  |  3            2             1            0
	//	Pos'n | 1098 7654  3210 9876  5432 1098  7654 3210
	//	===== | ==========================================
	//	Value | 8421-8421  8421-8421  8421-8421  8421-8421
	//	===== | ==========================================
	//		  | 
	// A-Rot0 | 0111 1111  1111 1111  1111 1111  1111 1111  
	// A-Rot1 | 1000 0000  0000 0000  0000 0000  0000 0000 
	//		  | 
	// B-Rot0 | 0011 1111  1111 1111  1111 1111  1111 1111  
	// B-Rot1 | 1100 0000  0000 0000  0000 0000  0000 0000  
	//		  | 
	// C-Rot0 | 0000 1111  1111 1111  1111 1111  1111 1111  
	// C-Rot1 | 1111 0000  0000 0000  0000 0000  0000 0000  
	//
	//	
	// Reg Size	MSB Position	Rotate-0 Mask	Rotate-1 Mask
	//	A	32		31			0x7FFFFFFF		0x80000000
	//	B	31		30			0x3FFFFFFF		0xC0000000
	//	C	29		28			0x0FFFFFFF		0xF0000000
	//
	m_Rot0_A( 0x7FFFFFFF ), 
	m_Rot0_B( 0x3FFFFFFF ), 
	m_Rot0_C( 0x0FFFFFFF ),
	m_Rot1_A( 0x80000000 ), 
	m_Rot1_B( 0xC0000000 ), 
	m_Rot1_C( 0xF0000000 )
	{
	}


//***********************************************
// Cryptor::~Cryptor
//***********************************************
// Destructor.
//***********************************************
Cryptor::~Cryptor()
	{
	}


//***********************************************
// Cryptor::Set_Key
//***********************************************
// Place key into the three LFSRs. For 
// simplicity in publication, this routine does 
// not report errors. Any fault in a key (e.g.,
// "key too short" or "key loads 0x00000000
// into one shift register") should report an
// error to the calling routine, either as a 
// return value or by raising an exception. The
// default error-handling in this routine is 
// not strong enough for practical purposes.
//
// This method should be called before starting 
// an encryption session. Both Transform_File
// and Transform_String do so. If the class is 
// extended to include methods for other data
// types, review these two routines as examples.
//
// DEVELOPER'S NOTE
// If, for some reason, you do not report errors
// back to the calling routine, at least make the
// following changes for your own implementation:
//
// (1) Change the default key string "Default 
// Seed" to a secret string.
//
// (2) Change the default values loaded when an
// LFSR contains 0x00000000.
//***********************************************
void Cryptor::Set_Key( const std::string & Key )
	{
	int Index = 0; 

	// Set default key if none provided.
	m_Key = Key;
	std::string		Seed	= m_Key ;
	if ( 0 == Seed.length() )
		{
		Seed = "Default Seed";
		}

	// Make sure seed is at least 12 bytes long . 
	for ( Index = 0; Seed.length() < 12; Index++ )
		{
		Seed += Seed[ Index ] ;
		}

	// LFSR A, B, and C get the first, second, and
	// third four bytes of the seed, respectively.
	for ( Index = 0; Index < 4; Index++ )
		{
		m_LFSR_A = 
			( 
			( m_LFSR_A <<= 8 ) | 
			( ( unsigned long int ) Seed[ Index + 0 ] ) 
			);
		m_LFSR_B = 
			( 
			( m_LFSR_B <<= 8 ) | 
			( ( unsigned long int ) Seed[ Index + 4 ] ) 
			);
		m_LFSR_C = 
			( 
			( m_LFSR_C <<= 8 ) | 
			( ( unsigned long int ) Seed[ Index + 8 ] ) 
			);
		}

	// If any LFSR contains 0x00000000, load a 
	// non-zero default value instead. There is
	// no particular "good" value. The ones here
	// were selected to be distinctive during
	// testing and debugging.
	if ( 0x00000000 == m_LFSR_A )
		m_LFSR_A = 0x13579BDF;

	if ( 0x00000000 == m_LFSR_B )
		m_LFSR_B = 0x2468ACE0;

	if ( 0x00000000 == m_LFSR_C )
		m_LFSR_C = 0xFDB97531;

	return;
	}


//***********************************************
// Cryptor::Transform_Char
//***********************************************
// Transform a single character. If it is 
// plaintext, it will be encrypted. If it is
// encrypted, and if the LFSRs are in the same
// state as when it was encrypted (that is, the
// same keys loaded into them and the same number
// of calls to Transform_Char after the keys
// were loaded), the character will be decrypted
// to its original value.
//
// DEVELOPER'S NOTE
// This code contains corrections to the LFSR
// operations that supercede the code examples
// in Applied Cryptography (first edition, up to
// at least the 4th printing, and second edition,
// up to at least the 6th printing). More recent
// errata sheets may show the corrections.
//***********************************************
void Cryptor::Transform_Char( unsigned char & Target )
	{
	int					Counter	= 0;
	unsigned char		Crypto	= '\0';
	unsigned long int	Out_B	= 
		( m_LFSR_B & 0x00000001 );
	unsigned long int	Out_C	= 
		( m_LFSR_C & 0x00000001 );

	// Cycle the LFSRs eight times to get eight 
	// pseudo-random bits. Assemble these into 
	// a single random character (Crypto).
	for ( Counter = 0; Counter < 8; Counter++ )
		{
		if ( m_LFSR_A & 0x00000001 )
			{
			// The least-significant bit of LFSR 
			// A is "1". XOR LFSR A with its 
			// feedback mask.
			m_LFSR_A = 
				( 
				( ( m_LFSR_A ^ m_Mask_A ) >> 1 ) | 
				m_Rot1_A 
				);
			
			// Clock shift register B once.
			if ( m_LFSR_B & 0x00000001 )
				{
				// The LSB of LFSR B is "1". XOR 
				// LFSR B with its feedback mask.
				m_LFSR_B = 
					( 
					( ( m_LFSR_B ^ m_Mask_B ) >> 1 ) | 
					m_Rot1_B 
					);
				Out_B = 0x00000001;
				}
			else
				{
				// The LSB of LFSR B is "0". Rotate 
				// the LFSR contents once.
				m_LFSR_B = 
					( 
					( m_LFSR_B >> 1) & 
					m_Rot0_B 
					);
				Out_B = 0x00000000;
				}
		}   // end if
		else
			{
			// The LSB of LFSR A is "0". 
			// Rotate the LFSR contents once.
			m_LFSR_A = ( ( m_LFSR_A >> 1 ) & m_Rot0_A );

			// Clock shift register C once.
			if ( m_LFSR_C & 0x00000001 )
				{
				// The LSB of LFSR C is "1". 
				// XOR LFSR C with its feedback mask.
				m_LFSR_C = 
					( 
					( ( m_LFSR_C ^ m_Mask_C ) >> 1 ) | 
					m_Rot1_C 
					);
				Out_C = 0x00000001;
				}   // end if
			else
				{
				// The LSB of LFSR C is "0". Rotate 
				// the LFSR contents once.
				m_LFSR_C = 
					( ( m_LFSR_C >> 1 ) & m_Rot0_C );
				Out_C = 0x00000000;
				}   // end else
			
			}   // end else

		// XOR the output from LFSRs B and C and 
		// rotate it into the right bit of Crypto.
		Crypto = 
			( 
			( Crypto << 1 ) | 
			( Out_B ^ Out_C ) 
			);

		}   // end for ( Counter . . .

	// XOR the resulting character with the 
	// input character to encrypt/decrypt it.
	Target = ( Target ^ Crypto );

	return;
	}


//***********************************************
// Cryptor::Transform_File
//***********************************************
// Using a given key, encrypt or decrypt all the
// contents of a disk file. The full pathname of 
// the file to transform is passed in as Target.
//
// DEVELOPER'S NOTE
// This routine is easily modified to take a
// standard stream as a parameter rather than
// a file path and name.
//***********************************************
void Cryptor::Transform_File
	( 
	const std::string & Key, 
	const std::string & Target 
	)
	{
	int		Current_Char	= 'X';
	bool	Success			= true;

	// Open the file for binary read and write.
	// 
	// DEVELOPER'S NOTE
	// ====================================================
	// ALWAYS TREAT THE FILES AS BINARY.
	// ====================================================
	// The transformation process can create '\0' characters 
	// in the output file. Functions expecting null-
	// terminated strings or explicit end-of-line and end-
	// of-file characters will not act correctly.
	std::ifstream Source
		( 
		Target.c_str(), 
		std::ios::in | std::ios::out | std::ios::binary  
		);
	std::ostream Out( Source.rdbuf() );

	if ( Success )
		{
		// Reset the shift registers.
		Set_Key( Key );

		// Transform each character in the file.
		while ( EOF != ( Current_Char = Source.peek() ) )
			{
			// Make the output buffer current.
			Out.rdbuf()->pubseekoff
				( 0, std::ios::cur );
			Transform_Char
				( ( unsigned char & ) Current_Char );
			Out.put( Current_Char );

			// Make the input buffer current.
			Source.rdbuf()->pubseekoff
				( 0, std::ios::cur );
			}   // end while ( EOF . . . 
		}   // end if ( Success )

	return;
	}


//***********************************************
// Cryptor::Transform_String
//***********************************************
// Encrypt or decrypt a standard string in place.
// The string to transform is passed in as 
// Target.
//***********************************************
void Cryptor::Transform_String
	( 
	const std::string & Key, 
	std::string & Target 
	)
	{
	int		Position	= 0;
	int		Length		= 0;

	// Reset the shift registers.
	Set_Key( Key );

	// Transform each character in the string.
	// 
	// DEVELOPER'S NOTE
	// ==========================================
	// DO NOT TREAT THE OUTPUT STRING AS A NULL-
	// TERMINATED STRING. 
	// ==========================================
	// The transformation process can create '\0' 
	// characters in the output string. Always 
	// use the length() method to retrieve the full 
	// string when it has been transformed.
	Length = Target.length();
	for ( Position = 0; Position < Length; Position++ )
		{
		Transform_Char
			( ( unsigned char & ) Target[ Position ] );
		}

	return;
	}


//***********************************************
// Cryptor::Weak_Transform_Char
//***********************************************
// An example of a faster but cryptographically
// weaker form of LFSR encryption. A single LFSR
// does produce pseudo-random numbers, but its
// output can be cryptanalyzed to break the 
// encryption. The triple-LFSR approach used
// in Transform_Char is cryptographically much
// stronger.
//***********************************************
void Cryptor::Weak_Transform_Char
	( 
	unsigned char & Target 
	)
	{
	int					Counter	= 0;
	unsigned char		Crypto	= '\0';
	unsigned long int	Out_A	= 0x00000000;

	// Cycle the LFSR eight times to get eight 
	// pseudo-random bits. Assemble these into 
	// a single random character (Crypto).
	for ( Counter = 0; Counter < 8; Counter++ )
		{
		if ( m_LFSR_A & 0x00000001 )
			{
			// The least-significant bit of 
			// LFSR A is "1". XOR LFSR A with 
			// its feedback mask.
			m_LFSR_A = 
				( 
				( ( m_LFSR_A ^ m_Mask_A ) >> 1 ) | 
				m_Rot1_A 
				);
			Out_A = 0x00000001;
			
			}   // end if ( m_LFSR_A . . .
		else
			{
			// The LSB of LFSR A is "0". 
			// Rotate the LFSR contents once.
			m_LFSR_A = 
				( 
				( m_LFSR_A >> 1 ) & 
				m_Rot0_A 
				);
			Out_A = 0x00000000;
			
			}   // end else

		// Rotate the output bit into Crypto.
		//
		Crypto = ( ( Crypto << 1 ) | ( Out_A ) );

		}   // end for ( Counter . . .

	// XOR the resulting character with the 
	// input character to encrypt/decrypt it.
	Target = ( Target ^ Crypto );

	return;
	}


//***********************************************
// Main()
//***********************************************
// This routine tests the Cryptor methods, both
// directly and indirectly. Watch the variable
// Success: if it changes to FALSE, a test has 
// failed. 
//
// NOTE
// This routine will create a test file on disk.
// The file appears in the root directory, named
// "\Source.txt".
//***********************************************
int main()
	{
	// Initialize local variables.
	bool	Success = true;
	int		Return_Code = 0;
	Cryptor	Test_Cryptor;

	
	// Test Transform_Char().
	unsigned char Original_Char		= '\0';
	unsigned char Target_Char		= '\0';
	std::string	Key(				"01234567890123456789" );

	Test_Cryptor.Set_Key( Key );
	Test_Cryptor.Transform_Char( Target_Char );
	Success = ( Success && ( Target_Char != Original_Char ) );

	Test_Cryptor.Set_Key( Key );
	Test_Cryptor.Transform_Char( Target_Char );
	Success = ( Success && ( Target_Char == Original_Char ) );


	// Test Weak_Transform_Char().
	Original_Char	= '\0';
	Target_Char		= '\0';

	Test_Cryptor.Set_Key( Key );
	Test_Cryptor.Weak_Transform_Char( Target_Char );
	Success = ( Success && ( Target_Char != Original_Char ) );

	Test_Cryptor.Set_Key( Key );
	Test_Cryptor.Weak_Transform_Char( Target_Char );
	Success = ( Success && ( Target_Char == Original_Char ) );


	// Test Transform_String. (Indirectly tests Transform_Char.)
	std::string	Original_String(	"AAAAAAAAAAZZZZZZZZZZ" );
	std::string	Target_String(		"AAAAAAAAAAZZZZZZZZZZ" );

	Test_Cryptor.Transform_String( Key, Target_String );
	Success = ( 0 != Original_String.compare( Target_String ) );

	Test_Cryptor.Transform_String( Key, Target_String );
	Success = ( 0 == Original_String.compare( Target_String ) );

  
	// Test Transform_File(). (Indirectly tests Transform_Char.)
	// Create a temporary file.
	std::string Source_Name( "\\Source.txt" );

	// Open the source file.
	std::ifstream Source_File
		( 
		Source_Name.c_str(), 
		std::ios::in | std::ios::out | std::ios::binary  
		);

	// Link an output stream to the same file so that
	// it can be written to.
	std::ostream Out_Stream( Source_File.rdbuf() );
	Success = 
		( 
		Success && 
		( Source_File.is_open() )
		);
	Success = 
		( 
		Success && 
		Source_File.good()
		);
	Success = 
		( 
		Success && 
		Out_Stream.good() 
		);

	// Load it with text and close it.
	Out_Stream.put( 'A' );
	Out_Stream.put( 'B' );
	Out_Stream.put( 'C' );
	Source_File.close();

	// Encrypt the contents of the Source file.
	Test_Cryptor.Transform_File( Key, Source_Name );

	// Now compare the encrypted contents with the
	// original data. No character should ever match.
	unsigned char Character;
	Source_File.open
		( 
		Source_Name.c_str(), 
		std::ios::in | std::ios::binary  
		);
	Success = 
		( 
		Success && 
		( Source_File.is_open() )
		);

	Success = 
		( 
		Success && 
		( 'A' != ( Character = Source_File.get() ) )
		);
	Success = 
		( 
		Success && 
		( 'B' != ( Character = Source_File.get() ) )
		);
	Success = 
		( 
		Success && 
		( 'C' != ( Character = Source_File.get() ) )
		);

	Source_File.close();


	// Decrypt the Source file.
	Test_Cryptor.Transform_File( Key, Source_Name );

	// Compare the decrypted contents with the
	// original data.
	Source_File.open
		( 
		Source_Name.c_str(), 
		std::ios::in | std::ios::binary  
		);
	Success = 
		( 
		Success && 
		( Source_File.is_open() )
		);

	Success = 
		( 
		Success && 
		( 'A' == ( Character = Source_File.get() ) )
		);
	Success = 
		( 
		Success && 
		( 'B' == ( Character = Source_File.get() ) )
		);
	Success = 
		( 
		Success && 
		( 'C' == ( Character = Source_File.get() ) )
		);

	// Test file is left on disk. Delete manually if desired.
	Source_File.close();

	return ( Success );
	}