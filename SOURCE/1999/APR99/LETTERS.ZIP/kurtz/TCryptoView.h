// TCryptoView.h : interface of the CTCryptoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TCRYPTOVIEW_H__66035FB1_8319_11D2_85E6_004005FFF9AF__INCLUDED_)
#define AFX_TCRYPTOVIEW_H__66035FB1_8319_11D2_85E6_004005FFF9AF__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "ARACrypt.h"

class CTCryptoView : public CFormView
{
protected: // create from serialization only
	CTCryptoView();
	DECLARE_DYNCREATE(CTCryptoView)

public:
	//{{AFX_DATA(CTCryptoView)
	enum { IDD = IDD_TCRYPTO_FORM };
	CString	m_csDecrypted;
	CString	m_csEncrypted;
	CString	m_csPassPhrase;
	CString	m_csTargetText;
	//}}AFX_DATA

// Attributes
public:
	CTCryptoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTCryptoView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTCryptoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	ARACrypt m_AESCrypt;

// Generated message map functions
protected:
	//{{AFX_MSG(CTCryptoView)
	afx_msg void OnPBDecrypt();
	afx_msg void OnPBEncrypt();
	afx_msg void OnPBClearAll();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TCryptoView.cpp
inline CTCryptoDoc* CTCryptoView::GetDocument()
   { return (CTCryptoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TCRYPTOVIEW_H__66035FB1_8319_11D2_85E6_004005FFF9AF__INCLUDED_)
