// TCryptoView.cpp : implementation of the CTCryptoView class
//

#include "stdafx.h"
#include "TCrypto.h"

#include "TCryptoDoc.h"
#include "TCryptoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTCryptoView

IMPLEMENT_DYNCREATE(CTCryptoView, CFormView)

BEGIN_MESSAGE_MAP(CTCryptoView, CFormView)
	//{{AFX_MSG_MAP(CTCryptoView)
	ON_BN_CLICKED(IDC_PBDECRYPT, OnPBDecrypt)
	ON_BN_CLICKED(IDC_PBENCRYPT, OnPBEncrypt)
	ON_BN_CLICKED(IDC_PBCLEARALL, OnPBClearAll)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTCryptoView construction/destruction

CTCryptoView::CTCryptoView()
	: CFormView(CTCryptoView::IDD)
{
	//{{AFX_DATA_INIT(CTCryptoView)
	m_csDecrypted = _T("");
	m_csEncrypted = _T("");
	m_csPassPhrase = _T("");
	m_csTargetText = _T("");
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CTCryptoView::~CTCryptoView()
{
}

void CTCryptoView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTCryptoView)
	DDX_Text(pDX, IDC_EDDECRYPTED, m_csDecrypted);
	DDX_Text(pDX, IDC_EDENCRYPTED, m_csEncrypted);
	DDX_Text(pDX, IDC_EDPASSPHRASE, m_csPassPhrase);
	DDX_Text(pDX, IDC_EDTARGETTEXT, m_csTargetText);
	//}}AFX_DATA_MAP
}

BOOL CTCryptoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTCryptoView diagnostics

#ifdef _DEBUG
void CTCryptoView::AssertValid() const
{
	CFormView::AssertValid();
}

void CTCryptoView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CTCryptoDoc* CTCryptoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTCryptoDoc)));
	return (CTCryptoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTCryptoView message handlers

void CTCryptoView::OnPBDecrypt() 
{
	UpdateData(TRUE);
	
	m_csDecrypted = m_csEncrypted;
	m_AESCrypt.TransformString(m_csPassPhrase, m_csDecrypted);
	UpdateData(FALSE);
	
}

void CTCryptoView::OnPBEncrypt() 
{
	UpdateData(TRUE);
	
	m_csEncrypted = m_csTargetText;
	m_AESCrypt.TransformString(m_csPassPhrase, m_csEncrypted);
	UpdateData(FALSE);
}

void CTCryptoView::OnPBClearAll() 
{
	m_csPassPhrase	= _T("");
	m_csTargetText	= _T("");
	m_csEncrypted	= _T("");
	m_csDecrypted	= _T("");
	UpdateData(FALSE);
}

