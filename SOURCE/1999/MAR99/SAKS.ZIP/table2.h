// table2.h - cross-reference table interface
     
class cross_reference_table
    {
public:
    cross_reference_table();
    void add(char const *w, unsigned n); 
    void put() const;
private:
    struct tree_node;
    static tree_node *add_tree
        (tree_node *t, char const *w, unsigned n);
    static void put_tree(tree_node const *t); 
    tree_node *root;
    };
     
// ... the rest is the same as Listing 1 ....
     

     
