import java.util.*;

public class Wrappers {
    public static void main(String[] args) {
        Date start = new Date();
        final int N = 250000;
        Integer[] a = new Integer[N];
        for (int i = 0; i < N; ++i)
            a[i] = new Integer(i);
        int sum = a[0].intValue();
        for (int i = 1; i < N; ++i)
            sum += a[i].intValue();
        Date stop = new Date();
        System.out.println(stop.getTime()
            - start.getTime());  // 1710
    }
}

                                                       
                                                       
            
