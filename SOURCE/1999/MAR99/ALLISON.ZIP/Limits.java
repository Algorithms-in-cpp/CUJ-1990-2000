public class Limits {
    public static void main(String[] args) {
        System.out.println("Byte: [" +
            Byte.MIN_VALUE + "," +
            Byte.MAX_VALUE + "]");
        System.out.println("Character: [" +
            Character.MIN_VALUE + "," +
            Character.MAX_VALUE + "]");
        System.out.println("Short: [" +
            Short.MIN_VALUE + "," +
            Short.MAX_VALUE + "]");
        System.out.println("Integer: [" +
            Integer.MIN_VALUE + "," +
            Integer.MAX_VALUE + "]");
        System.out.println("Long: [" +
            Long.MIN_VALUE + "," +
            Long.MAX_VALUE + "]");
        System.out.println("Float: [" +
            Float.MIN_VALUE + "," +
            Float.MAX_VALUE + "]");
        System.out.println("Double: [" +
            Double.MIN_VALUE + "," +
            Double.MAX_VALUE + "]");
    }
}

/* Output:
Byte: [-128,127]
Character: [0,65535]
Short: [-32768,32767]
Integer: [-2147483648,2147483647]
Long: [-9223372036854775808,9223372036854775807]
Float: [1.4E-45,3.4028235E38]
Double: [4.9E-324,1.7976931348623157E308]
*/
