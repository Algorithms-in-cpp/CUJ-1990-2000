import java.util.*;

public class Primitives {
    public static void main(String[] args) {
        Date start = new Date();
        final int N = 250000;
        int[] a = new int[N];
        for (int i = 0; i < N; ++i)
            a[i] = i;
        int sum = a[0];
        for (int i = 1; i < N; ++i)
            sum += a[i];
        Date stop = new Date();
        System.out.println(stop.getTime()
            - start.getTime());  // 50
    }
}
