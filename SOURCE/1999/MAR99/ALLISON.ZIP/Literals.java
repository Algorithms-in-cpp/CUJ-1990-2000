public class Literals {
    public static void main(String[] args) {
        boolean b = true;
        System.out.println(b);
        int i1 = 15, i2 = 017, i3 = 0x0f;
        System.out.println(i1 + "," + i2 + "," + i3);
        long n = 1234567L;
        System.out.println(n);
        float x1 = 123.4567F, x2 = .1234567e3f;
        System.out.println(x1 + "," + x2);
        double y1 = 2.3d, y2 = .23e1;
        System.out.println(y1 + "," + y2);
        char c1 = 'a', c2 = '\u0061', c3 = '\141';
        System.out.println(c1 + "," + c2 + "," + c3);
        String s = "hello";
        System.out.println(s);
    }
}

/* Output:
true
15,15,15
1234567
123.4567,123.4567
2.3,2.3
a,a,a
hello
*/

