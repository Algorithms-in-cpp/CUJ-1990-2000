import java.math.*;     // For BigInteger

public class BigInt {
    public static void main(String[] args) {
        // Build a number with 40 digits:
        String s = "12345678901234567890"
                 + "12345678901234567890";
        BigInteger b = new BigInteger(s);

        BigInteger one = BigInteger.valueOf(1);
        BigInteger two = BigInteger.valueOf(2);
        BigInteger b2 = b.add(one);
        
        System.out.println("b has " + b.bitCount() + " bits");
        System.out.println("b mod 2 = " + b.mod(two));
        System.out.println("b2 mod 2 = " + b2.mod(two));
        System.out.println("b2 - b = " + b2.subtract(b));
    }
}

/* Output:
b has 68 bits	// 2�s-complement
b mod 2 = 0		// even
b2 mod 2 = 1	// odd
b2 - b = 1
*/
