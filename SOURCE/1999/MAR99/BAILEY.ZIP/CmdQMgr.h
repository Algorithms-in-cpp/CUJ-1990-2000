#ifndef CMDQMGR
#define CMDQMGR
#include <std/string.h>


// enumerate type of user of queue
enum q_usage {creator, sender};

// define class to manage message queues
class CmdQMgr{

public:
    CmdQMgr (int signal_id, int proc_id);
    CmdQMgr (int signal_id);
    ~CmdQMgr(void);
    int send_msg(char *);
    int receive_msg(string& );

private:
    static int cmdq_creator_count;
    q_usage cmdqmgr_origin;
    long cmdqmgr_type;
    int cmdqmgr_signal_id;
    int cmdqmgr_proc_id;
    int cmdqmgr_key;
    int cmdqmgr_queue_id;
};
#endif

