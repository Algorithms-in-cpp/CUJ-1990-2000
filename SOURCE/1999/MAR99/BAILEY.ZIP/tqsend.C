#include <iostream.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/errno.h>
#include <stdlib.h>
#include <std/string.h>
#include "CmdQMgr.h"

int main(int argc, char *argv[]){

    int proc_id;
    int signal_id;
    int msg_q;
    int ret_val;
    CmdQMgr *Qobj;

    if (argc != 4 ){
        cerr << "Usage: " << argv[0] << 
               " : process_id signal_id Message\n";
        exit (1);
    }

    // convert the process ID and signal ID on the 
    // command line to integers
    proc_id = atoi(argv[1]);
    signal_id = atoi(argv[2]);

    // Instantiate a queue object that will manage access
    // to send messages to the process
    try {
        
        Qobj = new CmdQMgr(signal_id, proc_id);
    }
    catch (string err_msg){
        cout << err_msg << endl;
        return 1;
    }

    // Send the message 
    ret_val =  Qobj->send_msg( argv[3] );

    return ret_val;
}




