//
// CmdControl.h
//
// Header file for command and control class. 
//
//

#ifndef CMDCNTRL
#define CMDCNTRL
#include <map.h>
#include <std/string.h>
#include "CmdQMgr.h"

// define data type for iterator
typedef map <string, void(*)(), less<string> >::iterator rsI;

class CmdControl{

public:
    static void cmd_handler(int);
    CmdControl(int in_signal);
    ~CmdControl();
    void set_action( string cmd_desc, void (*call_function)());
    void unset_action( string cmd_desc);
    int is_used( string cmd_desc);
    void run_cmd(int);
    static map < int, CmdControl *, less<int> > cmd_sigobjref;
        

private:
    map <string, void(*)(), less<string> > run_string;
    CmdQMgr *cmd_msg_object;
    int cmd_signal;
};

#endif

