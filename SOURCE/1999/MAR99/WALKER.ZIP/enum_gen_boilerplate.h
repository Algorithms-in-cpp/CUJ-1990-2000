Author:  "Walker; Art" <Art.Walker@essexcorp.com> at Internet
Date:    2/2/99  9:38 AM
Priority: Normal
TO: Marc Briand at MFI-Lawrence
Subject: enum_gen article -- enum_gen_boilerplate.h
------------------------------- Message Contents -------------------------------
//---------------------------------------------------------------------- 
-------
//
//  Filename:   #CLASS_NAME#.h
//
//  Description:
//  Class #CLASS_NAME# generated using enum_gen. 
//
//---------------------------------------------------------------------- 
-------
     
#ifndef _#CLASS_NAME#_H
#define _#CLASS_NAME#_H
     
// The OSTREAM and ISTREAM typedefs are used due to a problem that 
occurs
// when compiling enum classes using MS Visual C++ 5.0; even with the 
// "using namespace std" declaration, lines containing ostream and 
istream 
// are flagged as ambiguous by VC++.
     
#ifdef WIN32
    #include <string>
    #include <iostream>
     
    using namespace std;
     
    typedef std::ostream  OSTREAM;
    typedef std::istream  ISTREAM;
     
#else  // SGI
    #include <iostream.h>
    #include <mstring.h>   // Needed for string class on SGI
     
    typedef ostream  OSTREAM;
    typedef istream  ISTREAM;
     
#endif
     
     
#HEADER#
     
//---------------------------------------------------------------------- 
-------
     
#ifdef ENUMS_USE_EXCEPTION_HANDLING
    #define #CLASS_NAME#_THROW_DECL    throw (const char *) 
    #define #CLASS_NAME#_THROW_EXEC    throw m_errorMsg;
#else
    #define #CLASS_NAME#_THROW_DECL
    #define #CLASS_NAME#_THROW_EXEC    #CLASS_NAME#::RangeError()
#endif
     
//---------------------------------------------------------------------- 
-------
     
class #CLASS_NAME# #BASE_CLASS_NAME# 
{
public:  
    #CONST_CODE#
     
     
public:
     
    #CLASS_NAME#()
    {
        m_defPtr = _UNDEFINED.m_defPtr;
    }
     
    #CLASS_NAME# (
        const #CLASS_NAME#&  objref )
    {
        m_defPtr = objref.m_defPtr;
    }
     
    explicit #CLASS_NAME# (
        const string&  estr );
     
    explicit #CLASS_NAME# (
        const int  ival );
     
    // GetInt is used instead of "operator int()" to enforce explicit 
    // conversion from #CLASS_NAME# to int.
     
    short GetInt() const #CLASS_NAME#_THROW_DECL 
    {
        if (m_defPtr == _UNDEFINED.m_defPtr) 
        {
            #CLASS_NAME#_THROW_EXEC;
        }
        return m_defPtr->m_value;
    }
     
    bool valid() const
    {
        return (m_defPtr != _UNDEFINED.m_defPtr);
    }
     
    #CLASS_NAME#& operator= (
        const #CLASS_NAME#&  objref )
    {
        m_defPtr = objref.m_defPtr;
        return *this;
    }
     
    bool operator== (
        const #CLASS_NAME#&  objref ) const #CLASS_NAME#_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            #CLASS_NAME#_THROW_EXEC;
        }
        return m_defPtr == objref.m_defPtr;
    }
     
    bool operator!= (
        const #CLASS_NAME#&  objref ) const #CLASS_NAME#_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            #CLASS_NAME#_THROW_EXEC;
        }
        return m_defPtr != objref.m_defPtr;
    }
     
    bool operator< (
        const #CLASS_NAME#&  objref ) const #CLASS_NAME#_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            #CLASS_NAME#_THROW_EXEC;
        }
        return m_defPtr < objref.m_defPtr;
    }
     
    bool operator<= (
        const #CLASS_NAME#&  objref ) const #CLASS_NAME#_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            #CLASS_NAME#_THROW_EXEC;
        }
        return m_defPtr <= objref.m_defPtr;
    }
     
    bool operator> (
        const #CLASS_NAME#&  objref ) const #CLASS_NAME#_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            #CLASS_NAME#_THROW_EXEC;
        }
        return m_defPtr > objref.m_defPtr;
    }
     
    bool operator>= (
        const #CLASS_NAME#&  objref ) const #CLASS_NAME#_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            #CLASS_NAME#_THROW_EXEC;
        }
        return m_defPtr >= objref.m_defPtr;
    }
     
    #CLASS_NAME# operator++();
     
    #CLASS_NAME# operator++(int);
     
    #CLASS_NAME# operator--();
     
    #CLASS_NAME# operator--(int);
     
    const char* GetLabel() const;
     
    string GetString() const;
     
    friend OSTREAM& operator<< (
        OSTREAM&             ostr,
        const #CLASS_NAME#&  objref );
     
    friend ISTREAM& operator>> (
        ISTREAM&       ostr,
        #CLASS_NAME#&  objref );
     
public: 
    static #CLASS_NAME# first()
    {
        return #FIRST_SYMBOL#;
    }
     
    static #CLASS_NAME# last()
    {
        return #LAST_SYMBOL#;
    }
     
    static int count()
    {
        return m_defArrCount - 1;
    }
     
     
private:  
    struct EnumDefStruct
    {
        short   m_value;
        string  m_name;
        EnumDefStruct (
            const int     value,
            const char*   name)
        : m_value (value), m_name (name)
        { }
    };
     
    // The class constructor with a EnumDefStruct* argument should only 
    // be used to construct the static constants that make up the enum 
    // values; thus it's declared private.
     
    #CLASS_NAME# (
        EnumDefStruct*  defPtr )
    {
        m_defPtr = defPtr;
    }
     
    static void RangeError();
     
private:
    EnumDefStruct*  m_defPtr;
     
     
private:
    static short          m_defArrCount; 
    static EnumDefStruct  m_defArr[];
    static const char*    m_errorMsg;
     
     
#DECLARE#
     
};
     
#endif
     
     
     
     
     
