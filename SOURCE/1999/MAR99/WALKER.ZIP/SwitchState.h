//-----------------------------------------------------------------------------
//
//  Filename:   SwitchState.h
//
//  Description:
//  Class SwitchState generated using enum_gen. 
//
//-----------------------------------------------------------------------------
     
#ifndef _SwitchState_H
#define _SwitchState_H
     
     
#include <iostream.h>
#include <mstring.h>
     
     
//-----------------------------------------------------------------------------
     
#ifdef ENUMS_USE_EXCEPTION_HANDLING
    #define SwitchState_THROW_DECL    throw (const char *) 
    #define SwitchState_THROW_EXEC    throw m_errorMsg;
#else
    #define SwitchState_THROW_DECL
    #define SwitchState_THROW_EXEC    SwitchState::RangeError()
#endif
     
//-----------------------------------------------------------------------------
     
class SwitchState 
{
public:  
    static const SwitchState  OFF;
    static const SwitchState  LOW;
    static const SwitchState  MED;
    static const SwitchState  HI;
    static const SwitchState  _UNDEFINED;
     
public:
     
    SwitchState()
    {
        m_defPtr = _UNDEFINED.m_defPtr;
    }
     
    SwitchState (
        const SwitchState&  objref )
    {
        m_defPtr = objref.m_defPtr;
    }
     
    explicit SwitchState (
        const string&  estr );
     
    explicit SwitchState (
        const int  ival );
     
    // GetInt is used instead of "operator int()" to enforce explicit 
    // conversion from SwitchState to int.
     
    short GetInt() const SwitchState_THROW_DECL 
    {
        if (m_defPtr == _UNDEFINED.m_defPtr) 
        {
            SwitchState_THROW_EXEC;
        }
        return m_defPtr->m_value;
    }
     
    bool valid() const
    {
        return (m_defPtr != _UNDEFINED.m_defPtr);
    }
     
    SwitchState& operator= (
        const SwitchState&  objref )
    {
        m_defPtr = objref.m_defPtr;
        return *this;
    }
     
    bool operator== (
        const SwitchState&  objref ) const SwitchState_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            SwitchState_THROW_EXEC;
        }
        return m_defPtr == objref.m_defPtr;
    }
     
    bool operator!= (
        const SwitchState&  objref ) const SwitchState_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            SwitchState_THROW_EXEC;
        }
        return m_defPtr != objref.m_defPtr;
    }
     
    bool operator< (
        const SwitchState&  objref ) const SwitchState_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            SwitchState_THROW_EXEC;
        }
        return m_defPtr < objref.m_defPtr;
    }
     
    bool operator<= (
        const SwitchState&  objref ) const SwitchState_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            SwitchState_THROW_EXEC;
        }
        return m_defPtr <= objref.m_defPtr;
    }
     
    bool operator> (
        const SwitchState&  objref ) const SwitchState_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            SwitchState_THROW_EXEC;
        }
        return m_defPtr > objref.m_defPtr;
    }
     
    bool operator>= (
        const SwitchState&  objref ) const SwitchState_THROW_DECL
    {
        if ( (m_defPtr == _UNDEFINED.m_defPtr) || 
             (objref.m_defPtr == _UNDEFINED.m_defPtr) )
        {
            SwitchState_THROW_EXEC;
        }
        return m_defPtr >= objref.m_defPtr;
    }
     
    SwitchState operator++();
     
    SwitchState operator++(int);
     
    SwitchState operator--();
     
    SwitchState operator--(int);
     
    const char* GetLabel() const;
     
    string GetString() const;
     
    friend ostream& operator<< (
        ostream&             ostr,
        const SwitchState&  objref );
     
    friend istream& operator>> (
        istream&       ostr,
        SwitchState&  objref );
     
public: 
    static SwitchState first()
    {
        return OFF;
    }
     
    static SwitchState last()
    {
        return HI;
    }
     
    static int count()
    {
        return m_defArrCount - 1;
    }
     
     
private:  
    struct EnumDefStruct
    {
        short   m_value;
        string  m_name;
        EnumDefStruct (
            const int     value,
            const char*   name)
        : m_value (value), m_name (name)
        { }
    };
     
    // The class constructor with a EnumDefStruct* argument should only 
    // be used to construct the static constants that make up the enum 
    // values; thus it's declared private.
     
    SwitchState (
        EnumDefStruct*  defPtr )
    {
        m_defPtr = defPtr;
    }
     
    static void RangeError();
     
private:
    EnumDefStruct*  m_defPtr;
     
private:
    static short          m_defArrCount; 
    static EnumDefStruct  m_defArr[];
    static const char*    m_errorMsg;
     
};
     
#endif
