//----------------------------------------------------------------------
-------
//
//  Filename:   enum_gen.cc
//
//  Author:     Arthur P. Walker
//              Essex Corporation
//              9150 Guilford Rd 
//              Columbia, MD 21046
//              awalker@essexcorp.com
//
//  Description:
//  Program for generating code for C++ classes that behave like 
//  enumerated types.  This program takes as input a file containing 
//  a C/C++ enum definitions, and creates a source and header file using

//  the name of the enum in the input file.  The suffix of the header 
//  file is always .h, while the suffix of the source file defaults to 
//  .cc but can be changed on the command line using the "-suffix"
option.
//
//   *****************************************************************
//   *                                                               *
//   *   This software is free.  The author and Essex Corporation    *
//   *   provided no warranty or guarantee of any kind, either       *
//   *   explicit or implied.  Use it at your own risk.              *
//   *                                                               *
//   *****************************************************************
//
//----------------------------------------------------------------------
-------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream.h>

#ifdef WIN32
        #include <vector>
        using namespace std;
#else
        #include <vector.h>
#endif


//----------------------------------------------------------------------
-------

enum Enum_State
{
    WAITING_FOR_SYMBOL, WAITING_FOR_VALUE, SYMBOL_FOUND, VALUE_FOUND
};

enum Class_State
{
    WAITING_FOR_NEW_ENUM, WAITING_FOR_CLASS_NAME,
WAITING_FOR_OPEN_BRACE, 
    OPEN_BRACE, CLOSE_BRACE, READING_BASE_CLASS
};

enum User_Code_State
{
    NO_USER_CODE, USER_DECL_CODE, USER_IMPL_CODE
};

//----------------------------------------------------------------------
-------

class Other_Code
{
public:
    Other_Code (
        const char*  descrip,
        const int    maxBytes )
    {
        m_descrip = new char [strlen (descrip) + 1];
        strcpy (m_descrip, descrip);

        m_byteCount = 0;
        m_maxBytes  = maxBytes;
        m_codePtr   = NULL;
    }

    ~Other_Code()
    {
        delete [] m_descrip;
        delete [] m_codePtr;
    }

    void Add (
        const char* codeLine )
    {
        if (! m_codePtr)
        {
            m_codePtr = new char [m_maxBytes];
        }

        m_byteCount += strlen (codeLine);
        if (m_byteCount >= m_maxBytes)
        {
            cerr << "ERROR: " << m_descrip << " buffer overflow" <<
endl;
            exit (1);
        }
        strcat (m_codePtr, codeLine);
    }

    bool Empty()
    {
        return (m_codePtr == NULL);
    }

    void Dump (
        FILE*  fptr )
    {
        if (m_codePtr)
        {
            m_codePtr[m_byteCount] = NULL;
            fprintf (fptr, m_codePtr);
        }
    }

private:
    Other_Code() {}  // no access to default ctor

    int    m_byteCount;
    int    m_maxBytes;
    char*  m_descrip;
    char*  m_codePtr;
};


//----------------------------------------------------------------------
-------

class Symbol_Pair 
{
public:
    Symbol_Pair (
        const char*  symbol_name,
        const char*  symbol_value = NULL)
    {
        m_name = new char [strlen (symbol_name) + 1];
        strcpy (m_name, symbol_name);

        if (symbol_value)
        {
            SetValue (symbol_value);
        }
        else
        {
            m_value = ++m_prev_value;
        }
    }

    Symbol_Pair (
        const Symbol_Pair&  tpair)
    {
        m_name = new char [strlen (tpair.m_name) + 1];
        strcpy (m_name, tpair.m_name);
        m_value = tpair.m_value;
    }

    ~Symbol_Pair()
    {
        delete [] m_name;
    }

    void SetValue (
        const char*  symbol_value )
    {
        int  value = 0;
        sscanf (symbol_value, "%d", &value);
        m_prev_value = m_value = value;
    }

    char* GetName() const
    {
        return m_name;
    }

    int GetValue() const
    {
        return m_value;
    }

    bool NameMatches (
        const Symbol_Pair&  symbolPair ) const
    {
        return (strcmp (m_name, symbolPair.m_name) == 0);
    }

public:
    static void Reset()
    {
        m_prev_value = -1;
    }

private:
    Symbol_Pair();  // no default ctor

private:
    char* m_name;
    int   m_value;

private:
    static int  m_prev_value;
};

int Symbol_Pair::m_prev_value = -1;


class Symbol_Vec : public vector<Symbol_Pair*>
{
public:
    void Reset()
    {
        iterator  iter = begin();
        for (; iter != end(); iter++)
        {
            Symbol_Pair*  ptr = *iter;
            delete ptr;
        }
        erase (begin(), end());
    }
};


//----------------------------------------------------------------------
-------

const char*  ENUM_GEN_ENVVAR = "ENUM_GEN_DIR";

const char*  SYMBOL_NAME_MARKER     = "#SYMBOL_NAME#";
const char*  FIRST_SYMBOL_MARKER    = "#FIRST_SYMBOL#";
const char*  LAST_SYMBOL_MARKER     = "#LAST_SYMBOL#";
const char*  CLASS_NAME_MARKER      = "#CLASS_NAME#";
const char*  BASE_CLASS_NAME_MARKER = "#BASE_CLASS_NAME#";
const char*  CONST_CODE_MARKER      = "#CONST_CODE#";
const char*  GETLABEL_CODE_MARKER   = "#GETLABEL_CODE#";
const char*  GETENUM_CODE_MARKER    = "#GETENUM_CODE#";

const char*  USER_HEADER_MARKER    = "#HEADER#";
const char*  USER_DECL_MARKER      = "#DECLARE#";
const char*  USER_IMPL_MARKER      = "#IMPLEMENT#";

const char*  h_boilerplate  = "enum_gen_boilerplate.h";
const char*  cc_boilerplate = "enum_gen_boilerplate.cc";

const int  MAX_DECL_CODE = 40000;
const int  MAX_IMPL_CODE = 40000;

const int  BUFF_LTH = 200;

const int MAX_SUFFIX_LTH = 11;
char  cpp_suffix[MAX_SUFFIX_LTH] = "cc";

bool  exitOnDupValues = true;


//----------------------------------------------------------------------
-------
// Prototypes.

void show_usage (
    FILE*  fptr = stdout );

void exit_on_error (
    const char*  msg );

char* process_cmd_line (
    int    argn,
    char*  argv[]);

bool match (
    const char* s1,
    const char* s2 );

void parse_line (
    char*          bptr,
    char*          class_name,
    char*          base_class_name,
    Symbol_Pair*&  symbol_pair_ptr,
    Class_State&   class_state,
    Symbol_Vec&    symbol_vec,
    Other_Code&    user_header );

void check_for_duplicates (
    const char*  class_name, 
    Symbol_Vec&  symbol_vec);

void gen_h_code (
    const int    max_lth, 
    const char*  class_name,
    const char*  base_class_name,
    Symbol_Vec&  symbol_vec,
    Other_Code&  user_header,
    Other_Code&  declCode );

void gen_cc_code (
    const int    max_lth, 
    const char*  class_name,
    Symbol_Vec&  symbol_vec, 
    Other_Code&  implCode );

void replace_str (
    char*        buffer,
    const char*  oldstr,
    const char*  newstr );

void add_h_const (
    FILE*         fout,
    const char*   class_name,
    Symbol_Vec&   symbol_vec);

void add_cc_const (
    FILE*        fout,
    const int    max_lth,
    const char*  class_name,
    Symbol_Vec&  symbol_vec);

void add_symbol_code (
    FILE*         fout,
    const char*   current_line,
    const int     max_lth,
    const char*   class_name, 
    Symbol_Vec&   symbol_vec);

FILE* open_file (
    const char*  envvar_name,
    const char*  file_name,
    const char*  option );

//----------------------------------------------------------------------
-------

main (int argn, char* argv[])
{
    char* fname = process_cmd_line (argn, argv);

    // Open the enum definition file.

    FILE*  fin = open_file (NULL, fname, "r");

    Symbol_Vec   symbol_vec;
    Symbol_Pair* symbol_pair_ptr = NULL;

    Class_State  class_state = WAITING_FOR_NEW_ENUM;
    char  class_name[60] = ""; 
    char  base_class_name[60] = ""; 

    char buffer [BUFF_LTH];

    // Loop until the enum class declaration is complete.

    const int  MAX_USER_HEADER_BYTES = 16000;
    Other_Code  user_header ("header", MAX_USER_HEADER_BYTES); 

    while (! feof (fin) && (class_state != CLOSE_BRACE))
    {
        fgets (buffer, BUFF_LTH, fin);
        buffer[strlen (buffer) - 1] = NULL;  // Get rid of end-of-line

        parse_line (buffer, class_name, base_class_name, 
                    symbol_pair_ptr, class_state, symbol_vec,
                    user_header );

        if (class_state == CLOSE_BRACE)
        {
            symbol_vec.push_back (new Symbol_Pair ("_UNDEFINED"));
        }
    }

    // Loop through the remainder of the file to extract any 
    // extensions to the class.

    User_Code_State   ucState = NO_USER_CODE;

    Other_Code  declCode ("user-declaration", MAX_DECL_CODE);
    Other_Code  implCode ("user-implementation", MAX_IMPL_CODE);

    while (! feof (fin))
    {
        fgets (buffer, BUFF_LTH, fin);

        if (strstr (buffer, USER_DECL_MARKER))
        {
            ucState = USER_DECL_CODE;
        }
        else if (strstr (buffer, USER_IMPL_MARKER))
        {
            ucState = USER_IMPL_CODE;
        }
        else if (ucState == USER_DECL_CODE)
        {
            declCode.Add (buffer);
        }
        else if (ucState == USER_IMPL_CODE)
        {
            implCode.Add (buffer);
        }
    }

    fclose (fin);

    // Create the enum files.

    if (symbol_vec.size() > 1)
    {
        printf ("Generating enum class %s...\n", class_name);
        check_for_duplicates (class_name, symbol_vec);

        // Find the longest symbol name.

        int  max_lth = 0;

        Symbol_Vec::iterator  iter = symbol_vec.begin();
        for (; iter != symbol_vec.end(); iter++)
        {
            Symbol_Pair*  sp_ptr = *iter;
            int  lth = strlen (sp_ptr->GetName());
            if (lth > max_lth)
                max_lth = lth;
        }
            
        gen_h_code (max_lth, class_name, base_class_name, symbol_vec, 
                    user_header, declCode);
        gen_cc_code (max_lth, class_name, symbol_vec, implCode);
    }
    else
    {
        printf ("No symbols defined for enum class %s\n", class_name);
    }
}

//----------------------------------------------------------------------
-------

void show_usage (
    FILE*  fptr )
{
    fprintf (stdout, 
            "enum_gen usage:  enum_gen [-suffix source_suffix]\n"
            "                          [-allow_dupl]\n" 
            "                          enum_source_file\n");
}

//----------------------------------------------------------------------
-------

void exit_on_error (
    const char*  msg )
{
    fprintf (stderr, "enum_gen ERROR: %s\n", msg);
    exit (1);
}

//----------------------------------------------------------------------
-------

char* process_cmd_line (
    int    argn,
    char*  argv[])
{
    if (argn < 2)
    {
        show_usage();
        exit (1);
    }

    int  n = 1;
    while ((n < argn) && (argv[n][0] == '-'))
    {
        if (strcmp (argv[n], "-suffix") == 0)
        {
            if (++n >= argn)
                show_usage();
            if (strlen (argv[n]) >= MAX_SUFFIX_LTH)
            {
                char  errmsg[100];
                sprintf (errmsg, "suffix lth exceeds %d chars", 
                         MAX_SUFFIX_LTH - 1);
                exit_on_error (errmsg);
            }
            strcpy (cpp_suffix, argv[n]);
        }

        else if (strcmp (argv[n], "-allow_dupl") == 0)
        {
            exitOnDupValues = false;
        }
        
        else
        {
            char  errmsg[200];
            sprintf (errmsg, "unknown cmd line option: %s", argv[n]);
            show_usage (stderr);
            exit_on_error (errmsg);
        }
        n++;
    }

    if (n >= argn)
    {
        show_usage (stderr);
        exit_on_error ("enum file name not found on cmd line");
    }

    return argv[n];
}
        
//----------------------------------------------------------------------
-------

bool match (
    const char* s1,
    const char* s2 )
{
    return ( strstr (s1, s2) != NULL);
}

//----------------------------------------------------------------------
-------

void parse_line (
    char*          buffPtr,
    char*          class_name, 
    char*          base_class_name, 
    Symbol_Pair*&  symbol_pair_ptr,
    Class_State&   class_state,
    Symbol_Vec&    symbol_vec,
    Other_Code&    user_header )
{
    const char* DELIMS = " ,;";
    char errmsg[100] = "";
    Enum_State  enum_state = WAITING_FOR_SYMBOL;

    char  buffCopy[BUFF_LTH];
    strncpy (buffCopy, buffPtr, BUFF_LTH);
    buffCopy[BUFF_LTH - 1] = NULL;

    const int  MAX_TOKENS = 100;  // should be enough....
    char*      token[MAX_TOKENS];
    int        tokenCount = 0;

    char*  cptr = strtok (buffCopy, DELIMS);
    while (cptr)
    {
        token[tokenCount++] = cptr;
        cptr = strtok (NULL, DELIMS);
    }

    bool  done = false;

    if ( (tokenCount < 1) && (class_state == WAITING_FOR_NEW_ENUM) &&
         (! user_header.Empty()) )
    {
        user_header.Add ("\n");
    }

    for (int n = 0; (n < tokenCount) && ! done; n++)
    {
        cptr = token[n];

        if (match (cptr, "enum"))
        {
            if (class_state != WAITING_FOR_NEW_ENUM)
            {
                sprintf (errmsg, "Found second enum declaration while
enum %s "
                         "is open", class_name);
                exit_on_error (errmsg);
            }
            class_state = WAITING_FOR_CLASS_NAME;
        }

        else if (class_state == WAITING_FOR_NEW_ENUM)
        {
            // If there's any other token on the line before we get the
            // "enum" token, then assume the line is to be added to the
            // header of the enum class.

            user_header.Add (buffPtr);
            user_header.Add ("\n");
            done = true;
        }

        else if (match (cptr, "//"))
        {
            done = true;
        }

        else if (match (cptr, ":"))
        {
            if (class_state != WAITING_FOR_OPEN_BRACE)
            {
                exit_on_error ("parse error on :");
            }
            strcpy (base_class_name, ":");
            class_state = READING_BASE_CLASS;
        }

        else if (match (cptr, "{"))
        {
            if ( (class_state != WAITING_FOR_OPEN_BRACE) &&
                 (class_state != READING_BASE_CLASS) )
            {
                exit_on_error ("parse error on {");
            }
            class_state = OPEN_BRACE;
        }

        else if (match (cptr, "}"))
        {
            if (class_state != OPEN_BRACE)
            {
                exit_on_error ("parse error on }");
            }
            class_state = CLOSE_BRACE;
        }

        // Symbol processing.

        else if (match (cptr, "="))
        {
            if (enum_state != SYMBOL_FOUND)
            {
                exit_on_error ("parse error on =");
            }
            enum_state = WAITING_FOR_VALUE;
        }

        else if ( strpbrk (cptr, "0123456789") == cptr)  
        {
            // It's a number.

            if (enum_state != WAITING_FOR_VALUE)
            {
                sprintf (errmsg, "found unexpected symbol value %s",
cptr);
                exit_on_error (errmsg);
            }
            symbol_pair_ptr->SetValue (cptr);
            enum_state = WAITING_FOR_SYMBOL;
        }

        else 
        {
            if (class_state == WAITING_FOR_CLASS_NAME)
            {
                strcpy (class_name, cptr);
                class_state = WAITING_FOR_OPEN_BRACE;
            }
            else if (class_state == READING_BASE_CLASS)
            {
                strcat (base_class_name, " ");
                strcat (base_class_name, cptr);
                // No change to state -- allows reading of "public",
then
                // the base class name.
            }
            else if ( (enum_state != SYMBOL_FOUND) &&
                      (enum_state != WAITING_FOR_SYMBOL) )
            {
                sprintf (errmsg, "found unexpected symbol %s", cptr);
                exit_on_error (errmsg);
            }
            else
            {
                enum_state = SYMBOL_FOUND;
                symbol_pair_ptr = new Symbol_Pair (cptr);
                symbol_vec.push_back (symbol_pair_ptr);
            }
        }
        cptr = strtok (NULL, DELIMS);
    }
}

//----------------------------------------------------------------------
-------

void check_for_duplicates (
    const char*  class_name, 
    Symbol_Vec&  symbol_vec)
{
    // Issue a warning if there are duplicate values.  While standard
    // enums allow duplicate values (no kidding -- check out K&R), this
    // may not be intended, so we'll give the user a chance to mend his
    // ways.

    bool   foundDupSymbol = false;
    bool   foundDupValue  = false;

    char*  errType = (exitOnDupValues ? "ERROR" : "WARNING");

    Symbol_Vec::iterator  aiter = symbol_vec.begin();
    for (; aiter != symbol_vec.end(); aiter++)
    {
        Symbol_Pair*  aptr = *aiter;
         
        Symbol_Vec::iterator  biter = aiter;
        biter++;
        for (; biter != symbol_vec.end(); biter++)
        {
            Symbol_Pair*  bptr = *biter;

            if (aptr->NameMatches (*bptr))
            {
                fprintf (stdout, 
                         "ERROR: %s symbol %s is declared more than
once\n", 
                         class_name, aptr->GetName());
                foundDupSymbol = true;
            }

            if (aptr->GetValue() == bptr->GetValue())
            {
                fprintf (stdout, 
                         "%s: %s symbols %s and %s both equal %d\n", 
                         errType, class_name, aptr->GetName(),
bptr->GetName(),
                         aptr->GetValue());
                foundDupValue = true;
            }
        }
    }

    if (foundDupSymbol || (foundDupValue && exitOnDupValues))
    {
        fprintf (stdout, "Aborting due previous errors\n");
        exit (1);
    }
}
            
//----------------------------------------------------------------------
-------

void gen_h_code (
    const int    max_lth, 
    const char*  class_name, 
    const char*  base_class_name, 
    Symbol_Vec&  symbol_vec,
    Other_Code&  user_header,
    Other_Code&  declCode )
{
    char  h_file[160] = "";
    strcpy (h_file, class_name);
    strcat (h_file, ".h");

    FILE*  h_out = open_file (NULL, h_file, "w");
    FILE*  h_in  = open_file (ENUM_GEN_ENVVAR, h_boilerplate, "r");

    const char*  first_symbol = symbol_vec[0]->GetName();
    const char*  last_symbol  = symbol_vec[symbol_vec.size() -
2]->GetName();

    char   buffer[BUFF_LTH];

    while (! feof (h_in))
    {
        fgets (buffer, BUFF_LTH, h_in);
        if (strstr (buffer, CONST_CODE_MARKER))
        {
            add_h_const (h_out, class_name, symbol_vec);
        }
        else if (strstr (buffer, SYMBOL_NAME_MARKER))
        {
            add_symbol_code (h_out, buffer, max_lth, class_name,
symbol_vec);
        }
        else if (strstr (buffer, USER_HEADER_MARKER))
        {
            user_header.Dump (h_out);
        }
        else if (strstr (buffer, USER_DECL_MARKER))
        {
            declCode.Dump (h_out);
        }
        else
        {
            replace_str (buffer, CLASS_NAME_MARKER, class_name);
            replace_str (buffer, BASE_CLASS_NAME_MARKER,
base_class_name);
            replace_str (buffer, FIRST_SYMBOL_MARKER, first_symbol);
            replace_str (buffer, LAST_SYMBOL_MARKER, last_symbol);
            fprintf (h_out, "%s", buffer);
        }
    }

    fclose (h_in);
    fclose (h_out);
}

//----------------------------------------------------------------------
-------

void gen_cc_code (
    const int    max_lth,
    const char*  class_name, 
    Symbol_Vec&  symbol_vec,
    Other_Code&  implCode )
{
    // Build the source file name.

    char  cc_file[160] = "";
    strcpy (cc_file, class_name);
    strcat (cc_file, ".");
    strcat (cc_file, cpp_suffix);

    FILE*  cc_out = open_file (NULL, cc_file, "w");
    FILE*  cc_in  = open_file (ENUM_GEN_ENVVAR, cc_boilerplate, "r");

    char   buffer[BUFF_LTH];

    while (! feof (cc_in))
    {
        fgets (buffer, BUFF_LTH, cc_in);
        if (strstr (buffer, CONST_CODE_MARKER))
        {
            add_cc_const (cc_out, max_lth, class_name, symbol_vec);
        }
        else if (strstr (buffer, SYMBOL_NAME_MARKER))
        {
            add_symbol_code (cc_out, buffer, max_lth, class_name,
symbol_vec);
        }
        else if (strstr (buffer, USER_IMPL_MARKER))
        {
            implCode.Dump (cc_out);
        }
        else
        {
            replace_str (buffer, CLASS_NAME_MARKER, class_name);
            fprintf (cc_out, "%s", buffer);
        }
    }

    fclose (cc_in);
    fclose (cc_out);
}

//----------------------------------------------------------------------
-------
// String replacement that can be used to replace one string with
another
// of different length.

void replace_str (
    char*        buffer,
    const char*  oldstr,
    const char*  newstr )
{
    char   newbuff[BUFF_LTH] = "";

    int    oldlth = strlen (oldstr);

    char*  bptr = buffer;
    char*  cptr = NULL;
    do 
    {
        cptr = strstr (bptr, oldstr);
        if (cptr)
        {
            *cptr = NULL;
            strcat (newbuff, bptr);
            strcat (newbuff, newstr);
            bptr += (oldlth + cptr - bptr);
        }
    } while (*bptr && cptr);

    if (bptr != buffer)
    {
        if (*bptr)
           strcat (newbuff, bptr);

        strcpy (buffer, newbuff);
    }
}


//----------------------------------------------------------------------
-------
// Output the static constant symbols declarations.

void add_h_const (
    FILE*        fout,
    const char*  class_name, 
    Symbol_Vec&  symbol_vec)
{
    Symbol_Vec::iterator  iter = symbol_vec.begin();
    for (; iter != symbol_vec.end(); iter++)
    {
        Symbol_Pair*  sp_ptr = *iter;
        fprintf (fout, "    static const %s  %s;\n", 
                 class_name, sp_ptr->GetName());
    }
    fprintf (fout, "\n");
}
        

//----------------------------------------------------------------------
-------
// Output the static constant symbol instances.

void add_cc_const (
    FILE*        fout,
    const int    max_lth,
    const char*  class_name, 
    Symbol_Vec&  symbol_vec)
{
    char  fmt[160];

    // Add the m_defArr declaration.

    fprintf (fout, "%s::EnumDefStruct  %s::m_defArr[] =\n{\n", 
             class_name, class_name);

    // Build the fmt statement for the m_defArr values.

    sprintf (fmt, "    EnumDefStruct ( %%5d, %%-%ds ),\n", max_lth + 2);

    // Output the m_defArr values.

    char  symbol[100];

    Symbol_Vec::iterator  iter = symbol_vec.begin();
    for (; iter != symbol_vec.end(); iter++)
    {
        Symbol_Pair*  sp_ptr = *iter;
/**
        fprintf (fout, "    EnumDefStruct ( %5d, \"%s\" ),\n", 
                 sp_ptr->GetValue(), sp_ptr->GetName());
 **/
        sprintf (symbol, "\"%s\"", sp_ptr->GetName());
        fprintf (fout, fmt, sp_ptr->GetValue(), symbol);
    }
    fprintf (fout, "};\n\n");

    // Build the fmt statement for the const defs.

    sprintf (fmt, "const %%s  %%s::%%-%ds (&m_defArr[%%d]);\n",
max_lth);

    // Add the const definitions.

    int  num = 0;
    iter = symbol_vec.begin();
    for (; iter != symbol_vec.end(); iter++)
    {
        Symbol_Pair*  sp_ptr = *iter;
        fprintf (fout, fmt, class_name, class_name, sp_ptr->GetName(),
num );
        num++;
    }
    fprintf (fout, "\n");
}
        
//----------------------------------------------------------------------
-------
// Generate a copy of the current line for each valid symbol, replacing 
// the SYMBOL_NAME_MARKER with each symbol.

void add_symbol_code (
    FILE*         fout,
    const char*   current_line,
    const int     max_lth,
    const char*   class_name, 
    Symbol_Vec&   symbol_vec)
{
    char  sfmt [40];
    sprintf (sfmt, "%%-%ds", max_lth);

    char  fmt[160];
    strcpy (fmt, current_line);

    replace_str (fmt, CLASS_NAME_MARKER, class_name);
    replace_str (fmt, SYMBOL_NAME_MARKER, sfmt);

    // Output one line for each valid symbol; don't output the last
symbol 
    // in the vector, 'cause it's the UNDEFINED symbol.

    for (int k = 0; k < symbol_vec.size() - 1; k++)
    {
        Symbol_Pair*  sp_ptr = symbol_vec[k];
        fprintf (fout, fmt, sp_ptr->GetName());
    }
    fprintf (fout, "\n");
}


//----------------------------------------------------------------------
-------

FILE* open_file (
    const char*  envvar_name,
    const char*  file_name,
    const char*  option )
{
    char   fname [300] = "";
    if (envvar_name)
    {
        char*  path = getenv (envvar_name);
        if (path)
        {
            strcpy (fname, path);
            strcat (fname, "/");
        }
    }
    strcat (fname, file_name);

    FILE*  fptr = fopen (fname, option);

    if (! fptr)
    {
        char  errmsg[300];
        sprintf (errmsg, "unable to open file %s", fname);
        exit_on_error (errmsg);
    }
    return fptr;
}

//----------------------------------------------------------------------
-------




