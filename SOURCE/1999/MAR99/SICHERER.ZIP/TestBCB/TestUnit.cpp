//---------------------------------------------------------------------------
// TestUnit.cpp - source for TestForm
// test for utility for language independent applications
// version 2.0 - Borland C++ Builder 3.0
// $Id$
// $Log$
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "TestUnit.h"
#include "ui_text.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTestForm *TestForm;
//---------------------------------------------------------------------------
void TranslateGUI(TForm *form)
{
  TTestForm *tform=dynamic_cast<TTestForm *>(form);
  if (tform) {
    tform->Label0->Caption=ZEROTH;
    tform->Label1->Caption=FIRST;
    tform->Label2->Caption=SECOND;
    tform->Label3->Caption=THIRD[0];
    tform->Label4->Caption=THIRD[1];
    tform->Label5->Caption=THIRD[2];
    tform->Label6->Caption=THIRD[3];
    tform->Label7->Caption=THIRD[4];
    tform->Label8->Caption=EIGHTH;
    tform->Label9->Caption=NINTH;
    tform->Label10->Caption=TENTH;
    tform->Label11->Caption=ELEVEN;
    tform->Label12->Caption=TWELVE;
  }
}
//---------------------------------------------------------------------------
__fastcall TTestForm::TTestForm(TComponent* Owner)
    : TForm(Owner)
{
  // comment this line to test the installed component
  Lingua=new TLingua(this);

  Lingua->Language="en";
  char locale[12]="Locale: ";
  GetLocaleInfo(GetUserDefaultLCID(),
    LOCALE_SABBREVLANGNAME,locale+8,3);
  TestForm->RadioButton1->Caption=locale;
}
//---------------------------------------------------------------------------
void __fastcall TTestForm::FormCreate(TObject *Sender)
{
  Lingua->RegisterTranslationFunction(TranslateGUI);
  TranslateGUI(this);
}
//---------------------------------------------------------------------------
void __fastcall TTestForm::RadioClick(TObject *Sender)
{
   switch (((TForm*)Sender)->Tag) {
   case 1:
      Lingua->Language=""; // default locale
      LinguaText->Lines->Clear();
      LinguaText->Lines->Append("");
      LinguaText->Lines->Append(" default locale");
      break;
   case 2:
      Lingua->Language="de";
      LinguaText->Lines->LoadFromFile("de.txt");
      break;
   case 3:
      Lingua->Language="en";
      LinguaText->Lines->LoadFromFile("en.txt");
      break;
   case 4:
      Lingua->Language="es";
      LinguaText->Lines->LoadFromFile("es.txt");
      break;
   case 5:
      Lingua->Language="fr";
      LinguaText->Lines->LoadFromFile("fr.txt");
      break;
   case 6:
      Lingua->Language="nl";
      LinguaText->Lines->LoadFromFile("nl.txt");
      break;
   }
}
//---------------------------------------------------------------------------


 