//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("TestLingua.res");
USEFORM("TestUnit.cpp", TestForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->CreateForm(__classid(TTestForm), &TestForm);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
