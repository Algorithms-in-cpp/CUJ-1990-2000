//---------------------------------------------------------------------------
// Lingua.h - header file for component
// component for language independent applications
// version 2.0 - Borland C++ Builder 3.0
// (C) SichemSoft 1998 - http://www.sichemsoft.nl
// Roghorst 160, 6708 KS Wageningen, Netherlands
// $Id$
// $Log$
//---------------------------------------------------------------------------
#ifndef LinguaH
#define LinguaH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class PACKAGE TLingua : public TComponent
{
private:
   AnsiString FLanguage;
   AnsiString Locale;
   void __fastcall SetLanguage(AnsiString name);
   void (*TranslateGUI)(TForm *form);
   // pointer to be set by the user
protected:
public:
   __fastcall TLingua(TComponent* Owner);
   __fastcall virtual ~TLingua();
   void RegisterTranslationFunction(void (*func)(TForm *));
__published:
   __property AnsiString Language = {read=FLanguage, write=SetLanguage};
};
//---------------------------------------------------------------------------
#endif
