//---------------------------------------------------------------------------
#ifndef TestUnitH
#define TestUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Lingua.h"
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTestForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label11;
    TLabel *Label13;
    TLabel *Label14;
    TLabel *Label15;
    TLabel *Label16;
    TLabel *Label17;
    TLabel *Label18;
    TLabel *Label19;
    TLabel *Label20;
    TLabel *Label21;
    TLabel *Label22;
    TLabel *Label23;
    TLabel *Label24;
    TLabel *Label10;
    TLabel *Label12;
    TBevel *Bevel1;
    TBevel *Bevel2;
    TBevel *Bevel3;
    TBevel *Bevel4;
    TRadioGroup *RadioGroup1;
    TRadioButton *RadioButton1;
    TRadioButton *RadioButton2;
    TRadioButton *RadioButton3;
    TRadioButton *RadioButton4;
    TRadioButton *RadioButton5;
    TRadioButton *RadioButton6;
    TLabel *Label25;
    TStaticText *StaticText1;
    TStaticText *StaticText2;
    TLabel *Label26;
    TMemo *LinguaText;
    TLabel *Label27;
    TBevel *Bevel5;
    TLabel *Label28;
//    TLingua *Lingua;
    TLabel *Label29;
    TLabel *Label0;
    TLingua *Lingua1;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall RadioClick(TObject *Sender);

private:	// User declarations
public:		// User declarations
  TLingua *Lingua;
  __fastcall TTestForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTestForm *TestForm;
//---------------------------------------------------------------------------
#endif
 