/* ui_text.h */

#ifndef UI_TEXT_H
#define UI_TEXT_H

#ifdef __cplusplus
extern "C" {
#endif

int ui_loadtext(char *fname,char *vers);
void ui_unloadtext(void);
char *ui_filetext(unsigned pos);
char **ui_filearray(unsigned pos);
extern char **ui_text;

#define ZEROTH                         ui_text[0]
#define FIRST                          ui_text[1]
#define SECOND                         ui_text[2]
#define THIRD                          (ui_text+3)
#define EIGHTH                         ui_text[8]
#define NINTH                          ui_filetext(0)
#define TENTH                          ui_filetext(1)
#define ELEVEN                         ui_filetext(2)
#define TWELVE                         ui_filetext(3)

#ifdef __cplusplus
}
#endif

#endif

