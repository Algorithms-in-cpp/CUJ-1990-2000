/* ---------------------------------*\
| lingua.h (version 1.4)             |
| Copyright (C) SichemSoft 1995/98   |
| Roghorst 160, 6708 KS Wageningen,  |
| Netherlands. Include for language- |
| independent applications           |
| author: Anneke Sicherer-Roetman,   |
| date: 950804                       |
\* ---------------------------------*/

#ifndef LINGUAH
#define LINGUAH

#define UIT_ENCRYPT 31
#define TRUE         1
#define FALSE        0

#ifdef __MSDOS__

#define readRA   "rb+"
#define writeRA  "wb+"
#define lf       "\r\n"
#define lfchk    ('\r'+'\n')
#define dirsep   '\\'

#else /* UNIX */

#define readRA   "r+"
#define writeRA  "w+"
#define lf       "\n"
#define lfchk    ('\n')
#define dirsep   '/'

#endif

#endif
