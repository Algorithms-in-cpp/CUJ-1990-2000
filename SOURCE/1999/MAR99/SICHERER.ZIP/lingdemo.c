/* (link with ui_text.c, 
    execute: lingdemo english) */

/* lingdemo.c */

#include <stdio.h>
#include "ui_text.h"

int main(int argc,char *argv[])
{
   if (argc!=2) return 1;
   if (ui_loadtext(argv[1],version)) {
      printf("%s",FIRST);
      printf("%s",SECOND);
      printf("%s",THIRD[0]);
      printf("%s",THIRD[1]);
      printf("%s",THIRD[2]);
      printf("%s",THIRD[3]);
      printf("%s",THIRD[4]);
      printf("%s",EIGHTH);
      printf("%s",NINTH);
      printf("%s",TENTH);
      printf("%s",ELEVEN);
      printf("%s",TWELVE);
      ui_unloadtext();
   } else puts("?@!#@#!@?");
   return 0;
}
