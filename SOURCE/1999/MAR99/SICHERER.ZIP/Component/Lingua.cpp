//---------------------------------------------------------------------------
// Lingua.cpp - component source
// component for language independent applications
// version 2.0 - Borland C++ Builder 3.0
// (C) SichemSoft 1998 - http://www.sichemsoft.nl
// Roghorst 160, 6708 KS Wageningen, Netherlands
// $Id$
// $Log$
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Lingua.h"
#include "ui_text.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------
#include "ui_text.c"
//---------------------------------------------------------------------------
// ValidCtrCheck is used to assure that the components created do not have
// do not have any pure virtual functions.
static inline void ValidCtrCheck(TLingua *)
{
  new TLingua(NULL);
}
//---------------------------------------------------------------------------
void __fastcall TLingua::SetLanguage(AnsiString name)
{
  bool defLocale=false;
  if (name.IsEmpty()) {
    name=Locale; defLocale=true;
  }
  FLanguage=name;
  if (ComponentState.Contains(csDesigning)) // only runtime!
    return;
  ui_unloadtext();
  char buffer[100];
  GetModuleFileName(NULL,buffer,100);
  char *p=strrchr(buffer,'\\'); p++;
  strcpy(p,Language.c_str()); strcat(p,".etf");
  strlwr(buffer);
  if (defLocale && Locale.Length()==3 && !FileExists(buffer)) {
     p=strchr(buffer,'.');
     memmove(p-1,p,strlen(p)+1); // remove 3d locale char
  }
  if (ui_loadtext(buffer,"")) {
    for (int i=0; i<Application->ComponentCount; i++) {
      TForm *form=dynamic_cast<TForm*>(Application->Components[i]);
      if (form) {
        if (form->Visible) {
          if (TranslateGUI) {
            TranslateGUI(form);
            form->Invalidate();
          } else
            throw Exception("RegisterTranslationFunction()");
        }
      }
    }
  } else
    throw Exception(buffer);
}
//---------------------------------------------------------------------------
__fastcall TLingua::TLingua(TComponent* Owner)
    : TComponent(Owner)
{
  char locale[4];
  GetLocaleInfo(GetUserDefaultLCID(),
    LOCALE_SABBREVLANGNAME,locale,3);
  Locale=locale;
  TranslateGUI=NULL;
  // to check if user registered one before switching language
}
//---------------------------------------------------------------------------
__fastcall TLingua::~TLingua()
{
  ui_unloadtext();
}
//---------------------------------------------------------------------------
void TLingua::RegisterTranslationFunction(void (*func)(TForm *))
{
  TranslateGUI=func;
  // only necessary if user switches from first language
}
//---------------------------------------------------------------------------
namespace Lingua
{
    void __fastcall PACKAGE Register()
    {
        TComponentClass classes[1] = {__classid(TLingua)};
        RegisterComponents("Extra", classes, 0);
    }
}
//---------------------------------------------------------------------------
