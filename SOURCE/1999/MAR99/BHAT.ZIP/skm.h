class Sliceiter ;

struct scale 
{
	double val ;
	const Sliceiter &ss ;

	scale (const Sliceiter &s1, double d) : ss (s1), val (d) {}
	inline double operator () (int);
} ;

class Sliceiter
{
public :
	size_t start, size ;

private :
	slice s ;
	valarray <double> &v ;

	double &ref  (size_t i) const { return v [start + i] ; }

public :
	Sliceiter (valarray <double> &vv, slice & ss) : v (vv), s (ss)
	{ 
		start = s.start () ;
		size  = s.size  () ;
	}

	Sliceiter (valarray <double> &vv, const Sliceiter &ss) : v (vv), 
	 s (slice (0, ss.size, 1))
	{
		start = s.start () ;
		size  = s.size  () ;

		for (int i = 0 ; i < size ; i ++) at(i) = ss[i] ;
	}

	Sliceiter (valarray <double> &vv, int ind, const Sliceiter &ss) : v (vv), 
	 s (slice(ind - ss.size, ss.size, 1))
	{
		start = s.start () ;
		size  = s.size  () ;
	}

	Sliceiter (Sliceiter &t1, int ind, int len) : v (t1.v), 
	 s (slice (t1.start + ind - len, len, 1))
	{
		start = s.start () ;
		size  = s.size  () ;
	}

	int length () const { return size ; }

	double &at (size_t i) { return ref(i) ; }
	double  at (size_t i) const { return ref(i) ; }

	double &operator [] (size_t i) { return ref(i) ; }
	double  operator [] (size_t i) const { return ref(i) ; }

	Sliceiter &operator = (const Sliceiter &s2) 
	{
		for (int i = 0 ; i < size ; i++) at(i) = s2[i] ;
		return *this ;
	}

	scale operator *(double val) 
	{
		return scale(*this, val);
	}

	Sliceiter &operator -= (scale &scn)
	{
		for (int i = 0 ; i < size ; i ++) at(i) -= scn(i) ;
		return *this ;
	}

	Sliceiter &operator /= (const Sliceiter &s2)
	{
		for (int i = 0 ; i < size ; i ++) at(i) /= s2[i] ;
		return *this ;
	}

	double dot_product (const Sliceiter &s2) const
	{
		int    i;
		double res;
		for (i = 0, res = 0.0 ; i < size ; i ++) res += at(i) * s2[i] ;

		return res ;
	}
	friend bool operator == (const Sliceiter &p, const Sliceiter &q)
	{
		return (p.size == q.size) ;
	}

	friend bool operator < (const Sliceiter &p, const Sliceiter &q)
	{
		return (p.size < q.size) ;
	}
} ;

class SkylineMatrix
{
private :
	size_t d1, sz ;
private :
	vector <int> addr ;
	valarray <double> *v, *diag, *wk2 ;
private :
	vector <Sliceiter *> stv ;
public :
	SkylineMatrix () ;

	void set (size_t, size_t) ;
	size_t dim  () const { return d1 ; }

	valarray <double> &array ()     { return *v ; }
	valarray <double> &diagarray () { return *diag ; }
	valarray <double> &tmparray  () { return *wk2  ; }

	double &diagelement (int index) { return (*diag) [index] ; }

	void fill_array (int) ;
	int  read_SkylineMatrix (ifstream &, size_t) ;

	int first_row (int j, int k1) const
	{
		return __min (j, addr[k1 + 1] - addr[k1]) ;
	}
	Sliceiter &column (size_t i) { return *(stv[i]) ; }
	~SkylineMatrix () ;
} ;