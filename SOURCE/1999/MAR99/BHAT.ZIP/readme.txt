Comparision of FORTRAN 90 and C++ Valarrays.

The programs used for the benchmarks, referred in the article are 
enclosed here.
C++ : skm.cpp and skm.h
F90 : skm.f90

The data is in the two 'txt' files, data5.txt and data.txt which
correspond to the 3rd and 4th rows of the tests. The data, which is
in ASCII format is as follows.
Row 1 : Number of columns in the matrix .. ndf
for i = 1 to ndf
    Row 2 : Number of values in column i
    Row 3 : Double precision values, starting from diagonal upwards in 
	    the column.
next i

The int SkylineMatrix :: read_SkylineMatrix (ifstream & fp, size_t maxlen)
member function reads in the  matrix from this file. We have
used the ifstream class for file reading, which is much slower than
fscanf. This may give the impression that the C++ program is slower.
However, time measurement is done starting after the file reading only.
The arguments to the program are , the input file name and the size of
the matrix. These are:
 data5 320000
 data  530000
In an actual implementation, the size would be known, before the 
SkylineMatrix object is created, and hence it is not computed within the
object.

Time measurement is done using the qtime.c . The same may be used for
the FORTRAN program also. We have also used the DATE_AND_TIME(TIME = stim(rtim))
intrinsic function, with the same results. Hence either can be used.

The C++ program was compiled with Maximise speed under VC++ 5.0, and
warnings set to none. The Fortran program was compiled under PowerStation
4.0, with Full optimisation. The PC used was a Pentium 150 (Non MMX), 
with a 48MB RAM, and 200MB free disk space, under NT 4.0 Build 1481.

The C++ program is complete, whereas the Fortran program does not contain
the read and setting up of the matrices. However, the procedure is
already explained in the article.

Any queries may be directed to the authors, and we will be glad to clarify.
