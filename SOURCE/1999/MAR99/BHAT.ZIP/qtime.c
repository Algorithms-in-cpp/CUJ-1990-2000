#include <stdio.h>
#include <sys/timeb.h>
#include <time.h>

static struct _timeb timebuffer[20];
static int ik = 0;

void notetime()
{
	_ftime( &timebuffer[ik++] );
}

void printtimestat()
{
   char *timeline;
   int i;

   printf("Time Statistics\n");
   
   for (i = 0; i < ik; i++)
   {
	   timeline = ctime( & ( timebuffer[i].time ) );
	   printf( "Case %2d time is %.19s.%hu %s", i, timeline, timebuffer[i].millitm, &timeline[20] );
   }
}