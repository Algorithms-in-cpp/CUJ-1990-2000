# include <iostream>
# include <fstream>
# include <valarray>
# include <stdio.h>
# include <vector>
# include <math.h>

using namespace std ;

# include "skm.h"

extern "C"
{
	void notetime();
	void printtimestat();
}

inline SkylineMatrix :: SkylineMatrix ()
{
}

inline SkylineMatrix :: ~SkylineMatrix ()
{
	addr.clear () ;
	stv.clear  () ;

	delete v, diag, wk2 ;
}

inline void SkylineMatrix :: set (size_t x, size_t maxlen) 
{
	sz = 0 ;
	d1 = x ;

	addr.resize  (d1 + 1) ;
	stv.reserve (d1) ;

	wk2  = new valarray <double> (0., d1) ;
	v    = new valarray <double> (0., maxlen) ;

	diag = new valarray <double> (0., d1) ;
}

inline int SkylineMatrix :: read_SkylineMatrix (ifstream & fp, size_t maxlen)
{
	int size, nrow, ht1, ht2 = 0 ;
	
	fp >> size;
	set (size, maxlen) ;

	fp >> nrow >> (*diag)[0] ;
	
	addr    [0] = 0 ;
	
	for (int i = 1 ; i < size ; i ++)
	{
		fp >> nrow;
		ht1 = nrow - 1 ;

		fp >> (*diag)[i];

		for (int j = 0 ; j < ht1 ; j ++)
			fp >> (*wk2) [j];
		
		addr [i] = addr[i - 1] + ht2 ;
		fill_array (ht1) ;

		ht2 = ht1 ;
		stv  [i] = new Sliceiter (*v, slice (addr[i], ht1, 1)) ;
	}

	addr[d1] = addr[d1 - 1]  + ht1 ;
	return d1 ;
}

inline void SkylineMatrix :: fill_array (int ht)
{
	for (int i = ht - 1 ; i >= 0 ; i --) 
		(*v) [sz ++] = (*wk2) [i] ;
}

inline double scale :: operator () (int i) 
{
	return ss[i] * val ;
}

void read_rhs (ifstream &fp, int d1, valarray <double> &rhs)
{
	int nlod ;

	fp >> nlod;
	for (int i = 0 ; i < d1 ; i ++)
	{
		fp >> rhs[i];
	}
}

void decompose (SkylineMatrix &mt)
{
	int i, j, k1, kk, size, d1 ;

	valarray <double> &diag = mt.diagarray () ;
	valarray <double> &wtmp = mt.tmparray  () ;

	d1 = mt.dim () ;

	for (i = 1 ; i < d1 ; i ++)
	{
		Sliceiter &t1 = mt.column (i) ;
		size = t1.size;
		
		for (j = 1 , k1  = i - size; j < size ; j ++)
		{
			Sliceiter &t2 = mt.column (k1 + j) ;

			kk  = mt.first_row (j, k1 + j) ;
			t1[j] -= Sliceiter (t2, t2.size, kk).dot_product (Sliceiter (t1, j, kk)) ;
		}

		Sliceiter t2 = Sliceiter (diag, i, t1) ;
		Sliceiter t3 = Sliceiter (wtmp, t1) ;

		t1 /= t2 ;

		diag[i] -= t1.dot_product(t3);
	}
}

void backsub (SkylineMatrix &mt, valarray <double> &rhs) 
{
	int d1 = mt.dim () ;

	for (int i = 1 ; i < d1 ; i ++)
	{
		Sliceiter &s1 = mt.column (i) ;
		rhs[i] -= s1.dot_product (Sliceiter (rhs, i, s1)) ;
	}

	rhs /= mt.diagarray () ;
	
	for (int j = d1 - 1 ; j > 0 ; j --)
	{
		Sliceiter &s1 = mt.column (j) ;
		Sliceiter s2  = Sliceiter (rhs, j, s1) ;

		s2 -= s1 * rhs[j] ;
	}
}

void solve (SkylineMatrix &mt, valarray <double> &rhs)
{
	notetime();
	decompose (mt) ;
	notetime();
	backsub (mt, rhs) ;
	notetime();
	printtimestat();
	for (int i = 0; i < rhs.size(); i++)
		printf("%4d %12.3f\n", i, rhs[i]);
}

void main (int narg, char **args)
{
	if (narg < 3)
	{
		cout << "Usage : ctest.exe datafilename totalsize\n";
		exit(0);
	}
	SkylineMatrix mt ;
	valarray <double> *rhs ;

	ifstream fp;
	fp.open(args[1]);
	if (fp.fail()) 
	{
		cout << "Error opening file\n";
		exit(0);
	}
	size_t maxlen = atoi(args[2]);
	if (maxlen < 1024) maxlen = 1024;

	int d1 = mt.read_SkylineMatrix (fp, maxlen) ;

	rhs  = new valarray <double> (0., d1) ;
	read_rhs (fp, d1, *rhs) ;
	fp.close();

	solve (mt, *rhs) ;
}
