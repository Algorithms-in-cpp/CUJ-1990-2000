#include "cips.h"

short **out_image;

main(argc, argv)
   int argc;
   char *argv[];
{
   char     name[80];
   char     *cc;
   double   da, db, dc, dd;
   int      alpha, beta;
   int      count, i, ie, ii, il, j, jj, le, l, ll, k,
            new_ie, new_il, set_i, set_j, square_size, w;
   int      ok = 0;
   long     cols, rows;
   struct   tiff_header_struct image_header;
   struct bmpfileheader      bmp_file_header;
   struct bitmapheader       bmheader;


      /**************************************
      *                      
      *   Command Line
      *                      
      **************************************/

   if(argc < 4 ){
      printf("\n usage: pattern file-name "
             "length width\n");
      exit(-1);
   }

   strcpy(name, argv[1]);
   l = atoi(argv[2]);
   w = atoi(argv[3]);

      /**************************************
      *                      
      *   Pre Processing
      *                      
      **************************************/

   cc = strstr(argv[1], ".tif");
   if(cc != NULL){  /* create a tif */
      ok = 1;
      image_header.lsb            = 1;
      image_header.bits_per_pixel = 8;
      image_header.image_length   = l;
      image_header.image_width    = w;;
      image_header.strip_offset   = 1000;
      rows = image_header.image_length;
      cols = image_header.image_width;
      create_allocate_tiff_file(argv[1], 
                                &image_header);
   }  /* ends tif */

   cc = strstr(argv[1], ".bmp");
   if(cc != NULL){  /* create a bmp */
      ok = 1;
      bmheader.height = l;
      bmheader.width  = w;
      rows = bmheader.height;
      cols = bmheader.width;
      create_allocate_bmp_file(argv[1], 
                               &bmp_file_header, 
                               &bmheader);
   }  /* ends tif */

   if(ok == 0){
      printf("\nERROR input file neither tiff nor bmp");
      exit(0);
   }

   out_image = allocate_image_array(l, w);

      /**************************************
      *                      
      *   Processing
      *                      
      **************************************/


      /* These lines of code make the simple
         blocks for the examples of 
         images 5 and 6.  */

   for(i=0; i<rows; i++)
      for(j=0; j<cols; j++)
        out_image[i][j] = 200;


   make_square(30, 30, 30, 100, out_image);
   make_square(50, 50, 30, 100, out_image);

      /* These lines of code make the 
         rolling hills of 
         images 2 and 8.  */

   for(i=0; i<rows; i++)
      for(j=0; j<cols; j++)
        out_image[i][j] = 0;


   for(i=0; i<rows; i++){
      for(j=0; j<cols; j++){
         count = distance(i, 49, j, 49);
         da = count/8.0;
         db = sin(da);
         db = db*12;
         if(db < 0.0) db = 0.0;
         count = db;
         out_image[i][j] = count;
      }
   }

      /**************************************
      *                      
      *   Post Processing
      *                      
      **************************************/

   write_image_array(name, out_image);
   free_image_array(out_image, l, w);

}  /* ends main */



make_square(x, y, size, level, image)
   short **image;
   int   x, y, size, level;
{
   int i, j;

   for(i=y; i<y+size; i++)
      for(j=x; j<x+size; j++)
             out_image[i][j] = level;

}  /* ends make_square */

