#include "stdafx.h"

#include "crtdbg.h"
#include <stdlib.h>
#include <map>

using namespace std;

static void **blk[257];

static bool bInitialized = false, bEnabled = false;

void DiscardFastHeap()
{
    for(size_t n = 0; n < sizeof(blk) / sizeof(blk[0]); n++)
    {
        void **p = blk[n];
        while(p != NULL)
        {
            void **pOld = p;
            p = (void**)*p;
            free(pOld);
        }
        blk[n] = NULL;
    } 
}

void EnableFastHeap()
{
    bEnabled = true;
}

void DisableFastHeap()
{
    DiscardFastHeap();
    bEnabled = false;
}

void *operator new(size_t size)
{
#ifdef _DEBUG_CHK_MEM
    _CrtCheckMemory( );
#endif
    if(size == 0)
        return(NULL);
    if(bInitialized == false)
    {
        memset(blk, 0, sizeof(blk));
        bInitialized = true;
    }
    size_t AllocSize = size + 1;
    size_t BlkPos = size - 16;

    void **p = NULL;
    if(BlkPos < 255)
    {
        if(blk[BlkPos] != NULL)
        {
            p = blk[BlkPos];
            blk[BlkPos] = (void**)*p;
            *(unsigned char*)p = (unsigned char)BlkPos;
        }
        else
            p = (void**)malloc(AllocSize);
        *(unsigned char*)p = BlkPos;
    }
    else
    {
        p = (void**)malloc(AllocSize);
        if(p == NULL)
        {
            DiscardFastHeap();
            p = (void**)malloc(AllocSize);
            if(p == NULL)
                throw("out of memory");
        }
        *(unsigned char*)p = 255;
    }

    return(((char*)p) + 1);
}

void operator delete(void *pUserData)
{
#ifdef _DEBUG_CHK_MEM
    _CrtCheckMemory( );
#endif
    if(pUserData != NULL)
    {
        void **p = (void**)((unsigned char*)pUserData - 1);
        size_t BlkPos = *((unsigned char*)p);
        if(BlkPos == 255 || bEnabled == false)
            free(p);
        else
        {
            *(void**)p = blk[BlkPos];
            blk[BlkPos] = p;
        }
    }
}


