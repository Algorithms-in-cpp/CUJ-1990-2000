#ifndef RND_SMATRIX_H
#define RND_SMATRIX_H

#include "smatrix.h"
#include <stdlib.h>

template <class t> class TRandom
{
public:
    double Min, Max;

    TRandom(double Min, double Max)
    {
        this->Min = Min;
        this->Max = Max;
    }
    operator t() 
    {
        double d(rand());
        d *= (Max - Min);
        d /= RAND_MAX;
        d += Min;
        return(d);
    }
};

namespace sm {

template <class t, class tRnd> class TRndSolvable : 
    public smatrix<t>
{
public:
    TRndSolvable(size_t dim, double Min, double Max, 
        size_t MaxNZ) : smatrix<t>(dim, dim, MaxNZ)
    {
        TRandom<tRnd> RndCoef(Min, Max);
        TRandom<size_t> RndIndex(1, dim);
        for(size_t n = 1; n <= dim; n++)
            insert(n, n, RndCoef);

        int Dist = 1;
        n = 1;
        while(NZ < MaxNZ)
        {
            if(n + Dist <= dim)
                insert(n, n + Dist, RndCoef);
            if((size_t)(n - Dist) <= dim && (n - Dist) >= 1)
                insert(n, n - Dist, RndCoef);
            if(++n > dim)
            {
                n = 1;
                Dist++;
            }
        }

        // Shuffle Rows
        for(n = 1; n <= dim; n++)
            PivotRow(n, RndIndex);

        // Shuffle Cols
        for(n = 1; n <= dim; n++)
            PivotCol(RndIndex, n);
    }
};

template <class t, class tRnd> class TRndSMatrix : 
    public smatrix<t>
{
public:
    TRndSMatrix(size_t iDim, size_t jDim, double Min, 
        double Max, size_t MaxNZ) : smatrix<t>(iDim, jDim, MaxNZ)
    {
        TRandom<tRnd> RndCoef(Min, Max);
        TRandom<size_t> iRnd(1, ((double)iDim) + .9999);
        TRandom<size_t> jRnd(1, ((double)jDim) + .9999);

        while(NZ < MaxNZ)
            Coef(iRnd, jRnd) = RndCoef;
    }
};

template <class t, class tRnd> class TRndDMatrix : 
    public smatrix<t>
{
public:
    TRndDMatrix(size_t iDim, size_t jDim, double Min, 
        double Max) : smatrix<t>(iDim, jDim, iDim * jDim)
    {
        TRandom<tRnd> RndCoef(Min, Max);

        for(size_t i = 1; i <= iDim; i++)
        {
            for(size_t j = 1; j <= jDim; j++)
                insert(i, j, RndCoef);
        }
    }
};

}

#endif

