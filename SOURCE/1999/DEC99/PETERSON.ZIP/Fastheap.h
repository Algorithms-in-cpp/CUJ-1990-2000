#ifndef FASTHEAP_H
#define FASTHEAP_H

void DiscardFastHeap();
void EnableFastHeap();
void DisableFastHeap();


#endif


