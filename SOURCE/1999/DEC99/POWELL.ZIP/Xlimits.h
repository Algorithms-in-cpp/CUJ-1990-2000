#if !defined(_XLIMITS_H)
#define _XLIMITS_H

#if defined(_MSC_VER)
#if _MSC_VER > 1000
#pragma once
#endif
#endif

/* ========================================================================
 * Copyright (c) 1999 
 * Gary Powell
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *
   ======================================================================== */
/* ------------------------------------------------------------------------
   Sub Includes
   ------------------------------------------------------------------------ */
#include <limits>
/* ------------------------------------------------------------------------
   Defines and Compile Flags
   ------------------------------------------------------------------------ */
/* ------------------------------------------------------------------------
   Enums
   ------------------------------------------------------------------------ */
/* ------------------------------------------------------------------------
   Typedefs
   ------------------------------------------------------------------------ */
/* ------------------------------------------------------------------------
   Macros   
   ------------------------------------------------------------------------ */
/* ------------------------------------------------------------------------
   Class Definition
   ------------------------------------------------------------------------ */

/* ------------------------------------------------------------------------
   Global Variables
   ------------------------------------------------------------------------ */

/* ------------------------------------------------------------------------
   Prototypes
   ------------------------------------------------------------------------ */

/* ------------------------------------------------------------------------
   Inline functions   
   ------------------------------------------------------------------------ */

// These are some templated fns to derive the correct value from the type
// of the variable itself.
//
// eg.
// set a variable to its max limit.
// fVar = xlimits::max(fVar);
//
// I'm trying to duplicate the interface to <limits> so I added the throw()
// 

// The namespace xlimits was chosen to mean "extended limits."
namespace xlimits {

template <class T>
inline T min(T const &) throw()
{
	return std::numeric_limits<T>::min();
}

template <class T>
inline T max(T const &) throw()
{
	return std::numeric_limits<T>::max();
}

template <class T>
inline T epsilon(T const &) throw()
{
	return std::numeric_limits<T>::epsilon();
}

template <class T>
inline T round_error(T const &) throw()
{
	return std::numeric_limits<T>::round_error();
}

template <class T>
inline T denorm_min(T const &) throw()
{
	return std::numeric_limits<T>::denorm_min();
}

template <class T>
inline T infinity(T const &) throw()
{
	return std::numeric_limits<T>::infinity();
}

template <class T>
inline T quiet_NaN(T const &) throw()
{
	return std::numeric_limits<T>::quiet_NaN();
}

template <class T>
inline T signaling_NaN(T const &) throw()
{
	return std::numeric_limits<T>::signaling_NaN();
}

template <class T>
inline bool is_bounded(T const &) throw()
{
	return std::numeric_limits<T>::is_bounded();
}

template <class T>
inline bool is_exact(T const &) throw()
{
	return std::numeric_limits<T>::is_exact();
}

template <class T>
inline bool is_iec559(T const &) throw()
{
	return std::numeric_limits<T>::is_iec559();
}

template <class T>
inline bool is_integer(T const &) throw()
{
	return std::numeric_limits<T>::is_integer();
}

template <class T>
inline bool is_modulo(T const &) throw()
{
	return std::numeric_limits<T>::is_modulo();
}

template <class T>
inline bool is_specialized(T const &) throw()
{
	return std::numeric_limits<T>::is_specialized();
}

template <class T>
inline int radix(T const &) throw()
{
	return std::numeric_limits<T>::radix();
}

template <class T>
inline bool has_denorm(T const &) throw()
{
	return std::numeric_limits<T>::has_denorm();
}

template <class T>
inline bool has_denorm_loss(T const &) throw()
{
	return std::numeric_limits<T>::has_denorm_loss();
}

template <class T>
inline bool has_infinity(T const &) throw()
{
	return std::numeric_limits<T>::has_infinity();
}

template <class T>
inline bool has_quiet_NaN(T const &) throw()
{
	return std::numeric_limits<T>::has_quiet_NaN();
}

template <class T>
inline bool has_signaling_NaN(T const &) throw()
{
	return std::numeric_limits<T>::has_signaling_NaN();
}

template <class T>
inline bool is_signed(T const &) throw()
{
	return std::numeric_limits<T>::is_signed();
}

template <class T>
inline bool tinyness_before(T const &) throw()
{
	return std::numeric_limits<T>::tinyness_before();
}

template <class T>
inline bool traps(T const &) throw()
{
	return std::numeric_limits<T>::traps();
}

template <class T>
inline std::float_round_style round_style(T const &) throw()
{
	return std::numeric_limits<T>::round_style();
}

template <class T>
inline int digits(T const &) throw()
{
	return std::numeric_limits<T>::digits();
}

template <class T>
inline int digits10(T const &) throw()
{
	return std::numeric_limits<T>::digits10();
}

template <class T>
inline int max_exponent(T const &) throw()
{
	return std::numeric_limits<T>::max_exponent();
}

template <class T>
inline int max_exponent10(T const &) throw()
{
	return std::numeric_limits<T>::max_exponent10();
}

template <class T>
inline int min_exponent(T const &) throw()
{
	return std::numeric_limits<T>::min_exponent();
}

template <class T>
inline int min_exponent10(T const &) throw()
{
	return std::numeric_limits<T>::min_exponent10();
}

}
   
#endif // _XLIMITS_H

