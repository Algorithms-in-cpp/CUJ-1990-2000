/* ========================================================================
   Copyright (c) 1999 Sierra On-Line, Inc. (R) and/or TM designate
   trademarks of, or licensed to Sierra On-Line, Inc., Bellevue WA 98007.
   Sierra Sports a divsion of Sierra On-Line, Inc. a wholly owned subsidary of
   Havas Interactive.
   All Rights Reserved
   ========================================================================
   Filename: FILENAME.cpp  -
   Author:   Gary Powell
   Description:
   

   
   ======================================================================== */

/* ------------------------------------------------------------------------
   Includes
   ------------------------------------------------------------------------ */
#include "xlimits.h"

#include <iostream>
#include <cassert>
/* ------------------------------------------------------------------------
   Notes
   ------------------------------------------------------------------------ */
using std::cout;
using std::endl;
using std::numeric_limits;
/* ------------------------------------------------------------------------
   Defines and Compile Flags
   ------------------------------------------------------------------------ */
   
/* ------------------------------------------------------------------------
   Macros
   ------------------------------------------------------------------------ */
   
/* ------------------------------------------------------------------------
   Class Definitions
   ------------------------------------------------------------------------ */
// A demo fixed point math class.
class Fixed10Dot6
{
public:
	enum { NUMBER_OF_DECIMALS = 6};
private:
	typedef short	rawDataType;

	rawDataType data;

	rawDataType convert2Fixed10Dot6(double x)
	{
		rawDataType r(static_cast<rawDataType>(x - .5));
		x -= r;
		r <<= NUMBER_OF_DECIMALS;

		double bitvalue(0.5);
		for(int bit(1 << (NUMBER_OF_DECIMALS - 1)); bit && x; bit >>= 1)
		{
			if (bitvalue <= x)
			{
				x -= bitvalue;
				r |= bit;	// set the bit.
			}
			bitvalue /= 2.0;
		}

		return r;
	}
public:
	inline Fixed10Dot6()	{}
	inline Fixed10Dot6(int x)
		:	data(x << NUMBER_OF_DECIMALS)
	{
		assert (x < std::numeric_limits<Fixed10Dot6>::max() );	// just test.
	}

	inline Fixed10Dot6(double x)
		: data(convert2Fixed10Dot6(x))
	{}
	
	inline friend std::ostream &operator<<(std::ostream &os, Fixed10Dot6 &x)
	{
		double fractionalPart(0.0);
		double bitvalue(0.5);

		for(int bit(1 << (NUMBER_OF_DECIMALS - 1)); bit; bit >>= 1)
		{
			if (bit & x.data)
			{
				fractionalPart += bitvalue;
			}
			bitvalue /= 2.0;
		}
		os << ((x.data >> NUMBER_OF_DECIMALS) + fractionalPart);
		return os;
	}

	inline friend bool const operator<(int x, Fixed10Dot6 y)
	{
		return ((x << NUMBER_OF_DECIMALS) < y.data);
	}
};

template<>
Fixed10Dot6 std::numeric_limits<Fixed10Dot6>::max()
{
	return (Fixed10Dot6((numeric_limits<short>::max() >> Fixed10Dot6::NUMBER_OF_DECIMALS)
		+ 1.0/2.0	// written out so you can see how the bits are used.
		+ 1.0/4.0
		+ 1.0/8.0
		+ 1.0/16.0
		+ 1.0/32.0
		+ 1.0/64.0)
		);
}
/* ------------------------------------------------------------------------
   Prototypes
   ------------------------------------------------------------------------ */

/* ------------------------------------------------------------------------
   Global Variables
   ------------------------------------------------------------------------ */

/* ------------------------------------------------------------------------
   Local Variables
   ------------------------------------------------------------------------ */

int main()
{
	short x;
	Fixed10Dot6 y(0.5);
	Fixed10Dot6 z(1);

	cout << y << endl;

	cout << std::numeric_limits<short>::max() << endl;

	cout << xlimits::max(x) << endl;

	cout << xlimits::max(y) << endl;

	return 0;
}
