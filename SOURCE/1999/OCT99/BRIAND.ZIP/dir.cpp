//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop


#include "dir.h"

bool Directory::setCurrentPath(const string &cp)
{
  string oldpath = curr_path;
  curr_path = cp;
  if(!pathIsValid())
  {
    curr_path = oldpath;
    return false;
  }
  return true;
}

bool Directory::pathIsValid() const
{
  string oldpath = GetCurrentDir().c_str();
  bool valid = SetCurrentDir(curr_path.c_str());
  SetCurrentDir(oldpath.c_str());
  return valid;
}

bool Directory::getSubdirNames(vector<string> &sbn) const
{
  if(!pathIsValid())
    return false;

  TSearchRec sr;
  int iattributes = faDirectory;
  // get directories
  string temppath = curr_path;
  if(temppath[temppath.size()-1] != '\\')
    temppath += "\\";
  temppath += "*.*";
  if(FindFirst(temppath.c_str(), iattributes, sr) == 0)
  {
    if(sr.Attr == iattributes)
    {
      sbn.push_back(sr.Name.c_str());
    }
  }
  while(FindNext(sr) == 0)
  {
    if(sr.Attr == iattributes)
    {
      sbn.push_back(sr.Name.c_str());
    }
  }
  FindClose(sr);

  // remove . and .. from directory vector
  for(vector<DirAdapter::CompositeHandle>::iterator i = sbn.begin();
      i != sbn.end(); i++)
  {
    if(*i == ".")
    {
      sbn.erase(i);
      break;
    }
  }
  for(vector<DirAdapter::CompositeHandle>::iterator j = sbn.begin();
      j != sbn.end(); j++)
  {
    if(*j == "..")
    {
      sbn.erase(j);
      break;
    }
  }
  return true;
}

bool Directory::getFileNames(vector<string> &fn) const
{
  if(!pathIsValid())
    return false;

  TSearchRec sr;
  int iattributes = faReadOnly | faHidden | faSysFile | faVolumeID | faArchive;
  string temppath = getCurrentPath();
  if(temppath[temppath.size()-1] != '\\')
    temppath += "\\";
  temppath += "*.*";
  if(FindFirst(temppath.c_str(), iattributes, sr) == 0)
  {
    fn.push_back(sr.Name.c_str());
  }
  while(FindNext(sr) == 0)
  {
    fn.push_back(sr.Name.c_str());
  }
  FindClose(sr);
  return true;
}

void
DirAdapter::getHandles
  (Directory &dir, vector<CompositeHandle> &cvec,
   vector<SimpleHandle> &svec)
{
  dir.getSubdirNames(cvec);
  dir.getFileNames(svec);
}

bool DirAdapter::moveDownTo(Directory &dir, const CompositeHandle &ch)
{
   string newpath = dir.getCurrentPath();
   if(newpath[newpath.size()-1] != separator)
     newpath += separator;
   newpath += ch;

   return dir.setCurrentPath(newpath);
}

bool DirAdapter::moveUp(Directory &dir)
{
  string newpath = dir.getCurrentPath();
  if(newpath.size() >= 2)
  {
    for(int i = newpath.size()-2; i >= 0; --i)
    {
      if(newpath[i] == separator)
      {
        string::iterator j = newpath.begin() + i;
        newpath.erase(j, newpath.end());
        break;
      }
    }
    return dir.setCurrentPath(newpath);
  }
  return false;
}

NamePrinter::NamePrinter(const string &outfile, char sep)
  : DirAdapter(sep)
{
  fout.open(outfile.c_str(), ios::out);
  if(!fout)
    throw "can't open output file";
}

bool NamePrinter::processComposite
  (Directory &dir, const CompositeHandle &ch)
{
  cout << ch << "...DIR" << endl;
  fout << ch << "...DIR" << endl;
  return true;
}

bool NamePrinter::processSimple
  (Directory &dir, const SimpleHandle &sh)
{
  cout << sh << "...FILE" << endl;
  fout << sh << "...FILE" << endl;
  return true;
}

//---------------------------------------------------------------------------
#pragma package(smart_init)
