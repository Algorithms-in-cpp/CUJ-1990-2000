//---------------------------------------------------------------------------
#ifndef dirH
#define dirH

#include <string>
#include <vector>
#include <iostream>
#include <fstream>

using namespace std;


class Directory
{
   string curr_path;
public:
   Directory(const string &cp) : curr_path(cp) {}
   string getCurrentPath() const {return curr_path;}
   bool setCurrentPath(const string &cp);
   bool pathIsValid() const;
   bool getSubdirNames(vector<string> &sbn) const;
   bool getFileNames(vector<string> &fn) const;
};

class DirAdapter
{
  char separator;
public:
  DirAdapter(char sep = '\\') : separator(sep) {};
  virtual ~DirAdapter() {}
  typedef string CompositeHandle;
  typedef string SimpleHandle;
  void getHandles(Directory &dir, vector<CompositeHandle> &cvec,
                       vector<SimpleHandle> &svec);
  bool moveDownTo(Directory &dir, const CompositeHandle &ch);
  bool moveUp(Directory &dir);
};

class NamePrinter : public DirAdapter
{
  fstream fout;
public:
  NamePrinter(const string &outfile, char sep = '\\');
  ~NamePrinter() {fout.close();}
  bool processComposite(Directory &dir, const CompositeHandle &ch);
  bool processSimple(Directory &dir, const SimpleHandle &sh);
};

class DirectoryCounter : public DirAdapter
{
  int count;
public:
  DirectoryCounter() : count(0) {}
  bool processComposite(Directory &dir, const CompositeHandle &ch)
  {count++;}
  bool processSimple(Directory &dir, const SimpleHandle &ch)
  {}
  int getCount() const {return count;}
  void setCount(int n = 0) {count = n;}
};

class FileCounter : public DirAdapter
{
   int count;
public:
   FileCounter() : count(0) {}
   bool processComposite(Directory &dir, const CompositeHandle &ch)
   {}
   bool processSimple(Directory &dir, const SimpleHandle &sh)
   {count++;}
   int getCount() const {return count;}
   void setCount(int n = 0) {count = n;}
};

//---------------------------------------------------------------------------
#endif
