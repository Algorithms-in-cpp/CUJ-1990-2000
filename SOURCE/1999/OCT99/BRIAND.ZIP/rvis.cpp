#include <condefs.h>
#pragma hdrstop

#include "dir.h"
#include "compos.h"

//---------------------------------------------------------------------------
USEUNIT("dir.cpp");
USEUNIT("compos.cpp");
//---------------------------------------------------------------------------
int main()
{
   NamePrinter nprinter("outfile.txt");
   Directory dir("c:\\proj\\compos");

   rVisit(dir, nprinter);

   FileCounter fcounter;
   rVisit(dir, fcounter);
   cout << "Number of files is " << fcounter.getCount() << endl;

   return 0;
}
