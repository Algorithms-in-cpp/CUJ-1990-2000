//---------------------------------------------------------------------------
#ifndef composH
#define composH

#include <cassert>
#include <vector>
#include <deque>

using namespace std;

//---------------------------------------------------------------------------


template <class CompositeType, class ProcessType>
int rVisit(CompositeType &cobj, ProcessType &pobj)
{
  deque<ProcessType::CompositeHandle> cdeq;
  deque<int> ndeq; // number of composites at current level
  vector<ProcessType::SimpleHandle> svec;
  vector<ProcessType::CompositeHandle> tempcvec;

  int depth = 0;
  bool searching = true;
  bool done = false;
  int count = 0;

  while(!done)
  {
    if(searching)
    {
      svec.erase(svec.begin(), svec.end());
      tempcvec.erase(tempcvec.begin(), tempcvec.end());
      pobj.getHandles(cobj, tempcvec, svec);
      ndeq.push_back(tempcvec.size());
      // push CompositeHandles to stack
      for(int i = tempcvec.size()-1; i >= 0; --i)
        cdeq.push_back(tempcvec[i]);
      for(int i = 0; i < tempcvec.size(); ++i)
      {
        pobj.processComposite(cobj, tempcvec[i]);
        count++;
      }
      for(int j = 0; j < svec.size(); ++j)
      {
        pobj.processSimple(cobj, svec[j]);
        count++;
      }
      searching = false;
    }
    else
    {
      if(ndeq.back() > 0)
      {
        pobj.moveDownTo(cobj, cdeq.back());
        assert(cdeq.size() > 0);
        cdeq.pop_back();
        ndeq.back()--;
        depth++;
        searching = true;
      }
      else
      {
        if(depth > 0)
        {
          assert(ndeq.size() > 0);
          ndeq.pop_back();
          pobj.moveUp(cobj);
          depth--;
        }
        else
        {
          assert(ndeq.size() > 0);
          ndeq.pop_back();
          done = true;
        }
      }
    }
  }
  assert(ndeq.size() == 0);
  assert(cdeq.size() == 0);
  assert(depth == 0);
  return count;
}

#endif
