#ifndef __RESOURCE_H__
#define __RESOURCE_H__

#include <memory>

#include "dphase.h"
#include "destructor.h"

using namespace std;

class Resource {
  typedef auto_ptr<Resource> ResourcePtr;

  static ResourcePtr& get_instance();
  static void destroy_instance() { delete get_instance().release(); }
  
  Resource();
  ~Resource();
  
  friend class auto_ptr<Resource>;
  friend class TDestructor<Resource>;
  
  Resource(const Resource&);
  Resource& operator=(const Resource&);

  bool status();

public:
  // singleton interface
  static Resource& instance() { return *get_instance(); }
  static const Resource& const_instance() { return instance(); }

  void process();
};

#endif // __RESOURCE_H__

