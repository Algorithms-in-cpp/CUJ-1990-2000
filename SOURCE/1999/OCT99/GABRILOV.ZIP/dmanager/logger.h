#ifndef __LOGGER_H__
#define __LOGGER_H__

#include <memory>
#include <string>

#include "dphase.h"
#include "destructor.h"

using namespace std;

class Logger {
  typedef auto_ptr<Logger> LoggerPtr;

  static LoggerPtr& get_instance();
  static void destroy_instance() 
  { delete get_instance().release(); }
  
  Logger();
  ~Logger();
  
  friend class auto_ptr<Logger>;
  friend class TDestructor<Logger>;
  
  Logger(const Logger&);
  Logger& operator=(const Logger&);

public:
  // singleton interface
  static Logger& instance() { return *get_instance(); }
  static const Logger& const_instance() { return instance(); }

  void log(string message);
};

#endif // __LOGGER_H__

