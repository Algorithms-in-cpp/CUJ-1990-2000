#include <iostream>
#include <string>

#include "dphase.h"
#include "destructor.h"
#include "logger.h"

using namespace std;

Logger::LoggerPtr& Logger::get_instance() 
{
  static LoggerPtr the_logger(new Logger);

  return the_logger;
}

Logger::Logger()
{
  new TDestructor<Logger>(this, DestructionPhase(1));

  cout << "Logger created" << endl;
}

Logger::~Logger()
{
  cout << "Logger destroyed" << endl;
}
  
void Logger::log(string message)
{ 
  cerr << "Logger: " << message << endl;
}

