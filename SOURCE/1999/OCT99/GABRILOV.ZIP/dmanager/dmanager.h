#ifndef __DMANAGER_H__
#define __DMANAGER_H__

#include <memory>
#include <vector>

using namespace std;

class Destructor; // forward declaration

class DestructionManager {
  typedef auto_ptr<DestructionManager> DestructionManagerPtr;

  vector<Destructor*> m_destructors;

  static DestructionManagerPtr& get_instance();
  
  DestructionManager() {} 
  ~DestructionManager();
  
  friend class auto_ptr<DestructionManager>;
  
  DestructionManager(const DestructionManager&);
  DestructionManager& operator=(const DestructionManager&);

public:
  // singleton interface
  static DestructionManager& instance() { return *get_instance(); }
  static const DestructionManager& const_instance() { return instance(); }

  void register_destructor(Destructor* destructor)
  { m_destructors.push_back(destructor); }
  
  void destroy_objects(); // destroy the objects
};

#endif // __DMANAGER_H__

