#include "dmanager.h"
#include "resource.h"
#include "logger.h"

void main(void)
{
  // some code
  Resource::instance().process();

  DestructionManager::instance().destroy_objects();
}


