#ifndef __DESTRUCTOR_H__
#define __DESTRUCTOR_H__

#include "dphase.h"
#include "dmanager.h"

class Destructor {
  DestructionPhase m_dphase;
public:
  Destructor(DestructionPhase dphase) : m_dphase(dphase)
  { DestructionManager::instance().register_destructor(this); }
  
  bool operator>(const Destructor& destructor) const
  { return m_dphase > destructor.m_dphase; }

  virtual void destroy() = 0;
};

template <class T> class TDestructor : public Destructor {
  T* m_object;
public:
  TDestructor(T* object, DestructionPhase dphase)
    : Destructor(dphase), m_object(object) {}

  void destroy() { m_object->destroy_instance(); }
};

#endif // __DESTRUCTOR_H__

