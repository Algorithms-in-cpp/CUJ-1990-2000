#include <iostream>
#include <string>

#include "dphase.h"
#include "destructor.h"
#include "logger.h"
#include "resource.h"

using namespace std;

Resource::ResourcePtr& Resource::get_instance() 
{
  static ResourcePtr the_resource(new Resource);

  return the_resource;
}

bool Resource::status()
{
  return false;
}

Resource::Resource()
{
  new TDestructor<Resource>(this, DestructionPhase(2));
 
  cout << "Resource created" << endl;
}

Resource::~Resource()
{
  if (!status())
    Logger::instance().log("Resource destructor detected bad status");
  
  cout << "Resource destroyed" << endl;
}
  
void Resource::process()
{ 
  cout << "Resource in process" << endl;

  if (!status())
    Logger::instance().log("Resource process detected bad status");
}


