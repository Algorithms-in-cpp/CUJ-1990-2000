#ifndef __DPHASE_H__
#define __DPHASE_H__

class DestructionPhase {
  int m_phase;  // the smaller the phase, 
                // the later the object should be destroyed
public:
  explicit DestructionPhase (int phase) : m_phase(phase) {}

  bool operator> (const DestructionPhase& dp) const 
  { return m_phase > dp.m_phase; }
};

#endif // __DPHASE_H__

