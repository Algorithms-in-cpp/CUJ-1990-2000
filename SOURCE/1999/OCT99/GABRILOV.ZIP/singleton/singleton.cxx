#include "singleton.h"

Singleton::SingletonPtr& Singleton::get_instance()
{
  static SingletonPtr the_singleton(new Singleton);
  
  return the_singleton;
}


