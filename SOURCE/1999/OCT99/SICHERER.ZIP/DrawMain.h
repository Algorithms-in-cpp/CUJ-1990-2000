//----------------------------------------------
// Filename:      DrawMain.h
// Programmer:    Anneke Sicherer-Roetman
// Email:         sicherer@sichemsoft.nl
// Version:       1.00
// Revision Date: 19990606
// Description:   DrawBoxDemo Form
//----------------------------------------------
#ifndef DrawMainH
#define DrawMainH
//----------------------------------------------
#include <vcl\sysutils.hpp>
#include <vcl\windows.hpp>
#include <vcl\messages.hpp>
#include <vcl\sysutils.hpp>
#include <vcl\classes.hpp>
#include <vcl\graphics.hpp>
#include <vcl\controls.hpp>
#include <vcl\forms.hpp>
#include <vcl\dialogs.hpp>
#include <vcl\stdctrls.hpp>
#include <vcl\buttons.hpp>
#include <vcl\extctrls.hpp>
#include <vcl\menus.hpp>
#include <Buttons.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <Forms.hpp>
#include "CGRID.h"
#include "DrawBox.h"
#include "DrawList.h"
//----------------------------------------------
class TMainForm : public TForm
{
__published:
   TMainMenu *MainMenu;
   TMenuItem *FileNewItem;
   TMenuItem *FileOpenItem;
   TMenuItem *FileSaveItem;
   TMenuItem *FileSaveAsItem;
   TMenuItem *FilePrintItem;
   TMenuItem *FilePrintSetupItem;
   TMenuItem *FileExitItem;
   TMenuItem *EditCopyItem;
   TMenuItem *EditDeleteItem;
   TMenuItem *ViewZoomInItem;
   TMenuItem *ViewZoomOutItem;
   TMenuItem *ViewNormalItem;
   TMenuItem *AboutItem;
   TOpenDialog *OpenDialog;
   TSaveDialog *SaveDialog;
   TPrintDialog *PrintDialog;
   TPrinterSetupDialog *PrintSetupDialog;
   TPanel *SpeedBar;
   TPanel *PaletteBar;
   TPanel *CoordPanel;
   TSpeedButton *NewButton;
   TSpeedButton *OpenButton;
   TSpeedButton *SaveButton;
   TSpeedButton *PrintButton;
   TSpeedButton *CopyButton;
   TSpeedButton *DeleteButton;
   TSpeedButton *ZoomInButton;
   TSpeedButton *ZoomOutButton;
   TSpeedButton *ZoomButton;
   TSpeedButton *ArrowButton;
   TSpeedButton *LineButton;
   TSpeedButton *RectButton;
   TSpeedButton *RoundRectButton;
   TSpeedButton *EllipseButton;
   TSpeedButton *InvertButton;
   TSpeedButton *TextButton;
   TCColorGrid *ColorGrid;
   TSpeedButton *HollowButton;
   TSpeedButton *CrossHairsButton;
   TDrawBox *DrawBox;
   void __fastcall FileNew(TObject *S);
   void __fastcall FileOpen(TObject *S);
   void __fastcall FileSave(TObject *S);
   void __fastcall FileSaveAs(TObject *S);
   void __fastcall FilePrint(TObject *S);
   void __fastcall FilePrintSetup(TObject *S);
   void __fastcall FileExit(TObject *S);
   void __fastcall EditCopy(TObject *S);
   void __fastcall EditDelete(TObject *S);
   void __fastcall ViewZoomInItemClick(TObject *S);
   void __fastcall ViewZoomOutItemClick(TObject *S);
   void __fastcall ViewNormalItemClick(TObject *S);
   void __fastcall AboutItemClick(TObject *S);
   void __fastcall ArrowButtonClick(TObject *S);
   void __fastcall LineButtonClick(TObject *S);
   void __fastcall RectButtonClick(TObject *S);
   void __fastcall RoundRectButtonClick(TObject *S);
   void __fastcall EllipseButtonClick(TObject *S);
   void __fastcall InvertButtonClick(TObject *S);
   void __fastcall TextButtonClick(TObject *S);
   void __fastcall ColorGridChange(TObject *S);
   void __fastcall HollowButtonClick(TObject *S);
   void __fastcall CrossHairsButtonClick(TObject *S);
   void __fastcall DrawBoxPaint(TObject *S);
   void __fastcall DrawBoxClick(TObject *S,
          double X, double Y);
   void __fastcall DrawBoxMarked(TObject *S,
          double Left, double Top,
          double Right, double Bottom);
   void __fastcall DrawBoxMouseMove(TObject *S,
          TShiftState Shift, double X, double Y);
private:        // private user declarations
   int Range;          // viewport range
   bool Invert;        // invert function on
   TColor PenColor;    // current pen color
   TColor BrushColor;  // current brush color
   TDrawList *DrawList;// list with objects
   AnsiString FileName;// current filename
   TDrawItem *SelectedItem; // selected object
   TDrawItem *MarkerItem;   // marker in list
   void Initialize();  // initialize transform
   void ClearSelection(); // no sel. object
public:         // public user declarations
   virtual __fastcall TMainForm(TComponent* Owner);
   virtual __fastcall ~TMainForm();
};
//----------------------------------------------
extern TMainForm *MainForm;
//----------------------------------------------
#endif
