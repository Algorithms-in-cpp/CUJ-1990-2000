Source code archive for CUJ article:

TDrawBox -
An interactive drawing surface Borland C++ Builder component

To install TDrawBox:
Choose Component | Install component and set the unit file name to drawbox.cpp. 
Add the component to a new or existing package, compile and install.

To build DrawBoxDemo.exe:
Choose File | Open Project, select DrawBoxDemo.bpr. 
Then Press F9 to compile and run.

I'd welcome feedback from you!

Anneke Sicherer-Roetman, sicherer@sichemsoft.nl
