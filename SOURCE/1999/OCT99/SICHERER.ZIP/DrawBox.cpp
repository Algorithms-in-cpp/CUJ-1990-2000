//----------------------------------------------
// Filename:      DrawBox.cpp
// Programmer:    Anneke Sicherer-Roetman
// Email:         sicherer@sichemsoft.nl
// Version:       1.00
// Revision Date: 19990606
// Description:   Implementation of TDrawBox
//----------------------------------------------
// Portability Issues - Win32 functions
// Used:             In:
// SetViewportOrgEx  ::Print
// GetCursorPos      TDrawBox::ScrollIfNeeded
// CreateRectRgn     TDrawBox::CreateMetafile
// SelectClipRgn     TDrawBox::CreateMetafile
// InvertRect        TDrawBox::DrawInvert/Marker
//                   TDrawBoxSurface::DrawCaret
//                   (strangely TCanvas misses
//                    an InvertRect analogon)
//----------------------------------------------
#include <vcl.h>
#include <assert.h>
#include <clipbrd.hpp>
#include <stdarg.h>
#include <stdlib.h>
#pragma hdrstop
//----------------------------------------------
#include "DrawBox.h"
#pragma package(smart_init)

//----------------------------------------------
// constants for cursor movement and marker size
//----------------------------------------------
const int LINEUP    = SB_LINEUP + 1;
const int LINELEFT  = SB_LINELEFT + 1;
const int LINEDOWN  = SB_LINEDOWN + 1;
const int LINERIGHT = SB_LINERIGHT + 1;
const int PAGEUP    = SB_PAGEUP + 1;
const int PAGELEFT  = SB_PAGELEFT + 1;
const int PAGEDOWN  = SB_PAGEDOWN + 1;
const int PAGERIGHT = SB_PAGERIGHT + 1;
const int TOP       = SB_TOP + 1;
const int LEFT      = SB_LEFT + 1;
const int BOTTOM    = SB_BOTTOM + 1;
const int RIGHT     = SB_RIGHT + 1;
const int MARKER    = 4;

//----------------------------------------------
// helper functions
//----------------------------------------------
inline void Swap(int &a, int &b)
{ int tmp = a; a = b; b = tmp; }

static bool Print(const AnsiString &jobName,
   TPrinter *printer, TMetafile *metafile,
   unsigned int from, unsigned int to,
   unsigned int copies, bool collate);

//----------------------------------------------
// Function TDrawBox::TDrawBox
// constructor
// TComponent* Owner : owner component
//----------------------------------------------
__fastcall
TDrawBox::TDrawBox(TComponent* Owner)
  : inherited(Owner)
{
   // create drawing surface
   Surface = new TDrawBoxSurface(this);
   Canvas = Surface->Canvas;

   // set default values for properties
   BorderStyle = bsSingle;
   Caret       = false;
   Color       = clWhite;
   CrossHairs  = false;
   Cursor      = oldCursor = crCross;
   Height      = 97;
   MarkShape   = msNone;
   ScaleFont   = false;
   Width       = 185;

   // set values for other variables
   ViewportWidth  = Width;
   ViewportHeight = Height;
   xw1 = 0; xw2 = ViewportWidth;
   yw1 = 0; yw2 = ViewportHeight;
   a = c = 1.0;
   b = d = 0.0;
   PrintThread = NULL;

   // set scrollbar attributes
   HorzScrollBar->Range = ViewportWidth;
   VertScrollBar->Range = ViewportHeight;
   HorzScrollBar->Tracking = true;
   VertScrollBar->Tracking = true;
}

//----------------------------------------------
// Function TDrawBox::~TDrawBox
// destructor
//----------------------------------------------
__fastcall
TDrawBox::~TDrawBox() // virtual
{
   // if printthread is running, terminate it
   if (PrintThread)
      PrintThread->Terminate();

   // destroy drawing surface
   delete Surface;
}

//----------------------------------------------
// Function TDrawBox::SetWindowExtents
// sets total drawing area in world coordinates
// returns : nothing
// double x1 : top left x coordinate
// double y1 : top left y coordinate
// double x2 : bottom right x coordinate
// double y2 : bottom right y coordinate
//----------------------------------------------
void
TDrawBox::SetWindowExtents(double x1, double y1,
                           double x2, double y2)
{
   assert(x1 != x2 && y1 != y2);

   int oldC = c;
   xw1 = x1; yw1 = y1;
   xw2 = x2; yw2 = y2;
   SetTransformation();
   if (ScaleFont) {
      Font->Size = Font->Size * c / oldC;
      // unfortunately, TFont does only
      // give access to the font's height,
      // not the font's width
   }
}

//----------------------------------------------
// Function TDrawBox::GetWindowExtents
// gets total drawing area in world coordinates
// returns : nothing
// double* x1 : top left x coordinate
// double* y1 : top left y coordinate
// double* x2 : bottom right x coordinate
// double* y2 : bottom right y coordinate
//----------------------------------------------
void
TDrawBox::GetWindowExtents(double *x1,
                           double *y1,
                           double *x2,
                           double *y2) const
{
   *x1 = xw1; *y1 = yw1;
   *x2 = xw2; *y2 = yw2;
}

//----------------------------------------------
// Function TDrawBox::SetWindowOrigin
// scrolls window so origin is at top left
// returns : nothing
// double x : x coordinate of origin
// double y : y coordinate of origin
//----------------------------------------------
void
TDrawBox::SetWindowOrigin(double x, double y)
{
   int xx, yy;
   WorldtoPC(x, y, &xx, &yy);
   HorzScrollBar->Position = xx;
   VertScrollBar->Position = yy;
}
//----------------------------------------------
// Function TDrawBox::GetWindowOrigin
// returns window origin coordinates
// returns : nothing
// double* x : x coordinate of origin
// double* y : y coordinate of origin
//----------------------------------------------
void
TDrawBox::GetWindowOrigin(double *x,
                          double *y) const
{
   PCtoWorld(HorzScrollBar->Position,
             VertScrollBar->Position, x, y);
}

//----------------------------------------------
// Function TDrawBox::RecalculateTransformation
// recalculates viewing transformation
// NOTE: This routine can be called if desired
// after a the range of a scrollbar is changed.
// This is needed because there seems to be no
// way the drawbox can be notified of changes
// in the ranges of its scrollbars.
// returns : nothing
//----------------------------------------------
void TDrawBox::RecalculateTransformation()
{
   SetTransformation();
}

//----------------------------------------------
// Function TDrawBox::CopyToClipboardAsEMF
// saves (part of) image to clipboard as emf
// returns : success (bool)
// double x1 : top left x coordinate (default 0)
// double y1 : top left y coordinate (default 0)
// double x2 : bottom right x coordinate (def. 0)
// double y2 : bottom right y coordinate (def. 0)
//----------------------------------------------
bool
TDrawBox::CopyToClipboardAsEMF(double x1,
                               double y1,
                               double x2,
                               double y2)
{
   return Save("", true, x1, y1, x2, y2);
}

//----------------------------------------------
// Function TDrawBox::CopyToClipboardAsBMP
// saves (part of) image to clipboard as bmp
// returns : success (bool)
// double x1 : top left x coordinate (default 0)
// double y1 : top left y coordinate (default 0)
// double x2 : bottom right x coordinate (def. 0)
// double y2 : bottom right y coordinate (def. 0)
//----------------------------------------------
bool
TDrawBox::CopyToClipboardAsBMP(double x1,
                               double y1,
                               double x2,
                               double y2)
{
   return Save("", false, x1, y1, x2, y2);
}

//----------------------------------------------
// Function TDrawBox::SaveToFileAsEMF
// saves (part of) image to file as emf
// returns : success (bool)
// const AnsiString& filename : name of file
// double x1 : top left x coordinate (default 0)
// double y1 : top left y coordinate (default 0)
// double x2 : bottom right x coordinate (def. 0)
// double y2 : bottom right y coordinate (def. 0)
//----------------------------------------------
bool
TDrawBox::SaveToFileAsEMF(const AnsiString &file,
                          double x1, double y1,
                          double x2, double y2)
{
   return Save(file, true, x1, y1, x2, y2);
}

//----------------------------------------------
// Function TDrawBox::SaveToFileAsBMP
// saves (part of) image to file as bmp
// returns : success (bool)
// const AnsiString& filename : name of file
// double x1 : top left x coordinate (default 0)
// double y1 : top left y coordinate (default 0)
// double x2 : bottom right x coordinate (def. 0)
// double y2 : bottom right y coordinate (def. 0)
//----------------------------------------------
bool
TDrawBox::SaveToFileAsBMP(const AnsiString &file,
                          double x1, double y1,
                          double x2, double y2)
{
   return Save(file, false, x1, y1, x2, y2);
}

//----------------------------------------------
// Function TDrawBox::Print
// prints entire image
// returns : nothing
// const AnsiString& jobName : name of print job
// unsigned int      from    : first page (def.0)
// unsigned int      to      : last page (def. 0)
// unsigned int      copies  : nr. of copies (1)
// bool              collate : collate pages? (+)
//----------------------------------------------
void
TDrawBox::Print(const AnsiString &jobName,
                unsigned int from,
                unsigned int to,
                unsigned int copies,
                bool collate)
{
   Print(jobName, xw1, yw1, xw2, yw2,
         from, to, copies, collate);
}

//----------------------------------------------
// Function TDrawBox::Print
// prints part of image
// returns : nothing
// const AnsiString& jobName : name of print job
// double            x1      : top left x
// double            y1      : top left y
// double            x2      : bottom right x
// double            y2      : bottom right y
// unsigned int      from    : first page (def.0)
// unsigned int      to      : last page (def. 0)
// unsigned int      copies  : nr. of copies (1)
// bool              collate : collate pages? (+)
//----------------------------------------------
void
TDrawBox::Print(const AnsiString &jobName,
                double x1, double y1,
                double x2, double y2,
                unsigned int from,
                unsigned int to,
                unsigned int copies,
                bool collate)
{
   // create metafile with copy
   // of specified window
   TMetafile *metafile =
      CreateMetafile(x1, y1, x2, y2);
   if (!metafile) {
      NotifyPrintDone(jobName, false);
      return;
   }

   // request pointer to current printer
   TPrinter *printer = Printer();

   if (!PrintThread) // thread printing
      PrintThread=
         new TDrawBoxPrintThread(this, jobName,
            printer, metafile, from, to,
            copies, collate);
   else {            // no thread printing
      bool result =
         ::Print(jobName, printer, metafile,
                 from, to, copies, collate);
      NotifyPrintDone(jobName, result);
   }
}

//----------------------------------------------
// Function TDrawBox::CountPrintPages
// returns number of print pages in image
// returns : number of print pages in image(uint)
//----------------------------------------------
unsigned int
TDrawBox::CountPrintPages() const
{
   // NOTE: this depends on the current printer!
   TPrinter *printer = Printer();

   // compute magnification from resolutions
   int screenResolution = Screen->PixelsPerInch;
   int printerResolution =
      printer->Canvas->Font->PixelsPerInch;
   float factor =
      1.0 * printerResolution / screenResolution;

   // compute size of drawing on printer canvas
   unsigned int pictureWidth =
      (int)(HorzScrollBar->Range * factor + 0.5);
   unsigned int pictureHeight=
      (int)(VertScrollBar->Range * factor + 0.5);

   // compute total number of print pages
   return (pictureWidth /
           printer->PageWidth + 1) *
          (pictureHeight /
           printer->PageHeight + 1);
}

//----------------------------------------------
// Function TDrawBox::Clear
// clears entire image
// returns : nothing
//----------------------------------------------
void
TDrawBox::Clear()
{
   DrawClear(xw1, yw1, xw2, yw2);
}

//----------------------------------------------
// Function TDrawBox::DrawLine
// draws line
// returns : nothing
// double x1 : first x coordinate
// double y1 : first y coordinate
// double x2 : second x coordinate
// double y2 : second y coordinate
//----------------------------------------------
void
TDrawBox::DrawLine(double x1, double y1,
                   double x2, double y2)
{
   int xx1, yy1, xx2, yy2;
   WorldtoPC(x1, y1, &xx1, &yy1);
   WorldtoPC(x2, y2, &xx2, &yy2);
   Canvas->MoveTo(xx1, yy1);
   Canvas->LineTo(xx2, yy2);
}

//----------------------------------------------
// Function TDrawBox::DrawPolyLine
// draws polyline
// returns : nothing
// unsigned n : number of vertices
// double x   : first vertex x coordinate
// double y   : first vertex y coordinate
// ...        : next x and y coordinates
//----------------------------------------------
void TDrawBox::DrawPolyLine(unsigned n,
                            double x, double y,
                            ...)
{
	assert(n >= 1);
	int xx, yy;
	WorldtoPC(x, y, &xx, &yy);
   Canvas->MoveTo(xx, yy);
   va_list ap;	va_start(ap, y);
	for (unsigned i = 0; i < n; ++i) {
      x = va_arg(ap, double);
      y = va_arg(ap, double);
		WorldtoPC(x, y, &xx, &yy);
      Canvas->LineTo(xx, yy);
	}
	va_end(ap);
}

//----------------------------------------------
// Function TDrawBox::DrawRectangle
// draws rectangle
// returns : nothing
// double x1 : top left x coordinate
// double y1 : top left y coordinate
// double x2 : bottom right x coordinate
// double y2 : bottom right y coordinate
//----------------------------------------------
void
TDrawBox::DrawRectangle(double x1, double y1,
                        double x2, double y2)
{
   assert(x1 <= x2 && y1 <= y2);
   int xx1, yy1, xx2, yy2;
   WorldtoPC(x1, y1, &xx1, &yy1);
   WorldtoPC(x2, y2, &xx2, &yy2);
   Canvas->Rectangle(xx1, yy1, xx2, yy2);
}

//----------------------------------------------
// Function TDrawBox::DrawRoundRect
// draws rectangle with rounded corners
// returns : nothing
// double x1 : top left x coordinate
// double y1 : top left y coordinate
// double x2 : bottom right x coordinate
// double y2 : bottom right y coordinate
//----------------------------------------------
void
TDrawBox::DrawRoundRect(double x1, double y1,
                        double x2, double y2)
{
   assert(x1 <= x2 && y1 <= y2);
   int xx1, yy1, xx2, yy2;
   WorldtoPC(x1, y1, &xx1, &yy1);
   WorldtoPC(x2, y2, &xx2, &yy2);
   Canvas->RoundRect(xx1, yy1, xx2, yy2,
      (xx1 - xx2) / 2, (yy1 - yy2) / 2);
}

//----------------------------------------------
// Function TDrawBox::DrawEllipse
// draws ellipse
// returns : nothing
// double x1 : top left x coordinate
// double y1 : top left y coordinate
// double x2 : bottom right x coordinate
// double y2 : bottom right y coordinate
//----------------------------------------------
void
TDrawBox::DrawEllipse(double x1, double y1,
                      double x2, double y2)
{
   assert(x1 <= x2 && y1 <= y2);
   int xx1, yy1, xx2, yy2;
   WorldtoPC(x1, y1, &xx1, &yy1);
   WorldtoPC(x2, y2, &xx2, &yy2);
   Canvas->Ellipse(xx1, yy1, xx2, yy2);
}

//----------------------------------------------
// Function TDrawBox::DrawText
// draws text
// returns : nothing
// double            x : top left x coordinate
// double            y : top left y coordinate
// const AnsiString& s : text to display
//----------------------------------------------
void
TDrawBox::DrawText(double x, double y,
                   const AnsiString &s)
{
   int xx, yy;
   WorldtoPC(x, y, &xx, &yy);
   Canvas->TextOut(xx, yy, s);
}

//----------------------------------------------
// Function TDrawBox::DrawClear
// clears rectangular area
// returns : nothing
// double x1 : top left x coordinate
// double y1 : top left y coordinate
// double x2 : bottom right x coordinate
// double y2 : bottom right y coordinate
//----------------------------------------------
void
TDrawBox::DrawClear(double x1, double y1,
                    double x2, double y2)
{
   assert(x1 <= x2 && y1 <= y2);
   // remember current pen and brush
   TPen *oldPen = new TPen;
   oldPen->Assign(Canvas->Pen);
   TBrush *oldBrush = new TBrush;
   oldBrush->Assign(Canvas->Brush);

   // create pen and brush in background color
   TPen *newPen = new TPen;
   newPen->Color = Color;
   Canvas->Pen->Assign(newPen);
   TBrush *newBrush = new TBrush;
   newBrush->Color = Color;
   Canvas->Brush->Assign(newBrush);

   // draw rectangle in background color
   int xx1, yy1, xx2, yy2;
   WorldtoPC(x1, y1, &xx1, &yy1);
   WorldtoPC(x2, y2, &xx2, &yy2);
   Canvas->Rectangle(xx1, yy1, xx2, yy2);

   // reset current pen and brush
   Canvas->Pen->Assign(oldPen);
   Canvas->Brush->Assign(oldBrush);
   delete oldPen; delete newPen;
   delete oldBrush; delete newBrush;
}

//----------------------------------------------
// Function TDrawBox::DrawInvert
// inverts rectangular area
// returns : nothing
// double x1 : top left x coordinate
// double y1 : top left y coordinate
// double x2 : bottom right x coordinate
// double y2 : bottom right y coordinate
//----------------------------------------------
void
TDrawBox::DrawInvert(double x1, double y1,
                     double x2, double y2)
{
   RECT rect;
   int xx1, yy1, xx2, yy2;
   WorldtoPC(x1, y1, &xx1, &yy1);
   WorldtoPC(x2, y2, &xx2, &yy2);
   rect.left = xx1; rect.top = yy1;
   rect.right = xx2; rect.bottom = yy2;
   ::InvertRect(Canvas->Handle, &rect);
}

//----------------------------------------------
// Function TDrawBox::DrawMarker
// draws marker (small inverted rectange)
// returns : nothing
// double x : x coordinate
// double y : y coordinate
//----------------------------------------------
void
TDrawBox::DrawMarker(double x, double y)
{
   RECT rect;
   int xx, yy;
   WorldtoPC(x, y, &xx, &yy);
   rect.left = xx - MARKER;
   rect.top = yy - MARKER;
   rect.right = xx + MARKER;
   rect.bottom = yy + MARKER;
   ::InvertRect(Canvas->Handle, &rect);
}

//----------------------------------------------
// Function TDrawBox::SetCaretPosition
// sets caret on specified position
// returns : nothing
// double x : x coordinate
// double y : y coordinate
//----------------------------------------------
void
TDrawBox::SetCaretPosition(double x, double y)
{
   int xx, yy;
   WorldtoPC(x, y, &xx, &yy);
   Surface->SetCaret(xx, yy);
}

//----------------------------------------------
// Function TDrawBox::GetCaretX
// returns horizontal caret position
// returns : horizontal caret position (double)
//----------------------------------------------
double
TDrawBox::GetCaretX() const
{
   double x, y;
   PCtoWorld(Surface->CaretX, Surface->CaretY,
             &x, &y);
   return x;
}

//----------------------------------------------
// Function TDrawBox::GetCaretY
// returns vertical caret position
// returns : vertical caret position (double)
//----------------------------------------------
double
TDrawBox::GetCaretY() const
{
   double x, y;
   PCtoWorld(Surface->CaretX, Surface->CaretY,
             &x, &y);
   return y;
}

//----------------------------------------------
// Function TDrawBox::GetMarkBox
// returns marked box coordinates
// returns : marked (bool)
// double* x1 : top left x coordinate
// double* y1 : top left y coordinate
// double* x2 : bottom right x coordinate
// double* y2 : bottom right y coordinate
//----------------------------------------------
bool
TDrawBox::GetMarkBox(double *x1, double *y1,
                     double *x2, double *y2)
{
   if (!Surface->Marked)
      return false;
   PCtoWorld(Surface->OriginX,
             Surface->OriginY, x1, y1);
   PCtoWorld(Surface->MarkedX,
             Surface->MarkedY, x2, y2);
   return true;
}
//----------------------------------------------
// Function TDrawBox::GetTextExtents
// determines text size of string in current font
// returns : nothing
// double* width  : width of string
// double* height : height of string
//----------------------------------------------
void
TDrawBox::GetTextExtents(const AnsiString &string,
                         double *width,
                         double *height)
{
   int x1 = 0;
   int x2 = Canvas->TextWidth(string);
   int y1 = 0;
   int y2 = Canvas->TextHeight(string);

   double xw1, yw1, xw2, yw2;
   PCtoWorld(x1, y1, &xw1, &yw1);
   PCtoWorld(x2, y2, &xw2, &yw2);

   *width = abs(xw2 - xw1);
   *height = abs(yw2 - yw1);
}
//----------------------------------------------
// Function TDrawBox::CreateParams
// special handling for borderstyle
//          (copied from TScrollBox)
// returns : nothing
// TCreateParams& Params : standard parameter
//----------------------------------------------
void __fastcall
TDrawBox::CreateParams(TCreateParams &Params)
{
   inherited::CreateParams(Params);
   Params.Style |=
      (FBorderStyle == bsSingle ? WS_BORDER : 0);
   if (NewStyleControls && Ctl3D &&
       FBorderStyle == bsSingle) {
      Params.Style &= ~WS_BORDER;
      Params.ExStyle |= WS_EX_CLIENTEDGE;
   }
}

//----------------------------------------------
// Function TDrawBox::SetBorderStyle
// sets borderstyle (copied from TScrollBox)
// returns : nothing
// TBorderStyle style : bsNone / bsSingle
//----------------------------------------------
void __fastcall
TDrawBox::SetBorderStyle(TBorderStyle style)
{
  if (style != FBorderStyle) {
    FBorderStyle = style;
    RecreateWnd();
  }
}

//----------------------------------------------
// Function TDrawBox::SetBrush
// sets current brush
// returns : nothing
// TBrush* brush : new brush
//----------------------------------------------
void __fastcall
TDrawBox::SetBrush(TBrush *brush)
{
   Canvas->Brush->Assign(brush);
}

//----------------------------------------------
// Function TDrawBox::GetBrush
// sets current brush
// returns : current brush (TBrush*)
//----------------------------------------------
TBrush* __fastcall
TDrawBox::GetBrush() const
{
   return Canvas->Brush;
}

//----------------------------------------------
// Function TDrawBox::SetCaret
// sets current caret state
// returns : nothing
// bool on : caret on (or off)?
//----------------------------------------------
void __fastcall
TDrawBox::SetCaret(bool on)
{
   if (Surface->Caret != on) {
      Surface->Caret = on;
      if (Surface->Caret) {
         // ensure drawbox can get focus
         TabStop=on;
         // adjust caretsize
         Surface->FontChanged(this);
      }
      Invalidate();
   }
}

//----------------------------------------------
// Function TDrawBox::GetCaret
// gets current caret state
// returns : caret on? (bool)
//----------------------------------------------
bool __fastcall
TDrawBox::GetCaret() const
{
   return Surface->Caret;
}

//----------------------------------------------
// Function TDrawBox::SetCrossHairs
// sets current crosshairs state
// returns : nothing
// bool on : crosshairs on (or off)?
//----------------------------------------------
void __fastcall
TDrawBox::SetCrossHairs(bool on)
{
   if (Surface->CrossHairs != on) {
      Surface->CrossHairs = on;
      if (on) {
         oldCursor = Cursor;
         Cursor = crNone;
      } else
         Cursor = oldCursor;
      Invalidate();
   }
}

//----------------------------------------------
// Function TDrawBox::GetCrossHairs
// gets current crosshairs state
// returns : crosshairs on? (bool)
//----------------------------------------------
bool __fastcall
TDrawBox::GetCrossHairs() const
{
   return Surface->CrossHairs;
}

//----------------------------------------------
// Function TDrawBox::SetFont
// sets current font
// returns : nothing
// TFont* font : new font
//----------------------------------------------
void __fastcall
TDrawBox::SetFont(TFont *font)
{
   Canvas->Font->Assign(font);
}

//----------------------------------------------
// Function TDrawBox::GetFont
// sets current font
// returns : current font (TFont*)
//----------------------------------------------
TFont* __fastcall
TDrawBox::GetFont() const
{
   return Canvas->Font;
}

//----------------------------------------------
// Function TDrawBox::SetMarkShape
// sets current marking shape
// returns : nothing
// TMarkShape markShape : new marking shape
//----------------------------------------------
void __fastcall
TDrawBox::SetMarkShape(TMarkShape markShape)
{
   if (Surface->MarkShape != markShape)
      Surface->MarkShape = markShape;
}

//----------------------------------------------
// Function TDrawBox::GetMarkShape
// gets current marking shape
// returns : current marking shape (TMarkShape)
//----------------------------------------------
TMarkShape __fastcall
TDrawBox::GetMarkShape() const
{
   return Surface->MarkShape;
}

//----------------------------------------------
// Function TDrawBox::SetPen
// sets current pen
// returns : nothing
// TPen* pen : new pen
//----------------------------------------------
void __fastcall
TDrawBox::SetPen(TPen *pen)
{
   Canvas->Pen->Assign(pen);
}

//----------------------------------------------
// Function TDrawBox::GetPen
// sets current pen
// returns : sets current pen (TPen*)
//----------------------------------------------
TPen* __fastcall
TDrawBox::GetPen() const
{
   return Canvas->Pen;
}

//----------------------------------------------
// Function __fastcall TDrawBox::GetCharWidth
// gets character width for current font
// returns : character width for font (uint)
//----------------------------------------------
unsigned int __fastcall
TDrawBox::GetCharWidth() const
{
   return Canvas->TextWidth("X");
}

//----------------------------------------------
// Function __fastcall TDrawBox::GetCharHeight
// gets character height for current font
// returns : character height for font (uint)
//----------------------------------------------
unsigned int __fastcall
TDrawBox::GetCharHeight() const
{
   return Canvas->TextHeight("X");
}

//----------------------------------------------
// Function TDrawBox::NotifyMarked
// surface notifies drawbox of end of marking op.
// returns : nothing
// int x1      : top left x coordinate
// int y1      : top left y coordinate
// int x2      : bottom right x coordinate
// int y2      : bottom right y coordinate
// bool region : region (or point) marked ?
//----------------------------------------------
void
TDrawBox::NotifyMarked(int x1, int y1,
                       int x2, int y2,
                       bool region)
{
   if (region) { // area marked
      if (FOnMarked && MarkShape != msNone) {
         double xx1, yy1, xx2, yy2;
         PCtoWorld(x1, y1, &xx1, &yy1);
         PCtoWorld(x2, y2, &xx2, &yy2);
         FOnMarked(this, xx1, yy1, xx2, yy2);
      }
   } else { // point clicked
      if (Caret)
         Surface->SetCaret(x2, y2);
      if (FOnClick) {
         double x, y;
         PCtoWorld(x2, y2, &x, &y);
         FOnClick(this, x, y);
      }
   }
}

//----------------------------------------------
// Function TDrawBox::NotifyMouseDown
// surface notifies drawbox of mouse down event
// returns : nothing
// TMouseButton button : button pressed
// ShiftState   shift  : key shift state
// int          x      : x coordinate
// int          y      : y coordinate
//----------------------------------------------
void
TDrawBox::NotifyMouseDown(TMouseButton button,
                          TShiftState shift,
                          int x, int y)
{
   if (!FOnMouseDown)
      return;

   double xx, yy;
   PCtoWorld(x, y, &xx, &yy);
   FOnMouseDown(this, button, shift, xx, yy);
}

//----------------------------------------------
// Function TDrawBox::NotifyMouseMove
// surface notifies drawbox of mouse move event
// returns : nothing
// TShiftState shift  : key shift state
// int         x      : x coordinate
// int         y      : y coordinate
//----------------------------------------------
void
TDrawBox::NotifyMouseMove(TShiftState shift,
                          int x, int y)
{
   if (!FOnMouseMove)
      return;

   double xx, yy;
   PCtoWorld(x, y, &xx, &yy);
   FOnMouseMove(this, shift, xx, yy);
}

//----------------------------------------------
// Function TDrawBox::NotifyMouseUp
// surface notifies drawbox of mouse up event
// returns : nothing
// TMouseButton button : button pressed
// TShiftState  shift  : key shift state
// int          x      : x coordinate
// int          y      : y coordinate
//----------------------------------------------
void
TDrawBox::NotifyMouseUp(TMouseButton button,
                        TShiftState shift,
                        int x, int y)
{
   if (!FOnMouseUp)
      return;

   double xx, yy;
   PCtoWorld(x, y, &xx, &yy);
   FOnMouseUp(this, button, shift, xx, yy);
}

//----------------------------------------------
// Function TDrawBox::NotifyPaint
// surface notifies drawbox of paint event
// returns : nothing
//----------------------------------------------
void
TDrawBox::NotifyPaint()
{
   if (FOnPaint)
      FOnPaint(this);
}

//----------------------------------------------
// Function TDrawBox::NotifyPrintDone
// surface notifies drawbox of print done event
// returns : nothing
// const AnsiString& job : print job name
// bool              ok  : success
//----------------------------------------------
void
TDrawBox::NotifyPrintDone(const AnsiString &job,
                          bool ok)
{
   PrintThread = NULL;
   if (FOnPrintDone)
      FOnPrintDone(this, job, ok);
}

//----------------------------------------------
// Function TDrawBox::ScrollIfNeeded
// scrolls image when necessary during marking
// returns : window scrolled? (bool)
//----------------------------------------------
bool
TDrawBox::ScrollIfNeeded()
{
   assert(Surface->Marking);

   // retrieve current mouse position
   // and compute window boundaries
   POINT mousePosition;
   ::GetCursorPos(&mousePosition);
   POINT surfacePosition = ClientOrigin;
   int left = surfacePosition.x;
   int top = surfacePosition.y;
   int right = left + ClientWidth;
   int bottom = top + ClientHeight;
   int x = mousePosition.x;
   int y = mousePosition.y;
   if (x >= left && x < right &&
       y >= top && y < bottom)
      return false;

   // determine horizontal scroll
   int dx = 0;
   if (x < left)
      dx = x - left;
   else if (x > right)
      dx = x - right;

   // determine vertical scroll
   int dy = 0;
   if (y < top)
      dy = y - top;
   else if (y > bottom)
      dy = y - bottom;

   // scroll window
   if (dx || dy) {
      if (dx) dx = 1 + dx / 2;
      if (dy) dy = 1 + dy / 2;
      int xpos = HorzScrollBar->Position;
      HorzScrollBar->Position = xpos + dx;
      int ypos = VertScrollBar->Position;
      VertScrollBar->Position = ypos + dy;
      if (xpos != HorzScrollBar->Position ||
          ypos != VertScrollBar->Position)
         return true;
   }

   // window not scrolled
   return false;
}

//----------------------------------------------
// Function TDrawBox::CreateMetafile
// copies (part of) image to metafile
// returns : pointer to created metafile
// NOTE: Caller should destroy this metafile!
// double x1 : top left x coordinate
// double y1 : top left y coordinate
// double x2 : bottom right x coordinate
// double y2 : bottom right y coordinate
//----------------------------------------------
TMetafile *
TDrawBox::CreateMetafile(double x1, double y1,
                         double x2, double y2)
{
   // do nothing if there is no OnPaint handler!
   if (!FOnPaint)
      return NULL;

   double xx1, yy1, xx2, yy2;
   int vw, vh;
   bool fullWindow;

   if (x1 != x2) { // use specified window

      fullWindow = false;
      // remember original window and viewport
      xx1 = xw1;  yy1 = yw1;
      xx2 = xw2;  yy2 = yw2;
      vw = ViewportWidth; vh = ViewportHeight;
      // compute proportional viewport size
      WorldtoPC(abs(x2 - x1), abs(y2 - y1),
                &ViewportWidth, &ViewportHeight);

   } else { // use full window extents

      fullWindow = true;
      ViewportWidth  = HorzScrollBar->Range;
      ViewportHeight = VertScrollBar->Range;

   }

   // create metafile with size of viewport
   TMetafile *metafile = new TMetafile;
   metafile->Width  = ViewportWidth;
   metafile->Height = ViewportHeight;

   // create metafile canvas to draw on
   TMetafileCanvas *metafileCanvas =
      new TMetafileCanvas(metafile,
                          Canvas->Handle);

   // copy attributes from screen window canvas
   metafileCanvas->Pen->Assign(Canvas->Pen);
   metafileCanvas->Brush->Assign(Canvas->Brush);
   metafileCanvas->Font->Assign(Canvas->Font);

   // change Canvas pointer to metafile canvas
   Canvas = metafileCanvas;

   if (!fullWindow) {
      // set new window extents
      SetWindowExtents(x1, y1, x2, y2);
   }

   // set clipping rectangle to viewport
   // NOTE: Canvas->ClipRect is a readonly
   // property and cannot be used for this!
   // http://www.inprise.com/devsupport/..
   // ..bcppbuilder/faq/FAQ4286C.html
   HRGN hrgn = ::CreateRectRgn(0, 0,
      ViewportWidth, ViewportHeight);
   ::SelectClipRgn(Canvas->Handle, hrgn);
   ::DeleteObject(hrgn);

   // call user's OnPaint
   FOnPaint(this);

   if (!fullWindow) {
      // restore previous window and viewport
      ViewportWidth = vw; ViewportHeight = vh;
      SetWindowExtents(xx1, yy1, xx2, yy2);
   }

   // change Canvas pointer back to screen window
   Canvas = Surface->Canvas;

   // close metafile canvas and return metafile
   delete metafileCanvas;
   return metafile;
}

//----------------------------------------------
// Function TDrawBox::Save
// performs various saving actions
// returns : success (bool)
// const AnsiString& filename : name of file
// bool   emf : save as emf (or bmp)?
// double x1  : top left x coordinate
// double y1  : top left y coordinate
// double x2  : bottom right x coordinate
// double y2  : bottom right y coordinate
//----------------------------------------------
bool
TDrawBox::Save(const AnsiString &filename,
               bool emf,
               double x1, double y1,
               double x2, double y2)
{
   // create metafile with copy of window
   TMetafile *metafile =
      CreateMetafile(x1, y1, x2, y2);
   if (!metafile)
      return false;
   bool result = true;

   // save/copy as enhanced metafile
   if (emf) {

      // copy metafile to clipboard
      if (filename.IsEmpty()) {
         Clipboard()->Open();
         Clipboard()->Assign(metafile);
         Clipboard()->Close();

      // or save metafile on disk
      } else {
         try {
            metafile->SaveToFile(filename);
         } catch (...) {
            result = false;
         }
      }

   // or save/copy as bitmap
   } else {

      // create temporary bitmap
      Graphics::TBitmap *bitmap =
         new Graphics::TBitmap();

      // set bitmap to size of metafile
      bitmap->Width = metafile->Width;
      bitmap->Height = metafile->Height;

      // draw metafile on bitmap's canvas
      bitmap->Canvas->Draw(0,0,metafile);

      // copy bitmap to clipboard
      if (filename.IsEmpty()) {
         Clipboard()->Open();
         Clipboard()->Assign(bitmap);
         Clipboard()->Close();

      // or save bitmap on disk
      } else {
         try {
            bitmap->SaveToFile(filename);
         } catch(...) {
            result = false;
         }
      }

      // delete temporary bitmap
      delete bitmap;
   }

   // delete created metafile
   delete metafile;
   return result;
}

//----------------------------------------------
// Function TDrawBox::SetTransformation
// sets coordinate transformation factors
// returns : nothing
//----------------------------------------------
void
TDrawBox::SetTransformation()
{
   assert(xw2 != xw1 && yw2 != yw1);

   if (Canvas == Surface->Canvas) {
      ViewportWidth = HorzScrollBar->Range;
      ViewportHeight = VertScrollBar->Range;
   }
   a = 1.0 * ViewportWidth / (xw2 - xw1);
   c = 1.0 * ViewportHeight / (yw2 - yw1);
   b = - a * xw1;
   d = - c * yw1;
   if (Canvas == Surface->Canvas)
      Invalidate();
}

//----------------------------------------------
// Function TDrawBox::WorldtoPC
// converts world coordinates to device coords
// returns : nothing
// double xw  : x coordinate to convert
// double yw  : y coordinate to convert
// int*   xpc : resulting x coordinate
// int*   ypc : resulting y coordinate
//----------------------------------------------
void
TDrawBox::WorldtoPC(double xw, double yw,
                    int *xpc, int *ypc) const
{
   assert(xpc && ypc);

   *xpc = (int)(a * xw + b + 0.5);
   *ypc = (int)(c * yw + d + 0.5);
}

//----------------------------------------------
// Function TDrawBox::PCtoWorld
// converts device coordinates to world coords
// returns : nothing
// int     xpc : x coordinate to convert
// int     ypc : y coordinate to convert
// double* xw  : resulting x coordinate
// double* yw  : resulting y coordinate
//----------------------------------------------
void
TDrawBox::PCtoWorld(int xpc, int ypc,
                    double *xw, double *yw) const
{
   assert(xw && yw);

   *xw = (double)((xpc - b) / a);
   *yw = (double)((ypc - d) / c);
}

//----------------------------------------------
// Function TDrawBox::CMCtl3DChanged
// called when Ctl3D style changes
//          (copied from TScrollBox)
// returns : nothing
// TMessage& Message : standard parameter
//----------------------------------------------
void __fastcall
TDrawBox::CMCtl3DChanged(TMessage &Message)
{
   if (NewStyleControls &&
      (FBorderStyle == bsSingle))
      RecreateWnd();
}

//----------------------------------------------
// Function TDrawBox::CMCursorChanged
// called when cursor changes
// (cannot override TControl::SetCursor)
// returns : nothing
// TMessage& Message : standard parameter
//----------------------------------------------
void __fastcall
TDrawBox::CMCursorChanged(TMessage &Message)
{
   inherited::Dispatch(&Message);
   if (Cursor != crNone)
      oldCursor = Cursor;
   if (CrossHairs)
      Cursor = crNone;
}

//----------------------------------------------
// Function TDrawBox::WMGetDlgCode
// called on each keypress to determine
//          which keys to pass on
// returns : nothing
// TMessage& Message : standard parameter
//----------------------------------------------
void __fastcall
TDrawBox::WMGetDlgCode(TMessage &Message)
{
   // see Harold Howe,
   // http://www.bcbdev.com/faqs/faq78.htm
   // needed because arrow keys are
   // otherwise used as navigation keys
   Message.Result |= DLGC_WANTARROWS;
}

//----------------------------------------------
// Function TDrawBox::KeyDown
// called when key is depressed
// returns : nothing
// Word&       Key   : code of pressed key
// TShiftState Shift : key shift state
//----------------------------------------------
void __fastcall
TDrawBox::KeyDown(Word &Key, TShiftState Shift)
{
   // call base class handler
   inherited::KeyDown(Key, Shift);

   if (Caret) {
      // See also WMGetDlgCode()
      switch (Key) {
      case VK_RIGHT:
         if (Shift.Contains(ssCtrl))
            Surface->MoveCaret(PAGERIGHT, 0);
         else
            Surface->MoveCaret(LINERIGHT, 0);
         break;
      case VK_LEFT:
         if (Shift.Contains(ssCtrl))
            Surface->MoveCaret(PAGELEFT, 0);
         else
            Surface->MoveCaret(LINELEFT, 0);
         break;
      case VK_DOWN:
         Surface->MoveCaret(0, LINEDOWN);
         break;
      case VK_UP:
         Surface->MoveCaret(0, LINEUP);
         break;
      case VK_NEXT:
         Surface->MoveCaret(0, PAGEDOWN);
         break;
      case VK_PRIOR:
         Surface->MoveCaret(0, PAGEUP);
         break;
      case VK_HOME:
         if (Shift.Contains(ssCtrl))
            Surface->MoveCaret(LEFT, TOP);
         else
            Surface->MoveCaret(LEFT, 0);
         break;
      case VK_END:
         if (Shift.Contains(ssCtrl))
            Surface->MoveCaret(RIGHT, BOTTOM);
         else
            Surface->MoveCaret(RIGHT, 0);
         break;
      }
   }
}

//----------------------------------------------
// Function TDrawBox::DragDrop
// called on drop event
// returns : nothing
// TObject* source : dropping object
// int      x      : x coordinate
// int      y      : y coordinate
//----------------------------------------------
void __fastcall
TDrawBox::DragDrop(TObject* source,
                   int x, int y)
{
   if (!FOnDragDrop)
      return;

   double xx, yy;
   PCtoWorld(x, y, &xx, &yy);
   FOnDragDrop(this, source, xx, yy);
}

//----------------------------------------------
// Function TDrawBox::DragOver
// called on drag over event
// returns : nothing
// TObject*   source : dropping object
// int        x      : x coordinate
// int        y      : y coordinate
// TDragState state  : dragging state
// bool&      accept : does component accept drop?
//----------------------------------------------
void __fastcall
TDrawBox::DragOver(TObject *source, int x, int y,
                   TDragState state, bool &accept)
{
   if (!FOnDragOver)
      return;

   double xx, yy;
   PCtoWorld(x, y, &xx, &yy);
   FOnDragOver(this, source, xx, yy,
               state, accept);
}

//----------------------------------------------
// Function TDrawBox::DoEndDrag
// called on end of drag event
// returns : nothing
// TObject* target : dropping object
// int      x      : x coordinate
// int      y      : y coordinate
//----------------------------------------------
void __fastcall
TDrawBox::DoEndDrag(TObject* target, int x, int y)
{
   if (!FOnEndDrag)
      return;

   double xx, yy;
   PCtoWorld(x, y, &xx, &yy);
   FOnEndDrag(this, target, xx, yy);
}

//----------------------------------------------
// Function TDrawBox::WMHScroll
// called on horizontal scroll event
// returns : nothing
// TWMScroll& Message : scroll message structure
//----------------------------------------------
void __fastcall
TDrawBox::WMHScroll(TWMScroll &Message)
{
   int relCaret = 0;
   if (Caret) {
      // restrict movement to
      // integer number of caretwidth's
      relCaret =
         Surface->CaretX -
            HorzScrollBar->Position;
      int posX = Message.Pos;
      int maxX =
         HorzScrollBar->Range -
            Surface->CaretWidth;
      short scrollCode = Message.ScrollCode;
      if (scrollCode != SB_THUMBPOSITION &&
          scrollCode != SB_THUMBTRACK &&
          scrollCode != SB_ENDSCROLL) {
         // fake scroll slider message to enable
         // indication of exact thumb position
         Message.ScrollCode = SB_THUMBPOSITION;
         posX = HorzScrollBar->Position;
         switch (scrollCode) {
         case SB_RIGHT:
            posX = maxX;
            break;
         case SB_PAGERIGHT:
            posX += ClientWidth;
            break;
         case SB_LINERIGHT:
            posX += Surface->CaretWidth;
            break;
         case SB_LINELEFT:
            posX -= Surface->CaretWidth;
            break;
         case SB_PAGELEFT:
            posX -= ClientWidth;
            break;
         case SB_LEFT:
            posX = 0;
            break;
         }
      }
      if (posX < 0)
         posX = 0;
      else if (posX > maxX)
         posX = maxX;
      posX = posX / Surface->CaretWidth *
                    Surface->CaretWidth;
      Message.Pos = (short)posX;
   }
   // call base class handler
   inherited::Dispatch(&Message);
   if (Caret &&
      Surface->CaretX -
         HorzScrollBar->Position != relCaret) {
      Surface->DrawCaret();
      Surface->CaretX =
         relCaret + HorzScrollBar->Position;
      Surface->DrawCaret();
   }
}

//----------------------------------------------
// Function TDrawBox::WMVScroll
// called on vertical scroll event
// returns : nothing
// TWMScroll& Message : scroll message structure
//----------------------------------------------
void __fastcall
TDrawBox::WMVScroll(TWMScroll &Message)
{
   int relCaret = 0;
   if (Caret) {
      // restrict movement to
      // integer number of caretheight's
      relCaret =
         Surface->CaretY -
            VertScrollBar->Position;
      int posY = Message.Pos;
      int maxY =
         VertScrollBar->Range -
            Surface->CaretHeight;
      short scrollCode = Message.ScrollCode;
      if (scrollCode != SB_THUMBPOSITION &&
          scrollCode != SB_THUMBTRACK &&
          scrollCode != SB_ENDSCROLL) {
         // fake scroll slider message to enable
         // indication of exact thumb position
         Message.ScrollCode = SB_THUMBPOSITION;
         posY = VertScrollBar->Position;
         switch (scrollCode) {
         case SB_BOTTOM:
            posY = maxY;
            break;
         case SB_PAGEDOWN:
            posY += ClientHeight;
            break;
         case SB_LINEDOWN:
            posY += Surface->CaretHeight;
            break;
         case SB_LINEUP:
            posY -= Surface->CaretHeight;
            break;
         case SB_PAGEUP:
            posY -= ClientHeight;
            break;
         case SB_TOP:
            posY = 0;
            break;
         }
      }
      if (posY < 0)
         posY = 0;
      else if (posY > maxY)
         posY = maxY;
      posY = posY / Surface->CaretHeight *
                    Surface->CaretHeight;
      Message.Pos = (short)posY;
   }
   // call base class handler
   inherited::Dispatch(&Message);
   if (Caret &&
      Surface->CaretY -
         VertScrollBar->Position != relCaret) {
      Surface->DrawCaret();
      Surface->CaretY =
         relCaret + VertScrollBar->Position;
      Surface->DrawCaret();
   }
}

//----------------------------------------------
// Function Register
// component registering function
// returns : nothing
// Note: 
// The namespace MUST be the name of the file 
// the component is in, minus the file extension, 
// with all lowercase letters except the first 
// one. If this convention is not followed, no 
// error message results, but the component will 
// NOT be registered on the component palette!
//----------------------------------------------
namespace Drawbox
{
  void __fastcall PACKAGE Register()
  {
     TComponentClass classes[1] =
        {__classid(TDrawBox)};
     RegisterComponents("Sichemsoft", classes, 0);
  }
}
//----------------------------------------------

//----------------------------------------------
// Function TDrawBoxSurface::TDrawBoxSurface
// constructor
// TComponent* owner : pointer to drawbox component
//----------------------------------------------
__fastcall
TDrawBoxSurface::
   TDrawBoxSurface(TComponent* owner):
   inherited(owner),
      Caret(false),
      DrawBox((TDrawBox*)owner),
      CurrentX(-1),
      CurrentY(-1),
      CaretX(0),
      CaretY(0),
      CaretWidth(0),
      CaretHeight(0),
      Marking(false),
      Marked(false)
{
   Parent = DrawBox;
   Align = alClient;
   Canvas->Font->OnChange=FontChanged;
   ControlStyle = ControlStyle << csOpaque;
   // to reduce flicker; see Harold Howe,
   // http://www.bcbdev.com/faqs/faq34.htm

   // give visual feedback on property changes
   if (ComponentState.Contains(csDesigning)) {
      Canvas->Pen->OnChange=StyleChanged;
      Canvas->Brush->OnChange=StyleChanged;
      OnPaint=DrawTestPicture;
   }
}

//----------------------------------------------
// Function TDrawBoxSurface::MouseDown
// called on mouse depress event
// returns : nothing
// TMouseButton button : button pressed
// TShiftState  shift  : key shift state
// int          x      : x coordinate
// int          y      : y coordinate
//----------------------------------------------
void __fastcall
TDrawBoxSurface::MouseDown(TMouseButton button,
                           TShiftState shift,
                           int x, int y)
{
   inherited::MouseDown(button,shift,x,y);
   DrawBox->NotifyMouseDown(button, shift, x, y);

   if (button != mbLeft)
      return;

   if (Marked) {
      DrawMarkShape();
      Marked = false;
   }

   // start marking
   OriginX = CurrentX = x;
   OriginY = CurrentY = y;
   Marking = true;
   if (MarkShape != msNone) {
      Timer = new TTimer(this);
      Timer->Interval = 50;
      Timer->OnTimer = TimerTick;
      Timer->Enabled = true;
   }
}

//----------------------------------------------
// Function TDrawBoxSurface::MouseMove
// called on mouse move event
// returns : nothing
// TShiftState shift  : key shift state
// int         x      : x coordinate
// int         y      : y coordinate
//----------------------------------------------
void __fastcall
TDrawBoxSurface::MouseMove(TShiftState shift,
                           int x, int y)
{
   inherited::MouseMove(shift,x,y);
   DrawBox->NotifyMouseMove(shift, x, y);

   // undraw crosshairs if needed
   if (CrossHairs)
      DrawCrossHairs();

   // undraw marking shape if needed
   if (Marking && MarkShape != msNone)
      DrawMarkShape();

   // change coordinates
   CurrentX = x; CurrentY = y;

   // draw crosshairs if needed
   if (CrossHairs)
      DrawCrossHairs();

   // draw marking shape if needed
   if (Marking && MarkShape != msNone)
      DrawMarkShape();
}

//----------------------------------------------
// Function TDrawBoxSurface::MouseUp
// called on mouse release event
// returns : nothing
// TMouseButton button : button pressed
// TShiftState  shift  : key shift state
// int          x      : x coordinate
// int          y      : y coordinate
//----------------------------------------------
void __fastcall
TDrawBoxSurface::MouseUp(TMouseButton button,
                         TShiftState shift,
                         int x, int y)
{
   inherited::MouseUp(button,shift,x,y);
   DrawBox->NotifyMouseUp(button, shift, x, y);

   if (!(Marking && button == mbLeft))
      return;

   // undraw rectangle
   CurrentX = x; CurrentY = y;
   if (MarkShape != msNone)
      DrawMarkShape();

   // fit and normalize shape
   int x1 = OriginX; int x2 = x;
   int y1 = OriginY; int y2 = y;
   if (MarkShape == msLine) {
      x1 = max(0, x1);
      x1 = min(x1, Width);
      y1 = max(0, y1);
      y1 = min(y1, Height);
      x2 = max(0, x2);
      x2 = min(x2, Width);
      y2 = max(0, y2);
      y2 = min(y2, Height);
   } else {
      if (x1 > x2) Swap(x1, x2);
      if (y1 > y2) Swap(y1, y2);
      x1 = max(0, x1);
      y1 = max(0, y1);
      x2 = min(x2, Width);
      y2 = min(y2, Height);
   }

   // is region or point marked?
   bool region = abs(x2-x1)>2 || abs(y2-y1)>2;

   // redraw rectangle if necessary
   if (region && MarkShape == msMark) {
      DrawMarkShape();
      OriginX = x1; OriginY = y1;
      MarkedX = x2; MarkedY = y2;
      Marked = true;
   }

   // send notification to surface object
   if (MarkShape != msNone)
      delete Timer;
   DrawBox->NotifyMarked(x1, y1, x2, y2, region);
   Marking = false;
}

//----------------------------------------------
// Function TDrawBoxSurface::Paint
// called on Paint event
// returns : nothing
//----------------------------------------------
void __fastcall
TDrawBoxSurface::Paint()
{
   if (OnPaint)
      OnPaint(this); // only when designing!

   // call users OnPaint
   DrawBox->NotifyPaint();

   // ensure crosshairs is redrawn if needed
   if (CrossHairs)
      DrawCrossHairs();

   // ensure marking shape is redrawn if needed
   if (Marking && MarkShape != msNone || Marked)
      DrawMarkShape();

   // ensure caret is redrawn if needed
   if (Caret)
      DrawCaret();
}

//----------------------------------------------
// Function TDrawBoxSurface::TimerTick
// called on timer event
// returns : nothing
// TObject* Sender : who sent the event?
//----------------------------------------------
void __fastcall
TDrawBoxSurface::TimerTick(TObject* Sender)
{
   assert(Marking);

   if (DrawBox->ScrollIfNeeded())
      Invalidate();
}

//----------------------------------------------
// Function TDrawBoxSurface::StyleChanged
// called when pen of brush is changed (design)
// returns : nothing
// TObject* Sender : who sent the event?
//----------------------------------------------
void __fastcall
TDrawBoxSurface::StyleChanged(TObject *Sender)
{
   Invalidate();
}

//----------------------------------------------
// Function TDrawBoxSurface::FontChanged
// called when font is changed
// returns : nothing
// TObject* Sender : who sent the event?
//----------------------------------------------
void __fastcall
TDrawBoxSurface::FontChanged(TObject *Sender)
{
   if (ComponentState.Contains(csDesigning))
      Invalidate();
   else {
      // recompute caret size
      if (Caret)
         DrawCaret();
      CaretHeight=Canvas->TextHeight("X");
      CaretWidth=Canvas->TextWidth("X");
      if (Caret)
         DrawCaret();
   }
}

//----------------------------------------------
// Function TDrawBoxSurface::DrawTestPicture
// draws test picture (when designing)
// returns : nothing
// TObject* Sender : who sent the event?
//----------------------------------------------
void __fastcall
TDrawBoxSurface::DrawTestPicture(TObject *Sender)
{
   int width = Canvas->TextWidth("TDrawBox");
   int height = Canvas->TextHeight("TDrawBox");
   Canvas->Rectangle(25, 25, 25 + 2 * width,
                             25 + 2 * height);
   Canvas->TextOut(25 + 0.5 * width,
                   25 + 0.5 * height,"TDrawBox");
}

//----------------------------------------------
// Function TDrawBoxSurface::DrawMarkShape
// draws marking shape
// returns : nothing
//----------------------------------------------
void
TDrawBoxSurface::DrawMarkShape()
{
   assert(Marking || Marked);

   // remember current pen and brush
   TPen *oldPen = new TPen;
   oldPen->Assign(Canvas->Pen);
   TBrush *oldBrush = new TBrush;
   oldBrush->Assign(Canvas->Brush);

   // create xornot dotted pen and clear brush
   TPen *newPen = new TPen;
   newPen->Mode = pmNotXor;
   newPen->Style = psDot;
   Canvas->Pen->Assign(newPen);
   TBrush *newBrush = new TBrush;
   newBrush->Style = bsClear;
   Canvas->Brush->Assign(newBrush);

   // draw shape
   if (Marked) {
      Canvas->Rectangle(OriginX, OriginY,
                        MarkedX, MarkedY);
   } else {
      switch (MarkShape) {
      case msLine :
         Canvas->MoveTo(OriginX, OriginY);
         Canvas->LineTo(CurrentX, CurrentY);
         break;
      case msMark:
      case msRectangle :
         Canvas->Rectangle(OriginX, OriginY,
                           CurrentX, CurrentY);
         break;
      case msEllipse :
         Canvas->Ellipse(OriginX, OriginY,
                         CurrentX, CurrentY);
         break;
      case msRoundRect :
         Canvas->RoundRect(OriginX, OriginY,
                           CurrentX, CurrentY,
                          (OriginX - CurrentX)/2,
                          (OriginY - CurrentY)/2);
         break;
      }
   }

   // reset current pen and brush
   Canvas->Pen->Assign(oldPen);
   Canvas->Brush->Assign(oldBrush);
   delete oldPen; delete newPen;
   delete oldBrush; delete newBrush;
}

//----------------------------------------------
// Function TDrawBoxSurface::DrawCrossHairs
// draws crosshairs
// returns : nothing
//----------------------------------------------
void
TDrawBoxSurface::DrawCrossHairs()
{
   // remember current pen
   TPen *oldPen = new TPen;
   oldPen->Assign(Canvas->Pen);

   // set xornot pen
   TPen *newPen = new TPen;
   newPen->Mode = pmNotXor;
   Canvas->Pen->Assign(newPen);

   // draw two lines
   Canvas->MoveTo(0, CurrentY);
   Canvas->LineTo(Width, CurrentY);
   Canvas->MoveTo(CurrentX, 0);
   Canvas->LineTo(CurrentX, Height);

   // reset current pen
   Canvas->Pen->Assign(oldPen);
   delete oldPen; delete newPen;
}

//----------------------------------------------
// Function TDrawBoxSurface::DrawCaret
// draws caret
// returns : nothing
//----------------------------------------------
void
TDrawBoxSurface::DrawCaret()
{
   if (!CaretWidth) {
      // setting this in constructor
      // leads to runtime error!!
      CaretHeight=Canvas->TextHeight("X");
      CaretWidth=Canvas->TextWidth("X");
   }
   RECT rect;
   rect.left = CaretX; rect.top = CaretY;
   rect.right = CaretX + CaretWidth;
   rect.bottom = CaretY + CaretHeight;
   ::InvertRect(Canvas->Handle, &rect);
}

//----------------------------------------------
// Function TDrawBoxSurface::MoveCaret
// moves caret specified distance
// returns : nothing
// int dx : x distance to move
// int dy : y distance to move
//----------------------------------------------
void
TDrawBoxSurface::MoveCaret(int dx, int dy)
{
   // hide caret
   DrawCaret();

   // compute some measurement values
   int maxX =
      DrawBox->HorzScrollBar->Range -
         CaretWidth;
   int maxY =
      DrawBox->VertScrollBar->Range -
         CaretHeight;
   int visW = DrawBox->ClientWidth;
   int visH = DrawBox->ClientHeight;
   int posX = DrawBox->HorzScrollBar->Position;
   int posY = DrawBox->VertScrollBar->Position;

   // compute new caret position
   switch (dx) {
   case RIGHT     : CaretX = maxX; break;
   case PAGERIGHT : CaretX += visW; break;
   case LINERIGHT : CaretX += CaretWidth; break;
   case LINELEFT  : CaretX -= CaretWidth; break;
   case PAGELEFT  : CaretX -= visW; break;
   case LEFT      : CaretX = 0; break;
   }
   switch (dy) {
   case BOTTOM    : CaretY = maxY; break;
   case PAGEDOWN  : CaretY += visH; break;
   case LINEDOWN  : CaretY += CaretHeight; break;
   case LINEUP    : CaretY -= CaretHeight; break;
   case PAGEUP    : CaretY -= visH; break;
   case TOP       : CaretY = 0; break;
   }

   // correct caret position for
   // boundaries and quantization
   CorrectCaret();

   // scroll if needed
   if (CaretX < posX || CaretX > posX + visW) {
      if (CaretX < posX) {
         switch (dx) {
         case LINELEFT:
            posX -= CaretWidth;
            break;
         case PAGELEFT:
            posX =
            DrawBox->HorzScrollBar->Position -
               visW;
            break;
         case LEFT:
            posX = 0;
            break;
         }
      } else {
         switch (dx) {
         case LINERIGHT:
            posX += CaretWidth;
            break;
         case PAGERIGHT:
            posX =
               DrawBox->HorzScrollBar->Position +
                  visW;
            break;
         case RIGHT:
            posX =
               DrawBox->HorzScrollBar->Range -
                  CaretWidth;
            break;
         }
      }
      posX = posX / CaretWidth * CaretWidth;
      DrawBox->HorzScrollBar->Position = posX;
   }
   if (CaretY < posY || CaretY > posY + visH) {
      if (CaretY < posY) {
         switch (dy) {
         case LINEUP:
            posY -= CaretHeight;
            break;
         case PAGEUP:
            posY =
               DrawBox->VertScrollBar->Position -
                  visH;
            break;
         case TOP:
            posY = 0;
            break;
         }
      } else {
         switch (dy) {
         case LINEDOWN:
            posY += CaretHeight;
            break;
         case PAGEDOWN:
            posY =
               DrawBox->VertScrollBar->Position +
                  visH;
            break;
         case BOTTOM:
            posY =
               DrawBox->VertScrollBar->Range -
                  CaretHeight;
            break;
         }
      }
      posY = posY / CaretHeight * CaretHeight;
      DrawBox->VertScrollBar->Position = posY;
   }

   // show caret
   DrawCaret();
}

//----------------------------------------------
// Function TDrawBoxSurface::SetCaret
// sets caret on specified position
// returns : nothing
// int x : x coordinate
// int y : y coordinate
//----------------------------------------------
void
TDrawBoxSurface::SetCaret(int x, int y)
{
   // hide caret
   DrawCaret();

   // compute some measurement values
   int maxX = DrawBox->HorzScrollBar->Range;
   int maxY = DrawBox->VertScrollBar->Range;
   int visW = DrawBox->ClientWidth;
   int visH = DrawBox->ClientHeight;
   int posX = DrawBox->HorzScrollBar->Position;
   int posY = DrawBox->VertScrollBar->Position;

   // set caret at new position and correct it
   CaretX = x; CaretY = y;
   CorrectCaret();

   // scroll if needed
   if (CaretX < posX || CaretX > posX + visW) {
      posX = CaretX - visW / 2;
      if (posX < 0)
         posX = 0;
      else if (posX > maxX)
         posX = maxX;
      posX = posX / CaretWidth * CaretWidth;
      DrawBox->HorzScrollBar->Position = posX;
   }
   if (CaretY < posY || CaretY > posY + visH) {
      posY = CaretY - visH / 2;
      if (posY < 0)
         posY = 0;
      else if (posY > maxY)
         posY = maxY;
      posY = posY / CaretHeight * CaretHeight;
      DrawBox->VertScrollBar->Position = posY;
   }

   // show caret
   DrawCaret();
}

//----------------------------------------------
// Function TDrawBoxSurface::CorrectCaret
// confine caret to viewport boundaries
// returns : nothing
//----------------------------------------------
void
TDrawBoxSurface::CorrectCaret()
{
   // compute some measurement values
   int maxX =
      DrawBox->HorzScrollBar->Range -
         CaretWidth;
   int maxY =
      DrawBox->VertScrollBar->Range -
         CaretHeight;

   // check boundaries
   if (CaretX < 0) CaretX = 0;
   else if (CaretX > maxX) CaretX = maxX;
   if (CaretY < 0) CaretY = 0;
   else if (CaretY > maxY) CaretY = maxY;

   // quantize caret position
   CaretX = CaretX / CaretWidth * CaretWidth;
   CaretY = CaretY / CaretHeight * CaretHeight;
}

//----------------------------------------------

//----------------------------------------------
// TDrawBoxPrintThread::TDrawBoxPrintThread
// constructor, starts thread
// DrawBox*          drawBox  : pointer to
//                              drawbox component
// const AnsiString& jobName  : name of print job
// TPrinter*         printer  : printer object
// TMetafile*        metafile : metafile to print
// unsigned int      from     : first page
// unsigned int      to       : last page
// unsigned int      copies   : number of copies
// bool              collate  : collate copies?
//----------------------------------------------
__fastcall
TDrawBoxPrintThread::TDrawBoxPrintThread(
   TDrawBox *drawBox, const AnsiString &jobName,
   TPrinter *printer, TMetafile *metafile,
   unsigned int from, unsigned int to,
   unsigned int copies, bool collate):
   TThread(true), DrawBox(drawBox),
   JobName(jobName), Printer(printer),
   Metafile(metafile), From(from), To(to),
   Copies(copies), Collate(collate)
{
   // Borland C++ Builder HOW-TO Chapter 12.1
   FreeOnTerminate = true;
   Resume();
}

//----------------------------------------------
// Function TDrawBoxPrintThread::Execute
// does actual printing
// returns : nothing
//----------------------------------------------
void __fastcall
TDrawBoxPrintThread::Execute()
{
   Result = ::Print(JobName, Printer, Metafile,
                    From, To, Copies, Collate);
   // notify drawbox that printing is done
   // Borland C++ Builder HOW-TO Chapter 12.2
   Synchronize(Done);
}

//----------------------------------------------
// Function TDrawBoxPrintThread::Done
// notifies drawbox thread is done
// returns : nothing
//----------------------------------------------
void __fastcall
TDrawBoxPrintThread::Done()
{
   DrawBox->NotifyPrintDone(JobName, Result);
}

//----------------------------------------------
// Function Print
// printing helper function, executed by thread
// returns : success (bool)
// const AnsiString& jobName  : name of print job
// TPrinter*         printer  : printer object
// TMetafile*        metafile : metafile to print
// unsigned int      from     : first page
// unsigned int      to       : last page
// unsigned int      copies   : number of copies
// bool              collate  : collate copies?
//----------------------------------------------
static bool Print(const AnsiString &jobName,
   TPrinter *printer, TMetafile *metafile,
   unsigned int from, unsigned int to,
   unsigned int copies, bool collate)
{
   bool result = true;
   // Borland C++ Builder Programming Explorer
   // Chapter 12, try..catch And Printing
   try {

   // start printing
   printer->Title = jobName;
   printer->BeginDoc();

   // compute magnification from resolutions
   int screenResolution =
      Screen->PixelsPerInch;
   int printerResolution =
      printer->Canvas->Font->PixelsPerInch;
   float factor =
      1.0 * printerResolution /
            screenResolution;
    // compute size of drawing on printer canvas
   unsigned int pictureWidth =
      (int)(metafile->Width * factor + 0.5);
   unsigned int pictureHeight=
      (int)(metafile->Height * factor + 0.5);

   // determine size of page of printer canvas
   unsigned int pageWidth =
      printer->PageWidth;
   unsigned int pageHeight =
      printer->PageHeight;

   // paginate if necessary
   unsigned int columns =
      pictureWidth / pageWidth + 1;
   unsigned int rows =
      pictureHeight / pageHeight + 1;

   // determine size of rectangle
   // in which to draw metafile
   TRect printRect;
   printRect.Left = 0; printRect.Top = 0;
   printRect.Right = pictureWidth;
   printRect.Bottom = pictureHeight;

   // determine print job sequence
   // Borland C++ Builder HOW-TO Chapter 10.2
   unsigned iterations = 1;
   if (collate) {
      iterations = copies; copies = 1;
   }

   // determine start and end page numbers
   if (!from)
      from = 1;
   if (!to)
      to = columns * rows;

   // printing routine proper
   bool nextPage = false;
   for (unsigned int x = 0; x < iterations; ++x) {

      unsigned int pageNumber = 0;

      for (unsigned int j = 0; j < rows; ++j) {
         int printOriginY = j * pageHeight;

         for (unsigned int i = 0;
              i < columns; ++i) {
            int printOriginX = i * pageWidth;

            ++pageNumber;

            for (unsigned int y = 0;
                 pageNumber >= from &&
                 pageNumber <= to &&
                 y < copies; ++y) {

               // start new page
               // (except for the first one)
               if (nextPage)
                  printer->NewPage();
               else
                  nextPage = true;

               // move origin of printer canvas
               // so the correct part of the
               // drawing is printed in the page
               ::SetViewportOrgEx(
                  printer->Canvas->Handle,
                  -printOriginX, -printOriginY,
                  NULL);

               // draw metafile on printer canvas
               printer->Canvas->StretchDraw(
                  printRect, metafile);

            }
         }
      }
   }
   } catch (...) {
      result = false;
   }

   // finish printing
   if (printer->Printing)
      printer->EndDoc();

   // delete metafile
   delete metafile;
   return result;
}
//----------------------------------------------

