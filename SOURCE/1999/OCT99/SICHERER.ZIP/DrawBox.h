//----------------------------------------------
// Filename:      DrawBox.h
// Programmer:    Anneke Sicherer-Roetman
// Email:         sicherer@sichemsoft.nl
// Version:       1.00
// Revision Date: 19990606
// Description:   Interface of TDrawBox
//----------------------------------------------
#ifndef DrawBoxH
#define DrawBoxH
//----------------------------------------------
#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>
#include <printers.hpp>

//----------------------------------------------
// global enum type
//----------------------------------------------
// current marking shape
enum TMarkShape {
   msNone,      // no marking done
   msMark,      // sticky mark rectangle
   msLine,      // single line
   msRectangle, // rectangle
   msEllipse,   // ellipse
   msRoundRect  // rectangle with rounded corners
};

//----------------------------------------------
// closure types (user definable events)
//----------------------------------------------
typedef void __fastcall
   (__closure *TDrawBoxClickEvent)
      (System::TObject* Sender,
       double X, double Y);
typedef void __fastcall
   (__closure *TDrawBoxDragDropEvent)
      (System::TObject* Sender,
       System::TObject* Source,
       double X, double Y);
typedef void __fastcall
   (__closure *TDrawBoxDragOverEvent)
      (System::TObject* Sender,
       System::TObject* Source,
       double X, double Y, TDragState State,
       bool &Accept);
typedef void __fastcall
   (__closure *TDrawBoxEndDragEvent)
      (System::TObject* Sender,
       System::TObject* Target,
       double X, double Y);
typedef void __fastcall
   (__closure *TDrawBoxMarkEvent)
      (System::TObject* Sender,
       double Left, double Top,
       double Right, double Bottom);
typedef void __fastcall
   (__closure *TDrawBoxMouseEvent)
      (System::TObject* Sender,
       TMouseButton Button,
       Classes::TShiftState Shift,
       double X, double Y);
typedef void __fastcall
   (__closure *TDrawBoxMouseMoveEvent)
      (System::TObject* Sender,
       Classes::TShiftState Shift,
       double X, double Y);
typedef void __fastcall
   (__closure *TDrawBoxPrintDoneEvent)
      (System::TObject* Sender,
       const AnsiString &JobName,
       bool ok);
//----------------------------------------------

//----------------------------------------------
// class TDrawBox : Scrollable drawing surface
//                  component with world
//                  coordinates support
// baseclass      : TScrollingWinControl
//----------------------------------------------
class PACKAGE TDrawBox : public TScrollingWinControl
{
   typedef TScrollingWinControl inherited;

   friend class TDrawBoxSurface;
   friend class TDrawBoxPrintThread;

public:

  // drawbox borderstyle
  enum TBorderStyle {
     bsNone,  // no border
     bsSingle // single border
  };

__published:

   // already __published by TScrollingWinControl:
   // Cursor, Height, HelpContext,
   // Hint, HorzScrollBar, Left, Name,
   // Tag, Top, VertScrollBar, Width.
   __property Cursor = { default=crCross };
   __property Height = { default=90 };
   __property Width  = { default=180 };

   // ancestor properties raised to published:
   __property Align;
   __property Color;
   __property Ctl3D;
   __property DragCursor;
   __property DragMode;
   __property Enabled;
   __property ParentCtl3D;
   __property ParentShowHint;
   __property PopupMenu;
   __property ShowHint;
   __property TabOrder;
   __property TabStop;
   __property Visible;

   // events from ancestors raised to published:
   __property OnDblClick;
   __property OnEnter;
   __property OnExit;
   __property OnKeyDown;
   __property OnKeyPress;
   __property OnKeyUp;

   // new properties:

   // style of border
   __property TBorderStyle BorderStyle =
   { read=FBorderStyle, write=SetBorderStyle };

   // drawing brush
   __property TBrush* Brush =
   { read=GetBrush, write=SetBrush};

   // caret on/off
   __property bool Caret =
   { read=GetCaret, write=SetCaret };

   // crosshairs on/off
   __property bool CrossHairs =
   { read=GetCrossHairs, write=SetCrossHairs };

   // drawing font
   __property TFont* Font =
   { read=GetFont, write=SetFont};

   // marking shape
   __property TMarkShape MarkShape =
   { read=GetMarkShape, write=SetMarkShape };

   // drawing pen
   __property TPen* Pen =
   { read=GetPen, write=SetPen};

   // scale font too?
   __property bool ScaleFont =
   { read=FScaleFont, write=FScaleFont};

   // new events:

   // mouse click
   __property TDrawBoxClickEvent OnClick =
   { read=FOnClick, write=FOnClick };

   // drop
   __property TDrawBoxDragDropEvent OnDragDrop =
   { read=FOnDragDrop, write=FOnDragDrop };

   // dragging over
   __property TDrawBoxDragOverEvent OnDragOver =
   { read=FOnDragOver, write=FOnDragOver };

   // stop dragging
   __property TDrawBoxEndDragEvent OnEndDrag =
   { read=FOnEndDrag, write=FOnEndDrag };

   // region marked
   __property TDrawBoxMarkEvent OnMarked =
   { read=FOnMarked, write=FOnMarked };

   // mouse depressed
   __property TDrawBoxMouseEvent OnMouseDown =
   { read=FOnMouseDown, write=FOnMouseDown };

   // mouse moved
   __property TDrawBoxMouseMoveEvent OnMouseMove=
   { read=FOnMouseMove, write=FOnMouseMove };

   // mouse released
   __property TDrawBoxMouseEvent OnMouseUp =
   { read=FOnMouseUp, write=FOnMouseUp };

   // repainting needed
   __property TNotifyEvent OnPaint =
   { read=FOnPaint, write=FOnPaint };

   // printing done
   __property TDrawBoxPrintDoneEvent OnPrintDone=
   { read=FOnPrintDone, write=FOnPrintDone };

public:

   __property unsigned int // character width
              CharWidth  = { read = GetCharWidth };
   __property unsigned int // character height
              CharHeight = { read = GetCharHeight };

   // constructor
   __fastcall TDrawBox(TComponent* Owner);

   // destructor
   virtual __fastcall ~TDrawBox();

   // sets total drawing area in world coords
   void SetWindowExtents(double x1, double y1,
                         double x2, double y2);

   // gets total drawing area in world coords
   void GetWindowExtents(double *x1, double *y1,
                         double *x2, double *y2)
                         const;

   // scrolls window so origin is at top left
   void SetWindowOrigin(double x, double y);

   // returns window origin coordinates
   void GetWindowOrigin(double *x, double *y)
                        const;

   // recalculates viewing transformation
   void RecalculateTransformation();

   // saves (part of) image to clipboard as emf
   bool CopyToClipboardAsEMF(double x1 = 0,
                             double y1 = 0,
                             double x2 = 0,
                             double y2 = 0);

   // saves (part of) image to clipboard as bmp
   bool CopyToClipboardAsBMP(double x1 = 0,
                             double y1 = 0,
                             double x2 = 0,
                             double y2 = 0);

   // saves (part of) image to file as emf
   bool SaveToFileAsEMF(const AnsiString &file,
                        double x1 = 0,
                        double y1 = 0,
                        double x2 = 0,
                        double y2 = 0);

   // saves (part of) image to file as bmp
   bool SaveToFileAsBMP(const AnsiString &file,
                        double x1 = 0,
                        double y1 = 0,
                        double x2 = 0,
                        double y2 = 0);

   // prints entire image
   void Print(const AnsiString &jobName,
              unsigned int from = 0,
              unsigned int to = 0,
              unsigned int copies = 1,
              bool collate = true);

   // prints entire image
   void Print(const AnsiString &jobName,
              double x1, double y1,
              double x2, double y2,
              unsigned int from = 0,
              unsigned int to = 0,
              unsigned int copies = 1,
              bool collate = true);

   // returns number of print pages in image
   unsigned int CountPrintPages() const;

   // clears entire image
   void Clear();

   // draws line
   void DrawLine(double x1, double y1,
                 double x2, double y2);

   // draws polyline
   void DrawPolyLine(unsigned n,
                     double x, double y, ...);              

   // draws rectangle
   void DrawRectangle(double x1, double y1,
                      double x2, double y2);

   // draws rectangle with rounded corners
   void DrawRoundRect(double x1, double y1,
                      double x2, double y2);

   // draws ellipse
   void DrawEllipse(double x1, double y1,
                    double x2, double y2);

   // draws text
   void DrawText(double x, double y,
                 const AnsiString &s);

   // clears rectangular area
   void DrawClear(double x1, double y1,
                  double x2, double y2);

   // inverts rectangular area
   void DrawInvert(double x1, double y1,
                   double x2, double y2);

   // draws marker (small inverted rectange)
   void DrawMarker(double x, double y);

   // sets caret on specified position
   void SetCaretPosition(double x, double y);

   // returns horizontal caret position
   double GetCaretX() const;

   // returns vertical caret position
   double GetCaretY() const;

   // returns marked box coordinates
   bool GetMarkBox(double *x1, double *y1,
                   double *x2, double *y2);

   // returns text size of string in current font
   void GetTextExtents(const AnsiString &string,
                       double *width,
                       double *height);

   // returns pointer to canvas when needed
   // Do not generally use this because
   // the canvas works in device coordinates!
   TCanvas *GetCanvas() const { return Canvas; }

protected:
   // property access methods should be protected
   // virtual functions (BCB Developer's Guide)

   // special handling for borderstyle
   virtual void __fastcall
      CreateParams(TCreateParams &Params);

   // sets borderstyle
   virtual void __fastcall
      SetBorderStyle(TBorderStyle style);

   // sets current brush
   virtual void __fastcall
      SetBrush(TBrush *brush);

   // gets current brush
   virtual TBrush* __fastcall
      GetBrush() const;

   // sets current caret state
   virtual void __fastcall
      SetCaret(bool on);

   // gets current caret state
   virtual bool __fastcall
      GetCaret() const;

   // sets current crosshairs state
   virtual void __fastcall
      SetCrossHairs(bool on);

   // gets current crosshairs state
   virtual bool __fastcall
      GetCrossHairs() const;

   // sets current font
   virtual void __fastcall
      SetFont(TFont *font);

   // gets current font
   virtual TFont* __fastcall
      GetFont() const;

   // sets current marking shape
   virtual void __fastcall
      SetMarkShape(TMarkShape markShape);

   // gets current marking shape
   virtual TMarkShape __fastcall
      GetMarkShape() const;

   // sets current pen
   virtual void __fastcall
      SetPen(TPen *pen);

   // sets current pen
   virtual TPen* __fastcall
      GetPen() const;

   // gets character width for current font
   virtual unsigned int __fastcall
      GetCharWidth() const;

   // gets character height for current font
   virtual unsigned int __fastcall
      GetCharHeight() const;

private:

   // property variables
   TBorderStyle FBorderStyle; // border style
   bool FScaleFont;           // scale font
                              // with window?

   // event variables
   TDrawBoxClickEvent FOnClick;
   TDrawBoxDragDropEvent FOnDragDrop;
   TDrawBoxDragOverEvent FOnDragOver;
   TDrawBoxEndDragEvent FOnEndDrag;
   TDrawBoxMarkEvent FOnMarked;
   TDrawBoxMouseEvent FOnMouseDown;
   TDrawBoxMouseMoveEvent FOnMouseMove;
   TDrawBoxMouseEvent FOnMouseUp;
   TNotifyEvent FOnPaint;
   TDrawBoxPrintDoneEvent FOnPrintDone;

   // other variables
   TDrawBoxSurface *Surface;  // drawing surface
   TCanvas *Canvas;           // where to draw
   double xw1, yw1, xw2, yw2; // window corners
   double a, b, c, d;         // conversion parm.
   int ViewportWidth;         // guess what ...
   int ViewportHeight;        // ... this is.
   TCursor oldCursor;         // remember cursor
   TDrawBoxPrintThread* PrintThread;

   // surface notifies drawbox of end of marking operation
   void NotifyMarked(int x1, int y1,
                     int x2, int y2,
                     bool region);

   // surface notifies drawbox of mousedown event
   void NotifyMouseDown(TMouseButton button,
      TShiftState shift, int x, int y);

   // surface notifies drawbox of mousemove event
   void NotifyMouseMove(TShiftState shift,
                        int x, int y);

   // surface notifies drawbox of mouseup event
   void NotifyMouseUp(TMouseButton button,
      TShiftState shift, int x, int y);

   // surface notifies drawbox of paint event
   void NotifyPaint();

   // surface notifies drawbox of printdone event
   void NotifyPrintDone(const AnsiString &job,
                        bool ok);

   // scrolls image when necessary during marking
   bool ScrollIfNeeded();

   // copies (part of) image to metafile
   TMetafile *CreateMetafile(double x1,
                             double y1,
                             double x2,
                             double y2);

   // performs various saving actions
   bool Save(const AnsiString &filename,
             bool emf,
             double x1, double y1,
             double x2, double y2);

   // sets coordinate transformation factors
   void SetTransformation();

   // converts world coordinates to device coord.
   void WorldtoPC(double xw, double yw,
                  int *xpc, int *ypc) const;

   // converts device coordinates to world coord.
   void PCtoWorld(int xpc, int ypc,
                  double *xw, double *yw) const;

   // called when Ctl3D style changes
   void __fastcall
      CMCtl3DChanged(TMessage &Message);

   // called when Cursor changes
   void __fastcall
      CMCursorChanged(TMessage &Message);

   // called on each keypress to determine
   //          which keys to pass on
   void __fastcall
      WMGetDlgCode(TMessage &Message);

   // called when key is depressed
   DYNAMIC void __fastcall
      KeyDown(Word &Key, TShiftState Shift);

   // called on drop event
   DYNAMIC void __fastcall
      DragDrop(TObject* Source, int X, int Y);

   // called on drag over event
   DYNAMIC void __fastcall
      DragOver(TObject* Source,
               int X, int Y,
               TDragState State, bool &Accept);

   // called on end of drag event
   DYNAMIC void __fastcall
      DoEndDrag(TObject* Target, int X, int Y);

   // called on horizontal scroll event
   void __fastcall
      WMHScroll(TWMScroll &Message);

   // called on vertical scroll event
   void __fastcall
      WMVScroll(TWMScroll &Message);

   // extra handled messages for TDrawBox
   BEGIN_MESSAGE_MAP
      MESSAGE_HANDLER(WM_HSCROLL, TWMScroll,
                      WMHScroll);
      MESSAGE_HANDLER(WM_VSCROLL, TWMScroll,
                      WMVScroll);
      MESSAGE_HANDLER(WM_GETDLGCODE, TMessage,
                      WMGetDlgCode);
      MESSAGE_HANDLER(CM_CTL3DCHANGED, TMessage,
                      CMCtl3DChanged);
      MESSAGE_HANDLER(CM_CURSORCHANGED, TMessage,
                      CMCursorChanged);
   END_MESSAGE_MAP(inherited)
};

//----------------------------------------------
// class TDrawBoxSurface : Actual drawing surface
// baseclass             : TPaintBox
//----------------------------------------------
class TDrawBoxSurface : public TPaintBox
{
   typedef TPaintBox inherited;

   friend TDrawBox; // all members can be private!

private:
   TDrawBox *DrawBox;    // pointer to parent
   int OriginX, OriginY; // remember coordinates
   int CurrentX, CurrentY; // ... during marking
   bool Marking;         // busy marking ?
   bool Marked;          // sticky rect marked ?
   int MarkedX, MarkedY; // sticky rect coords
   TMarkShape MarkShape; // current marking shape
   bool CrossHairs;      // draw crosshairs?
   bool Caret;           // draw caret?
   int CaretX, CaretY;   // caret coordinates
   int CaretHeight,
      CaretWidth;        // caret dimensions
   TTimer *Timer;        // for marking outside

   // constructor
   __fastcall TDrawBoxSurface(TComponent* owner);

   // called on mouse depress event
   DYNAMIC void __fastcall
      MouseDown(TMouseButton Button,
                TShiftState Shift, int X, int Y);

   // called on mouse move event
   DYNAMIC void __fastcall
      MouseMove(TShiftState Shift,
                int X, int Y);

   // called on mouse release event
   DYNAMIC void __fastcall
      MouseUp(TMouseButton Button,
              TShiftState Shift, int X, int Y);

   // called on Paint event
   virtual void __fastcall
      Paint();

   // called on timer event
   void __fastcall
      TimerTick(TObject* Sender);

   // called when pen or brush is changed
   void __fastcall // (only when designing)
      StyleChanged(TObject *Sender);

   // called when font is changed
   void __fastcall
      FontChanged(TObject *Sender);

   // draws test picture
   void __fastcall // (only when designing)
      DrawTestPicture(TObject *Sender);

   // draws marking shape
   void DrawMarkShape();

   // draws crosshairs
   void DrawCrossHairs();

   // draws caret
   void DrawCaret();

   // moves caret specified distance
   void MoveCaret(int dx, int dy);

   // sets caret on specified position
   void SetCaret(int x, int y);

   // confine caret to viewport boundaries
   // and integer*caretsize position
   void CorrectCaret();
};

//----------------------------------------------
// class TDrawBoxPrintThread : background print
// baseclass                 : TThread
//----------------------------------------------
class TDrawBoxPrintThread: public TThread
{
   friend TDrawBox; // all members can be private

private:

   // constructor, starts thread
   __fastcall TDrawBoxPrintThread(
      TDrawBox *drawbox,
      const AnsiString &jobName,
      TPrinter *printer, TMetafile *metafile,
      unsigned int from = 0,
      unsigned int to = 0,
      unsigned int copies = 1,
      bool collate = false);

   TDrawBox *DrawBox;     // pointer to drawbox
   AnsiString JobName;    // print job name
   TPrinter *Printer;     // pointer to printer
   TMetafile *Metafile;   // pointer to metafile to print
   unsigned int From, To; // start and stop pages
   unsigned Copies;       // number of copies
   bool Collate;          // collate copies?
   bool Result;           // success?

   // does actual printing
   virtual void __fastcall Execute();

   // notifies drawbox thread is done
   void __fastcall Done();

};
//----------------------------------------------
#endif

