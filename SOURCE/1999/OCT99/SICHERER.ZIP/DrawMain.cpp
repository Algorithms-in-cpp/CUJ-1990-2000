//----------------------------------------------
// Filename:      DrawMain.cpp
// Programmer:    Anneke Sicherer-Roetman
// Email:         sicherer@sichemsoft.nl
// Version:       1.00
// Revision Date: 19990606
// Description:   DrawBoxDemo Form
//----------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "DrawMain.h"
//----------------------------------------------
#pragma link "CGRID"
#pragma resource "*.dfm"
TMainForm *MainForm;
//----------------------------------------------
#define MAXRANGE 4000 // max zoom
#define MINRANGE  250 // min zoom
#define NORMAL   1000 // normal zoom
//----------------------------------------------
__fastcall
TMainForm::TMainForm(TComponent* Owner)
   : TForm(Owner)
{
   FileName = "";
   Caption = "DrawBoxDemo";
   BrushColor = clWhite;
   PenColor = clBlack;
   Invert = false;
   Initialize();
   DrawList = new TDrawList();
}
//----------------------------------------------
__fastcall
TMainForm::~TMainForm()
{
   delete DrawList;
}
//----------------------------------------------
void __fastcall
TMainForm::FileNew(TObject *Sender)
{
   DrawList->Clear();
   DrawBox->Clear();
   Initialize();
}
//----------------------------------------------
void __fastcall
TMainForm::FileOpen(TObject *Sender)
{
   if (!OpenDialog->Execute())
      return;
   FileNew(Sender);
   if (DrawList->Load(OpenDialog->FileName)) {
      FileName = OpenDialog->FileName;
      Caption = "DrawBoxDemo - " + FileName;
   }
   DrawBox->Invalidate();
}
//----------------------------------------------
void __fastcall
TMainForm::FileSave(TObject *Sender)
{
   if (FileName == "")
      FileSaveAs(Sender);
   else
      DrawList->Save(FileName);
}
//----------------------------------------------
void __fastcall
TMainForm::FileSaveAs(TObject *Sender)
{
   if (!SaveDialog->Execute())
      return;
   double x1, y1, x2, y2;
   bool marked =
      DrawBox->GetMarkBox(&x1, &y1, &x2, &y2);
   AnsiString fileName = SaveDialog->FileName;
   switch (SaveDialog->FilterIndex) {
   case 1: // native
      FileName = fileName;
      FileSave(Sender);
      Caption = "DrawBoxDemo - " + FileName;
      break;
   case 2: // emf
      if (marked)
         DrawBox->SaveToFileAsEMF(fileName,
            x1, y1, x2, y2);
      else
         DrawBox->SaveToFileAsEMF(fileName);
      break;
   case 3: // bmp
      if (marked)
         DrawBox->SaveToFileAsBMP(fileName,
            x1, y1, x2, y2);
      else
         DrawBox->SaveToFileAsBMP(fileName);
         break;
   }
}
//----------------------------------------------
void __fastcall
TMainForm::FilePrint(TObject *Sender)
{
   double x1, y1, x2, y2;
   // see if there is a marked block
   bool marked =
      DrawBox->GetMarkBox(&x1, &y1, &x2, &y2);
   // compose print options
   PrintDialog->Options.Clear();
   if (marked)
      PrintDialog->Options << poSelection;
   PrintDialog->Options << poPageNums;
   PrintDialog->MinPage = 1;
   PrintDialog->MaxPage =
      DrawBox->CountPrintPages();
   // show print dialog
   if (!PrintDialog->Execute())
      return;
   // determine print range
   unsigned int from =
      PrintDialog->PrintRange == prPageNums ?
         PrintDialog->FromPage : 0;
   unsigned int to =
      PrintDialog->PrintRange == prPageNums ?
         PrintDialog->ToPage : 0;
   if (PrintDialog->PrintRange == prSelection) {
      // print selection
      DrawBox->Print("DrawBoxDemo",
         x1, y1, x2, y2,
         0, 0, PrintDialog->Copies,
         PrintDialog->Collate);
   } else {
      // print requested pages of entire canvas
      DrawBox->Print("DrawBoxDemo",
         from, to, PrintDialog->Copies,
         PrintDialog->Collate);
   }
}
//----------------------------------------------
void __fastcall
TMainForm::FilePrintSetup(TObject *Sender)
{
   PrintSetupDialog->Execute();
}
//----------------------------------------------
void __fastcall
TMainForm::FileExit(TObject *Sender)
{
   Close();
}
//----------------------------------------------
void __fastcall
TMainForm::EditCopy(TObject *Sender)
{
   double x1, y1, x2, y2;
   // see if there is a marked block
   bool marked =
      DrawBox->GetMarkBox(&x1, &y1, &x2, &y2);
   if (marked)
      // copy marked block to clipboard
      DrawBox->CopyToClipboardAsEMF(
         x1, y1, x2, y2);
   else
      // copy entire image to clipboard
      DrawBox->CopyToClipboardAsEMF();
}
//----------------------------------------------
void __fastcall
TMainForm::EditDelete(TObject *Sender)
{
   if (!SelectedItem)
      return;
   // delete selected object from list
   DrawList->Delete(SelectedItem);
   // delete marker item also from list
   DrawList->Delete(MarkerItem);
   // redraw
   DrawBox->Invalidate();
   SelectedItem = NULL;
}
//----------------------------------------------
void __fastcall
TMainForm::ViewZoomInItemClick(TObject *Sender)
{
   if (Range >= MAXRANGE)
      return;
   double x, y;
   DrawBox->GetWindowOrigin(&x, &y);
   Range *= 2;
   DrawBox->HorzScrollBar->Range = Range;
   DrawBox->VertScrollBar->Range = Range;
   DrawBox->SetWindowExtents(0, 0,
                             NORMAL, NORMAL);
   DrawBox->SetWindowOrigin(x, y);
}
//----------------------------------------------
void __fastcall
TMainForm::ViewZoomOutItemClick(TObject *Sender)
{
   if (Range <= MINRANGE)
      return;
   double x, y;
   DrawBox->GetWindowOrigin(&x, &y);
   Range /= 2;
   DrawBox->HorzScrollBar->Range = Range;
   DrawBox->VertScrollBar->Range = Range;
   DrawBox->SetWindowExtents(0, 0,
                             NORMAL, NORMAL);
   DrawBox->SetWindowOrigin(x, y);
}
//----------------------------------------------
void __fastcall
TMainForm::ViewNormalItemClick(TObject *Sender)
{
   Range = NORMAL;
   DrawBox->HorzScrollBar->Range = Range;
   DrawBox->VertScrollBar->Range = Range;
   DrawBox->SetWindowExtents(0, 0,
                             NORMAL, NORMAL);
}
//----------------------------------------------
void __fastcall
TMainForm::AboutItemClick(TObject *Sender)
{
   Application->MessageBox("TDrawBox \
Demo Application\n\n\
(C)1999 Anneke Sicherer-Roetman\n\
email: sicherer@sichemsoft.nl",
      "About DrawBoxDemo",MB_OK);
}
//----------------------------------------------
void __fastcall
TMainForm::ArrowButtonClick(TObject *Sender)
{
   DrawBox->MarkShape = msMark;
   DrawBox->Cursor = crArrow;
}
//----------------------------------------------
void __fastcall
TMainForm::LineButtonClick(TObject *Sender)
{
   DrawBox->MarkShape = msLine;
   DrawBox->Cursor = crCross;
}
//----------------------------------------------
void __fastcall
TMainForm::RectButtonClick(TObject *Sender)
{
   DrawBox->MarkShape = msRectangle;
   DrawBox->Cursor = crCross;
   Invert = false;
}
//----------------------------------------------
void __fastcall
TMainForm::RoundRectButtonClick(TObject *Sender)
{
   DrawBox->MarkShape = msRoundRect;
   DrawBox->Cursor = crCross;
}
//----------------------------------------------
void __fastcall
TMainForm::EllipseButtonClick(TObject *Sender)
{
   DrawBox->MarkShape = msEllipse;
   DrawBox->Cursor = crCross;
}
//----------------------------------------------
void __fastcall
TMainForm::InvertButtonClick(TObject *Sender)
{
   DrawBox->MarkShape = msRectangle;
   DrawBox->Cursor = crCross;
   Invert = true;
}
//----------------------------------------------
void __fastcall
TMainForm::TextButtonClick(TObject *Sender)
{
   DrawBox->MarkShape = msNone; // text
   DrawBox->Cursor = crCross;
}
//----------------------------------------------
void __fastcall
TMainForm::ColorGridChange(TObject *Sender)
{
   PenColor =
      ColorGrid->ForegroundColor;
   if (BrushColor != NOCOLOR)
      BrushColor =
         ColorGrid->BackgroundColor;
}
//----------------------------------------------
void __fastcall
TMainForm::HollowButtonClick(TObject *Sender)
{
   bool hollow = HollowButton->Down;
   ColorGrid->BackgroundEnabled = !hollow;
   BrushColor = hollow ? NOCOLOR :
      ColorGrid->BackgroundColor;
}
//----------------------------------------------
void __fastcall TMainForm::CrossHairsButtonClick(
   TObject *Sender)
{
   DrawBox->CrossHairs = CrossHairsButton->Down;
}
//--------------------------------------------------------------------------
void __fastcall TMainForm::DrawBoxPaint(
   TObject *Sender)
{
   DrawList->Draw(DrawBox);
}
//----------------------------------------------
void __fastcall TMainForm::DrawBoxClick(
   TObject *Sender, double X, double Y)
{
   ClearSelection();
   TDrawItem *drawItem = NULL;
   if (DrawBox->MarkShape == msNone) { // text
      AnsiString string;
      if (!InputQuery("Enter Text",
                      "", string))
         return;
      double width, height;
      DrawBox->GetTextExtents(string,
                              &width, &height);
      drawItem =
         new TTextItem(X, Y,
                       X + width, Y + height,
                       string,
                       PenColor, BrushColor);
   } else if (DrawBox->MarkShape == msMark) {
      double x1, y1, x2, y2;
      SelectedItem =
         DrawList->Find(X, Y,
                        &x1, &y1, &x2, &y2);
      if (SelectedItem)
         drawItem = MarkerItem =
            new TMarkerItem(x1, y1, x2, y2);
   }
   if (drawItem) {
      DrawList->Add(drawItem);
      drawItem->Draw(DrawBox);
   }
}
//----------------------------------------------
void __fastcall
TMainForm::DrawBoxMarked(TObject *Sender,
                         double Left,
                         double Top,
                         double Right,
                         double Bottom)
{
   ClearSelection();
   TDrawItem *drawItem = NULL;
   switch (DrawBox->MarkShape) {
   case msLine:
      drawItem =
         new TLineItem(Left, Top, Right, Bottom,
                       PenColor);
      break;
   case msRoundRect:
      drawItem =
         new TRoundRectItem(Left, Top,
                            Right, Bottom,
                            PenColor,
                            BrushColor);
      break;
   case msEllipse:
      drawItem =
         new TEllipseItem(Left, Top,
                          Right, Bottom,
                          PenColor, BrushColor);
      break;
   case msRectangle:
      if (Invert) {
         drawItem =
            new TInvertItem(Left, Top,
                            Right, Bottom);
      } else {
         drawItem =
            new TRectangleItem(Left, Top,
                               Right, Bottom,
                               PenColor,
                               BrushColor);
      }
      break;
   }
   if (drawItem) {
      DrawList->Add(drawItem);
      drawItem->Draw(DrawBox);
   }
}
//----------------------------------------------
void __fastcall
TMainForm::DrawBoxMouseMove(TObject *Sender,
                            TShiftState Shift,
                            double X, double Y)
{
   char buffer[20];
   sprintf(buffer,"%6.1f %6.1f", X, Y);
   CoordPanel->Caption = buffer;
}
//----------------------------------------------
void
TMainForm::Initialize()
{
   Range = NORMAL;
   DrawBox->HorzScrollBar->Range = NORMAL;
   DrawBox->VertScrollBar->Range = NORMAL;
   DrawBox->SetWindowExtents(0, 0,
                             NORMAL, NORMAL);
   DrawBox->SetWindowOrigin(0, 0);
   SelectedItem = NULL;
}
//----------------------------------------------
void
TMainForm::ClearSelection()
{
   if (!SelectedItem)
      return;
   DrawList->Delete(MarkerItem);
   SelectedItem = NULL;
   DrawBox->Invalidate();
}
//----------------------------------------------

