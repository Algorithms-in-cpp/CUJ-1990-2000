//----------------------------------------------
// Filename:      DrawList.h
// Programmer:    Anneke Sicherer-Roetman
// Email:         sicherer@sichemsoft.nl
// Version:       1.00
// Revision Date: 19990606
// Description:   DrawBoxDemo Object List
//----------------------------------------------
#ifndef DrawListH
#define DrawListH
#include <vcl\vcl.h>
#include <fstream.h>
#include <list>
using namespace std;
#include "DrawBox.h"
//----------------------------------------------
enum TDrawItemType { // shapes in object list
   line, rectangle, roundrect,
   ellipse, invert, text
};
#define NOCOLOR (TColor(-1)) // transparent
//----------------------------------------------
class TDrawItem : public TObject
// abstract base class for TDrawList items
{
public:
   static TDrawItem *Load(ifstream &ifp);
   virtual void Save(ofstream &ofp) = 0;
   virtual void Draw(TDrawBox *drawBox) = 0;
   bool Hit(double x, double y,
            double *x1, double *y1,
            double *x2, double *y2);

protected:
   TDrawItem(double x1, double y1,
             double x2, double y2,
             TColor lineColor,
             TColor fillColor);
   TDrawItem(ifstream &ifp);
   void Save(ofstream &ofp, TDrawItemType type);
   void SetPen(TColor *oldColor,
               const TDrawBox *drawBox);
   void ResetPen(TColor oldColor,
                 const TDrawBox *drawBox);
   void SetBrush(TColor *oldColor,
                 TBrushStyle *oldStyle,
                 const TDrawBox *drawBox);
   void ResetBrush(TColor oldColor,
                   TBrushStyle oldStyle,
                   const TDrawBox *drawBox);

   double X1, Y1, X2, Y2;
   TColor LineColor, FillColor;
};
//----------------------------------------------
class TLineItem : public TDrawItem
{
public:
   TLineItem(double x1, double y1,
             double x2, double y2,
             TColor lineColor);
   TLineItem(ifstream &ifp);
   virtual void Save(ofstream &ofp);
   virtual void Draw(TDrawBox *drawBox);

private:
   double LX1, LY1, LX2, LY2;
};
//----------------------------------------------
class TRectangleItem : public TDrawItem
{
public:
   TRectangleItem(double x1, double y1,
                  double x2, double y2,
                  TColor lineColor,
                  TColor fillColor);
   TRectangleItem(ifstream &ifp);
   virtual void Save(ofstream &ofp);
   virtual void Draw(TDrawBox *drawBox);
};
//----------------------------------------------
class TRoundRectItem : public TDrawItem
{
public:
   TRoundRectItem(double x1, double y1,
                  double x2, double y2,
                  TColor lineColor,
                  TColor fillColor);
   TRoundRectItem(ifstream &ifp);
   virtual void Save(ofstream &ofp);
   virtual void Draw(TDrawBox *drawBox);
};
//----------------------------------------------
class TEllipseItem : public TDrawItem
{
public:
   TEllipseItem(double x1, double y1,
                double x2, double y2,
                TColor lineColor,
                TColor fillColor);
   TEllipseItem(ifstream &ifp);
   virtual void Draw(TDrawBox *drawBox);
   virtual void Save(ofstream &ofp);
};
//----------------------------------------------
class TInvertItem : public TDrawItem
{
public:
   TInvertItem(double x1, double y1,
               double x2, double y2);
   TInvertItem(ifstream &ifp);
   virtual void Save(ofstream &ofp);
   virtual void Draw(TDrawBox *drawBox);
};
//----------------------------------------------
class TTextItem : public TDrawItem
{
public:
   TTextItem(double x1, double y1,
             double x2, double y2,
             const AnsiString &string,
             TColor lineColor,
             TColor fillColor);
   TTextItem(ifstream &ifp);
   virtual void Save(ofstream &ofp);
   virtual void Draw(TDrawBox *drawBox);

private:
   AnsiString String;
};
//----------------------------------------------
class TMarkerItem : public TDrawItem
{
public:
   TMarkerItem(double x1, double y1,
               double x2, double y2);
   virtual void Save(ofstream &ofp) {} // don't!
   virtual void Draw(TDrawBox *drawBox);
};
//----------------------------------------------
class TDrawList
{
public:
   TDrawList();
   ~TDrawList();
   bool Load(const AnsiString &filename);
   void Save(const AnsiString &filename);
   void Draw(TDrawBox *drawBox);
   void Add(TDrawItem *item);
   void Delete(TDrawItem *item);
   void Clear();
   TDrawItem *Find(double x, double y,
                   double *x1, double *y1,
                   double *x2, double *y2);

private:
   typedef list<TDrawItem *> TInternalDrawList;
   TInternalDrawList List;
   TInternalDrawList::iterator Current;
};
//----------------------------------------------
#endif
//----------------------------------------------

