//----------------------------------------------
// Filename:      DrawBoxDemo.cpp
// Programmer:    Anneke Sicherer-Roetman
// Email:         sicherer@sichemsoft.nl
// Version:       1.00
// Revision Date: 19990606
// Description:   Main DrawBoxDemo program
//----------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("DrawBoxDemo.res");
USEFORM("DrawMain.cpp", MainForm);
USEUNIT("DrawList.cpp");
//----------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
       Application->Initialize();
       Application->Title = "DrawBoxDemo";
       Application->CreateForm(
          __classid(TMainForm), &MainForm);
       Application->Run();
   }
   catch (Exception &exception)
   {
       Application->ShowException(&exception);
   }
   return 0;
}
//----------------------------------------------
