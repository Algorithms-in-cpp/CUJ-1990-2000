//----------------------------------------------
// Filename:      DrawList.cpp
// Programmer:    Anneke Sicherer-Roetman
// Email:         sicherer@sichemsoft.nl
// Version:       1.00
// Revision Date: 19990606
// Description:   DrawBoxDemo Object List
//----------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "DrawList.h"
#pragma package(smart_init)
//----------------------------------------------
// shorthand for write / read calls
#define Write(os, nr) \
   os.write((char*)(&nr), sizeof(nr))
#define Read(is, nr) \
   is.read((char*)(&nr), sizeof(nr))
#define MARK 3 // marker size
//----------------------------------------------
inline void 
Swap(double &a, double &b)
{ double tmp = a; a = b; b = tmp; }
//----------------------------------------------
//----------------------------------------------
TDrawItem::TDrawItem(double x1, double y1,
                     double x2, double y2,
                     TColor lineColor,
                     TColor fillColor) :
   X1(x1), Y1(y1), X2(x2), Y2(y2),
   LineColor(lineColor), FillColor(fillColor)
{}
//----------------------------------------------
TDrawItem::TDrawItem(ifstream &ifp)
{
   Read(ifp, X1);
   Read(ifp, Y1);
   Read(ifp, X2);
   Read(ifp, Y2);
   Read(ifp, LineColor);
   Read(ifp, FillColor);
}
//----------------------------------------------
TDrawItem *
TDrawItem::Load(ifstream &ifp) // static
{
   TDrawItemType type;
   Read(ifp, type);
   switch (type) {
   case line: 
      return new TLineItem(ifp);
   case rectangle: 
      return new TRectangleItem(ifp);
   case roundrect: 
      return new TRoundRectItem(ifp);
   case ellipse: 
      return new TEllipseItem(ifp);
   case invert: 
      return new TInvertItem(ifp);
   case text: 
      return new TTextItem(ifp);
   }
   return NULL;
}
//----------------------------------------------
void
TDrawItem::Save(ofstream &ofp,
                TDrawItemType type)
{
   Write(ofp, type);
   Write(ofp, X1);
   Write(ofp, Y1);
   Write(ofp, X2);
   Write(ofp, Y2);
   Write(ofp, LineColor);
   Write(ofp, FillColor);
}
//----------------------------------------------
bool
TDrawItem::Hit(double x, double y,
               double *x1, double *y1,
               double *x2, double *y2)
{
   if (x >= X1 && x <= X2 &&
       y >= Y1 && y <= Y2) {
      *x1 = X1; *y1 = Y1; 
      *x2 = X2; *y2 = Y2;
      return true;
   }
   return false;
}
//----------------------------------------------
void
TDrawItem::SetPen(TColor *oldColor,
                  const TDrawBox *drawBox)
{
   *oldColor = drawBox->Pen->Color;
   drawBox->Pen->Color = LineColor;
}
//----------------------------------------------
void
TDrawItem::ResetPen(TColor oldColor,
                    const TDrawBox *drawBox)
{
   drawBox->Pen->Color = oldColor;
}
//----------------------------------------------
void
TDrawItem::SetBrush(TColor *oldColor,
                    TBrushStyle *oldStyle,
                    const TDrawBox *drawBox)
{
   *oldColor = drawBox->Brush->Color;
   *oldStyle = drawBox->Brush->Style;
   if (FillColor == NOCOLOR)
      drawBox->Brush->Style = bsClear;
   else {
      drawBox->Brush->Style = bsSolid;
      drawBox->Brush->Color = FillColor;
   }
}
//----------------------------------------------
void
TDrawItem::ResetBrush(TColor oldColor,
                      TBrushStyle oldStyle,
                      const TDrawBox *drawBox)
{
   drawBox->Brush->Color = oldColor;
   drawBox->Brush->Style = oldStyle;
}
//----------------------------------------------
TLineItem::TLineItem(double x1, double y1,
                     double x2, double y2,
                     TColor lineColor):
   TDrawItem(x1, y1, x2, y2, 
             lineColor, NOCOLOR),
   LX1(x1), LY1(y1), LX2(x2), LY2(y2)
{
   // correct bounding box
   if (X1 > X2) Swap(X1, X2);
   if (Y1 > Y2) Swap(Y1, Y2);
}
//----------------------------------------------
TLineItem::TLineItem(ifstream &ifp):
   TDrawItem(ifp)
{
   Read(ifp, LX1);
   Read(ifp, LY1);
   Read(ifp, LX2);
   Read(ifp, LY2);
}
//----------------------------------------------
void
TLineItem::Save(ofstream &ofp) // virtual
{
   TDrawItem::Save(ofp, line);
   Write(ofp, LX1);
   Write(ofp, LY1);
   Write(ofp, LX2);
   Write(ofp, LY2);
}
//----------------------------------------------
void
TLineItem::Draw(TDrawBox *drawBox) // virtual
{
   TColor oldPenColor;
   SetPen(&oldPenColor, drawBox);
   drawBox->DrawLine(LX1, LY1, LX2, LY2);
   ResetPen(oldPenColor, drawBox);
}
//----------------------------------------------
//----------------------------------------------
TRectangleItem::TRectangleItem(
                double x1, double y1,
                double x2, double y2,
                TColor lineColor,
                TColor fillColor):
   TDrawItem(x1, y1, x2, y2,
             lineColor, fillColor)
{}
//----------------------------------------------
TRectangleItem::TRectangleItem(ifstream &ifp):
   TDrawItem(ifp)
{
}
//----------------------------------------------
void
TRectangleItem::Save(ofstream &ofp) // virtual
{
   TDrawItem::Save(ofp, rectangle);
}
//----------------------------------------------
void
TRectangleItem::Draw(TDrawBox *drawBox) // virt.
{
   TColor oldPenColor;
   SetPen(&oldPenColor, drawBox);
   TColor oldBrushColor;
   TBrushStyle oldBrushStyle;
   SetBrush(&oldBrushColor, &oldBrushStyle,
            drawBox);
   drawBox->DrawRectangle(X1, Y1, X2, Y2);
   ResetPen(oldPenColor, drawBox);
   ResetBrush(oldBrushColor, oldBrushStyle,
              drawBox);
}
//----------------------------------------------
//----------------------------------------------
TRoundRectItem::TRoundRectItem(
                double x1, double y1,
                double x2, double y2,
                TColor lineColor,
                TColor fillColor):
   TDrawItem(x1, y1, x2, y2,
             lineColor, fillColor)
{}
//----------------------------------------------
TRoundRectItem::TRoundRectItem(ifstream &ifp):
   TDrawItem(ifp)
{}
//----------------------------------------------
void
TRoundRectItem::Save(ofstream &ofp) // virtual
{
   TDrawItem::Save(ofp, roundrect);
}
//----------------------------------------------
void
TRoundRectItem::Draw(TDrawBox *drawBox) // virt.
{
   TColor oldPenColor;
   SetPen(&oldPenColor, drawBox);
   TColor oldBrushColor;
   TBrushStyle oldBrushStyle;
   SetBrush(&oldBrushColor, &oldBrushStyle,
            drawBox);
   drawBox->DrawRoundRect(X1, Y1, X2, Y2);
   ResetPen(oldPenColor, drawBox);
   ResetBrush(oldBrushColor, oldBrushStyle,
              drawBox);
}
//----------------------------------------------
//----------------------------------------------
TEllipseItem::TEllipseItem(double x1, double y1,
                           double x2, double y2,
                           TColor lineColor,
                           TColor fillColor):
   TDrawItem(x1, y1, x2, y2,
             lineColor, fillColor)
{}
//----------------------------------------------
TEllipseItem::TEllipseItem(ifstream &ifp):
   TDrawItem(ifp)
{}
//----------------------------------------------
void
TEllipseItem::Save(ofstream &ofp) // virtual
{
   TDrawItem::Save(ofp, ellipse);
}
//----------------------------------------------
void
TEllipseItem::Draw(TDrawBox *drawBox) // virtual
{
   TColor oldPenColor;
   SetPen(&oldPenColor, drawBox);
   TColor oldBrushColor;
   TBrushStyle oldBrushStyle;
   SetBrush(&oldBrushColor, &oldBrushStyle,
            drawBox);
   drawBox->DrawEllipse(X1, Y1, X2, Y2);
   ResetPen(oldPenColor, drawBox);
   ResetBrush(oldBrushColor, oldBrushStyle,
              drawBox);
}
//----------------------------------------------
//----------------------------------------------
TInvertItem::TInvertItem(double x1, double y1,
                         double x2, double y2):
   TDrawItem(x1, y1, x2, y2, NOCOLOR, NOCOLOR)
{}
//----------------------------------------------
TInvertItem::TInvertItem(ifstream &ifp):
   TDrawItem(ifp)
{}
//----------------------------------------------
void
TInvertItem::Save(ofstream &ofp) // virtual
{
   TDrawItem::Save(ofp, invert);
}
//----------------------------------------------
void
TInvertItem::Draw(TDrawBox *drawBox) // virtual
{
   drawBox->DrawInvert(X1, Y1, X2, Y2);
}
//----------------------------------------------
//----------------------------------------------
TTextItem::TTextItem(double x1, double y1,
                     double x2, double y2,
                     const AnsiString &string,
                     TColor lineColor,
                     TColor fillColor):
   TDrawItem(x1, y1, x2, y2,
             lineColor, fillColor),
   String(string)
{}
//----------------------------------------------
TTextItem::TTextItem(ifstream &ifp):
   TDrawItem(ifp)
{
   int len;
   Read(ifp, len);
   char *buffer = new char[len];
   ifp.read(buffer,len);
   String = buffer;
   delete buffer;
}
//----------------------------------------------
void
TTextItem::Save(ofstream &ofp) // virtual
{
   TDrawItem::Save(ofp, text);
   int len = String.Length() + 1;
   Write(ofp, len);
   ofp.write(String.c_str(), len);
}
//----------------------------------------------
void
TTextItem::Draw(TDrawBox *drawBox) // virtual
{
   // We have to set the font color 'manually'
   // because the BCB VCL seems to inhibit
   // font color changes during the handling
   // of one paint message (cacheing probem?)
   HDC hdc = drawBox->GetCanvas()->Handle;
   int oldBkMode = ::GetBkMode(hdc);
   ::SetBkMode(hdc, FillColor == NOCOLOR ?
                    TRANSPARENT : OPAQUE);
   COLORREF oldTextColor = ::GetTextColor(hdc);
   ::SetTextColor(hdc, ColorToRGB(LineColor));
   COLORREF oldBkColor = ::GetBkColor(hdc);
   ::SetBkColor(hdc, ColorToRGB(FillColor));

   // now draw the text normally
   drawBox->DrawText(X1, Y1, String);

   // restore everything we've done
   ::SetBkMode(hdc, oldBkMode);
   ::SetTextColor(hdc, oldTextColor);
   ::SetBkColor(hdc, oldBkColor);
}
//----------------------------------------------
//----------------------------------------------
TMarkerItem::TMarkerItem(double x1, double y1,
                         double x2, double y2):
   TDrawItem(x1, y1, x2, y2, NOCOLOR, NOCOLOR)
{
}
//----------------------------------------------
void
TMarkerItem::Draw(TDrawBox *drawBox) // virtual
{
   drawBox->DrawMarker(X1, Y1);
   drawBox->DrawMarker(X1, Y2);
   drawBox->DrawMarker(X2, Y1);
   drawBox->DrawMarker(X2, Y2);
}
//----------------------------------------------
//----------------------------------------------
TDrawList::TDrawList()
{
   Current = List.begin();
}
//----------------------------------------------
TDrawList::~TDrawList()
{
   Clear();
}
//----------------------------------------------
bool
TDrawList::Load(const AnsiString &filename)
{
   ifstream ifp;
   ifp.open(filename.c_str(),
            ios::in | ios::binary);
   if (ifp.fail()) {
      Application->MessageBox(
         "File could not be opened",
         "Error",MB_OK | MB_ICONHAND);
      return false;
   }
   Clear();
   int size; Read(ifp, size);
   for (int i = 0; i < size; ++i) {
      TDrawItem *item = TDrawItem::Load(ifp);
      List.push_back(item);
   }
   ifp.close();
   return true;
}
//----------------------------------------------
void
TDrawList::Save(const AnsiString &filename)
{
   ofstream ofp;
   ofp.open(filename.c_str(),
            ios::out | ios::binary);
   if (ofp.fail()) {
      Application->MessageBox(
         "File could not be saved",
         "Error",MB_OK | MB_ICONHAND);
      return;
   }
   int count = List.size();
   Write(ofp, count);
   TInternalDrawList::iterator i;
   for (i = List.begin(); i != List.end(); ++i)
      (*i)->Save(ofp);
   ofp.close();
}
//----------------------------------------------
void
TDrawList::Draw(TDrawBox *drawBox)
{
   drawBox->Clear();
   TInternalDrawList::iterator i;
   for (i = List.begin(); i != List.end(); ++i)
      (*i)->Draw(drawBox);
}
//----------------------------------------------
void
TDrawList::Add(TDrawItem *item)
{
   List.push_back(item);
}
//----------------------------------------------
void
TDrawList::Delete(TDrawItem *item)
{
   TInternalDrawList::iterator i;
   for (i = List.begin();
        i != List.end(); ++i) {
      if (*i == item) {
         bool current = (i == Current);
         delete *i;
         List.erase(i);
         if (current)
            Current = List.begin();
         break;
      }
   }
}
//----------------------------------------------
void
TDrawList::Clear()
{
   TInternalDrawList::iterator i;
   for (i = List.begin(); i != List.end(); ++i)
      delete *i;
   List.clear();
   Current = List.begin();
}
//----------------------------------------------
TDrawItem *
TDrawList::Find(double x, double y,
                double *x1, double *y1,
                double *x2, double *y2)
{
   for (int n = List.size(); n; --n) {
      Current++;
      if (Current == List.end())
         Current = List.begin();
      if ((*Current)->Hit(x, y, x1, y1, x2, y2))
         return *Current;
   }
   return NULL;
}
//----------------------------------------------

