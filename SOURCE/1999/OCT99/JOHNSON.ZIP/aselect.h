// class to save the current graphical drawing object, select a new one, 
// then restore the old one upon destruction.  An instance of this
// class must be constructed and destroyed within the processing 
// of a single Windows message.  (Otherwise, the class might be
// left with a dangling pointer; see MSDN topic 'CDC::SelectObject'.)
     
class AutoSelector
{
public:
   AutoSelector(CDC* pDC, CGdiObject* pNew) 
   :  m_pOld( pDC->SelectObject(pNew) ),
      m_pDC( pDC )
   {
      ASSERT(m_pOld);
      ASSERT( !pNew->IsKindOf(RUNTIME_CLASS(CRgn)) );
   }
     
   AutoSelector(CDC* pDC, int iStockObject)
   :  m_pOld( pDC->SelectStockObject(iStockObject) ),
      m_pDC( pDC )
   {
      ASSERT(m_pOld);
   }
     
   ~AutoSelector()
   {
      m_pDC->SelectObject(m_pOld);
   }
     
private:
   // prevent use of (incorrect) defaults 
   AutoSelector(const AutoSelector& a); 
   AutoSelector& operator=(const AutoSelector& a);
     
   // prevent region selection at compile time when possible 
   AutoSelector(CDC* pDC, CRgn* pRgn);
     
   CGdiObject* m_pOld;
   CDC* m_pDC;
};

