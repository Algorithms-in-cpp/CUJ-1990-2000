// try2.h, Listing 3

class Singleton
{
public:
  static Singleton& instance();
  void show_state();

protected:
  Singleton();

private:
  int state;
};

Singleton& Singleton::instance()
{
  static Singleton _instance;
  return _instance;
}
