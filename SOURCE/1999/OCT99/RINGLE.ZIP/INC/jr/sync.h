/*---------------------------------------------------------------------------*\

  Copyright (C) 1999 by Jonathan Ringle.  You may freely use and modify
  this software, subject to the following restrictions:
  (1) This copyright notice must remain in the source, unchanged.
  (2) You are NOT allowed to redistribute this software in any form.
  
    NOTE: This software is provided without warranty of any kind.
    
\*---------------------------------------------------------------------------*/

#if !defined(__JR_SYNC_H__INCLUDED__)
#define __JR_SYNC_H__INCLUDED__

#if _MSC_VER >= 1000
#	pragma once
#endif // _MSC_VER >= 1000

#if !defined(_INC_WINDOWS)
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

namespace jr
{
  class Critical_Section
  {
  public:
    Critical_Section() { InitializeCriticalSection(&mutex); }
    ~Critical_Section() { DeleteCriticalSection(&mutex); }
    
    void acquire() { EnterCriticalSection(&mutex); }
    void release() { LeaveCriticalSection(&mutex); }
    
  private:
    CRITICAL_SECTION mutex;
  };
  
  template< class Key >
    class Lock_Guard
  {
  public:
    Lock_Guard( Key& a_key ) : _key( a_key ) { lock(); }
    ~Lock_Guard() { unlock(); }
    
    void lock() { _key.acquire(); }
    void unlock() { _key.release(); }
    
  private:
    Key& _key;
  };
  
} // namespace jr

#endif // !defined(__JR_SYNC_H__INCLUDED__)
