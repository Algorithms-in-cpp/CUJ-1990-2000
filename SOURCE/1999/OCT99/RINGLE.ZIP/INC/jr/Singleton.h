/*---------------------------------------------------------------------------*\

  Copyright (C) 1999 by Jonathan Ringle.  You may freely use and modify
  this software, subject to the following restrictions:
  (1) This copyright notice must remain in the source, unchanged.
  (2) You are NOT allowed to redistribute this software in any form.
  
    NOTE: This software is provided without warranty of any kind.
    
\*---------------------------------------------------------------------------*/

#if !defined(__JR_SINGLETON_H__INCLUDED__)
#define __JR_SINGLETON_H__INCLUDED__

#if _MSC_VER >= 1000
#  pragma once
#endif // _MSC_VER >= 1000

#include <stack>
#include "jr/sync.h"

namespace jr
{
  class Singleton_Base
  {
    friend class Singleton_Manager;
  protected:
    Singleton_Base() { }
    virtual ~Singleton_Base() { }
    
    static Critical_Section& manager_key();
    static void add_to_manager( Singleton_Base* singleton );
  };
  
  template< class T >
    class Singleton : private Singleton_Base
  {
  public:
    static T& instance();
    
  protected:
    Singleton();
    virtual ~Singleton();
    
  private:
    T _object;
    static Singleton< T >* _instance;
  };
  
  class Singleton_Manager
  {
    friend class Singleton_Base;
    friend class Singleton_Manager_Creator;
  protected:
    Singleton_Manager();
    ~Singleton_Manager();
    
    Critical_Section& key() { return _key; }
    static Singleton_Manager& instance();
    
    void add( Singleton_Base* singleton );
    
  private:
    std::stack< Singleton_Base* > _singleton_stack;
    
    static Singleton_Manager* _instance;
    static Critical_Section _key;
  };
  
} // namespace jr

#include "jr/singleton.i"

#endif // !defined(__JR_SINGLETON_H__INCLUDED__)
