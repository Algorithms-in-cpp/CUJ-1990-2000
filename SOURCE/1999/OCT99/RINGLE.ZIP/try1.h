// try1.h, Listing 2

class Singleton
{
public:
  static Singleton& instance();
  void show_state();

protected:
  Singleton();

private:
  static Singleton* _instance;
  int state;
};

Singleton* Singleton::_instance = NULL;

inline Singleton& Singleton::instance()
{
  if(!_instance) // Race condition exists here
    _instance = new Singleton;

  return *_instance;
}
