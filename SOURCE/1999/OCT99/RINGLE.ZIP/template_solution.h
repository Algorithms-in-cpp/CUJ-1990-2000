// solution.h, Listing 6

#include "jr/singleton.h"

class Singleton
{
  friend class jr::Singleton< Singleton >;
public:
  static Singleton& instance();
  void show_state();

protected:
  Singleton();

private:
  int state;
};

inline Singleton& Singleton::instance()
{
  return jr::Singleton< Singleton >::instance();
}
