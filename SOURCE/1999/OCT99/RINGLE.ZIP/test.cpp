// test.cpp, Listing 1

#include <windows.h>
#include <process.h>
#include <stdio.h>
#include <time.h>

//#include "try1.h"
//#include "try2.h"
//#include "try3.h"
//#include "solution.h"
#include "template_solution.h"

class Timer
{
public:
  Timer() : start_(0), stop_(0) { }

  void start() { start_ = clock(); }
  void stop() { stop_ = clock(); }

  double elapsed() const
  { return (double)(stop_ - start_) / CLOCKS_PER_SEC; }

private:
  clock_t start_;
  clock_t stop_;
};

Singleton::Singleton()
{
  printf("Singleton 0x%08X has been allocated by tid %d\n",
    this, ::GetCurrentThreadId());
 
  Sleep(1000); // Simulate a long operation.

  state = 0xABCD; // Initialize dummy state.
  printf("Singleton 0x%08X -state initialized by tid %d\n",
    this, ::GetCurrentThreadId());
}

void Singleton::show_state()
{
  printf("show_state(): this=0x%08X state=0x%04X tid=%d\n",
    this, state, ::GetCurrentThreadId());
}

void join(long thread_handle)
{
  // Join with thread.
  WaitForSingleObject(reinterpret_cast<HANDLE>(thread_handle),
    INFINITE);
}

void profile()
{
  Timer timer;
  int i = 0;

  timer.start();
  for(; i < 10000000; ++i)
    Singleton::instance();

  timer.stop();

  printf("Profiling on tid %d took %f seconds\n",
    ::GetCurrentThreadId(), timer.elapsed());
}

void thread2(void*)
{
  printf("thread2 tid is %d\n", ::GetCurrentThreadId());
  Singleton::instance().show_state();

  profile();
}

int main(int, char*[])
{
  printf("main tid is %d\n", ::GetCurrentThreadId());
  long spawned_thread = _beginthread(thread2, 0, NULL);

  Singleton::instance().show_state();
  
  profile();
  join(spawned_thread);

  return 0;
}
