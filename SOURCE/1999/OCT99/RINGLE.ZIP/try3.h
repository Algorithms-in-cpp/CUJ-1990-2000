// try3.h, Listing 5

#include "jr/sync.h"

class Singleton
{
public:
  static Singleton& instance();
  void show_state();

protected:
  Singleton();

private:
  static Singleton* _instance;
  static jr::Critical_Section _key;
  int state;
};

Singleton* Singleton::_instance = NULL;
jr::Critical_Section Singleton::_key;

inline Singleton& Singleton::instance()
{
  jr::Lock_Guard<jr::Critical_Section> gate(_key);

  if(!_instance)
    _instance = new Singleton;

  return *_instance;
}
