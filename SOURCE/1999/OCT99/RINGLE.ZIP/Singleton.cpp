/*---------------------------------------------------------------------------*\

  Copyright (C) 1999 by Jonathan Ringle.  You may freely use and modify
  this software, subject to the following restrictions:
  (1) This copyright notice must remain in the source, unchanged.
  (2) You are NOT allowed to redistribute this software in any form.
  
    NOTE: This software is provided without warranty of any kind.
    
\*---------------------------------------------------------------------------*/

#include "jr/singleton.h"

namespace jr
{
  Singleton_Manager* Singleton_Manager::_instance = 0;
  Critical_Section Singleton_Manager::_key;
  
  Singleton_Manager::Singleton_Manager()
    : _singleton_stack()
  {
  }
  
  Singleton_Manager::~Singleton_Manager()
  {
    Singleton_Base* s;
    while( !_singleton_stack.empty() )
    {
      s = _singleton_stack.top();
      _singleton_stack.pop();
      delete s;
    }
  }	
  
  inline Singleton_Manager& Singleton_Manager::instance()
  {
    if( !_instance )
    {
      Lock_Guard< Critical_Section > gate( _key );
      
      if( !_instance )
        _instance = new Singleton_Manager;
    }
    
    return *_instance;
  }
  
  void Singleton_Manager::add( Singleton_Base* singleton )
  {
    _singleton_stack.push( singleton );
  }
  
  Critical_Section& Singleton_Base::manager_key()
  {
    return Singleton_Manager::instance().key();
  }
  
  void Singleton_Base::add_to_manager( Singleton_Base* singleton )
  {
    Singleton_Manager::instance().add( singleton );
  }
  
  class Singleton_Manager_Creator
  {
  public:
    Singleton_Manager_Creator();
    ~Singleton_Manager_Creator();
  };
  
  Singleton_Manager_Creator::Singleton_Manager_Creator()
  {
    // Try to make sure Singleton_Manager has been created
    // before any application threads are created.
    Singleton_Manager::instance();
  }
  
  Singleton_Manager_Creator::~Singleton_Manager_Creator()
  {
    delete Singleton_Manager::_instance;
    Singleton_Manager::_instance = 0;
  }

} // namespace jr

namespace // {un-named}
{
  jr::Singleton_Manager_Creator singleton_manager_creator;

} // namespace {un-named}
