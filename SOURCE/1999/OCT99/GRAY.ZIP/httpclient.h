#ifndef __HTTPClient_H__
#define __HTTPClient_H__

#include <windows.h>

class cHTTPClient {
private:
	char *mTempDir;
	u_long mTempDirLen;
	char *mProxyIP;
	u_short mProxyPort;
	SOCKADDR_IN mProxyAddress; // Retreived from mProxyID and mProxyPort
	void UpdateProxyAddress();
	char *get_unique_filename();

public:
	cHTTPClient();
	~cHTTPClient();
	void set_temp_dir( const char *dir );
	void set_proxy( const char *ip, u_short port );
	char* request( const char *URL );
	class eNeedProxy {};
};

#endif
