/* Agent Tcl
   Bob Gray
   24 May 1996

   platPorting.h

   This header file handles porting issues that occur because
   of differences between systems.  It reads in UNIX-related
   header files and sets up UNIX-related macros for Agent Tcl's 
   UNIX core.  It should be the only file that contains #ifdefs 
   to handle different flavors of UNIX.  This file sets up the
   union of all UNIX-related things needed by any of the Tcl
   core files.  This file depends on configuration #defines such
   as NO_DIRENT_H that are set up by the "configure" scripts".

   Copyright (c) 1995-1996, Bob Gray, Dartmouth College

   See the file "agent.terms" for information on usage and redistribution
   of this file and for a DISCLAIMER OF ALL WARRANTIES.
*/

#ifndef _PLAT_PORTING_H
#define _PLAT_PORTING_H

    /* include sys/select.h if it is present */

#ifdef HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif

    /* The following macro defines the type of the mask arguments to select: */

#ifndef NO_FD_SET
#   define SELECT_MASK fd_set
#else
#   ifndef _AIX
	typedef long fd_mask;
#   endif
#   if defined(_IBMR2)
#	define SELECT_MASK void
#   else
#	define SELECT_MASK int
#   endif
#endif

    /* include crypt.h if it is present */

#ifdef HAVE_CRYPT_H
#include <crypt.h>
#endif

    /* include the string header files */

#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#ifdef HAVE_BSTRING_H
#include <bstring.h>
#endif

#endif /* _PLAT_PORTING_H */
