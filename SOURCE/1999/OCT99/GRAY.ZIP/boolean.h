/* Dynamic classes 
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   boolean.h

   This file defines a boolean type.
*/

#ifndef _BOOLEAN_H
#define _BOOLEAN_H

enum Boolean {
    e_FALSE = 0,
    e_TRUE  = 1
};

#endif /* _BOOLEAN_H */
