/* Dynamic classes
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey
   Bob Gray

   5 August 1996

   mystrings.cc

   This file implements a version of "strcpy" that returns a dynamically
   allocated copy of the source string.
*/

#include <string.h>
#include "mystrings.h"
#include "faststring.h"

char *my_strcpy (const char *string)
{
    char *copy;

    if (string == NULL) {
	copy = NULL;
    } else {
	copy = new char [fast_strlen(string) + 1];
	fast_strcpy (copy, string);
    }

    return (copy);
}

char *strip_whitespace (const char *string)
{
    char *spd;
    int length;
    char *new_string;
    const char *sp;

	/* nothing to do for NULL strings */
  
    if (string == NULL) {
	return NULL;
    }

	/* tear off the leading whitespace */

    for (sp = string; (*sp == '\r') || (*sp == ' ') || (*sp == '\t') || (*sp == '\n'); sp++) {
	// empty
    }


    length = strlen(sp);
    new_string = new char [length + 1];
    strcpy (new_string, sp);

	/* tear off the trailing whitespace */

    for (spd = new_string + length - 1; spd >= new_string; spd--) {
	if ((*spd == '\r') || (*spd == ' ') || (*spd == '\t') || (*spd == '\n')) {
	    *spd = '\0';
	} else {
	    break;
	}
    }

    return new_string;
}
