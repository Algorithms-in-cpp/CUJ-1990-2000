/* Dynamic classes
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   dynversion.cc

   This file implements class "DynamicVersion" which keeps track of a 
   dynamically loaded class version.
*/

#ifndef _WIN32
#include <dlfcn.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include "dynversion.h"

/* DynamicVersion::DynamicVersion

   Purpose: These procedures are the constructor for class DynamicVersion.
*/

DynamicVersion::DynamicVersion (void):
    names (),
    file (e_FALSE),
    dlhandle (NULL),
    dlloaded (e_FALSE),
    active (e_FALSE),
    refCount (0),
    funcPtr (NULL),
    force (e_FALSE)
{
    /* empty */
}

DynamicVersion::DynamicVersion (const char *className, const char *actualName, const char *localName, Boolean p_file, Boolean p_active):
    names (className, actualName, localName),
    file (p_file),
    dlhandle ((void *) NULL),
    dlloaded (e_FALSE),
    active (p_active),
    refCount (0),
    funcPtr (NULL),
    force (e_FALSE)
{
    /* empty */
}

DynamicVersion::DynamicVersion (const DynamicVersion &p_version):
    names (p_version.names),
    file (p_version.file), 
    dlhandle (p_version.dlhandle),
    dlloaded (p_version.dlloaded),
    active (p_version.active),
    refCount (p_version.refCount),
    funcPtr (p_version.funcPtr),
    force (p_version.force)
{
    /* empty */
}

/* DynamicVersion::operator=

   Purpose: This procedure is an assignment operator for class DynamicVersion.
*/

DynamicVersion & DynamicVersion::operator= (const DynamicVersion &p_version) {

    if (this != &p_version) {
	names    = p_version.names;
	file 	 = p_version.file;
	dlhandle = p_version.dlhandle;
	dlloaded = p_version.dlloaded;
	active   = p_version.active;
	refCount = p_version.refCount;
	funcPtr  = p_version.funcPtr;
	force    = p_version.force; 
    }

    return (*this);
}
