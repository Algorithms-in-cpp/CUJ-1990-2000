/* Dynamic classes
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   3 July 1996

   lockexcept.cc

   This file implements the exceptions associated with class "MutexLock".
*/

#include <stdio.h>
#include <stdlib.h>
#include "lockexcept.h"
#include "faststring.h"
#include "mystrings.h"

    /* exception descriptions */

static const char * const lockSystemErrorMessage = 
    "fatal system error: unable to block on a mutex";

static const char *const lockNotHoldingMessage =
    "can not release a mutex that is not being held";

char * LockSystemError::describeException (void)
{
    return (my_strcpy (lockSystemErrorMessage));
}

char * LockNotHolding::describeException (void)
{
    return (my_strcpy (lockNotHoldingMessage));
} 
