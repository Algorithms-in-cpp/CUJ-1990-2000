/* Agent Tcl 
   Bob Gray
   26 June 1995

   tcpip.cc

   This file implements the routines that handle TCP/IP connections.  These
   routines are based on the examples in [W. Richard Stevens, Unix Network
   Programming, Prentice Hall, 1990] and on the code that Saurab Nog
   developed as part of his A.I. project.

   Copyright (c) 1995, Robert S. Gray Dartmouth College

   See the file "agent.terms" for information on usage and redistribution
   of this file and for a DISCLAIMER OF ALL WARRANTIES.
*/

  /* includes */

#include "platPorting.h"
#ifdef USE_PTHREADS
#include "pthread.h"
#endif
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/un.h>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "boolean.h"
#include "genTcpip.h"
#include "genTimers.h"
#include "genUtility.h"

    /* maximum name length for a Unix socket */

const int MAX_NAME_LENGTH = 128;

    /* actual IP address and name of the current host */

static UINT_32 actual_ip   = 0;
static char *  actual_name = NULL;

    /* IP address "127.0.0.1" */

static UINT_32 local_ip = 0;

/* tcpip_setActual

   Purpose: Set the actual IP address and name of the current host.  Any 
            reference to the actual IP address or name will be turned into a 
            reference to "localhost".  This support is needed for mobile 
            computers that may have networking turned off.  If networking is 
            turned off, references to the actual IP address fail but 
	    references to "localhost" are fine.

     Input: ip   = actual IP address of the current host
		   (UINT_32)

	    name = name of the actual host
		   (char *)
 
    Output: The procedure sets the actual IP address and name of the current 
            host.
*/

void tcpip_setActual (UINT_32 ip, char *name)
{
    actual_ip = ip;
    actual_name = my_strcpy (name); 
    local_ip    = (UINT_32) inet_addr ("127.0.0.1");
}

/* tcpip_getLocalhost

   Purpose: Return the numeric representation of the localhost IP address
            "127.0.0.1"

     Input: None

    Output: The procedure returns the numeric representaton of the localhost
            IP address "127.0.0.1".
*/
 
UINT_32 tcpip_getLocalhost (void) {
    
    if (local_ip == 0) {
	local_ip = (UINT_32) inet_addr ("127.0.0.1");
    }

    return (local_ip); 
}

/* tcpip_asynchronous

   Purpose: Turn on asynchronous I/O for a socket

     Input: sockfd = the socket descriptor

    Output: The procedure returns TCPIP_FCNTL on error and 0 otherwise.
*/

int tcpip_asynchronous (int sockfd)
{
  int flags;

  if (fcntl (sockfd, F_SETOWN, getpid()) < 0) {
    return TCPIP_FCNTL;
  }

  if ((flags = fcntl (sockfd, F_GETFL, 0)) < 0) {
    return TCPIP_FCNTL;
  }

  if (fcntl (sockfd, F_SETFL, flags | FASYNC) < 0) {
    return TCPIP_FCNTL;
  }

  return 0;
}

/* tcpip_getsockname

   Purpose: Get the IP address and the port number associated with the
            LOCAL end of a socket

     Input: sockfd = socket descriptor

    Output: The procedure returns TCPIP_UNABLE_TO_GET_PORT on error.
            Otherwise the procedure fills in *ip and *port with the IP 
            address and port number.
*/

int tcpip_getsockname (int sockfd, UINT_32 *ip, UINT_32 *port)
{
  struct sockaddr_in address;  
  int size = sizeof(sockaddr_in);

  if (getsockname(sockfd, (struct sockaddr *) &address, &size) < 0) {
    return TCPIP_UNABLE_TO_GET_PORT;
  }

  *ip   = (UINT_32) address.sin_addr.s_addr;
  *port = ntohs (address.sin_port);
  return 0;
}

/* tcpip_getpeername

   Purpose: Get the IP address and the port number associated with the
            REMOTE end of a CONNECTED socket

     Input: sockfd = socket descriptor

    Output: The procedure returns TCPIP_UNABLE_TO_GET_PORT on error.
            Otherwise the procedure fills in *ip and *port with the IP 
            address and port number.
*/

int tcpip_getpeername (int sockfd, UINT_32 *ip, UINT_32 *port)
{
  struct sockaddr_in address;  
  int size = sizeof(sockaddr_in);

  if (getpeername(sockfd, (struct sockaddr *) &address, &size) < 0)
    return TCPIP_UNABLE_TO_GET_PORT;

  *ip   = (UINT_32) address.sin_addr.s_addr;  
  *port = ntohs (address.sin_port);
  return 0;
}

#ifdef USE_PTHREADS

/* tcpip_getip

   Purpose: This procedure gets the IP address of the given machine *but* 
            failes with an error if it is unable to get the IP address before
            the specified stop time.  

     Input: machine = machine name and IP address
		      (class MACHINE_ID &) 

	    stop    = wall time at which to give up
		      (struct timeval)
 
    Output: The procedure returns one of the following codes.

	    TCPIP_TIMEOUT	= timeout expired before IP address was found
	    TCPIP_NOT_FOUND	= unable to determine IP address
	    TCPIP_OK		= success

	    On success machine.ip is filled in with the IP address of the
	    machine.     
*/

void *gethostbyname_thread (void *argument)
{
    struct hostent *info;
    struct hostent *temp;

    temp = gethostbyname ((char *) argument);
    info = (struct hostent *) new struct hostent;
    memcpy (info, temp, sizeof(struct hostent));
    return ((void *) info);
}

int tcpip_getip (MACHINE_ID& machine, struct timeval stop)
{
    int rc;
    int length;
    pthread_t tid;
    char *name = NULL;
    struct hostent *serverInfo;

	/* assertions on the parameters */

    assert ((machine.name != NULL) || (machine.ip != UNKNOWN_IP));
    assert ((stop.tv_sec >= 0) && (stop.tv_usec >= 0));

	/* do nothing if we know the IP address */

    if (machine.ip != UNKNOWN_IP) {
	return TCPIP_OK;
    }

	/* get the jump buffer -- make sure that we call disposeTimers */

    if (((name = strip_whitespace (machine.name)) != NULL) && (*name != '\0')) { 
	    /* see if the name corresponds to the current host */

	if (actual_name != NULL) {

	    length = strlen(name);

	    if (!strncmp (name, actual_name, length)) {
		if ((name[length-1] == '.') || (actual_name[length] == '.') || (actual_name[length] == '\0')) {
		    machine.ip = actual_ip;
		    delete (name);
		    return TCPIP_OK;
		}
	    }
	}

	    /* see if the name is an ASCII represention of an IP */ 

	if ((machine.ip = (UINT_32) inet_addr(name)) != INADDR_NONE) {
	    delete (name);
	    return (TCPIP_OK);
	}

	    /* otherwise go to the name server */

	if (pthread_create (&tid, NULL, gethostbyname_thread, (void *) name) < 0) {

	    rc = TCPIP_NOT_FOUND;

	} else if (pthread_join (tid, (void **) &serverInfo) < 0) {

	    rc = TCPIP_NOT_FOUND;

	} else if (serverInfo == NULL) {

	    rc = TCPIP_NOT_FOUND;

	} else {

	    memcpy ((void *) &machine.ip, (void *) serverInfo -> h_addr, sizeof(UINT_32));
	    rc = TCPIP_OK;

	} 
    }

	/* done */ 

    delete (name);
    return (rc);
}
     
#else

/* tcpip_getip

   Purpose: This procedure gets the IP address of the given machine *but* 
            failes with an error if it is unable to get the IP address before
            the specified stop time.  This procedure represents an *evil* use
            of the "sigsetjmp" and "siglongjmp" standard C functions but there
            is no choice since "gethostbyname" will not abort until its 
            internal timer expires; a SIGALRM set by the program will
            interrupt "gethostbyname" but "gethostbyname" will always resume
            when the SIGALRM handler has finished.  Since the internal timer
            of "gethostbyname" ranges from 2 to 5 minutes on many systems,
            this is unacceptable.  Therefore I have resorted to calling
            "siglongjmp" from inside the SIGALRM handler.  If I can ever find a
            better solution, I will use it immediately. 

     Input: machine = machine name and IP address
		      (class MACHINE_ID &) 

	    stop    = wall time at which to give up
		      (struct timeval)
 
    Output: The procedure returns one of the following codes.

	    TCPIP_TIMEOUT	= timeout expired before IP address was found
	    TCPIP_NOT_FOUND	= unable to determine IP address
	    TCPIP_OK		= success

	    On success machine.ip is filled in with the IP address of the
	    machine.     
*/

class HOSTNAME_TRAP: public TIMER_TRAP
{
	TIMERS timers;            // timers
	sig_atomic_t inProgress;   // getip in progress

    public:

	sigjmp_buf buffer;        // buffer for siglongjmp

	HOSTNAME_TRAP (void):
	    inProgress (0)
	{}

        void wallAlarm (void) {
	    if (!inProgress) {
		delete (this);
	    } else {
		siglongjmp (buffer, 1);
	    }
	}

	void cpuAlarm (void) { // never called
	    assert (0);
	}

	void start (struct timeval stop) {
	    inProgress = 1;
	    timers.add (stop, this);
	}

	void stop (void) {
	    inProgress = 0;
	}

	void dispose (void) {
	    inProgress = 0;
	    timers.disposeTimers ();
	}
};

int tcpip_getip (MACHINE_ID& machine, struct timeval stop)
{
    int rc;
    int length;
    char *name = NULL;
    struct hostent *serverInfo;
    HOSTNAME_TRAP *timerTrap = NULL;

	/* assertions on the parameters */

    assert ((machine.name != NULL) || (machine.ip != UNKNOWN_IP));
    assert ((stop.tv_sec >= 0) && (stop.tv_usec >= 0));

	/* do nothing if we know the IP address */

    if (machine.ip != UNKNOWN_IP) {
	return TCPIP_OK;
    }

	/* get the jump buffer -- make sure that we call disposeTimers */

    if (((name = strip_whitespace (machine.name)) != NULL) && (*name != '\0')) { 
	    /* see if the name corresponds to the current host */

	if (actual_name != NULL) {

	    length = strlen(name);

	    if (!strncmp (name, actual_name, length)) {
		if ((name[length-1] == '.') || (actual_name[length] == '.') || (actual_name[length] == '\0')) {
		    machine.ip = actual_ip;
		    delete (name);
		    return TCPIP_OK;
		}
	    }
	}

	    /* see if the name is an ASCII represention of an IP */ 

	if ((machine.ip = (UINT_32) inet_addr(name)) != INADDR_NONE) {
	    delete (name);
	    return (TCPIP_OK);
	}

	    /* otherwise go to the name server; first set up the timer trap */

	timerTrap = new HOSTNAME_TRAP ();

	    /* jump back here when the timer trap is called; make sure */
	    /* that we call disposeTimers since otherwise we will miss */
	    /* timers; then bail with a timeout error                  */

	if (sigsetjmp (timerTrap -> buffer, 1) == 1) {
	    timerTrap -> dispose ();
	    delete (timerTrap);
	    delete (name);
	    return TCPIP_TIMEOUT; 
        } 

	    /* gethostbyname with a timer */ 

        timerTrap -> start (stop);
	serverInfo = gethostbyname (name);
	timerTrap -> stop ();

	    /* did we get the IP address */

	if (serverInfo != NULL) {

	    memcpy ((void *) &machine.ip, (void *) serverInfo -> h_addr, sizeof(UINT_32));
	    rc = TCPIP_OK;

	} else {

	    rc = TCPIP_NOT_FOUND;
	}
    }

	/* done -- do NOT delete the timer trap since the timer might   */
	/* still be active -- it would be nice to have a "cancel timer" */
	/* facility here                                                */

    delete (name);
    return (rc);
}

#endif  /* USE_PTHREADS */

/* tcpip_hostname

   Purpose: Get the name of the current host

     Input: None

    Output: The procedure returns NULL if it is unable to get the host name.
            Otherwise the procedure returns a pointer to a dyanmically
            allocated string that contains the hostname.
*/

char *tcpip_hostname (void)
{
  char *name_copy;
  char name[MAX_NAME_LENGTH];

  if (gethostname (name, MAX_NAME_LENGTH) < 0) {
    return NULL;
  }

  name_copy = new char [strlen(name) + 1];
  strcpy (name_copy, name);
  return name_copy;
}

/* tcpip_socket

   Purpose: This function creates a socket.

     Input: None

   Purpose: The procedure returns TCPIP_UNABLE_TO_CREATE if it is unable to
            create the socket.  Otherwise the procedure returns the sockfd.
*/

int tcpip_socket (void)
{
  int sockfd;
  int flag = 1;

    /* create the socket */

  if ((sockfd = socket (AF_INET, SOCK_STREAM, 0)) < 0) {
    return TCPIP_UNABLE_TO_CREATE;
  }

    /* turn on the TCP_NODELAY flag */

  if (setsockopt (sockfd, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int)) < 0) {
    close (sockfd);
    return TCPIP_UNABLE_TO_CREATE;
  }

    /* turn on the SO_KEEPALIVE flag  */

  if (setsockopt (sockfd, SOL_SOCKET, SO_KEEPALIVE, (char *) &flag, sizeof(int)) < 0) {
    close (sockfd);
    return TCPIP_UNABLE_TO_CREATE;
  }

  return sockfd;
}

/* tcpip_unix_socket

   Purpose: This function creates a Unix domain socket.

     Input: None

    Output: The procedure returns TCPIP_UNABLE_TO_CREATE if it is unable to
            create the socket.  Otherwise the procedure returns the sockfd.
*/

int tcpip_unix_socket (void)
{
  int sockfd;

  if ((sockfd = socket (AF_UNIX, SOCK_STREAM, 0)) < 0) {
    return TCPIP_UNABLE_TO_CREATE;
  }

  return sockfd;
}
 
/* tcpip_connect 

   Purpose: Connect a socket to a port on a remote machine

     Input: sockfd    = socket descriptor
		        (int)

	    port      = machine name and IP address and the port number
			(struct REMOTE_PORT &)

	    stop      = wall time at which to abandon the connection attempt
		        (struct timeval)
						
    Output: The procedure returns one of the following codes.

            TCPIP_NOT_FOUND         = unable to determine network location of destination machine
	    TCPIP_TIMEOUT           = timeout expired before connection
            TCPIP_UNABLE_TO_CONNECT = connection request was rejected
	    TCPIP_OK                = success
*/

int tcpip_connect (int sockfd, REMOTE_PORT& port, struct timeval stop)
{
    int code;
    int mode;
    int new_mode;
    fd_set writeSet;
    struct timeval timeout; 
    struct sockaddr_in address;  
    int size = sizeof(sockaddr_in);
    struct sockaddr_in serverAddress;    

	/* convert the machine name to an IP number */

    MACHINE_ID machine (port.machine, port.ip);

    if ((code = tcpip_getip (machine, stop)) != TCPIP_OK) { 
	return (code);
    }

    port.ip = machine.ip; 

	/* use "localhost" for the local host */

    if (port.ip == actual_ip) {
	port.ip = local_ip;
    }

	/* fill in the server address */

    memset ((void *) &serverAddress, 0, sizeof (sockaddr_in));
    memcpy ((void *) &serverAddress.sin_addr, (void *) &port.ip, sizeof(UINT_32));
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port   = htons (port.port);

	/* mark the socket as nonblocking */

    mode = fcntl (sockfd, F_GETFL, 0);
    new_mode = mode | O_NONBLOCK;
    fcntl (sockfd, F_SETFL, new_mode);

	/* start the asynchronous connection */

    do {
	code = connect (sockfd, (struct sockaddr *) &serverAddress, sizeof(sockaddr_in));
    } while ((code < 0) && (errno == EINTR));

	/* wait for the connection to complete */

    if (code < 0) {

	if ((errno == EWOULDBLOCK) || (errno == EINPROGRESS)) {

	    do {

		FD_ZERO (&writeSet);
		FD_SET (sockfd, &writeSet);
		timeout = TIMERS::subTimevals (stop, TIMERS::getCurrentWall());
		code = select (sockfd + 1, NULL, &writeSet, NULL, &timeout);

	    } while ((code < 0) && (errno == EINTR));
	}

	if (code < 0) {
	    code = TCPIP_UNABLE_TO_CONNECT;
	} else if (code == 0) {
	    code = TCPIP_TIMEOUT;
	} else if (getpeername(sockfd, (struct sockaddr *) &address, &size) < 0) {
	    code = TCPIP_UNABLE_TO_CONNECT;
	} else {
	    code = TCPIP_OK;
	}
    }

	/* undo the mode change */

    fcntl (sockfd, F_SETFL, mode);
    return (code);
}

/* tcpip_unix_connect

   Purpose: Connect to a Unix domain socket

     Input: sockfd = socket descriptor
            name   = filename of the Unix domain socket

    Output: The procedure returns TCPIP_UNABLE_TO_CONNECT if it is unable to
	    connect sockfd to the Unix domain socket.  Otherwise the procedure
	    returns 0.
*/

int tcpip_unix_connect (int sockfd, char *name)
{
  unsigned len;
  int return_code;
  struct sockaddr_un unix_addr;

    /* determine the appropriate length */

#ifdef SUNLEN_EXISTS
  len = sizeof(unix_addr.sun_family) + sizeof(unix_addr.sun_len) + strlen(name) + 1;
#else
  len = sizeof(unix_addr.sun_family) + strlen(name);
#endif

    /* check the length */

  if (len >= sizeof(sockaddr_un)) {
    return TCPIP_UNABLE_TO_CONNECT;
  }

    /* fill in the sockaddr structure */

  memset ((void *) &unix_addr, 0, sizeof(sockaddr_un));
#ifdef SUNLEN_EXISTS
  unix_addr.sun_len = len;
#endif
  unix_addr.sun_family = AF_UNIX;
  strcpy (unix_addr.sun_path, name);

    /* try to connect */

  do
  {
    return_code = connect (sockfd, (struct sockaddr *) &unix_addr, len);
  }
  while ((return_code < 0) && (errno == EINTR));

    /* error code */

  if (return_code < 0) {
    return TCPIP_UNABLE_TO_CONNECT;
  } else {
    return 0;
  }
}
 
/* tcpip_listen

   Purpose: Listen to a socket

     Input: sockfd = socket descriptor

    Output: The procedure returns TCPIP_UNABLE_TO_LISTEN on error.  Otherwise
            the procedure returns 0.
*/

int tcpip_listen (int sockfd)
{
  if (listen(sockfd, TCPIP_BACKLOG) < 0)
  {
    return TCPIP_UNABLE_TO_LISTEN;
  }
  else
  {
    return 0;
  }
}

/* tcpip_bind

   Purpose: Bind a socket to a local port

     Input: sockfd = socket descriptor
            port   = port number

    Output: The procedure returns TCPIP_UNABLE_TO_BIND if it can not bind to
            the port.  The procedure returns TCPIP_UNABLE_TO_GET_PORT if it
	    is unable to verify the port number of the bound port.  Otherwise
	    the procedure returns 0 and fills in *selected_port with the 
	    TCPIP/IP port of the socket.  The selected port will be equal to 
	    the requested port unless the requested port was TCPIP_ANY in 
	    which case the procedure lets the system choose a port.
*/

int tcpip_bind (int sockfd, int port, int *selected_port)
{
  struct sockaddr_in address;  
  int size = sizeof(sockaddr_in);

    /* bind the local address so thet a client can send to us */

  memset ((void *) &address, 0, sizeof(address));
  address.sin_family      = AF_INET;
  address.sin_port        = htons (port);
  address.sin_addr.s_addr = htonl (INADDR_ANY);

  if (bind(sockfd, (struct sockaddr *) &address, size) < 0) {
    return TCPIP_UNABLE_TO_BIND;
  }

  if (getsockname(sockfd, (struct sockaddr *) &address, &size) < 0) {
    return TCPIP_UNABLE_TO_GET_PORT;
  }

  if (selected_port != NULL) {
    *selected_port = ntohs (address.sin_port);
  }
 
  return 0;
}

/* tcpip_unix_bind

   Purpose: Bind a Unix domain socket to a filename

     Input: sockfd = socket descriptor
            name   = filename  

    Output: The procedure returns TCPIP_UNABLE_TO_BIND if it is unable to
            bind the socket to the specified port.  Otherwise the procedure
            returns 0.
*/

int tcpip_unix_bind (int sockfd, char *name)
{
  unsigned len;
  struct sockaddr_un unix_addr;

    /* determine the appropriate length */

#ifdef SUNLEN_EXISTS
  len = sizeof(unix_addr.sun_family) + sizeof(unix_addr.sun_len) + strlen(name) + 1;
#else
  len = sizeof(unix_addr.sun_family) + strlen(name);
#endif

    /* check the length */

  if (len >= sizeof(unix_addr)) {
    return TCPIP_UNABLE_TO_BIND;
  }

    /* remove the filename if it exists */

  unlink (name);

    /* create the sockaddr structure */

  memset ((void *) &unix_addr, 0, sizeof(unix_addr));
#ifdef SUNLEN_EXISTS
  unix_addr.sun_len = len;
#endif
  unix_addr.sun_family = AF_UNIX;
  strcpy (unix_addr.sun_path, name);

    /* bind to the filename */

  if (bind (sockfd, (struct sockaddr *) &unix_addr, len) < 0) {
    return TCPIP_UNABLE_TO_BIND;
  }

  return 0;
}

/* tcpip_setup

   Purpose: This function creates, binds and listens to a socket.

     Input: port = TCP/IP port for the socket

    Output: The procedure returns one of the error flags in tcpip.h on error.
            Otherwise the procedure fills in *selected__port with the TCP/IP
            port of the socket and returns the socket descriptor of the 
            socket.  The selected port will be equal to the requested port
            unless the desired port is TCPIP_ANY in which case the procedure 
            lets the system choose a port.
*/

int tcpip_setup (int port, int *selected_port)
{
  int sockfd;                  /* socket descriptor   */
  int return_code;             /* return code         */

    /* open the socket */

  if ((sockfd = tcpip_socket ()) < 0) {
    return sockfd;
  }

    /* bind the socket */

  if ((return_code = tcpip_bind (sockfd, port, selected_port)) < 0) {
    close (sockfd);
    return return_code;
  }

    /* listen at the sockt */

  if ((return_code = tcpip_listen (sockfd)) < 0) {
    close (sockfd);
    return return_code;
  }

  return sockfd;
}

/* tcpip_unix_setup

   Purpose: This function creates, binds and listens to a Unix domain socket.

     Input: name = filename

    Output: The procedure returns one of the error flags in tcpip.h on error.
            Otherwise the procedure returns the socket number.
*/

int tcpip_unix_setup (char *name)
{
  int sockfd;                  /* socket descriptor   */
  int return_code;             /* return code         */

    /* open the socket */

  if ((sockfd = tcpip_unix_socket ()) < 0) {
    return sockfd;
  }

    /* bind the socket */

  if ((return_code = tcpip_unix_bind (sockfd, name)) < 0) {
    close (sockfd);
    return return_code;
  }

    /* listen at the sockt */

  if ((return_code = tcpip_listen (sockfd)) < 0) {
    close (sockfd);
    return return_code;
  }

  return sockfd;
}

/* tcpip_accept

   Purpose: Accept a connection on a socket

     Input: sockfd = socket descriptor returned from tcpip_setup
 
    Output: The procedure returns TCPIP_UNABLE_TO_ACCEPT if it is unable
            to accept a connection.  Otherwise the procedure returns the
            NEW socket descriptor.
*/

int tcpip_accept (int sockfd)
{
  int flag = 1;                    /* flag for setsockopt        */
  int new_sockfd;                  /* new socket descriptor      */
  struct sockaddr_in address;      /* client address             */
  int size = sizeof(sockaddr_in);  /* size of the client address */

    /* accept a connection */

  do {
    new_sockfd = accept (sockfd, (struct sockaddr *) &address, &size);
  } while ((new_sockfd < 0) && (errno == EINTR));

    /* check for error */

  if (new_sockfd < 0) {
    return TCPIP_UNABLE_TO_ACCEPT;
  }

    /* make sure the TCP_NODELAY option is set for the new socket     */
    /* This should not be necessary but on some machines the accept() */
    /* function does not correctly propagate the TCP_NODELAY flag     */
    /* from sockfd to new_sockfd.                                     */

  setsockopt (new_sockfd, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int));
  return new_sockfd;
}

/* tcpip_readn

   Purpose: This function is used in place of "read" when reading from a
            socket.

     Input: fd     = socket descriptor
            ptr    = buffer into which the characters are read
            nbytes = number of characters to read

    Output: The procedure returns an integer less than 0 on error.  
            Otherwise the procedure returns the number of characters
            read from the socket.
*/

int tcpip_readn (register int fd, register char *ptr, register size_t nbytes)
{
  register int nread;               /* number of bytes read         */   
  register size_t nleft = nbytes;   /* number of bytes left to read */

  while (nleft > 0) {

    do {
      nread = read (fd, ptr, nleft);
    } while ((nread < 0) && (errno == EINTR));

    if (nread < 0) {             /* ERROR */
      return (nread);
    } else if (nread == 0) {     /* EOF   */
      break;            
    }

    nleft -= nread;
    ptr   += nread;
  }

  return (nbytes - nleft);
}


/* tcpip_writen

   Purpose: This function is used in place of "write" when writing to a 
            socket.

     Input: fd     = file descriptor
            ptr    = buffer from which characters are written
            nbytes = number of bytes to write

    Output: The procedure returns an integer less than 0 on error. 
            The procedure returns 0 on EOF. 
            Otherwise the procedure returns the number of bytes written.
*/

int tcpip_writen (register int fd, const char *ptr, register size_t nbytes)
{
   register size_t nleft = nbytes;   /* number of bytes left to write  */
   register int nwritten;            /* number of bytes written        */
   
   nleft = nbytes;

   while (nleft > 0)
   {
     do
     {
       nwritten = write (fd, ptr, nleft);
     }
     while ((nwritten < 0) && (errno == EINTR));

     if (nwritten <= 0)         /* ERROR or EOF */
       return nwritten;

     nleft -= nwritten;
     ptr   += nwritten;
   }

   return (nbytes - nleft);
}

/* tcpip_error_to_string

   Purpose: Convert one of the error codes to a string

     Input: code = error code

    Output: The procedure returns a pointer to a STATIC string that describes
            the error code. 
*/

const char *tcpip_error_to_string (int code)
{
   switch (code)
   {
     case TCPIP_UNABLE_TO_CREATE:
       return "unable to open a socket";
     case TCPIP_UNABLE_TO_BIND:
       return "unable to bind sockfd to the port";
     case TCPIP_UNABLE_TO_LISTEN:
       return "unable to listen on sockfd "; 
     case TCPIP_UNABLE_TO_GET_PORT:
       return "unable to get the port number of sockfd";
     case TCPIP_UNABLE_TO_ACCEPT:
       return "unable to accept on sockfd";
     case TCPIP_NOT_FOUND:
       return "unable to determine network address of machine"; 
     case TCPIP_UNABLE_TO_CONNECT:
       return "unable to connect sockfd to remote port";
     case TCPIP_TIMEOUT:
       return "timeout";
     default:
       return "unknown error";
    }
}

/* tcpip_read_* and tcpip_write_*
 
   Purpose: These procedures send and receive data on the socket.
*/

int tcpip_read_byte (int fd, UINT_8 *number)
{
  UINT_8 netChar;   /* char in network format */

  if (tcpip_readn (fd, (char *) &netChar, sizeof(UINT_8)) < (int) sizeof(UINT_8)) {
    return -1;
  }
 
  *number = netChar; 
  return 0;
}

int tcpip_read_short (int fd, UINT_16 *number)
{
  UINT_16 netShort;  /* short integer in network format */

  if (tcpip_readn (fd, (char *) &netShort, sizeof(UINT_16)) < (int) sizeof(UINT_16)) {
    return -1;
  }

  *number = ntohs (netShort); 
  return 0;
} 

int tcpip_read_long (int fd, UINT_32 *number)
{
  UINT_32 netLong;   /* long integer in network format */

  if (tcpip_readn (fd, (char *) &netLong, sizeof(UINT_32)) < (int) sizeof(UINT_32)) {
    return -1;
  }

  *number = ntohl (netLong);
  return 0;
}

char *tcpip_read_string (int fd)
{
  char *string;
  UINT_32 length;

  if (tcpip_read_long (fd, &length) < 0) {
    return NULL;
  }

  if (length == 0) {
    return NULL;
  }

  string = new char [length];

  if (tcpip_readn (fd, string, length) < (int) length) {
    delete string;
    return NULL;
  }

  string[length - 1] = '\0';
  return string;
}
 
int tcpip_write_byte (int fd, UINT_8 number)
{
  UINT_8 netChar = number;

  if (tcpip_writen (fd, (char *) &netChar, sizeof(UINT_8)) < 0)
    return -1;
 
  return 0;
}

int tcpip_write_short (int fd, UINT_16 number)
{
  UINT_16 netShort = htons (number);

  if (tcpip_writen (fd, (char *) &netShort, sizeof(UINT_16)) < 0)
    return -1;

  return 0;
}

int tcpip_write_long (int fd, UINT_32 number)
{
  UINT_32 netLong = (UINT_32) htonl(number);

  if (tcpip_writen (fd, (char *) &netLong, sizeof(UINT_32)) < 0)
    return -1;

  return 0;
}

int tcpip_write_string (int fd, char *string)
{
  UINT_32 length = (string == NULL) ? 0 : strlen(string) + 1;

  if (tcpip_write_long (fd, length) < 0)
    return -1;

  if ((length > 0) && (tcpip_writen (fd, string, length) < 0))
    return -1;

  return 0;
}


char *tcpip_iptostring (UINT_32 ip)
{
    struct in_addr inaddr;
    inaddr.s_addr = ip;
    return (my_strcpy (inet_ntoa (inaddr)));
}

int tcpip_reset_error (int sockfd)
{
   int rc;
   int optvalue;
   int optlength = sizeof(int);

   if ((rc = getsockopt (sockfd, SOL_SOCKET, SO_ERROR, (char *) &optvalue, &optlength)) < 0) {
	return rc;
   }

   return (optvalue);
}
