/* Translated by the Edison Design Group C++/C front end (version 2.28) */
/* Fri Mar 21 10:33:04 1997 */
static int __sexten(i,n) int i,n;
{int mask=(1<<(n-1))-1; if(i<0||i>mask)i=(i&mask)|~mask; return(i);}
#line 1 "class.cc"
#line 6 "/usr/include/stdio.h"
#ident "$Revision: 1.49 $"
#line 6 "/usr/include/stdlib.h"
#ident "$Revision: 1.34 $"
#line 19 "/usr/include/sgidefs.h"
#ident "$Revision: 1.5 $"
#line 3 "/usr/include/getopt.h"
#ident "$Revision: 1.8 $"
struct __T268748320;
#line 128 "/usr/include/stdio.h"
struct FILE;
#line 142 "/usr/include/sgidefs.h"
struct __int64_t;



struct __uint64_t;
#line 63 "/usr/include/stdlib.h"
struct div_t;




struct ldiv_t;
#line 21 "../../base.h"
struct Base;
#line 23 "../baseclass.h"
struct Test_Base;
#line 21 "class.h"
struct Test; struct __T268748320 { short d; short i; void (*f)();};
#line 40 "/usr/include/stdio.h"
typedef unsigned int size_t;
#line 47
typedef long fpos_t;
#line 128
struct FILE {

int _cnt;




char *_ptr;
char *_base;

char _flag;
char _file;};
#line 145
typedef struct FILE FILE;
#line 125 "/usr/include/sgidefs.h"
typedef int __int32_t;
typedef unsigned int __uint32_t;
#line 142
struct __int64_t {
int hi32;
int lo32;};

struct __uint64_t {
unsigned int hi32;
unsigned int lo32;};
#line 63 "/usr/include/stdlib.h"
struct div_t {
int quot;
int rem;};
typedef struct div_t div_t;

struct ldiv_t {
long quot;
long rem;};
typedef struct ldiv_t ldiv_t;
#line 103
typedef long wchar_t;
#line 21 "../../base.h"
struct Base { struct __T268748320 *__vptr;};
#line 23 "../baseclass.h"
struct Test_Base { struct Base __b_Base;};
#line 21 "class.h"
struct Test { struct Test_Base __b_Test_Base;

int a;
int b;}; extern void *__nw__FUi(); extern void __dl__FPv();
#line 167 "/usr/include/stdio.h"
extern int printf(); extern void __pure_virtual_called();
#pragma inline global (__dt__4BaseFv)
#line 29 "../../base.h"
static void __dt__4BaseFv();
#pragma inline global (__dt__9Test_BaseFv)
#line 23 "../baseclass.h"
static void __dt__9Test_BaseFv();
#line 33 "class.cc"
extern struct Test *__ct__4TestFv();
#line 25
extern struct Base *copyInstance__4TestFv();
#line 20
extern void assignInstance__4TestFR4Base();
#line 40
extern struct Base *createInstance__4TestSFv();
#line 29
extern void print__4TestFv();
#pragma inline global (__dt__4TestFv)
#line 21 "class.h"
static void __dt__4TestFv(); struct __T268748320 __vtbl__4Base__class_cc___vtbl__4Test[5]; struct __T268748320 __vtbl__9Test_Base__class_cc___vtbl__4Test[6]; extern struct __T268748320 __vtbl__4Test[6]; struct __T268748320 __vtbl__4Base__class_cc___vtbl__4Test[5] = {{((short)0),((short)0),((void (*)
#line 21
())0)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)())__dt__4BaseFv)},{((short)0),((short)0),((void (*)())0)}}; struct __T268748320 __vtbl__9Test_Base__class_cc___vtbl__4Test[6] = {{((short)0
#line 21
),((short)0),((void (*)())0)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)())__dt__9Test_BaseFv)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)
#line 21
())0)}}; struct __T268748320 __vtbl__4Test[6] = {{((short)0),((short)0),((void (*)())0)},{((short)0),((short)0),((void (*)())copyInstance__4TestFv)},{((short)0),((short)0),((void (*)())assignInstance__4TestFR4Base)},{((short)0),((short)0),((void (*)())__dt__4TestFv)},{((short)0),((short)0),((void (*
#line 21
)())print__4TestFv)},{((short)0),((short)0),((void (*)())0)}};
#line 29 "../../base.h"
static void __dt__4BaseFv(this, __T268793084) struct Base *this; int __T268793084; { if (this != ((struct Base *)0)) { (this->__vptr) = __vtbl__4Base__class_cc___vtbl__4Test; if (__T268793084 & 1) { __dl__FPv(((void *)this)); } } return; }
#line 23 "../baseclass.h"
static void __dt__9Test_BaseFv(this, __T268801856) struct Test_Base *this; int __T268801856; { auto struct Base *__T268802372; if (this != ((struct Test_Base *)0)) { ((this->__b_Base).__vptr) = __vtbl__9Test_Base__class_cc___vtbl__4Test; { { __T268802372 = (&((*this).__b_Base)); { if (__T268802372 
#line 23
!= ((struct Base *)0)) { (__T268802372->__vptr) = __vtbl__4Base__class_cc___vtbl__4Test; } } } } if (__T268801856 & 1) { __dl__FPv(((void *)this)); } } return; }
#line 33 "class.cc"
struct Test *__ct__4TestFv(this) struct Test *this;


{ auto struct Base *__T268798892; auto struct Test_Base *__T268798764; if ((this != ((struct Test *)0)) || ((this = ((struct Test *)(__nw__FUi(((unsigned int)12))))) != ((struct Test *)0))) { { __T268798764 = (&((*this).__b_Test_Base));
#line 33
{ if ((__T268798764 != ((struct Test_Base *)0)) || ((__T268798764 = ((struct Test_Base *)(__nw__FUi(((unsigned int)4))))) != ((struct Test_Base *)0))) { { __T268798892 = (&((*__T268798764).__b_Base)); { if ((__T268798892 != ((struct Base *)0)) || ((__T268798892 = ((struct Base *)(__nw__FUi(((
#line 33
unsigned int)4))))) != ((struct Base *)0))) { (__T268798892->__vptr) = __vtbl__4Base__class_cc___vtbl__4Test; } } } ((__T268798764->__b_Base).__vptr) = __vtbl__9Test_Base__class_cc___vtbl__4Test; } } } (((this->__b_Test_Base).__b_Base).__vptr) = __vtbl__4Test; (this->a) = 5; (this->b) = 7; }




return this; }
#line 25
struct Base *copyInstance__4TestFv(this) struct Test *this; {
return &(((*(__ct__4TestFv(((struct Test *)0)))).__b_Test_Base).__b_Base);
}
#line 20
void assignInstance__4TestFR4Base(this, __923_34_dest) struct Test *this; struct Base *__923_34_dest;
{ auto struct Test_Base *__T268795176; auto struct Test_Base *__T268795124; auto struct Base *__T268795072; auto struct Base *__T268795020; auto struct Test *__T268794896; auto struct Test *__T268794796;
(*(((__T268794796 = ((struct Test *)__923_34_dest)) , (__T268794896 = ((struct Test *)this))) , ((((((__T268795176 = (&((*__T268794796).__b_Test_Base))) , (__T268795124 = ((struct Test_Base *)((struct Test_Base *)(&((*__T268794896).__b_Test_Base)))))) , (((__T268795020 = (&((*__T268795176).__b_Base)
#line 22
)) , (__T268795072 = ((struct Base *)((struct Base *)(&((*__T268795124).__b_Base)))))) , ((void)0))) , ((__T268794796->a) = ((__T268794896->a)))) , ((__T268794796->b) = ((__T268794896->b)))) , __T268794796)));
return; }
#line 40
struct Base *createInstance__4TestSFv() {
return &(((*(__ct__4TestFv(((struct Test *)0)))).__b_Test_Base).__b_Base);
}
#line 29
void print__4TestFv(this) struct Test *this; {
printf(((char *)"This is version 1.1 (%d x %d)!\n"), ((this->a)), ((this->b)));
return; }
#line 21 "class.h"
static void __dt__4TestFv(this, __T268803776) struct Test *this; int __T268803776; { auto struct Base *__T268804468; auto struct Test_Base *__T268804340; if (this != ((struct Test *)0)) { (((this->__b_Test_Base).__b_Base).__vptr) = __vtbl__4Test; { { __T268804340 = (&((*this).__b_Test_Base)); { if (
#line 21
__T268804340 != ((struct Test_Base *)0)) { ((__T268804340->__b_Base).__vptr) = __vtbl__9Test_Base__class_cc___vtbl__4Test; { { __T268804468 = (&((*__T268804340).__b_Base)); { if (__T268804468 != ((struct Base *)0)) { (__T268804468->__vptr) = __vtbl__4Base__class_cc___vtbl__4Test; } } } } } } } } if 
#line 21
(__T268803776 & 1) { __dl__FPv(((void *)this)); } } return; }
__cgi__class_cc___vtbl__4Test() {
}
