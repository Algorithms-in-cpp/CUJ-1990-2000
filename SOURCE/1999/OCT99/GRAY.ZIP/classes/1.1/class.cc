/* Dynamic objects
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   class.cc

   This file implements version 1.1 of the test class.
*/

#include <stdio.h>
#include <stdlib.h>
#include "class.h"

void Test::assignInstance (Base &dest)
{
    ((Test&) dest) = *this;
}

Base *Test::copyInstance (void) {
    return (new Test);
}

void Test::print (void) {
    printf ("This is version 1.1 (%d x %d)!\n", a, b);
}

Test::Test (void):
  a (5),
  b (7)
{
    // empty 
}

Base * Test::createInstance (void) {
    return (new Test ()); 
}
