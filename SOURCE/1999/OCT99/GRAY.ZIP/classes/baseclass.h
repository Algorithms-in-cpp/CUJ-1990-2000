/* Dynamic objects
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   baseclass.h

   This file defines the base class for each version of the test class.  
   version.
*/

#ifndef _BASE_CLASS_H
#define _BASE_CLASS_H

#include <stdio.h>
#include "base.h"

class Test_Base: public Base
{
    public:

	    /* interface and class names -- needed to construct */
	    /* mangled linker names                             */

	INTERFACE_NAME ("Test_Base");
	CLASS_NAME ("Test");

	    /* functions that belong with the class */

	virtual void print (void) = 0;
};

#endif /* _BASE_CLASS_H */
