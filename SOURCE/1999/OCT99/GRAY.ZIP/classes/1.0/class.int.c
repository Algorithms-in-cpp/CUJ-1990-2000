/* Translated by the Edison Design Group C++/C front end (version 2.28) */
/* Fri Mar 21 10:33:02 1997 */
static int __sexten(i,n) int i,n;
{int mask=(1<<(n-1))-1; if(i<0||i>mask)i=(i&mask)|~mask; return(i);}
#line 1 "class.cc"
#line 6 "/usr/include/stdio.h"
#ident "$Revision: 1.49 $"
#line 6 "/usr/include/stdlib.h"
#ident "$Revision: 1.34 $"
#line 19 "/usr/include/sgidefs.h"
#ident "$Revision: 1.5 $"
#line 3 "/usr/include/getopt.h"
#ident "$Revision: 1.8 $"
struct __T268748320;
#line 128 "/usr/include/stdio.h"
struct FILE;
#line 142 "/usr/include/sgidefs.h"
struct __int64_t;



struct __uint64_t;
#line 63 "/usr/include/stdlib.h"
struct div_t;




struct ldiv_t;
#line 21 "../../base.h"
struct Base;
#line 23 "../baseclass.h"
struct Test_Base;
#line 21 "class.h"
struct Test; struct __T268748320 { short d; short i; void (*f)();};
#line 40 "/usr/include/stdio.h"
typedef unsigned int size_t;
#line 47
typedef long fpos_t;
#line 128
struct FILE {

int _cnt;




char *_ptr;
char *_base;

char _flag;
char _file;};
#line 145
typedef struct FILE FILE;
#line 125 "/usr/include/sgidefs.h"
typedef int __int32_t;
typedef unsigned int __uint32_t;
#line 142
struct __int64_t {
int hi32;
int lo32;};

struct __uint64_t {
unsigned int hi32;
unsigned int lo32;};
#line 63 "/usr/include/stdlib.h"
struct div_t {
int quot;
int rem;};
typedef struct div_t div_t;

struct ldiv_t {
long quot;
long rem;};
typedef struct ldiv_t ldiv_t;
#line 103
typedef long wchar_t;
#line 21 "../../base.h"
struct Base { struct __T268748320 *__vptr;};
#line 23 "../baseclass.h"
struct Test_Base { struct Base __b_Base;};
#line 21 "class.h"
struct Test { struct Test_Base __b_Test_Base;}; extern void *__nw__FUi(); extern void __dl__FPv();
#line 167 "/usr/include/stdio.h"
extern int printf(); extern void __pure_virtual_called();
#pragma inline global (__dt__4BaseFv)
#line 29 "../../base.h"
static void __dt__4BaseFv();
#pragma inline global (__dt__9Test_BaseFv)
#line 23 "../baseclass.h"
static void __dt__9Test_BaseFv();
#line 38 "class.cc"
extern char *number__4TestFv();
#line 20
extern struct Test *__ct__4TestFv();
#line 30
extern struct Base *copyInstance__4TestFv();
#line 25
extern void assignInstance__4TestFR4Base();
#line 43
extern struct Base *createInstance__4TestSFv();
#line 34
extern void print__4TestFv();
#pragma inline global (__dt__4TestFv)
#line 21 "class.h"
static void __dt__4TestFv(); struct __T268748320 __vtbl__4Base__class_cc___vtbl__4Test[5]; struct __T268748320 __vtbl__9Test_Base__class_cc___vtbl__4Test[6]; extern struct __T268748320 __vtbl__4Test[6]; struct __T268748320 __vtbl__4Base__class_cc___vtbl__4Test[5] = {{((short)0),((short)0),((void (*)
#line 21
())0)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)())__dt__4BaseFv)},{((short)0),((short)0),((void (*)())0)}}; struct __T268748320 __vtbl__9Test_Base__class_cc___vtbl__4Test[6] = {{((short)0
#line 21
),((short)0),((void (*)())0)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)())__dt__9Test_BaseFv)},{((short)0),((short)0),((void (*)())__pure_virtual_called)},{((short)0),((short)0),((void (*)
#line 21
())0)}}; struct __T268748320 __vtbl__4Test[6] = {{((short)0),((short)0),((void (*)())0)},{((short)0),((short)0),((void (*)())copyInstance__4TestFv)},{((short)0),((short)0),((void (*)())assignInstance__4TestFR4Base)},{((short)0),((short)0),((void (*)())__dt__4TestFv)},{((short)0),((short)0),((void (*
#line 21
)())print__4TestFv)},{((short)0),((short)0),((void (*)())0)}};
#line 29 "../../base.h"
static void __dt__4BaseFv(this, __T268793084) struct Base *this; int __T268793084; { if (this != ((struct Base *)0)) { (this->__vptr) = __vtbl__4Base__class_cc___vtbl__4Test; if (__T268793084 & 1) { __dl__FPv(((void *)this)); } } return; }
#line 23 "../baseclass.h"
static void __dt__9Test_BaseFv(this, __T268801032) struct Test_Base *this; int __T268801032; { auto struct Base *__T268801548; if (this != ((struct Test_Base *)0)) { ((this->__b_Base).__vptr) = __vtbl__9Test_Base__class_cc___vtbl__4Test; { { __T268801548 = (&((*this).__b_Base)); { if (__T268801548 
#line 23
!= ((struct Base *)0)) { (__T268801548->__vptr) = __vtbl__4Base__class_cc___vtbl__4Test; } } } } if (__T268801032 & 1) { __dl__FPv(((void *)this)); } } return; }
#line 38 "class.cc"
char *number__4TestFv(this) struct Test *this;
{
return "ZERO";
}
#line 20
struct Test *__ct__4TestFv(this) struct Test *this;
{ auto struct Base *__T268795228; auto struct Test_Base *__T268795100; if ((this != ((struct Test *)0)) || ((this = ((struct Test *)(__nw__FUi(((unsigned int)4))))) != ((struct Test *)0))) { { __T268795100 = (&((*this).__b_Test_Base));
#line 20
{ if ((__T268795100 != ((struct Test_Base *)0)) || ((__T268795100 = ((struct Test_Base *)(__nw__FUi(((unsigned int)4))))) != ((struct Test_Base *)0))) { { __T268795228 = (&((*__T268795100).__b_Base)); { if ((__T268795228 != ((struct Base *)0)) || ((__T268795228 = ((struct Base *)(__nw__FUi(((
#line 20
unsigned int)4))))) != ((struct Base *)0))) { (__T268795228->__vptr) = __vtbl__4Base__class_cc___vtbl__4Test; } } } ((__T268795100->__b_Base).__vptr) = __vtbl__9Test_Base__class_cc___vtbl__4Test; } } } (((this->__b_Test_Base).__b_Base).__vptr) = __vtbl__4Test; }


return this; }
#line 30
struct Base *copyInstance__4TestFv(this) struct Test *this; {
return &(((*(__ct__4TestFv(((struct Test *)0)))).__b_Test_Base).__b_Base);
}
#line 25
void assignInstance__4TestFR4Base(this, __927_34_dest) struct Test *this; struct Base *__927_34_dest;
{ auto struct Test_Base *__T268797916; auto struct Test_Base *__T268797864; auto struct Base *__T268797812; auto struct Base *__T268797760; auto struct Test *__T268797636; auto struct Test *__T268797536;
(*(((__T268797536 = ((struct Test *)__927_34_dest)) , (__T268797636 = ((struct Test *)this))) , ((((__T268797916 = (&((*__T268797536).__b_Test_Base))) , (__T268797864 = ((struct Test_Base *)((struct Test_Base *)(&((*__T268797636).__b_Test_Base)))))) , (((__T268797760 = (&((*__T268797916).__b_Base))) 
#line 27
, (__T268797812 = ((struct Base *)((struct Base *)(&((*__T268797864).__b_Base)))))) , ((void)0))) , __T268797536)));
return; }
#line 43
struct Base *createInstance__4TestSFv() {
return &(((*(__ct__4TestFv(((struct Test *)0)))).__b_Test_Base).__b_Base);
}
#line 34
void print__4TestFv(this) struct Test *this; {
printf(((char *)"This is version 1.0 (%s)!\n"), (number__4TestFv(this)));
return; }
#line 21 "class.h"
static void __dt__4TestFv(this, __T268802952) struct Test *this; int __T268802952; { auto struct Base *__T268803644; auto struct Test_Base *__T268803516; if (this != ((struct Test *)0)) { (((this->__b_Test_Base).__b_Base).__vptr) = __vtbl__4Test; { { __T268803516 = (&((*this).__b_Test_Base)); { if (
#line 21
__T268803516 != ((struct Test_Base *)0)) { ((__T268803516->__b_Base).__vptr) = __vtbl__9Test_Base__class_cc___vtbl__4Test; { { __T268803644 = (&((*__T268803516).__b_Base)); { if (__T268803644 != ((struct Base *)0)) { (__T268803644->__vptr) = __vtbl__4Base__class_cc___vtbl__4Test; } } } } } } } } if 
#line 21
(__T268802952 & 1) { __dl__FPv(((void *)this)); } } return; }
__cgi__class_cc___vtbl__4Test() {
}
