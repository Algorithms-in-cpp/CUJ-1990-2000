/* Dynamic objects
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   class.cc

   This file implements version 1.0 of the test class.
*/

#include <stdio.h>
#include <stdlib.h>
#include "class.h"

Test::Test (void)
{
    // empty
}

void Test::assignInstance (Base &dest)
{
    ((Test&) dest) = *this;
}

Base *Test::copyInstance (void) {
    return (new Test);
}

void Test::print (void) {
    printf ("This is version 1.0 (%s)!\n", number());
}

char *Test::number (void)
{
   return "ZERO";
}

Base * Test::createInstance (void) {
    return (new Test ()); 
}

