/* Dynamic objects
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   class.h

   This file defines version 1.0 of the test class.
*/

#ifndef _CLASS_H
#define _CLASS_H

#include "baseclass.h"

class Test: public Test_Base
{
	char *number (void); 

    public:

	Test ();

	    /* functions that allow dynamic versioning */

	Base *copyInstance (void);

	void assignInstance (Base &dest);

	static Base *createInstance (void);
	
	    /* functions that belong with the class */
    
	void print (void);
};

#endif /* _CLASS_H */
