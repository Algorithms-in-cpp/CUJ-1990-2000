/* Agent Tcl
   Bob Gray
   5 April 1995

   genHash.h

   This file defines a hash table class that maps a string to an integer
   handle.

   Copyright (c) 1995-1997, Robert S. Gray Dartmouth College

   See the file "agent.terms" for information on usage and redistribution
   of this file and for a DISCLAIMER OF ALL WARRANTIES.
*/

#ifndef _GEN_HASH_H
#define _GEN_HASH_H

#pragma interface

struct HashNode
{
    char *m_key;        /* string key               */ 
    int m_handle;       /* handle                   */
    HashNode *m_next;   /* next node in a list of nodes */

	/* constructor and destructor */

    HashNode (const char *key, int handle, HashNode *next);
   ~HashNode ();
};

class Hash
{
    unsigned entries;    /* number of entries in the table */
    unsigned max_index;  /* maximum table index            */
    HashNode **table;    /* hash table                     */

	/* hash the string key */

    long hash (const char *string_key);

public:

	/* constructor and destructor */

    Hash (void);
   ~Hash ();

      /* get the number of entries */

    unsigned getNumberOfEntries (void) { 
	return entries; 
    } 

      /* add, lookup and remove entries */  

    void add (const char *key, int handle);
    int lookup (const char *key, int& handle);
    int remove (const char *key);

      /* empty out the hash table */

    void empty (void);
};

#endif
