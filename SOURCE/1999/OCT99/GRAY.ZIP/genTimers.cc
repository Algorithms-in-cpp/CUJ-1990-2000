/* Agent Tcl
   Bob Gray
   28 Spetember 1995

   timers.cc

   This file implements a class that allows a process to define any number 
   of timers.

   Copyright (c) 1995, Robert S. Gray Dartmouth College

   See the file "agent.terms" for information on usage and redistribution
   of this file and for a DISCLAIMER OF ALL WARRANTIES.
*/

#include <sys/types.h>
#include <sys/time.h>
#include <sys/times.h>
#include <assert.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "boolean.h"
#include "genInterrupt.h"
#include "genTimers.h"

  /* this is ugly -- it should not be needed */

extern "C" int BSDgettimeofday(struct timeval *tp, struct timezone *tzp);

  /* static data members */

long         TIMERS::ticks      = 0;
int          TIMERS::timerMax   = 0;
int          TIMERS::timerCount = 0;
int          TIMERS::count      = 0;
TIMER       *TIMERS::timerHeap  = NULL;
MutexLock   *TIMERS::timerLock  = NULL;
	
/* TIMER::TIMER

   Purpose: These procedures are the constructors for class TIMER.
*/

TIMER::TIMER (struct timeval stop, TIMER_TRAP *trap)
{
    TIMER::stop = stop;
    TIMER::trap = trap; 
}

TIMER::TIMER (const TIMER &timer)
{
    stop = timer.stop;
    trap = timer.trap;
}

TIMER::TIMER (void)
{
    stop.tv_sec  = 0;
    stop.tv_usec = 0;
    trap         = (TIMER_TRAP *) NULL;
}

/* TIMERS::timerStopToDuration

   Purpose: Convert a stop time to a duration

     Input: stop = the stop time
		   (struct timeval)

    Output: The procedure fills in duration and returns a pointer to duration.
*/
    
struct timeval *timerStopToDuration (struct timeval stop, struct timeval& duration)
{
    struct timeval current;

#ifdef HAVE_BSDGETTIMEOFDAY
#define gettimeofday BSDgettimeofday
#endif

    current = TIMERS::getCurrentWall ();

    if (stop.tv_sec < current.tv_sec) {
	duration.tv_sec  = 0;
	duration.tv_usec = 0;
	return (&duration);
    }

    duration.tv_sec = stop.tv_sec - current.tv_sec;

    if (stop.tv_usec < current.tv_usec) {

	if (duration.tv_sec == 0) {
	    duration.tv_usec = 0;
	    return (&duration);
	}

	duration.tv_sec -= 1;
	duration.tv_usec = 1000000 + current.tv_usec - stop.tv_usec;
	return (&duration);
    }

    duration.tv_usec = stop.tv_usec - current.tv_usec;
    return (&duration);
} 

/* TIMERS::addTimevals

   Purpose: Add two timevals

     Input: t1 = the first timeval
		 (struct timeval)

	    t2 = the second timeval
		 (struct timeval)

    Output: The procedure returns the sum of the two timevals.
*/

struct timeval TIMERS::addTimevals (struct timeval t1, struct timeval t2)
{
    struct timeval sum;

    sum.tv_sec  = t1.tv_sec  + t2.tv_sec;
    sum.tv_usec = t1.tv_usec + t2.tv_usec;

    if (sum.tv_usec >= 1000000) {
	sum.tv_sec += 1;
        sum.tv_usec -= 1000000;
    }

    return (sum);
}

/* TIMERS::subTimevals

   Purpose: Subtract two timevals

     Input: t1 = the first timeval
		 (struct timeval)

	    t2 = the second timeval
		 (struct timeval)

    Output: The procedure returns the difference t1 - t2 (or a timeval of 0
	    if t1 > t2).
*/

struct timeval TIMERS::subTimevals (struct timeval t1, struct timeval t2)
{
    struct timeval diff;

	/* timeval of 0 if t1 is smaller than t2 */

    if (t1.tv_sec < t2.tv_sec) {

	diff.tv_sec  = 0;
	diff.tv_usec = 0; 

    } else {

	diff.tv_sec = t1.tv_sec - t2.tv_sec;

	if (t1.tv_usec < t2.tv_usec) {

	    if (t1.tv_sec == 0) {
		diff.tv_usec = 0;
	    } else {
	  	diff.tv_sec -= 1;
		diff.tv_usec = 1000000 + t1.tv_usec - t2.tv_usec;
	    }

	} else {

	    diff.tv_usec = t1.tv_usec - t2.tv_usec;
	}
    }

    return (diff);
}

/* TIMERS::compareTimevals

   Purpose: Compare two timevals

     Input: t1 = the first timeval
		 (struct timeval)

	    t2 = the second timeval
	 	 (struct timeval)
  
    Output: The procedure returns -1 if t1 < t2, 0 if t1 == t2 and 1 if t1 > t2.
*/

int TIMERS::compareTimevals (struct timeval t1, struct timeval t2)
{
    if (t1.tv_sec < t2.tv_sec) {
	return -1;
    } else if (t1.tv_sec > t2.tv_sec) {
	return 1;
    } else if (t1.tv_usec < t2.tv_usec) {
	return -1;
    } else if (t1.tv_usec > t2.tv_usec) {
	return 1;
    } else {
	return 0;
    }
}

/* TIMERS::secondsToTimeval

   Purpose: Convert seconds to a timeval

     Input: seconds = the number of seconds
		      (double)

    Output: The procedure returns a timeval structure that specifies the given
	    number of seconds.
*/

struct timeval TIMERS::secondsToTimeval (double seconds)
{
    double integer;
    double fraction;
    struct timeval tv;

    fraction = modf (seconds, &integer);
    tv.tv_sec = (long) (integer);
    tv.tv_usec = (long) (fraction * 1000000.0);
    return (tv);
}

/* TIMERS::timevalToSeconds

   Purpose: Convert a timeval to seconds

     Input: tv = the timeval
                 (struct timeval)

    Output: The procedure returns the number of seconds that corresponds to
	    the given timeval.
*/

double TIMERS::timevalToSeconds (struct timeval tv)
{
    double seconds;

    seconds = (double) tv.tv_sec;
    seconds += ((double) tv.tv_usec / 1000000.0);
    return (seconds);
}

/* TIMERS::getCurrentWall

   Purpose: Get the current wall time

     Input; None

    Output: The procedure returns the current wall time.
*/

struct timeval TIMERS::getCurrentWall (void) 
{
#ifdef NO_GETTOD
    time_t wallTicks;
    struct tms buffer;
#endif
    struct timeval wall;


#ifdef NO_GETTOD
   
    if (ticks == 0) {
	ticks = sysconf (_SC_CLK_TCK);
    }

    wallTicks    = times (&buffer);
    wall.tv_sec  = wallTicks / ticks;
    wall.tv_usec = 1000000 * (wallTicks % ticks) / ticks;

#else

#ifdef HAVE_BSDGETTIMEOFDAY
#define gettimeofday BSDgettimeofday
#endif

    (void) gettimeofday (&wall, (struct timezone *) NULL);

#endif

    return (wall);
}
  
/* TIMERS::disposeTimers

   Purpose: Dispose of expired timers 

     Input: None

    Output: The procedure disposes of expired timers and calls the
            corresponding handlers.
 
      NOTE: The procedure assumes that SIGALRM is blocked.
*/

void TIMERS::disposeTimers (void)
{
    struct TIMER timer;       /* timer that has expired  */
    struct timeval wall;      /* current wall time       */ 
    struct timeval interval;  /* time until next timer   */
    struct itimerval itimer;  /* interval timer          */

	/* don't use mutexGuard -- we might SIGLONGJMP out of the handler */
 
    timerLock -> acquire ();

	/* dispose of expired timers */

    wall = getCurrentWall ();
   
    while ((timerCount > 0) && (compareTimevals (wall, timerHeap[0].stop) >= 0)) {
	remove (timer);

	timerLock -> release ();

	if (timer.trap != NULL) {
	    timer.trap -> wallAlarm ();
	} 

	timerLock -> acquire ();

	wall = getCurrentWall ();
    }

	/* set a SIGALRM for the next timer */

    if (timerCount > 0) {
	interval = subTimevals (timerHeap[0].stop, wall);
        itimer.it_interval.tv_sec = 0;
	itimer.it_interval.tv_usec = 0;
	itimer.it_value.tv_sec = interval.tv_sec;
	itimer.it_value.tv_usec = interval.tv_usec;
	setitimer (ITIMER_REAL, &itimer, NULL);
    }
   
    timerLock -> release ();
}

/* TIMERS::bubble_up

   Purpose: Bubble an item up to its proper position in the heap

     Input: i = index of the item in the heap

    Output: The procedure bubbles the item up to its proper position.

      NOTE: The procedure assumes that SIGALRM is blocked.
*/

void TIMERS::bubble_up (int i)
{
    int child;           /* index of the child in the heap  */
    int parent;          /* index of the parent in the heap */

	/* we better have a valid heap element */

    assert (i < timerCount);

	/* bubble up the item */

    child  = i;
    parent = (child - 1) >> 1;

    while ((parent >= 0) && (compareTimevals (timerHeap[child].stop, timerHeap[parent].stop) < 0)) {
	swap (child, parent);
	child  = parent;
	parent = (child - 1) >> 1;
    }
}

/* TIMERS::swap

   Purpose: Swap two elements of the heap

     Input: i = index of first element
            j = index of second element

    Output: The procedure swaps the two elements.

      NOTE: This procedure assumes that SIGALRM is blocked.
*/

void TIMERS::swap (int i, int j)
{
  TIMER temp   = timerHeap[i];
  timerHeap[i] = timerHeap[j];
  timerHeap[j] = temp;
}  

/* TIMERS::TIMERS

   Purpose: This procedure is the constructor for class TIMERS.
*/

TIMERS::TIMERS (void)
{
	/* set up if this is the first instance */

    if (count == 0) {

	    /* set up the static data */

	ticks      = sysconf (_SC_CLK_TCK);
	timerMax   = DEFAULT_TIMER_MAX;
	timerHeap  = new TIMER [timerMax];
	timerCount = 0;
	count      = 1;
	timerLock  = new MutexLock ();

	    /* install the SIGALRM interrupt */
    
        install_signal_intr (SIGALRM, sigalrm_handler, 0);

    } else {

	MutexGuard guard (*timerLock); // automatically released
	count += 1;
    }
}

/* TIMERS::~TIMERS

   Purpose: This procedure is the destructor for class TIMER.
*/

TIMERS::~TIMERS ()
{
	/* scope for the guard */

    {
	MutexGuard guard (*timerLock); // automatically released 

	--count;

	if (count == 0) {
	    install_signal_intr (SIGALRM, (void (*)(int)) SIG_IGN, 0);
	}
    }

	/* now it's safe to delete if necessary */
 
    if (count == 0) {
	delete (timerHeap);
	delete (timerLock);
    }
}

/* TIMERS::add

   Purpose: Add a timer to the set of timers

     Input: stop = time at which the timer should expire
		   (struct timeval)

	    trap = TIMER_TRAP instance
		   (class TIME_TRAP *) 

    Output: The procedure adds the timer to the set of timers.
*/

void TIMERS::add (struct timeval stop, TIMER_TRAP *trap)
{
    int newIndex;
    TIMER *newHeap; 

	/* guard the access (lock is automatically released) */

    MutexGuard guard (*timerLock);

       /* make the heap bigger if necessary */

    if (timerCount == timerMax) {

	newHeap = new TIMER [timerMax << 1];
    
	for (int i = 0; i < timerMax; i++) {
	    newHeap[i] = timerHeap[i];
	}

	delete timerHeap;
	timerMax = timerMax << 1;
	timerHeap = newHeap;
    }  

	/* add the timer to the heap and bubble up */

    newIndex = timerCount;
    timerHeap[newIndex] = TIMER (stop, trap);
    timerCount += 1;
    bubble_up (newIndex);

	/* dispose of any expired timers */

    disposeTimers ();
}

/* TIMERS::remove

   Purpose: Remove the smallest timer from the heap

     Input: None

    Output: The procedure removes and returns the smallest timer. 

      NOTE: The procedure assumes that SIGALRM is blocked.
*/

void TIMERS::remove (struct TIMER &minTimer)
{
    int hole;          /* the hole that we are bubbling down */
    int left;          /* the left child of the hole         */
    int right;         /* the right child of the hole        */

	/* guard the access (lock is automatically released) */

    MutexGuard guard (*timerLock);

	/* assert that there is one or more timers in the heap */

    assert (timerCount > 0);

	/* copy out the min element */

    minTimer = timerHeap[0];

	/* bubble the empty whole down */

    hole  = 0;
    left  = (hole << 1) + 1;
    right = (hole << 1) + 2;
 
    while (left < timerCount) {
	if ((right >= timerCount) || (compareTimevals (timerHeap[left].stop, timerHeap[right].stop) < 0)) {
	    swap (left, hole);
	    hole = left;
	} else {
	    swap (right, hole);
	    hole = right;
	} 

	left  = (hole << 1) + 1;
	right = (hole << 1) + 2;
    }

	/* copy and bubble up in order to get a full tree again */

    timerCount -= 1;

    if (hole != timerCount) {
	timerHeap[hole] = timerHeap[timerCount];
	bubble_up (hole);
    }
}

/* sigalrm_handler

   Purpose: Handle SIGALRM signals

     Input: signo = SIGALRM

    Output: The procedure disposes of the expired timer.
*/

void sigalrm_handler (int signo)
{
    int oldErrno;

	/* save errno */

    oldErrno = errno;

	/* dispose of the timers */

    TIMERS::disposeTimers ();

	/* restore errno */

    errno = oldErrno;
}
