#include "httpclient.h"
#include <fstream.h>

#include <windows.h>
#include <winsock.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

#define MAX_FILENAME_LEN 128

/* first part of the proxied HTTP request */
const char HttpHeader[] = "GET ";

/* last part of the proxied HTTP request */
const char HttpTrailer[] = " HTTP/1.0\r\nAccept: */*\r\nUser-Agent: DynClass/1.0\r\n\r\n";

enum tReadingState { sHeader, sCR1, sLF1, sCR2, sBody };
const tReadingState state_moves_CR[]  = { sCR1, sHeader, sCR2, sHeader, sBody };
const tReadingState state_moves_LF[]  = { sHeader, sLF1, sHeader, sBody, sBody };

cHTTPClient::cHTTPClient() 
	: mProxyIP(NULL), 
	mProxyPort(0)
{
	mTempDir = strdup("");  // mTempDir always has a value
	mTempDirLen = 0;
	assert( mTempDir != NULL );

	WORD wVersionRequested;
	WSADATA wsadata;
	int error;
	// Initialize WinSock
	wVersionRequested = MAKEWORD(1,1);
	error = WSAStartup( wVersionRequested, (LPWSADATA) &wsadata );
}

cHTTPClient::~cHTTPClient() {
	if ( mProxyIP != NULL )
		delete mProxyIP;
	delete mTempDir;
	WSACleanup();
}

void cHTTPClient::UpdateProxyAddress() {
	// Find the real address using the mProxyIP
	// If the address is on the form "###.###.###.###" then we 
	// don't have to look it up.
	int err;
	u_long addr = inet_addr( mProxyIP );
	if ( addr == INADDR_NONE ) {
		// Look up tha name
		struct hostent *tmp;
		tmp = gethostbyname(mProxyIP);
		if ( tmp == NULL ) {
			err = WSAGetLastError();
		} else {
			addr = *((u_long *)(tmp->h_addr));
		}
	}
	// Naming the socket
	mProxyAddress.sin_family = AF_INET;
	mProxyAddress.sin_port = htons(mProxyPort);
	mProxyAddress.sin_addr.s_addr = addr;
}

void cHTTPClient::set_temp_dir( const char *dir ) {
	delete mTempDir;
	mTempDir = strdup( dir );
	mTempDirLen = strlen( mTempDir );
	assert( mTempDir != NULL );
}

void cHTTPClient::set_proxy( const char *ip, u_short port ) {
	if ( mProxyIP != NULL )
		delete mProxyIP;
	mProxyIP = strdup( ip );
	mProxyPort = port;
	UpdateProxyAddress();
}

const char* random_name() {
	char filename[MAX_FILENAME_LEN];
	sprintf( filename, "tmp%ul.dll", rand() );
	return filename;
}

char *cHTTPClient::get_unique_filename() {
	ifstream *tmp_stream_ptr;

	char *filename = new char[mTempDirLen+MAX_FILENAME_LEN+1];
	strcpy( filename, mTempDir );
	strcpy( &filename[mTempDirLen], random_name() );

	// Find out if the files exist
	tmp_stream_ptr = new ifstream( filename, ios::nocreate );
	cout << "Try " << filename << endl;
	while ( tmp_stream_ptr->good() ) {
		tmp_stream_ptr->close();
		strcpy( &filename[mTempDirLen], random_name() );
		tmp_stream_ptr = new ifstream( filename, ios::nocreate  );
		cout << "Try " << filename << endl;
	}
	return filename;
}

char* cHTTPClient::request( const char *URL ) {
	SOCKET s;
	int ret;
	char *filename;

	if ( mProxyIP == NULL )
		throw eNeedProxy();

	// Opening the socket
	s = socket( PF_INET, SOCK_STREAM, 0 );
	// Connect
	ret = connect( s, (SOCKADDR*)(&mProxyAddress), sizeof(mProxyAddress) );

	// Send the request
	send( s, HttpHeader, sizeof(HttpHeader) - 1, 0 );
	send( s, URL, strlen(URL), 0 );
	send( s, HttpTrailer, sizeof(HttpTrailer) - 1, 0 );


	// Now read the response and remove the header.
	char buf[4096];
	int len;
	int offset;

	// Create and open a file with random name
	filename = get_unique_filename();
	ofstream out( filename, ios::out | ios::binary | ios::noreplace );
	cout << "Out " << filename << endl;

	// The automata is
	//         CR        LF        CR        LF  
	// HEADER ----> CR1 ----> LF1 ----> CR2 ----> BODY
	//    ^          |         |         |
	//    |----<---------<----------<-----
	//              Otherwise


	tReadingState state = sHeader;
	while ( (len = recv( s, buf, sizeof(buf), 0 )) != 0 ) {
		if ( state != sBody ) {
			offset = 0;
			while ( (state != sBody) && (offset < len) ) {
				if ( buf[offset] == '\r' ) {
					state = state_moves_CR[ state ];
				} else if ( buf[offset] == '\n' ) {
					state = state_moves_LF[ state ];
				} else {
					state = sHeader;
				}
				++offset;
			}
			// Write out the body part of this block.
			if ( state == sBody )
				out.write( &buf[offset], len - offset );
		} else {
			out.write( buf, len );
		}
	}
	out.close();				// Close the output file
	send( s, "QUIT\n", 5, 0 );	// Close the service
	closesocket( s ); 			// Close the socket
	return filename;
}

