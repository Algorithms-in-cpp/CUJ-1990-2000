/* Agent Tcl
   Bob Gray
   28 Spetember 1995

   timers.h

   This file defines a class that allows a process to define any number of
   timers.

   Copyright (c) 1995, Robert S. Gray Dartmouth College

   See the file "agent.terms" for information on usage and redistribution
   of this file and for a DISCLAIMER OF ALL WARRANTIES.
*/

#ifndef _TIMERS_H
#define _TIMERS_H

#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include "lock.h"

  /* default size of the timer heap */

const int DEFAULT_TIMER_MAX = 8;

  /* interrupt handler for SIGALRM */

void sigalrm_handler (int signo);

    /* any class that needs a timer interrupt inherits TIMER_TRAP */

class TIMER_TRAP
{
     friend class TIMERS;

protected:

	/* a wall timer has expired */

    virtual void wallAlarm (void) = 0;

	/* a cpu timer has expired */

    virtual void cpuAlarm (void) = 0;

public:

    virtual ~TIMER_TRAP() {};
}; 

  /* one TIMER */
 
struct TIMER
{
    struct timeval stop;    /* timer expiration */
    TIMER_TRAP *trap;       /* timer trap       */

	/* constructors */

    TIMER (void);
    TIMER (const TIMER &timer);
    TIMER (struct timeval stop, TIMER_TRAP *trap);

	/* assignment operator */

    TIMER& operator= (const TIMER &timer) {
	stop = timer.stop;
        trap = timer.trap;
	return (*this);
    } 
};

  /* all active TIMERS */

class TIMERS
{
      /* sigalrm_handler can access any element of the class */

    friend void sigalrm_handler (int);

    static int count;               /* number of instances of this class   */
    static long ticks;              /* number of clock ticks per second    */
    static int timerMax;            /* maxium number of timers in the heap */
    static int timerCount;          /* number of timers in the heap        */
    static TIMER *timerHeap;        /* a min-heap of timers                */
    static MutexLock *timerLock;    /* mutual exclusion                    */   
      /* swap two elements of the heap */

    static void swap (int i, int j);

      /* bubble an element up */

    static void bubble_up (int i);

      /* remove a timer */

    static void  remove (struct TIMER &minTimer);

  public:

      /* dispose of expired timers */

    static void disposeTimers (void);

	/* get the current wall time */

    static struct timeval getCurrentWall (void);

	/* convert seconds to a timeval */

    static struct timeval secondsToTimeval (double seconds);

	/* convert a timeval to seconds */

    static double timevalToSeconds (struct timeval tv);

	/* compare two timevals */

    static int compareTimevals (struct timeval t1, struct timeval t2);

	/* add and substract two timevals */

    static struct timeval addTimevals (struct timeval t1, struct timeval t2);
    static struct timeval subTimevals (struct timeval t1, struct timeval t2);
 
	/* insert a timer */

    void add (struct timeval stop, TIMER_TRAP *trap);
 
      /* constructor and destructor */

    TIMERS (void);
   ~TIMERS ();
};

#endif
