/* Dynamic classes
  
   Bob Gray and Gisli Hjalmtysson
   AT&T, Network Mathematics Research Department (AK0112730)
   600 Mountain Avenue
   Murray Hill, New Jersey
   Bob Gray

   5 August 1996

   mystrings.h

   This file provides a version of strcpy that creates a dynamically
   allocated copy of the source string.
*/

#ifndef _MY_STRINGS_H
#define _MY_STRINGS_H

char *my_strcpy (const char *string);

char *strip_whitespace (const char *string);

#endif
