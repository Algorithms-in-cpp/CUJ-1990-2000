#include "download.h"
#include "httpclient.h"

char *downloadVersion (const char *URL, const char *tempDir) {
	cHTTPClient client;
	client.set_proxy( "135.205.49.32", 8192 );
	client.set_temp_dir( tempDir );
	return client.request( URL );
}