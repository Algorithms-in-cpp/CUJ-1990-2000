/* Dynamic classes
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   testmedi.cc

   This file tests the "medium" version of the dynamic template.
*/

#include "lock.h"
#include "baseclass.h"
#include "dynmedium.h"
#include "exception.h"

int main (int argc, char **argv)
{
    int handle;

	/* test the dynamic classes */

    try {

	printf ("\n--- should have an InvalidHandle exception\n");

	try {
	    dynmedium<Test_Base> a1 (4);
	} 
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}
	
	printf ("\n--- should have an InvalidVersion exception\n");
	
	try {
	    handle = dynmedium<Test_Base>::activate ("libBad.so.0.0", "Hello");
	    dynmedium<Test_Base> a1 (handle);
	} 
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}

	printf ("\n--- should have a handle of 1\n");	
	handle = dynmedium<Test_Base>::activate ("libTest.so.1.0", "Test");
	printf ("handle ==> %d\n", handle);
    	dynmedium<Test_Base> d (handle);

    	printf ("\n--- some output (from version 1.0)\n");
    	d->print();

	printf ("\n--- should have an ActiveVersion exception\n");

	try {
	    dynmedium<Test_Base>::invalidate ("libTest.so.1.0", handle);
	} 
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}

	printf ("\n--- should have a NonexistentVersion exception\n");

	try {
	    dynmedium<Test_Base>::invalidate ("libTest.so.1.1", handle);
	} 
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}

	printf ("\n--- number below should be 1 since there is now 1 version\n");
        printf ("%d\n", dynmedium<Test_Base>::getVersionCount(handle));

	dynmedium<Test_Base>::activate ("libTest.so.1.1");
    	dynmedium<Test_Base> e (handle);

    	printf ("\n--- some output (from version 1.1, 1.0, 1.1, 1.0)\n");
    	e->print();
    	d->print();
    	e->print();
    	d->print();

	printf ("\n--- number below should be 2 since there are now 2 versions\n");
        printf ("%d\n", dynmedium<Test_Base>::getVersionCount(handle));

	dynmedium<Test_Base>::activate ("libTest.so.1.2");
    	dynmedium<Test_Base> f (handle);
    	dynmedium<Test_Base> g (handle);

    	printf ("\n--- some output (from version 1.0, 1.1, 1.2, 1.2, 1.0, 1.1, 1.2, 1.2)\n");
    	d->print();
    	e->print();
    	f->print();
    	g->print();
    	d->print();
    	e->print();
    	f->print();
    	g->print();

	printf ("\n--- testing assignment (should change from version 1.2 to 1.0)\n");
    	dynmedium<Test_Base> h (handle);
	h -> print ();
	h = d;
    	h -> print ();

	printf ("\n--- testing copy constructor (should see two version 1.0's)\n");
    	h -> print ();
	dynmedium<Test_Base> i (h);
	i -> print ();
   
	printf ("\n--- should have a ZombieVersion exception\n"); 
	dynmedium<Test_Base>::activate_and_invalidate ("libTest.so.1.2");

	try {
	    d->print();
	}
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}	

	printf ("\n--- number below should be 3 since there are now 3 versions\n");
        printf ("==> %d\n", dynmedium<Test_Base>::getVersionCount(handle));
    }
    catch (Exception &except) {
	printf ("EXCEPTION! %s\n", except.describeException ());
	exit (1);
    }


    exit (0);
}
