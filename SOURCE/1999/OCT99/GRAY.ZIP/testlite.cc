/* Dynamic classes
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   testlite.cc

   This file tests the "lite" version of the dynamic template. 
*/

#include "lock.h"
#include "baseclass.h"
#include "dynlite.h"
#include "exception.h"

int main (int argc, char **argv)
{
	/* test the dynamic classes */

    try {

	printf ("\n--- should have a NoActiveVersions exception\n");

	try {
	    dynlite<Test_Base> a1;
	} 
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}

	printf ("\n--- should have an InvalidVersion exception\n");
	
	try {
	    dynlite<Test_Base>::activate ("libBad.so.0.0");
	    dynlite<Test_Base> a1;
	} 
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}

	dynlite<Test_Base>::activate ("libTest.so.1.0");
    	dynlite<Test_Base> d;

    	printf ("\n--- some output (from version 1.0)\n");
    	d->print();

	printf ("\n--- should have an ActiveVersion exception\n");

	try {
	    dynlite<Test_Base>::invalidate ("libTest.so.1.0");
	} 
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}
	
	printf ("\n--- should have a NonexistentVersion exception\n");

	try {
	    dynlite<Test_Base>::invalidate ("libTest.so.1.1");
	} 
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}

	printf ("\n--- number below should be 1 since there is now 1 version\n");
        printf ("%d\n", dynlite<Test_Base>::getVersionCount());

	dynlite<Test_Base>::activate ("libTest.so.1.1");
    	dynlite<Test_Base> e;

    	printf ("\n--- some output (from version 1.1, 1.0, 1.1, 1.0)\n");
    	e->print();
    	d->print();
    	e->print();
    	d->print();

	printf ("\n--- number below should be 2 since there are now 2 versions\n");
        printf ("%d\n", dynlite<Test_Base>::getVersionCount());

	dynlite<Test_Base>::activate ("libTest.so.1.2");
    	dynlite<Test_Base> f;
    	dynlite<Test_Base> g;

    	printf ("\n--- some output (from version 1.0, 1.1, 1.2, 1.2, 1.0, 1.1, 1.2 1.2)\n");
    	d->print();
    	e->print();
    	f->print();
    	g->print();
    	d->print();
    	e->print();
    	f->print();
    	g->print();

	printf ("\n--- testing assignment (should change from version 1.2 to 1.0)\n");
    	dynlite<Test_Base> h;
	h -> print ();
	h = d;
    	h -> print ();

	printf ("\n--- testing copy constructor (should see two version 1.0's)\n");
    	h -> print ();
	dynlite<Test_Base> i (h);
	i -> print ();
    
	printf ("\n--- should have a ZombieVersion exception\n");
	dynlite<Test_Base>::activate_and_invalidate ("libTest.so.1.2");

	try {
	    d->print();
	}
	catch (Exception &except) {
	    printf ("EXCEPTION! %s\n", except.describeException ());
	}	

	printf ("\n--- number below should be 3 since there are now 3 versions\n");
        printf ("%d\n", dynlite<Test_Base>::getVersionCount());
    }
    catch (Exception &except) {
	printf ("EXCEPTION! %s\n", except.describeException ());
	exit (1);
    }


    exit (0);
}
