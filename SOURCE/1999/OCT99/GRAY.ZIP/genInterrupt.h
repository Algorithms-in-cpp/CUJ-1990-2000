/* Agent Tcl
   Bob Gray
   9 February 1995

   interrupt.h

   This file defines a reliable signal function "install_signal".  This
   function is based on the examples in "UNIX Network Programming" by
   W. Richard Stevens [Prentice-Hall, 1990].

   Copyright (c) 1995, Robert S. Gray Dartmouth College

   See the file "agent.terms" for information on usage and redistribution
   of this file and for a DISCLAIMER OF ALL WARRANTIES.
*/

#ifndef _INTERRUPT_H
#define _INTERRUPT_H

#include <signal.h>

int install_signal (int signo, void (*func) (int), int sa_flags);
int install_signal_intr (int signo, void (*func) (int), int sa_flags);

#endif
