/* Agent Tcl
   Bob Gray
   25 January 1995

   genPorts.h 

   This file defines the structures REMOTE_PORT and MACHINE_ID.

   Copyright (c) 1996, Robert S. Gray, AT&T Research
*/

#ifndef _GEN_PORTS_H
#define _GEN_PORTS_H

#include <sys/time.h>
#include <stdlib.h>
#include "genUtility.h"
#include "mystrings.h"

    /* unknown IP address */

const UINT_32 UNKNOWN_IP = 0xffffffff;

    /* wildcard constants */

#define ANY_SERVER	NULL
const UINT_32 ANY_IP	= 0;
#define ANY_NAME	NULL
const UINT_32 ANY_ID	= 0;
#define ANY_TAG		NULL

    /* machine identification */

struct MACHINE_ID        
{
    char    *name;    /* name of the machine                        */
    UINT_32 ip;       /* IP address of the machine (or UNKNOWN_IP)  */

#ifdef __cplusplus

	/* constructors */

    MACHINE_ID (void);
    MACHINE_ID (const MACHINE_ID &id);
    MACHINE_ID (char *server, UINT_32 server_ip);
  
	/* overload the assignment operator */

    MACHINE_ID& operator= (const MACHINE_ID& id);

	/* change the name and IP address */

    void update (char *server, UINT_32 server_ip);
 
	/* destructor */
 
    ~MACHINE_ID ();

#endif
};

    /* a port identification */

struct REMOTE_PORT  
{
    char *machine;       /* machine name              */
    UINT_32 ip;          /* IP address of the machine */
    int port;            /* port number               */

#ifdef __cplusplus

	/* constructors */

    REMOTE_PORT (char *p_machine, UINT_32 p_ip, int p_port):
	machine		(my_strcpy (p_machine)),
	ip		(p_ip),
	port		(p_port)
    {
	/* empty */
    };
	

    REMOTE_PORT (const REMOTE_PORT &port):
	machine		(my_strcpy (port.machine)),
	ip		(port.ip),
	port		(port.port)
    {
	/* empty */
    };

    REMOTE_PORT (void):
	machine		((char *) NULL),
	ip		(0),
	port		(0)
    {
	/* empty */
    };

	/* destructor */

   ~REMOTE_PORT () {
	delete (machine);
    };

#endif
};

#endif
