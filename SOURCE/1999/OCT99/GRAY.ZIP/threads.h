/* Dynamic classes
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   3 July 1996

   threads.h

   This file provides a class for initializing the "pthreads" package.
*/

#ifndef _THREADS_H
#define _THREADS_H

#ifdef USE_PTHREADS

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

class ThreadInitialize
{ 
    public:

	ThreadInitialize (void) {
	    pthread_init ();
	}
};

#else

#include <assert.h>

class ThreadInitialize
{
    public:

	ThreadInitialize (void) {
	    assert (0);
	}
};

#endif /* USE_PTHREADS */
#endif /* _THREADS_H */
