/* Dynamic classes
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   manager.h

   This file defines a generic template which manages a pointer to a heap
   object, i.e., it ensures that the heap object is deleted when it is no
   longer needed.

   This template is taken directly from the book "C++ Faqs: Frequently Asked
   Questions" by Marshal Cline and Greg Lomow (Addison-Wesley, 1995).  The
   template appears in Faq 460 on page 439.
*/

#ifndef _MANAGER_H
#define _MANAGER_H

#include <stdlib.h>
#include <assert.h>

template <class T> class HeapPtr {

	T *ptr;
	HeapPtr (const HeapPtr<T>&); 		    // unimplemented
	HeapPtr<T>& operator= (const HeapPtr<T>&);  // unimplemented

    public:

	    /* deallocate or relingquish ownership */

	void deallocate (void) {
	    delete ptr;
	    ptr = NULL;
	}

	T *relinquishOwnership (void) {
	    T *old = ptr;
	    ptr = NULL;
	    return (old);
	}

	    /* constructor, destructor and assignment operator */

	HeapPtr (T *p_ptr=NULL):
	    ptr (p_ptr)
	{
	    /* empty */
	}

       ~HeapPtr () {
	    deallocate ();
	}

	HeapPtr<T>& operator= (T * p_ptr) {
	    deallocate ();
	    ptr = p_ptr;
	    return (*this);
	}

	    /* access and type conversion */

	T* operator-> (void) {
	    return (ptr);
	}

	T& operator* (void) {
	    return (*ptr);
	}

	operator T* () {
	    return (ptr);
	}
};

#endif
