/* Dynamic classes
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   dynversion.h

   This file defines class "DynamicVersion" which keeps track of a 
   dynamically loaded class version.
*/

#ifndef _DYN_VERSION_H
#define _DYN_VERSION_H

#include "boolean.h"
#include "name.h"

#ifdef _WIN32
#include <windows.h>
#endif

class DynamicVersion 
{
public:

	VersionName names;        /* actual and local names                 */
	Boolean file;             /* e_TRUE if we got the agent from a file */ 
#ifdef _WIN32
	HINSTANCE dlhandle;       /* handle for dynamic link library        */
#else
	void *dlhandle;           /* handle for dynamic link library        */
#endif
        Boolean dlloaded;         /* e_TRUE if dynamic link library loaded  */
	Boolean active;           /* e_TRUE if this is the active version   */
	int refCount;             /* number of instances of this version    */
	void * (*funcPtr) (void); /* function to create the object          */
	Boolean force;            /* e_TRUE if we are disallowing all       */
				  /* further use                            */

public:

	    /* constructors */

	DynamicVersion 
	    (void);

	DynamicVersion 
	    (const char *className, const char *actualName, const char *localName, Boolean p_file, Boolean p_active);

	DynamicVersion 
	    (const DynamicVersion &p_version);

	    /* assignment operator */

	DynamicVersion &operator= (const DynamicVersion &p_version);

	    /* see if we have the same class name */

	Boolean isClass (const char *className) {

	    Boolean sameActual;

	    if ((names.className == NULL) && (className == NULL)) {
		sameActual = e_TRUE; 
	    } else if ((names.className == NULL) || (className == NULL)) {
		sameActual = e_FALSE; 
	    } else if (!strcmp (names.className, className)) {
		sameActual = e_TRUE; 
	    } else {
		sameActual = e_FALSE; 
	    }

	    return (sameActual);
	}

	    /* see if we have the same library name */

	Boolean isLibrary (const char *actualLocation) {

	    Boolean sameActual;

	    if ((names.actualLocation == NULL) && (actualLocation == NULL)) {
	 	sameActual = e_TRUE;
	    } else if ((names.actualLocation == NULL) || (actualLocation == NULL)) {
		sameActual = e_FALSE;
	    } else if (!strcmp (names.actualLocation, actualLocation)) {
		sameActual = e_TRUE;
	    } else {
		sameActual = e_FALSE;
	    }
	
 	    return (sameActual);
	}

	    /* see if we have the same class and library names */

	Boolean isSame (const DynamicVersion &version) {

	    Boolean same;

	    if (!(isClass (version.names.className))) {
		same = e_FALSE;
	    } else if (!(isLibrary (version.names.actualLocation))) {
		same = e_FALSE;
	    } else {
		same = e_TRUE;
	    }

	    return (same);
	}
};

#endif /* _DYN_VERSION_H */
