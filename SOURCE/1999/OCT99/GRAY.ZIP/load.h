/* Dynamic classes

   Bob Gray and Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   20 March 1997

   load.h

   This file defines the routine that loads a library from either the disk
   or across the network.
*/

#ifndef _LOAD_H
#define _LOAD_H

#include "dynexcept.h"

struct DynamicVersion;     // forward declaration so we cam compile

    // load the shared library

#ifdef _WIN_32

void loadLibrary (DynamicVersion *dvPtr, const char *className);

#else

void loadLibrary (DynamicVersion *dvPtr, const char *className)
    throw (NoVersionLibrary, InvalidVersion, NoCreateFunction);

#endif

    // unload the shared library

void unloadLibrary (DynamicVersion *dvPtr);

#endif
