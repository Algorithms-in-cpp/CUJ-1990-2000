/* Dynamic classes
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   name.h

   This file defines the "VersionName" class.
*/

#ifndef _VERSION_H
#define _VERSION_H

#include <assert.h>
#include <string.h>
#include "mystrings.h"

class VersionName
{
	friend class DynamicVersion;

    private:

	char *className;	  /* name of the class              */
	char *actualLocation;     /* actual location of the library */
        char *localLocation;      /* local location of the library  */

    public:

	    /* constructors */

	VersionName (void):
	    className ((char *) NULL),
	    actualLocation ((char *) NULL),
	    localLocation ((char *) NULL)
	{
	    /* empty */
	}

	VersionName (const char *p_className, const char *p_actualLocation, const char *p_localLocation):
	    className (my_strcpy (p_className)),
	    actualLocation (my_strcpy (p_actualLocation)),
	    localLocation (my_strcpy (p_localLocation))
	{
	    /* empty */
	}

	VersionName (const VersionName& name):
	    className (my_strcpy (name.className)),
	    actualLocation (my_strcpy (name.actualLocation)),
	    localLocation (my_strcpy (name.localLocation))
	{
	    /* empty */
	}

	    /* assignment operator */

	VersionName& operator= (const VersionName& name) {

	    if (this != &name) {
		delete (className);
		className = my_strcpy (name.className);
		delete (actualLocation);
		actualLocation = my_strcpy (name.actualLocation);
		delete (localLocation);
		localLocation = my_strcpy (name.localLocation);
	    }

	    return (*this);
	}

	    /* get the class, actual and local names */ 

	char * getClassName (void) {
	    return (my_strcpy (className));
	}

	char * getActualLocation (void) {
	    return (my_strcpy (actualLocation));
  	}

	char * getLocalLocation (void) {
	    return (my_strcpy (localLocation));
	}
};

#endif /* _VERSION_H */
