/* Dynamic classes
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   dynlite.h

   This file defines the template class that provides for versioning.
*/

#ifdef _WIN32
#define THROW1(e1)
#define THROW2(e1,e2)
#define THROW3(e1,e2,e3)
#define THROW4(e1,e2,e3,e4)
#define THROW5(e1,e2,e3,e4,e5)
#else
#define THROW1(e1)              throw(e1)
#define THROW2(e1,e2)           throw(e1,e2)
#define THROW3(e1,e2,e3)        throw(e1,e2,e3)
#define THROW4(e1,e2,e3,e4)     throw(e1,e2,e3,e4)
#define THROW5(e1,e2,e3,e4,e5)  throw(e1,e2,e3,e4,e5)
#endif

#ifndef _DYNAMIC_H
#define _DYNAMIC_H

#include "lock.h"
#include <assert.h>

#ifdef _WIN32
// no equivalents
#else
#include <dirent.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "boolean.h"
#include "dynexcept.h"
#include "dynversion.h"
#include "faststring.h"
#include "list.h"
#include "load.h"
#include "manager.h"
#include "map.h"

#ifdef ALLOW_DOWNLOADS
#ifdef _WIN32
#include "win_download.h"
#else
#include "download.h"
#endif
#endif

    /* the main proxy */

typedef list<DynamicVersion*> VersionList;

template<class T> class dynlite {

    protected:

	    /*
	     * the active version, the list of all versions and a lock
	     * for mututal exclusion
	     */

	static DynamicVersion *activePtr; 
	static VersionList *versionList;
#ifdef USE_THREADS
	static MutexLock lock;
#endif

	    /*
	     * The actual object and its version information 
	     */

	T *object;
	DynamicVersion *dvPtr;

	    /*
	     * activation
	     */

	static void activateInternal
	    (Boolean invalidate, const char *actualName)
	    THROW5(NoTemporaryLibrary,NoDownload,NoVersionLibrary,InvalidVersion,NoCreateFunction);

	    /* deactivation */

	static void eraseVersion
	    (DynamicVersion *dvPtr); 

	static void deactivateVersion
	    (DynamicVersion *ptr, Boolean force);

	static void invalidateAll
	    (const char *actualName);

    public:

	    /* constructor, copy constructor and destructor */ 

        dynlite (void) 
	    THROW2 (NoActiveVersions,NoObject);

	dynlite (const dynlite<T>& proxy)
	    THROW2 (NoObject,ZombieVersion);

       ~dynlite ();

	    /* assignment operator */

	dynlite<T>& operator= (const dynlite<T>& proxy)
	    THROW1 (ZombieVersion);

	    /* smart pointer to reference the actual object */

	T *operator-> (void) 
	    THROW1 (ZombieVersion);

	    /* activate a version */

	static void activate 
	    (const char *actualName)
	    THROW5(NoTemporaryLibrary,NoDownload,NoVersionLibrary,InvalidVersion,NoCreateFunction);
 
	    /* invalidate a version */

	static void invalidate 
	    (const char *actualName)
	    THROW2 (ActiveVersion,NonexistentVersion);

	    /* invalidate current versions and activate a new version */

	static void activate_and_invalidate 
	    (const char *actualName)
	    THROW5(NoTemporaryLibrary,NoDownload,NoVersionLibrary,InvalidVersion,NoCreateFunction);

	    /* information routines -- need more routines */ 

	static int getVersionCount (void);
};

/* static data */

template <class T>
    DynamicVersion *
    dynlite<T>::activePtr = NULL;

template <class T> 
    VersionList *
    dynlite<T>::versionList = NULL;

#ifdef USE_THREADS

template <class T>
    MutexLock
    dynlite<T>::lock;

#endif

/* template<class T> dynlite<T>::dynlite

   Purpose: This procedure is the constructor for class "dynamic".

     Input: className = name of the class of which we are creating an
		        instance
			(const char *) 

    Output: The procedure initializes this instance of "dynamic", i.e., it
            creates an object of the given class and adds this object
   	    to the internal control structures.
*/

template<class T> dynlite<T>::dynlite (void) THROW2(NoActiveVersions,NoObject)
{
	/* lock for mutual exclusion -- automatically released */

    DEFINE_GUARD(guard,lock);

	/* get the active version */
 
    dvPtr  = activePtr; 

    if (dvPtr == NULL) {
	throw NoActiveVersions();
    }
    
	/* call the function to create the object -- we know that funcPtr  */
	/* is not NULL since a version can never become the active version */
	/* unless activate was able to load the library and find the       */
	/* createInstance method                                           */

    object = (T *)(*(dvPtr->funcPtr))(); 

    if (object == NULL) {
	throw NoObject ();
    }

	/* increment the reference count for the library */ 

    dvPtr -> refCount += 1;
}

/* template <class T> dynlite<T>::dynlite

   Purpose: This procedure is the copy constructor for class "dynamic".

     Input: proxy = the proxy that is being copied
		    (const class dynlite<T>&)

    Output: The procedure copies the object.
*/

template<class T> dynlite<T>::dynlite (const dynlite<T>& proxy) THROW2 (NoObject,ZombieVersion)
{
	/* lock the list that contains the *copied* object's version */

    DEFINE_GUARD(guard,proxy.lock);

	/* disallow the copy if we have a zombie version */ 

    if (proxy.dvPtr -> force) {
	throw ZombieVersion (); 
    } 

	/* copy the object */

    if ((object = (T *) proxy.object -> copyInstance()) == NULL) {
	throw NoObject();
    }

	/* reference the appropriate version and increment reference count */

    dvPtr = proxy.dvPtr;
    dvPtr -> refCount += 1;
}

/* template <class T> dynlite<T>::~dynamic

   Purpose: This procedure is the destructor for class "dynamic".

     Input: None

    Output: The procedure destroys this instance of "dynamic", i.e., it
            destroys the associated object of interface type T and removes 
	    this object from the internal control structures.
*/

template<class T> void dynlite<T>::eraseVersion (DynamicVersion *dvPtr)
{
    versionList -> remove (dvPtr);

    if (dvPtr == activePtr) {
	activePtr = NULL;
    }

    unloadLibrary (dvPtr);
    delete (dvPtr);
}

template<class T> dynlite<T>::~dynlite() 
{
	/* lock for mutual exclusion -- automatically released */

    DEFINE_GUARD(guard,lock);

	/* delete the actual object -- this must be done FIRST since */
	/* we need the destructor, i.e., we can't do the "dlclose"   */
	/* until we are finished with the destructor                 */

    delete (object);

	/* decrement the *version* reference count and remove the */
	/* version if we are done with it			  */

    dvPtr -> refCount -= 1;

    if (!(dvPtr -> active) && (dvPtr -> refCount == 0)) {
	eraseVersion (dvPtr);
    }
} 

/* template <class T> dynlite<T>::operator=

   Purpose: This procedure is the assignment operator for class dynlite<T>.

     Input: proxy = proxy from which we are assigning
		    (const class dynlite<T>&)
*/

template <class T> dynlite<T>& dynlite<T>::operator= (const dynlite<T>& proxy) THROW1(ZombieVersion)
{
    T *oldObject;
    DynamicVersion *oldDvPtr;

	/* locks for mutual exclusion -- automatically released */

    DEFINE_GUARD(guard,lock);
    DEFINE_GUARD(otherGuard,proxy.lock);
	
	/* disallow the assignment if we have a zombie version */
	/* or incompatible versions                            */

    if (proxy.dvPtr -> force) {
	throw ZombieVersion();
    }

	/* nothing to do if we are the same proxy */

    if (this == &proxy) {
	return (*this);
    }

	/* nothing to do if we refer to the same object */

    if (object == proxy.object) {
	return (*this);
    }

	/* remember the version information that we're about to replace */
 
    oldDvPtr = dvPtr;

	/* do the assignment */

    if (dvPtr -> isSame (*proxy.dvPtr)) {

        proxy.object -> assignInstance (*object);

    } else {

	oldObject = object;

	if ((object = (T *) proxy.object -> copyInstance()) == NULL) {
	    object = oldObject;
	    throw NoObject ();
	}

	delete (oldObject);

    } 

    dvPtr = proxy.dvPtr;
    dvPtr -> refCount += 1;

	/* see if we are done with the old version */

    oldDvPtr -> refCount -= 1;

    if ((oldDvPtr -> refCount == 0) && !(oldDvPtr -> active)) {
	eraseVersion (oldDvPtr);
    } 

	/* done */

    return (*this);
}

/* template <class T> dynlite<T>::activate

   Purpose: Register a class version as the current active version 

     Input:  actualName = actual name of the version library to be activated
		         (const char *) 

    Output: The procedure marks the class version as the current version.
*/

template<class T> void dynlite<T>::activateInternal (Boolean invalidate, const char *actualName) THROW5(NoTemporaryLibrary,NoDownload,NoVersionLibrary,InvalidVersion,NoCreateFunction)
{
    Boolean file; 
    const char *localName;
#ifdef ALLOW_DOWNLOADS
    char *temporaryPath;
    HeapPtr<char> temporaryName;
#endif
    VersionList::iterator i;

	/* assertions */

    assert (actualName != NULL);

	/* get the classname */

    const char *className = T::getClassName();

	/* lock for mutual exclusion -- automatically released */

    DEFINE_GUARD(guard,lock);

	/* allocate the version list if necessary */

    if (versionList == NULL) {
	versionList = new VersionList;
    }

	/* see if the new version already exists */

    DynamicVersion *ptr = NULL;
 
    for (i = versionList -> begin(); i != versionList -> end(); ++i) {
	if ((*i) -> isLibrary (actualName)) {
	    ptr = (*i);
	    break;
	}
    }

    if (ptr != NULL) {

	    /* invalidate all previous versions if we are invalidating; */
	    /* otherwise just unmark the current active version if it   */
	    /* is not the same as the new active version                */

	if (invalidate == e_TRUE) {

	    invalidateAll (actualName);
	
	} else if (ptr != activePtr) {

	    deactivateVersion (activePtr, e_FALSE);
	}

	    /* turn on the newly activated version */

	ptr -> active = e_TRUE;
	ptr -> force = e_FALSE;
	activePtr = ptr;
	return;
    }

	/* If we are allowing downloads, we might have to get the version */
	/* from the World Wide Web.  Otherwise the version always comes   */
	/* from the local filesystem.                                     */

#ifdef ALLOW_DOWNLOADS

    if (!strncmp (actualName, "http://", 7)) {

	if ((temporaryPath = getenv("TEMPORARY_LIBRARY")) == NULL) {
	    throw NoTemporaryLibrary ((char *) NULL);
	}

	if ((temporaryName = downloadVersion (actualName, temporaryPath)) == NULL) {
	    throw NoDownload (actualName);
	}

	file = e_FALSE;
        localName = temporaryName;

    } else {

	file = e_TRUE;
	localName = actualName;
    }

#else

    localName = actualName;
    file = e_TRUE;

#endif   /* ALLOW_DOWNLOADS */

	/* create the version information */

    DynamicVersion *dvPtr = new DynamicVersion (className, actualName, localName, file, e_TRUE);

	/* load the library */

    try {
	loadLibrary (dvPtr, T::getClassName ());
    } catch (Exception &except) {
	delete (dvPtr);
	throw;
    }

	/* invalidate all previous versions if we are invalidating; */
	/* otherwise just unmark the active version                 */

    if (invalidate == e_TRUE) {

	invalidateAll (NULL);

    } else if (activePtr != NULL) {

	deactivateVersion (activePtr, e_FALSE);
    }

	/* turn the new verrsion into the active version */

    versionList -> insert (versionList -> begin(), dvPtr);
    activePtr = dvPtr;
}

template<class T> void dynlite<T>::activate (const char *actualName) THROW5(NoTemporaryLibrary,NoDownload,NoVersionLibrary,InvalidVersion,NoCreateFunction)
{
    activateInternal (e_FALSE, actualName);
}

/* template <class T> dynlite<T>::activate_and_invalidate

   Purpose: Register a class version as the current active version *and*
	    invalidate all previous versions

     Input: actualName = actual name of the version library
		         (const char *) 

    Output: The procedure marks the class version as the active version
	    *and* invalidates all previous versions.
*/

template<class T> void dynlite<T>::invalidateAll (const char *actualName)
{
	/* assertions on the parameters */

    assert (actualName != NULL);

	/* invalidate all previous versions */

    VersionList::iterator i;

    for (i = versionList -> begin(); i != versionList -> end(); ++i) {
	if ((*i) -> isLibrary (actualName)) {
	    continue;
	} else {
	    deactivateVersion (*i, e_TRUE);
	}
    }
}

template<class T> void dynlite<T>::activate_and_invalidate (const char *actualName) THROW5(NoTemporaryLibrary,NoDownload,NoVersionLibrary,InvalidVersion,NoCreateFunction)
{
    activateInternal (e_TRUE, actualName);
}


/* ---------------------------- DEACTIVATION ---------------------------- */

template <class T> void dynlite<T>::deactivateVersion (DynamicVersion *ptr, Boolean force) 
{
    if (ptr -> refCount == 0) {
	eraseVersion (ptr);
    } else {
        ptr -> active = e_FALSE; 
	ptr -> force = force;
    }
}

/* template <class T> void dynlite<T>::invalidate

   Purpose: Turn off a version and disallow continued use of that version,
	    i.e., all further calls to operator -> will fail.

     Input: actualName = actual name of the version library
		         (const char *)

    Output: The procedure turns off the version and disallows continued use.
*/

template <class T> void dynlite<T>::invalidate (const char *actualName) THROW2(ActiveVersion,NonexistentVersion)
{
    VersionList::iterator i;

	/* assertions */

    assert (actualName != NULL);

	/* get the class name */

    const char *className = T::getClassName ();

	/* lock for mutual exclusion -- automatically released */

    DEFINE_GUARD(guard,lock);

	/* find the version and turn it off */

    DynamicVersion *ptr = NULL;

    if (versionList != NULL) {
        for (i = versionList -> begin(); i != versionList -> end(); ++i) {
	    if ((*i) -> isLibrary (actualName)) { 
	        ptr = (*i);
	        break;
	    }
        }
    }

    if (ptr != NULL) {

	if (ptr -> active) {
	    throw ActiveVersion();
	}

	deactivateVersion (ptr, e_TRUE);

    } else {

	throw NonexistentVersion (className, actualName);
    }
}

/* ---------------------- Informational routines ------------------------ */

/* template <class T> dynlite<T>::getVersionCount

   Purpose: Determine the current number of versions for a particular class

     Input: None

    Output: The procedure returns the current number of versions.
*/

template <class T> int dynlite<T>::getVersionCount (void)
{
    int size;

	/* lock for mutual exclusion -- automatically released */

    DEFINE_GUARD(guard,lock);

    if (versionList == NULL) {
	size = 0;
    } else {
        size = versionList -> size();
    }

    return (size);
}


/* -------------------------- "Smart" pointer --------------------------- */

/* template <class T> dynlite<T>::operator->

   Purpose: Get the pointer to the actual object

     Input: None

    Output: The procedure returns a pointer to the actual object.
*/

template <class T> T * dynlite<T>::operator-> (void) THROW1(ZombieVersion)
{
	/* see if object usage is allowed */ 

    if (dvPtr -> force) {
	throw ZombieVersion();
    }

    return (object);
}

#endif /* _DYNAMIC_H */
