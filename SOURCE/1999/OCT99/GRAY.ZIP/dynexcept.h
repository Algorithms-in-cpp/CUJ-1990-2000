/* Dynamic classes
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   dynexcept.h

   This file defines the exceptions associated with class "dynamic".
*/

#ifndef _DYN_EXCEPT_H
#define _DYN_EXCEPT_H

#include "exception.h"
#include "dynversion.h"

class NoDownload: public Exception
{
        char *URL;

    public:

	NoDownload (const char *URL);
	char *describeException (void);
       ~NoDownload ();
};
 
class ZombieVersion: public Exception
{
    public:

	char *describeException (void);
};

class InvalidHandle: public Exception
{
    public:

	char *describeException (void);
};

class ActiveVersion: public Exception
{
    public:

	char *describeException (void);
};

class NoActiveVersions: public Exception
{
    public:

	char *describeException (void);
}; 

class NoVersionLibrary: public Exception
{
	char *dirName;

    public:

        NoVersionLibrary (const char *dirName);
	char *describeException (void);
       ~NoVersionLibrary ();
};

class NoTemporaryLibrary: public Exception
{
	char *dirName;

    public:

        NoTemporaryLibrary (const char *dirName);
	char *describeException (void);
       ~NoTemporaryLibrary ();
};

class InvalidVersion: public Exception
{
	char *className;
	char *pathName;
	char *dlmessage;	  /* dynamic linker message */

    public:

	InvalidVersion 
	    (const char *className, const char * pathName, const char *dlmessage);

	char *describeException (void);

       ~InvalidVersion ();
};

class NonexistentVersion: public Exception
{
	char *className;
	char *versionName;

    public:

	NonexistentVersion (const char *className, const char * versionName);
	char *describeException (void);
       ~NonexistentVersion ();
};

class NoCreateFunction: public Exception
{
	char *className;
	char *funcName;
	char *fileName;

    public:

	NoCreateFunction
	    (const char *className, const char *funcName, const char *fileName);

	char *describeException
	    (void);

       ~NoCreateFunction
	    ();
};

class NoObject: public Exception
{
    public:

	char *describeException (void);
};

#endif /* _DYN_EXCEPT_H */
