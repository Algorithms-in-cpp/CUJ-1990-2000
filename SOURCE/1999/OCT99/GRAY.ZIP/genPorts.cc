/* Agent Tcl
   Bob Gray
   25 January 1995

   genPorts.cc 

   D.This file implements the structures REMOTE_PORT and MACHINE)

   Copyright (c) 1996, Robert S. Gray, AT&T Research
*/

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "genPorts.h"
#include "platPorting.h"
#include "genUtility.h"

/* MACHINE_ID::MACHINE_ID 
 
   Purpose: These procedures are the constructors for class MACHINE_ID.
*/

MACHINE_ID::MACHINE_ID (void)
{
    name = (char *) NULL;
    ip   = UNKNOWN_IP;
}

 
MACHINE_ID::MACHINE_ID (char *newName, UINT_32 newIP) 
{
    name = my_strcpy (newName);
    ip   = newIP;
}

MACHINE_ID::MACHINE_ID (const MACHINE_ID &machine)
{
    name = my_strcpy (machine.name);
    ip   = machine.ip; 
}

/* MACHINE_ID::update

   Purpose: Change the server name and IP address.
*/

void MACHINE_ID::update (char *newName, UINT_32 newIP)
{
    if (name != newName) {
	delete (name);
	name = my_strcpy (newName);
    }

    ip = newIP;
}

/* MACHINE_ID::operator=

   Purpose: Defines the assignment operator for class MACHINE_ID
*/

MACHINE_ID& MACHINE_ID::operator= (const MACHINE_ID &id)
{
    update (id.name, id.ip);
    return (*this);
}

/* MACHINE_ID::~MACHINE_ID

   Purpose: This procedure is the destructor for class MACHINE_ID.
*/

MACHINE_ID::~MACHINE_ID ()
{
    delete (name);
}
