/* Dynamic classes

   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   16 June 1996

   This file defines the generic base class.  Each dynamic class must inherit
   from a specialized base class that in turn inherits from this generic base
   class.
*/

#ifndef _BASE_H
#define _BASE_H

    /* the generic interface class */

class Base
{
    public:

	virtual Base *copyInstance (void) = 0;
	
	virtual void assignInstance (Base &dest) = 0;

	virtual ~Base () {};
};

    /* macros that help when defining the specific interface classes */

#define INTERFACE_NAME(N) \
    static const char *getInterfaceName (void) { \
	return N; \
    } 

#define CLASS_NAME(N) \
    static const char *getClassName (void) { \
	return N; \
    }

#endif /* _BASE_H */
