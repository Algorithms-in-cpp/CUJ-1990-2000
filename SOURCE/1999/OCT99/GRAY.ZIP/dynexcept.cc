/* Dynamic classes
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   dynexcept.cc

   This file implements the exceptions associated with class "dynamic".
*/

#include <stdio.h>
#include <stdlib.h>
#include "dynexcept.h"
#include "faststring.h"
#include "mystrings.h"

    /* exception descriptions */

static const char * const invalidHandleMessage =
    "invalid handle (InvalidHandle)";

static const char * const zombieVersionMessage = 
    "object's version is no longer valid (ZombieVersion)";

static const char * const activeVersionMessage =
    "can not invalidate the active version (ActiveVersion)";

static const char *const noActiveVersionsMessage =
    "no active versions are available (NoActiveVersions)";

static const char *const noVersionLibraryMessage =
    "environment variable \"VERSION_LIBRARY\" has not been set (NoVersionLibrary)";

static const char *const noObjectMessage =
    "unable to create actual object (NoObject)";

static const char *const noTemporaryLibraryMessage =
    "environment variable \"TEMPORARY_LIBRARY\" has not been set";
 
char * NoObject::describeException (void)
{
    return (my_strcpy (noObjectMessage));
} 

char * InvalidHandle::describeException (void)
{
    return (my_strcpy (invalidHandleMessage));
}

char * ZombieVersion::describeException (void)
{
    return (my_strcpy (zombieVersionMessage));
}

char * ActiveVersion::describeException (void) {
    return (my_strcpy (activeVersionMessage));
}

char * NoActiveVersions::describeException (void)
{
    return (my_strcpy (noActiveVersionsMessage));
}

NoDownload::NoDownload (const char * p_URL):
	URL (my_strcpy (p_URL))
{
    /* empty */
}

char *NoDownload::describeException (void)
{
    char *message = new char [fast_strlen(URL) + 128];
    sprintf (message, "unable to download \"%s\" (NoDownload)", URL);
    return (message);
}

NoDownload::~NoDownload ()
{
    delete (URL);
}

NoTemporaryLibrary::NoTemporaryLibrary (const char *p_dirName):
    dirName 	(my_strcpy (p_dirName))
{
    /* empty */
}

char * NoTemporaryLibrary::describeException (void)
{
    char *message;

	/* construct the message */

    if (dirName == NULL) {
	message = my_strcpy (noTemporaryLibraryMessage);
    } else {
	message = new char [fast_strlen(dirName) + 128];
	sprintf (message, "environment variable \"TEMPORARY_LIBRARY\" specifies an invalid directory \"%s\" (NoTemporaryLibrary)", dirName);
    }

    return (message); 
}

NoTemporaryLibrary::~NoTemporaryLibrary ()
{
    delete (dirName);
}

NoVersionLibrary::NoVersionLibrary (const char *p_dirName):
    dirName 	(my_strcpy (p_dirName))
{
    /* empty */
}
	
char * NoVersionLibrary::describeException (void)
{
    char *message;

	/* construct the message */

    if (dirName == NULL) {
	message = my_strcpy (noVersionLibraryMessage);
    } else {
	message = new char [fast_strlen(dirName) + 128];
	sprintf (message, "environment variable \"VERSION_LIBRARY\" specifies an invalid directory \"%s\" (NoVersionLibrary)", dirName);
    }

    return (message); 
}

NoVersionLibrary::~NoVersionLibrary ()
{
    delete (dirName);
}

NonexistentVersion::NonexistentVersion (const char *p_className, const char *p_versionName):
    className 	(my_strcpy (p_className)),
    versionName (my_strcpy (p_versionName))
{
    /* empty */
}

char *NonexistentVersion::describeException (void)
{
    char *message;

	/* construct the message */

    message = new char [fast_strlen(className) + fast_strlen(versionName) + 256];
    sprintf (message, "version \"%s\" of class \"%s\" is not currently loaded (NonExistentVersion)", versionName, className);
    return (message);
}

NonexistentVersion::~NonexistentVersion ()
{
    delete (className);
    delete (versionName);
}

InvalidVersion::InvalidVersion (const char *p_className, const char *p_pathName, const char *p_dlmessage):
    className 	(my_strcpy (p_className)),
    pathName    (my_strcpy (p_pathName)),
    dlmessage   (my_strcpy (p_dlmessage))
{
    /* empty */
}

char *InvalidVersion::describeException (void)
{
    char *message;

	/* construct the message */

    message = new char [fast_strlen(dlmessage) + fast_strlen(pathName) + fast_strlen(className) + 256];
    sprintf (message, "can not load library \"%s\" for class \"%s\": \"%s\" (InvalidVersion)", pathName, className, dlmessage);
    return (message);
}

InvalidVersion::~InvalidVersion ()
{
    delete (className);
    delete (pathName);
    delete (dlmessage);
}

NoCreateFunction::NoCreateFunction (const char *p_className, const char *p_funcName, const char *p_fileName):
    className	(my_strcpy (p_className)),
    funcName	(my_strcpy (p_funcName)),
    fileName	(my_strcpy (p_fileName))
{
    /* empty */
}

char *NoCreateFunction::describeException (void)
{
    int length;
    char *message;

	/* construct the message */

    length = fast_strlen(fileName) + 2 * fast_strlen(className) + 256;

    if (funcName != NULL) {
	length += fast_strlen(funcName);
    }

    message = new char [length];

    if (funcName == NULL) {
        sprintf (message, "unable to create an instance of \"%s\": can not find function \"%s::createInstance\" in \"%s\" (NoCreateFunction)", className, className, fileName);
    } else {
        sprintf (message, "unable to create an instance of \"%s\": can not find function \"%s::createInstance\" (%s) in \"%s\" (NoCreateFunction)", className, className, funcName, fileName);
    }

    return (message);
}

NoCreateFunction::~NoCreateFunction ()
{
    delete (className);
    delete (funcName);
    delete (fileName);
} 
