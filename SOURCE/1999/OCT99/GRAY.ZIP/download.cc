/* Dynamic classes
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   6 August 1996

   download.cc

   This file implements the function that downloads a version library from an 
   Apache web server. 
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "boolean.h"
#include "download.h"
#include "faststring.h"
#include "genTcpip.h"
#include "genTimers.h"
#include "manager.h"

    /* pattern for the temporary filenames */

const char *const tempPrefix = "tlibv";

    /* name and length of the "content-length" tag */

const char * const CONTENT_LENGTH_TAG = "content-length:";
const int CONTENT_LENGTH_TAG_SIZE = 15;

    /* name and length of the "filename" tag */

const char *const FILENAME_TAG = "filename:";
const int FILENAME_TAG_SIZE = 9; 

    /* header that indicates a successfully download */

const char * const OK_HEADER = "200 ok";

    /* wait no more than 5 seconds when contacting the local proxy server */

const struct timeval PROXY_DELAY = {5, 0};

    /* first part of the proxied HTTP request */

const char * const HttpHeader = "GET ";

    /* last part of the proxied HTTP request */

const char * const HttpTrailer = " HTTP/1.0\r\nAccept: */*\r\nUser-Agent: DynClass/1.0\r\n\r\n";

ParseResponse::ParseResponse (int p_sockfd)
{
    contentLength = -1;
    sockfd        = p_sockfd;
    bufpos        = 0;
    filename      = (char *) NULL;

    if ((bufcnt = tcpip_readn (sockfd, buffer, BUFFER_SIZE)) < 0) {
	pageStatus = e_FALSE;
    } else {
	pageStatus = e_TRUE;
    }
}

char *ParseResponse::getLine (void)
{
   register char *lp = line;

	/* read through the buffer */

    while (1) {

	    /* error or end of stream */ 

	if (pageStatus == e_FALSE) {
	    return ((char *) NULL);
	} 

	if (bufcnt == 0) {
	    *line = '\0';
	    return (line);
	}

	while (bufpos < bufcnt) {

	    *lp++ = buffer[bufpos];

	    if (buffer[bufpos++] == '\n') {
		*lp = '\0';
		return (line);
	    }
	} 

        bufpos = 0;

        if ((bufcnt = tcpip_readn (sockfd, buffer, BUFFER_SIZE)) < 0) {
	    pageStatus = e_FALSE;
	}
    }

	/* should never get here */

    assert (0);
    return ((char *) NULL);
}

int ParseResponse::parseHeader (void)
{ 
    int line = 0;
    register char *lp;
    register char *cp; 
    Boolean fileFound = e_FALSE;
    Boolean lengthFound = e_FALSE;

	/* read each line of the header in sequence */
 
    while (1) {

	if ((lp = getLine ()) == NULL) {
	    pageStatus = e_FALSE;
	    return -1;
	}

	if ((*lp == '\r') || (*lp == '\n') || (*lp == '\0')) {
	    return 0;
        }

	if (line == 0) {

	    for (cp = lp; *cp != '\0'; cp++) {
		*cp = fast_tolower (*cp);
	    }

	    if (strstr (lp, OK_HEADER) == NULL) {
		pageStatus = e_FALSE;
		return -1;
	    }

	} else if ((!fileFound) || (!lengthFound)) {

	    for (cp = lp; *cp != '\0'; cp++) {

		if (*cp == ':') {
		    break;
		}

		*cp = fast_tolower (*cp);
	    }

	    if (!strncmp(lp, CONTENT_LENGTH_TAG, CONTENT_LENGTH_TAG_SIZE)) {

		sscanf (lp + CONTENT_LENGTH_TAG_SIZE, "%d", &contentLength);

	    } else if (!strncmp(lp, FILENAME_TAG, FILENAME_TAG_SIZE)) {

		filename = my_strcpy (lp + FILENAME_TAG_SIZE + 1);
		contentLength = 0;

		for (cp = filename; *cp != '\r'; cp++) {
		    /* empty */
		}

		*cp = '\0';
	    }		
        }

	line += 1;
    }

	/* should never get here */

    assert (0);
    return -1;
}

void ParseResponse::waitForDisconnect (void)
{
   char c;
   (void) tcpip_readn (sockfd, &c, 1);  
}

int ParseResponse::copyBody (int fd)
{
    register int totalBytes = 0;

	/* write out anything left in the buffer */

    if (bufpos < bufcnt) {
	totalBytes += bufcnt - bufpos;
	tcpip_writen (fd, &buffer[bufpos], bufcnt - bufpos);
    }

	/* copy as fast as possible */

    while (1) {

	bufcnt = tcpip_readn (sockfd, buffer, BUFFER_SIZE);

	if (bufcnt < 0) {

	    pageStatus = e_FALSE;
	    return (bufcnt);

	} else if (bufcnt == 0) {

	    if (totalBytes != contentLength) {
		pageStatus = e_FALSE;
		return -1;
	    } else {
		return 0;
	    }
	}

	totalBytes += bufcnt;
	tcpip_writen (fd, buffer, bufcnt);
    }
}

/* downloadVersion

   Purpose: Download a dynamic library from an Apache web server

     Input: URL     = full URL of the desired library
		      (const char *)
	
	    tempDir = directory for temporary libraries
		      (const char *) 

    Output: The procedure returns NULL on error.  Otherwise the procedure
	    returns a pointer to a dynamically allocated string that
	    contains the full pathname of the tempoary library.
*/

char *downloadVersion (const char *URL, const char *tempDir)
{
    int fd;
    char *dp;
    int sockfd;
    struct timeval stop;
    HeapPtr<char> temporaryPrefix;
    HeapPtr<char> temporaryName;

	/* assertions on the parameters */

    assert (URL != NULL);
    assert (tempDir != NULL);

	/* create the socket */ 

    if ((sockfd = tcpip_socket ()) < 0) {
	return ((char *) NULL);
    }

	/* connect to the proxy server -- first construct the time out */

    stop = TIMERS::addTimevals (TIMERS::getCurrentWall(), PROXY_DELAY);

	/* then construct the remote port */

    REMOTE_PORT port ((char *) NULL, tcpip_getLocalhost(), PROXY_PORT);

	/* then perform the actual connection */

    if (tcpip_connect (sockfd, port, stop) < 0) {
	close (sockfd);
	return ((char *) NULL);
    }

	/* construct the HTTP request */

    int httpRequestLength = strlen(HttpHeader) + strlen(URL) + strlen(HttpTrailer) + 1;
    char *httpRequest = new char [httpRequestLength];
    strcpy (httpRequest, HttpHeader);
    strcat (httpRequest, URL);
    strcat (httpRequest, HttpTrailer);

	/* send the request */

    if (tcpip_writen (sockfd, httpRequest, httpRequestLength) < 0) {
	close (sockfd);
	return ((char *) NULL);
    }

	/* read the response -- should have a timeout */

    ParseResponse parser (sockfd);

    if (parser.parseHeader() < 0) {
	close (sockfd);
	return ((char *) NULL);
    }

	/* done if we have a local file */

    if ((dp = parser.getLocalFile()) != NULL) {
	parser.waitForDisconnect ();
	close (sockfd);
	return (dp);
    }

	/* otherwise we need a temporary file -- get the first piece */

    if ((temporaryPrefix = tempnam (tempDir, tempPrefix)) == NULL) {
	close (sockfd);
	return ((char *) NULL);
    }

	/* create a dummy file */

    fd = open (temporaryPrefix, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    close (fd);

	/* finish off the filename */

     temporaryName = new char[fast_strlen(temporaryPrefix) + 4];
     dp = fast_strcpy (temporaryName, temporaryPrefix);
     dp = fast_strcpy (dp, ".so");

	/* open the file */

    if ((fd = open (temporaryName, O_WRONLY | O_CREAT | O_TRUNC, 0600)) < 0) {
	unlink (temporaryPrefix);
	close (sockfd);
	return ((char *) NULL);
    }

    if (parser.copyBody (fd) < 0) {
	unlink (temporaryName);
	unlink (temporaryPrefix);
	close (fd);
	close (sockfd);
	return ((char *) NULL);
    }

	/* success */

    close (sockfd);
    close (fd);
    return (temporaryName.relinquishOwnership());
}

Boolean postData (const char *URL)
{
    int sockfd;
    struct timeval stop;

	/* assertions on the parameters */

    assert (URL != NULL);

	/* create the socket */ 

    if ((sockfd = tcpip_socket ()) < 0) {
	return e_FALSE;
    }

	/* connect to the proxy server -- first construct the time out */

    stop = TIMERS::addTimevals (TIMERS::getCurrentWall(), PROXY_DELAY);

	/* then construct the remote port */

    REMOTE_PORT port ((char *) NULL, tcpip_getLocalhost(), PROXY_PORT);

	/* then perform the actual connection */

    if (tcpip_connect (sockfd, port, stop) < 0) {
	close (sockfd);
	return e_FALSE;
    }

	/* construct the HTTP request */

    int httpRequestLength = strlen(HttpHeader) + strlen(URL) + strlen(HttpTrailer) + 1;
    char *httpRequest = new char [httpRequestLength];
    strcpy (httpRequest, HttpHeader);
    strcat (httpRequest, URL);
    strcat (httpRequest, HttpTrailer);

	/* send the request */

    if (tcpip_writen (sockfd, httpRequest, httpRequestLength) < 0) {
	close (sockfd);
	return e_FALSE;
    }

	/* read the response -- should have a timeout */

    ParseResponse parser (sockfd);

    if (parser.parseHeader() < 0) {
	close (sockfd);
	return e_FALSE;
    }

	/* success */

    close (sockfd);
    return e_TRUE;
}
