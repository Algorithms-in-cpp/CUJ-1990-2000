/* Dynamic classes
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   3 July 1996

   lock.h

   This file defines the classes that provide mututal exclusion (using Posix
   threads).
*/

#ifndef _LOCK_H
#define _LOCK_H

#ifdef USE_THREADS
#ifdef USE_PTHREADS
#include "pthread.h"
#elif defined(_WIN32)
// do nothing for now 
#else
#include "platSigStack.h"
#endif
#endif

#include <assert.h>
#include <stdio.h>
#include "boolean.h"
#include "lockexcept.h"



#ifdef USE_THREADS
#ifdef USE_PTHREADS

class MutexLock
{
	    /* stack of signal masks */

	pthread_mutex_t mutex;
	pthread_mutexattr_t attribs; 

    public:

	    /* constructor */

	MutexLock (void) { 
	    pthread_mutexattr_init (&attribs);
	    pthread_mutexattr_settype (&attribs, PTHREAD_MUTEXTYPE_RECURSIVE);
	    pthread_mutex_init (&mutex, &attribs);
	}

	    /* acquire (blocking), acquire (non-blocking) and release */

	void acquire (void) throw(LockSystemError) {
	    if (pthread_mutex_lock (&mutex)) {
		throw LockSystemError();
	    } 
	}
    
	Boolean try_acquire (void) {
	    return (pthread_mutex_trylock (&mutex) ? e_FALSE : e_TRUE);
	}

	void release (void) throw(LockNotHolding) {
	    if (pthread_mutex_unlock (&mutex)) {
		throw LockNotHolding();
	    }
	}

	    /* destructor */

       ~MutexLock () {
	    pthread_mutex_destroy (&mutex);
	    pthread_mutexattr_destroy (&attribs);
	}
};

#elif defined(USE_SIGNALS)

class MutexLock
{
	    /* stack of signal masks */

	SIGNAL_STACK stack;

    public:

	Boolean acquire (void) {

	    sigset_t oldMask;
	    sigset_t newMask;

		/* block the signals */

	    sigemptyset (&oldMask);
	    sigemptyset (&newMask);
	    sigaddset (&newMask, SIGIO);
	    sigaddset (&newMask, SIGALRM);
	    sigaddset (&newMask, SIGPROF);
	    sigprocmask (SIG_BLOCK, &newMask, &oldMask);
	    stack.push (oldMask);

	 	/* success */ 

	    return (e_TRUE);
	}
    
	Boolean release (void) {

	    sigset_t oldMask;

		/* unblock the signals */

	    oldMask = stack.pop ();
	    sigprocmask (SIG_SETMASK, &oldMask, NULL);

		/* success */

	    return (e_TRUE);
	}
};

#else

class MutexLock
{
    public:

	Boolean acquire (void) {
	    return (e_TRUE);
	}

	Boolean release (void) {
	    return (e_TRUE);
	}
};

#endif  /* USE_PTHREADS */
#else   /* USE_THREADS  */

class MutexLock
{
    public:

	Boolean acquire (void) {
	    return (e_TRUE);
	}

	Boolean release (void) {
	    return (e_TRUE);
	}
};

#endif   /* USE_THREADS */



    /* This is a guard that ensures that an acquired MutexLock is released */

class MutexGuard
{
	MutexLock *lock;

    public:

	MutexGuard (void):
	    lock ((MutexLock *) NULL)
	{
	    // empty
	}
	   
	MutexGuard (MutexLock &p_lock) throw(LockSystemError):
	    lock (&p_lock)
	{
	    lock->acquire ();
	}

       ~MutexGuard () throw(LockNotHolding) {
	    if (lock != NULL) {
		lock->release ();
	    }
	}

	MutexGuard &operator= (MutexLock &p_lock) throw(LockSystemError) {
	    assert (lock == NULL);
	    lock = &p_lock;
	    lock->acquire();
	    return (*this);
	}
};



    /* macro to create a guard */

#ifdef USE_THREADS
#define DEFINE_GUARD(x,y) MutexGuard x (y)
#else
#define DEFINE_GUARD(x,y) {}
#endif

#endif 
