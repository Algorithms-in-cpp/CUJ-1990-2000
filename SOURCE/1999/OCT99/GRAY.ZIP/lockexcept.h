/* Dynamic classes
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   lockexcept.h

   This file defines the exceptions associated with class "MutexLock"
*/

#ifndef _LOCK_EXCEPT_H
#define _LOCK_EXCEPT_H

#include "exception.h"

class LockSystemError: public Exception
{
    public:

	char *describeException (void);
};

class LockNotHolding: public Exception
{
    public:

	char *describeException (void);
}; 

#endif /* _LOCK_EXCEPT_H */
