/* Agent Tcl
   Bob Gray
   5 April 1995

   genHash.cc

   This file implements a hash table that maps a string to an integer handle.

   Copyright (c) 1995-1997, Robert S. Gray Dartmouth College

   See the file "agent.terms" for information on usage and redistribution
   of this file and for a DISCLAIMER OF ALL WARRANTIES.
*/

#pragma implementation

#include <string.h>
#include "genHash.h"
#include "mystrings.h"

// default number of buckets in the hash table -- this must be a power of 2!

const int DEFAULT_BUCKETS = 32;

/* HashNode::HashNode

   Purpose: This procedure is the constructor for class HashNode.

     Input: key	   = the string key
           	     (const char *)

	    handle = the handle
		     (int)
 
	    next   = next node in the hash table bucket
		     (HashNode *)
*/

HashNode::HashNode (const char *key, int handle, HashNode *next)
{
    m_key    = my_strcpy (key);
    m_handle = handle;
    m_next   = next;
}

/* HashNode::~HashNode

   Purpose: This procedure is the destructor for class HashNode.
*/

HashNode::~HashNode ()
{
    delete (m_key);
} 

/* Hash::Hash

   Purpose: This procedure is the constructor for class HASH.

     Input: buckets = number of buckets in the hash table

            buckets must be a power of two since the hash function is
            just a bit-wise AND.
*/

Hash::Hash (void)
{
	/* initialize */

    Hash::max_index = DEFAULT_BUCKETS - 1;
    Hash::entries   = 0;
    Hash::table     = new HashNode * [DEFAULT_BUCKETS];

    for (unsigned i = 0; i <= max_index; i++) {
	table[i] = (HashNode *) NULL;
    }
}

/* Hash::empty

   Purpose: This procedure empties out the hash table.

     Input: None

    Output: The procedure empties out the hash table.
*/

void Hash::empty (void)
{
    register HashNode *current;
    register HashNode *next;

	/* delete the table entries */

    for (unsigned i = 0; i <= max_index; i++) {

	for (current = table[i]; current != NULL; current = next) {
	    next = current -> m_next;
	    delete (current);
        } 

	table[i] = NULL;
    }
}

/* Hash::~Hash

   Purpose: This procedure is the destructor for class HASH.
*/

Hash::~Hash ()
{
    empty ();
    delete (table);
}

/* Hash::add

   Purpose; Add an entry to the hash table

     Input: key     = the string key
                      (const char *)

            handle  = the handle
                      (int)

    Output: If the key is already in the hash table, the procedure *replaces*
            the handle associated with that key.  If the key is not already
            in the hash table, the procedure adds a new entey to the hash
            table.
*/

long Hash::hash (const char *key)
{
    long value;
    register const char *sp = key;

    for (value = 0; *sp != '\0'; sp++) {
	value = (value << 3) + value + *sp;
    }   

    return value & max_index;
}

void Hash::add (const char *key, int handle)
{
    HashNode *current;

	/* check if the entry is in the table */

    long index = hash (key);

    for (current = table[index]; current != NULL; current = current -> m_next) {
        if (!strcmp (current -> m_key, key)) {
	    current -> m_handle = handle;
	    return;
	}
    }

	/* add a new entry to the table */

    table[index] = new HashNode (key, handle, table[index]);
    entries     += 1;
}

/* Hash::lookup

   Purpose: Lookup an entry in the hash table

     Input: key = the string key
                  (const char *) 
 
    Output: The procedure returns -1 if there is no entry with the given
            key.  Otherwise the procedure returns 0 and sets handle to the
            associated handle. 
*/

int Hash::lookup (const char *key, int& handle)
{
    register HashNode *current;

	/* check if the entry is in the table */

    long index = hash(key);

    for (current = table[index]; current != NULL; current = current -> m_next) {
        if (!strcmp (current -> m_key, key)) {
	    handle = current -> m_handle;
	    return 0;
	}
    }

    return -1;
}

/* Hash::remove

   Purpose: Remove an entry in the hash table

     Input: key = the string key
                  (const char *) 
 
    Output: The procedure returns -1 if the entry is not in the hash
            table.  Otherwise the procedure removes the entry and returns 0.
*/

int Hash::remove (const char *key)
{
    register HashNode *current;
    register HashNode *previous;

       /* check if the entry is in the table */

    long index = hash (key);

    for (previous = NULL, current = table[index]; current != NULL; previous = current, current = current -> m_next) {
        if (!strcmp(current -> m_key, key)) {
            if (previous == NULL) {
		table[index] = current -> m_next;
	    } else {
		previous -> m_next = current -> m_next;
	    }

	    delete (current);
	    entries -= 1;
	    return 0; 
	}
    }

    return -1; 
} 
