/* Dynamic classes
  
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730), AT&T 
   600 Mountain Avenue
   Murray Hill, New Jersey

   4 June 1996

   exception.h

   This file defines class "exception" which is the root of the exception
   hieararchy.  
*/

#ifndef _EXCEPTION_H
#define _EXCEPTION_H

class Exception
{
    public:

	virtual char *describeException (void) = 0;
};

#endif /* _EXCEPTION_H */
