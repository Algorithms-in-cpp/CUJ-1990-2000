/* Dynamic classes

   Bob Gray and Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   20 March 1997

   load.h

   This file implements the routine that loads a library from either the disk
   or across the network.
*/

#include "dynexcept.h"
#include "dynversion.h"
#include "faststring.h"
#include "load.h"
#include "manager.h"

#ifdef _WIN_32

void unloadLibrary (DynamicVersion *dvPtr)
{
    if (dvPtr -> dlloaded) {
	reeLibrary (dvPtr ->  dlhandle);
    }
}

void loadLibrary (DynamicVersion *dvPtr, const char *className) 
{
    int len;
    char *dp;
    char nbuffer[16];
    HeapPtr<char> fullname;
    HeapPtr<char> funcName;

	/* get the version name */

    HeapPtr<char> pathName (dvPtr -> names.getLocalLocation());

	/* construct the full version name */

    if ((dvPtr -> file) && (*pathName != '\\')) {

	    /* get the library directory */ 

	char *libraryName = getenv ("VERSION_LIBRARY");

	if (libraryName == NULL) {
	    throw NoVersionLibrary ((char *) NULL);
	}

	    /* construct the full pathname of the library */

	len = fast_strlen(libraryName) + fast_strlen(pathName) + 2;
	fullname = new char[len];
	dp = fast_strcpy (fullname, libraryName);
	dp = fast_strcpy (dp, "\\");
	dp = fast_strcpy (dp, pathName);

    } else {

	    /* construct the full pathname of the library */

	len = fast_strlen(pathName) + 1;
	fullname = new char[len];
	dp = fast_strcpy (fullname, pathName);
    }

	/* load the dynamic link library */ 

    dvPtr -> dlhandle = LoadLibrary (fullname);
	
    if (dvPtr -> dlhandle == (void *) NULL) {
	throw InvalidVersion (className, fullname, GetLastError());
    }

    dvPtr -> dlloaded = e_TRUE;

	/* construct the function name */ 

    len = fast_strlen(className);
    fast_atoi (len, nbuffer);
    len += 132;

    funcName = new char[len];
    dp = fast_strcpy (funcName, "?createInstance@");
    dp = fast_strcpy (dp, className);
    dp = fast_strcpy (dp, "@@SAPAV");
    dp = fast_strcpy (dp, "Base");  // Parent class ???
    dp = fast_strcpy (dp, "@@XZ");

	/* look for the create function */

    dvPtr -> funcPtr = (void * (*) (void)) GetProcAddress( dvPtr->dlhandle, funcName );

    if (dvPtr -> funcPtr == NULL) {
	unloadLibrary (dvPtr);
	throw NoCreateFunction (className, funcName, fullname);
    }
}

#else

#include <dlfcn.h>

void unloadLibrary (DynamicVersion *dvPtr)
{
    if (dvPtr -> dlloaded) {
	dlclose (dvPtr -> dlhandle);
    }
}

void loadLibrary (DynamicVersion *dvPtr, const char *className) throw (NoVersionLibrary, InvalidVersion, NoCreateFunction)
{
    int len;
    char *dp;
    char nbuffer[16];
    HeapPtr<char> fullname;
    HeapPtr<char> funcName;

	/* get the version name */

    HeapPtr<char> pathName (dvPtr -> names.getLocalLocation());

	/* construct the full version name */

    if ((dvPtr -> file) && (*pathName != '/')) {

	    /* get the library directory */ 

	char *libraryName = getenv ("VERSION_LIBRARY");

	if (libraryName == NULL) {
	     throw NoVersionLibrary ((char *) NULL);
	}

	    /* construct the full pathname of the library */

	len = fast_strlen(libraryName) + fast_strlen(pathName) + 2;
	fullname = new char[len];
	dp = fast_strcpy (fullname, libraryName);
	dp = fast_strcpy (dp, "/");
	dp = fast_strcpy (dp, pathName);

    } else {

	    /* construct the full pathname of the library */

	len = fast_strlen(pathName) + 1;
	fullname = new char[len];
	dp = fast_strcpy (fullname, pathName);
    }

	/* load the dynamic link library */ 

    dvPtr -> dlhandle = dlopen (fullname, RTLD_NOW);
	
    if (dvPtr -> dlhandle == (void *) NULL) {
        throw InvalidVersion (className, fullname, dlerror());
    }

    dvPtr -> dlloaded = e_TRUE;

	/* construct the function name */ 

    len = fast_strlen(className);
    fast_atoi (len, nbuffer);
    len += 32;

    funcName = new char[len];
    dp = fast_strcpy (funcName, "createInstance__");
    dp = fast_strcpy (dp, nbuffer);
    dp = fast_strcpy (dp, className);
#ifndef GCC_LINKING
    dp = fast_strcpy (dp, "SFv");
#endif

	/* look for the creation function */
	
    dvPtr -> funcPtr = (void * (*) (void)) dlsym (dvPtr -> dlhandle, funcName);

    if (dvPtr -> funcPtr == NULL) {
	unloadLibrary (dvPtr);
	throw NoCreateFunction (className, funcName, fullname);
    }
}

#endif
