/* Dynamic classes
   Bob Gray
   Gisli Hjalmtysson
   Network Mathematics Research Department (AK0112730)
   AT&T
   600 Mountain Avenue
   Murray Hill, New Jersey

   6 August 1996

   download.h

   This file defines the function that downloads a version library from an 
   Apache web server. 
*/

#ifndef _DOWNLOAD_H
#define _DOWNLOAD_H

#include "boolean.h"
#include "mystrings.h"

    /* buffer size */

const int BUFFER_SIZE = 2048;

    /* parse the HTTP header */

class ParseResponse 
{
    Boolean pageStatus;
    int contentLength;
    char *filename;
    int sockfd;
    int bufpos;
    int bufcnt;
    char line[BUFFER_SIZE];
    char buffer[BUFFER_SIZE];

	/* read a line of the header */

    char *getLine (void);

public:

	/* constructor */

    ParseResponse (int sockfd);

	/* parse the header */

    int parseHeader (void);

	/* wait for the server to disconnect */

    void waitForDisconnect (void);

	/* copy out the body */

    int copyBody (int fd);

	/* get the name of a local file */ 

    char *getLocalFile (void) {
	return (my_strcpy (filename));
    }

	/* check the page status */

    Boolean getPageStatus (void) {
	return (pageStatus);
    };
};

    /* down a library from an Apache web server */

char *downloadVersion (const char *URL, const char *tempDir);

    /* POST to a cgi script */

Boolean postData (const char *URL);

#endif /* _DOWNLOAD_H */
