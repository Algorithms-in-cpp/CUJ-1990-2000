// This file is only for Windows
#ifndef _DOWNLOAD_H
#define _DOWNLOAD_H

char *downloadVersion (const char *URL, const char *tempDir);

#endif /* _DOWNLOAD_H */
