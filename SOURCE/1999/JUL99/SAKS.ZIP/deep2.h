// deep.h

#ifndef DEEP_H_INCLUDED
#define DEEP_H_INCLUDED

template <typename T>
class deep_pointer
    {
public:
    deep_pointer();
    deep_pointer(T *p);
    deep_pointer &operator=(T *p);
    operator T *&();
    operator T const *const &() const;
    T *operator->();
    T const *operator->() const;
private:
    T *actual_pointer;
    };

template <typename T>
inline
deep_pointer<T> &deep_pointer<T>::operator=(T *p)
    {
    actual_pointer = p;
    return *this;
    }

// and all other inline member functions as
// in Listing 1

#endif
