// listing 3
// CopyFile.cpp 
#include <windows.h> 
#include <fstream.h>
#include "logevent.h"
#include "msg.h"

static const char *pszAppName = "CopyFile";

BOOL CopyFileAndLog(LPSTR pszSource,LPSTR pszTarget,BOOL bLogErrorsOnly)
{
if (!bLogErrorsOnly) 
   LogEvent(pszAppName,APP_I_STARTED_COPY,"ss",pszSource,pszTarget);

BOOL bReturn; 
if (!(bReturn=CopyFile(pszSource,pszTarget,FALSE)))
   LogEvent(pszAppName,APP_E_COPY_FAILED,"ssdm",pszSource,pszTarget,
            GetLastError(),GetLastError());
else 
if (!bLogErrorsOnly) 
   LogEvent(pszAppName,APP_I_COMPLETED_COPY,"ss",pszSource,pszTarget);


return bReturn; 
}

void main(int argc,char *argv[]) 
{
if (argc != 3) 
   {     /*-- DISPLAY THE ONLINE HELP --*/
   LogEvent(pszAppName,APP_W_INVALID_ARGUMENTS);
   LPSTR pszHelpText; 
   DWORD rc; 
   rc = FormatMessage(
              FORMAT_MESSAGE_ALLOCATE_BUFFER |
              FORMAT_MESSAGE_IGNORE_INSERTS |
              FORMAT_MESSAGE_FROM_HMODULE, 
              NULL,
              APP_I_HELP,
              MAKELANGID(LANG_NEUTRAL,SUBLANG_DEFAULT),
              (LPSTR)&pszHelpText,0,NULL);
   if (rc > 0) 
      {
      cout << pszHelpText; 
      LocalFree(pszHelpText);
      }
   else 
      {
      cerr << "Help text is not available. Error " << GetLastError() 
           << " occurred." << endl;
      }
   exit(1);
   }
if (!CopyFileAndLog(argv[1],argv[2],FALSE))
   {
   exit(1);
   }
exit(0);
}
