 // listing 1 - msg.mc
//
//  Values are 32 bit values layed out as follows:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|     Facility          |               Code            |
//  +---+-+-+-----------------------+-------------------------------+
//
//  where
//
//      Sev - is the severity code
//
//          00 - Success
//          01 - Informational
//          10 - Warning
//          11 - Error
//
//      C - is the Customer code flag
//
//      R - is a reserved bit
//
//      Facility - is the facility code
//
//      Code - is the facility's status code
//
//
// Define the facility codes
//


//
// Define the severity codes
//


//
// MessageId: APP_W_INVALID_ARGUMENTS
//
// MessageText:
//
//  The program was started with invalid command line arguments. 
//
#define APP_W_INVALID_ARGUMENTS          0x80000001L

//
// MessageId: APP_I_STARTED_COPY
//
// MessageText:
//
//  Copy of file %1 to %2 has started. 
//
#define APP_I_STARTED_COPY               0x40000002L

//
// MessageId: APP_I_COMPLETED_COPY
//
// MessageText:
//
//  Copy of file %1 to %2 was completed. 
//
#define APP_I_COMPLETED_COPY             0x40000003L

//
// MessageId: APP_E_COPY_FAILED
//
// MessageText:
//
//  Copy of file %1 to %2 failed with error %3. %4
//
#define APP_E_COPY_FAILED                0xC0000004L

//
// MessageId: APP_I_HELP
//
// MessageText:
//
//  The use is CopyFile <source> <dest>.
//
#define APP_I_HELP                       0x40000064L

