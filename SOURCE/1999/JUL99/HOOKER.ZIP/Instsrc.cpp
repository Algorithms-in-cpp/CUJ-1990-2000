// listing 2 
#include <windows.h> 
#include <fstream.h>

LONG InstallEventLogSource(LPCSTR pszEvSrc,LPCSTR pszPath)
{
LONG lResult = 0;
DWORD dwDisposition;
HKEY hKey;

/*--- CREATE THE REGISTRY KEY --*/
char szRegKey[300];
strcpy(szRegKey,"System\\CurrentControlSet\\Services\\EventLog\\Application");
strcat(szRegKey,"\\");
strcat(szRegKey,pszEvSrc);
lResult = RegCreateKeyEx(HKEY_LOCAL_MACHINE,szRegKey,0,
                         "",
                         REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,
                         &hKey,&dwDisposition);
if (lResult == 0)
   {    /*-- SET EventMessageFile AND TypesSupported REGISTRY KEYS ---*/
   DWORD dwEventTypes = EVENTLOG_ERROR_TYPE | EVENTLOG_WARNING_TYPE |
                        EVENTLOG_INFORMATION_TYPE;
   lResult = RegSetValueEx(hKey,"EventMessageFile",0,
                           REG_EXPAND_SZ,
                           (UCHAR*)pszPath,strlen(pszPath)+1);
   if (lResult == 0)
      {
      lResult = RegSetValueEx(hKey,"TypesSupported",0,
                   REG_DWORD,(LPBYTE)&dwEventTypes,sizeof(DWORD));
      }

   RegCloseKey(hKey);
   }

done:
return lResult;
}


void main(int argc,char *argv[])
{
if (argc != 3) 
   {
   cout << "Specify <event log source> <binary path name>" << endl;
   exit(1);
   }

LONG rc; 
rc = InstallEventLogSource(argv[1],argv[2]);
if (rc != NOERROR) 
   {
   cerr << "Error " << rc << " writing to the registry occurred." << endl;
   exit(1);
   }
exit(0);
}
