DWORD LogEvent(LPCSTR pszAppName,DWORD dwEvent,LPCSTR pszFormat=NULL,...);
LONG InstallEventLogSource(LPCSTR pszEvSrc,LPCSTR pszPath);

