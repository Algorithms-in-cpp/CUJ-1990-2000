// EmployeeTest4.java
class Employee {
    private String last;
    private String first;
    private String title;
    private int age;
    
    static int count = 0;

    // Shared construtor:
    {
        ++count;
    }
    public Employee() {}
    public Employee(String last, String first,
                    String title, int age)
    {
        this.last = last;
        this.first = first;
        this.title = title;
        this.age = age;
    }
    public void release() {
        --count;
    }
    // not shown: get/set functions for members last, first, 
    // title, and age; and toString() -- same as before
    // ...

    public static int getCount() {
        return count;
    }
}

public class EmployeeTest4 {
    public static void main(String[] args)
    {
        Employee e0 = new Employee();
        Employee e = 
            new Employee("Malone", "Karl", "Forward", 36);
        System.out.println(e);
        System.out.println("Employee.count == " + 
            Employee.getCount());
        e0.release();
        System.out.println("Employee.count == " + 
            Employee.getCount());
        e.release();
        System.out.println("Employee.count == " + 
            Employee.getCount());
    }
}

/* Output:
{Malone,Karl,Forward,36}
Employee.count == 2
Employee.count == 1
Employee.count == 0
*/

