// EmployeeTest1.java: Uses a class like a C-struct
class Employee
{
    // Fields:
    public String last;
    public String first;
    public String title;
    public int age;
}

public class EmployeeTest1 {
    public static void processEmployee(Employee e) {
        System.out.println("{" + e.last + "," + e.first +
                           "," + e.title + "," + e.age + "}");
    }

    public static void main(String[] args)
    {
        Employee e = new Employee();
        e.last = "Malone";
        e.first = "Karl";
        e.title = "Forward";
        e.age = 36;
        processEmployee(e);
    }
}

/* Output:
{Malone,Karl,Forward,36}
*/
