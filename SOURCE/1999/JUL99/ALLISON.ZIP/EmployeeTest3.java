// EmployeeTest3.java
class Employee
{
    // Fields:
    private String last;
    private String first;
    private String title;
    private int age;
    
    // Methods:
    public Employee() {}
    public Employee(String last, String first,
                    String title, int age)
    {
        this.last = last;
        this.first = first;
        this.title = title;
        this.age = age;
    }
    // not shown: get/set functions for members last, first, 
    // title, and age; and toString() -- same as before
    // ...
}

public class EmployeeTest3 {
    public static void main(String[] args)
    {
        Employee e0 = new Employee();
        System.out.println(e0);
        Employee e = 
            new Employee("Malone", "Karl", "Forward", 36);
        System.out.println(e);
    }
}

/* Output:
{null,null,null,0}
{Malone,Karl,Forward,36}
*/

