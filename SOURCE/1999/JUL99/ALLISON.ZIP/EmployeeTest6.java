// EmployeeTest6.java
class Employee {
    private String last;
    private String first;
    private String title;
    private int age;
    private Department dept;

    public Employee() {}
    public Employee(String last, String first,
                    String title, int age)
    {
        this.last = last;
        this.first = first;
        this.title = title;
        this.age = age;
    }
    // not shown: get/set functions for members last, first, 
    // title, and age; and toString() -- same as before
    // ...

    public Department getDepartment() {
        return dept;
    }
    public void setDepartment(Department dept) {
        this.dept = dept;
    }
    public String toString() {
        return "{" + last + "," + first + 
               "," + title+ "," + age + "}";
    }
}

class Department {
    private String name;
    private Employee mgr;

    public Department(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public Employee getManager() {
        return mgr;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setManager(Employee mgr) {
        this.mgr = mgr;
    }
    public String toString() {
        return name;
    }
}

public class EmployeeTest6 {
    public static void main(String[] args)
    {
        // Create Objects
        Employee e = 
            new Employee("Malone", "Karl", "Forward", 36);
        Employee mgr = 
            new Employee("Sloan", "Larry", "Coach", 52);
        Department dept = new Department("Utah Jazz");

        // Establish Relationships
        dept.setManager(mgr);
        e.setDepartment(dept);
        mgr.setDepartment(dept);

        // Print Karl's Department and manager:
        Department d = e.getDepartment();
        System.out.println("Karl's department: " + d);
        Employee m = d.getManager();
        System.out.println("Karl's manager: " + m);
    }
}

/* Output:
Karl's department: Utah Jazz
Karl's manager: {Sloan,Larry,Coach,52}
*/

