// EmployeeTest2.java
class Employee
{
    // Fields:
    private String last;
    private String first;
    private String title;
    private int age;
    
    // Methods:
    public String getLast()
    {
        return last;
    }
    public String getFirst()
    {
        return first;
    }
    public String getTitle()
    {
        return title;
    }
    public int getAge()
    {
        return age;
    }
    public void setLast(String last)
    {
        this.last = last;
    }
    public void setFirst(String first)
    {
        this.first = first;
    }
    public void setTitle(String title)
    {
        this.title = title;
    }
    public void setAge(int age)
    {
        this.age = age;
    }
    public String toString()
    {
        return "{" + last + "," + first +
               "," + title+ "," + age + "}";
    }
}

public class EmployeeTest2 {
    public static void main(String[] args)
    {
        Employee e = new Employee();
        e.setLast("Malone");
        e.setFirst("Karl");
        e.setTitle("Forward");
        e.setAge(36);
        System.out.println(e);
    }
}

/* Output:
{Malone,Karl,Forward,36}
*/

