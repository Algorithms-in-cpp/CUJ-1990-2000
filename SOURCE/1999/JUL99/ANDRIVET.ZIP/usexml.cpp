// Get the name of the first town

#include "..\..\XmlReader.h"
using namespace SimpleXMLParser;

char* OpenXmlFile(char* szFileName, long& nSize)
{
    ...
}

void main()
{
    // Get the content of the XML file
    long nSize = 0;
    char* pBuffer = OpenXmlFile("sample.xml", nSize);
    if(pBuffer == 0)
        return(false);

    try
    {
        // Parse the XML document
        Parser parser;
        const Element& root = parser.Parse(pBuffer, nSize);
      
        // Get the name of the first (index 0) town
        string strName = root("town", 0)("name").GetValue();
        cout << "Name of the first town: " 
             << strName << endl;
    }
    catch(Exception e)
    {
        cout << "Parsing error at line " 
             << e.GetLine() << endl;
    }

    // Delete the buffer
    delete[] pBuffer;
    return(1);
}
