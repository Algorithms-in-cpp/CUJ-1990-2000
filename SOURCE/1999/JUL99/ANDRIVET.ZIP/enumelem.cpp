#include "..\..\XmlReader.h"
using namespace SimpleXMLParser;
     
char* OpenXmlFile(char* szFileName, long& nSize) 
{
    ...
}
     
void ShowElemAndChilds(const Element& elem, int nIndent = 0) 
// ---------------------------------------------
// Enumerate childs of elem, recursivly and 
// display their name (with identation)
//
// elem:    [in] element to display
// nIndent: [in] number of identation
// --------------------------------------------- 
{
    // Indentation (2 characters per indentation) 
    for(int i = 0; i < 2 * nIndent; ++i)
        cout << ' ';
    // Display the name of the element
    cout << elem.GetName() << endl;
     
    const Elements* pChilds = elem.GetChilds(); 
    if(pChilds == 0)
        return;
     
    // For each child
    for(Elements::const_iterator it = pChilds->begin(); 
        it < pChilds->end(); ++it)
    {
        // Display the child and its sub-childs 
        ShowElemAndChilds(**it, nIndent + 1);
    }
}
     
int main()
// --------------------------------------------- 
// Entry point
// --------------------------------------------- 
{
    // Get the content of the XML file
    long nSize = 0;
    char* pBuffer = OpenXmlFile("sample.xml", nSize); 
    if(pBuffer == 0)
        return(false);
     
    try
    {
        // Parse the XML document
        Parser parser;
        const Element& root = parser.Parse(pBuffer, nSize); 
        // Display the elements, starting at the root 
        ShowElemAndChilds(root);
    }
    catch(Exception e)
    {
        // Parsing error
        cout << "Parsing error at line " 
             << e.GetLine() << endl;
    }
     
    // Delete the buffer
    delete[] pBuffer;
    return(1);
}
     
     
