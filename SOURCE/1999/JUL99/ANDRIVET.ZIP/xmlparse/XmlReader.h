//////////////////////////////////////////////////////////////////////
// A Simple XML Parser
//////////////////////////////////////////////////////////////////////
// Version:     1.0.1
// OS:          Windows NT 4.0 SP4
// Compiler:    Microsoft Visual C++ 6.0 SP2
// STL:         Silicon Graphics STL version 3.12
// 
// Copyright (c) 1999 Sebastien Andrivet. All rights reserved.
// 
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// ``Software''), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED ``AS IS'', WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL JAMES CLARK BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.

// Except as contained in this notice, the name of Sebastien Andrivet
// shall not be used in advertising or otherwise to promote the sale, 
// use or other dealings in this Software without prior written 
// authorization from Sebastien Andrivet.
//////////////////////////////////////////////////////////////////////

#ifndef INC_XMLREADER_H
#define INC_XMLREADER_H

// STL
#include <memory>
#include <vector>
#include <string>

// Smaltalk like self
#ifndef self
#define self (*this)
#endif

namespace SimpleXMLParser
{

//////////////////////////////////////////////////////////////////////

// Character type used
typedef char Char;
typedef const Char* PSTR;
typedef const Char* PCSTR;

// Permit to use Unicode (L"..") later
#ifndef TEXT
#define TEXT(str) str
#endif

class Attribute;
class Element;
class ElementNull;

typedef vector<Attribute*>  Attributes;
typedef vector<Element*>    Elements;

//////////////////////////////////////////////////////////////////////
// Attribute of Elements
//////////////////////////////////////////////////////////////////////

class Attribute
{
    string  m_strName;  // Name of the attribute
    string  m_strValue; // Value of the attribute

public:
    Attribute(const string& strName, const string& strValue);

    const string& GetName() const;  // Get the name
    const string& GetValue() const; // Get the value
};

// Array (vector) of Attributes
typedef vector<Attribute*> Attributes;

//////////////////////////////////////////////////////////////////////
// Value of Elements
//////////////////////////////////////////////////////////////////////

class Value
{
    string  m_strValue; // Value itself

public:
    Value();
    // Add the text to the current value
    void Add(const string& strText);
    // Add the char to the current value
    void Add(Char c);

    // Conversion operator
    operator const string&() const;
};

//////////////////////////////////////////////////////////////////////
// Elements (Markups) - Abstract class
//////////////////////////////////////////////////////////////////////

class Element
{
private:
    const string    m_strName;  // Name of the element
    Value           m_value;    // Value (content) of the element

public:
    static ElementNull& null;   // null element (singleton)

public:
    Element();
    Element(const string& strName);
    virtual ~Element();

    // Add the text to the current value
    void AddValue(const string& strText);
    // Add the char to the current value
    void AddValue(Char c);

    const string& GetName() const;  // Get the name
    const Value& GetValue() const;  // Get the value (content)

    // Get the nth element named szName
    const Element& operator()(PCSTR szName, int nIndex = 0) const;

public:
    // All element are not null except Element::null
	virtual bool IsNull() const;
    // Add a child
    virtual bool Add(Element* pChild) = 0;
    // Get childs
    virtual const Elements* GetChilds() const = 0;
    // Get the nth element called szName
	virtual const Element& GetChild(PCSTR szName, int nIndex = 0) const = 0;
    // Get attributes
	virtual const Attributes* GetAttributes() const = 0;
};

typedef vector<Element*> Elements;

//////////////////////////////////////////////////////////////////////
// Tag Element - Element of the form <name>...</name> or <name/>
// Can contain other elements and may have attributes
//////////////////////////////////////////////////////////////////////

class ElementTag : public Element
{
private:
    Attributes  m_attributes;   // Attributes
    Elements    m_childs;       // Childs

public:
    ElementTag(const string& strName);
    ~ElementTag();

    // Add an attribute
    void Add(Attribute* pAttribute);

    // Add a child
    virtual bool Add(Element* pChild);
    // Get childs
    virtual const Elements* GetChilds() const;
    // Get the nth element called szName
	virtual const Element& GetChild(PCSTR szName, int nIndex = 0) const;
    // Get attributes or NULL if none
	virtual const Attributes* GetAttributes() const;

private:
    // Find a child called szName starting at it
    bool FindChild(PCSTR szName, Elements::const_iterator& it) const;
};

//////////////////////////////////////////////////////////////////////
// Element without childs (like comments)
//////////////////////////////////////////////////////////////////////

class ElementSimple: public Element
{
public:
    ElementSimple(const string& strName);

    // Add a child - do nothing
    virtual bool Add(Element* pChild);
    // Get childs - return NULL
    virtual const Elements* GetChilds() const;
    // Get the nth element called szName - return null
	virtual const Element& GetChild(PCSTR szName, int nIndex = 0) const;
    // Get attributes - return NULL
	virtual const Attributes* GetAttributes() const;
};

//////////////////////////////////////////////////////////////////////
// Comment - Element named '!'
//////////////////////////////////////////////////////////////////////

class ElementComment : public ElementSimple
{
public:
    ElementComment(const string& strComment);
};

//////////////////////////////////////////////////////////////////////
// Null element (for Element::null)
//////////////////////////////////////////////////////////////////////

class ElementNull : public ElementSimple
{
public:
    ElementNull();

private:
	virtual bool IsNull() const;
};

//////////////////////////////////////////////////////////////////////
// Parsing Exception (error)
//////////////////////////////////////////////////////////////////////

class Exception
{
private:
    int m_nLine;
    int m_nColumn;

public:
    Exception(int nLine, int nColumn);

    int GetLine() const;
    int GetColumn() const;
};

//////////////////////////////////////////////////////////////////////
// XML Parser
//////////////////////////////////////////////////////////////////////

class Parser  
{
private:
    //////////////////////////////////////////////////////////////////
    // Bookmark : record the current position in the document
    //////////////////////////////////////////////////////////////////
    class Bookmark
    {
    private:
        Parser&     m_reader;           // Parser
        const Char* m_szSourceCurrent;  // Position recorded
        int         m_nLine;            // Line recorded
        int         m_nColumn;          // Column recorded

    public:
        Bookmark(Parser& reader);
        // Change back the position 
        void Restore();
        // Get the sub-string between the current and 
        // the recorded positions
        void GetSubString(string& strString, int nNumEndSkip = 0); 
        // Record the current position
        void Reset();
    };

    friend class Bookmark;

private:
	const Char*         m_szSource;         // XML document
    const Char*         m_szSourceCurrent;  // Current position
    const Char*         m_szSourceEnd;      // End of the document
    int                 m_nLine;            // Current line
    int                 m_nColumn;          // Current column

    string              m_strXmlVersion;    // Version of XML used in doc.
    auto_ptr<Element>   m_pRootElem;        // Root element

public:
	Parser();
	virtual ~Parser();

    // Parse the document
	Element& Parse(PCSTR szSource, int nSourceSize); // Can throw exception

private:
    // Next char (next position)
    Char NextChar();
    // Previous position
    void PreviousChar();

    // All these following member functions can throw exceptions

    // Read One or more spaces
    bool ParseSpaces();
    // Read the given string
    bool ParseString(const Char* pString);
    // Read the given string (not case sensitive)
    bool ParseStringNoCase(const Char* pString);
    // Read a (decimal) number
    bool ParseNumber(int& nNum);
    // Read an hexadecimal number
    bool ParseHexNumber(int& nNum);
    // Read a given char
    bool ParseChar(Char c);
    // Read a name (letters, digits and special chars)
    bool ParseName(string& strName);

    // Parse a declaration (like: version = )
    bool ParseDeclBegining(PCSTR szString);
    // Parse XML declaration (<?xml version="1.0" ... ?>
    bool ParseXMLDecl();
    // Parse equal sign
    bool ParseEq();
    // Parse XML version
    bool ParseVersionInfo(string& strVersion);
    // Parse XML version number
    bool ParseVersionNum(string& strVersion);
    // Parse XML encoding declaration
    bool ParseEncodingDecl();
    // Parse encoding name
    bool ParseEncName();
    // Parse Comments, spaces, etc.
    void ParseMiscs();
    // Parse reference
    bool ParseReference(char& c);
    // Parse attribute value
    bool ParseAttValue(string& strValue);
    // Parse Attribute
    bool ParseAttribute(ElementTag* pElem);
    // Parse end tad
    bool ParseETag(Element& element);
    // Parse element content and end tag
    void ParseContentETag(ElementTag& element);
    // Parse markups like comments, CDATA, elements, etc.
    bool ParseMarkup(Element& element);
    // Parse CDATA
    bool ParseCDATA(Element& element);

    // Parse comment and construct an element
    ElementComment* ParseComment();
    // Parse start tag and construct an element
    ElementTag* ParseTagBegining();
    // Parse element and construct an object
    ElementTag* ParseElement();
    // Parse document and construct a (root) element
    Element* ParseDocument();

    // Get the reference equivalent
    bool MapReferenceName(const string& strName, char& c);

    // Syntax error (throw exception)
    void SyntaxError();
};


//////////////////////////////////////////////////////////////////////

#include "XmlReader.inl"

//////////////////////////////////////////////////////////////////////

}

#endif
