// Sample1.cpp - Get the name of the first town
//

#include <stdio.h>
#include "..\..\XmlReader.h"
using namespace SimpleXMLParser;

// Get the name of the first town

char* OpenXmlFile(char* szFileName, long& nSize)
// ---------------------------------------------
// Load a XML file a return it in a buffer
//
// szFileName:  [in]  file name of the XML file
// nSize:       [out] size of the data returned
// Return:      pointer to XML file content
//
// Note:        The caller must destroy the
//              returned buffer with delete[]
// ---------------------------------------------
{
    // Open the file
    FILE* pFile = fopen(szFileName, "r");
    if(pFile == 0) // open failed ?
        return(0);

    // Compute the size of the file
    fseek(pFile, 0, SEEK_END);
    nSize = ftell(pFile);
    // Put the file pointer at the beginning
    fseek(pFile, 0, SEEK_SET);

    // Allocate a buffer big enough
    char* pBuffer = new char[nSize + 1];
    // Put the XML file data in the buffer
    fread(pBuffer, nSize, 1, pFile);
    // Put a 0 char at the end
    pBuffer[nSize] = 0;
    // Close the file
    fclose(pFile), pFile = 0;

    // Return the buffer
    return(pBuffer);
}

int main(int argc, char* argv[])
// ---------------------------------------------
// Entry point
// ---------------------------------------------
{
    // Get the content of the XML file
    long nSize = 0;
    char* pBuffer = OpenXmlFile("sample.xml", nSize);
    if(pBuffer == 0)
        return(false);

    try
    {
        // Parse the XML document
        Parser parser;
        const Element& root = parser.Parse(pBuffer, nSize);
      
        // Get the name of the first (index 0) town
        string strName = root("town", 0)("name").GetValue();
        cout << "Name of the first town: " << strName << endl;
    }
    catch(Exception e)
    {
        cout << "Parsing error at line " << e.GetLine() << endl;
    }

    // Delete the buffer
    delete[] pBuffer;
    return(1);
}

