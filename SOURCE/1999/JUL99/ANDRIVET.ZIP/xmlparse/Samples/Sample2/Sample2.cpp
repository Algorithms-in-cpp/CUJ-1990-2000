// Sample2.cpp - Load a display the hierarchy of
// of XML file.

#include <stdio.h>
#include "..\..\XmlReader.h"
using namespace SimpleXMLParser;

char* OpenXmlFile(char* szFileName, long& nSize)
// ---------------------------------------------
// Load a XML file a return it in a buffer
//
// szFileName:  [in]  file name of the XML file
// nSize:       [out] size of the data returned
// Return:      pointer to XML file content
//
// Note:        The caller must destroy the
//              returned buffer with delete[]
// ---------------------------------------------
{
    // Open the file
    FILE* pFile = fopen(szFileName, "r");
    if(pFile == 0) // open failed ?
        return(0);

    // Compute the size of the file
    fseek(pFile, 0, SEEK_END);
    nSize = ftell(pFile);
    // Put the file pointer at the beginning
    fseek(pFile, 0, SEEK_SET);

    // Allocate a buffer big enough
    char* pBuffer = new char[nSize + 1];
    // Put the XML file data in the buffer
    fread(pBuffer, nSize, 1, pFile);
    // Put a 0 char at the end
    pBuffer[nSize] = 0;
    // Close the file
    fclose(pFile), pFile = 0;

    // Return the buffer
    return(pBuffer);
}

void ShowElemAndChilds(const Element& elem, int nIndent = 0)
// ---------------------------------------------
// Enumerate childs of elem, recursivly and 
// display their name (with identation)
//
// elem:    [in] element to display
// nIndent: [in] number of identation
// ---------------------------------------------
{
    // Indentation (2 characters per indentation)
    for(int i = 0; i < 2 * nIndent; ++i)
        cout << ' ';
    // Display the name of the element
    cout << elem.GetName() << endl;

    const Elements* pChilds = elem.GetChilds();
    if(pChilds == 0)
        return;

    // For each child
    for(Elements::const_iterator it = pChilds->begin(); 
        it < pChilds->end(); ++it)
    {
        // Display the child and its sub-childs
        ShowElemAndChilds(**it, nIndent + 1);
    }
}

int main()
// ---------------------------------------------
// Entry point
// ---------------------------------------------
{
    // Get the content of the XML file
    long nSize = 0;
    char* pBuffer = OpenXmlFile("sample.xml", nSize);
    if(pBuffer == 0)
        return(false);

    try
    {
        // Parse the XML document
        Parser parser;
        const Element& root = parser.Parse(pBuffer, nSize);
        // Display the elements, starting at the root
        ShowElemAndChilds(root);
    }
    catch(Exception e)
    {
        // Parsing error
        cout << "Parsing error at line " << e.GetLine() << endl;
    }

    // Delete the buffer
    delete[] pBuffer;
    return(1);
}

