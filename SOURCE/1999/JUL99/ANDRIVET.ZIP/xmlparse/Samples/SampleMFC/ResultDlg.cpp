// ResultDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleXMLReader.h"
#include "ResultDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CResultDlg dialog


CResultDlg::CResultDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CResultDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CResultDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CResultDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CResultDlg)
	DDX_Control(pDX, IDC_TREE, m_tree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CResultDlg, CDialog)
	//{{AFX_MSG_MAP(CResultDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

HTREEITEM CResultDlg::SetRoot(const CString& strName)
// Set the root of the tree
{
    return(m_tree.InsertItem(strName, 0, 0, TVI_ROOT)); // image 0
}

HTREEITEM CResultDlg::AddChild(HTREEITEM hItemRoot, const CString& strName)
// Add a child to the element hItemRoot
{
    return(m_tree.InsertItem(strName, 0, 0, hItemRoot));
}

HTREEITEM CResultDlg::AddValue(HTREEITEM hItemRoot, const CString& strValue)
// Add a value to the element hItemRoot
{
    // Add only if not empty
    if(strValue.IsEmpty())
        return(NULL);
    return(m_tree.InsertItem(strValue, 1, 1, hItemRoot)); // image 1
}

HTREEITEM CResultDlg::AddAttribute(HTREEITEM hItemRoot, const CString& strName, const CString& strValue)
// Add an attribute to the element hItemRoot
{
    // Add the attribute
    HTREEITEM hItem = m_tree.InsertItem(strName, 2, 2, hItemRoot); // image 2
    if(NULL == hItem)
        return(NULL);

    // Add its value if any
    if(!strValue.IsEmpty())
        m_tree.InsertItem(strValue, 1, 1, hItem);

    return(hItem);
}

static void Expand(CTreeCtrl& tree, HTREEITEM hItem)
// Expand node hItem and its childs (recusivly)
{
    // Expand the node hItem
    tree.Expand(hItem, TVE_EXPAND);
    // For each child...
    HTREEITEM hChild = tree.GetChildItem(hItem);
    while(hChild != NULL)
    {
        // Expand it and its childs
        Expand(tree, hChild);
        // Next child
        hChild = tree.GetNextItem(hChild, TVGN_NEXT);
    }
}

void CResultDlg::ExpandAll()
// Expand tree
{
    HTREEITEM hRoot = m_tree.GetRootItem();
    if(NULL != hRoot)
        Expand(m_tree, hRoot);
}

/////////////////////////////////////////////////////////////////////////////
// CResultDlg message handlers

BOOL CResultDlg::Create(CWnd* pParent)
{
	return(CDialog::Create(IDD, pParent));
}

BOOL CResultDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
    // Load the image list for the tree
    VERIFY(m_image.Create(IDB_TREE, 16, 1, RGB(0, 255, 0)));
    m_tree.SetImageList(&m_image, TVSIL_NORMAL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CResultDlg::PostNcDestroy() 
{
	CDialog::PostNcDestroy();
    delete this;
}
