// SimpleXMLReaderView.cpp : implementation of the CSimpleXMLReaderView class
//

#include "stdafx.h"
#include "SimpleXMLReader.h"

#include "SimpleXMLReaderDoc.h"
#include "SimpleXMLReaderView.h"
#include "ResultDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderView

IMPLEMENT_DYNCREATE(CSimpleXMLReaderView, CEditView)

BEGIN_MESSAGE_MAP(CSimpleXMLReaderView, CEditView)
	//{{AFX_MSG_MAP(CSimpleXMLReaderView)
	ON_COMMAND(ID_XML_PARSE, OnXmlParse)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderView construction/destruction

CSimpleXMLReaderView::CSimpleXMLReaderView()
{
	// TODO: add construction code here

}

CSimpleXMLReaderView::~CSimpleXMLReaderView()
{
}

BOOL CSimpleXMLReaderView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CEditView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderView drawing

void CSimpleXMLReaderView::OnDraw(CDC* pDC)
{
	CSimpleXMLReaderDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderView printing

BOOL CSimpleXMLReaderView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSimpleXMLReaderView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSimpleXMLReaderView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderView diagnostics

#ifdef _DEBUG
void CSimpleXMLReaderView::AssertValid() const
{
	CEditView::AssertValid();
}

void CSimpleXMLReaderView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CSimpleXMLReaderDoc* CSimpleXMLReaderView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSimpleXMLReaderDoc)));
	return (CSimpleXMLReaderDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderView message handlers

void CSimpleXMLReaderView::OnInitialUpdate() 
{
	CEditView::OnInitialUpdate();
	
    CFont font;
    font.CreateStockObject(ANSI_FIXED_FONT);
	GetEditCtrl().SetFont(&font, false);
}

void CSimpleXMLReaderView::OnXmlParse() 
{
    using namespace SimpleXMLParser;

	CString strXml;
    CEdit& edit = GetEditCtrl();
    edit.GetWindowText(strXml);

    try
    {
        SimpleXMLParser::Parser parser;
        Element& elem = parser.Parse(strXml, strXml.GetLength());

        CResultDlg* pDlg = new CResultDlg;
        pDlg->Create(this);
        pDlg->ShowWindow(SW_SHOW);

        if(!elem.IsNull())
        {
            HTREEITEM hItem = pDlg->SetRoot(elem.GetName().c_str());
            AddChilds(pDlg, hItem, elem);
            pDlg->ExpandAll();
        }
    }
    catch(SimpleXMLParser::Exception e)
    {
        CString strError;
        strError.Format(_T("Syntax error at line(%i), column(%i)"), e.GetLine(), e.GetColumn());
        AfxMessageBox(strError, MB_ICONEXCLAMATION);

        int nBegin = edit.LineIndex(e.GetLine() - 1);
        if(nBegin < 0)
            nBegin = edit.GetWindowTextLength();

        int nEnd = edit.LineIndex(e.GetLine());
        if(nEnd < 0)
            nEnd = edit.GetWindowTextLength();
        edit.SetSel(nBegin, nEnd - 1);
    }
}

void CSimpleXMLReaderView::AddChilds(CResultDlg* pDlg, HTREEITEM hItemRoot, const SimpleXMLParser::Element& elem) 
{
    using namespace SimpleXMLParser;

    const Attributes* pAttributes = elem.GetAttributes();
    if(NULL != pAttributes)
    {
        for(Attributes::const_iterator itAttr = pAttributes->begin(); itAttr < pAttributes->end(); ++itAttr)
        {
            const Attribute* pAttr = *itAttr;
            pDlg->AddAttribute(hItemRoot, pAttr->GetName().c_str(), pAttr->GetValue().c_str());
        }
    }

    const Elements* pElements = elem.GetChilds();
    if(NULL != pElements)
    {
        for(Elements::const_iterator itElem = pElements->begin(); itElem < pElements->end(); ++itElem)
        {
            const Element* pElem = *itElem;
            HTREEITEM hItemChild = pDlg->AddChild(hItemRoot, pElem->GetName().c_str());
            AddChilds(pDlg, hItemChild, *pElem);
        }
    }
    else
    {
        string strValue = elem.GetValue();
        pDlg->AddValue(hItemRoot, strValue.c_str());
    }
}
