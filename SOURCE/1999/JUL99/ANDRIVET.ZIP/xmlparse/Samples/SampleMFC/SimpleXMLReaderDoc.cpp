// SimpleXMLReaderDoc.cpp : implementation of the CSimpleXMLReaderDoc class
//

#include "stdafx.h"
#include "SimpleXMLReader.h"

#include "SimpleXMLReaderDoc.h"
#include "SimpleXMLReaderView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderDoc

IMPLEMENT_DYNCREATE(CSimpleXMLReaderDoc, CDocument)

BEGIN_MESSAGE_MAP(CSimpleXMLReaderDoc, CDocument)
	//{{AFX_MSG_MAP(CSimpleXMLReaderDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderDoc construction/destruction

CSimpleXMLReaderDoc::CSimpleXMLReaderDoc()
{
	// TODO: add one-time construction code here

}

CSimpleXMLReaderDoc::~CSimpleXMLReaderDoc()
{
}

BOOL CSimpleXMLReaderDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderDoc serialization

void CSimpleXMLReaderDoc::Serialize(CArchive& ar)
{
	((CSimpleXMLReaderView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderDoc diagnostics

#ifdef _DEBUG
void CSimpleXMLReaderDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSimpleXMLReaderDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSimpleXMLReaderDoc commands
