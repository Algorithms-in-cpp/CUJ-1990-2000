#if !defined(AFX_RESULTDLG_H__D6F6A225_AF75_11D2_B5E9_00C04F8A1A06__INCLUDED_)
#define AFX_RESULTDLG_H__D6F6A225_AF75_11D2_B5E9_00C04F8A1A06__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ResultDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CResultDlg dialog

class CResultDlg : public CDialog
{
// Dialog Data
	//{{AFX_DATA(CResultDlg)
	enum { IDD = IDD_RESULT };
	CTreeCtrl	m_tree;
	//}}AFX_DATA

private:
    CImageList  m_image;    // ImageList for the tree

// Construction
public:
	CResultDlg(CWnd* pParent = NULL);   // standard constructor
	BOOL Create(CWnd* pParent);

    // Set the root of the tree
    HTREEITEM SetRoot(const CString& strName);
    // Add a child to the element hItemRoot
    HTREEITEM AddChild(HTREEITEM hItemRoot, const CString& strName);
    // Add a value to the element hItemRoot
    HTREEITEM AddValue(HTREEITEM hItemRoot, const CString& strValue);
    // Add an attribute to the element hItemRoot
    HTREEITEM AddAttribute(HTREEITEM hItemRoot, const CString& strName, const CString& strValue);
    // Expand tree
    void ExpandAll();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CResultDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CResultDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RESULTDLG_H__D6F6A225_AF75_11D2_B5E9_00C04F8A1A06__INCLUDED_)
