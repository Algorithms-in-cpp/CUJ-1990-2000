//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SimpleXMLReader.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SIMPLETYPE                  129
#define IDD_RESULT                      130
#define IDB_TREE                        131
#define IDC_TREE                        1000
#define ID_XML_PARSE                    32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
