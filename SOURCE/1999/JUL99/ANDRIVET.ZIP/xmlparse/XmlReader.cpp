//////////////////////////////////////////////////////////////////////
// A Simple XML Parser
//
// See XmlReader.h
//////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1999 Sebastien Andrivet. All rights reserved.
// 
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// ``Software''), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED ``AS IS'', WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL JAMES CLARK BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.

// Except as contained in this notice, the name of Sebastien Andrivet
// shall not be used in advertising or otherwise to promote the sale, 
// use or other dealings in this Software without prior written 
// authorization from Sebastien Andrivet.
//////////////////////////////////////////////////////////////////////
//
// Parser.cpp: implementation of the Parser class.

#include "XmlReader.h"

// Some debugging stuf (only for Win32)
#if defined(_DEBUG) & defined(DEBUG_NEW)
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// Macro to get the number of element in a array
#ifndef elemof
#define elemof(array) (sizeof(array) / sizeof((array)[0]))
#endif

// Our namespace
namespace SimpleXMLParser
{

//////////////////////////////////////////////////////////////////////
// XML Parser
//////////////////////////////////////////////////////////////////////

Parser::Parser()
:   m_szSource(NULL),
    m_strXmlVersion(TEXT("1.0")), // By default
    m_nLine(1),
    m_nColumn(1)
{
}

Parser::~Parser()
{
}

void Parser::SyntaxError()
// Syntax error (throw exception)
{
    throw Exception(m_nLine, m_nColumn);
}


//////////////////////////////////////////////////////////////////////

Char Parser::NextChar()
// Next char (next position)
{
    // End of document ?
    if(m_szSourceCurrent >= m_szSourceEnd)
        return(0);
    // Next char
    Char c = *m_szSourceCurrent++;

    // Skip \r if any
    if(c == TEXT('\r'))
    {
        // End of document ?
        if(m_szSourceCurrent >= m_szSourceEnd)
            return(0);
        // Next char
        c = *m_szSourceCurrent++;
    }

    // If new line, increment the line number
    if(c == TEXT('\n'))
        ++m_nLine, m_nColumn = 1;
    else // increment the column number
        ++m_nColumn;

    // Return the char
    return(c);
}

void Parser::PreviousChar()
// Previous position
{
    // Decrement the position if we are not already
    // at the begining of the document
    if(m_szSourceCurrent - 1 < m_szSource)
        m_szSourceCurrent = m_szSource;
    else
        m_szSourceCurrent -= 1;
}

//////////////////////////////////////////////////////////////////////

bool Parser::ParseString(const Char* pString)
// Read the given string
{
    // Record the current position
    Bookmark bookmark(self);

    // not end of string ?
    while(*pString != 0)
    {
        // Next char
        Char c = NextChar();
        // Same ?
        if(c != *pString)
        {
            // Not the same so revert back to
            // the previous position
            bookmark.Restore();
            return(false);
        }

        // Next char of the string
        ++pString;
    }

    return(true);
}

bool Parser::ParseStringNoCase(const Char* pString)
// Read the given string (not case sensitive)
{
    // Record the current position
    Bookmark bookmark(self);

    // not end of string ?
    while(*pString != 0)
    {
        // Next char
        Char c = NextChar();
        // Same (not case sensitive) ?
        if(LowCase(c) != LowCase(*pString))
        {
            // Not the same so revert back to
            // the previous position
            bookmark.Restore();
            return(false);
        }

        // Next char of the string
        ++pString;
    }

    return(true);
}

bool Parser::ParseNumber(int& nNum)
// Read a (decimal) number
{
    Char c = NextChar();
    // Start with a digit ?
    if(!IsDigit(c))
        return(false); // not a number
    
    nNum = 0;
    // Read all digits possible
    while(IsDigit(c))
    {
        // Compute new number
        nNum = nNum * 10 + c - TEXT('0');
        // Next char
        c = NextChar();
    }

    // The current char if not part of the number
    PreviousChar();
    return(true);
}

bool Parser::ParseHexNumber(int& nNum)
// Read an hexadecimal number
{
    Char c = NextChar();
    // Start with an hexadecimal digit ?
    if(!IsHexDigit(c))
        return(false);

    nNum = 0;
    // Read all digits possible
    while(IsHexDigit(c))
    {
        // Compute new number
        nNum = nNum * 16 + HexDigitValue(c);
        // Next char
        c = NextChar();
    }

    // The current char if not part of the number
    PreviousChar();
    return(true);
}

bool Parser::ParseChar(Char c)
// Read a given char
{
    if(NextChar() != c)
    {
        PreviousChar();
        return(false);
    }
    return(true);
}

//////////////////////////////////////////////////////////////////////

bool Parser::ParseSpaces()
// Read One or more spaces
// S ::= (#x20 | #x9 | #xD | #xA)+
{
    Char c = NextChar();
    if(!IsSpace(c))
    {
        PreviousChar();
        return(false);
    }

    do c = NextChar(); while(IsSpace(c));
    PreviousChar();
    return(true);
}

bool Parser::ParseDeclBegining(PCSTR szString)
// Parse a declaration (like: version = )
// 
// S <szString> Eq.
// Marker: <szString>
{
    // Parse: S
    Char c = NextChar();
    if(!IsSpace(c))
    {
        PreviousChar();
        return(false);
    }
    ParseSpaces();

    // Parse: <szString>
    if(!ParseString(szString))
        return(false);

    // Parse: Eq
    if(!ParseEq())
        SyntaxError();

    return(true);
}

//////////////////////////////////////////////////////////////////////

bool Parser::ParseXMLDecl()
// Parse XML declaration
// 
// XMLDecl ::= '<?xml' VersionInfo EncodingDecl? S? '?>'
// Marker: '<?xml'
{
    // Parse: '<?xml'
    if(!ParseStringNoCase(TEXT("<?xml")))
        return(false);

    // Parse: VersionInfo EncodingDecl? SDDecl? S? '?>'
    if(!ParseVersionInfo(m_strXmlVersion))
        SyntaxError();

    // Parse EncodingDecl (optional)
    ParseEncodingDecl();
    // Parse S (spaces) (optional)
    ParseSpaces();

    // Parse end of declaration '?>'
    if(!ParseString(TEXT("?>")))
        SyntaxError();

    return(true);
}

bool Parser::ParseEq()
// Parse equal sign
// 
// Eq ::= S? '=' S?
// Marker: '='
{
    // Record the current position
    Bookmark bookmark(self);

    // Parse spaces (optional)
    ParseSpaces();
    // Is an equal sign ?
    if(!ParseChar(TEXT('=')))
    {
        // No, so revert to the previous position
        bookmark.Restore();
        return(false);
    }
    // Skip spaces if any
    ParseSpaces();

    return(true);
}

bool Parser::ParseVersionInfo(string& strVersion)
// Parse XML version
// 
// VersionInfo ::= S 'version' Eq (' VersionNum ' | " VersionNum ")
// Marker: 'version'
{
    // Parse: S 'version' Eq
    if(!ParseDeclBegining(TEXT("version")))
        return(false);

    // Parse: (' VersionNum ' | " VersionNum ")
    Char c = NextChar();
    if(c != TEXT('\'') && c != TEXT('\"'))
        SyntaxError();

    // Parse version number and check the delimiter
    if(!ParseVersionNum(strVersion) || NextChar() != c)
        SyntaxError();

    return(true);
}

bool Parser::ParseVersionNum(string& strVersion)
// Parse XML version number
//
// VersionNum ::= ([a-zA-Z0-9_.:] | '-')+
{
    // Record the current position
    Bookmark bookmark(self);

    Char c = NextChar();
    // Is an allowed character ?
    if(!IsAlphaDigitEx(c))
        return(false);

    c = NextChar();
    // Get as more char as possible
    while(IsAlphaDigitEx(c))
        c = NextChar();

    // Current character is not part of the version num.
    PreviousChar();

    // Get the version number
    bookmark.GetSubString(strVersion);
    return(true);
}


bool Parser::ParseEncodingDecl()
// Parse XML encoding declaration
//
// EncodingDecl ::=  S 'encoding' Eq ('"' EncName '"' |  "'" EncName "'")
// Marker: 'encoding'
{
    // Parse: S 'encoding' Eq
    if(!ParseDeclBegining(TEXT("encoding")))
        return(false);

    // Parse: ('"' EncName '"' |  "'" EncName "'")
    Char c = NextChar();
    if(c != TEXT('\'') && c != TEXT('\"'))
        SyntaxError();

    // Parse encoding name and check delimiter
    if(ParseEncName() || NextChar() != c)
        SyntaxError();

    return(true);
}

bool Parser::ParseEncName()
// Parse encoding name
// 
// EncName ::=  [A-Za-z] ([A-Za-z0-9._] | '-')*
{
    Char c = NextChar();
    // Is an allowed character ?
    if(!IsAlpha(c))
        return(false);

    c = NextChar();
    // Get as more char as possible
    while(IsAlphaDigitEx(c))
        c = NextChar();

    // Current character is not part of the version num.
    PreviousChar();

    // In this version, the encoding is not used
    return(true);
}

void Parser::ParseMiscs()
// Parse Comments, spaces, etc.
// 
// Misc*
// Misc ::= Comment | S
{
    for(;;)
    {
        // Parse spaces if any
        ParseSpaces();

        // Parse comment if any
        auto_ptr<ElementComment> pElem(ParseComment());
        if(NULL == pElem.get())
            break;
    }
}

ElementComment* Parser::ParseComment()
// Parse comment and construct an element
// 
// Comment ::= '<!--' ((Char - '-') | ('-' (Char - '-')))* '-->'
{
    // Check the start of the comment
    if(!ParseString(TEXT("<!--")))
        return(NULL);

    // Record the current position to extract later the
    // content of the comment
    Bookmark bookmark(self);
    for(;;)
    {
        // Look for the end of the comment
        if(ParseString(TEXT("--")))
        {
            // Really the end ?
            if(!ParseChar(TEXT('>')))
                SyntaxError();
            break;
        }

        // End of document ?
        if(NextChar() == 0)
            SyntaxError();
    }

    // Extract the content of the comment
    string strComment;
    bookmark.GetSubString(strComment, 3);

    // Construct an element
    return(new ElementComment(strComment));
}

//////////////////////////////////////////////////////////////////////

bool Parser::ParseName(string& strName)
// Read a name (letters, digits and special chars)
//
// Name     ::=  (Letter | '_' | ':') (NameChar)* 
// NameChar ::=  Letter | Digit | '.' | '-' | '_' | ':' | CombiningChar | Extender 
{
    // Record the current position to extract later the name
    Bookmark bookmark(self);

    Char c = NextChar();
    // Is allowed ?
    if(!IsAlpha(c) && c != TEXT('_') && c != TEXT(':'))
    {
        PreviousChar();
        return(false);
    }

    // Get as more (allowed) char as possible
    for(;;)
    {
        c = NextChar();
        // Is allowed ?
        if(!IsAlphaDigitEx(c))
            break;
    }

    // Current character is not part of the version num.
    PreviousChar();

    // Extract the name
    bookmark.GetSubString(strName);
    return(true);
}

bool Parser::ParseReference(char& cRef)
// Parse reference
//
// Reference ::=  EntityRef | CharRef 
// EntityRef ::=  '&' Name ';' 
// CharRef ::=  '&#' [0-9]+ ';' | '&#x' [0-9a-fA-F]+ ';' 
// Marker: '&'
{
    // Begin like a reference ?
    if(!ParseChar(TEXT('&')))
        return(false);

    Char c = NextChar();
    // EntityRef ? (not a CharRef)
    if(c != TEXT('#'))
    {
        // It is an EntityRef
        PreviousChar();
        // Get the name of the reference and check the end (';')
        string strReferenceName;
        if(!ParseName(strReferenceName) || !ParseChar(TEXT(';')))
            SyntaxError();
        // Look for the reference
        if(!MapReferenceName(strReferenceName, cRef))
            SyntaxError();

        return(true);
    }

    // It is a CharRef
    c = NextChar();
    // Compute the value (character code)
    int nNum = 0;
    // Hexadecimal ?
    if(c == TEXT('x'))
    {
        // Get the value
        if(!ParseHexNumber(nNum))
            SyntaxError();
    }
    else
    {
        PreviousChar();
        // Get the value
        if(!ParseNumber(nNum))
            SyntaxError();
    }

    // Check the end of the reference
    if(!ParseChar(TEXT(';')))
        SyntaxError();

    // Return the character with the computed code
    cRef = static_cast<Char>(nNum);
    return(true);
}

bool Parser::ParseAttValue(string& strValue)
// Parse attribute value
//
// '"' ([^<&"] | Reference)* '"'  | "'" ([^<&'] | Reference)* "'" 
// Marker: '"' | "'"
{
    // Get the value delimiter (quote or apostroph)
    Char cDelim = NextChar();
    if(cDelim != TEXT('\'') && cDelim != TEXT('\"'))
    {
        PreviousChar();
        return(false);
    }

    // Record the current position to extract later the value
    Bookmark bookmark(self);

    Char c = NextChar();
    // Search the end of the value
    while(c != cDelim)
    {
        switch(c)
        {
        case 0: // end of document
            SyntaxError();

        case TEXT('<'): // Tag
            SyntaxError();

        case TEXT('&'): // Reference
            {
                PreviousChar();
                // Put what we already have in the value
                string strBefore;
                bookmark.GetSubString(strBefore);
                strValue += strBefore;

                char c;
                // Get the reference
                if(!ParseReference(c))
                    SyntaxError();

                // Put the char in the value
                strValue += c;
                // Record the new position (after the reference)
                bookmark.Reset();
            }
            break;

        default:
            // Next character
            c = NextChar();
            break;
        }
    }

    // Put the remaining of the value
    string strRemaining;
    bookmark.GetSubString(strRemaining, 1);
    strValue += strRemaining;

    return(true);
}

bool Parser::ParseAttribute(ElementTag* pElem)
// Parse Attribute
//
// Attribute ::=  Name Eq AttValue
// Marker: Name
{
    // Get attribute name
    string strName;
    if(!ParseName(strName))
        return(false);

    // Get attribute value after the equal sign
    string strValue;
    if(!ParseEq() || !ParseAttValue(strValue))
        SyntaxError();

    // Construct an Attribute object and add it to the element
    auto_ptr<Attribute> pAttrib(new Attribute(strName, strValue));
    pElem->Add(pAttrib.release());

    return(true);
}

bool Parser::ParseCDATA(Element& element)
// Parse CDATA
//
// CDSect ::=  '<![CDATA[' CData ']]>' 
// CData ::=  (Char* - (Char* ']]>' Char*))  
// Marker: '<![CDATA[' 
{
    // Parse: <![CDATA[
    if(!ParseString(TEXT("<![CDATA[")))
        return(false);

    Bookmark bookmark(self);
    // Parse: CData
    for(;;)
    {
        // End of CDATA ?
        if(ParseString(TEXT("]]>")))
            break;

        // Is character allowed ?
        if(!IsXmlChar(NextChar()))
            SyntaxError();
    }

    // Get CDATA content and add it as-is to the value
    string strCDATA;
    bookmark.GetSubString(strCDATA, 3);
    element.AddValue(strCDATA);
    return(true);
}

ElementTag* Parser::ParseTagBegining()
// Parse start tag and construct an element
//
// '<' Name (S Attribute)* S?
// Marker: '<'
{
    // Parse: '<'
    if(!ParseChar(TEXT('<')))
        return(NULL);

    // Get the name of the tag
    string strName;
    if(!ParseName(strName))
        SyntaxError();

    // Construct an element object
    auto_ptr<ElementTag> pElem(new ElementTag(strName));

    // Parse: (S Attribute)* S?
    while(ParseSpaces() && ParseAttribute(pElem.get()))
        ;

    // return the element to the caller
    return(pElem.release());
}

bool Parser::ParseETag(Element& element)
// Parse end tad
//
// ETag ::=  '</' Name S? '>'
// Marker: '</'
{
    // Is an End tag ?
    if(!ParseString(TEXT("</")))
        return(false);

    // Get the tag name
    string strEndTagName;
    if(!ParseName(strEndTagName))
        SyntaxError();

    // Start and end tag names must match
    if(strEndTagName != element.GetName())
        SyntaxError();

    // Skip spaces
    ParseSpaces();
    // End of the tag
    if(!ParseChar(TEXT('>')))
        SyntaxError();

    return(true);
}

bool Parser::ParseMarkup(Element& element)
// Parse markups like comments, CDATA, elements, etc.
//
// Comment   begins with '<!--'
// CDSect    begins with '<![CDATA['
// element   begins with '<'
{
    // Try to read a comment
    auto_ptr<ElementComment> pComment(ParseComment());
    if(NULL != pComment.get())
    {
        // Add it to the element
        if(!element.Add(pComment.release()))
            SyntaxError();
        return(true);
    }

    // Try to read a CDATA
    if(ParseCDATA(element))
        return(true);

    // Try to read an element
    auto_ptr<ElementTag> pTag(ParseElement());
    if(NULL != pTag.get())
    {
        if(!element.Add(pTag.release()))
            SyntaxError();
        return(true);
    }

    return(false);
}

void Parser::ParseContentETag(ElementTag& element)
// Parse element content and end tag
//
// content  ::=  (element | CharData | Reference | CDSect | Comment)*
// CharData ::=  [^<&]* - ([^<&]* ']]>' [^<&]*) 
// Reference begins with '&'
{
    // Record the current position to extract later the content
    Bookmark bookmark(self);

    Char c = NextChar();
    for(;;)
    {
        // "]]>" not allowed in content
        if(ParseString(TEXT("]]>")))
            SyntaxError();

        switch(c)
        {
        case 0: // End of document
            SyntaxError();
            break;

        case TEXT('&'):
        case TEXT('<'):
            {
                PreviousChar();

                // Put what we already have in the value
                string strValue;
                bookmark.GetSubString(strValue);
                element.AddValue(strValue);

                // Tag or reference ?
                if(c == TEXT('&'))
                {
                    // Get the reference
                    if(!ParseReference(c))
                        SyntaxError();

                    // Add it to the value
                    element.AddValue(c);
                }
                else
                {
                    // Is an end tag ?
                    if(ParseETag(element))
                        return;
                    else if(!ParseMarkup(element))
                        SyntaxError();
                }

                bookmark.Reset();
            }
            break;

        default:
            break;
        }

        // Next char
        c = NextChar();
    }
}

ElementTag* Parser::ParseElement()
// Parse element and construct an object
//
// element      ::= EmptyElemTag | STag content ETag
// EmptyElemTag ::=  '<' Name (S Attribute)* S? '/>'
// STag         ::=  '<' Name (S Attribute)* S? '>'  
// Marker: '<'
{
    // Begining of element (start tag)
    auto_ptr<ElementTag> pTag(ParseTagBegining());
    if(pTag.get() == NULL)
        return(NULL);

    Char c = NextChar();
    if(c == TEXT('/')) // Empty tag ?
    {
        c = NextChar();
        if(c != TEXT('>'))
            SyntaxError();

        return(pTag.release());
    }

    // End of the tag
    if(c != TEXT('>'))
        SyntaxError();

    // Parse the remaining of the element
    ParseContentETag(*pTag);
    return(pTag.release());
}

//////////////////////////////////////////////////////////////////////

Element* Parser::ParseDocument()
// Parse document and construct a (root) element
//
// document ::= XMLDecl? Misc* element Misc*
{
    // XML declaration (optional)
    ParseXMLDecl();
    ParseMiscs();

    // Get the root element
    auto_ptr<Element> pElem(ParseElement());
    if(NULL == pElem.get())
        SyntaxError();

    ParseMiscs();
    return(pElem.release());
}

Element& Parser::Parse(PCSTR szSource, int nSourceSize)
// Parse the document
{
    m_szSource          = szSource;
    m_szSourceCurrent   = m_szSource;
    m_szSourceEnd       = m_szSource + nSourceSize;
    m_nLine             = 1;
    m_nColumn           = 1;

    // Get the root eleement
    m_pRootElem.reset(ParseDocument());
    return(*m_pRootElem);
}

//////////////////////////////////////////////////////////////////////
// Entity references
//////////////////////////////////////////////////////////////////////

// Map a name to a character
struct MapReference
{
    PSTR szName;
    Char c;
}

// Predefined refererences
static const s_MapReference[] = 
{
    { TEXT("lt"),   TEXT('<') },
    { TEXT("gt"),   TEXT('>') },
    { TEXT("amp"),  TEXT('&') },
    { TEXT("apos"), TEXT('\"') },
    { TEXT("quot"), TEXT('\'') }
};

bool Parser::MapReferenceName(const string& strName, char& c)
// Find the reference strName and return its equivalent
{
    for(int nIndex = 0; nIndex < elemof(s_MapReference); ++nIndex)
    {
        // Same name ?
        if(strName == s_MapReference[nIndex].szName)
        {
            // return the equivalent
            c = s_MapReference[nIndex].c;
            return(true);
        }
    }
    
    return(false);
}

//////////////////////////////////////////////////////////////////////

}

