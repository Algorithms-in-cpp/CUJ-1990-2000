//////////////////////////////////////////////////////////////////////
// A Simple XML Parser
//
// See XmlReader.h
//////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1999 Sebastien Andrivet. All rights reserved.
// 
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// ``Software''), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED ``AS IS'', WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL JAMES CLARK BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.

// Except as contained in this notice, the name of Sebastien Andrivet
// shall not be used in advertising or otherwise to promote the sale, 
// use or other dealings in this Software without prior written 
// authorization from Sebastien Andrivet.
//////////////////////////////////////////////////////////////////////
//
// XmlElements.cpp: implementation of the Element classes.

#include "XmlReader.h"

#if defined(_DEBUG) & defined(DEBUG_NEW)
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// Define NULL if not already the case
#ifndef NULL
#define NULL 0
#endif

// Our namespace
namespace SimpleXMLParser
{

// Null element
static ElementNull s_nullElem;
ElementNull& Element::null = s_nullElem;

//////////////////////////////////////////////////////////////////////
// Attribute of Elements
//////////////////////////////////////////////////////////////////////

Attribute::Attribute(const string& strName, const string& strValue)
:   m_strName(strName),
    m_strValue(strValue)
{
}

//////////////////////////////////////////////////////////////////////
// Value of Elements
//////////////////////////////////////////////////////////////////////

Value::Value()
{
}

void Value::Add(const string& strText)
// Add the text to the current value
{
    m_strValue += strText;
}

void Value::Add(Char c)
// Add the char to the current value
{
    m_strValue += c;
}

Value::operator const string&() const
// Conversion operator
{
    return(m_strValue);
}

//////////////////////////////////////////////////////////////////////
// Elements (Markups) - Abstract class
//////////////////////////////////////////////////////////////////////

Element::Element()
{
}

Element::Element(const string& strName)
:   m_strName(strName)
{
}

Element::~Element()
{
}

bool Element::IsNull() const
// All element are not null except Element::null
{
    return(false);
}

//////////////////////////////////////////////////////////////////////
// Tag Element - Element of the form <name>...</name> or <name/>
//////////////////////////////////////////////////////////////////////

ElementTag::ElementTag(const string& strName)
:   Element(strName)
{
}

ElementTag::~ElementTag()
{
    // Destroy attributes
    for(Attributes::iterator itAttrib = m_attributes.begin(); itAttrib < m_attributes.end(); ++itAttrib)
        delete *itAttrib;

    // Destroy childs
    for(Elements::iterator itElem = m_childs.begin(); itElem < m_childs.end(); ++itElem)
        delete *itElem;
}

bool ElementTag::Add(Element* pChild)
// Add a child to the element
{
    m_childs.push_back(pChild);
    return(true);
}

const Elements* ElementTag::GetChilds() const
// Get the childs of this element
{
    return(m_childs.empty() ? NULL : &m_childs);
}

bool ElementTag::FindChild(PCSTR szName, Elements::const_iterator& it) const
// Find a child called szName starting at it
{
    // Simply look at each child
    for(; it < m_childs.end(); ++it)
    {
        if((*it)->GetName() == szName) // Same name ?
            return(true);
    }

    return(false);
}

const Element& ElementTag::GetChild(PCSTR szName, int nIndex) const
// Get the nth element called szName
{
    // Start with the first child
    Elements::const_iterator it = m_childs.begin();
    // Count the number of match to skip (less 1)
    for(int nCount = 0; nCount < nIndex; ++nIndex)
    {
        // Search a child named szName
        if(!FindChild(szName, it))
            return(null);
        // Next child
        ++it;
    }

    // Last search (we skip nIndex - 1)
    if(!FindChild(szName, it))
        return(null);
    // Return the child
    return(**it);
}

const Attributes* ElementTag::GetAttributes() const
// Get attributes or NULL if none
{
    // If we have attributes, return them else NULL
    return(m_attributes.empty() ? NULL : &m_attributes);
}

//////////////////////////////////////////////////////////////////////
// Element without childs (like comments)
//////////////////////////////////////////////////////////////////////

ElementSimple::ElementSimple(const string& strName)
:   Element(strName)
{
}

bool ElementSimple::Add(Element* pChild)
// Add a child - do nothing
{
    // No child allowed
    return(false);
}

const Elements* ElementSimple::GetChilds() const
// Get childs - return NULL
{
    return(NULL);
}

const Element& ElementSimple::GetChild(PCSTR szName, int nIndex) const
// Get the nth element called szName - return null
{
    return(null);
}

const Attributes* ElementSimple::GetAttributes() const
// Get attributes - return NULL
{
    return(NULL);
}

//////////////////////////////////////////////////////////////////////
// Comment - Element named '!'
//////////////////////////////////////////////////////////////////////

ElementComment::ElementComment(const string& strComment)
:   ElementSimple(TEXT("!"))
{
    // Set the value
    AddValue(strComment);
}

//////////////////////////////////////////////////////////////////////
// Null element (for Element::null)
//////////////////////////////////////////////////////////////////////

ElementNull::ElementNull()
:   ElementSimple(TEXT(""))
{
}

bool ElementNull::IsNull() const
{
    return(true);
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

}
