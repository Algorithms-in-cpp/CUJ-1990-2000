import java.applet.*;
import java.awt.*;

public class j102awtappguimenu extends Applet {

 public static void main(String args[]) {
  j102awtappguimenu app = new j102awtappguimenu();
  app.init();
  app.start();
 }

 public void init() {
  AppletContext ac = null;
  try{ac = getAppletContext();}
  catch(NullPointerException npe){}
  new j102awtappguimenuFrame(ac);
 }
}

class j102awtappguimenuFrame extends Frame {
 MenuBar mb = new MenuBar();
 Menu file = new Menu("File");
 Menu edit = new Menu("Edit");
 Menu view = new Menu("View");
 Menu help = new Menu("Help");
 MenuItem fileOpen = new MenuItem("Open...");
 MenuItem separator = new MenuItem("-");
 MenuItem fileSaveAs = new MenuItem("Save As...");
 MenuItem editCut = new MenuItem("Cut");
 MenuItem editCopy = new MenuItem("Copy");
 MenuItem editPaste = new MenuItem("Paste");
 MenuItem helpAbout = new MenuItem("About...");
 AppletContext ac;

 j102awtappguimenuFrame(AppletContext ac) {
  super();
  this.ac = ac;

  /* Add menu items to menus */
  file.add(fileOpen);
  file.add(separator);
  file.add(fileSaveAs);
  edit.add(editCut);
  edit.add(editCopy);
  edit.add(editPaste);
  help.add(helpAbout);

  /* Add menus to menubar */
  mb.add(file);
  mb.add(edit);
  mb.add(view);
  mb.add(help);

  /* Set menubar */
  setMenuBar(mb);

  /* Size the frame */
  resize(200,200);

  /* Center the frame */
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle frameDim = bounds();
  move((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);

  /* Show the frame */
  show();
 }

 public boolean handleEvent(Event evt) {
  if (evt.id == Event.WINDOW_DESTROY) {
   dispose(); if (ac == null) System.exit(0);
  }
  return super.handleEvent(evt);
 }

 public boolean action(Event evt, Object obj) {
  if (evt.target == fileOpen);
  else if (evt.target == fileSaveAs);
  else if (evt.target == editCut);
  else if (evt.target == editCopy);
  else if (evt.target == editPaste);
  else if (evt.target == helpAbout);

  return true;
 }
}
