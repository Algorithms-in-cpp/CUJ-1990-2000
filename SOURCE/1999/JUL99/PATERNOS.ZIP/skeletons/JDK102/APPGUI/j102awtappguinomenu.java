import java.applet.*;
import java.awt.*;

public class j102awtappguinomenu extends Applet {

 public static void main(String args[]) {
  j102awtappguinomenu app = new j102awtappguinomenu();
  app.init();
  app.start();
 }

 public void init() {
  AppletContext ac = null;
  try{ac = getAppletContext();}
  catch(NullPointerException npe){}
  new j102awtappguinomenuFrame(ac);
 }
}

class j102awtappguinomenuFrame extends Frame {
 AppletContext ac;

 j102awtappguinomenuFrame(AppletContext ac) {
  super();
  this.ac = ac;

  /* Size the frame */
  resize(200,200);

  /* Center the frame */
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle frameDim = bounds();
  move((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);

  /* Show the frame */
  show();
 }

 public boolean handleEvent(Event evt) {
  if (evt.id == Event.WINDOW_DESTROY) {
   dispose(); if (ac == null) System.exit(0);
  }
  return super.handleEvent(evt);
 }
}
