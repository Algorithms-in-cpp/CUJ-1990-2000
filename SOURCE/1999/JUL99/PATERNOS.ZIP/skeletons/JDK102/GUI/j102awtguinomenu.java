import java.awt.*;

public class j102awtguinomenu {

 public static void main(String args[]) {
  new j102awtguinomenuFrame();
 }
}

class j102awtguinomenuFrame extends Frame {

 j102awtguinomenuFrame() {
  super();

  /* Size the frame */
  resize(200,200);

  /* Center the frame */
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle frameDim = bounds();
  move((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);

  /* Show the frame */
  show();
 }

 public boolean handleEvent(Event evt) {
  if (evt.id == Event.WINDOW_DESTROY) {
   dispose(); System.exit(0);
  }
  return super.handleEvent(evt);
 }
}
