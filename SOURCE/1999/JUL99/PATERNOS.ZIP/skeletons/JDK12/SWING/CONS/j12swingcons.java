import java.awt.*;

public class j12swingcons {

 public static void main(String args[]) { new j12swingcons(); }
 public j12swingcons(){}
}
