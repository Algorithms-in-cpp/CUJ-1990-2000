import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class j12swingguinomenu {

 public static void main(String args[]) {
  new j12swingguinomenuFrame();
 }
}

class j12swingguinomenuFrame extends JFrame {

 j12swingguinomenuFrame() {
  super();

  /* Components should be added to the container's content pane */
  Container cp = getContentPane();

  /* Add the window listener */
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent evt) {
    dispose(); System.exit(0);}});

  /* Size the frame */
  setSize(200,200);

  /* Center the frame */
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle frameDim = getBounds();
  setLocation((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);

  /* Show the frame */
  setVisible(true);
 }
}
