import java.applet.*;
import java.awt.*;
import javax.swing.*;

public class j12swingappletnomenu extends JApplet {
 public void init(){}
 public void start(){}
 public void stop(){}
 public void destroy(){}
}
