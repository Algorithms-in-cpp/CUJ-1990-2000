import java.applet.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class j12swingappguinomenu extends JApplet {

 public static void main(String args[]) {
  j12swingappguinomenu app = new j12swingappguinomenu();
  app.init();
  app.start();
 }

 public void init() {
  AppletContext ac = null;
  try{ac = getAppletContext();}
  catch(NullPointerException npe){}
  new j12swingappguinomenuFrame(ac);
 }
}

class j12swingappguinomenuFrame extends JFrame {
 AppletContext ac;

 j12swingappguinomenuFrame(AppletContext ac) {
  super();
  this.ac = ac;

  /* Components should be added to the container's content pane */
  Container cp = getContentPane();

  /* Add the window listener */
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent evt) {
    dispose(); if (j12swingappguinomenuFrame.this.ac == null) System.exit(0);}});

  /* Size the frame */
  setSize(200,200);

  /* Center the frame */
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle frameDim = getBounds();
  setLocation((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);

  /* Show the frame */
  setVisible(true);
 }
}
