import java.applet.*;
import java.awt.event.*;
import java.awt.*;

public class j12awtappguinomenu extends Applet {

 public static void main(String args[]) {
  j12awtappguinomenu app = new j12awtappguinomenu();
  app.init();
  app.start();
 }

 public void init() {
  AppletContext ac = null;
  try{ac = getAppletContext();}
  catch(NullPointerException npe){}
  new j12awtappguinomenuFrame(ac);
 }
}

class j12awtappguinomenuFrame extends Frame {
 AppletContext ac;

 j12awtappguinomenuFrame(AppletContext ac) {
  super();
  this.ac = ac;

  /* Add the window listener */
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent evt) {
    dispose(); if (j12awtappguinomenuFrame.this.ac == null) System.exit(0);}});

  /* Size the frame */
  setSize(200,200);

  /* Center the frame */
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle frameDim = getBounds();
  setLocation((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);

  /* Show the frame */
  setVisible(true);
 }
}
