import java.applet.*;
import java.awt.event.*;
import java.awt.*;

public class j12awtappguimenu extends Applet {

 public static void main(String args[]) {
  j12awtappguimenu app = new j12awtappguimenu();
  app.init();
  app.start();
 }

 public void init() {
  AppletContext ac = null;
  try{ac = getAppletContext();}
  catch(NullPointerException npe){}
  new j12awtappguimenuFrame(ac);
 }
}

class j12awtappguimenuFrame extends Frame implements ActionListener {
 MenuBar mb = new MenuBar();
 Menu file = new Menu("File");
 Menu edit = new Menu("Edit");
 Menu view = new Menu("View");
 Menu help = new Menu("Help");
 MenuItem fileOpen = new MenuItem("Open...");
 MenuItem separator = new MenuItem("-");
 MenuItem fileSaveAs = new MenuItem("Save As...");
 MenuItem editCut = new MenuItem("Cut");
 MenuItem editCopy = new MenuItem("Copy");
 MenuItem editPaste = new MenuItem("Paste");
 MenuItem helpAbout = new MenuItem("About...");
 AppletContext ac;

 j12awtappguimenuFrame(AppletContext ac) {
  super();
  this.ac = ac;

  /* Add menu items to menus */
  file.add(fileOpen);
  file.add(separator);
  file.add(fileSaveAs);
  edit.add(editCut);
  edit.add(editCopy);
  edit.add(editPaste);
  help.add(helpAbout);

  /* Add menus to menubar */
  mb.add(file);
  mb.add(edit);
  mb.add(view);
  mb.add(help);

  /* Set menubar */
  setMenuBar(mb);

  /* Add the action listeners */
  fileOpen.addActionListener(this);
  fileSaveAs.addActionListener(this);
  editCut.addActionListener(this);
  editCopy.addActionListener(this);
  editPaste.addActionListener(this);
  helpAbout.addActionListener(this);

  /* Add the window listener */
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent evt) {
    dispose(); if (j12awtappguimenuFrame.this.ac == null) System.exit(0);}});

  /* Size the frame */
  setSize(200,200);

  /* Center the frame */
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle frameDim = getBounds();
  setLocation((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);

  /* Show the frame */
  setVisible(true);
 }

 public void actionPerformed(ActionEvent evt) {
  Object obj = evt.getSource();

  if (obj == fileOpen);
  else if (obj == fileSaveAs);
  else if (obj == editCut);
  else if (obj == editCopy);
  else if (obj == editPaste);
  else if (obj == helpAbout);
 }
}
