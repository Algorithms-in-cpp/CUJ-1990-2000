import java.awt.event.*;
import java.awt.*;

public class j12awtguinomenu {

 public static void main(String args[]) {
  new j12awtguinomenuFrame();
 }
}

class j12awtguinomenuFrame extends Frame {

 j12awtguinomenuFrame() {
  super();

  /* Add the window listener */
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent evt) {
    dispose(); System.exit(0);}});

  /* Size the frame */
  setSize(200,200);

  /* Center the frame */
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle frameDim = getBounds();
  setLocation((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);

  /* Show the frame */
  setVisible(true);
 }
}
