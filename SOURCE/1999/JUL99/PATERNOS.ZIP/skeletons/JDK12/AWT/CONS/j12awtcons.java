import java.awt.*;

public class j12awtcons {

 public static void main(String args[]) { new j12awtcons(); }
 public j12awtcons(){}
}
