import java.applet.*;
import java.awt.*;
import com.sun.java.swing.*;
import java.awt.event.*;

public class j11swingappletmenu extends JApplet implements ActionListener {
 JMenuBar mb = new JMenuBar();
 JMenu file = new JMenu("File");
 JMenu edit = new JMenu("Edit");
 JMenu view = new JMenu("View");
 JMenu help = new JMenu("Help");
 JMenuItem fileOpen = new JMenuItem("Open...");
 JSeparator separator = new JSeparator();
 JMenuItem fileSaveAs = new JMenuItem("Save As...");
 JMenuItem editCut = new JMenuItem("Cut");
 JMenuItem editCopy = new JMenuItem("Copy");
 JMenuItem editPaste = new JMenuItem("Paste");
 JMenuItem helpAbout = new JMenuItem("About...");

 public void init() {

  /* Add menu items to menus */
  file.add(fileOpen);
  file.add(separator);
  file.add(fileSaveAs);
  edit.add(editCut);
  edit.add(editCopy);
  edit.add(editPaste);
  help.add(helpAbout);

  /* Add menus to menubar */
  mb.add(file);
  mb.add(edit);
  mb.add(view);
  mb.add(help);

  /* Set menubar */
  setJMenuBar(mb);

  /* Add the action listeners */
  fileOpen.addActionListener(this);
  fileSaveAs.addActionListener(this);
  editCut.addActionListener(this);
  editCopy.addActionListener(this);
  editPaste.addActionListener(this);
  helpAbout.addActionListener(this);
 }

 public void start(){}
 public void stop(){}
 public void destroy(){}

 public void actionPerformed(ActionEvent evt) {
  Object obj = evt.getSource();

  if (obj == fileOpen);
  else if (obj == fileSaveAs);
  else if (obj == editCut);
  else if (obj == editCopy);
  else if (obj == editPaste);
  else if (obj == helpAbout);
 }
}
