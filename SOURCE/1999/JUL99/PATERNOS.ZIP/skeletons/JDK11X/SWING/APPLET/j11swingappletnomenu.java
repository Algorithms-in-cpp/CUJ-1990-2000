import java.applet.*;
import java.awt.*;
import com.sun.java.swing.*;

public class j11swingappletnomenu extends JApplet {
 public void init(){}
 public void start(){}
 public void stop(){}
 public void destroy(){}
}
