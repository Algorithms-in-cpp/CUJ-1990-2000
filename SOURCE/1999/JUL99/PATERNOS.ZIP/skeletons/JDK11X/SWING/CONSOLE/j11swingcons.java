import java.awt.*;

public class j11swingcons {

 public static void main(String args[]) { new j11swingcons(); }
 public j11swingcons(){}
}
