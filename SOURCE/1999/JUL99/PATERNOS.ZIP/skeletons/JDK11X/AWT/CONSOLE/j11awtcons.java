import java.awt.*;

public class j11awtcons {

 public static void main(String args[]) { new j11awtcons(); }
 public j11awtcons(){}
}
