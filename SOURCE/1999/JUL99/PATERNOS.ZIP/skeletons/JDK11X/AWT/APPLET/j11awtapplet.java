import java.applet.*;
import java.awt.*;

public class j11awtapplet extends Applet {
 public void init(){}
 public void start(){}
 public void stop(){}
 public void destroy(){}
 public void paint(Graphics g){}
}
