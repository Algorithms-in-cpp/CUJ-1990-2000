import java.awt.*;

public class jdk102cons {

   public static void main(String args[]) { new jdk102cons(); }
   public jdk102cons(){}
}
