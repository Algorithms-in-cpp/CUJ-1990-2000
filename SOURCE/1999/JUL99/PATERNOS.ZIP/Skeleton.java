import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Skeleton
{
 public static void main(String args[])
 {
  new SkeletonFrame("Skeleton");
 }
}


class SkeletonFrame extends Frame implements ActionListener, TextListener, ItemListener
{
 Panel panel1 = new Panel();
 Panel panel2 = new Panel();
 Panel panel3 = new Panel();
 Panel panel4 = new Panel();
 Panel panel4a = new Panel();
 Panel panel5 = new Panel();
 TextField fileName = new TextField(30);
 CheckboxGroup programType = new CheckboxGroup();
 Checkbox consoleApp = new Checkbox("Console",programType,true);
 Checkbox guiApp = new Checkbox("GUI",programType,false);
 Checkbox applet = new Checkbox("Applet",programType,false);
 Checkbox appletGUI = new Checkbox("Applet/GUI",programType,false);
 CheckboxGroup jdkVer = new CheckboxGroup();
 Checkbox jdk102 = new Checkbox("JDK 1.0.2",jdkVer,true);
 Checkbox jdk11x = new Checkbox("JDK 1.1.x",jdkVer,false);
 Checkbox jdk12x = new Checkbox("JDK 1.2.x",jdkVer,false);
 Checkbox guiMenu = new Checkbox("Add Standard Menu to GUI Program",false);
 CheckboxGroup componentType = new CheckboxGroup();
 Checkbox awt = new Checkbox("AWT Components",componentType,true);
 Checkbox swing = new Checkbox("Swing Components",componentType,false);
 Button generate = new Button("Generate");
 Button close = new Button(" Close  ");
 Button about = new Button("About...");
 String newLine = System.getProperty("line.separator");
 int newLineLen = newLine.length();

 SkeletonFrame(String title)
 {
  super(title);
 
  /* Set the layouts */
  setLayout(new GridLayout(6,1));
  panel1.setLayout(new FlowLayout(FlowLayout.LEFT,3,3));
  panel2.setLayout(new FlowLayout(FlowLayout.LEFT,3,3));
  panel3.setLayout(new FlowLayout(FlowLayout.LEFT,3,3));
  panel4.setLayout(new FlowLayout(FlowLayout.LEFT,3,3));
  panel4a.setLayout(new FlowLayout(FlowLayout.LEFT,3,3));
  panel5.setLayout(new FlowLayout());
  
  /* Disable components */
  guiMenu.setEnabled(false);
  swing.setEnabled(false);
  generate.setEnabled(false);

  /* Add components to panels */
  panel1.add(new Label("Java Source File Name:"));
  panel1.add(fileName);
  panel2.add(new Label("JDK Version:"));
  panel2.add(jdk102);
  panel2.add(jdk11x);
  panel2.add(jdk12x);
  panel3.add(new Label("Component Type:"));
  panel3.add(awt);
  panel3.add(swing);
  panel4.add(new Label("Program Type:"));
  panel4.add(consoleApp);
  panel4.add(guiApp);
  panel4.add(applet);
  panel4.add(appletGUI);
  panel4a.add(new Label("Menu Option:"));
  panel4a.add(guiMenu);
  panel5.add(generate);
  panel5.add(close);
  panel5.add(about);

  /* Add panels to frame */
  add(panel1);
  add(panel2);
  add(panel3);
  add(panel4);
  add(panel4a);
  add(panel5);

  /* Add the listeners */
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent evt) {
    dispose();System.exit(0);}});

  generate.addActionListener(this);
  close.addActionListener(this);
  about.addActionListener(this);
  fileName.addTextListener(this);
  jdk102.addItemListener(this);
  jdk11x.addItemListener(this);
  jdk12x.addItemListener(this);
  awt.addItemListener(this);
  swing.addItemListener(this);
  consoleApp.addItemListener(this);
  guiApp.addItemListener(this);
  applet.addItemListener(this);
  appletGUI.addItemListener(this);

  /* Size the frame */
  pack();

  /* Get screen and frame dimensions and center the frame */  
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle winRect = getBounds();
  setLocation((screenDim.width - winRect.width) / 2,(screenDim.height - winRect.height) / 2);

  /* Set frame visible */
  setVisible(true);
 }

 public void itemStateChanged(ItemEvent evt)
 {
  Object obj = evt.getSource();
  
  if (obj == swing)
  {
   if (!consoleApp.getState())
    if (!guiMenu.isEnabled())
     guiMenu.setEnabled(true);
  }
  else if (obj == awt)
  {
   if (consoleApp.getState() || applet.getState())
    if (guiMenu.isEnabled())
    {
     guiMenu.setState(false);
     guiMenu.setEnabled(false);
    }
  }
  else if (obj == applet)
  {
   if (swing.getState())
   {
    if (!guiMenu.isEnabled())
     guiMenu.setEnabled(true);
   }
   else
   {
    if (guiMenu.isEnabled())
    {
     guiMenu.setState(false);
     guiMenu.setEnabled(false);
    }
   }
  }
  else if (obj == consoleApp)
  {
   if (guiMenu.isEnabled())
   {
    guiMenu.setState(false);
    guiMenu.setEnabled(false);
   }
  }
  else if (obj == guiApp || obj == appletGUI)
  {
   if (!guiMenu.isEnabled())
    guiMenu.setEnabled(true);
  }
  else if (obj == jdk102)
  {
   if (swing.isEnabled())
   {
    if (swing.getState())
    {
     swing.setState(false);
     awt.setState(true);
    }
    swing.setEnabled(false);
   }

   if (guiMenu.isEnabled() && applet.getState())
   {
    guiMenu.setState(false);
    guiMenu.setEnabled(false);
   } 
  }
  else if (obj == jdk11x || obj == jdk12x)
  {
   if (!swing.isEnabled())
    swing.setEnabled(true);
  }
 }
 
 public void textValueChanged(TextEvent evt)
 {
  Object obj = evt.getSource();

  if (((TextComponent)obj).getText().length() > 0 && !generate.isEnabled())
   generate.setEnabled(true);
  else if (((TextComponent)obj).getText().length() == 0 && generate.isEnabled())
   generate.setEnabled(false);
 }
 
 public void actionPerformed(ActionEvent evt)
 {
  FileWriter javaClassFile = null;
  Object obj = evt.getSource();
 
  if (obj == generate)
  {
   boolean bCreated = false;
   
   /* Get the file name */
   String strFileName = fileName.getText();

   /* Check for the .java extension in the file */
   if (strFileName.indexOf(".java") == -1)
    strFileName += ".java";

   /* Check if file exists */
   try
   {
    File file = new File(strFileName);
    if (file.exists())
    {
     String message[] = new String[1];
     message[0] = strFileName + " file already exists!";
     MessageBox msgBox = new MessageBox(this,"Skeleton",message);
     return;
    }
   }
   catch(SecurityException se)
   {
    String message[] = new String[1];
    message[0] = "Security violation creating " + strFileName + " !";
    MessageBox msgBox = new MessageBox(this,"Skeleton",message);
    return;    
   }

   /* Create the file */   
   try 
   {
    /* Get offset of .java extension */
    int extOffset = strFileName.indexOf(".java");
    
    /* Get offset of the last file separator */
    int fileOffset = strFileName.lastIndexOf(File.separator);
    
    /*
    ** Add one to the offset. This will either set the offset past the file separator
    ** if a path was included in the file name or it will set the offset to zero if a
    ** path was not included in the file name since the return from the lastIndexOf()
    ** method will be -1.
    */
    fileOffset++;
    
    javaClassFile = new FileWriter(strFileName);
   
    /* Determine what code type to generate */
    if (consoleApp.getState())
     bCreated = generateConsoleApp(javaClassFile,strFileName.substring(fileOffset,extOffset),jdk102.getState() ? jdk102 : (jdk11x.getState() ? jdk11x : jdk12x));
    else if (guiApp.getState())
     bCreated = generateAppletGUI(javaClassFile,strFileName.substring(fileOffset,extOffset),jdk102.getState() ? jdk102 : (jdk11x.getState() ? jdk11x : jdk12x),true);
    else if (applet.getState())
     bCreated = generateApplet(javaClassFile,strFileName.substring(fileOffset,extOffset),jdk102.getState() ? jdk102 : (jdk11x.getState() ? jdk11x : jdk12x));
    else if (appletGUI.getState())
     bCreated = generateAppletGUI(javaClassFile,strFileName.substring(fileOffset,extOffset),jdk102.getState() ? jdk102 : (jdk11x.getState() ? jdk11x : jdk12x),false);
   }    
   catch(IOException ioe)
   {
    String message[] = new String[1];
    message[0] = "Problem encountered creating " + strFileName + " file!";
    MessageBox msgBox = new MessageBox(this,"Skeleton",message);
    return;
   }
   finally 
   {
    try{javaClassFile.close();}
    catch(IOException ioe){}
    if (bCreated)
    {
     String message[] = new String[1];
     message[0] = "Java source file " + strFileName + " was successfully created!";
     MessageBox msgBox = new MessageBox(this,"Skeleton",message);
    }
   }
  }
  else if (obj == close)
   dispatchEvent(new WindowEvent(this,WindowEvent.WINDOW_CLOSING));
  else if (obj == about)
  {
   String message[] = new String[2];
   message[0] = "Skeleton Application";
   message[1] = "A Java 'Skeleton' Code Generator";
   MessageBox aboutMsg = new MessageBox(this,"About Skeleton",message);
  }
 }

 public boolean generateConsoleApp(FileWriter fw, String name, Object obj)
 {
  boolean bReturn = true;
  int nameLen = name.length();
  
  try
  {
   fw.write("import java.awt.*;" + newLine + newLine,0,"import java.awt.*;".length() + (newLineLen * 2));
   fw.write("public class " + name + " {" + newLine,0,15 + nameLen + newLineLen);
   fw.write(newLine + " public static void main(String args[]) { new " + name + "();" + " }" + newLine,0,51 + nameLen + (newLineLen * 2));
   fw.write(" public " + name + "(){}" + newLine,0,12 + nameLen + newLineLen);
   fw.write("}" + newLine,0,"}".length() + newLineLen);
  }
  catch(IOException ioe)
  {
   String message[] = new String[1];
   message[0] = "Problem encountered writing to " + name + ".java file!";
   MessageBox msgBox = new MessageBox(this,"Skeleton",message);
   bReturn = false;
  }
  return bReturn;
 }

 public boolean generateApplet(FileWriter fw, String name, Object obj)
 {
  boolean bReturn = true;
  boolean isSwing = swing.getState();
  boolean isAddMenuChecked = guiMenu.getState();
  int nameLen = name.length();
  
  try
  {
   fw.write("import java.applet.*;" + newLine,0,"import java.applet.*;".length() + newLineLen);
   fw.write("import java.awt.*;" + newLine,0,"import java.awt.*;".length() + newLineLen);

   if (isSwing)
   {
    if (obj == jdk11x)
     fw.write("import com.sun.java.swing.*;" + newLine,0,"import com.sun.java.swing.*;".length() + newLineLen);
    else
     fw.write("import javax.swing.*;" + newLine,0,"import javax.swing.*;".length() + newLineLen);

    if (isAddMenuChecked)
    {
     fw.write("import java.awt.event.*;" + newLine,0,"import java.awt.event.*;".length() + newLineLen);     
     fw.write(newLine + "public class " + name + " extends JApplet implements ActionListener {" + newLine,0,57 + nameLen + (newLineLen * 2));
    }
    else
     fw.write(newLine + "public class " + name + " extends JApplet {" + newLine,0,31 + nameLen + (newLineLen * 2));
   }
   else
    fw.write(newLine + "public class " + name + " extends Applet {" + newLine,0,30 + nameLen + (newLineLen * 2));

   if (isAddMenuChecked)
   {
    createSwingMenuComponents(fw);
    fw.write(newLine + " public void init() {" + newLine,0," public void init() {".length() + (newLineLen * 2));
    addMenuComponents(fw);
    addMenuListener(fw);
    fw.write(" }" + newLine + newLine,0," }".length() + (newLineLen * 2));
   }
   else
    fw.write(" public void init(){}" + newLine,0," public void init(){}".length() + newLineLen);

   fw.write(" public void start(){}" + newLine,0," public void start(){}".length() + newLineLen);
   fw.write(" public void stop(){}" + newLine,0," public void stop(){}".length() + newLineLen);
   fw.write(" public void destroy(){}" + newLine,0," public void destroy(){}".length() + newLineLen);

   if (!isSwing)
    fw.write(" public void paint(Graphics g){}" + newLine,0," public void paint(Graphics g){}".length() + newLineLen);

   if (isAddMenuChecked)
    addActionPerformed(fw);

   fw.write("}" + newLine,0,"}".length() + newLineLen);
  }
  catch(IOException ioe)
  {
   String message[] = new String[1];
   message[0] = "Problem encountered writing to " + name + ".java file!";
   MessageBox msgBox = new MessageBox(this,"Skeleton",message);
   bReturn = false;
  }
  return bReturn;
 }
 
 public boolean generateAppletGUI(FileWriter fw, String name, Object obj, boolean guiOnly)
 {
  boolean bReturn = true;
  boolean isAddMenuChecked = guiMenu.getState();
  boolean isSwing = swing.getState();
  int nameLen = name.length();
  
  try
  {
   if (!guiOnly)
    fw.write("import java.applet.*;" + newLine,0,"import java.applet.*;".length() + newLineLen);

   if (obj == jdk11x || obj == jdk12x)
    fw.write("import java.awt.event.*;" + newLine,0,"import java.awt.event.*;".length() + newLineLen);

   fw.write("import java.awt.*;" + newLine,0,"import java.awt.*;".length() + newLineLen);

   if (isSwing)
   {
    if (obj == jdk11x)
     fw.write("import com.sun.java.swing.*;" + newLine,0,"import com.sun.java.swing.*;".length() + newLineLen);
    else
     fw.write("import javax.swing.*;" + newLine,0,"import javax.swing.*;".length() + newLineLen);
   }

   if (guiOnly)
    fw.write(newLine + "public class " + name + " {" + newLine,0,2 + "public class ".length() + nameLen + (newLineLen * 2));
   else
   {
    if (isSwing)
     fw.write(newLine + "public class " + name + " extends JApplet {" + newLine,0,31 + nameLen + (newLineLen * 2));
    else
     fw.write(newLine + "public class " + name + " extends Applet {" + newLine,0,30 + nameLen + (newLineLen * 2));
   }

   fw.write(newLine + " public static void main(String args[]) {" + newLine,0," public static void main(String args[]) {".length() + (newLineLen * 2));

   if (!guiOnly)
   {
    fw.write("  " + name + " app = new " + name + "();" + newLine,0,16 + (nameLen * 2) + newLineLen);
    fw.write("  app.init();" + newLine + "  app.start();" + newLine + " }" + newLine,0,29 + (newLineLen * 3));
    fw.write(newLine + " public void init() {" + newLine,0," public void init() {".length() + (newLineLen * 2));
    fw.write("  AppletContext ac = null;" + newLine,0,"  AppletContext ac = null;".length() + newLineLen);
    fw.write("  try{ac = getAppletContext();}" + newLine,0,"  try{ac = getAppletContext();}".length() + newLineLen);
    fw.write("  catch(NullPointerException npe){}" + newLine,0,"  catch(NullPointerException npe){}".length() + newLineLen);
    fw.write("  new " + name + "Frame(ac);" + newLine,0,16 + nameLen + newLineLen);
   }
   else
    fw.write("  new " + name + "Frame();" + newLine,0,14 + nameLen + newLineLen);

   fw.write(" }" + newLine,0," }".length() + newLineLen);
   fw.write("}" + newLine,0,1 + newLineLen);

   if (isSwing)
    fw.write(newLine + "class " + name + "Frame extends JFrame ",0,27 + nameLen + newLineLen);
   else
    fw.write(newLine + "class " + name + "Frame extends Frame ",0,26 + nameLen + newLineLen);

   if (isAddMenuChecked && (obj == jdk11x || obj == jdk12x))
    fw.write("implements ActionListener {" + newLine,0,"implements ActionListener {".length() + newLineLen);
   else
    fw.write("{" + newLine,0,1 + newLineLen);

   if (isAddMenuChecked)
   {
    if (isSwing)
     createSwingMenuComponents(fw);
    else
     createAWTMenuComponents(fw);
   }

   if (!guiOnly)
   {
    fw.write(" AppletContext ac;" + newLine,0," AppletContext ac;".length() + newLineLen);
    fw.write(newLine + " " + name + "Frame(AppletContext ac) {" + newLine,0,26 + nameLen + (newLineLen * 2));
   }
   else
    fw.write(newLine + " " + name + "Frame() {" + newLine,0,10 + nameLen + (newLineLen * 2));

   fw.write("  super();" + newLine,0,10 + newLineLen);

   if (!guiOnly)
    fw.write("  this.ac = ac;" + newLine,0,"  this.ac = ac;".length() + newLineLen);

   if (isSwing)
   {
    fw.write(newLine + "  /* Components should be added to the container's content pane */" + newLine,0,"  /* Components should be added to the container's content pane */".length() + (newLineLen * 2));
    fw.write("  Container cp = getContentPane();" + newLine,0,"  Container cp = getContentPane();".length() + newLineLen);
   }

   if (isAddMenuChecked)
    addMenuComponents(fw);

   if (obj == jdk102)
   {
    fw.write(newLine + "  /* Size the frame */" + newLine,0,"  /* Size the frame */".length() + (newLineLen * 2));
    fw.write("  resize(200,200);" + newLine,0,"  resize(200,200);".length() + newLineLen);
    fw.write(newLine + "  /* Center the frame */" + newLine,0,"  /* Center the frame */".length() + (newLineLen * 2));
    fw.write("  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();" + newLine,0,"  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();".length() + newLineLen);
    fw.write("  Rectangle frameDim = bounds();" + newLine,0,"  Rectangle frameDim = bounds();".length() + newLineLen);
    fw.write("  move((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);" + newLine,0,"  move((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);".length() + newLineLen);
    fw.write(newLine + "  /* Show the frame */" + newLine,0,"  /* Show the frame */".length() + (newLineLen * 2));
    fw.write("  show();" + newLine + " }" + newLine,0,11 + (newLineLen * 2));
    fw.write(newLine + " public boolean handleEvent(Event evt) {" + newLine,0," public boolean handleEvent(Event evt) {".length() + (newLineLen * 2));
    fw.write("  if (evt.id == Event.WINDOW_DESTROY) {" + newLine,0,"  if (evt.id == Event.WINDOW_DESTROY) {".length() + newLineLen);

    if (!guiOnly)
     fw.write("   dispose(); if (ac == null) System.exit(0);" + newLine,0,"   dispose(); if (ac == null) System.exit(0);".length() + newLineLen);
    else
     fw.write("   dispose(); System.exit(0);" + newLine,0,"   dispose(); System.exit(0);".length() + newLineLen);

    fw.write("  }" + newLine + "  return super.handleEvent(evt);" + newLine + " }" + newLine,0,5 + "  return super.handleEvent(evt);".length() + (newLineLen * 3));

    if (isAddMenuChecked)
    {
     fw.write(newLine + " public boolean action(Event evt, Object obj) {" + newLine,0," public boolean action(Event evt, Object obj) {".length() + (newLineLen * 2));
     fw.write("  if (evt.target == fileOpen);" + newLine,0,"  if (evt.target == fileOpen);".length() + newLineLen);
     fw.write("  else if (evt.target == fileSaveAs);" + newLine,0,"  else if (evt.target == fileSaveAs);".length() + newLineLen);
     fw.write("  else if (evt.target == editCut);" + newLine,0,"  else if (evt.target == editCut);".length() + newLineLen);
     fw.write("  else if (evt.target == editCopy);" + newLine,0,"  else if (evt.target == editCopy);".length() + newLineLen);
     fw.write("  else if (evt.target == editPaste);" + newLine,0,"  else if (evt.target == editPaste);".length() + newLineLen);
     fw.write("  else if (evt.target == helpAbout);" + newLine,0,"  else if (evt.target == helpAbout);".length() + newLineLen);
     fw.write(newLine + "  return true;" + newLine,0,"  return true;".length() + (newLineLen * 2));
     fw.write(" }" + newLine,0,2 + newLineLen);
    }

    fw.write("}" + newLine,0,1 + newLineLen);
   }
   else
   {
    if (isAddMenuChecked)
     addMenuListener(fw);

    fw.write(newLine + "  /* Add the window listener */" + newLine,0,"  /* Add the window listener */".length() + (newLineLen * 2));
    fw.write("  addWindowListener(new WindowAdapter() {" + newLine,0,"  addWindowListener(new WindowAdapter() {".length() + newLineLen);
    fw.write("   public void windowClosing(WindowEvent evt) {" + newLine,0,"   public void windowClosing(WindowEvent evt) {".length() + newLineLen);

    if (!guiOnly)
     fw.write("    dispose(); if (" + name + "Frame.this.ac == null) System.exit(0);}});" + newLine,0,"    dispose(); if (".length() + nameLen + "Frame.this.ac == null) System.exit(0);}});".length() + newLineLen);
    else
     fw.write("    dispose(); System.exit(0);}});" + newLine,0,"    dispose(); System.exit(0);}});".length() + newLineLen);

    fw.write(newLine + "  /* Size the frame */" + newLine,0,"  /* Size the frame */".length() + (newLineLen * 2));
    fw.write("  setSize(200,200);" + newLine,0,"  setSize(200,200);".length() + newLineLen);
    fw.write(newLine + "  /* Center the frame */" + newLine,0,"  /* Center the frame */".length() + (newLineLen * 2));
    fw.write("  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();" + newLine,0,"  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();".length() + newLineLen);
    fw.write("  Rectangle frameDim = getBounds();" + newLine,0,"  Rectangle frameDim = getBounds();".length() + newLineLen);
    fw.write("  setLocation((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);" + newLine,0,"  setLocation((screenDim.width - frameDim.width) / 2,(screenDim.height - frameDim.height) / 2);".length() + newLineLen);
    fw.write(newLine + "  /* Show the frame */" + newLine,0,"  /* Show the frame */".length() + (newLineLen * 2));
    fw.write("  setVisible(true);" + newLine,0,"  setVisible(true);".length() + newLineLen);
    fw.write(" }" + newLine,0,2 + newLineLen);

    if (isAddMenuChecked)
     addActionPerformed(fw);

    fw.write("}" + newLine,0,1 + newLineLen);
   }
  }
  catch(IOException ioe)
  {
   String message[] = new String[1];
   message[0] = "Problem encountered writing to " + name + ".java file!";
   MessageBox msgBox = new MessageBox(this,"Skeleton",message);
   bReturn = false;
  }  
  return bReturn;
 }

 public void addMenuListener(FileWriter fw) throws IOException
 {
  fw.write(newLine + "  /* Add the action listeners */" + newLine,0,"  /* Add the action listeners */".length() + (newLineLen * 2));
  fw.write("  fileOpen.addActionListener(this);" + newLine,0,"  fileOpen.addActionListener(this);".length() + newLineLen);
  fw.write("  fileSaveAs.addActionListener(this);" + newLine,0,"  fileSaveAs.addActionListener(this);".length() + newLineLen);
  fw.write("  editCut.addActionListener(this);" + newLine,0,"  editCut.addActionListener(this);".length() + newLineLen);
  fw.write("  editCopy.addActionListener(this);" + newLine,0,"  editCopy.addActionListener(this);".length() + newLineLen);
  fw.write("  editPaste.addActionListener(this);" + newLine,0,"  editPaste.addActionListener(this);".length() + newLineLen);
  fw.write("  helpAbout.addActionListener(this);" + newLine,0,"  helpAbout.addActionListener(this);".length() + newLineLen);
 }

 public void addActionPerformed(FileWriter fw) throws IOException
 {
  fw.write(newLine + " public void actionPerformed(ActionEvent evt) {" + newLine,0," public void actionPerformed(ActionEvent evt) {".length() + (newLineLen * 2));
  fw.write("  Object obj = evt.getSource();" + newLine,0,"  Object obj = evt.getSource();".length() + newLineLen);
  fw.write(newLine + "  if (obj == fileOpen);" + newLine,0,"  if (obj == fileOpen);".length() + (newLineLen * 2));
  fw.write("  else if (obj == fileSaveAs);" + newLine,0,"  else if (obj == fileSaveAs);".length() + newLineLen);
  fw.write("  else if (obj == editCut);" + newLine,0,"  else if (obj == editCut);".length() + newLineLen);
  fw.write("  else if (obj == editCopy);" + newLine,0,"  else if (obj == editCopy);".length() + newLineLen);
  fw.write("  else if (obj == editPaste);" + newLine,0,"  else if (obj == editPaste);".length() + newLineLen);
  fw.write("  else if (obj == helpAbout);" + newLine,0,"  else if (obj == helpAbout);".length() + newLineLen);
  fw.write(" }" + newLine,0,2 + newLineLen);
 }
 
 public void createAWTMenuComponents(FileWriter fw) throws IOException
 {
  fw.write(" MenuBar mb = new MenuBar();" + newLine,0," MenuBar mb = new MenuBar();".length() + newLineLen);
  fw.write(" Menu file = new Menu(\"File\");" + newLine,0," Menu file = new Menu(\"File\");".length() + newLineLen);
  fw.write(" Menu edit = new Menu(\"Edit\");" + newLine,0," Menu edit = new Menu(\"Edit\");".length() + newLineLen);
  fw.write(" Menu view = new Menu(\"View\");" + newLine,0," Menu edit = new Menu(\"View\");".length() + newLineLen);
  fw.write(" Menu help = new Menu(\"Help\");" + newLine,0," Menu help = new Menu(\"Help\");".length() + newLineLen);
  fw.write(" MenuItem fileOpen = new MenuItem(\"Open...\");" + newLine,0," MenuItem fileOpen = new MenuItem(\"Open...\");".length() + newLineLen);
  fw.write(" MenuItem separator = new MenuItem(\"-\");" + newLine,0," MenuItem separator = new MenuItem(\"-\");".length() + newLineLen);
  fw.write(" MenuItem fileSaveAs = new MenuItem(\"Save As...\");" + newLine,0," MenuItem fileSaveAs = new MenuItem(\"Save As...\");".length() + newLineLen);
  fw.write(" MenuItem editCut = new MenuItem(\"Cut\");" + newLine,0," MenuItem editCut = new MenuItem(\"Cut\");".length() + newLineLen);
  fw.write(" MenuItem editCopy = new MenuItem(\"Copy\");" + newLine,0," MenuItem editCopy = new MenuItem(\"Copy\");".length() + newLineLen);
  fw.write(" MenuItem editPaste = new MenuItem(\"Paste\");" + newLine,0," MenuItem editPaste = new MenuItem(\"Paste\");".length() + newLineLen);
  fw.write(" MenuItem helpAbout = new MenuItem(\"About...\");" + newLine,0," MenuItem helpAbout = new MenuItem(\"About...\");".length() + newLineLen);
 }
 
 public void createSwingMenuComponents(FileWriter fw) throws IOException
 {
  fw.write(" JMenuBar mb = new JMenuBar();" + newLine,0," JMenuBar mb = new JMenuBar();".length() + newLineLen);
  fw.write(" JMenu file = new JMenu(\"File\");" + newLine,0," JMenu file = new JMenu(\"File\");".length() + newLineLen);
  fw.write(" JMenu edit = new JMenu(\"Edit\");" + newLine,0," JMenu edit = new JMenu(\"Edit\");".length() + newLineLen);
  fw.write(" JMenu view = new JMenu(\"View\");" + newLine,0," JMenu edit = new JMenu(\"View\");".length() + newLineLen);
  fw.write(" JMenu help = new JMenu(\"Help\");" + newLine,0," JMenu help = new JMenu(\"Help\");".length() + newLineLen);
  fw.write(" JMenuItem fileOpen = new JMenuItem(\"Open...\");" + newLine,0," JMenuItem fileOpen = new JMenuItem(\"Open...\");".length() + newLineLen);
  fw.write(" JSeparator separator = new JSeparator();" + newLine,0," JSeparator separator = new JSeparator();".length() + newLineLen);
  fw.write(" JMenuItem fileSaveAs = new JMenuItem(\"Save As...\");" + newLine,0," JMenuItem fileSaveAs = new JMenuItem(\"Save As...\");".length() + newLineLen);
  fw.write(" JMenuItem editCut = new JMenuItem(\"Cut\");" + newLine,0," JMenuItem editCut = new JMenuItem(\"Cut\");".length() + newLineLen);
  fw.write(" JMenuItem editCopy = new JMenuItem(\"Copy\");" + newLine,0," JMenuItem editCopy = new JMenuItem(\"Copy\");".length() + newLineLen);
  fw.write(" JMenuItem editPaste = new JMenuItem(\"Paste\");" + newLine,0," JMenuItem editPaste = new JMenuItem(\"Paste\");".length() + newLineLen);
  fw.write(" JMenuItem helpAbout = new JMenuItem(\"About...\");" + newLine,0," JMenuItem helpAbout = new JMenuItem(\"About...\");".length() + newLineLen);
 }
 
 public void addMenuComponents(FileWriter fw) throws IOException
 {
  fw.write(newLine + "  /* Add menu items to menus */" + newLine,0,"  /* Add menu items to menus */".length() + (newLineLen * 2));
  fw.write("  file.add(fileOpen);" + newLine,0,"  file.add(fileOpen);".length() + newLineLen);
  fw.write("  file.add(separator);" + newLine,0,"  file.add(separator);".length() + newLineLen);
  fw.write("  file.add(fileSaveAs);" + newLine,0,"  file.add(fileSaveAs);".length() + newLineLen);
  fw.write("  edit.add(editCut);" + newLine,0,"  edit.add(editCut);".length() + newLineLen);
  fw.write("  edit.add(editCopy);" + newLine,0,"  edit.add(editCopy);".length() + newLineLen);
  fw.write("  edit.add(editPaste);" + newLine,0,"  edit.add(editPaste);".length() + newLineLen);
  fw.write("  help.add(helpAbout);" + newLine,0,"  help.add(helpAbout);".length() + newLineLen);
  fw.write(newLine + "  /* Add menus to menubar */" + newLine,0,"  /* Add menus to menubar */".length() + (newLineLen * 2));
  fw.write("  mb.add(file);" + newLine,0,"  mb.add(file);".length() + newLineLen);
  fw.write("  mb.add(edit);" + newLine,0,"  mb.add(edit);".length() + newLineLen);
  fw.write("  mb.add(view);" + newLine,0,"  mb.add(view);".length() + newLineLen);
  fw.write("  mb.add(help);" + newLine,0,"  mb.add(help);".length() + newLineLen);
  fw.write(newLine + "  /* Set menubar */" + newLine,0,"  /* Set menubar */".length() + (newLineLen * 2));
  if (swing.getState())
   fw.write("  setJMenuBar(mb);" + newLine,0,"  setJMenuBar(mb);".length() + newLineLen);
  else
   fw.write("  setMenuBar(mb);" + newLine,0,"  setMenuBar(mb);".length() + newLineLen);
 }
}


class MessageBox extends Dialog implements ActionListener
{
 Panel panel1 = new Panel();
 Panel panel2 = new Panel();
 Button ok = new Button("OK");

 MessageBox(Frame owner,String title,String[] message)
 {
  /* Create a modal dialox box */
  super(owner,title,true);

  /* Set the layout manager */
  panel1.setLayout(new GridLayout(message.length,1));

  /* Add the panels */
  add("North",panel1);
  add("South",panel2);
  
  /* Add components */
  for (int i = 0;i < message.length;i++)
   panel1.add(new Label(message[i],Label.CENTER));
  panel2.add(ok);
  
  /* Add the listeners */
  ok.addActionListener(this);
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent evt) {
    dispose();}});

  /* Size the dialog */
  pack();
  
  /* Make the dialog unresizable */
  setResizable(false);
  
  /* Get screen and window dimensions and center the window */  
  Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
  Rectangle winRect = getBounds();
  setLocation((screenDim.width - winRect.width) / 2,(screenDim.height - winRect.height) / 2);

  /* Set dialog visible */
  setVisible(true);
 }
 
 public void actionPerformed(ActionEvent evt)
 {
  Object obj = evt.getSource();
  
  if (obj == ok)
   dispatchEvent(new WindowEvent(this,WindowEvent.WINDOW_CLOSING));
 }
}
