Option Explicit
Implements IWordStream
     
Private sub Class_Initialize()
    Dim doc as New Word.Document
    ' do interesting things with doc
End Sub
     
Private Sub 
IWordStream_AddText(ByVal str As String)
    ... vb code ...
End Sub
     
Private Sub 
IWordStream_SetUnderLine
    (ByVal underlinetype As Long)
    ... vb code ...
End Sub
     
Private Sub 
IWordStream_SetJustification 
    (ByVal justifytype As Long)
    ... vb code ...
End Sub
     
Private Sub 
IWordStream_SetBold(ByVal bold As Long)
    ... vb code ...
End Sub
     
Private Sub 
IWordStream_SetItalic(ByVal italic As Long)
    ... vb code ...
End Sub
     
Private Sub 
IWordStream_SaveAs(ByVal str As String )
    ... vb code ...
End Sub
     
Private Sub IWordStream_PrintOut ( )
    ... vb code ...
End Sub
     
Private Property 
Let IWordStream_FontSize(ByVal size as Single)
    m_size = size
End Property
     
Private Property 
Get IWordStream_FontSize( ) As Single
    IWordStream_FontSize = m_size
End Property
