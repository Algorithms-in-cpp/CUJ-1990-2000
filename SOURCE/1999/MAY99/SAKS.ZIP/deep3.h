// deep3.h

#ifndef DEEP_H_INCLUDED
#define DEEP_H_INCLUDED

template <typename T>
class deep_pointer
    {
public:
    deep_pointer();
    deep_pointer(T *p);
    operator T *&();
    operator T const *const &() const;
private:
    T *actual_pointer;
    };

template <typename T>
inline
deep_pointer<T>::deep_pointer()
    {
    }

template <typename T>
inline
deep_pointer<T>::deep_pointer(T *p)
    {
    actual_pointer = p;
    }

template <typename T>
inline
deep_pointer<T>::operator T *&()
    {
    return actual_pointer;
    }

template <typename T>
inline
deep_pointer<T>::operator T const *const &() const
    {
    return actual_pointer;
    }

#endif
