// deep2.h

#ifndef DEEP_H_INCLUDED
#define DEEP_H_INCLUDED

template <typename T>
class deep_pointer
    {
public:
    T *&operator()();
    T const *const &operator()() const;
private:
    T *actual_pointer;
    };

template <typename T>
inline
T *&deep_pointer<T>::operator()()
    {
    return actual_pointer;
    }

template <typename T>
inline
T const *const &
deep_pointer<T>::operator()() const
    {
    return actual_pointer;
    }

#endif
