// deep.h

#ifndef DEEP_H_INCLUDED
#define DEEP_H_INCLUDED

template <typename T>
class deep_pointer
    {
public:
    T *&value();
    T const *const &value() const;
private:
    T *actual_pointer;
    };

template <typename T>
inline
T *&deep_pointer<T>::value()
    {
    return actual_pointer;
    }

template <typename T>
inline
T const *const &
deep_pointer<T>::value() const
    {
    return actual_pointer;
    }

#endif
