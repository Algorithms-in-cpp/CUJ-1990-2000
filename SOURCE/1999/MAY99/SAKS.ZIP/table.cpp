// table.cpp

#include <stdio.h>
#include <string.h>

#include "deep4.h"
#include "table.h"

struct list_node
    {
    unsigned number;
    deep_pointer<list_node> next;
    };

struct cross_reference_table::tree_node
    {
    deep_pointer<char> word;
    deep_pointer<list_node> first, last;
    deep_pointer<tree_node> left, right;
    };

cross_reference_table::tree_node *
cross_reference_table::add_tree
(tree_node *t, char const *w, unsigned n)
    {
    int cmp;
    if (t == NULL)
        {
        t = new tree_node;
        t->word = new char [strlen(w) + 1];
        strcpy(t->word, w);
        t->first = new list_node;
        t->first->number = n;
        t->first->next = NULL;
        t->last = t->first;
        t->left = t->right = NULL;
        }
    else if ((cmp = strcmp(w, t->word)) < 0)
        t->left = add_tree(t->left, w, n);
    else if (cmp > 0)
        t->right = add_tree(t->right, w, n);
    else if (n != t->last->number)
        {
        t->last->next = new list_node;
        t->last = t->last->next;
        t->last->number = n;
        t->last->next = NULL;
        }
    return t;
    }

void
cross_reference_table::put_tree
(tree_node const *t)
    {
    if (t != NULL)
        {
        put_tree(t->left);
        printf("%12s:", t->word);
        list_node const *p = t->first;
        for (; p != NULL; p = p->next)
            printf(" %4d", p->number);
        printf("\n");
        put_tree(t->right);
        }
    }

