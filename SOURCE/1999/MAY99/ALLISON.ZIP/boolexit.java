public class Nested {
    public static void main(String[] args) {
        boolean done1 = false;
        for (int i = 0; !done1 && i < 2; ++i) {
            boolean done2 = false;
            for (int j = 0; !done2 && j < 2; ++j) {
                boolean done3 = false;
                for (int k = 0; !done3 && k < 2; ++k) {
                    System.out.println(i + "," + j + "," + k);
                    if (k == 1)
                        done3 = done2 = done1 = true;
                }
            }
        }

    }
}

/* Output:
0,0,0
0,0,1
*/
