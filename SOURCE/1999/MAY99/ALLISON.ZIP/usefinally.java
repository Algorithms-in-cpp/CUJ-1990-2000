import java.io.*;

public class Copy {
    static void copy(String file)
    throws IOException {
        FileReader r = new FileReader(file);
        int c;
    
        try {
            while ((c = r.read()) != -1)
                System.out.write(c);
        }
        finally {
            r.close();
        }
    }

    public static void main(String[] args) {
        try {
            copy(args[0]);
        }
        catch (IOException x) {
            System.out.println(x);
        }
    }
}

/* Output with a non-existent file:
java.io.FileNotFoundException: foo (The system cannot find 
the file specified)
*/

                                                       
                                                       
                                                       
                                                       
               
