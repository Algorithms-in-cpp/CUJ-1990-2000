import java.util.*;    // for class Random

public class Deep2 {
    static long seed;

    static int f() {
        System.out.println("doing f...");
        return g();
    }

    static int g() {
        System.out.println("doing g...");
        return h();
    }

    static int h() {
        Random r = new Random(seed);
        int code = r.nextInt(2);
        if (code == 0)
            System.out.println("doing h...");
        return code;
    }

    public static void main(String[] args) {
        seed = Long.parseLong(args[0]);
        int code = f();
        if (code != 0)
            System.out.println("f() returned " + code);
        System.out.println("back in main");
    }
}

/* Output of "java Deep2 0":
doing f...
doing g...
doing h...
back in main

  Output of "java Deep2 1":
doing f...
doing g...
f() returned 1
back in main
*/
