import java.io.*;

public class Hilo2
{
    public static void main (String[] args)
    throws IOException {
        BufferedReader in =
            new BufferedReader(new InputStreamReader(System.in));
        outer:
        for (;;) {
            int lo = 1, hi = 100, guess = 0;
            while (lo <= hi) {
                guess = (lo + hi) / 2;
                System.out.println("Is it " + guess + "?");
                char r = in.readLine().toUpperCase().charAt(0);
                
                if (r == 'L')
                    lo = guess + 1;
                else if (r == 'H')
                    hi = guess - 1;
                else if (r == 'Q')
                    break outer;
                else if (r != 'Y')
                    System.out.println("Try again...");
                else
                    break;
            }
            
            if (lo > hi)
                System.out.println("You cheated!");
            else
                System.out.println("Your number was " + guess);

            System.out.println("Want to play again?");
            if (in.readLine().toUpperCase().charAt(0) != 'Y')
                break;
        }
    }
}
