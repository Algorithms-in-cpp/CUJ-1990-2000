public class Deep {
    
    static void f() {
        System.out.println("doing f...");
        g();
    }

    static void g() {
        System.out.println("doing g...");
        h();
    }

    static void h() {
        System.out.println("doing h...");
    }

    public static void main(String[] args) {
        f();
        System.out.println("back in main");
    }
}

/* Output:
doing f...
doing g...
doing h...
back in main
*/

