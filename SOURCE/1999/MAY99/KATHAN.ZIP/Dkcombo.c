Author:  Joseph Kathan <jgk@pagesz.net> at Internet
Date:    2/4/99  5:52 PM
Priority: Normal
TO: Amy Pettle at MFI-Lawrence
CC: joeka@medcmp.com at Internet
Subject: Manuscript Submission
------------------------------- Message Contents -------------------------------
#define UNIX
#include <stdlib.h>
#include <stdio.h>
#ifdef UNIX
#include <signal.h>
#endif
#ifdef WINDOWS
#include <windows.h>
#endif
     
#define LOGFILE "pid.log"
     
main(int argc, char* argv[])
{
FILE *fp;
#ifdef UNIX
pid_t pid;
#endif
#ifdef WINDOWS
DWORD pid;
HANDLE h;
DWORD a;
#endif
     
fp = fopen(LOGFILE,"r");
while (!feof(fp))
    {
    fscanf(fp,"%u",&pid);
    if (!feof(fp))
        {
#ifdef UNIX
        kill(pid,SIGTERM);
#endif
#ifdef WINDOWS
        a = 1;
        h = OpenProcess(a,1,pid);
        TerminateProcess(h,1);
#endif
        }
    }
fclose(fp);
     
exit(0);
}
     
