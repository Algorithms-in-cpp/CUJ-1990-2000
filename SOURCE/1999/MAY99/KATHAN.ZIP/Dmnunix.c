Author:  Joseph Kathan <jgk@pagesz.net> at Internet
Date:    2/4/99  5:52 PM
Priority: Normal
TO: Amy Pettle at MFI-Lawrence
CC: joeka@medcmp.com at Internet
Subject: Manuscript Submission
------------------------------- Message Contents -------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <setjmp.h>
     
#define LOGFILE  "pid.log"
     
void sig_handler(int sig);
void register_daemon(int pid);
     
int               kill_sig = 0;
sig_atomic_t      jmpok;
static sigjmp_buf jmpbuf;
     
int main(int argc, char *argv[])
{
pid_t pid;
     
pid = getpid();
register_daemon(pid);
     
signal(SIGTERM,sig_handler);
kill_sig = sigsetjmp(jmpbuf, 0);
     
if (kill_sig)
    {
    exit(0);
    }
jmpok = 1;
     
for(;;);
     
exit(0);
}
     
void sig_handler(int sig)
{
if (!jmpok)
    return;
     
if (sig == SIGTERM)
    {
    signal(SIGTERM,SIG_DFL);
    jmpok = 0;
    siglongjmp(jmpbuf, 0);
    }
     
return;
}
     
void register_daemon(int pid)
{
FILE *fp;
     
fp = fopen(LOGFILE, "a");
fprintf(fp,"%u\n",pid);
fclose(fp);
     
return;
}
     
