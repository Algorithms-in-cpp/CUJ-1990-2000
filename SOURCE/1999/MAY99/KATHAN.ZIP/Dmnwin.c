Author:  Joseph Kathan <jgk@pagesz.net> at Internet
Date:    2/4/99  5:52 PM
Priority: Normal
TO: Amy Pettle at MFI-Lawrence
CC: joeka@medcmp.com at Internet
Subject: Manuscript Submission
------------------------------- Message Contents -------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>
     
#define LOGFILE  "pid.log"
     
BOOL WINAPI MyHandler(DWORD ddwCtrlType); 
void register_daemon(int pid);
     
int main(int argc, char *argv[])
{
DWORD pid;
     
pid = GetCurrentProcessId();
register_daemon(pid);
     
SetConsoleCtrlHandler((PHANDLER_ROUTINE)MyHandler,TRUE);
     
for(;;);
     
exit(0);
}
     
BOOL WINAPI MyHandler(DWORD ddwCtrlType) 
{
DWORD exitcode;
HANDLE h = GetCurrentProcess();
     
GetExitCodeProcess(h, &exitcode);
ExitProcess(exitcode);
     
return TRUE;
}
     
void register_daemon(int pid)
{
FILE *fp;
     
fp = fopen(LOGFILE, "a");
fprintf(fp,"%u\n",pid);
fclose(fp);
     
return;
}
     
