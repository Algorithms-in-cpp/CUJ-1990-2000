Author:  Joseph Kathan <jgk@pagesz.net> at Internet
Date:    2/4/99  5:52 PM
Priority: Normal
TO: Amy Pettle at MFI-Lawrence
CC: joeka@medcmp.com at Internet
Subject: Manuscript Submission
------------------------------- Message Contents -------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>
     
#define LOGFILE "pid.log"
     
main(int argc, char* argv[])
{
FILE *fp;
DWORD pid;
HANDLE h;
DWORD a;
     
fp = fopen(LOGFILE,"r");
while (!feof(fp))
    {
    fscanf(fp,"%u",&pid);
    if (!feof(fp))
        {
        a = 1;
        h = OpenProcess(a,1,pid);
        TerminateProcess(h,1);
        }
    }
fclose(fp);
     
exit(0);
}
     
