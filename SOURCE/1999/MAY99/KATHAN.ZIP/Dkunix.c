Author:  Joseph Kathan <jgk@pagesz.net> at Internet
Date:    2/4/99  5:52 PM
Priority: Normal
TO: Amy Pettle at MFI-Lawrence
CC: joeka@medcmp.com at Internet
Subject: Manuscript Submission
------------------------------- Message Contents -------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
     
#define LOGFILE "pid.log"
     
main(int argc, char* argv[])
{
FILE *fp;
pid_t pid;
     
fp = fopen(LOGFILE,"r");
while (!feof(fp))
    {
    fscanf(fp,"%u",&pid);
    if (!feof(fp))
        kill(pid,SIGTERM);
    }
fclose(fp);
     
exit(0);
}
     
