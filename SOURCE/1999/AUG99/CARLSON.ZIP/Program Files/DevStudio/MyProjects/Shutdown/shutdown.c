#include <windows.h>
#include <winuser.h>
#include <stdio.h>

#define DLL_EXPORT __declspec (dllexport)

// ***************
// Important Note:
// ***************
//
// The following lines create a special data segment
// that stores the file name used by this DLL.  Since
// this DLL has many entry points, it is kept in shared
// memory.  
// 
// The linker has a special command specified in the
// optional settings section:
//
// /SECTION:shared, rws
//
// This means that the "shared" section is readable,
// writable, and shareable.
//
// Additionally, shared variables MUST be initialized, otherwise
// it will be placed in the default address space.


#pragma data_seg("shared")

int shutdownProcess = 0;

#pragma data_seg()

// Function Prototypes.
DWORD WINAPI WaitForShutdown(LPVOID);
DLL_EXPORT void LoadDLL();
DLL_EXPORT void ShutdownProcess();

// Variable Declarations.
DWORD currentThreadId = 0;
HMODULE ghModule = 0;


BOOL APIENTRY DllMain( HANDLE hModule, DWORD ul_reason_for_call, 
                        LPVOID lpReserved )
{
    ghModule = (HMODULE)hModule;

    return(1);
}


DLL_EXPORT void ShutdownProcess()
{
	shutdownProcess = 1;
}


DWORD WINAPI WaitForShutdown(LPVOID aVoidPointer)
{
	// Wait for the shutdown to be triggered.
	for (;;)
	{
		Sleep(1000);
		if (shutdownProcess == 1)
		{
			break;
		}
	}

	ExitProcess(0);

	return(0);
}


DLL_EXPORT void LoadDLL()
{
	DWORD ThreadId = 0;

	// Run our checking on another thread....

	// Spawn a thread to wait for shutdown signal.
	CreateThread(NULL, 0, WaitForShutdown, 0, 0, &ThreadId);
}

