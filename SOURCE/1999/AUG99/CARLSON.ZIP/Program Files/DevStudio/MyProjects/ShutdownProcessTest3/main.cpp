#include <iostream.h>
#include <windows.h>

typedef void (CALLBACK* LOADDLL)();
typedef void (CALLBACK* SHUTDOWNPROCESS)();

HINSTANCE hInstance;
LOADDLL LoadDLL;
SHUTDOWNPROCESS ShutdownProcess;

void main(int argc, char *argv[])
{
	char ch;

	hInstance = LoadLibrary("SHUTDOWN.DLL");
	LoadDLL = reinterpret_cast<LOADDLL>(GetProcAddress(hInstance, "LoadDLL") );
	ShutdownProcess = reinterpret_cast<SHUTDOWNPROCESS>(GetProcAddress(hInstance, "ShutdownProcess") );
	LoadDLL();

	cout << "Press CTRL-Z and then press enter";
	cin >> ch;
	
	FreeLibrary(hInstance);
}
