//
//
// Sample source file, tn.cxx, showing usage of the tnVector class 
//
//
     
#include "tnVector.h"
#include <assert.h>     // For "Sanity Check" in expandBox().
     
  /*
   * Read in weighted points as x y z  w triplets, 
   * compute the centroid of the point cloud,
   * compute the root-mean-distance from the centroid, and 
   * compute the axis-aligned bounding-box.
   *
   * The bounding box encompasses all points, even those with 
   * non-positive weights.
   *
   * Note: for clarity, the stream is not checked for 
   *       validity before or after its use.
   */
     
void expandBox(tnVector<3>& lowerLeft,
               tnVector<3>& upperRight,
               const tnVector<3>& thePoint) {
     
  int ix; // Loop variable
     
  for (ix = 0; ix != 3; ++ix) ;
     
  for (ix = 0; ix != 3; ++ix) {
  // Sanity check
    assert(lowerLeft[ix] <= upperRight[ix]);
     
    if (lowerLeft[ix] > thePoint[ix])
      lowerLeft[ix] = thePoint[ix];
    else if (upperRight[ix] < thePoint[ix])
      upperRight[ix] = thePoint[ix];
     
  }  
}
     
void main() {
     
  // Initialize the vector in case the stream is empty 
  tnVector<3> thePoint(0.0, 0.0, 0.0);
  double weight = 0.0;
     
  // Accumulation variables
  tnVector<3> centroid(0.0, 0.0, 0.0); 
  double sumOfWeights        = 0.0;
  double sumOfSquaredLengths = 0.0;
  int count = 0;
     
  // Bounding box
  tnVector<3> lowerLeft, upperRight;
     
  // .. Default: unit box centered at the origin 
  lowerLeft.initialize(-0.5);
  upperRight.initialize(0.5);
     
  // Read in the points
  while (cin >> thePoint >> weight) {
     
    // Initial box corners are at the 1st point 
    if (count == 0) 
      lowerLeft = upperRight = thePoint;
     
    // Accumulate values
    ++count;
    centroid.increment(thePoint, weight); 
    sumOfWeights += weight;
    sumOfSquaredLengths += weight * thePoint.lengthSquared();
     
    // Expand the box
    expandBox(lowerLeft, upperRight, thePoint);
  }
     
  // Root-mean-square distance of points from the centroid 
  double rms;
     
  if (sumOfWeights <= 0.0) {
    centroid.initialize(0.0);
    rms = 0.0;
  }
  else {
    centroid /= sumOfWeights;
    rms = sqrt(sumOfSquaredLengths / sumOfWeights - centroid.lengthSquared());
  }
     
  cerr << "Statistics for " << count << " points.\n"; 
  cerr << "Centroid = " << centroid << endl;
  cerr << "Root-mean-square " << rms << endl; 
  cerr << "Bounding box: < " << lowerLeft
       << ">, < " << upperRight << ">\n";
}
     
