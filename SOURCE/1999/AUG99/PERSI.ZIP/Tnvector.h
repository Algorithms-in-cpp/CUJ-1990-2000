//
//
// Header file, tnVector.h, for tnVector class 
//
//
     
#ifndef INCtnVector
#define INCtnVector
/* ***********************************************************
 *
 * File: tnVector.h
 *
 * Author: Fred Persi
 *
 * Copyright (c) 1997-1999, Fred M. Persi 
 *
 * Permission is granted to use this code without restriction
 * as long as this copyright notice appears in all header files. 
 *
 * ***********************************************************/
     
#include <math.h> // Needed for root (sqrt) and trig functions.
     
template<int Dim> class tnVector {
public:
     
  // Constructors
  tnVector() {}
  tnVector(const double x, const double y) { setValue(x, y); }
  tnVector(const double x, const double y, const double z) { setValue(x,y,z); } 
  // Compiler generates copy constructor: tnVector(const tnVector<Dim>&); 
     
  // INQUIRY FUNCTIONS
     
  // Element access operators. No bounds checking.
  double operator[](const int index) const { return _v[index]; } 
  double& operator[](const int index) { return _v[index]; }
     
  // Get values.
  const double* getValue() const { return _v; } 
  double* getValue() { return _v; }
     
  // Returns dimension (number of elements) of vector. 
  int dimension() const { return Dim; }
     
  // Returns true iff all elements are == double(0). 
  bool degenerate() const {
    for (int i=0;i<Dim;++i) if (_v[i]!=0.0) return false; 
    return true; }
     
  // Computes self . self.
  double lengthSquared() const { return dot(*this); }
     
  // Returns Euclidean length of vector, sqrt(self . self). 
  double length() const { return sqrt(dot(*this)) };
     
  // Functions that reduce pairs or triples of vectors to scalars.
     
  // Computes | *this - p |^2 cleanly, with no temporary vectors. 
  double distanceSquared(const tnVector<Dim>& p) const {
    double t, a(0.0);
    for (int ix = 0; ix < Dim; ++ix) { t = _v[ix] - p[ix]; a += t * t; } 
    return a; }
     
  // Computes the dot product plus a scalar: dot <- a + self . p.  Unrolled. 
  double dot(const tnVector<Dim>& p, double a = 0.0) const
    {a+=_v[0]*p[0]+_v[1]*p[1]; for(int i=2;i<Dim;++i) a+=_v[i]*p[i];return a;}
     
  // Computes (self . p) / |self| |p| efficiently. Returns 0 if p or self=0. 
  double cosIncludedAngle(const tnVector<Dim>& p) const
    { double d=sqrt(dot(*this) * p.dot(p)); return (d==0.0) ? 0.0:dot(p)/d;}
     
  // Component-wise multiplication: self[ix] *= v[ix]. 
  void elementMultiply(tnVector<Dim>& v)
    { for (int ix = 0; ix < Dim; ++ix) _v[ix] *= v._v[ix]; }
     
  // Swap self and y:  self <-> y.
  void swap(tnVector<Dim>& y)
    {double t; int i=Dim; while(i) { t=y._v[--i]; y._v[i]=_v[i]; _v[i]=t; } }
     
  // In-place negation of each vector element.
  void negate() { for (int ix = 0; ix < Dim; ++ix) _v[ix] = -_v[ix]; }
     
  // Make unit length if possible. Return initial length. zero stays zero. 
  double normalize() { double x=length(); if (x>0.0) (*this) /= x; return x;}
     
  // Compute self = self + x * scalar.
  void increment(const tnVector<Dim>& x, const double scalar = 1.0)
    { for (int ix = 0; ix<Dim; ++ix) _v[ix] += x._v[ix] * scalar; }
     
  // Math operators
  void operator+=(const tnVector<Dim>& p)
    { for (int ix = 0; ix < Dim; ++ix) _v[ix] += p._v[ix]; }
     
  void operator-=(const tnVector<Dim>& p)
    { for (int ix = 0; ix < Dim; ++ix) _v[ix] -= p._v[ix]; }
     
  void operator+=(const double s) { for (int ix=0; ix<Dim; ++ix) _v[ix] += s;} 
  void operator-=(const double s) { for (int ix=0; ix<Dim; ++ix) _v[ix] -= s;} 
  void operator*=(const double s) { for (int ix=0; ix<Dim; ++ix) _v[ix] *= s;} 
  void operator/=(const double s) { for (int ix=0; ix<Dim; ++ix) _v[ix] /= s;}
     
  // Set Functions.
     
  // Set all elements of vector to common passed value.
  void initialize(const double s=0.0) { int ix(Dim); while (ix) _v[--ix] = s;}
     
  // Set to difference of vectors: self = x - y.
  void setDifference(const tnVector<Dim>& x, const tnVector<Dim>& y)
    { for (int ix=0; ix<Dim; ++ix) _v[ix] = x._v[ix] - y._v[ix]; }
     
  // Set to sum of vectors: self = x + y.
  inline void setSum(const tnVector<Dim>& x, const tnVector<Dim>& y)
    { for (int ix=0; ix<Dim; ++ix) _v[ix] = x._v[ix] + y._v[ix]; }
     
  // Set to weighted sum of vectors: self = x * w_x + y * w_y. 
  void setWeightedSum(const tnVector<Dim>& x, const double w_x,
                      const tnVector<Dim>& y, const double w_y = 1.0)
    { for(int ix=0; ix<Dim; ++ix) _v[ix] = x._v[ix]*w_x + y._v[ix] * w_y; }
     
  // Dimension-specific functions
     
  void setValue(const double x, const double y);
     
  // .. Directed angle from *this to b, in a CCW sense. Result is in (-Pi, Pi]. 
  double directedAngle(const tnVector<2>&) const;
     
  void setValue(const double x, const double y, const double z);
     
  // .. Set to right-handed cross product of 3-vectors x cross y. 
  void setCross(const tnVector<3>& x, const tnVector<3>& y);
     
  // Returns self . (b x c).  Only valid for 3-vectors
  double tripleProduct(const tnVector<3>&, const tnVector<3>&) const;
     
protected:
  double _v[Dim]; // Storage for vector elements.
     
};  // End tnVector
     
// Inline definitions of dimension-specific functions
     
inline void tnVector<2>
::setValue(const double x, const double y) 
{ _v[0] = x; _v[1] = y; }
     
inline void tnVector<3>
::setValue(const double x, const double y, const double z) 
{ _v[0] = x; _v[1] = y; _v[2] = z; }
     
inline void tnVector<3>
::setCross(const tnVector<3>& x, const tnVector<3>& y) {
  _v[0] = x._v[1] * y._v[2] - x._v[2] * y._v[1]; 
  _v[1] = x._v[2] * y._v[0] - x._v[0] * y._v[2]; 
  _v[2] = x._v[0] * y._v[1] - x._v[1] * y._v[0];
}
     
inline double tnVector<2>
::directedAngle(const tnVector<2>& b) const
{ return atan2(_v[0]*b._v[1] - _v[1]*b._v[0], _v[0]*b._v[0] + _v[1]*b._v[1]);}
     
inline double tnVector<3>
::tripleProduct(const tnVector<3>& b,
                const tnVector<3>& c) const {
  return
    _v[0] * (b._v[1] * c._v[2] - b._v[2] * c._v[1]) + 
    _v[1] * (b._v[2] * c._v[0] - b._v[0] * c._v[2]) + 
    _v[2] * (b._v[0] * c._v[1] - b._v[1] * c._v[0]);
}
     
     
#include <iostream.h>
template<int Dim> inline
ostream& operator<<(ostream& s, const tnVector<Dim>& v)
{ for (int ix = 0; ix < Dim; ++ix) s << v[ix] << " "; return s; }
     
template<int Dim> inline
istream& operator>>(istream& s, tnVector<Dim>& v)
{ for (int ix = 0; ix < Dim; ++ix) s >> v[ix]; return s; }
     
#endif // INCtnVector
     
