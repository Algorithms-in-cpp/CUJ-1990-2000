class wastefulVec {
public:
   wastefulVec() {}
     
   double& operator[](const int ix) { return _data[ix]; } 
   const double& operator[](const int ix) const
      { return _data[ix]; }
     
   wastefulVec operator+(const wastefulVec& b) const; 
   wastefulVec operator-(const wastefulVec& b) const; 
   // other functions not shown
private:
   double _data[3];
};
     
wastefulVec wastefulVec::operator+(const wastefulVec& b) const {
   wastefulVec temporarySum; // << === potentially wasteful
     
   temporarySum[0] = _data[0] + b._data[0]; 
   temporarySum[1] = _data[1] + b._data[1]; 
   temporarySum[2] = _data[2] + b._data[2];
     
   return temporarySum;
}
     
// Similar code for operator-(const wastefulVec&) const
     
main() {
   wastefulVec a, b;
   /// ... initialize a and b here
     
   wastefulVec sum;
   sum = a + b; // Construct temporary and copy
     
   wastefulVec difference(a - b);
     
}
     
