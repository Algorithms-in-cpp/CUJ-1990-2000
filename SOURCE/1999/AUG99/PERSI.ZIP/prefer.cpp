#include "tnVector.h"
#include <iostream.h>
     
main() {
     
   // Create a point cloud
   const int pointCount = 1024;
   tnVector<3> pointCloud[pointCount];
     
   // .. initialize the data here
     
   /*
    * Apply the transform p_i -> 2 p_i + t to each point
    * in the cloud and compute average squared distance to the 
    * source point s.
    */
     
   tnVector<3> t(3.0,  4.0, 5.0);  // Meaningless values 
   tnVector<3> s;
   s.setValue(5.0, 12.0, 13.0);    // Meaningless values
     
   double sum = 0.0;
   for (int ix = 0; ix < pointCount; ++ix) {
      pointCloud[ix] *= 2.0;
      pointCloud[ix] += t;
      // Or, use
      // pointCloud[ix].setWeightedSum(pointCloud[ix], 2.0, t);
     
      sum += pointCloud[ix].distanceSquared(s);
   }
     
   if (pointCount > 0) sum /= double(pointCount);
     
   cerr << "RMS value " << sqrt(sum) << endl;
     
   // Now compute the cross product of s and t. 
   tnVector<3> cross;
   cross.setCross(s, t);
}
     
