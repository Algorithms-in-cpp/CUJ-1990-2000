// deep.h
     
#ifndef DEEP_H_INCLUDED
#define DEEP_H_INCLUDED
     
template <typename T>
class deep_pointer
    {
public:
    deep_pointer();
    deep_pointer(T *p);
    deep_pointer &operator=(T *p);
    operator T *();
    operator T const *() const;
    T *operator->();
    T const *operator->() const;
private:
    T *actual_pointer;
    };
     
...
     
#endif
