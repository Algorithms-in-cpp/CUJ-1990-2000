// xr.cpp

#include <ctype.h>
#include <stdio.h>
     
#include "table.h"
     
int get_token(char *s, size_t n);
     
#define MAX_TOKEN 256
     
int main()
    {
    cross_reference_table table;
    char token[MAX_TOKEN];
    unsigned ln = 1;
    while (get_token(token, MAX_TOKEN))
        if (isalpha(token[0]) || token[0] == '_')
            table.add(token, ln);
        else // if (token[0] == '\n')
            ++ln;
    table.put();
    return 0;
    }
     
int get_token(char *s, size_t n)
    {
    int c;
    while ((c = fgetc(stdin)) != EOF)
        if (isalpha(c) || c == '_' || c == '\n')
            break;
    if (c == EOF)
        {
        *s = '\0';
        return 0;
        }
    *s++ = c;
    n -= 2;
    if (c != '\n')
        {
        while (isalnum(c = fgetc(stdin)) || c == '_')
            if (n > 0)
                {
                *s++ = c;
                --n;
                }
        ungetc(c, stdin);
        }
    *s = '\0';
    return 1;
    }
