////////////////////////////////////////////////////////////////////////////////
//
// File             : Glyph.h
//
// Description      : Interface of the CGlyph class
//
// Original Authors : Mike Bertrand        mikeber@execpc.com
//                    Dave Grundgeiger     daveg@tarasoftware.com
//
////////////////////////////////////////////////////////////////////////////////

#if !defined __GLYPH_H__
#define __GLYPH_H__

class CGlyph
{
// public attributes
public:
  double m_dScale;           // for scaling the glyph

// public operations
public:
  CGlyph();
  ~CGlyph();
  void Draw(
    HDC hDC,
    const int xOffset = 0,
    const int yOffset = 0
  ) const;
  double GetAngle();
  void GetBoundingRect(
    RECT * const prect,      // address of rectangle to receive data
    const int xOffset = 0,   // (xOffset, yOffset) is the desired origin
    const int yOffset = 0    //     of the rectangle
  ) const;
  bool IsRealized() const;
  bool Realize(const HDC hDC, const LPLOGFONT lpf);
  Realize(
    const UINT uChar,        // new character to realize
    const HDC hDC,           // handle to device context
    const LPLOGFONT plf      // pointer to logical font
  );
  void SetAngle(const double dNewValue);
  void Unrealize();

// private attributes
protected:
  bool m_bRealized;          // true if m_lpvBuffer contains valid data
  DWORD m_cbBuffer;          // size of m_lpvBuffer
  double m_dAngleDegrees;    // angle by which to rotate glyph
  GLYPHMETRICS m_gm;         // glyph measurements from GetGlyphOutline
  LPVOID m_lpvBuffer;        // curve data from GetGlyphOutline
  MAT2 m_mat2;               // transformation matrix for GetGlyphOutline
  UINT m_uChar;              // character to render

// private operations
protected:
  inline void FromGGOPoint(
    POINT * const ppt,       // address of POINT to receive new values
    const int xGGO,          // x-coordinate to convert
    const int yGGO,          // y-coordinate to convert
    const int xOffset = 0,   // desired coordinates of upper-left corner
    const int yOffset = 0    //     of glyph's bounding box
  ) const;
  inline void FromGGOPoint(
    POINT * const ppt,       // address of POINT to receive new values
    const POINTFX & ptfxGGO, // point to convert
    const int xOffset = 0,   // desired coordinates of upper-left corner
    const int yOffset = 0    //     of glyph's bounding box
  ) const;
  void FromGGORect(
    RECT * const prect,      // address of POINT to receive new values
    const int nGGOLeft,      // values to convert
    const int nGGOTop,
    const int nGGORight,
    const int nGGOBottom,
    const int xOffset = 0,   // desired coordinates of upper-left corner
    const int yOffset = 0    //     of glyph's bounding box
  ) const;
  void MakeRotationMatrix();
  void ReselectOldFont(
    const HDC hDC,           // display context fonts selected in
    const HFONT hOldFont,    // previously selected font, to reselect
    const HFONT hFont        // currently selected font, to delete
  );

}; // class CGlyph

#endif // __GLYPH_H__
