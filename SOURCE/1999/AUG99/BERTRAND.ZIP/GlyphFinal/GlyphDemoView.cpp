// GlyphDemoView.cpp : implementation of the CGlyphDemoView class
//

#include "stdafx.h"
#include "GlyphDemo.h"
#include "GlyphDemoDoc.h"
#include "GlyphDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGlyphDemoView

IMPLEMENT_DYNCREATE(CGlyphDemoView, CView)

BEGIN_MESSAGE_MAP(CGlyphDemoView, CView)
  //{{AFX_MSG_MAP(CGlyphDemoView)
  ON_WM_CHAR()
  //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGlyphDemoView construction/destruction

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyphDemoView
// Method         : CGlyphDemoView (constructor)
// Description    : Init font member variable.
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
CGlyphDemoView::CGlyphDemoView()
{
  // Initial font information.
  memset(&m_lf, 0, sizeof(m_lf));
  m_lf.lfPitchAndFamily = FF_ROMAN;
  m_lf.lfHeight         = GGO_FONT_HT;
  m_lf.lfCharSet        = ANSI_CHARSET;
  m_lf.lfOutPrecision   = OUT_TT_PRECIS;
  strcpy(m_lf.lfFaceName, "Times New Roman");

}

CGlyphDemoView::~CGlyphDemoView()
{
}

BOOL CGlyphDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
  // TODO: Modify the Window class or styles here by modifying
  //  the CREATESTRUCT cs

  return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGlyphDemoView drawing

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyphDemoView
// Method         : OnDraw
// Description    : View's Paint routine.
// Remarks        : Draw glyph in center of client rectangle.
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CGlyphDemoView::OnDraw(CDC* pDC)
{
  CGlyphDemoDoc* pDoc = GetDocument();
  ASSERT_VALID(pDoc);

  CRect rectClient;          // app's client rectangle
  CRect rectGlyph;           // glyph's bounding box
  int nLeft;                 // left edge of glyph on screen
  int nTop;                  // top edge of glyph on screen

  // First time through, realize 'B'.
  if (!pDoc->m_glyph.IsRealized())
    pDoc->m_glyph.Realize('B', *pDC, &m_lf);

  // Center the glyph in the client window.
  GetClientRect(&rectClient);
  pDoc->m_glyph.GetBoundingRect(&rectGlyph);
  nLeft = ((rectClient.right - rectClient.left)
    - (rectGlyph.right - rectGlyph.left)) / 2;
  nTop = ((rectClient.bottom - rectClient.top)
    - (rectGlyph.bottom - rectGlyph.top)) / 2;

  // Draw the glyph.
  pDoc->m_glyph.Draw(*pDC, nLeft, nTop);

}

/////////////////////////////////////////////////////////////////////////////
// CGlyphDemoView diagnostics

#ifdef _DEBUG
void CGlyphDemoView::AssertValid() const
{
  CView::AssertValid();
}

void CGlyphDemoView::Dump(CDumpContext& dc) const
{
  CView::Dump(dc);
}

CGlyphDemoDoc* CGlyphDemoView::GetDocument() // non-debug version is inline
{
  ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGlyphDemoDoc)));
  return (CGlyphDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGlyphDemoView message handlers

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyphDemoView
// Method         : OnChar
// Description    : Keyboard event handler (come here when key pressed).
// Remarks        : Realize new character and draw.
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CGlyphDemoView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
  CGlyphDemoDoc* pDoc;
  pDoc = reinterpret_cast<CGlyphDemoDoc *>(GetDocument());
  ASSERT_VALID(pDoc);
  CDC *pDC = GetDC();        // need a DC to realize the glyph

  // Must realize the glyph for change to take effect.
  pDoc->m_glyph.Realize(nChar, *pDC, &m_lf);

  // Redraw.
  Invalidate();

}
