// GlyphDemoDoc.h : interface of the CGlyphDemoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLYPHDEMODOC_H__579BD68B_C081_11D1_9212_444553540000__INCLUDED_)
#define AFX_GLYPHDEMODOC_H__579BD68B_C081_11D1_9212_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "glyph.h"

class CGlyphDemoDoc : public CDocument
{
protected: // create from serialization only
  CGlyphDemoDoc();
  DECLARE_DYNCREATE(CGlyphDemoDoc)

// Attributes
public:
  CGlyph m_glyph;

// Operations
public:

// Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CGlyphDemoDoc)
  public:
  virtual BOOL OnNewDocument();
  virtual void Serialize(CArchive& ar);
  //}}AFX_VIRTUAL

// Implementation
public:
  virtual ~CGlyphDemoDoc();
#ifdef _DEBUG
  virtual void AssertValid() const;
  virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
  //{{AFX_MSG(CGlyphDemoDoc)
    // NOTE - the ClassWizard will add and remove member functions here.
    //    DO NOT EDIT what you see in these blocks of generated code !
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GLYPHDEMODOC_H__579BD68B_C081_11D1_9212_444553540000__INCLUDED_)
