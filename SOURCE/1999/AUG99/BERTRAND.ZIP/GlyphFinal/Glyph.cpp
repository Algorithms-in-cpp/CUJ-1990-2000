////////////////////////////////////////////////////////////////////////////////
//
// File           : Glyph.cpp
//
// Description    : Implementation of the CGlyph class
//
// Authors        : Mike Bertrand        mikeber@execpc.com
//                  Dave Grundgeiger     daveg@tarasoftware.com
//
// Remarks        : The CGlyph class is an example of how to use the
//                  GetGlyphOutline API call.  CGlyph can be studied to
//                  gain an understanding of how to use this complicated
//                  function call, or it can be used directly in a C++
//                  project to hide GetGlyphOutline's complexity.
//
//                  The CGlyph class doesn't depend on MFC, so it can be
//                  used in both MFC and non-MFC projects.  To use it in a
//                  non-MFC application, replace the '#include "stdafx.h"'
//                  below with '#include "windows.h"'.
//
//                  You are free to cut and paste the code from this module
//                  into your own projects--that's why we wrote it!
//
////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"          // for MFC apps
#include "math.h"            // for cos and sin
#include "assert.h"          // for assert()
#include "Glyph.h"

// ------------------------------- Constants -----------------------------------

static const double dPI = 3.14159265358979;
static const int nBEZIER_DEPTH = 4;  // controls recursion in DrawQSpline

// ---------------------- Local Function Declarations --------------------------

static POINTFX AvgPointsFX(
  const POINTFX p,
  const POINTFX q
);

static bool DrawQSpline(
  HDC hDC,
  const POINTFX p1,
  const POINTFX p2,
  const POINTFX p3
);

static inline FIXED FixedFromDouble(const double d);
static inline double RadiansFromDegrees(const double dDegrees);

// ----------------------- Local Function Definitions --------------------------

////////////////////////////////////////////////////////////////////////////////
// Class          : none
// Method         : AvgPointsFX
// Description    : Find the midpoint of two POINTFX points.
// Remarks        : Uses typecasting to convert the FIXED x and y to longs,
//                  then add and quick divide by 2 with shifting.  Convert
//                  back to FIXED coordinates and return the POINTFX.
// Returns        : (POINTFX) midway between the given points.
////////////////////////////////////////////////////////////////////////////////
static POINTFX AvgPointsFX(
  const POINTFX p,
  const POINTFX q
)
{
  long x, y;            // average of x's and y's, as longs
  POINTFX r;            // average, converted back to POINTFX

  // Convert coords to long and average.
  x = (*((long far *)&(p.x)) + *((long far *)&(q.x))) >> 1;
  y = (*((long far *)&(p.y)) + *((long far *)&(q.y))) >> 1;

  // Convert calculated values back to FIXED and return the POINTFX.
  r.x = *(FIXED *)&x;
  r.y = *(FIXED *)&y;
  return (r);

} // AvgPointsFX

////////////////////////////////////////////////////////////////////////////////
// Class          : none
// Method         : DrawQSpline
// Description    : Recursively draw a QSpline, or quadratic Bezier curve,
//                  given its three defining points.
// Remarks        : p1 and p3 are the controls, p2 the handle. Each call
//                  calculates the deCasteljau construction points to divide
//                  the curve into a left sub-Bezier and a right sub-Bezier,
//                  which are themselves drawn by recursive calls to this
//                  function. Actual drawing is done and recursion broken off
//                  when the recursive depth (nCurrentDepth), incremented once
//                  for each recursion level, becomes nBEZIER_DEPTH. The
//                  controls on each subdivided curve are also points on the
//                  original curve. The original Bezier curve is broken into
//                  2^(nBEZIER_DEPTH - 1) short line segments and they are
//                  generated in order from left (the p1 side) to right (the
//                  p3 side). If nBEZIER_DEPTH = 4, for example, the original
//                  Bezier is broken into 2^3 = 8 short line segments.
// Returns        : (bool) True if successful, false if error.
////////////////////////////////////////////////////////////////////////////////
static bool DrawQSpline(
  HDC hDC,
  const POINTFX p1,
  const POINTFX p2,
  const POINTFX p3
)
{
  POINTFX q1, q2, r2;        // de Casteljau construction points
  static int nCurrentDepth = 0;  // controls recursion
  bool bResult1, bResult2;   // receive results of drawing calls

  nCurrentDepth++;

  // nCurrentDepth == nBEZIER_DEPTH means that we are at the finest
  // subdivision level.
  if (nCurrentDepth == nBEZIER_DEPTH)
    {
    // Actually draw a short line segment between the controls of the most
    // finely subdivided Bezier -- these controls are on the original Bezier.
    bResult1 = (MoveToEx(hDC, p1.x.value, p1.y.value, NULL) != FALSE);
    bResult2 = (LineTo(hDC, p3.x.value, p3.y.value) != FALSE);
    // Decrement recursive depth because ...
    nCurrentDepth--;
    // ... we're at the greatest depth and are returning to the calling
    // instance, one higher in depth, without more subdividing.
    return (bResult1 && bResult2);
    }
  
  // Calculate de Casteljau construction points as averages of previous
  // points (ie., midway points). q's are midway between the p's.
  q1 = AvgPointsFX(p1, p2);
  q2 = AvgPointsFX(p2, p3);
  
  // r2 is midway between the q's.
  r2 = AvgPointsFX(q1, q2);
  
  // Draw subdivided Beziers -- the left one then the right one.
  bResult1 = DrawQSpline(hDC, p1, q1, r2);
  bResult2 = DrawQSpline(hDC, r2, q2, p3);

  // Decrement recursive depth because have returned from subdividing and are
  // returning to the calling instance, one higher in depth.
  nCurrentDepth--;
  return (bResult1 && bResult2);

} // DrawQSpline

////////////////////////////////////////////////////////////////////////////////
// Class          : none
// Method         : FixedFromDouble
// Description    : Convert double to FIXED
// Remarks        : The correct operation of this function is dependent on
//                  the storage sizes of the data types involved.  If future
//                  versions of Windows redefine the size of the FIXED data
//                  type, then this function will have to be rewritten.
// Returns        : FIXED value equivalent to given double
////////////////////////////////////////////////////////////////////////////////
static inline FIXED FixedFromDouble(const double d)
{
  long l;
  
  l = (long) (d * 65536L);
  return *(FIXED *)&l;

} // FixedFromDouble

////////////////////////////////////////////////////////////////////////////////
// Class          : none
// Method         : RadiansFromDegrees
// Description    : Convert degrees to radians
// Returns        : (double) Angle in radians equivalent to given angle in
//                  degrees
////////////////////////////////////////////////////////////////////////////////
static inline double RadiansFromDegrees(const double dDegrees)
{
  return dDegrees * dPI / 180;

} // RadiansFromDegrees

// --------------------- Class Member Function Definitions ---------------------

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : CGlyph
// Description    : default constructor
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
CGlyph::CGlyph()
{
  // A constructor should initialize all data members.
  m_bRealized = false;
  m_cbBuffer = 0;
  m_dAngleDegrees = 0;
  memset(&m_gm, 0, sizeof(m_gm));
  m_lpvBuffer = NULL;
  memset(&m_mat2, 0, sizeof(m_mat2));
  m_uChar = 0;
  // Set scale = 75% to fit into client area initially.
  m_dScale = 0.75;
} // CGlyph

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : ~CGlyph
// Description    : destructor
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
CGlyph::~CGlyph()
{
  Unrealize();      // make sure buffer has been released
} // ~CGlyph                         

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : Draw
// Description    : Draws the glyph in the given device context.
// Remarks        : The glyph is drawn so that the upper-left corner is at pixel
//                  position (xOffset, yOffset). Member variable m_lpvBuffer
//                  holds the glyph polygon data returned by GetGlyphOutline()
//                  and m_cbBuffer is the buffer's size. This routine traverses
//                  the buffer, rendering each contour in the Glyph. GGO's points
//                  are converted to screen pixels by utility function
//                  FromGGOPoint(). Each contour consists of a series of
//                  intermingled polylines and QSpline records (one or more
//                  QSpline, or quadratic Bezier, curves).
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CGlyph::Draw(HDC hDC, const int xOffset, const int yOffset) const
{
  LPTTPOLYGONHEADER lpttph;  // pointer to current polygon in glyph
  LPTTPOLYCURVE lpttpc;      // pointer to current polycurve in polygon
  DWORD dwHeaderOffset;      // byte offset of current polygon header
                             //     from start of buffer
  DWORD dwCurveOffset;       // byte offset of current polycurve header
                             //     from start of polygon header
  DWORD dwStructSize;        // size of current polycurve (depends on
                             //     the number of points in the polycurve)
  POINT ptPolyStart;         // polygon start point
  POINT ptCurveLast;         // last point on previous curve
  POINT pt;                  // temporary holder of point coordinates
  int i;                     // to loop thru lines or splines
  POINTFX p1, p2, p3;        // three points defining spline

  if (!IsRealized())
    return;

  assert(m_lpvBuffer != NULL);

  // Outer while loops for all polygon headers (can be more than one).
  dwHeaderOffset = 0;
  while (m_cbBuffer >= (dwHeaderOffset + sizeof(TTPOLYGONHEADER)))
    {
    // Get pointer to start of the polygon.
    lpttph = (LPTTPOLYGONHEADER)(((char *)m_lpvBuffer) + dwHeaderOffset);
    assert(lpttph->dwType == TT_POLYGON_TYPE);
    // Convert polygon's start point to pixels.
    FromGGOPoint(&ptPolyStart, lpttph->pfxStart, xOffset, yOffset);
    // Init last point of last record to polygon start point.
    ptCurveLast = ptPolyStart;
    // Position graphics current pointer to start of polygon.
    MoveToEx(hDC, ptPolyStart.x, ptPolyStart.y, NULL);

    // Inner while loops for all polycurves in one polygon.
    // (A polycurve is one or more polyline and/or QSpline records.)
    dwCurveOffset = sizeof(TTPOLYGONHEADER);
    while (lpttph->cb >= (dwCurveOffset + sizeof(TTPOLYCURVE)))
      {
      // Get pointer to start of polycurve.
      lpttpc = (LPTTPOLYCURVE)(((char *)m_lpvBuffer) + dwHeaderOffset
               + dwCurveOffset);

      // Test record type, draw polyline or series of Beziers accordingly.
      switch (lpttpc->wType)
        {
        case TT_PRIM_LINE:
          // Draw polyline connecting GGO points (there are lpttpc->cpfx).
          for (i = 0; i < lpttpc->cpfx; i++)
            {
            FromGGOPoint(&pt, lpttpc->apfx[i], xOffset, yOffset);
            LineTo(hDC, pt.x, pt.y);
            }
          ptCurveLast = pt;
          break;
        case TT_PRIM_QSPLINE:
          // Draw series of Beziers connecting GGO points.
          // But for initial Bezier, grab last point on previous curve.
          p3.x.value = (short)ptCurveLast.x;
          p3.x.fract = 0;
          p3.y.value = (short)ptCurveLast.y;
          p3.y.fract = 0;
          // Draw QSplines based on GGO points (there are lpttpc->cpfx-1).
          for (i = 0; i < lpttpc->cpfx - 1; i++)
            {
            // p1 is 1st control -- last point in this or previous contour.
            p1 = p3;
            // p2 is handle -- a point in the record.
            FromGGOPoint(&pt, lpttpc->apfx[i], xOffset, yOffset);
            p2.x.value = (short)pt.x;
            p2.x.fract = 0;
            p2.y.value = (short)pt.y;
            p2.y.fract = 0;
            // p3 is 2nd control -- the midpoint of 2 spline points
            // except for the last spline, when it is the second to
            // the last point in the spline record.
            p3 = (i == (lpttpc->cpfx-2)) ? lpttpc->apfx[i+1] :
                 AvgPointsFX(lpttpc->apfx[i], lpttpc->apfx[i+1]);
            FromGGOPoint(&pt, p3, xOffset, yOffset);
            p3.x.value = (short)pt.x;
            p3.x.fract = 0;
            p3.y.value = (short)pt.y;
            p3.y.fract = 0;
            // Call deCasteljau to draw quadratic Bezier curve.
            DrawQSpline(hDC, p1, p2, p3);
            } // for
          ptCurveLast = pt;
          break;
        default:
          assert(false); // must be one of the two cases above
          break;
        } // switch

      // Increment curve offset so point to next polycurve.
      dwStructSize = sizeof(TTPOLYCURVE) + ((lpttpc->cpfx - 1)
                     * sizeof(POINTFX));
      dwCurveOffset += dwStructSize;
      } // inner while (polycurve)

    // Close polygon by drawing a line back to the start point.
    LineTo(hDC, ptPolyStart.x, ptPolyStart.y);

    // Increment polygon offset so point to next polygon.
    dwHeaderOffset += lpttph->cb;
    } // outer while (polygon)

} // Draw

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : FromGGOPoint (from int's)
// Description    : Converts a point given in GGO coordinates to coordinates
//                  more easily drawn on a device context.
// Remarks        : This function does two things:
//                  - Reverse the direction of the y-axis.  (The
//                    coordinates returned by GetGlyphOutline have
//                    decreasing y values as you go from the top to the
//                    bottom of the glyph.  This is opposite to the
//                    default behavior of device context coordinates.)
//                  - Put the upper-left corner of the glyph at the point
//                    (xOffset, yOffset).  (Internally, the upper-left
//                    corner may be at non-zero, even negative,
//                    coordinates depending on what transformations have
//                    been applied through the MAT2 structure.  This
//                    function normalizes that by first adjusting the
//                    point so that the upper-left corner of the glyph's
//                    bounding rectangle would be at (0,0), then adding
//                    the given xOffset and yOffset)
// Returns        : none (POINT is returned in parameter)
////////////////////////////////////////////////////////////////////////////////
inline void CGlyph::FromGGOPoint(
  POINT * const ppt,         // address of POINT to receive new values
  const int xGGO,            // x-coordinate to convert
  const int yGGO,            // y-coordinate to convert
  const int xOffset,         // desired coordinates of upper-left corner
  const int yOffset          //     of glyph's bounding box
) const
{
  ppt->x = static_cast<long>
    (m_dScale * (xGGO - m_gm.gmptGlyphOrigin.x) + xOffset);
  ppt->y = static_cast<long>
    (m_dScale * (m_gm.gmptGlyphOrigin.y - yGGO) + yOffset);

} // FromGGOPoint (from int's)

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : FromGGOPoint (from POINTFX)
// Description    : Converts a point given in GGO coordinates to coordinates
//                  more easily drawn on a device context.
// Remarks        : See remarks for FromGGOPoint (from int's)
// Returns        : none (POINT is returned in parameter)
////////////////////////////////////////////////////////////////////////////////
inline void CGlyph::FromGGOPoint(
  POINT * const ppt,         // address of POINT to receive new values
  const POINTFX & ptfxGGO,   // point to convert
  const int xOffset,         // desired coordinates of upper-left corner
  const int yOffset          //     of glyph's bounding box
) const
{
  FromGGOPoint(ppt, ptfxGGO.x.value, ptfxGGO.y.value, xOffset, yOffset);

} // FromGGOPoint (from POINTFX)

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : FromGGORect
// Description    : Converts a rectangle given in GGO coordinates to
//                  coordinates more easily drawn on a device context.
// Remarks        : See remarks for FromGGOPoint (from int's)
// Returns        : none (RECT is returned in parameter)
////////////////////////////////////////////////////////////////////////////////
void CGlyph::FromGGORect(
  RECT * const prect,        // address of POINT to receive new values
  const int nGGOLeft,        // values to convert
  const int nGGOTop,
  const int nGGORight,
  const int nGGOBottom,
  const int xOffset,         // desired coordinates of upper-left corner
  const int yOffset          //     of glyph's bounding box
) const
{
  POINT pt;

  FromGGOPoint(&pt, nGGOLeft, nGGOTop, xOffset, yOffset);
  prect->left = pt.x;
  prect->top = pt.y;

  FromGGOPoint(&pt, nGGORight, nGGOBottom, xOffset, yOffset);
  prect->right = pt.x;
  prect->bottom = pt.y;

} // FromGGORect

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : GetAngle
// Description    : Returns the current angle of rotation of the glyph (in
//                  degrees).
// Returns        : double
////////////////////////////////////////////////////////////////////////////////
double CGlyph::GetAngle()
{
  return m_dAngleDegrees;

} // GetAngle

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : GetBoundingRect
// Description    : Returns the smallest rectangle that encloses the glyph.
// Returns        : none (RECT is returned in parameter)
////////////////////////////////////////////////////////////////////////////////
void CGlyph::GetBoundingRect(
  RECT * const prect,        // address of rectangle to receive data
  const int xOffset,         // (xOffset, yOffset) is the desired origin
  const int yOffset          //     of the rectangle
) const
{
  if (IsRealized())
    {
    FromGGORect(
      prect,
      m_gm.gmptGlyphOrigin.x,
      m_gm.gmptGlyphOrigin.y,
      m_gm.gmptGlyphOrigin.x + m_gm.gmBlackBoxX,
      m_gm.gmptGlyphOrigin.y - m_gm.gmBlackBoxY,
      xOffset,
      yOffset);
    }
  else
    {
    prect->left = 0;
    prect->top = 0;
    prect->right = 0;
    prect->bottom = 0;
    }

} // GetBoundingRect

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : IsRealized
// Description    : Indicates whether the glyph is currently realized.
// Returns        : (bool) true if realized, false if not
////////////////////////////////////////////////////////////////////////////////
bool CGlyph::IsRealized() const
{
  return m_bRealized;

} // IsRealized

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : MakeRotationMatrix
// Description    : Sets transformation matrix for use by GetGlyphOutline.
// Remarks        : GetGlyphOutline applies the transformation matrix to all
//                  points in the glyph before returning them in lpvBuffer.
//
//                  The transformation is accomplished through matrix
//                  multiplication.  Let (x,y) represent a point in the glyph,
//                  and (x',y') represent the new point after transformation.
//                  The new point is calculated as follows:
//
//                        *-  -*     *-          -*     *- -*
//                        | x' |     | eM11  eM21 |     | x |
//                        |    |  =  |            |  *  |   |
//                        | y' |     | eM12  eM22 |     | y |
//                        *-  -*     *-          -*     *- -*
//
//                  This allows us to rotate a glyph through angle theta by
//                  setting up the transformation matrix as follows:
//
//                        *-  -*     *-                       -*     *- -*
//                        | x' |     | cos(theta)  -sin(theta) |     | x |
//                        |    |  =  |                         |  *  |   |
//                        | y' |     | sin(theta)   cos(theta) |     | y |
//                        *-  -*     *-                       -*     *- -*
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CGlyph::MakeRotationMatrix()
{
  double cosTheta, sinTheta;

  // Calculate cosine and sine of angle.
  cosTheta = cos(RadiansFromDegrees(m_dAngleDegrees));
  sinTheta = sin(RadiansFromDegrees(m_dAngleDegrees));

  // Fill values into transformation matrix.
  m_mat2.eM11 = FixedFromDouble(cosTheta);
  m_mat2.eM12 = FixedFromDouble(sinTheta);
  m_mat2.eM21 = FixedFromDouble(-sinTheta);
  m_mat2.eM22 = FixedFromDouble(cosTheta);

} // MakeRotationMatrix

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : ReselectOldFont
// Description    : Selects old font, so current font can be deleted
// Remarks        : Created hFonts must be deleted with DeleteObject() or the
//                  object heap will be eventually exhausted. But an hFont
//                  currently selected into a DC cannot be deleted, so this
//                  function selects some *other* font (hOldFont) into the
//                  DC before deleting hFont.
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CGlyph::ReselectOldFont(const HDC hDC, const HFONT hOldFont, const HFONT hFont)
{
  // Re-select previous font into DC, so that ...
  SelectObject(hDC, hOldFont);
  // ...the new font can be deleted.
  DeleteObject(hFont);

} // ReselectOldFont

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : Realize
// Description    : Allocates a buffer and calls GetGlyphOutline to retrieve
//                  the outline of the character in m_uChar in the True Type
//                  font that is selected into the specified device context.
// Remarks        : If the device context doesn't have a True Type font
//                  selected into it, GetGlyphOutline (and Realize) will fail.
//                  Create an hFont based on the incoming LOGFONT and select
//                  into the DC before calling GetGlyphOutline(). Then before
//                  exiting, reselect the original font (and delete the new one).
//                  If this function is called on a glyph that has previously
//                  been realized, it will first be unrealized, then the new
//                  glyph will be realized.
// Returns        : (bool) True if successful, false if error.
////////////////////////////////////////////////////////////////////////////////
bool CGlyph::Realize(const HDC hDC, const LPLOGFONT plf)
{
  HFONT hFont;               // new TrueType font derived from incoming LOGFONT
  HFONT hOldFont;            // font originally selected into incoming DC
  DWORD dwResult;            // GetGlyphOutline() return value

  // If already realized, then unrealize to free memory.
  if (m_bRealized)
    Unrealize();

  // Calculate rotation matrix for current angle.
  MakeRotationMatrix();

  // If no LOGFONT, exit.
  if (!plf)
    return false;

  // Create new TrueType font from incoming LOGFONT.
  hFont = CreateFontIndirect(plf);
  // Select new font, retrieving old one, so can re-select later.
  hOldFont = (HFONT) SelectObject(hDC, hFont);

  // Get size of the buffer needed for this glyph.
  m_cbBuffer = GetGlyphOutline(hDC, m_uChar, GGO_NATIVE, &m_gm, 0, NULL, &m_mat2);
  if (m_cbBuffer == GDI_ERROR)
    {
    Unrealize();
    ReselectOldFont(hDC, hOldFont, hFont);
    return false;
    } // if

  // Allocate the buffer.
  m_lpvBuffer = malloc(m_cbBuffer);
  if (m_lpvBuffer == NULL)
    {
    Unrealize();
    ReselectOldFont(hDC, hOldFont, hFont);
    return false;
    } // if

  // Get vector points for this glyph.
  dwResult = GetGlyphOutline(hDC, m_uChar, GGO_NATIVE, &m_gm, m_cbBuffer,
    m_lpvBuffer, &m_mat2);
  assert(dwResult == m_cbBuffer);
  if (dwResult == GDI_ERROR)
    {
    Unrealize();
    ReselectOldFont(hDC, hOldFont, hFont);
    return false;
    } // if

  // Reselect previously selected font into DC, delete new one.
  ReselectOldFont(hDC, hOldFont, hFont);

  m_bRealized = true;
  return true;

} // Realize(HDC, LPFOGFONT)

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : Realize
// Description    : Overloaded function allows new character to be specified
//                  when realizing.
// Returns        : (bool) True if successful, false if error.
////////////////////////////////////////////////////////////////////////////////
CGlyph::Realize(
  const UINT uChar,          // new character to realize
  const HDC hDC,             // handle to device context
  const LPLOGFONT plf        // pointer to logical font
)
{
  m_uChar = uChar;
  return Realize(hDC, plf);

} // Realize(UINT, HDC, LPLOGFONT)

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : SetAngle
// Description    : Sets current angle of rotation for the glyph (in degrees).
// Remarks        : Any value is allowed.  It is normalized to be in the range
//                  0 <= angle < 360 before it is applied to the glyph.
//                  Subsequent calls to GetAngle will return the normalized
//                  value.
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CGlyph::SetAngle(const double dNewValue)
{
  long lIntegerPart = static_cast<long>(dNewValue);
  double dFractionPart = dNewValue - lIntegerPart;

  m_dAngleDegrees = (lIntegerPart % 360) + dFractionPart;

  if (m_dAngleDegrees < 0)
    m_dAngleDegrees += 360;

} // SetAngle

////////////////////////////////////////////////////////////////////////////////
// Class          : CGlyph
// Method         : Unrealize
// Description    : Frees the memory allocated to the glyph, and resets most
//                  members to null values.
// Remarks        : Scale (m_dScale) and angle (m_dAngleDegrees and m_mat2)
//                  are not reset.  This allows these values to be persistent
//                  through calls to Realize.
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CGlyph::Unrealize()
{
  memset(&m_gm, 0, sizeof(m_gm));
  m_cbBuffer = 0;
  free(m_lpvBuffer); // safe even if m_lpvBuffer is NULL
  m_lpvBuffer = NULL;
  m_bRealized = false;

} // Unrealize
