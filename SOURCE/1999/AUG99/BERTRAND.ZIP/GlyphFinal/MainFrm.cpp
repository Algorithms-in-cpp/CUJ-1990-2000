// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "GlyphDemo.h"

#include "Glyph.h"
#include "GlyphDemoDoc.h"
#include "GlyphDemoView.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
  //{{AFX_MSG_MAP(CMainFrame)
  ON_WM_CREATE()
  ON_COMMAND(ID_GLYPH_FONT, OnGlyphFont)
  ON_COMMAND(ID_GLYPH_ROTATE_LEFT, OnGlyphRotateLeft)
  ON_COMMAND(ID_GLYPH_ROTATE_RIGHT, OnGlyphRotateRight)
  ON_COMMAND(ID_GLYPH_ZOOM_IN, OnGlyphZoomIn)
  ON_COMMAND(ID_GLYPH_ZOOM_OUT, OnGlyphZoomOut)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
  ID_SEPARATOR,           // status line indicator
  ID_INDICATOR_CAPS,
  ID_INDICATOR_NUM,
  ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
  // TODO: add member initialization code here
  
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
  if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
    return -1;
  
  if (!m_wndToolBar.Create(this) ||
    !m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
  {
    TRACE0("Failed to create toolbar\n");
    return -1;      // fail to create
  }

  if (!m_wndStatusBar.Create(this) ||
    !m_wndStatusBar.SetIndicators(indicators,
      sizeof(indicators)/sizeof(UINT)))
  {
    TRACE0("Failed to create status bar\n");
    return -1;      // fail to create
  }

  // TODO: Remove this if you don't want tool tips or a resizeable toolbar
  m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
    CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

  // TODO: Delete these three lines if you don't want the toolbar to
  //  be dockable
  m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
  EnableDocking(CBRS_ALIGN_ANY);
  DockControlBar(&m_wndToolBar);

  return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
  // TODO: Modify the Window class or styles here by modifying
  //  the CREATESTRUCT cs

  return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
  CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
  CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

////////////////////////////////////////////////////////////////////////////////
// Class          : CMainFrame
// Method         : OnGlyphFont
// Description    : Menu event handler for Glyph / Font.
// Remarks        : Show ChooseFont dialog box, realize current character
//                  in new font, redraw.
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnGlyphFont() 
{
  CGlyphDemoView *pView = reinterpret_cast<CGlyphDemoView *>(GetActiveView()); // view window
  CGlyphDemoDoc* pDoc;
  pDoc = reinterpret_cast<CGlyphDemoDoc *>(pView->GetDocument());
  ASSERT_VALID(pDoc);
  CDC *pDC = pView->GetDC(); // need a DC to realize the glyph
  CHOOSEFONT cf;             // needed by ChooseFont common dialog
  BOOL bResult;              // return value of ChooseFont
  
  // Start all CHOOSEFONT fields to 0.
  memset(&cf, 0, sizeof(cf));
  cf.lStructSize = sizeof(cf);
  cf.hwndOwner   = pView->m_hWnd;
  // Init logFont from member variable holding current settings.
  cf.lpLogFont   = &(pView->m_lf);
  // Flags:  Use logfont structure to initialize the dialog controls,
  // show only screen fonts, show only True Type fonts.
  cf.Flags = CF_INITTOLOGFONTSTRUCT | CF_SCREENFONTS | CF_TTONLY;
  
  // Set font height so sample text appears in dialog.
  pView->m_lf.lfHeight = SAMPLE_FONT_HT;
  
  // Display the ChooseFont common dialog.
  bResult = ChooseFont(&cf);
  
  // Reset font height to GGO_FONT_HT before realizing the character -- this
  // is the size for GGO to use when creating the glyph outline.
  pView->m_lf.lfHeight = GGO_FONT_HT;

  // If ChooseFont failed, then exit.
  if (!bResult)
    return;

  // Realize current character in new font, redraw.
  pDoc->m_glyph.Realize(*pDC, &(pView->m_lf));
  pView->Invalidate();

}


////////////////////////////////////////////////////////////////////////////////
// Class          : CMainFrame
// Method         : OnGlyphRotateLeft
// Description    : Menu event handler for Glyph / Rotate Left.
// Remarks        : Add 10 degrees to angle (rotate left, or counter-clockwise
//                  from current orientation), realize current character at new
//                  angle, redraw.
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnGlyphRotateLeft() 
{
  CGlyphDemoView *pView = reinterpret_cast<CGlyphDemoView *>(GetActiveView()); // view window
  CGlyphDemoDoc* pDoc;
  pDoc = reinterpret_cast<CGlyphDemoDoc *>(pView->GetDocument());
  ASSERT_VALID(pDoc);
  CDC *pDC = pView->GetDC(); // need a DC to realize the glyph

  // Adjust angle to 10 degrees more than previous value (counter-clockwise).
  pDoc->m_glyph.SetAngle(pDoc->m_glyph.GetAngle() + 10);

  // Must realize the glyph for change to take effect.
  pDoc->m_glyph.Realize(*pDC, &(pView->m_lf));

  // Redraw.
  pView->Invalidate();

}

////////////////////////////////////////////////////////////////////////////////
// Class          : CMainFrame
// Method         : OnGlyphRotateRight
// Description    : Menu event handler for Glyph / Rotate Right
// Remarks        : Subtract 10 degrees from angle (rotate right, or clockwise
//                  from current orientation), realize current character at new
//                  angle, redraw.
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnGlyphRotateRight() 
{
  CGlyphDemoView *pView = reinterpret_cast<CGlyphDemoView *>(GetActiveView()); // view window
  CGlyphDemoDoc* pDoc;
  pDoc = reinterpret_cast<CGlyphDemoDoc *>(pView->GetDocument());
  ASSERT_VALID(pDoc);
  CDC *pDC = pView->GetDC(); // need a DC to realize the glyph

  // Adjust angle to 10 degrees less than previous value (clockwise).
  pDoc->m_glyph.SetAngle(pDoc->m_glyph.GetAngle() - 10);

  // Must realize the glyph for change to take effect.
  pDoc->m_glyph.Realize(*pDC, &(pView->m_lf));

  // Redraw.
  pView->Invalidate();
  
}

////////////////////////////////////////////////////////////////////////////////
// Class          : CMainFrame
// Method         : OnGlyphZoomIn
// Description    : Menu event handler for Glyph / Zoom In.
// Remarks        : Change scale to 111% of current value, redraw (character
//                  becomes larger).
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnGlyphZoomIn() 
{
  CGlyphDemoView *pView = reinterpret_cast<CGlyphDemoView *>(GetActiveView()); // view window
  CGlyphDemoDoc* pDoc;
  pDoc = pView->GetDocument();
  ASSERT_VALID(pDoc);

  // Adjust scale to 111% of previous value (1.0/0.9).
  pDoc->m_glyph.m_dScale /= 0.9;

  // Don't need to realize glyph for change in scale, just redraw.
  pView->Invalidate();
  
}

////////////////////////////////////////////////////////////////////////////////
// Class          : CMainFrame
// Method         : OnGlyphZoomOut
// Description    : Menu event handler for Glyph / Zoom Out.
// Remarks        : Change scale to 90% of current value, redraw (character
//                  becomes smaller).
// Returns        : none
////////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnGlyphZoomOut() 
{
  CGlyphDemoView *pView = reinterpret_cast<CGlyphDemoView *>(GetActiveView()); // view window
  CGlyphDemoDoc* pDoc;
  pDoc = reinterpret_cast<CGlyphDemoDoc *>(pView->GetDocument());
  ASSERT_VALID(pDoc);

  // Adjust scale to 90% of previous value.
  pDoc->m_glyph.m_dScale *= 0.9;

  // Don't need to realize glyph for change in scale, just redraw.
  pView->Invalidate();
  
}
