// GlyphDemo.h : main header file for the GLYPHDEMO application
//

#if !defined(AFX_GLYPHDEMO_H__579BD685_C081_11D1_9212_444553540000__INCLUDED_)
#define AFX_GLYPHDEMO_H__579BD685_C081_11D1_9212_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
  #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"        // main symbols

// Constants
static const int SAMPLE_FONT_HT = 48; // font height for ChooseFont dialog
static const int GGO_FONT_HT = 576;   // font height for glyph realizing

/////////////////////////////////////////////////////////////////////////////
// CGlyphDemoApp:
// See GlyphDemo.cpp for the implementation of this class
//

class CGlyphDemoApp : public CWinApp
{
public:
  CGlyphDemoApp();

// Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CGlyphDemoApp)
  public:
  virtual BOOL InitInstance();
  //}}AFX_VIRTUAL

// Implementation

  //{{AFX_MSG(CGlyphDemoApp)
  afx_msg void OnAppAbout();
    // NOTE - the ClassWizard will add and remove member functions here.
    //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GLYPHDEMO_H__579BD685_C081_11D1_9212_444553540000__INCLUDED_)
