/* ============================================================
MultiThread.h
============================================================ */

#ifndef MULTITHREAD_H
#define MULTITHREAD_H

#include <windows.h>

class ThreadableObject;

DWORD WINAPI MultiThreadImpl( LPVOID lpParam );


class MultiThreadState 
{
public:
    enum {  UNINITIALIZED, INITIALIZED, 
            WORKING, SLEEPING, DONE,
            SUSPENDED, RESUMED };

    MultiThreadState();
    ~MultiThreadState();
    void Reset();

private:
    // not implemented
    MultiThreadState( const MultiThreadState& copyMe );
    MultiThreadState& operator=( const MultiThreadState& rhs );

    friend class MultiThread;
    friend DWORD WINAPI MultiThreadImpl( LPVOID lpParam );

    // Closing handle twice is an error.
    void CloseThreadHandle();
    HANDLE  m_hThread;

    HANDLE  m_hRunEvent;
    HANDLE  m_hWorkEvent;
    HANDLE  m_hDoneEvent;

    // Controls access to following data.
    HANDLE  m_hMutex;
    DWORD   m_dwCycleTime;
    bool    m_bStopThread;
    int     m_eState;
    DWORD   m_dwSuspendCount;

    ThreadableObject* m_pObject;
};


class MultiThread
{
public:
    MultiThread();
    ~MultiThread();

    bool Initialize(
                ThreadableObject* ptrClass,
                DWORD dwMilliSecs,
                DWORD dwStackSize = 0 );

    void Run();

    void RequestStop();
    bool IsStopping() const;

    void DoWork();

    DWORD CycleTime() const;
    void CycleTime( DWORD dwCycleTime );

    // Similar to Win32 functions, except they return the
    // threads current suspend count, not the previous count.

    DWORD Suspend();
    DWORD Resume();
    bool IsSuspended( DWORD* dwSuspendCount = NULL ) const;

    // Same as Win32 functions GetExitCodeThread and 
    // SetThreadPriority.

    BOOL ExitCode( LPDWORD lpExitCode );

    BOOL Priority( int nPriority );

    // Suspends caller until DoneEvent is signalled.

    void WaitUntilDone();

    // See enum in MultiThreadState for return values.

    int ThreadState() const;

private:
    // not implemented
    MultiThread( const MultiThread& copyMe );
    MultiThread& operator=( const MultiThread& rhs );

    MultiThreadState m_td;
};
#endif
