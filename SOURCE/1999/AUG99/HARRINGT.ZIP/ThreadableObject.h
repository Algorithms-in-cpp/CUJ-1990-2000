/* =====================================================
ThreadableObject.h
===================================================== */

#ifndef THREADABLEOBJECT_H
#define THREADABLEOBJECT_H

#include <windows.h>

class ThreadableObject
{
public:
    virtual ~ThreadableObject() {};

    virtual bool ThreadableTask( DWORD* dwReturnCode ) = 0;

private:
    // none
};
#endif
