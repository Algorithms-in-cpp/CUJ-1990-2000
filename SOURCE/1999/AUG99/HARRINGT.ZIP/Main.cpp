/* =======================================================
Main.cpp
======================================================= */

#include "derived.h"
#include "multithread.h"
#include <iostream>


int main()
{
    using namespace std;
    const int nSize = 26;
    int loop;

    // Create threadable objects

    Derived ObjectArray[nSize];
    for (loop = 0; loop < nSize; ++loop)
    {
        // letters of the alphabet
        ObjectArray[loop].SetChar('a' + (loop % 26) );
    }

    // Create threads

    MultiThread ThreadArray[nSize];
    for (loop = 0; loop < nSize; ++loop)
    {
        ThreadArray[loop].Initialize( &ObjectArray[loop], 10 );
        ThreadArray[loop].Run();       
    }

    // Wait until they finish

    for (loop = 0; loop < nSize; ++loop)
    {
        ThreadArray[loop].WaitUntilDone();
    }

    cout << endl;
    return 0;
}
