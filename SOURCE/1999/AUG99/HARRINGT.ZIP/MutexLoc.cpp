/* ==================================================
MutexLock.cpp
================================================== */

#include "mutexlock.h"


MutexLock::MutexLock()
{
    m_hMutex = 0;
}


MutexLock::MutexLock( HANDLE hMutex )
{
    m_hMutex = hMutex;
    WaitForSingleObject( hMutex, INFINITE );
}


MutexLock::~MutexLock()
{
    Release();
}


void MutexLock::Lock( HANDLE hMutex )
{
    Release();
    m_hMutex = hMutex;
    WaitForSingleObject( hMutex, INFINITE );
}


void MutexLock::Release()
{
    if ( m_hMutex )
    {
        ReleaseMutex( m_hMutex );
        m_hMutex = 0;
    }
}



