/* ======================================================
Derived.h
====================================================== */

#ifndef DERIVED_H
#define DERIVED_H

#ifndef THREADABLEOBJECT_H
#include "threadableobject.h"
#endif

class Derived : public ThreadableObject
{
public:
    Derived();
    ~Derived();
    
    void SetChar( char ch );

    // Pure Virtual function in MultiThread.
    virtual bool ThreadableTask(DWORD* dwReturnCode);

private:
    char m_ch;
    int m_nCount;
};
#endif
