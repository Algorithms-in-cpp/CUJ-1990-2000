/* ===================================================
MutexLock.h
=================================================== */

#ifndef MUTEXLOCK_H
#define MUTEXLOCK_H

#include <windows.h>

class MutexLock
{
public:
    MutexLock();
    MutexLock( HANDLE hMutex );
    ~MutexLock();

    // Releases previous lock, if any.
    void Lock( HANDLE hMutex );

private:
    HANDLE m_hMutex;

    void Release();

    // not implemented
    MutexLock( const MutexLock& copyMe );
    MutexLock& operator=( const MutexLock& rhs );
};
#endif
