/* ======================================================
Derived.cpp
====================================================== */

#include "derived.h"
#include <iostream>


Derived::Derived()
:ThreadableObject()
{
    m_ch = '\0';
    m_nCount = 0;
}


Derived::~Derived()
{}


void Derived::SetChar(char ch)
{
    m_ch = ch;
}


bool Derived::ThreadableTask( DWORD* dwReturnCode )
{
    using namespace std;

    while ( m_nCount < 100 )
    {
        cout << m_ch;
        m_nCount++;
        // return true;
    }

    *dwReturnCode = 0;
    return false;
}

