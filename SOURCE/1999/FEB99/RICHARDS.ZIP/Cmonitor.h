//-----------------------------------------------------------------------------
// Listing 3
//
// File : CMonitor.h"
//
//-----------------------------------------------------------------------------
#ifndef  CMonitor_H
#define  CMonitor_H

#include <assert.h>

#include "CMonMutex.h"

//-----------------------------------------------------------------------------
// Class    :  CMonitor
//
// Purpose  :  The template class protects a shared object of type T.
//             The class is constructed with a reference to an instance of
//             the shared object and the timeout value to use for the mutex.
//-----------------------------------------------------------------------------
template<class T> class CMonitor
{
public:
   //--------------------------------------------------------------------------
   // Class    :  CShield
   //
   // Purpose  :  The template class is a nested class within the CMonitor
   //             template class. The CMonitor class will have one insatnce
   //             of this class and it will return copies of this class
   //             via the copy constructor.
   //--------------------------------------------------------------------------
   template<class T> class CShield
   {
   public:
      //-----------------------------------------------------------------------
      // Method   :  Constructor
      //
      // Purpose  :  This constructor is used by the CMonitor class to
      //             create its own private instance.
      //-----------------------------------------------------------------------
      CShield(T& rElement, IMutex* pMutex, unsigned short usTimeOut = INFINITE)
      {
         m_pElement  = &rElement;
         m_pMutex    = pMutex;
         m_usTimeOut = usTimeOut;
         m_bCopy     = false;
      }

      //-----------------------------------------------------------------------
      // Method   :  Copy constructor
      //
      // Purpose  :  The copy constructor will copy the data from the orgininal
      //             class and call wait on the mutex as the last statement
      //             before returning.
      //-----------------------------------------------------------------------
      CShield(const CShield& shield)
      {
         assert( shield.m_bCopy != true );

         m_pElement  = shield.m_pElement;
         m_pMutex    = shield.m_pMutex;
         m_usTimeOut = shield.m_usTimeOut;
         m_bCopy     = true;

         m_pMutex->wait(m_usTimeOut);
      }

      //-----------------------------------------------------------------------
      // Method   :  Destructor
      //
      // Purpose  :  The destructor for an insatnce created with the copy
      //             constructor will call release on the mutex.
      //-----------------------------------------------------------------------
      ~CShield()
      {
         if( m_bCopy )
         {
            m_pMutex->release();
         }
      }

      //-----------------------------------------------------------------------
      // Method   : element
      //
      // Purpose  :  Return a reference to the element protected by the
      //             monitor.
      //-----------------------------------------------------------------------
      T& element() const
      {
         return *m_pElement;
      }

   protected:
      T*                m_pElement;       // pointer the object to protected
      IMutex*           m_pMutex;         // pointer to the mutex used
      unsigned short    m_usTimeOut;      // timeout value to use for mutex
      bool              m_bCopy;          // flag indicating if it is a copy

   private:
      // these methods are hidden here so that the complier
      // wont generate them
      CShield();
      CShield& operator=(const CShield& shield);
   };

   //--------------------------------------------------------------------------
   // Method   :  Constructor
   //
   // Purpose  :  The monitor is constructed with a reference to the element
   //             that must be protected and the timeout value
   //             to use when waiting.
   //--------------------------------------------------------------------------
   CMonitor(T& rElement, unsigned short usTimeOut = INFINITE)
   {
      m_usTimeOut = usTimeOut;
      m_pElement  = &rElement;

      m_pShield = new CShield<T>(*m_pElement, &m_Mutex, m_usTimeOut);
   }

   //--------------------------------------------------------------------------
   // Method   :  Destructor
   //
   // Purpose  :  Delete the internal copy of the shield object.
   //--------------------------------------------------------------------------
   virtual ~CMonitor()
   {
      delete m_pShield;
   }

   //--------------------------------------------------------------------------
   // Method   :  Safe
   //
   // Purpose  :  Return a copy of the shield object. This object is
   //             suppose to only be used on the stack.
   //--------------------------------------------------------------------------
   CShield<T> Safe()
   {
      return *m_pShield;
   }

protected:
   unsigned short       m_usTimeOut;      // timeout value to use when waiting
   T*                   m_pElement;       // pointer to protected element
   CMonMutex            m_Mutex;          // mutex to use for synchronization
   CShield<T>*          m_pShield;        // pointer to internal shield object

private:


};

#endif