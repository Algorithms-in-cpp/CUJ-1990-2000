//-----------------------------------------------------------------------------
// Listing 1
//
// File : MutexInterface.h"
//
//-----------------------------------------------------------------------------
#ifndef  MutexInterface_H
#define  MutexInterface_H

//-----------------------------------------------------------------------------
// MutexException
//
// Purpose  :  Typedef of exceptions that can be thrown by the IMutex
//             interface.
//-----------------------------------------------------------------------------
typedef enum
{
   TIMEOUT,
   ABANDONED
} MutexException;


//-----------------------------------------------------------------------------
// Class    :  IMutex
//
// Purpose  :  This is the interface specification for a simple mutex.
//-----------------------------------------------------------------------------
class IMutex
{
public:
   //--------------------------------------------------------------------------
   // Method   :  Destructor
   //
   // Purpose  :
   //--------------------------------------------------------------------------
   virtual ~IMutex() {};

   //--------------------------------------------------------------------------
   // Method   :  wait
   //
   // Purpose  :  Perform a wait on the mutex.
   //--------------------------------------------------------------------------
   virtual void wait(unsigned short usTimeOut) throw (MutexException) = 0;

   //--------------------------------------------------------------------------
   // Method   :  release
   //
   // Purpose  :  Release the mutex thats already owned by the calling thread.
   //--------------------------------------------------------------------------
   virtual void release() = 0;

protected:

private:

};

#endif
