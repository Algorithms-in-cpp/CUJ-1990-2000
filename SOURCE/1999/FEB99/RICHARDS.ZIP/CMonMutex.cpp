//-----------------------------------------------------------------------------
// Listing 2 b
//
// File : CMonMutex.cpp"
//
//-----------------------------------------------------------------------------
#include "CMonMutex.h"

//-----------------------------------------------------------------------------
// Class    :  CMonMutex
//
// Purpose  :  This is a win32 implementation of the IMutex interface.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Method   :  Constructor
//
// Purpose  :  Creates a win32 mutex.
//-----------------------------------------------------------------------------
CMonMutex::CMonMutex()
{
   m_hMutex = CreateMutex( NULL, FALSE, NULL );
}

//-----------------------------------------------------------------------------
// Method   :  Destructor
//
// Purpose  :  Destroy the win32 mutex.
//-----------------------------------------------------------------------------
CMonMutex::~CMonMutex()
{
   CloseHandle( m_hMutex );
}

//-----------------------------------------------------------------------------
// Method   :  wait
//
// Purpose  :  Wait on the mutex. If the timeout is reached and exception
//             will be thrown.
//-----------------------------------------------------------------------------
void CMonMutex::wait(unsigned short usTimeOut ) throw (MutexException)
{
   DWORD    dwResult;

   dwResult = WaitForSingleObject( m_hMutex, usTimeOut );

   if( dwResult == WAIT_OBJECT_0 )
      return;

   if( dwResult == WAIT_ABANDONED )
      throw(ABANDONED);

   if( dwResult == WAIT_TIMEOUT )
      throw(TIMEOUT);
}

//-----------------------------------------------------------------------------
// Method   :  release
//
// Purpose  :  Release the mutex.
//-----------------------------------------------------------------------------
void CMonMutex::release()
{
   ReleaseMutex( m_hMutex );
}
