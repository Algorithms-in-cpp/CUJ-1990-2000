//-----------------------------------------------------------------------------
// Listing 4
//
// File : Foo.h"
//
//-----------------------------------------------------------------------------
#ifndef  Foo_H
#define  Foo_H

class Foo
{
public:
   Foo() 
   {
      m_nValue = 1;   
   }

   ~Foo() 
   {
   
   }

   void inc( int nTimes )
   {
      for( int i = 0; i < nTimes; i++ )
      {
         Sleep( 100 );
         m_nValue++;

         cout << "Incrementing value..." << endl;
      }
   }

   int value()
   {
      return m_nValue;
   }

private:
   int   m_nValue;
};

#endif