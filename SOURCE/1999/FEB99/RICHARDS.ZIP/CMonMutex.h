//-----------------------------------------------------------------------------
// Listing 2 a
//
// File : CMonMutex.h"
//
//-----------------------------------------------------------------------------
#ifndef  CMonMutex_H
#define  CMonMutex_H

#include <windows.h>

#include "MutexInterface.h"

//-----------------------------------------------------------------------------
// Class    :  CMonMutex
//
// Purpose  :  This is a win32 implementation of the IMutex interface.
//-----------------------------------------------------------------------------
class CMonMutex: public IMutex
{
public:
   //--------------------------------------------------------------------------
   // Method   :  Constructor
   //
   // Purpose  :  Creates a win32 mutex.
   //--------------------------------------------------------------------------
   CMonMutex();

   //--------------------------------------------------------------------------
   // Method   :  Destructor
   //
   // Purpose  :  Destroy the win32 mutex.
   //--------------------------------------------------------------------------
   virtual ~CMonMutex();

   //--------------------------------------------------------------------------
   // Method   :  wait
   //
   // Purpose  :  Wait on the mutex. If the timeout is reached and exception
   //             will be thrown.
   //--------------------------------------------------------------------------
   virtual void wait(unsigned short usTimeOut = INFINITE) throw (MutexException);

   //--------------------------------------------------------------------------
   // Method   :  release
   //
   // Purpose  :  Release the mutex.
   //--------------------------------------------------------------------------
   virtual void release();

private:

protected:
   HANDLE      m_hMutex;         // handle to the win32 mutex
};

#endif