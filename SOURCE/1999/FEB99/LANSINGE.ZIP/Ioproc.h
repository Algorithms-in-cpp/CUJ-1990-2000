/*

IOPROC.H - header file for IOPROC.CPP

This work is dedicated to the public domain by the author,
Edward J. Lansinger (lansie@rpi.edu).  It is therefore not
protected by copyright and can be used freely by anyone
for any purpose.

*/

#ifndef _IOPROC_H
#define _IOPROC_H

#include "std.h"
#include "lcd.h"
#include "dummy.h"

#define MAXDIALCOUNTS 1023

class IOFieldClass;

struct ZFieldListRec
{
  IOFieldClass *F;
  UINT Z;
  ZFieldListRec *pNext;
};

struct TabStopFieldListRec
{
  IOFieldClass *F;
  UINT TabStopIndex;
  TabStopFieldListRec *pNext;
};

class IOProcessClass : ProcessClass
{
  ULONG LastDisplayTime;
  UINT LastDialPosition;
  virtual void Go();
  ZFieldListRec *ZListHead;
  TabStopFieldListRec *TabStopListHead;
  TabStopFieldListRec *Focus;
  void RightSWButtonPress();
    /* Sent when the right steering wheel button is pressed. */
    /* Triggers data logging. */
protected:
  LCDDisplayClass Display; /* use this for all display purposes */
  virtual void Paint();
    /* Sent no faster than maximum screen update rate.  IOProcess should
    redraw anything that changed since the last update. */
  /* Driver input messages.  These are sent only when the Display
  belonging to the IOProcess is visible. */
  virtual void LeftSWButtonPress();
    /* Sent when the left steering wheel button is pressed */
    /* Default action is to move focus to next input control. */
  virtual void DialMovedTo(UINT Position);
    /* Sent on a change of position of the input potentiometer.  The
    "dial" has positions numbered 0..MAXDIALCOUNTS, so Position will take
    on only these values.*/
    /* Default action is to send the value to the input control that
    has focus. */
  void RegisterField(IOFieldClass *F, UINT ZOrder = 0, UINT TabStopIndex = 0);
    /* register field with the IOProcess, defining a Z ordering for
    painting (lower numbers get painted first), and optionally define
    the tab stop index for accepting input messages.  If TabStopIndex
    is omitted or set to zero, the field will receive no input messages. */
  void DeRegisterField(IOFieldClass *F);
  IOFieldClass *FieldThatHasFocus();
    /* returns a pointer to the field that has focus, or
    NULL if no field has focus */
public:
  IOProcessClass(); /* clears the Display to White */
friend IOFieldClass;
};

class IOFieldClass
{
protected:
  UINT X, Y; // upper left corner
  UINT W, H; // height and width
  LCDDisplayClass *Display;
public:
  IOFieldClass(LCDDisplayClass *d, UINT x, UINT y, UINT h, UINT w);
  ~IOFieldClass();
  virtual void Paint();
  virtual void Clear();
    /* clears the region that the field owns */
  // Input messages
  // The base IOProcess class does not send RightSW and LeftSW
  // button presses to registered input fields.  RightSW is used
  // to trigger data logging and LeftSW is used to move input
  // focus.
  virtual void GotFocus(); // called when the field gets input focus
  virtual void LostFocus(); // called when the field loses the input focus
  virtual void RightSWButtonPress();
  virtual void LeftSWButtonPress();
  virtual void DialMovedTo(UINT Position);
friend IOProcessClass;
};

class TextOutputIOFieldClass : public IOFieldClass
{
protected:
  Font FontToUse;
  TextColor TColor;
  char buf[32];
  BOOL Changed;
public:
  TextOutputIOFieldClass(LCDDisplayClass *d, UINT x, UINT y, UINT w, UINT h);
  void SetText (Font F, TextColor TC, char *s);
  virtual void Paint();
};

enum StripChartOrientation {Vertical, Horizontal};

class StripChartFieldClass : public IOFieldClass
{
  UINT *DataBuf;  // data to plot
  PixelLoc *PixelBuf; // coordinates of pixels last plotted
  UINT PixelCount; // number of points plotted last time through
  UINT NumPoints; // number of data points stored in Buf
  UINT DataHead;  // newest value in DataBuf
  UINT DataTail;  // oldest value in DataBuf
  StripChartOrientation Orientation;
  BOOL Changed;
public:
  StripChartFieldClass(LCDDisplayClass *d, UINT x, UINT y, UINT w, UINT h,
                       StripChartOrientation o);
  void NewPoint(UINT val);  // scaled so 0 is min and MAX(UINT) is max
  virtual void Paint();
};

class ParmSelectFieldClass : public TextOutputIOFieldClass
{
protected:
  PRMClass *PRM;
public:
  ParmSelectFieldClass(LCDDisplayClass *d, UINT x, UINT y, UINT w, UINT h);
  PRMClass *GetParm(); // returns currently selected PRM
  virtual void GotFocus();
  virtual void LostFocus();
  virtual void DialMovedTo(UINT Position);
};

#endif
