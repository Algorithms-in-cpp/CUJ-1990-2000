/*

LCD.CPP - source file for LCDDisplayClass class and support classes

This work is dedicated to the public domain by the author,
Edward J. Lansinger (lansie@rpi.edu).  It is therefore not
protected by copyright and can be used freely by anyone
for any purpose.

Most of the code in this source file is specifically for the
DMF5005 LCD and compatibles.

*/

#include "lcd.h"

/*

The following three routines are assembly-language routines
in an external library.  See the source file "LCDLIB.S16"
for details.

*/

extern void LCDInit();
extern void LCDWriteData(BYTE D);
extern void LCDWriteCommand(BYTE C);

/*

These constants are specifically for the DMF5005 LCD and
compatibles.

*/

const static UINT BytesPerDisplay = 1920;
const static UINT MinX = 0;
const static UINT MaxX = 239;
const static UINT MinY = 0;
const static UINT MaxY = 63;
const static UINT AspectRatioNumerator = 1;
const static UINT AspectRatioDenominator = 1;

static BOOL PhysicalDisplayInitialized = FALSE;
static UINT NextDisplayID = 0;
static UINT CurrentDisplayID = 0; // ID of virtual display actually shown

BOOL LCDDisplayClass::IsVisible()
{
  return (ID == CurrentDisplayID);  // true if the LCD is actually showing
                  // the virtual display owned by this object
}

UINT LCDDisplayClass::GetMaxX() { return MaxX; };
UINT LCDDisplayClass::GetMaxY() { return MaxY; };
UINT LCDDisplayClass::GetAspectRatioNumerator() { return AspectRatioNumerator; };
UINT LCDDisplayClass::GetAspectRatioDenominator() { return AspectRatioDenominator; };

LCDDisplayClass::LCDDisplayClass()
{
  ID = NextDisplayID;
  GraphicsHomeAddress = NextDisplayID * BytesPerDisplay;
  NextDisplayID++;
  if (!PhysicalDisplayInitialized)
  {
    LCDDisplay_InitPhysicalDisplay();
    PhysicalDisplayInitialized = TRUE;
  }
}

void LCDDisplay_InitPhysicalDisplay()
{
  LCDInit();

  // Mode set: use CG ROM, OR text and graphics 0x80
  LCDWriteCommand(0x80);

  // Set text home address to $0000 (i.e. doesn't matter)
  LCDWriteData(0x00);
  LCDWriteData(0x00);
  LCDWriteCommand(0x40);

  // Set text number of columns to 30.
  LCDWriteData(30);
  LCDWriteData(0);
  LCDWriteCommand(0x41);

  // Set graphics home address to 0, i.e. the first display, i.e. this
  // display.
  LCDWriteData(0);
  LCDWriteData(0);
  LCDWriteCommand(0x42);

  // Make sure the number of graphics "columns" is 30.
  LCDWriteData(30);
  LCDWriteData(0x00);
  LCDWriteCommand(0x43);

  // Set the display mode to graphics only, no cursor.
  LCDWriteCommand(0x98);
}

void LCDDisplayClass::ClearScreen()
{
  UINT j;
  // Point to correct screen region
  LCDWriteData(LOBYTE(GraphicsHomeAddress));
  LCDWriteData(HIBYTE(GraphicsHomeAddress));
  LCDWriteCommand(0x24); // address pointer set command
  // Fill the region with zeros to clear it.
  for (j = 1; j<=BytesPerDisplay; j++)
  {
    LCDWriteData(0);
    LCDWriteCommand(0xC0);
  }
}

void LCDDisplayClass::FillRegion(UINT  X,
                                 UINT  Y,
                                 UINT  W,
                                 UINT  H,
                                 Color C
                                )
/*

Fills a region on the screen. The upper-left corner is (X, Y).  The region
is W pixels wide and H pixels high.  This routine is fastest when X is on
a byte boundary (i.e. a multiple of eight).  This routine is based on
HLine.

*/
{
  short i,istop;

  if ((W != 0) && (H !=0) && (X <= MaxX))
  {
    istop = Y + H;
    for (i = Y; i<istop; i++) // for each row
      HLine(X, i, W, C);
  }
//  else
//    IgnorableError(LCDDisplay_PlotOutOfBounds);
}


void LCDDisplayClass::Plot(UINT  X,
                           UINT  Y,
                           Color C
                          )
/*

Plots a dot at (X, Y) in color C.  (MinX, MinY) is the upper-left
corner of the screen.  (MaxX, MaxY) is the lower-right corner. If (X, Y)
is off the screen, no dot is plotted.

*/
{
  WORD Address;
  BYTE BitSetCommand;

  if ((X > MaxX) || (Y > MaxY))
  {
    //IgnorableError(LCDDisplay_PlotOutOfBounds);
  }
  else
  {
    Address = (30*Y+X/8)+GraphicsHomeAddress;
  
    // Now that we know what byte contains the specified dot, set the
    // LCD display address pointer to point to that location.
    LCDWriteData(LOBYTE(Address));
    LCDWriteData(HIBYTE(Address));
    LCDWriteCommand(0x24); // address pointer set command
  
    // Now set or clear the correct bit at that address.
    // Figure out which bit in that byte to set.
    BitSetCommand = 7 - (X % 8);
    // Set the color of the bit.
    if (C == Black)
      BitSetCommand = BitSetCommand | 0x08; // Set the bit.
    BitSetCommand = BitSetCommand | 0xF0; // Finish the command.
    LCDWriteCommand(BitSetCommand);
  }
}

void LCDDisplayClass::HLine(UINT  X,
                            UINT  Y,
                            UINT  Length,
                            Color C
                           )
/*

This routine draws a horizontal line in the specified color.  It has been
optimized for speed.  Any portion of the line that can be drawn as eight
contiguous pixels all in the same byte will be drawn with a single "byte
set" instruction rather than eight Plot instructions.

*/
{
  UINT x, xstop, i;
  short istop;
  WORD Address;
  BYTE fill = 0x00;

  if ((X > MaxX) || (Y > MaxY))
  {
    //IgnorableError(LCDDisplay_PlotOutOfBounds);
    return;
  }

  x = X;
  xstop = X + Length;
  if (C == Black) fill = 0xFF;


  // Do the part of the line on the left edge which does not begin
  // on a byte boundary, if any.
  while ((x % 8) && (x < xstop))
  {
    Plot(x, Y, C);
    x++;
  }
  if ((x != xstop) && (x < MaxX))
  {
    istop = (((xstop > MaxX) ? MaxX : xstop) - x) / 8;
    if (istop > 0)
    {
      // Do the middle section of the line (which begins and ends on a byte
      // boundary) a byte (eight pixels) at a time.
      Address = (30*Y+x/8)+GraphicsHomeAddress;
      LCDWriteData(LOBYTE(Address));
      LCDWriteData(HIBYTE(Address));
      LCDWriteCommand(0x24); // address pointer set command
      for(i = 0; i < istop; i++)
      {
        LCDWriteData(fill);
        LCDWriteCommand(0xC0);
        x+=8;
      }
    }
    while (x < xstop) // do remainder of line
    {
      Plot(x, Y, C);
      x++;
    }
  }
}

void LCDDisplayClass::VLine(UINT  X,
                            UINT  Y,
                            UINT  Length,
                            Color C
                           )
/*

This routine is much slower than HLine for long lines of the same length
because each dot is in a different byte.

*/
{
  UINT i, istop;
  istop = Y + Length;
  for (i = Y; i < istop; ++i)
    Plot(X, i, C);
}

void LCDDisplayClass::Line(UINT X1,
                           UINT Y1, 
                           UINT X2,
                           UINT Y2, 
                           Color C 
                          )
{  
  short  deltaX, deltaY;     // delta's to compute slope
  short  xStart, yStart;     // start values of abscissa, ordinate
  short  xFinish, yFinish;   // end values of abscissa, ordinate
  short  currentX, currentY; // current plot value of abscissa, ordinate
  short  slope;              // slope = deltaY/deltaX
  short  incr;               // how much to increment delta1
  UINT   i;                  // how much to increment delta2

  deltaY = (Y2-Y1);  // compute deltaY
  deltaX = (X2-X1);  // compute deltaX

  if (deltaY == 0)  // if deltaY == 0, then horizontal line
  {
    if (deltaX < 0)
      HLine(X2, Y1, -deltaX, C);
    else
      HLine(X1, Y1, deltaX, C);
    goto Return;
  }
  else
    if (deltaX == 0)  // if deltaX == 0 , slope undefined, vertical line
    {
      if (deltaY < 0)
        VLine(X1, Y2, -deltaY, C);
      else
        VLine(X1, Y1, deltaY, C);
      goto Return;
    }
  slope  = (deltaY/deltaX);  // compute slope
  if (slope < 0) slope = -(slope);  // make it positive
  if (deltaY < 0)
  {
    yStart = Y2; xStart = X2;
    yFinish = Y1; xFinish = X1;  // define starting/ending points
    if (deltaX > 0)  // if delta is greater than 0
      incr = 1;  // the delta incrementer will be 1
    else  // otherwise
    {
      if (slope > 1)  // if deltaY < 0 and deltaX < 0 and slope > 1, then 
      {
        yStart = Y1; xStart = X1;  // redefine starting/ending points
        yFinish = Y2; xFinish = X2;
      }
      incr = -1;  // if deltaY < 0 and deltaX < 0 and slope <= 1, then delta incr = -1
      deltaY = -(deltaY);  // and switch sign on deltaY
    }
  }
  else if (deltaY > 0)
  {  
    yStart = Y1; xStart = X1; yFinish = Y2; xFinish = X2;
    if (deltaX < 0)
      incr = 1;
    else
    {
      if (slope > 1)
      {
        yStart = Y2; xStart = X2;
        yFinish = Y1; xFinish = X1;
      }
      deltaY = -(deltaY);
      incr = -1;
    }
  }
  if (slope <= 1)  // define initial currentX and currentY for slope <= 1
  {
    currentX = (xStart-incr);
    currentY = (yStart-(deltaY/deltaX));
  }
  else
  {
    currentX = (xStart+(deltaX/deltaY));
    currentY = (yStart+incr);
  }
  i = 1;
  while ((currentX != xFinish) || (currentY != yFinish))  // stop when reach final values
  {
    if (slope <= 1)
    {
      currentX = (xStart-(i*incr));
      currentY = (yStart-((i*deltaY)/(deltaX)));
    }
    else
    {
      currentX = (xStart+((i*deltaX)/(deltaY)));
      currentY = (yStart+(i*incr));
    }
    Plot (currentX, currentY, C);
    i++;
  }
Return:;
}

/*

The following array defines bitmaps for the smallest available font.  Note
that only a subset of the ASCII printable characters is defined.

*/

const BYTE  _8x8Map[]  = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,   //space
                           0x02, 0x02, 0x02, 0x02, 0x02, 0x00, 0x02, 0x00,   // !
                           0x0a, 0x0a, 0x0a, 0x00, 0x00, 0x00, 0x00, 0x00,   // "
                           0x0a, 0x0a, 0x1f, 0x0a, 0x1f, 0x0a, 0x0a, 0x00,   // #
                           0x04, 0x0f, 0x14, 0x0e, 0x05, 0x1e, 0x04, 0x00,   // $
                           0x21, 0x02, 0x04, 0x08, 0x10, 0x21, 0x00, 0x00,   // %
                           0x1c, 0x22, 0x14, 0x08, 0x24, 0x26, 0x19, 0x00,   // &
                           0x04, 0x04, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00,   // '
                           0x02, 0x04, 0x08, 0x08, 0x08, 0x04, 0x02, 0x00,   // (
                           0x08, 0x04, 0x02, 0x02, 0x02, 0x04, 0x08, 0x00,   // )
                           0x49, 0x2a, 0x1c, 0x7f, 0x1c, 0x2a, 0x49, 0x00,   // *
                           0x00, 0x04, 0x04, 0x1f, 0x04, 0x04, 0x00, 0x00,   // +
                           0x04, 0x04, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00,   // �
                           0x00, 0x00, 0x00, 0x1e, 0x00, 0x00, 0x00, 0x00,   // -
                           0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00,   // .
                           0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x00,   // /
                           0x0e, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0e, 0x00,   // 0
                           0x04, 0x0c, 0x04, 0x04, 0x04, 0x04, 0x0e, 0x00,   // 1
                           0x0e, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1f, 0x00,   // 2
                           0x0e, 0x11, 0x01, 0x0e, 0x01, 0x11, 0x0e, 0x00,   // 3
                           0x02, 0x06, 0x0a, 0x12, 0x1f, 0x02, 0x02, 0x00,   // 4
                           0x1f, 0x10, 0x1e, 0x01, 0x01, 0x11, 0x0e, 0x00,   // 5
                           0x06, 0x08, 0x10, 0x1e, 0x11, 0x11, 0x0e, 0x00,   // 6
                           0x1f, 0x01, 0x02, 0x04, 0x04, 0x04, 0x04, 0x00,   // 7
                           0x0e, 0x11, 0x11, 0x0e, 0x11, 0x11, 0x0e, 0x00,   // 8
                           0x0e, 0x11, 0x11, 0x0e, 0x01, 0x02, 0x06, 0x00,   // 9
                           0x00, 0x00, 0x04, 0x00, 0x00, 0x04, 0x00, 0x00,   // :
                           0x00, 0x00, 0x04, 0x00, 0x04, 0x04, 0x08, 0x00,   // ;
                           0x02, 0x04, 0x08, 0x10, 0x08, 0x04, 0x02, 0x00,   // <
                           0x00, 0x00, 0x1f, 0x00, 0x1f, 0x00, 0x00, 0x00,   // =
                           0x08, 0x04, 0x02, 0x01, 0x02, 0x04, 0x08, 0x00,   // >
                           0x0e, 0x11, 0x01, 0x02, 0x04, 0x04, 0x00, 0x04,   // ?
                           0x0e, 0x11, 0x01, 0x09, 0x15, 0x15, 0x0e, 0x00,   // @
                           0x0e, 0x11, 0x11, 0x1f, 0x11, 0x11, 0x11, 0x00,   // A
                           0x1e, 0x11, 0x11, 0x1e, 0x11, 0x11, 0x1e, 0x00,   // B
                           0x0e, 0x11, 0x10, 0x10, 0x10, 0x11, 0x0e, 0x00,   // C
                           0x1e, 0x09, 0x09, 0x09, 0x09, 0x09, 0x1e, 0x00,   // D
                           0x1f, 0x10, 0x10, 0x1f, 0x10, 0x10, 0x1f, 0x00,   // E
                           0x1f, 0x10, 0x10, 0x1e, 0x10, 0x10, 0x10, 0x00,   // F
                           0x0e, 0x11, 0x10, 0x13, 0x11, 0x11, 0x0f, 0x00,   // G
                           0x11, 0x11, 0x11, 0x1f, 0x11, 0x11, 0x11, 0x00,   // H
                           0x0e, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0e, 0x00,   // I
                           0x07, 0x02, 0x02, 0x02, 0x02, 0x12, 0x0c, 0x00,   // J
                           0x11, 0x12, 0x14, 0x18, 0x14, 0x12, 0x11, 0x00,   // K
                           0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1f, 0x00,   // L
                           0x11, 0x1b, 0x15, 0x15, 0x11, 0x11, 0x11, 0x00,   // M
                           0x11, 0x19, 0x15, 0x15, 0x13, 0x11, 0x11, 0x00,   // N
                           0x0e, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0e, 0x00,   // O
                           0x1e, 0x11, 0x11, 0x1e, 0x10, 0x10, 0x10, 0x00,   // P
                           0x0e, 0x11, 0x11, 0x11, 0x15, 0x13, 0x0e, 0x00,   // Q
                           0x1e, 0x11, 0x11, 0x1e, 0x14, 0x12, 0x11, 0x00,   // R
                           0x0e, 0x11, 0x10, 0x0e, 0x01, 0x11, 0x0e, 0x00,   // S
                           0x1f, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x00,   // T
                           0x11, 0x11, 0x11, 0x11, 0x11, 0x12, 0x1e, 0x00,   // U
                           0x11, 0x11, 0x11, 0x11, 0x11, 0x04, 0x04, 0x00,   // V
                           0x11, 0x11, 0x11, 0x15, 0x15, 0x1b, 0x11, 0x00,   // W
                           0x11, 0x11, 0x0a, 0x04, 0x0a, 0x11, 0x11, 0x00,   // X
                           0x11, 0x11, 0x0a, 0x04, 0x04, 0x04, 0x04, 0x00,   // Y
                           0x1f, 0x01, 0x02, 0x04, 0x08, 0x10, 0x1f, 0x00,   // Z
                           0x0e, 0x08, 0x08, 0x08, 0x08, 0x08, 0x0e, 0x00,   // [
                           0x00, 0x10, 0x08, 0x04, 0x02, 0x01, 0x00, 0x00,   // backslash
                           0x0e, 0x02, 0x02, 0x02, 0x02, 0x02, 0x0e, 0x00,   // ]
                           0x04, 0x0a, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00,   // ^
                           0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1f, 0x00,   // _
                           0x10, 0x08, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00 }; // `


// XScale and YScale must be ordered the same way that Font is ordered.
// They are used in scaling the base font to different sizes.

BYTE XScale[] = {1, 1, 1, 1, 1, 1, 1,
                 2, 2, 2, 2, 2, 2, 2,
                 3, 3, 3, 3, 3, 3, 3,
                 4, 4, 4, 4, 4, 4, 4,
                 5, 5, 5, 5, 5, 5, 5,
                 6, 6, 6, 6, 6, 6, 6,
                 7, 7, 7, 7, 7, 7, 7
                };
BYTE YScale[] = {1, 2, 3, 4, 5, 6, 7,
                 1, 2, 3, 4, 5, 6, 7,
                 1, 2, 3, 4, 5, 6, 7,
                 1, 2, 3, 4, 5, 6, 7,
                 1, 2, 3, 4, 5, 6, 7,
                 1, 2, 3, 4, 5, 6, 7,
                 1, 2, 3, 4, 5, 6, 7
                };

void LCDDisplayClass::TextOut (UINT      X,     // "X" coordinate of text position
                               UINT      Y,     // "Y" coordinate of text position
                               Font      Fnt,
                               TextColor TC,
                               PSTR      szText // string to display
                              )
{ 
  UINT  xCount, yCount; // counter variables
  UINT  xDouble, yDouble;
  BYTE  pattern;
  BYTE  bitPosition;
  UINT  x_mul, y_mul;
  BYTE  *charAddress;
  Color DotColor;

  x_mul =XScale[Fnt];
  y_mul =YScale[Fnt];

  while (*szText)
  {
    /* charAddress is computed by offsetting the ascii character by 20
     since the first byte in _8x8Map will be ascii ' '.  Then each
     subsequent character will appear in the _8x8Map in the same order
     as it appears in ascii.  It is then multiplied by the width to 
     jump over Fnt bytes, and the result is added to the base address
     of _8x8Map
    */
    charAddress = ((BYTE *)_8x8Map + (((*szText)-0x20) * 8));
    for (yCount=0; yCount<8; yCount++) // each 8x8 char bitmap is 8 bytes deep
    {
      for (yDouble=0; yDouble<y_mul; yDouble++)  // if font is double high, need to do twice
      {
        pattern = *charAddress;  // get first 8 bit pattern
        bitPosition = 0x80;  // initialize bitPosition
        xCount = 0;
        /* if this is an opaque color, clear out the background */
        if (TC == BlackOnWhite)
          HLine(X, Y+(yCount*y_mul+yDouble), x_mul * 8, White);
        else
          if (TC == WhiteOnBlack)
            HLine(X, Y+(yCount*y_mul+yDouble), x_mul * 8, Black);
        if (*szText != ' ') // if a space, nothing more need be done
          while (xCount < (x_mul * 8))  // scan byte pattern doubling as necessary
          {
            BYTE tmp;
            tmp = (bitPosition & pattern);
            if (tmp == 0) // means it's background and has already been plotted
              xCount+=x_mul; // don't plot a dot
            else
            {
              if ((TC == WhiteOnBlack) || (TC == WhiteOnClear))
                DotColor = White;
              else
                DotColor = Black;
              for (xDouble=0;xDouble<x_mul;xDouble++)  // need to double?
                Plot(X+(xCount++),Y+(yCount*y_mul+yDouble),DotColor);
            }
            bitPosition >>= 1;
          }
      }
      charAddress++;
    }
    X += x_mul * 8;  // update X coordinate on display
    szText++;
  }
}

void LCDDisplayClass::ByteBlt(UINT Offset,
                              UINT Count,
                              BYTE *Buf
                             )
/*

Blts an array of bytes to the physical display.  "Offset" is the target
address for the blit measured in bytes offset from the first byte
of the display.

*/
{
  if (Offset > (BytesPerDisplay - 1))
    Offset = BytesPerDisplay - 1;
  if ((Count + Offset) > BytesPerDisplay)
    Count = BytesPerDisplay - Offset;

  UINT Address, i;

  Address = Offset+GraphicsHomeAddress;
  LCDWriteData(LOBYTE(Address));
  LCDWriteData(HIBYTE(Address));
  LCDWriteCommand(0x24); // address pointer set command
  for(i = 0; i < Count; i++)
  {
    LCDWriteData(*Buf);
    LCDWriteCommand(0xC0);
    Buf += 1;
  }
}

void NextLCDDisplay()
/*

Switches the physical display to show the next virtual display.

*/
{
  WORD GHA;
  CurrentDisplayID = (CurrentDisplayID + 1) % NextDisplayID;
  GHA = CurrentDisplayID*BytesPerDisplay;
  // Set graphics home address
  LCDWriteData(LOBYTE(GHA));
  LCDWriteData(HIBYTE(GHA));
  LCDWriteCommand(0x42);
}

void FirstLCDDisplay()
/*

Switches the physical display to show the first virtual display.

*/
{
  WORD GHA;
  CurrentDisplayID = 0;
  GHA = 0; //CurrentDisplayID*BytesPerDisplay;
  // Set graphics home address
  LCDWriteData(LOBYTE(GHA));
  LCDWriteData(HIBYTE(GHA));
  LCDWriteCommand(0x42);
}

UINT LCDDisplayCount()
{
  return NextDisplayID;
}
