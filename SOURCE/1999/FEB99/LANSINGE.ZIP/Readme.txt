This archive contains the source code that accompanies the article
"A Lightweight C++ Library for Embedded LCDs" by Edward J. Lansinger,
published in the February, 1999 issue of "C/C++ Users Journal".

All files in this archive have been placed in the public domain
by the author, Edward J. Lansinger.  Notices to this effect appear
at the head of each file.

Although this code was taken from a running system, the author
warns that it may yet contain errors, it may not work as expected,
and that it may not be safe to use in critical applications or
any other application.

The files in this archive are as follows:
  README.TXT     - this file
  STD.H          - various common #defines and typedefs 
  DUMMY.H        - declarations required for a clean compile (the
                   actual function definitions are not included
                   because they are beyond the scope of the article)
  LCD.H, .CPP    - source for LCDDisplayClass and support routines;
                   this virtualizes the display hardware and provides
                   drawing routines
  IOPROC.H, .CPP - source for IOProcess class derivatives; these
                   automate the creation and painting of different
                   types of I/O control fields in a window

The code compiled without errors or warnings on Microsoft Visual
C++ 5.0.  It does not link, of course, as it is not a complete
application.

You are welcome to direct any questions you may have to the
author by email at lansie@rpi.edu.  Additional information may
be found at the following web site:

    http://www.dbit.com/~lansie/lcd.htm

[Thank you for reading the article! - Ed Lansinger]


