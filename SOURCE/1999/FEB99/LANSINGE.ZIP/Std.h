/*

STD.H - standard #defines and typedefs

This work is dedicated to the public domain by the author,
Edward J. Lansinger (lansie@rpi.edu).  It is therefore not
protected by copyright and can be used freely by anyone
for any purpose.

*/

#ifndef _STD_H
#define _STD_H

/*

The following "standard" #defines and typedefs could be
removed if their equivalents are defined elsewhere.

*/

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned short UINT;
typedef short BOOL;
typedef unsigned long DWORD;
typedef unsigned long ULONG;
typedef char * PSTR;

#define TRUE 1
#define FALSE 0

#define LOWORD(l) ((WORD)(l))
#define HIWORD(l) ((WORD)(((DWORD)(l) >> 16) & 0xFFFF))
#define LOBYTE(w) ((BYTE)(w))
#define HIBYTE(w) ((BYTE)(((WORD)(w) >> 8) & 0xFF))

#define MIN(a,b) ((a<b) ? a : b)
#define MAX(a,b) ((a<b) ? b : a)

#define NULL 0
#define USHRT_MAX       65535U          /* maximum unsigned short value */


#endif
