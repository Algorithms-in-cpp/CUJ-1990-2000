/*

LCD.H - header file for LCD.CPP

This work is dedicated to the public domain by the author,
Edward J. Lansinger (lansie@rpi.edu).  It is therefore not
protected by copyright and can be used freely by anyone
for any purpose.

*/

#ifndef _LCD_H
#define _LCD_H

#include "std.h"

enum Color {White, Black};
enum TextColor {BlackOnWhite, WhiteOnBlack, BlackOnClear, WhiteOnClear};

/* WidthxHeight in pixels of the available "fonts" (okay, so it's
really only one font available in different sizes) */

enum Font { _8x8,   _8x16,  _8x24,  _8x32,
            _8x40,  _8x48,  _8x56,  _16x8,
            _16x16, _16x24, _16x32, _16x40,
            _16x48, _16x56, _24x8,  _24x16,
            _24x24, _24x32, _24x40, _24x48,
            _24x56, _32x8,  _32x16, _32x24,
            _32x32, _32x40, _32x48, _32x56,
            _40x8,  _40x16, _40x24, _40x32,
            _40x40, _40x48, _40x56, _48x8,
            _48x16, _48x24, _48x32, _48x40,
            _48x48, _48x56, _56x8,  _56x16,
            _56x24, _56x32, _56x40, _56x48,
            _56x56s };

void LCDDisplay_InitPhysicalDisplay();

struct PixelLoc
{
  UINT X;
  UINT Y;
};

class LCDDisplayClass
{
  UINT ID;
  WORD GraphicsHomeAddress;
public:
  LCDDisplayClass();
  BOOL IsVisible();
  UINT GetMaxX();
  UINT GetMaxY();
  UINT GetAspectRatioNumerator();
  UINT GetAspectRatioDenominator();
  void ClearScreen();
  void FillRegion(UINT  X,
                  UINT  Y,
                  UINT  W,
                  UINT  H,
                  Color C
                 );
  void Plot(UINT  X,
            UINT  Y,
            Color C
           );
  void HLine(UINT  X,
             UINT  Y,
             UINT  Length,
             Color C
            );
  void VLine(UINT  X,
             UINT  Y,
             UINT  Length,
             Color C
            );
  void Line(UINT X1,
            UINT Y1, 
            UINT X2,
            UINT Y2, 
            Color C 
           );
  void TextOut(UINT      X,
               UINT      Y,
               Font      Fnt,
               TextColor TC,
               PSTR      szText
              );
  void ByteBlt(UINT      Offset,
               UINT      Count,
               BYTE      *Buf
              );
friend void NextLCDDisplay();
friend void FirstLCDDisplay();
friend UINT LCDDisplayCount();
};

void NextLCDDisplay();
void FirstLCDDisplay();
UINT LCDDisplayCount();

#endif
