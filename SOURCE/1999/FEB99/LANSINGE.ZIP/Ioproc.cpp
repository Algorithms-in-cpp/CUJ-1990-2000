/*

IOPROC.CPP - source file for class IOProcessClass

This work is dedicated to the public domain by the author,
Edward J. Lansinger (lansie@rpi.edu).  It is therefore not
protected by copyright and can be used freely by anyone
for any purpose.

*/

#include "ioproc.h"
#include "lcd.h"
#include "dummy.h"
#include <string.h>
#include <stdio.h>

IOProcessClass::IOProcessClass()
{
  ZListHead = NULL;
  TabStopListHead = NULL;
  Focus = NULL;
  Display.ClearScreen();
}

void IOProcessClass::Go()
{
  if (!DataLogger.IsRecording())
  {
    if (DataLogger.SetRecordTime(128))
      (void) DataLogger.Enable(EndTrigger);
  }

  if (Display.IsVisible())
  {
    ULONG Time = SlowClock.Time() >> 3;
    if (Time != LastDisplayTime)
    {
      UINT PressCount, i;

      PressCount = RightSWButton.GetPressCount();
      for (i = 0; i < PressCount; i += 1)
        this->RightSWButtonPress();

      PressCount = LeftSWButton.GetPressCount();
      for (i = 0; i < PressCount; i += 1)
        this->LeftSWButtonPress();

      UINT Position;
      Position = Dial.GetVal1024();
      if (Position != LastDialPosition)
      {
        LastDialPosition = Position;
        this->DialMovedTo(Position);
      }

      this->Paint();

      LastDisplayTime = Time;
    }
  }
}

void IOProcessClass::Paint()
{
  /* Paint the Fields in order */
  IOFieldClass *F;
  ZFieldListRec *p;
  p = ZListHead;
  while (p != NULL)
  {
    F = p->F;
    F->Paint();
    p = p->pNext;
  }
}

void IOProcessClass::RightSWButtonPress()
/* Trigger Data Logging */
{
//  DataLogger.Trigger();
}

void IOProcessClass::LeftSWButtonPress()
/* Move input focus to next input field. After last control move
focus to NULL.  Make sure to tell the fields that they got/lost focus. */
{
  if (Focus == NULL)
    Focus = TabStopListHead;
  else
    {
      Focus->F->LostFocus();
      Focus = Focus->pNext;
    }
  if (Focus != NULL)
    Focus->F->GotFocus();
}

void IOProcessClass::DialMovedTo(UINT Position)
/* Send value to input control with focus */
{
  if (Focus != NULL)
    Focus->F->DialMovedTo(Position);
}

void IOProcessClass::RegisterField(IOFieldClass *F,
                                   UINT         ZOrder,
                                   UINT         TabStopIndex)
{
  /* Maintain two lists, one sorted by Z-order (all fields), the
  other by tab stop order (input fields) */

  { /* Do Z-order list insertion first. */
    ZFieldListRec *pnew;
    ZFieldListRec *p1;
    ZFieldListRec *p2;
  
    pnew = new ZFieldListRec;
    pnew->F = F;
    pnew->Z = ZOrder;
    p1 = ZListHead;
    if (p1 == NULL)
    {
      /* Insert first and only element into list */
      pnew->pNext = NULL;
      ZListHead = pnew;
    }
    else
      if (p1->Z > ZOrder)
      {
        /* Insert at head of list */
        pnew->pNext = p1->pNext;
        ZListHead = p1;
      }
      else
      while (p1 != NULL)
      {
        p2 = p1;
        p1 = p1->pNext;
        if (p1 == NULL)
        {
          /* Insert at end of list */
          pnew->pNext = NULL;
          p2->pNext = pnew;
        }
        else
          if (p1->Z > ZOrder)
          {
            /* Insert into middle of list */
            pnew->pNext = p1;
            p2->pNext = pnew;
            p1 = NULL; /* exit while loop */
          }
      }
  } // Do Z-order list insertion first.

  { /* Now do tab stop list insertion. */
    TabStopFieldListRec *pnew;
    TabStopFieldListRec *p1;
    TabStopFieldListRec *p2;
  
    if (TabStopIndex > 0)
    {
      pnew = new TabStopFieldListRec;
      pnew->F = F;
      pnew->TabStopIndex = TabStopIndex;
      p1 = TabStopListHead;
      if (p1 == NULL)
      {
        /* Insert first and only element into list */
        pnew->pNext = NULL;
        TabStopListHead = pnew;
      }
      else
        if (p1->TabStopIndex > TabStopIndex)
        {
          /* Insert at head of list */
          pnew->pNext = p1->pNext;
          TabStopListHead = p1;
        }
        else
          while (p1 != NULL)
          {
            p2 = p1;
            p1 = p1->pNext;
            if (p1 == NULL)
            {
              /* Insert at end of list */
              pnew->pNext = NULL;
              p2->pNext = pnew;
            }
            else
              if (p1->TabStopIndex > TabStopIndex)
              {
                /* Insert into middle of list */
                pnew->pNext = p1;
                p2->pNext = pnew;
                p1 = NULL; /* exit while loop */
              }
          }
    } // if (TabStopIndex > 0)
  } // Now do tab stop list insertion.
} // RegisterField()

void IOProcessClass::DeRegisterField(IOFieldClass *F)
{
  { /* Find F in the Z list and take it out */
    ZFieldListRec *p;
    p = ZListHead;
    if (p->F == F)
    {
      ZListHead = p->pNext; // first in list, so take it out
      delete p;
    }
    else // search through list
    {
      while (p != NULL)
      {
        if (p->pNext->F == F) break;
        p = p->pNext;
      }
      if (p != NULL)
      {
        delete p->pNext;
        p->pNext = p->pNext->pNext; // take it out of the list
      }
    }
  } // Find F in the Z list and take it out 

  { /* Now find F in the tab stop list and take it out */
    TabStopFieldListRec *p;
  
    p = TabStopListHead;
    if (p->F == F)
    {
      TabStopListHead = p->pNext; // first in list, so take it out
      delete p;
    }
    else // search through list
    {
      while (p != NULL)
      {
        if (p->pNext->F == F) break;
        p = p->pNext;
      }
      if (p != NULL)
      {
        delete p->pNext;
        p->pNext = p->pNext->pNext; // take it out of the list
      }
    }
  } // Now find F in the tab stop list and take it out
}

IOFieldClass *IOProcessClass::FieldThatHasFocus()
{
  if (Focus == NULL)
    return NULL;
  else
    return Focus->F;
}

IOFieldClass::IOFieldClass(LCDDisplayClass *d,
                           UINT x,
                           UINT y,
                           UINT w,
                           UINT h)
{
  X = x;
  Y = y;
  W = w;
  H = h;
  Display = d;
  Clear();
}

IOFieldClass::~IOFieldClass()
{
  Clear();
}

void IOFieldClass::Paint() {}
void IOFieldClass::Clear() { Display->FillRegion(X, Y, W, H, White); }
void IOFieldClass::GotFocus() {}
void IOFieldClass::LostFocus() {}
void IOFieldClass::RightSWButtonPress() {}
void IOFieldClass::LeftSWButtonPress() {}
void IOFieldClass::DialMovedTo(UINT Position) {}

TextOutputIOFieldClass::TextOutputIOFieldClass(LCDDisplayClass *d,
                                               UINT x,
                                               UINT y,
                                               UINT w,
                                               UINT h
                                              ) : IOFieldClass(d, x, y, w, h)
{
  buf[0]='\0';
  buf[sizeof(buf)/sizeof(buf[0])-1]='\0';
  FontToUse = _8x8;
  Changed = FALSE;
}

void TextOutputIOFieldClass::SetText (Font F, TextColor TC, char *s)
{
  FontToUse = F;
  TColor = TC;
  strcpy(buf, s);
  Changed = TRUE;
}

void TextOutputIOFieldClass::Paint()
{
  if (Changed != FALSE)
  {
    Clear();
    Display->TextOut(X, Y, FontToUse, TColor, buf);
    Changed = FALSE;
  }
}

StripChartFieldClass::StripChartFieldClass(LCDDisplayClass *d,
                                           UINT x,
                                           UINT y,
                                           UINT w,
                                           UINT h,
                                           StripChartOrientation o
                                          ) : IOFieldClass(d, x, y, w, h)
{
  Orientation = o;
  DataHead = 0;
  DataTail = 0;
  PixelCount = 0;
  Changed = FALSE;

  // allocate space to hold time series values, one point per
  // screen line
  if (Orientation == Horizontal)
    NumPoints = w;
  else
    NumPoints = h;

  DataBuf = new UINT[NumPoints];
  PixelBuf = new PixelLoc[NumPoints];

  for (short i = 0; i < NumPoints; i++)
  {
    if (Orientation == Horizontal)
    {
      PixelBuf[i].X = i + X;
    }
    else
    {
      PixelBuf[i].Y = i + Y;
    }
  }
}

void StripChartFieldClass::NewPoint(UINT val)
{
  DataHead = (DataHead + 1) % NumPoints;
  if (DataHead == DataTail)
    DataTail = (DataTail + 1) % NumPoints;
  DataBuf[DataHead] = val;
  Changed = TRUE; // assumed atomic
}

void StripChartFieldClass::Paint()
{
  // I suppose I should really use walking pointers instead
  // of array indexing in this routine.

  UINT t;

  if (Changed == FALSE) // assumed atomic
    return;
  Changed = FALSE; // assumed atomic

  // Erase all the old points on the screen
  t = 0;
  while (t != PixelCount)
  {
    Display->Plot(PixelBuf[t].X, PixelBuf[t].Y, White);
    t += 1;
  }

  // Plot the new points on the screen
  PixelCount = 0;
  t = DataTail;
  while (t != DataHead)
  {
    // scale the value so it fits in the graph
    // only need to set the value of one coordinate now, other coordinate
    // was set in the constructor as it will not change further
    if (Orientation == Horizontal)
    {
      PixelBuf[PixelCount].Y = (Y+H-1) - (unsigned int)((unsigned long) DataBuf[t] * (unsigned long) (H-1)) / ((unsigned long) USHRT_MAX + 1);
    }
    else
    {
      PixelBuf[PixelCount].X = (X+W-1) - (unsigned int)((unsigned long) DataBuf[t] * (unsigned long) (W-1)) / ((unsigned long) USHRT_MAX + 1);
    }
    t = (t + 1) % NumPoints;
    PixelCount+=1;
  }
  // Draw the points in PixelBuf
  for (short i = 0; i < PixelCount; i++)
    Display->Plot(PixelBuf[i].X, PixelBuf[i].Y, Black);
}

ParmSelectFieldClass::ParmSelectFieldClass(LCDDisplayClass *d,
                                           UINT x,
                                           UINT y, 
                                           UINT w,
                                           UINT h
                                          ) : TextOutputIOFieldClass(d, x, y, w, h)
{
  PRM = LastPRMAddedToList;
  FontToUse = _8x8;
  TColor = BlackOnWhite;
  sprintf(buf, "%-10.10s %-4.4s", PRM->GetName(), PRM->GetDisplayUnits());
  Changed = TRUE;
}

PRMClass *ParmSelectFieldClass::GetParm()
{
  return PRM;
}

void ParmSelectFieldClass::GotFocus()
{
  TColor = WhiteOnBlack;
  Changed = TRUE;
}

void ParmSelectFieldClass::LostFocus()
{
  TColor = BlackOnWhite;
  Changed = TRUE;
}

void ParmSelectFieldClass::DialMovedTo(UINT Position)
{
  // The absolute dial position determines which parameter is to
  // be displayed.
  UINT n;

  n = (SampleablePRMCount * Position) / MAXDIALCOUNTS;

  // find the nth viewable parameter in the list

  PRMClass *p;
  p = LastPRMAddedToList;
  if (SampleablePRMCount > 0)
    while (p->GetSampleSize() == IgnoredSample)
      p = p->Next();  // find first sampleable parameter
  short i = 0;
  while (i < n)
  {
    p = p->Next();
    // skip over parameters that aren't normally sampled
    if (p->GetSampleSize() != IgnoredSample)
      i+=1;
  }
  PRM = p;
  sprintf(buf, "%-10.10s %-4.4s", PRM->GetName(), PRM->GetDisplayUnits());
  Changed = TRUE;
}

