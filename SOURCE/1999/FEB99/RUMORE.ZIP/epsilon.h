#ifndef __EPSILON_H
#define __EPSILON_H

// declaration
template <class T> T calcEpsilon(T);

#endif
