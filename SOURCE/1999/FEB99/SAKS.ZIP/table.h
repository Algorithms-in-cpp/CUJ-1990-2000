// table.h - cross-reference table interface

struct tree_node;

tree_node *
add_tree(tree_node *t, char const *w, unsigned n);

void put_tree(tree_node const *t);

class cross_reference_table
    {
public:
    cross_reference_table();
    void add(char const *w, unsigned n);
    void put() const;
private:
    tree_node *root;
    };

inline
cross_reference_table::cross_reference_table()
    {
    root = NULL;
    }

inline
void
cross_reference_table::add(char const *w, unsigned n)
    {
    root = add_tree(root, w, n);
    }

inline
void cross_reference_table::put() const
    {
    put_tree(root);
    }
