// table.cpp - cross-reference table implementation

#include <stdio.h>
#include <string.h>

#include "table.h"

struct list_node
    {
    unsigned number;
    list_node *next;
    };

struct cross_reference_table::tree_node
    {
    char *word;
    list_node *first, *last;
    tree_node *left, *right;
    };

cross_reference_table::tree_node *
cross_reference_table::add_tree
    (tree_node *t, char const *w, unsigned n)
    {
    ... same as in Listing 1 ...
    }

void
cross_reference_table::put_tree(tree_node const *t)
    {
    ... same as in Listing 1 ...
    }




