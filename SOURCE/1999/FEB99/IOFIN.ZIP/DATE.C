#include "date.h"

/* Source Code: */
/*///////////////////////////////////////////////////
//  Function: FindCenturyDigits
//	Description: Finds a day of the week for a date 
//  in a given century. Compares it with a day of 
//  the week for a date in MWDDYY format.  If they are
//  equal CC digits are returned.
//	Returns:  int CC digits if Ok, 0 -- otherwise
//////////////////////////////////////////////////////
*/
int FindCenturyDigits(char *MWDDYYDate)
{
  char MWDDYYBuffer[7], MMDDCCYYBuffer[9],CCDigits[3];
  const int First400Start = 16;
  const int Second400Start = 20;
  const int Third400Start = 24;
  int i=0;
  int DayOfWeek; 
  strcpy (MWDDYYBuffer, MWDDYYDate);
  if(MWDDYYBuffer[1]>'6') {
    for(i=Second400Start;i<Third400Start;i++) {
      MWDDYYToMMDDCCYY(i,MWDDYYBuffer,MMDDCCYYBuffer); 
    DayOfWeek=FindDay(MMDDCCYYBuffer);
	  /* Add offset for dates in centuries after 20th */ 
	  DayOfWeek+=7; 
      if (atoi(XDigitToDecimal(MWDDYYBuffer[1]))==
        DayOfWeek) {
        return SetCCDigits(MMDDCCYYBuffer, CCDigits); 
      }
    }		
  }
  else { /* to count back centuries for efficiency */
    for(i=(Second400Start-1);i>=First400Start;i--) {
      MWDDYYToMMDDCCYY(i,MWDDYYBuffer,MMDDCCYYBuffer);
      DayOfWeek = FindDay(MMDDCCYYBuffer);
      if((MWDDYYBuffer[1]-'0')==DayOfWeek) {
        return SetCCDigits(MMDDCCYYBuffer, CCDigits); 
      }
    }		
  }
  return (0); 
}    
/*
//////////////////////////////////////////////////
//  Function:   MMDDYYToDDDDDh
//	Description: 	Date converter.
//	Returns:  char * -- DDDDD.
//////////////////////////////////////////////////////
*/
char *MMDDYYToDDDDDh(int CCDigits, 
  char *MMDDCCYYStartDate, char *MMDDYYDate, 
  char *DDDDD) 
{
  char MMDDCCYYStartBuffer[9], MMDDCCYYBuffer[9],
    MMDDYYBuffer[7];
  static char DDDDDBuffer[6];
  unsigned long DayCount;
  strcpy(MMDDCCYYStartBuffer, MMDDCCYYStartDate);
  strcpy(MMDDYYBuffer, MMDDYYDate); 
  MMDDYYToMMDDCCYY(CCDigits, MMDDYYBuffer, 
    MMDDCCYYBuffer); 
  DayCount = FindJulianDay(MMDDCCYYBuffer) - 
    FindJulianDay(MMDDCCYYStartBuffer); 
  (void)printf("DayCount=%lu;\n", DayCount);   
  ltoa(DayCount, DDDDDBuffer, 16); /* convert to hex */
  strcpy(DDDDD, DDDDDBuffer);
  return DDDDDBuffer;
} 
/*////////////////////////////////////////////////////
//  Function:   MMDDYYToDDDBased64
//	Description: 	Date converter.  The number of days
//  passed since starting date is converted to octal
//  number. This number is split in 3 2-digits octal
//  numbers. These numbers are converted to decimals 
//  and serve as indices to DigitsBasedOn64[] array.
//  Base 64 is  8 * 8. Hence this conversion algorithm
//  is similar to conversion of hexadecimal numbers to
//  binary where each 4 binary digits are presented
//  as a single hex digit (16 = 2*2*2*2). Overflow 
//  date for 3 char array is 09/23/2317.
//	Returns:  char * -- DDD.
////////////////////////////////////////////////////// 
*/
char *MMDDYYToDDDBased64(int CCDigits, 
  char *MMDDCCYYStartDate,char *MMDDYYDate,char *DDD) 
{
  char MMDDCCYYStartBuffer[9],MMDDCCYYBuffer[9],
    MMDDYYBuffer[7], DDDDDDBuffer[7],
	IndexBuffer[3]; 
  static char DDDBuffer[4];
  long DayCount;
  int Index1, Index2, Index3,Ind1, Ind2, Ind3,
    DDDDDDBufferLen;
  strcpy(MMDDCCYYStartBuffer, MMDDCCYYStartDate);
  memset (DDDDDDBuffer, '0', 6); /* set all char to 0 */
  DDDDDDBuffer[6] = '\0';
  strcpy(MMDDYYBuffer, MMDDYYDate); 
  MMDDYYToMMDDCCYY(CCDigits, MMDDYYBuffer, 
    MMDDCCYYBuffer); 
  DayCount = FindJulianDay(MMDDCCYYBuffer) - 
    FindJulianDay(MMDDCCYYStartBuffer);
  ltoa(DayCount, DDDDDDBuffer, 8); /* convert to octal */
  DDDDDDBufferLen = strlen(DDDDDDBuffer);
  if(DDDDDDBufferLen==0 || 
    DDDDDDBufferLen>6) { /* invalid date */
  	DDD="";
  	return""; 
  }	
  CirculateChars(DDDDDDBuffer); 
  strncpy(IndexBuffer, DDDDDDBuffer, 2); 
  IndexBuffer[2] = '\0'; 
  Index1 = OctalToDecimal(IndexBuffer, &Ind1);
  memset(IndexBuffer, '0', 2);
  IndexBuffer[2] = '\0';
  strncpy(IndexBuffer, &DDDDDDBuffer[2], 2);
  Index2 = OctalToDecimal(IndexBuffer, &Ind2);
  memset(IndexBuffer, '0',2);
  IndexBuffer[2] = '\0';
  strncpy(IndexBuffer, &DDDDDDBuffer[4], 2);
  Index3 = OctalToDecimal(IndexBuffer, &Ind3);
  DDDBuffer[0] = (char)DigitsBasedOn64[Index1];
  DDDBuffer[1] = (char)DigitsBasedOn64[Index2];
  DDDBuffer[2] = (char)DigitsBasedOn64[Index3];
  DDDBuffer[3] = '\0';
  strcpy(DDD, DDDBuffer);
  return DDDBuffer;
}
/*////////////////////////////////////////////////////
//  Function:  SetCCDigits
//	Description: Sets Century digits.
//	Returns: int CCDigitsPar converted to int.
////////////////////////////////////////////////////// 
*/
int SetCCDigits(char *MMDDCCYYDate, char *CCDigitsPar) 
{
  char MMDDCCYYBuffer[9];
  static char CCDigits[3]; 
  strcpy (MMDDCCYYBuffer, MMDDCCYYDate);
  memset (CCDigits, '\0', 3);
  CCDigits[0] = MMDDCCYYBuffer[4]; 
  CCDigits[1] = MMDDCCYYBuffer[5]; 
  CCDigits[2] = '\0'; 
  strcpy(CCDigitsPar, CCDigits); 
  return (atoi(CCDigitsPar));
}
/*////////////////////////////////////////////////////
//  Function:  MWDDYYToMMDDCCYY
//	Description:  Date converter.
//	Returns:  char *--MMDDCCYYDate on Ok, "" if not.
//////////////////////////////////////////////////////
*/
char *MWDDYYToMMDDCCYY(int CCDigits, char *MWDDYYDate,
  char *MMDDCCYYDate)
{
  char MWDDYYDBuffer[7], CCDigitsBuffer[3],
    MonthDigits[3]; 
  static char MMDDCCYYBuffer[9]; 
  _itoa (CCDigits, CCDigitsBuffer, 10);
  strcpy (MWDDYYDBuffer, MWDDYYDate);
  if (isxdigit((int)MWDDYYDBuffer[0])) {
    strcpy(MonthDigits, XDigitToDecimal(
      MWDDYYDBuffer[0])); 
    strcpy(MMDDCCYYBuffer, MonthDigits); /* MM */
    strncat(MMDDCCYYBuffer, &MWDDYYDBuffer[2],2);/* DD */
    MMDDCCYYBuffer[4]='\0';
    strcat(MMDDCCYYBuffer, CCDigitsBuffer);/* CC */
    strncat(MMDDCCYYBuffer, &MWDDYYDBuffer[4],2);/* YY */
	MMDDCCYYBuffer[8]='\0'; 
	strcpy (MMDDCCYYDate, MMDDCCYYBuffer);
	return MMDDCCYYBuffer;
  }
  return ""; /* error */
}
/*////////////////////////////////////////////////////
//  Function:  OctalToDecimal
//	Description:  Date converter.
//	Returns:  int -- converted number.
////////////////////////////////////////////////////// 
*/
int OctalToDecimal(char *IndexBuffer, int *Index) 
{
  char Buffer[3];
  static int Ind=0;
  strcpy(Buffer, IndexBuffer);
  Ind=(Buffer[0]-'0')*8+Buffer[1]-'0';  
  *Index=Ind;
  return Ind;
}
/*////////////////////////////////////////////////////
//  Function:  FindDay
//	Description: Calculates the day of the week by a 
//  given date.Algorithm: (Can be used also in mental 
//  calculations). For a given date <=> (Year, Month, Date)
//	Year <=> (CCDigits=Year/100, YYDigits=Year%100)
//	Day = YYDigits+YYDigits/4+month_index[Month]+ 
//	FirstTwoMonthsIndex(YYDigits)+
//  CenturyBenchMarkDay(CCDigits); Here:
// Century BenchMarkDay for 20th century is SUNDAY=0;
// Century BenchMarkDay for 19th century is TUESDAY=2;
// Century BenchMarkDay for 18th century is THURSDAY=4;
// Century BenchMarkDay for 17th century is SATURDAY=6.
//	Note: These benchmark days repeat every 400 years.
//	NOTE: I learned this exquisite elaboration of 
//  Jackobstahl formula from my relative, Lev Sheinin.
//	Returns: int day of week (look at enum days).
////////////////////////////////////////////////////// 
*/
int FindDay(char *MMDDCCYYDate)
{
  int Index, Month, Date, CCDigits, YYDigits,
    FirstTwoMonthsIndex;
  static int Day; 
  char MMDDCCYYBuffer[9];
  strcpy(MMDDCCYYBuffer, MMDDCCYYDate);  
  Month=Get(MMDDCCYYBuffer, (int)MM);
  Date=Get(MMDDCCYYBuffer, (int)DD);
  CCDigits=Get(MMDDCCYYBuffer, (int)CC);
  YYDigits=Get(MMDDCCYYBuffer, (int)YY);
  FirstTwoMonthsIndex=
    (IsGregorianLeapYear(MMDDCCYYBuffer)  && 
      Month<=2)?-1:0;
  Index=(Date+FirstTwoMonthsIndex+
    FindMonthIndex(Month)+YYDigits+YYDigits/4+
    FindCenturyBenchmarkDay(CCDigits))%7;
  Index = (Index >= 0) ? Index : (7 + Index);
  Day = Index;
  return (Day);
}
/*////////////////////////////////////////////////////
//  Function:  FindJulianDay
//	Description: Calculates JD for Gregorian calendar. 
//	Count starts from January 1st, 4713 BC. 
//  Days count from a median Greenwich noon foolowing
//  a median Greenwich midnight defining the beginning
//  of the considered date.
//	Returns:  long -- JD value.
//////////////////////////////////////////////////////
*/
long FindJulianDay(char *MMDDCCYYDate)
{
  unsigned long Year, CCDigits, YYDigits;  
  char MMDDCCYYBuffer[9];
  unsigned long JD;
  static float JulianDay;
  float YearConst;
  strcpy (MMDDCCYYBuffer, MMDDCCYYDate);  
  CCDigits=Get(MMDDCCYYBuffer, (int)CC);
  YYDigits=Get(MMDDCCYYBuffer, (int)YY);
  Year=CCDigits*100+YYDigits;
  JD=(4712+Year)*365+1178+Year/4+Year/400-
    CCDigits; /* 1178=4712/4  */
  switch (Year % 4)	{
    case 0:
      YearConst = 1.0F;
      break;
    case 1:
      YearConst = 1.75F;
      break;
    case 2:
      YearConst = 1.50F;
      break;
    case 3:
      YearConst = 1.25F;
	  break;
  }
  JulianDay=(float)JD+YearConst;
  JulianDay+=(float)FindDateOrderedNumber
    (MMDDCCYYBuffer); 
  JD=(long)JulianDay;
  return (JD);	
} 
/*////////////////////////////////////////////////////
// Function:  CirculateChars
// Description: Perform circular substitution of chars
//////////////////////////////////////////////////////
*/
void CirculateChars(char *s)
{
  char Buffer[7];
  memset(Buffer, '0', 6);
  Buffer[6]='\0';
  if (strlen(s)<6) {
    Buffer[6-strlen(s)]='\0';   
    strcat(Buffer, s);
  }
  else if(strlen(s)==6) { 
   Buffer[6]='\0';
   strcpy(Buffer, s);
  }
  else {
    strcpy(Buffer, "");
  } 
  strcpy(s, Buffer);
}
/*////////////////////////////////////////////////////
//  Function: XDigitToDecimal
//	Description: Converts a hex digit to a decimal
//  number presented as a string.
//	Returns: char * -- Decimal on Ok, "" -- if no
// 
//////////////////////////////////////////////////////
*/
char *XDigitToDecimal(char c)
{
  char d;
  static char Decimal[3];
  d = c; 
  if (('0'<=d)  && (d<='9')) {
    Decimal[0]='0';
	Decimal[1]=d;
	Decimal[2]='\0';
	return Decimal;	
  }
  else if (d >'9' && d <='f') {
    switch (d) {
      case 'a':
        return _itoa(10, Decimal, 10);
      case 'b': 
		return _itoa(11, Decimal, 10);
      case 'c':
        return _itoa(12, Decimal, 10);
      case 'd':
        return _itoa(13, Decimal, 10);
      case 'e':
        return _itoa(14, Decimal, 10);
      case 'f':
        return _itoa(15, Decimal, 10);
      default:
		break;
	}
  }
  return ""; /* an error flag*/	
}
/*////////////////////////////////////////////////////
//  Function:  Get
//	Description:  Gets specified fileds.
//	Returns:  int-- TwoDigits.
//////////////////////////////////////////////////////
*/
int Get(char *MMDDCCYYDate, int WhichField)
{
  char MMDDCCYYBuffer[9]; 
  static char TwoDigits[3];  
  memset(TwoDigits, '\0', 3);
  strcpy (MMDDCCYYBuffer, MMDDCCYYDate); 
  TwoDigits[0]=MMDDCCYYBuffer[(int)WhichField];
  TwoDigits[1]=MMDDCCYYBuffer[(int)(WhichField+1)];
  TwoDigits[2]='\0'; 
  return atoi(TwoDigits);
}
/*////////////////////////////////////////////////////
//  Function:  IsGregorianLeapYear
//	Description: Checks if a year is the leap one 
//	Returns:  int -- TRUE if the year is the leap one, 
//  FALSE -- otherwise.
//////////////////////////////////////////////////////
*/
int IsGregorianLeapYear (char *MMDDCCYYDate)
{
  char CCYY[5];
  int Year;
  strcpy(CCYY, &MMDDCCYYDate[4]); 
  Year = atoi(CCYY);
  return ((((Year % 4) == 0 && Year % 100 != 0) || 
    (Year % 400 == 0)) ? TRUE : FALSE);
} 
/*////////////////////////////////////////////////////
//  Function:  FindCenturyBenchmarkDay
//  Description: Calculates benchmark day for century.  
//	Returns:  int -- day.  For the Gregorian calendar
//	the last day of the last century is the benchmark.
////////////////////////////////////////////////////// 
*/
int FindCenturyBenchmarkDay(int CCDigits)
{
	return (SATURDAY-2*(CCDigits%4));
}
/*////////////////////////////////////////////////////
//  Function:  FindMonthIndex
//	Description: Calculates months indices for 
//  non-leap year. If you divide number of days in 
//  full months preceding a date by 7 (number of days 
//  in a week) you will have this number.  
//	Returns:  int -- month index.
//////////////////////////////////////////////////////
*/
int FindMonthIndex(int Month)
{
  int sum=0; 
  int i;
  for (i=0; i<(Month-1); i++) {
    sum+=month_days[i];
  } 
  return (sum %7);
} 
/*////////////////////////////////////////////////////
//  Function: FindDateOrderedNumber
//	Description:  Calculates date's ordinal number 
//  within a year. If you take a number of days in full 
//  months preceding a date, and add a date you will 
//  have this number.  
//	Returns:  int -- ordinal number.
//////////////////////////////////////////////////////
*/
int FindDateOrderedNumber(char *MMDDCCYYDate)
{
  int Month, Date, i;
  char MMDDCCYYBuffer[9];
  static int Sum = 0; 
  strcpy (MMDDCCYYBuffer, MMDDCCYYDate);  
  Month=Get(MMDDCCYYBuffer, (int)MM);
  Date = Get(MMDDCCYYBuffer, (int)DD);
  for (i=0; i<(Month-1); i++) {
    Sum += month_days[i];
  }
  Sum+=Date;
  if (IsGregorianLeapYear(MMDDCCYYBuffer) && 
      (Month>FEBRUARY)) {
        Sum++;
  } 
  return Sum;
} 
/*////////////////////////////////////////////////////
//  Function: MMDDYYToMMDDCCYY
//	Description: 	Date converter.
//	Returns: char * -- MMDDCCYYDate.
//////////////////////////////////////////////////////
*/
char *MMDDYYToMMDDCCYY(int CCDigits, char *MMDDYYDate, 
  char *MMDDCCYYDate) 
{
  char MMDDYYBuffer[7], CCBuffer[3];
  static char MMDDCCYYBuffer[9]; 
  strcpy(MMDDYYBuffer, MMDDYYDate); 
  strncpy(MMDDCCYYBuffer, MMDDYYBuffer, 4);
  MMDDCCYYBuffer[4]='\0'; 
  strcat(MMDDCCYYBuffer,_itoa(CCDigits,CCBuffer,10));
  strncat (MMDDCCYYBuffer, &MMDDYYBuffer[4], 2); 
  MMDDCCYYBuffer[8]='\0';
  strcpy (MMDDCCYYDate, MMDDCCYYBuffer);
  return  MMDDCCYYBuffer;
}
/*////////////////////////////////////////////////////
//  Function:  MMDDYYToMWDDYY
//	Description: 	Date converter.
//	Return: char * -- MMDDYYDate.
////////////////////////////////////////////////////// 
*/
char *MMDDYYToMWDDYY(char *MMDDYYDate, int CCDigits, 
  char *MWDDYYDate) 
{
  char MMDDCCYYBuffer[9],MMDDYYBuffer[7], 
    MonthBuffer[2], DayBuffer[2];
  static char MWDDYYBuffer[7];
  int Month, WeekDay; 
  strcpy(MMDDYYBuffer, MMDDYYDate);
  MMDDYYToMMDDCCYY(CCDigits, MMDDYYBuffer, 
    MMDDCCYYBuffer); 
  Month=Get(MMDDCCYYBuffer, (int)MM);
  WeekDay=FindDay(MMDDCCYYBuffer);
  /* Add offset for dates in centuries after 20th */
  WeekDay=(CCDigits<20)?WeekDay : WeekDay+7;  
  _itoa(Month, MonthBuffer, 16);
  _itoa(WeekDay, DayBuffer, 16); 
  MWDDYYBuffer[0]=MonthBuffer[0];
  MWDDYYBuffer[1]=DayBuffer[0];
  MWDDYYBuffer[2]=MMDDCCYYBuffer[2];
  MWDDYYBuffer[3]=MMDDCCYYBuffer[3];
  MWDDYYBuffer[4]=MMDDCCYYBuffer[6];
  MWDDYYBuffer[5]=MMDDCCYYBuffer[7]; 
  MWDDYYBuffer[6]='\0'; 
  strcpy(MWDDYYDate, MWDDYYBuffer);
  return MWDDYYBuffer;
}
/*////////////////////////////////////////////////////
// 	Function:  MMDDCCYYToMWDDYY
//	Description:  Date converter.
//	Returns:  char * -- MMDDYYDate
//////////////////////////////////////////////////////
*/
char *MMDDCCYYToMWDDYY(char *MMDDCCYYDate, 
  char *MWDDYYDate) 
{
 char MMDDCCYYBuffer[9], MonthBuffer[2], DayBuffer[2];
  static char MWDDYYBuffer[7];
  int Month, WeekDay, CCDigits; 
  strcpy(MMDDCCYYBuffer, MMDDCCYYDate);
  Month=Get(MMDDCCYYBuffer, (int)MM);
  CCDigits=Get(MMDDCCYYBuffer, (int)CC);
  WeekDay=FindDay(MMDDCCYYBuffer); 
  WeekDay=(CCDigits < 20) ? WeekDay : WeekDay+7;
  _itoa(Month, MonthBuffer, 16);
  _itoa(WeekDay, DayBuffer, 16); 
  MWDDYYBuffer[0]=MonthBuffer[0];/* D */
  MWDDYYBuffer[1]=DayBuffer[0];  /* W (DOW) */
  MWDDYYBuffer[2]=MMDDCCYYBuffer[2];
  MWDDYYBuffer[3]=MMDDCCYYBuffer[3];
  MWDDYYBuffer[4]=MMDDCCYYBuffer[6];
  MWDDYYBuffer[5]=MMDDCCYYBuffer[7];
  strcpy(MWDDYYDate, MWDDYYBuffer);
  return MWDDYYBuffer;
}
/*////////////////////////////////////////////////////
// 	Function:  Test Driver
//	Description:  1) Takes an input in MMDDYY format, 
//  and also century digits to generate MWDDYY date. 
//  Calculates weekdays for  subsequent century digits
//  to compare it with a W field of a considered date.
//  Correct century digits produce the same weekday.
//  2) Convert MMDDYY date to (DDDDD)h; 3) Convert 
//  MMDDYY to DDD number with 64 as a base. 
//////////////////////////////////////////////////////
*/
int main (void)
{
  char MMDDCCYYStartDate[9], MMDDYYDate[7],
    MWDDYYDate[7],DDDDDBuffer[6],DDDBuffer[4],
    CCDigits[3], WeekDay; 
  int CC, CCFound; 
  
  strcpy(MMDDCCYYStartDate, "01011600");  /* 01/01/1600 */
  while (1)	{
    memset(DDDDDBuffer, '\0', 6);
    memset(DDDBuffer, '\0', 4);
    (void)printf(
     "Enter date in MMDDYY Format or Q(q) to exit.\n");
    scanf ("%s", MMDDYYDate);
    if (MMDDYYDate[0]=='Q' || MMDDYYDate[0]=='q') {
      (void)printf("Have a good day.\n");
      exit(0);
    }
   (void)printf(
     "Enter First Two Digits of Year(19, 20, etc.\n");
   scanf ("%s", CCDigits);
   CC=atoi(CCDigits); 
   if (CC<16 || CC>24) {
     (void)printf(
       "Valid values are 16 <= CC <= 24. Repeat.\n"); 
     continue;
   }
   MMDDYYToMWDDYY(MMDDYYDate, CC, MWDDYYDate);
   CCFound =FindCenturyDigits(MWDDYYDate); 
   if (CCFound==CC) {
   	(void)printf("MWDDYYDate = %s\n", MWDDYYDate); 
     WeekDay=(char)(atoi(XDigitToDecimal(MWDDYYDate[1]))%7);
     (void)printf("CC = %d, W (DOW) =%d; OK.\n", 
       CC, (int)WeekDay); 
   } 
   MMDDYYToDDDDDh(CC, MMDDCCYYStartDate, MMDDYYDate, 
     DDDDDBuffer);
   (void)printf("DDDDDh = %s\n", DDDDDBuffer); 
   MMDDYYToDDDBased64(CC, MMDDCCYYStartDate, 
     MMDDYYDate, DDDBuffer); 
   (void)printf("DDD64 = %s\n", DDDBuffer); 
    continue;
  }	
  return (0);
} 


