#ifndef Date_H
#define Date_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <ctype.h>

#define TRUE 1
#define FALSE 0
const int month_days [] = {
  31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};

const int DigitsBasedOn64[] = {
  '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
  'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
  'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd',
  'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
  'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
  'y', 'z', '#', '$'
};

enum months {
  JANUARY = 1, FEBRUARY, MARCH, APRIL, MAY, JUNE, 
  JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, 
  DECEMBER
} ;  

enum days {
  SUNDAY, MONDAY, TUESDAY, WEDNESDAY, 
  THURSDAY, FRIDAY, SATURDAY
};

enum fields
{
	MM, DD=2, CC=4, YY=6
}; 

int FindCenturyDigits(char *MWDDYYDate);
char *MMDDYYToDDDDDh(int CCDigits, 
  char *MMDDCCYYStartDate, char *MMDDYYDate, 
  char *DDDDD) ;
char *MMDDYYToDDDBased64(int CCDigits, 
  char *MMDDCCYYStartDate,char *MMDDYYDate,char *DDD);
int SetCCDigits(char *MMDDCCYYDate, char *CCDigitsPar);
char *MWDDYYToMMDDCCYY(int CCDigits, char *MWDDYYDate,
  char *MMDDCCYYDate);
int OctalToDecimal(char *IndexBuffer, int *Index);
int FindDay(char *MMDDCCYYDate);
long FindJulianDay(char *MMDDCCYYDate);
void CirculateChars(char *s);
char *XDigitToDecimal(char c);
int Get(char *MMDDCCYYDate, int WhichField);
int IsGregorianLeapYear (char *MMDDCCYYDate);
int FindCenturyBenchmarkDay(int CCDigits);
int FindMonthIndex(int Month);
int FindDateOrderedNumber(char *MMDDCCYYDate);
char *MMDDYYToMMDDCCYY(int CCDigits, char *MMDDYYDate, 
  char *MMDDCCYYDate);
char *MMDDYYToMWDDYY(char *MMDDYYDate, int CCDigits, 
  char *MWDDYYDate);
char *MMDDCCYYToMWDDYY(char *MMDDCCYYDate, 
  char *MWDDYYDate);

#endif
