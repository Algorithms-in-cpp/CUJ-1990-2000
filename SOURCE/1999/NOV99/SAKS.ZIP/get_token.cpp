int get_token(char *s, size_t n)
    {
    int c;
    while ((c = fgetc(stdin)) != EOF)
        if (isalpha(c) || c == '_' || c == '\n')
            break;
    if (c == EOF)
        {
        *s = '\0';
        return 0;
        }
    *s++ = c;
    n -= 2;
    if (c != '\n')
        {
        while (isalnum(c = fgetc(stdin)) || c == '_')
            if (n > 0)
                {
                *s++ = c;
                --n;
                }
        ungetc(c, stdin);
        }
    *s = '\0';
    return 1;
    }
