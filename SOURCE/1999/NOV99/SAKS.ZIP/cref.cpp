#include <ctype.h>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

istream &get_token(istream &is, string &s)
    {
    char c;
    while (is.get(c) && isspace(c))
        ;
    if (is)
        {
        s = c;
        if (isalpha(c) || c == '_')
            while (is.peek() != EOF && is.get(c))
                if (isalnum(c) || c == '_')
                    s += c;
                else
                    {
                    is.putback(c);
                    break;
                    }
        }
    return is;
    }

int main()
    {
    unsigned ln = 0;
    typedef vector<unsigned> sequence;
    typedef map<string, sequence> container;
    container table;
    string id, line;
    while (getline(cin, line))
        {
        ++ln;
        istringstream iss(line);
        while (get_token(iss, id))
            if (isalpha(id[0]) || id[0] == '_')
                table[id].push_back(ln);
        }
    container::iterator i = table.begin();
    for (; i != table.end(); ++i)
        {
        cout << left << setw(12) << i->first << ": ";
        sequence::iterator j = i->second.begin();
        for (; j != i->second.end(); ++j)
            cout << setw(5) << *j;
        cout << '\n';
        }
    return 0;
    }
    
