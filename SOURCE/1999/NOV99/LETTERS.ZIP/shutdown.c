#include <windows.h>
#include <winuser.h>
#include <stdio.h>

#define DLL_EXPORT \
   __declspec (dllexport)

// Function Prototypes.
DWORD WINAPI WaitForShutdown(LPVOID);
DLL_EXPORT void LoadDLL();
DLL_EXPORT void ShutdownProcess();

// Variable Declarations.
DWORD currentThreadId = 0;
HMODULE ghModule = 0;
HANDLE ghShutdownEvent = 0;


BOOL APIENTRY 
DllMain(HANDLE hModule, 
   DWORD ul_reason_for_call, 
   LPVOID lpReserved)
{
   if (ul_reason_for_call == 
          DLL_PROCESS_ATTACH )
   {
      ghModule = (HMODULE)hModule;
      ghShutdownEvent = 
         CreateEvent(NULL, TRUE, 
            FALSE, "SHUTDOWN_EVENT");
   }
   else if (ul_reason_for_call == 
               DLL_PROCESS_DETACH )
   {
      CloseHandle(ghShutdownEvent);
   }

    return(1);
}


DLL_EXPORT void ShutdownProcess()
{
   SetEvent(ghShutdownEvent);
}


DWORD WINAPI 
WaitForShutdown(LPVOID aVoidPointer)
{
   // Wait for the shutdown 
   // to be triggered.
   WaitForSingleObject
      (ghShutdownEvent, INFINITE);

   ExitProcess(0);

   return(0);
}


DLL_EXPORT void LoadDLL()
{
   DWORD ThreadId = 0;

   // Run our checking 
   // on another thread...

   // Spawn a thread to wait for 
   // shutdown signal.
   CreateThread(NULL, 0, 
      WaitForShutdown, 0, 0, 
      &ThreadId);
}


