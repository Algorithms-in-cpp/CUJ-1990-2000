//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
// CFeed demonstration program. Calculates the function 
// f(t) = A*exp(-k*t)*sin(w*t) and its derivatives.
//
#include <iostream.h>
#include <fstream.h>
#include <math.h>
#include "feed.h" 

#define pi 3.14159265359       // pi

void main()
{
    CFeed f;                   // f(t) = A*exp(-k*t)*sin(w*t)
    CFeed t;                   // time = (t, dt = 1, ddt = 0)
    double A     = 16.0;       // amplitude
    double k     = 0.1;        // dampening constant
    double w     = 2*pi/16.0;  // frequency
    double dt    = 1.0;        // derivative of time
    int i;                     // loop counter
    int T = 60;                // loop limit
   
   ofstream out("feed.txt",ios::out); // open output file

   for(i = 0; i <= T; i++)    // loop over time 0 sec to T sec
    {
        t = CFeed(1,(double) i, &dt); // store time as feed variable
        f = A*exp(-k*t)*sin(w*t);     // compute f and its derivatives

        // output results: f() is f(t), f(1) = df/dt and f(1,1) = d^2f/dt^2
        out << i << '\t' << f() << '\t' << f(1) << '\t' << f(1,1) << endl;
    }
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//      end       end       end       end       end       end       end        
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
