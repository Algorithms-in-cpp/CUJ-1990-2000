//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
// feed.h
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// Class definition for FEED (Fast and Efficient Evaluation of Derivatives)
// class.  The feed class contains constructions, destructor, and operators
// for derivative evalution of function with N independent variables up  to
// second order.
//
// Class contains four data members (all protected):
//
// (1) m_N   - size: number of independent variable in function.
// (2) m_f   - base: function value i.e. f(x1o,x2o,...,xNo) 
// (3) m_df  - 1st partials:  df/dxi |(x1o,x2o,...,xNo) 
// (4) m_ddf - 2nd partials:  d2f/dxidxj |(x1o,x2o,...,xNo) 
//
// Class functions (all public) include:
//
// (1) constructors, destructor, and assignment operators
// (2) arithmetic operators e.g. +, -, /, and * 
// (3) special: negation and chain rule (call operator)
//
// Class friends:
//
// (1) Math functions e.g. sin, cos, pow, etc...
// (2) I/O operator (<<)
//
// In addtion the +, -, /, * have been overloaded to support
// arithmetic of CFeed with doubles.
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................

class CFeed {
              protected:
                 unsigned long m_N;           // number of independent variables
                 double        m_f;           // function value
                 double       *m_df;          // first order partials 
                 double       *m_ddf;         // Jacobian: second order partials
              public:
// creation, destruction, assignement
                 CFeed(const CFeed &);        // class constructor
                 CFeed(unsigned long  = 0,    // full constructor
                       double   = 0,    
                       double * = 0, 
                       double * = 0);
                ~CFeed(void);                 // destructor 
       CFeed &   operator=(const CFeed &);    // equal operator
// arithmetic operators
       CFeed &   operator+=(const CFeed &);   // additon equal operator
       CFeed &   operator+=(const double);    // additon equal operator
       CFeed     operator+(const CFeed &);    // addition operator
       CFeed     operator+(const double);     // addition operator
       CFeed &   operator-=(const CFeed &);   // subtraction equal operator
       CFeed &   operator-=(const double);    // subtraction equal operator
       CFeed     operator-(const CFeed &);    // subtraction operator
       CFeed     operator-(const double);     // subtraction operator
       CFeed &   operator*=(const CFeed &);   // mutltiplication equal operator
       CFeed &   operator*=(const double);    // mutltiplication equal operator
       CFeed     operator*(const CFeed &);    // mutltiplication operator
       CFeed     operator*(const double);     // mutltiplication operator
       CFeed &   operator/=(const CFeed &);   // division equal operator
       CFeed &   operator/=(const double);    // division equal operator
       CFeed     operator/(const CFeed &);    // division operator
       CFeed     operator/(const double);     // division operator
// special
       CFeed &   operator-(void);             // unary minus operator
       CFeed     operator()(const CFeed &);   // call operator (chain rule) 
// I/O
       double    operator()(void);            // call operator; return base value
       double    operator()(unsigned long);   // call operator; return 1sst partial
       double    operator()(unsigned long, unsigned long);   // call operator; return 2nd partial
unsigned long    size(void);                  // return size of feed object
// Math
friend CFeed     exp(const CFeed &);          // exponential
friend CFeed     log(const CFeed &);          // natural logrithm
friend CFeed     log10(const CFeed &);        // base 10 logrithm
friend CFeed     sqrt(const CFeed &);         // square root
friend CFeed     sin(const CFeed &);          // sine
friend CFeed     cos(const CFeed &);          // cosine
friend CFeed     tan(const CFeed &);          // tangent
friend CFeed     asin(const CFeed &);         // arc sine
friend CFeed     acos(const CFeed &);         // arc cosine
friend CFeed     atan(const CFeed &);         // arc tangent
friend CFeed     sinh(const CFeed &);         // hyperbolic sine
friend CFeed     cosh(const CFeed &);         // hyperbolic cosine
friend CFeed     tanh(const CFeed &);         // hyperbolic tangent
friend CFeed     pow(const CFeed &,const CFeed &); // pow  feed^feed
friend CFeed     pow(const CFeed &,const double);  // pow  feed^double
friend CFeed     pow(const double,const CFeed &);  // pow  double^feed
// I/O
friend ostream & operator<<(ostream &,CFeed &);    // write output
            };
            
// non-member operators
            
CFeed operator+(const double, const CFeed &);      // double + feed
CFeed operator-(const double, const CFeed &);      // double - feed
CFeed operator*(const double, const CFeed &);      // double * feed
CFeed operator/(const double, const CFeed &);      // double / feed

//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//      end       end       end       end       end       end       end        
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
