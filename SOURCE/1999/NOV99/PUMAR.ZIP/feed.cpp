//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
// feed.cpp
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// Class functions for FEED (Fast and Efficient Evaluation of Derivatives)
// class.  The feed class contains constructions, destructor, and operators
// for derivative evalution of function with N independent variables up  to
// second order.

#include <iostream.h>
#include <math.h>
#include "feed.h"

//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// constructors * destructors * equality 
//
// Note: these functions involve memory management; it is assumed that a
// new_handler function exists and is called automatically when new
// fails.  A set_new_handler function (such as in MS VC++) is also
// assumed and a user defined function for handeling memory allocation
// errors is presumed to have been defined before using the FEED class.
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// Default constructor
// 
// Inputs:
//
// unsigned long N   - size of feed class
// double        f   - base value of function
// double       *df  - values of first partials
// double       *ddf - values of second partials
//
// ABSTRACT: Initialize data member with values supplied by input
//           parameters.  All inpuuts have default zero. NOTE: pointer
//           df is assumed to point to memory block of length N and
//           pointer ddf to block of length N*N.  
//
CFeed::CFeed(unsigned long N, double f, double *df, double *ddf)
{
   unsigned long i, j;                  // counters
    
   m_N = N;                             // store values of size
   m_f = f;                             // and function
   
   m_df  = 0;                           // zero pointers
   m_ddf = 0;
   
   if(m_N == 0) return;                 // zero length class
   
   m_df  = new double [m_N];            // allocate memory for 1st order 
   m_ddf = new double [m_N*m_N];        // partials and second order 
       
   for(i = 0; i < m_N; i++)             // copy derivatives
   {
     if(df != 0) m_df[i] = df[i];       // copy first order partials 
     else m_df[i] = 0;
     for(j = 0; j < m_N; j++)
     { 
       if(ddf != 0) m_ddf[i*m_N+j] = ddf[i*N+j];  
       else m_ddf[i*m_N+j] = 0;         // copy second order partials
     }      
   }
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// Default constructor
// 
// Inputs:
//
// CFeed &feed - reference to intialization feed class
//
// ABSTRACT: Create a feed object from another feed object.
//
CFeed::CFeed(const CFeed &feed)
{
   unsigned long i, j;                  // counters
    
   m_N = feed.m_N;                      // store values of size
   m_f = feed.m_f;                      // and function
   
   m_df  = 0;                           // zero pointers
   m_ddf = 0;
 
   if(m_N == 0) return;                 // zero length class

   m_df  = new double [m_N];            // allocate memory for 1st order partials
   m_ddf = new double [m_N*m_N];        // and second order partials
       
   for(i = 0; i < m_N; i++)
   {
     m_df[i] = feed.m_df[i];            // copy first order partials 
     for(j = 0; j < m_N; j++)
      m_ddf[i*m_N+j] = feed.m_ddf[i*feed.m_N+j];   // copy second order partials
   }
      
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// destructor
//
// ABSTRACT: Delete memory for 1st and 2nd partials; zero all data members.
//
CFeed::~CFeed(void)
{   
   m_f = 0;
   if(m_df != 0) delete [] m_df;        // free memory
   m_df = 0;                            // first partials
   
   if(m_ddf != 0) delete [] m_ddf;      // second partials
   m_ddf = 0;
   
   m_N = 0;                             // zero length
   
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// equal operator
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: Copy one feed object to another.  NOTE: the equal operator
//           changes the size of the object being copied to.  Memory
//           is de-allocated and re-allocated by this operator.
//
CFeed & CFeed::operator=(const CFeed &feed)
{
   unsigned long i,                     // counters
                 j;                        
    
   if(this == &feed) return(*this);     // itself

   if(m_df  != 0) delete [] m_df;       // free memory 
   if(m_ddf != 0) delete [] m_ddf;      // and
   m_df  = 0;                           // zero pointers
   m_ddf = 0;

     
   m_N = feed.m_N;                      // store values of size
   m_f = feed.m_f;                      // and function
   
   if(m_N == 0) return(*this);          // done; zero length class
 
   m_df  = new double [m_N];            // allocate memory for 1st and
   m_ddf = new double [m_N*m_N];        // 2nd order partials
       
   for(i = 0; i < m_N; i++)
   {
     m_df[i] = feed.m_df[i];            // copy first order partials 
     for(j = 0; j < m_N; j++)
       m_ddf[i*m_N+j] = feed.m_ddf[i*feed.m_N+j];  // copy second order partials
   }
      
   return(*this);                       // return class
}
 
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// Addtion operators:
//
// operator+=(const CFeed &) * operator+=(const double)
// operator+(const CFeed &)  * operator+(const double)
//
// The addtion of two feed objects is a feed object.  Constants are
// considered feed objects with zero length (size) i.e. no independent
// variables.  When adding feed objects, the size of the resulting
// object is equal to the size of the largest object in the sum e.g.
// f(x,y) + g(x,y,z) = h(x,y,z).  The += operator can therefore change
// the size of its feed object.
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// addition equal operator 
// 
// Inputs:
//
// CFeed &feed - reference to feed class 
//
// ABSTRACT: Add one feed object to another: feed1 += feed2;
//
CFeed & CFeed::operator+=(const CFeed &feed)
{
  unsigned long i,                      // counters
                j;
                
  CFeed THIS(*this);                    // make copy of 'this'
  if(m_N < feed.m_N)                    // 'this' smaller so set 'this' to
   *this = feed;                        // 'feed' to increase its size
                                        
  m_f = feed.m_f + THIS.m_f;            // add  bases
  for(i = 0; i < m_N; i++)               
  {
    m_df[i] = 0;                        // add first order partials
    if(i < THIS.m_N)
     m_df[i] += THIS.m_df[i];            
    if(i < feed.m_N)
     m_df[i] += feed.m_df[i];            
    for(j = 0; j < m_N; j++)
    {                                   
      m_ddf[i*m_N+j] = 0;               // add second order partials
      if((i < feed.m_N) && (j < feed.m_N))
       m_ddf[i*m_N+j] += feed.m_ddf[i*feed.m_N+j];  
      if((i < THIS.m_N) && (j < THIS.m_N))
       m_ddf[i*m_N+j] += THIS.m_ddf[i*THIS.m_N+j];  
    }
  } 
   
  return(*this);      
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// addition equal operator 
// 
// Inputs:
//
// double c - real constant
//
// ABSTRACT: Add constant to feed object: feed += c;
//
CFeed & CFeed::operator+=(const double c)
{
   m_f += c;                            // add constant to base only
   return(*this);      
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// addition operator
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: Add two feed objects: feed3 = feed1 + feed2;
//
CFeed  CFeed::operator+(const CFeed &feed)
{
  CFeed sum(*this);                     // initialize sum with 'this'
  sum += feed;                          // add 'feed'
  return(sum);                          // return sum
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// addition operator
// 
// Inputs:
//
// double c - real constant
//
// ABSTRACT: Add feed object and a constant: feed2 = feed1 + c;
//
CFeed  CFeed::operator+(const double c)
{
   CFeed sum(*this);                    // initialize sum with 'this'
   sum.m_f += c;                        // add constant to base
   return(sum);                         // return sum
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// unary minus or negation operator-(void)
//
// Change the sign of all data members of a feed object. This operator
// does not effect the size of the feed object.
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// unary minus  operator
// 
// Inputs:
//
// None 
//
// ABSTRACT: Change the sign of all data members of a feed object.
//
CFeed & CFeed::operator-(void)
{ 
   unsigned long i,j;                   // counters
   
   m_f = -m_f;                          // invert sign of base, 
   for(i = 0; i < m_N; i++)
   {
     m_df[i] = -m_df[i];                // 1st partials
     for(j = 0; j < m_N; j++)           // and
      m_ddf[i*m_N+j] = -m_ddf[i*m_N+j];       // second partials
   } 
   
   return(*this);
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// Subtraction operators:
//
// operator-=(const CFeed &) * operator-=(const double)
// operator-(const CFeed &)  * operator-(const double)
//
// The subtraction of two feed objects is a feed object.  Constants are
// considered feed objects with zero length (size) i.e. no independent
// variables.  When subtracting feed objects, the size of the resulting
// object is equal to the size of the largest object in the sum e.g.
// f(x,y) - g(x,y,z) = h(x,y,z).  The -= operator can therefore change
// the size of its feed object.
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// subtraction equal operator 
// 
// Inputs:
//
// CFeed &feed - reference to feed class 
//
// ABSTRACT: Subtract one feed object from another: feed1 -= feed2;
//
CFeed & CFeed::operator-=(const CFeed &feed)
{
  unsigned long i,                      // counters
                j;
                
                
  CFeed THIS(*this);                    // make copy of 'this'
  if(m_N < feed.m_N)                    // 'this' smaller so set 'this' to
   *this = feed;                        // 'feed' to increase its size
                                        
  m_f = THIS.m_f - feed.m_f;            // subtract  bases
  for(i = 0; i < m_N; i++)               
  {
    m_df[i] = 0;                        // subtract first order partials
    if(i < THIS.m_N)
     m_df[i] += THIS.m_df[i];            
    if(i < feed.m_N)
     m_df[i] -= feed.m_df[i];            
    for(j = 0; j < m_N; j++)
    {                                   
      m_ddf[i*m_N+j] = 0;               // subtract second order partials
      if((i < THIS.m_N) && (j < THIS.m_N))
       m_ddf[i*m_N+j] += THIS.m_ddf[i*THIS.m_N+j];  
      if((i < feed.m_N) && (j < feed.m_N))
       m_ddf[i*m_N+j] -= feed.m_ddf[i*feed.m_N+j];  
    }
  } 
   
  return(*this);   
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// subtraction equal operator 
// 
// Inputs:
//
// double c - real constant
//
// ABSTRACT: Subtract a constant from a feed object: feed -= c;
//
CFeed & CFeed::operator-=(const double c)
{
   m_f -= c;                            // subtract constant from base
   return(*this);                       // and return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// subtraction operator
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: Subtract two feed objects: feed3 = feed1 - feed2;
//
CFeed  CFeed::operator-(const CFeed &feed)
{
   CFeed sum(*this);                    // initialize sum to 'this'
   sum -= feed;                         // subtract 'feed' and
   return(sum);                         // return result
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// subtraction operator
// 
// Inputs:
//
// double c - real constant
//
// ABSTRACT: Subtract a constant from a feed object : feed2 = feed1 - c;
//
CFeed  CFeed::operator-(const double c)
{
   CFeed sum(*this);                    // initialize sum to 'this'
   sum.m_f -= c;                        // subtract constant from base
   return(sum);                         // and return result
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// Multiplication operators:
//
// operator*=(const CFeed &) * operator*=(const double)
// operator*(const CFeed &)  * operator*(const double)
//
// The multiplication of two feed objects is a feed object.  Constants are
// considered feed objects with zero length (size) i.e. no independent
// variables.  When multiplying feed objects, the size of the resulting
// object is equal to the size of the largest object forming the product e.g.
// f(x,y)*g(x,y,z) = h(x,y,z).  The *= operator can therefore change
// the size of its feed object. Unlike addition and subtraction, the product
// of two feed objects is NOT the product of their members, but is given by
// the chain rule:
//
//  h(x1,x2,...xN) = f(x1,x2,...,xN)*g(x1,x2,...,xM); N > M
//  dh/dxi         = f*dg/dxi + g*df/dxi
//  d2h/dxjdxi     = f*d2g/dxjdxi + df/dxj*dg/dxi + dg/dxj*df/dxi + g*d2f/dxjdxi
//
//  In the above expressions dg/dxi = 0 for i > M
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// multiplication equal operator 
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: Multiply one feed object by another: feed1 *= feed2;
//
CFeed & CFeed::operator*=(const CFeed &feed)
{
  unsigned long i,                      // counters
                j; 
                
  CFeed THIS(*this);                    // make copy of 'this'
  if(m_N < feed.m_N)                    // 'this' smaller so set 'this' to
   *this = feed;                        // 'feed' to increase its size

  for(i = 0; i < m_N; i++)       
  { 
    for(j = 0; j < m_N; j++)            // multiply 2nd partials: chain rule
    {
      m_ddf[i*m_N+j] = 0;
      
      if((i < feed.m_N) && (j < feed.m_N))
       m_ddf[i*m_N+j] += THIS.m_f*feed.m_ddf[i*feed.m_N+j];
      
      if((i < THIS.m_N) && (j < feed.m_N))
       m_ddf[i*m_N+j] += THIS.m_df[i]*feed.m_df[j];
       
      if((j < THIS.m_N) && (i < feed.m_N))
       m_ddf[i*m_N+j] += THIS.m_df[j]*feed.m_df[i];
       
      if((i < THIS.m_N) && (j < THIS.m_N))
       m_ddf[i*m_N+j] += THIS.m_ddf[i*THIS.m_N+j]*feed.m_f;
    }
  }
    
  for(j = 0; j < m_N; j++)              // multiply  
  {
    m_df[j] = 0;
    if( j < feed.m_N)
     m_df[j] += THIS.m_f*feed.m_df[j];  // 1st partials: chain rule
    if( j < THIS.m_N)
     m_df[j] += feed.m_f*THIS.m_df[j];
   } 
     
  m_f = feed.m_f*THIS.m_f;             // multiply bases
   
  return(*this);   
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// multiplication equal operator 
// 
// Inputs:
//
// double c - real constant
//
// ABSTRACT: Multiply a feed object by a constant: feed *= c;
//
CFeed & CFeed::operator*=(const double c)
{
   unsigned long i,                     // counters
                 j;
   
   m_f = c*m_f;                         // multiply base
   
   for(i = 0; i < m_N; i++)
   {
     m_df[i] = c*m_df[i];               // 1st partials
     for(j = 0; j < m_N; j++)
      m_ddf[i*m_N+j] = c*m_ddf[i*m_N+j]; // and second partials
   }
   
   return(*this);      
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// multiplication operator
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: Multiply two feed objects: feed3 = feed1 * feed2;
//
CFeed  CFeed::operator*(const CFeed &feed)
{
  CFeed product(*this);                 // initialize product to 'this'
  product *= feed;                      // and multiply by 'feed'
  return(product);                      // return result
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// multiplication operator
// 
// Inputs:
//
// double c - real constant
//
// ABSTRACT: Multiply a feed object and a constant: feed2 = feed1 * c;
//
CFeed  CFeed::operator*(const double c)
{
   CFeed product(*this);                // initialize product to 'this'
   product *= c;                        // and multiply by constant
   return(product);                     // return result
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// Division operators:
//
// operator/=(const CFeed &) * operator/=(const double)
// operator/(const CFeed &)  * operator/(const double)
//
// The division of two feed objects is a feed object.  Constants are
// considered feed objects with zero length (size) i.e. no independent
// variables.  When dividing feed objects, the size of the resulting
// object is equal to the size of the largest object forming the product e.g.
// f(x,y)/g(x,y,z) = h(x,y,z).  The /= operator can therefore change
// the size of its feed object. Unlike addition and subtraction, the division
// of two feed objects is NOT the division of their members, but is given by
// the chain rule:
//
//  h(x1,x2,...xN) = f(x1,x2,...,xN)/g(x1,x2,...,xM); N > M
//  dh/dxi         = (1/g)*df/dxi - (f/g^2)*dg/dxi 
//  d2h/dxjdxi     = (1/g)*d2f/dxjdxi - (1/g^2)*df/dxi*dg/dxj- (1/g^2)*df/dxj*dg/dxi
//                 + 2*(f/g^3)*dg/dxj*dg/dxi - (f/g^2)*d2g/dxjdxi
//
//  In the above expressions dg/dxi = 0 for i > M
//
//  NOTE: The division operators do NOT check if the divisor e.g. g, above, is
//        zero.
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// division equal operator 
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: divide one feed object by another: feed1 /= feed2
//
CFeed & CFeed::operator/=(const CFeed &feed)
{
  unsigned long i,                      // counters
                j;
                
  CFeed THIS(*this);                    // make copy of 'this'
  if(m_N < feed.m_N)                    // 'this' smaller
   *this =  feed;                       // so set 'this' to 'feed'
                                        // larger size 
  for(i = 0; i < m_N; i++)       
  { 
    for(j = 0; j < m_N; j++)            // divide 2nd partials: chain rule
    {
      m_ddf[i*m_N+j] = 0;
    
      if((i < feed.m_N) && (j < feed.m_N))
       m_ddf[i*m_N+j] += 2.0*THIS.m_f*feed.m_df[i]*feed.m_df[j]/(feed.m_f*feed.m_f*feed.m_f);

      if((i < feed.m_N) && (j < feed.m_N))
       m_ddf[i*m_N+j] -= feed.m_ddf[i*feed.m_N+j]*THIS.m_f/(feed.m_f*feed.m_f); 
        
      if((i < THIS.m_N) && (j < THIS.m_N)) 
       m_ddf[i*m_N+j] += THIS.m_ddf[i*THIS.m_N+j]/feed.m_f;
        
      if((j < THIS.m_N) && (i < feed.m_N))
       m_ddf[i*m_N+j] -= feed.m_df[i]*THIS.m_df[j]/(feed.m_f*feed.m_f); 
         
      if((i < THIS.m_N) && (j < feed.m_N))
       m_ddf[i*m_N+j] -= feed.m_df[j]*THIS.m_df[i]/(feed.m_f*feed.m_f);
         
    }
  }
    
  for(j = 0; j < m_N; j++)              // divide  
  {
    m_df[j] = 0;
    
    if( j < feed.m_N)                   // 1st partials: chain rule
     m_df[j] -= THIS.m_f*feed.m_df[j]/(feed.m_f*feed.m_f);

    if( j < THIS.m_N)                   // 1st partials: chain rule
     m_df[j] += THIS.m_df[j]/feed.m_f;       
  } 
     
  m_f = THIS.m_f/feed.m_f;              // divide bases
   
  return(*this);   
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// division equal operator 
// 
// Inputs:
//
// double c - real constant
//
// ABSTRACT: divide a feed object by a constant: feed1 /= c
//
CFeed & CFeed::operator/=(const double c)
{
   unsigned long i,                     // counters
                 j;
                 
   if(c == 0) return(*this);            // can't divide by zero
   
   m_f = m_f/c;                         // divide base
   
   for(i = 0; i < m_N; i++)
   {
     m_df[i] = m_df[i]/c;               // 1st partials
     for(j = 0; j < m_N; j++)
      m_ddf[i*m_N+j] = m_ddf[i*m_N+j]/c; // and second partials
   }
   
   return(*this);      
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// division operator
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: divide two feed objects: feed3 = feed1 / feed2
//
CFeed  CFeed::operator/(const CFeed &feed)
{
  CFeed product(*this);                 // initialize product to 'this'
  product /= feed;                      // and divide by 'feed'
  return(product);                      // return result
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// division operator
// 
// Inputs:
//
// double c - real constant
//
// ABSTRACT: divide a feed object by a constant: feed2 = feed1 / c
//
CFeed  CFeed::operator/(const double c)
{
   CFeed product(*this);                // initialize product to 'this'
   product /= c;                        // and divide by constant
   return(product);                     // return result
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// call operator() * composite function chain rule
//
// operator()(const CFeed &) 
//
// The composite function chain rule is implemented using the call operator.
// Usage is as follows:
//
// feed3 = feed1(feed2)
//
// where fee1, feed2, and feed3 are feed objects AND (by definition) feed1
// has length one.  NOTE: the call operator does NOT check that feed1 is
// of length one; only the first item in the 1st and 2nd partial members
// is used.  The size of the result (feed3) is the same as the size of the
// parameter function (feed2). The result members are given by the chain rule
// as applied to composite functions:

//
//  h(x1,x2,...xN) = f(g(x1,x2,...,xN)); 
//  dh/dxi         = (df/dg)*(dg/dxi) 
//  d2h/dxjdxi     = (df/dg)*(d2g/dxjdxi) + (d2f/dgdg)*(dg/dxi)*(dg/dxj)
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// call operator * composite function chain rule
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: compute feed object using composite function chain rule.
//
CFeed  CFeed::operator()(const CFeed &feed)
{
  CFeed composite(feed.m_N);            // define composite 
  unsigned long i,                      // counters
                j; 
  if(m_N == 0) return(*this);           // constant
                
  for(i = 0; i < composite.m_N; i++)       
  { 
   for(j = 0; j < composite.m_N; j++)  // 2nd partials
     composite.m_ddf[i*composite.m_N+j] = feed.m_df[i]*feed.m_df[j]*m_ddf[0]
                           + feed.m_ddf[i*feed.m_N+j]*m_df[0];
  }
    
  for(j = 0; j < composite.m_N; j++)              // 1st partials
   composite.m_df[j] = feed.m_df[j]*m_df[0];       
     
  composite.m_f = m_f;                            // base
   
  return(composite);   
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// I/O operators and functions
//
// The call operator is overloaded to provide output access to the feed class
// objects data members: m_f, m_df, and m_ddf.  The size member function returns
// the size of the feed class object: M_N.
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// call operator * I/O to feed class members
// 
// Inputs:
//
// unsigned long i, j - member index
//
// ABSTRACT: Return value of feed class members:
//
//           if i = 0 & j = 0 return base valuue
//           if i > 0 & j = 0 return ith 1st partial
//           if i > 0 & j > 0 return ith, jth second partial
//
// Example: if feed is a feed class object then:
//
//          feed()    returns the base value of the object
//          feed(1)   returns df/dx1
//          feed(1,2) returns d^2f/dx1dx2 
//
// NOTE: the index of the partials is ONE based.  Out of range index
//       returns zero.
//
double  CFeed::operator()(void) {return(m_f);}     // base value
double  CFeed::operator()(unsigned long i)
{
  if(i > m_N)    return(0);                        // band index
  else if(i > 0) return(m_df[i-1]);                // first partial
  else return(0);                                  // bad index
}
double  CFeed::operator()(unsigned long i, unsigned long j)
{
  if((i > m_N) || (j > m_N))    return(0);         // band index
  else if((i > 0)  && (j > 0))  return(m_ddf[(i-1)*m_N+(j-1)]); // second partial
  else return(0);                                  // bad index
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// size
// 
// Inputs:
//
// None
//
// ABSTRACT: Return size of feed object
//
unsigned long CFeed::size(void) { return(m_N); }

//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// NON-Member operators
//
// operator+(const double, const CFeed &)
// operator-(const double, const CFeed &)
// operator*(const double, const CFeed &)
// operator/(const double, const CFeed &)
//
// These operators complete the addition, subtraction, multiplication, and 
// division operatiors.  They all involve constants and feed objects and
// of C++ syntax rules cannot be member functions of the feed class.  Since
// these operators work with only one feed object and a constant they do
// not change the size of the feed object; the resuling object is always
// the same size as the feed object in the operation. NOTE: the division
// operator does not check for a zero divisor; the base value of the feed
// object is assumed non-zero.
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// addition operator
// 
// Inputs:
//
// double c    - real constant
// CFeed &feed - reference to feed class 
//
// ABSTRACT: add a feed object to a constant
//
CFeed operator+(const double c, const CFeed &feed)
{
   CFeed sum(feed);                     // initialize sum to 'feed'
   sum += c;                            // add constant
   return(sum);                         // return result
    
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// subtraction operator
// 
// Inputs:
//
// double c    - real constant
// CFeed &feed - reference to feed class
//
// ABSTRACT: subtract a feed object from a constant
//
CFeed operator-(const double c, const CFeed &feed)
{
   CFeed sum(feed);                     // initialize sum to 'feed'
   sum = -sum;                          // reverse sign of sum
   sum += c;                            // add constant
   return(sum);                         // return result
    
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// multiplication operator
// 
// Inputs:
//
// double c    - real constant
// CFeed &feed - reference to feed class
//
// ABSTRACT: multiply a constant by a feed object
//
CFeed operator*(const double c, const CFeed &feed)
{
   CFeed product(feed);                 // initialize product to 'feed'
   product *= c;                        // multiply by constant
   return(product);                     // return result
    
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// divide operator
// 
// Inputs:
//
// double c    - real constant
// CFeed &feed - reference to feed class
//
// ABSTRACT: divide a constant by a feed object
//
CFeed operator/(const double c, const CFeed &feed)
{
   CFeed product(0,c);                  // initialize product to constant
   product /= feed;                     // divide by feed
   return(product);                     // return result
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// Math functions (friends)
//
// exp(CFeed &)  * log(CFeed &)  * log10(CFeed &) * sqrt(CFeed &)
// pow(CFeed &, CFeed &) * pow(double, CFeed &) * pow(CFeed &, double)
// sin(CFeed &)  * cos(CFeed &)  * tan(CFeed &) 
// asin(CFeed &) * acos(CFeed &) * atan(CFeed &) 
// sinh(CFeed &) * cosh(CFeed &) * tanh(CFeed &) 
//
// The math function listed above comprise all the transcendental functions
// contained in the standard math library (<math.h>).  These functions are
// declared as friends to the feed class and return the feed object corresponding
// to the composite function derivatives (chain rule) of the operand feed object:
// e.g.  CFeed ef = exp(CFeed &feed) ->
//
// ef.m_f        = exp(feed.m_f)
// ef.m_df[i]    = d exp(feed.m_f)/dxi      = exp(feed.m_f)*feed.m_df[i]
// ef.m_ddf[i,j] = d^2 exp(feed.m_f)/dxjdxi = exp(feed.m_f)*feed.m_df[i]*feed.m_df[j]
//                                          + exp(feed.m_f)*feed.m_ddf[i,j] 
//
// NOTE: These functions, like their <math.h> library counter parts do NOT
//       check for inappropiate values e.g. log(0), etc.  However, the range
//       of allowed  values (feed object base value) for each function is
//       listed in its header.
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// exp function
// 
// Inputs:
//
// CFeed &feed - reference to feed class 
//
// ABSTRACT: FEED for exp(f(x1,x2,...,xN))
//
//           (1) exp(x) 
//           (2) d exp(x)/dx   =  exp(x)
//           (2) d2 exp(x)/dx2 =  exp(x)
//
//           valid range of x = feed.m_f: -oo < x < oo
//
CFeed exp(const CFeed &feed)
{
   double df[1]     = {exp(feed.m_f)};  // first derivative
   double ddf[1]    = {exp(feed.m_f)};  // second derivative 
   CFeed e(1,exp(feed.m_f),df,ddf);     // e - feed class
   
   return(e(feed));                     // chain rule; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// log function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for log(f(x1,x2,...,xN))
//
//           (1) log(x) 
//           (2) d log(x)/dx   =   1/x
//           (2) d2 log(x)/dx2 =  -1/x^2
//
//           valid range of x = feed.m_f: 0 < x < oo
//
CFeed log(const CFeed &feed)
{
   double x         = feed.m_f;
   double df[1]     = {1.0/x};          // first derivative
   double ddf[1]    = {-1.0/(x*x)};     // second derivative 
   CFeed ln(1,log(x),df,ddf);           // ln - feed class
   
   return(ln(feed));                    // log; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// log10 function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for log10(f(x1,x2,...,xN))
//
//           (1) log10(x) 
//           (2) d log10(x)/dx   =   log10(e)/x
//           (2) d2 log10(x)/dx2 =  -log10(e)/x^2
//
//           valid range of x = feed.m_f: 0 < x < oo
//
CFeed log10(const CFeed &feed)
{
   double x = feed.m_f;
   double c = log10(exp(1.0));          // scale constant
   double df[1]     = {c/x};            // first derivative
   double ddf[1]    = {-c/(x*x)};       // second derivative 
   CFeed lg(1,log10(x),df,ddf);         // lg - feed class
   
   return(lg(feed));                    // log; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// sqrt function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for sqrt(f(x1,x2,...,xN))
//
//           (1) sqrt(x) 
//           (2) d sqrt(x)/dx   =   0.5/sqrt(x)
//           (2) d2 sqrt(x)/dx2 =  -0.25/(x*sqrt(x))
//
//           valid range of x = feed.m_f: 0 < x < oo
//
CFeed sqrt(const CFeed &feed)
{
   double X         = 1.0/sqrt(feed.m_f);
   double df[1]     = {0.5*X};          // first derivative
   double ddf[1]    = {-0.25*X*X*X};    // second derivative 
   CFeed sr(1,sqrt(feed.m_f),df,ddf);   // sr - feed class
   
   return(sr(feed));                    // square root; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// sin function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for sin(f(x1,x2,...,xN))
//
//           (1) sin(x) 
//           (2) d sin(x)/dx   =  cos(x)
//           (2) d2 sin(x)/dx2 = -sin(x)
//
//           valid range of x = feed.m_f: -oo < x < oo
//
CFeed sin(const CFeed &feed)
{
   double df[1]     = {cos(feed.m_f)}; // first derivative
   double ddf[1]    = {-sin(feed.m_f)};// second derivative 
   CFeed s(1,sin(feed.m_f),df, ddf);   // sin - feed class
   
   return(s(feed));                    // sine; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// cos function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for cos(f(x1,x2,...,xN))
//
//           (1) cos(x) 
//           (2) d cos(x)/dx   = -sin(x)
//           (2) d2 cos(x)/dx2 = -cos(x)
//
//           valid range of x = feed.m_f: -oo < x < oo
//
CFeed cos(const CFeed &feed)
{
   double df[1]     = {-sin(feed.m_f)};// first derivative
   double ddf[1]    = {-cos(feed.m_f)};// second derivative 
   CFeed c(1,cos(feed.m_f),df,ddf);    // cos - feed class
   
   return(c(feed));                    // cosine; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// tan function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for tan(f(x1,x2,...,xN))
//
//           (1) tan(x) 
//           (2) d tan(x)/dx   =  1/cos^2(x)
//           (2) d2 tan(x)/dx2 =  2*tan(x)/cos^2(x)
//
//           valid range of x = feed.m_f:  x != n*pi/2, n = any non-zero integer
//
CFeed tan(const CFeed &feed)
{
   double df[1]     = {1.0/(cos(feed.m_f)*cos(feed.m_f))};
   double ddf[1]    = {2.0*tan(feed.m_f)/(cos(feed.m_f)*cos(feed.m_f))}; 
   CFeed t(1,tan(feed.m_f),df, ddf);    // tan - feed class
   
   return(t(feed));                     // tangent; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// asin function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for asin(f(x1,x2,...,xN))
//
//           (1) asin(x) 
//           (2) d asin(x)/dx   =  1/sqrt(1-x^2)
//           (2) d2 asin(x)/dx2 =  x/((1-x^2)*sqrt(1-x^2))
//
//           valid range of x = feed.m_f: 0 < x < 1
//
CFeed asin(const CFeed &feed)
{ 
   double x         = (1.0 - feed.m_f*feed.m_f);
   double df[1]     = {1.0/sqrt(x)}; 
   double ddf[1]    = {feed.m_f/(x*sqrt(x))}; 
   CFeed s(1,asin(feed.m_f),df, ddf); 
   
   return(s(feed));                     // arc sine; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// acos function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for acos(f(x1,x2,...,xN))
//
//           (1) acos(x) 
//           (2) d acos(x)/dx   =  -1/sqrt(1-x^2)
//           (2) d2 acos(x)/dx2 =  -x/((1-x^2)*sqrt(1-x^2))
//
//           valid range of x = feed.m_f: 0 < x < 1
//
CFeed acos(const CFeed &feed)
{
   double x         = (1.0 - feed.m_f*feed.m_f);
   double df[1]     = {-1.0/sqrt(x)}; 
   double ddf[1]    = {-feed.m_f/(x*sqrt(x))}; 
   CFeed c(1,acos(feed.m_f),df,ddf); 
   
   return(c(feed));                     // arc cosine; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// atan function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for atan(f(x1,x2,...,xN))
//
//           (1) atan(x) 
//           (2) d atan(x)/dx   =  1/(1+x^2)
//           (2) d2 atan(x)/dx2 =  -2*x/(1+x^2)^2
//
//           valid range of x = feed.m_f: -oo < x < oo
//
CFeed atan(const CFeed &feed)
{
   double x         = 1.0 + feed.m_f*feed.m_f;
   double df[1]     = {1.0/x};
   double ddf[1]    = {-2.0*feed.m_f/(x*x)}; 
   CFeed t(1,atan(feed.m_f),df,ddf);   // atan - feed class
   
   return(t(feed));                    // arc tangent; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// sinh function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for sinh(f(x1,x2,...,xN))
//
//           (1) sinh(x) 
//           (2) d sinh(x)/dx   =  cosh(x)
//           (2) d2 sinh(x)/dx2 =  sinh(x)
//
//           valid range of x = feed.m_f: -oo < x < oo
//
CFeed sinh(const CFeed &feed)
{ 
   double df[1]     = {cosh(feed.m_f)}; 
   double ddf[1]    = {sinh(feed.m_f)}; 
   CFeed s(1,sinh(feed.m_f),df, ddf); 
   
   return(s(feed));                     // hyperbolic sine; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// cosh function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for cosh(f(x1,x2,...,xN))
//
//           (1) cosh(x) 
//           (2) d cosh(x)/dx   =  sinh(x)
//           (2) d2 cosh(x)/dx2 =  cosh(x)
//
//           valid range of x = feed.m_f: -oo < x < oo
//
CFeed cosh(const CFeed &feed)
{
   double df[1]     = {sinh(feed.m_f)}; 
   double ddf[1]    = {cosh(feed.m_f)}; 
   CFeed c(1,cosh(feed.m_f),df, ddf); 
   
   return(c(feed));                     // hyperbolic cosine; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// tanh function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
//
// ABSTRACT: FEED for tanh(f(x1,x2,...,xN))
//
//           (1) tanh(x) 
//           (2) d tanh(x)/dx   =  1/cosh^2(x)
//           (2) d2 tanh(x)/dx2 =  -2*tanh(x)/cosh^2(x)
//
//           valid range of x = feed.m_f: -oo < x < oo
//
CFeed tanh(const CFeed &feed)
{
   double df[1]     = {1.0/(cosh(feed.m_f)*cosh(feed.m_f))};
   double ddf[1]    = {-2.0*tanh(feed.m_f)/(cosh(feed.m_f)*cosh(feed.m_f))}; 
   CFeed t(1,tanh(feed.m_f),df,ddf);    // tanh - feed class
   
   return(t(feed));                     // hyperbolic tangent; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// pow function
// 
// Inputs:
//
// CFeed &feed - reference to feed class
// double p    - double
//
// ABSTRACT: FEED for f(x1,x2,...,xN)^p
//
//           (1) x^p 
//           (2) d x^p/dx   =  p*x^(p-1)
//           (2) d2 x^p/dx2 =  p*(p-1)*x^(p-2)
//
//           valid range of x = feed.m_f: -oo < x < oo;
//
CFeed pow(const CFeed &feed, const double p)
{
   double df[1]     = {p*pow(feed.m_f,p-1.0)};
   double ddf[1]    = {p*(p-1.0)*pow(feed.m_f,p-2.0)}; 
   CFeed w(1,pow(feed.m_f,p),df,ddf);   // pow - feed class
   
   return(w(feed));                     // pow; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// pow function
// 
// Inputs:
//
// CFeed &u - reference to feed class
// CFeed &v - reference to feed class
//
//
// ABSTRACT: FEED for u(x1,x2,...,xN)^v(x1,x2,...,xM)
//
//       (1) u(x1,x2,...,xN)^v(x1,x2,...,xM) = exp(v*log(u))
//       (2) d u^v/dx    = u^v*(log(u)*dv/dx +(v/u)*du/dx)
//       (2) d2 u^v/dxdy = u^v*(log(u)*dv/dx +(v/u)*du/dx)*(log(u)*dv/dy +(v/u)*du/dy)
//                           + u^v*(log(u)d2v/dxdy + (1/u)*dv/dx*du/dy 
//                                + (1/u)*dv/dy*du/dx - (v/u^2)*du/dx*du/dy 
//                                + (v/u)*d2u/dxdy)
//
//           valid range of u = u.m_f: 0 < u < oo; u != 0 
//           valid range of v = v.m_f: -oo < v < oo;  
//
CFeed pow(const CFeed &u ,const CFeed &v )
{
   unsigned long i,j;                   // counters
   CFeed p((u.m_N > v.m_N ? u.m_N : v.m_N),
           pow(u.m_f,v.m_f));           // pow - feed class
   
   for(i = 0; i < p.m_N; i++)           // 1st partials
   {
     p.m_df[i] = 0;
     if(i < v.m_N)
      p.m_df[i] += p.m_f*v.m_df[i]*log(u.m_f); 
     if(i < u.m_N)
      p.m_df[i] += p.m_f*u.m_df[i]*v.m_f/u.m_f;
   }
   
   for(i = 0; i < p.m_N; i++)           // 2nd partials
   {
     for(j = 0; j < p.m_N; j++)
     { 
       p.m_ddf[i*p.m_N+j] = 0;
       if(j < v.m_N)
        p.m_ddf[i*p.m_N+j] += p.m_df[i]*v.m_df[j]*log(u.m_f); 
       if(j < u.m_N)
        p.m_ddf[i*p.m_N+j] += p.m_df[i]*u.m_df[j]*v.m_f/u.m_f;
       if((i < v.m_N) && (j < v.m_N)) 
        p.m_ddf[i*p.m_N+j] += p.m_f*v.m_ddf[i*v.m_N+j]*log(u.m_f);
       if((i < u.m_N) && (j < u.m_N)) 
        p.m_ddf[i*p.m_N+j] += p.m_f*u.m_ddf[i*u.m_N+j]*v.m_f/u.m_f;
       if((i < u.m_N) && (j < v.m_N)) 
        p.m_ddf[i*p.m_N+j] += p.m_f*v.m_df[j]*u.m_df[i]/u.m_f;
       if((i < v.m_N) && (j < u.m_N)) 
        p.m_ddf[i*p.m_N+j] += p.m_f*v.m_df[i]*u.m_df[j]/u.m_f;
       if((i < u.m_N) && (j < u.m_N)) 
        p.m_ddf[i*p.m_N+j] -= p.m_f*u.m_df[i]*u.m_df[j]*v.m_f/(u.m_f*u.m_f);
     }
   }
   
   return(p);                    // pow; return
}
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// pow function
// 
// Inputs:
//
// douuble q - double
// CFeed &u  - reference to feed class
//
//
// ABSTRACT: FEED for q^u(x1,x2,...,xN)
//
//       (1) q^u(x1,x2,...,xN)
//       (2) d (q^u)/dx    = (q^u)*log(q)*du/dx 
//       (2) d2 (q^p)/dxdy = (q^u)*log(q)*(d2u/dxdy + log(q)*du/dy*du/dx)
//
//           valid range of u = u.m_f: -oo < u < oo; u != 0 
//           valid range of q: 0 < q < oo; q != 0 
//
CFeed pow(const double q ,const CFeed &u )
{
   unsigned long i,j;                   // counters
   CFeed p(u.m_N,pow(q,u.m_f));         // pow - feed class
   
   for(i = 0; i < p.m_N; i++)           
   {
     p.m_df[i] = p.m_f*u.m_df[i]*log(q); // 1st partials 
     for(j = 0; j < p.m_N; j++)          // 2nd partials
     {
       p.m_ddf[i*p.m_N+j] = p.m_f*log(q)*(u.m_df[i]*u.m_df[j]*log(q) + u.m_ddf[i*u.m_N+j]); 
     } 
   }
   
   return(p);                           // pow; return
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
// NON-Member functions: I/O
//
// operator<<(ostream &, CFeed &)
//
// The single friend operator in this category prints the feed object's
// data members to the screen or a file depending on how the output
// stream is defined. 
//
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//
//..............................................................................
//       1         2         3         4         5         6         7         8
//345678901234567890123456789012345678901234567890123456789012345678901234567890 
//..............................................................................
//
// output operator<<
// 
// Inputs:
//
// CFeed &feed - reference to feed class
// ostream &os - reference to ostream
//
// ABSTRACT: print all members of feed class to output stream:
//
//           (1) size: N
//           (2) base: f
//
//           (3) 1 df/dx1
//           (4) 2 df/dx2
//                   .
//                   .
//                   .
//         (N+2) N df/dxN 
//
//         (N+3) 1 1 d2f/dx1dx1
//         (N+4) 1 2 d2f/dx1dx2
//                   .
//                   .
//                   .
//       (2*N+2) 1 N d2f/dx1dxN
//       (2*N+3) 2 1 d2f/dx2dx1
//                   .
//                   .
//                   .
//       (N*N+2) N N d2f/dxNdxN
//
ostream & operator<<(ostream &os,CFeed &feed)  
{
   unsigned long i,j;
   
   os << "Feed Size:   " << feed.m_N << endl;
   os << "Base Value : " << feed.m_f << endl << endl;

   os << "First Partials: " << endl << endl;
   
   for(i = 0; i < feed.m_N; i++)
    os << "df[" << i+1 << "]: " << feed.m_df[i] << endl;
    
   os << endl << "Second Partials: " << endl; 
   
   for(i = 0; i < feed.m_N; i++)
   {
     os << endl; 
     for(j = 0; j < feed.m_N; j++)
      os << "d^2f[" <<  i+1 << "," << j+1 << "]: " << feed.m_ddf[i*feed.m_N+j] << endl;
   }

   return(os);
}
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
//      end       end       end       end       end       end       end        
//......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......]*[.......].
       