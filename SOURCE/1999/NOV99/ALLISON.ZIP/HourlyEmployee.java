class HourlyEmployee extends Employee
{
    public HourlyEmployee(String name, double rate)
    {
        super(name, rate);
    }
    public double computePay()
    {
        if (timeWorked > 40.0)
            return 40.0*rate + (timeWorked - 40.0) * rate*1.5;
        else
            return timeWorked * rate;
    }
}

