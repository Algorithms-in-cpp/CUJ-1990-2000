import java.util.*;

class ArrayListTest
{
    public static void main(String[] args)
    {
        // Populate collection:
        ArrayList a = new ArrayList();
        a.add(new Integer(1));
        a.add(new Integer(2));

        for (int i = 0; i < a.size(); ++i)
        {
            Integer n = (Integer) a.get(i);
            System.out.println(n);
        }
    }
}

/* Output:
1
2
*/

