class EmployeeTest
{
    private static Employee[] emps;

    static void pay(Employee e)
    {
        System.out.println(e.getName() +
            " gets " + e.computePay());
    }
    public static void doPayroll()
    {
        for (int i = 0; i < emps.length; ++i)
            pay(emps[i]);
    }

    public static void main(String[] args)
    {
        Employee e1 =
            new Employee("John Hourly", 
                    16.50);
        e1.recordTime(52.0);
        SalariedEmployee e2 = new
            SalariedEmployee("Jane Salaried", 
                1125.0);
        e2.recordTime(1.0);

        emps = new Employee[2];
        emps[0] = e1;
        emps[1] = e2;
        doPayroll();
    }
}

/* Output:
John Hourly gets 957.0
Jane Salaried gets 1125.0
*/
