abstract class Employee
{
    String name;
    double rate;
    double timeWorked;

    public Employee(String name, double rate)
    {
        this.rate = rate;
        this.name = name;
    }
    public final String getName()
    {
        return name;
    }
    public final double getRate()
    {
        return rate;
    }
    public final void recordTime(double time)
    {
        timeWorked = time;
    }
    public abstract double computePay();
}

