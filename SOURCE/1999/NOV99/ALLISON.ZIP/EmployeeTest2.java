class EmployeeTest
{
    private static Employee[] emps;

    static void pay(Employee e)
    {
        System.out.println(e.getName() + " gets " + 
            e.computePay());
    }
    public static void doPayroll()
    {
        for (int i = 0; i < emps.length; ++i)
            pay(emps[i]);
    }
    
    public static void main(String[] args)
    {
        emps = new Employee[2];
        emps[0] = new HourlyEmployee("John Hourly", 16.50);
        emps[0].recordTime(52.0);
        emps[1] = new SalariedEmployee("Jane Salaried", 1125.0);
        emps[1].recordTime(1.0);
        doPayroll();
    }
}
