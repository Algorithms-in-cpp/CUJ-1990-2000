class DownCastTest
{
    public static void main(String[] args)
    {
        Employee e =
            new Employee("John Hourly", 16.50);

        // The following is true:
        System.out.println(e instanceof Employee);

        // The following is false:
        System.out.println(e instanceof SalariedEmployee);

        // An invalid cast:
        SalariedEmployee s = (SalariedEmployee) e;
    }
}
