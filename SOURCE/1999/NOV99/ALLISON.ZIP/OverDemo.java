class B
{
    public void f() {
        System.out.println("B.f()");
    }
}

class D extends B
{
    public void f(int i) {
        System.out.println("D.f(" + i + ")");
    }
}

class ScopeTest
{
    public static void main(String[] args) {
        D d = new D();
        d.f();          // B.f
        d.f(1);         // D.f
    }
}

/* Output:
B.f
D.f
*/



