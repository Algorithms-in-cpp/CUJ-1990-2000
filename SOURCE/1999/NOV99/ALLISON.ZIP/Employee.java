class Employee
{
    String name;
    double rate;
    double timeWorked;

    public Employee(String name, double rate)
    {
        this.rate = rate;
        this.name = name;
    }
    public String getName()
    {
        return name;
    }
    public double getRate()
    {
        return rate;
    }
    public void recordTime(double time)
    {
        timeWorked = time;
    }
    public double computePay()
    {
        if (timeWorked > 40.0)
            return 40.0*rate +
                (timeWorked - 40.0)*rate*1.5;
        else
            return timeWorked * rate;
    }
}
