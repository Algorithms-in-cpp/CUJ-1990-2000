
MFC_equalizer_demo.zip:

I will assume that you are using Visual C++ 6 to compile and run 
this project.  I understand that Borland C++ 4 would also compile 
this project, but I haven't actually tried it. 

Also, I will assume that you have a fast PC (minimum Pentium II 
at 300 MHz or equivalent).  If the PC is not fast enough, the 
audio file might playing with gaps, or even the computer may lock. 
Remember that this demo does not show an appropriate use of FIR 
filtering techniques;  it just shows the capabilities and the 
way the classes may be used.  For a real-time CD-quality audio 
processing system, other techniques may be more appropriate.


To compile and run this demo:

Launch WinZip and extract all the files to a directory on your 
hard disk (e.g., c:\FIR_demo).  Launch Visual C++ 6 and select 
the menu "File/Open Workspace..." Select the file MFC_demo.dsw 
and click on "Open".  Finally, run the program. 
