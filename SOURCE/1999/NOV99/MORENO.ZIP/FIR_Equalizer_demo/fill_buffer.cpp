
#include <cstdio>
#include <vector>
#include <valarray>
using namespace std;

#include "FIR.h"
#include "Signals.h"

#include "definitions.h"
#include "coefficients_arrays.h"


static FILE * audio_file = NULL;


basic_FIR<int> update_filter (const vector<double> & eq_levels)
{
    static valarray<double> coefficients_80 (coeff_80, sizeof(coeff_80) / sizeof(coeff_80[0]));
    static valarray<double> coefficients_200 (coeff_200, sizeof(coeff_200) / sizeof(coeff_200[0]));
    static valarray<double> coefficients_500 (coeff_500, sizeof(coeff_500) / sizeof(coeff_500[0]));
    static valarray<double> coefficients_1k (coeff_1k, sizeof(coeff_1k) / sizeof(coeff_1k[0]));
    static valarray<double> coefficients_2k (coeff_2k, sizeof(coeff_2k) / sizeof(coeff_2k[0]));
    static valarray<double> coefficients_5k (coeff_5k, sizeof(coeff_5k) / sizeof(coeff_5k[0]));
    static valarray<double> coefficients_8k (coeff_8k, sizeof(coeff_8k) / sizeof(coeff_8k[0]));
    static valarray<double> coefficients_15k (coeff_15k, sizeof(coeff_15k) / sizeof(coeff_15k[0]));

    valarray<double> mix = eq_levels[0] * coefficients_80 + 
                           eq_levels[1] * coefficients_200 + 
                           eq_levels[2] * coefficients_500 + 
                           eq_levels[3] * coefficients_1k + 
                           eq_levels[4] * coefficients_2k + 
                           eq_levels[5] * coefficients_5k + 
                           eq_levels[6] * coefficients_8k + 
                           eq_levels[7] * coefficients_15k;

    valarray<int> result;

    result.resize (mix.size());

    for (int i = 0; i < result.size(); i++)
    {
        convert (mix[i], result[i]);
    }

    return basic_FIR<int> (result);   // The coefficients are already calculated 
                                      // with the scale factor of 65536
}


bool FillBuffer (SAMPLE_TYPE * pBuffer, const vector<double> & eq_levels)
{
    static short int SamplesBuffer [2 * OUT_BUFFER_SIZE];
    static short int LeftBuffer  [OUT_BUFFER_SIZE], 
                     RightBuffer [OUT_BUFFER_SIZE];

    static Signal<short int> signal_L (50 * OUT_BUFFER_SIZE), 
                             signal_R (50 * OUT_BUFFER_SIZE);

    static basic_FIR<int> filter (Low_pass(1,2,10));

    static vector<double> previous_eq_levels;

    if (eq_levels.size() != previous_eq_levels.size() || 
        ! equal (eq_levels.begin(), eq_levels.end(), previous_eq_levels.begin()))
    {
        previous_eq_levels = eq_levels;
        filter = update_filter (eq_levels);
    }

    int num_samples;
    
    if (audio_file != NULL)
    {
        num_samples = fread ((void *) SamplesBuffer, 2*OUT_BUFFER_SIZE, sizeof(SAMPLE_TYPE), audio_file);
    }
    else
    {
        num_samples = 0;
    }

    if (num_samples != 0)
    {
        SAMPLE_TYPE * sample = SamplesBuffer;

        int i;      // so that it works in VC++

        for (i = 0; i < OUT_BUFFER_SIZE; i++)
        {
            LeftBuffer[i] = *sample++;          // Split stream into L-R streams
            RightBuffer[i] = *sample++;
        }

                // Now filter each audio channel separately
		signal_L.insert_block (LeftBuffer, OUT_BUFFER_SIZE);
        signal_R.insert_block (RightBuffer, OUT_BUFFER_SIZE);

        static int ScaledLeftBuffer [OUT_BUFFER_SIZE], 
                   ScaledRightBuffer [OUT_BUFFER_SIZE];

		signal_L.filtered_block (filter, OUT_BUFFER_SIZE, ScaledLeftBuffer);
        signal_R.filtered_block (filter, OUT_BUFFER_SIZE, ScaledRightBuffer);

                // Merge the two channels to submit to the audio device
        sample = pBuffer;
		for (i = 0; i < OUT_BUFFER_SIZE; i++)
		{
            *sample++ = ScaledLeftBuffer[i] / 65536;
            *sample++ = ScaledRightBuffer[i] / 65536;
		}
        return true;
    }
    else
    {
        return false;
    }
}



// ****  Uses global variable audio_file  (local to this module)  ****
struct wave_header open_audio_file (const char * filename)
{
    struct wave_header file_header;

    if (audio_file != NULL)
    {
        void close_audio_file();    // prototype -- defined below

        close_audio_file ();
    }

    audio_file = fopen (filename, "rb");
    if (audio_file != NULL)
    {
        fread ((void *) &file_header, sizeof(file_header), 1, audio_file);
    }
    else
    {
        file_header.nChannels = 0;      // Mark error condition
    }

    return file_header;
}


// ****  Uses global variable audio_file  (local to this module)  ****
void close_audio_file ()
{
    if (audio_file != NULL)
    {
        fclose (audio_file);
        audio_file = NULL;
    }
}

