
#ifndef __DEFINITIONS_H__
#define __DEFINITIONS_H__

struct wave_header
{
    char RIFF[4];
    int size_of_waveform_chunk;
    char WAVE[4];
    char fmt[4];
    int size_of_format_chunk;
    short int FormatTag;
    short int nChannels;
    int SamplesPerSecond;
    int AvgBytesPerSecond;
    short int BlockAlign;
    short int BitsPerSample;
    char data[4];
    int size_of_waveform_data;
};

const int OUT_BUFFER_SIZE = 16384;

typedef short int SAMPLE_TYPE;

#endif
