// MFC_demoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MFC_demo.h"
#include "MFC_demoDlg.h"

#include <mmsystem.h>   // Win32 API multi-media facilities

#include <vector>
#include <cmath>
using namespace std;

#include "definitions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFC_demoDlg dialog

CMFC_demoDlg::CMFC_demoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMFC_demoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMFC_demoDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32

    m_80Hz = 50;
	m_15kHz = 50;
	m_1kHz = 50;
	m_200Hz = 50;
	m_2kHz = 50;
	m_500Hz = 50;
	m_5kHz = 50;
	m_8kHz = 50;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFC_demoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMFC_demoDlg)
	DDX_Control(pDX, IDC_PB_OPEN_FILE, m_pb_OpenFile);
	DDX_Control(pDX, IDC_PB_STOP, m_pb_Stop);
	DDX_Control(pDX, IDC_SLD_8K, m_ctl_8kHz);
	DDX_Control(pDX, IDC_SLD_5K, m_ctl_5kHz);
	DDX_Control(pDX, IDC_SLD_500, m_ctl_500Hz);
	DDX_Control(pDX, IDC_SLD_2K, m_ctl_2kHz);
	DDX_Control(pDX, IDC_SLD_200, m_ctl_200Hz);
	DDX_Control(pDX, IDC_SLD_1K, m_ctl_1kHz);
	DDX_Control(pDX, IDC_SLD_15K, m_ctl_15kHz);
	DDX_Control(pDX, IDC_SLD_80, m_ctl_80Hz);
	DDX_Control(pDX, IDC_PB_PLAY, m_pb_Play);
	DDX_Slider(pDX, IDC_SLD_80, m_80Hz);
	DDX_Slider(pDX, IDC_SLD_15K, m_15kHz);
	DDX_Slider(pDX, IDC_SLD_1K, m_1kHz);
	DDX_Slider(pDX, IDC_SLD_200, m_200Hz);
	DDX_Slider(pDX, IDC_SLD_2K, m_2kHz);
	DDX_Slider(pDX, IDC_SLD_500, m_500Hz);
	DDX_Slider(pDX, IDC_SLD_5K, m_5kHz);
	DDX_Slider(pDX, IDC_SLD_8K, m_8kHz);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMFC_demoDlg, CDialog)
	//{{AFX_MSG_MAP(CMFC_demoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_PB_OPEN_FILE, OnPbOpenFile)
	ON_BN_CLICKED(IDC_PB_PLAY, OnPbPlay)
	ON_BN_CLICKED(IDC_PB_STOP, OnPbStop)
	//}}AFX_MSG_MAP
    ON_MESSAGE (MM_WOM_OPEN, On_MM_WOM_OPEN)
    ON_MESSAGE (MM_WOM_DONE, On_MM_WOM_DONE)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFC_demoDlg message handlers

BOOL CMFC_demoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMFC_demoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMFC_demoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMFC_demoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}



void CMFC_demoDlg::OnPbOpenFile() 
{
    struct wave_header open_audio_file (const char * filename);

    CFileDialog dlg (true, "wav", NULL, OFN_FILEMUSTEXIST, "Wave files (*.wav)|*.wav||");

    if (dlg.DoModal() == IDOK)
    {
        m_filename = dlg.GetPathName();
        m_audio_file_header = open_audio_file (m_filename);

        if (m_audio_file_header.nChannels == 0)
        {
            MessageBox ("Error opening audio file", "Error", MB_OK + MB_ICONEXCLAMATION);
        }
        else if (m_audio_file_header.SamplesPerSecond < 44100 || 
            m_audio_file_header.nChannels < 2 || 
            m_audio_file_header.BitsPerSample < 16)
        {
            void close_audio_file ();   // prototype -- defined in fill_buffer.cpp

            close_audio_file ();
            m_pb_Play.EnableWindow (false);
            MessageBox ("This demo only works with .wav audio files containing stereo, 16 bits, 44.1kHz or 48kHz data", 
                        "Invalid Audio File", 
                        MB_OK + MB_ICONEXCLAMATION);
        }
        else
        {
            m_pb_Play.EnableWindow();
        }
    }
}

void CMFC_demoDlg::OnPbPlay() 
{
    pWaveHdr1 = (struct wavehdr_tag *) malloc (sizeof (WAVEHDR)) ;
    pWaveHdr2 = (struct wavehdr_tag *) malloc (sizeof (WAVEHDR)) ;
    pBuffer1  = (SAMPLE_TYPE *) malloc (2 * OUT_BUFFER_SIZE * sizeof(SAMPLE_TYPE)) ;
    pBuffer2  = (SAMPLE_TYPE *) malloc (2 * OUT_BUFFER_SIZE * sizeof(SAMPLE_TYPE)) ;

    if (!pWaveHdr1 || !pWaveHdr2 || !pBuffer1 || !pBuffer2)
    {
         if (!pWaveHdr1) free (pWaveHdr1) ;
         if (!pWaveHdr2) free (pWaveHdr2) ;
         if (!pBuffer1)  free (pBuffer1) ;
         if (!pBuffer2)  free (pBuffer2) ;

         // MessageBeep (MB_ICONEXCLAMATION) ;
         MessageBox ("Error allocating memory!", "FIR Filters Demo", MB_ICONEXCLAMATION | MB_OK) ;
         return;
    }

         // Variable to indicate Off button pressed

//    bShutOff = FALSE ;   // OJO!!!!
         
         // Open waveform audio for output
         
    waveformat.wFormatTag      = WAVE_FORMAT_PCM;
    waveformat.nChannels       = m_audio_file_header.nChannels;
    waveformat.nSamplesPerSec  = m_audio_file_header.SamplesPerSecond;
    waveformat.nAvgBytesPerSec = m_audio_file_header.AvgBytesPerSecond;
    waveformat.nBlockAlign     = m_audio_file_header.BlockAlign;
    waveformat.wBitsPerSample  = m_audio_file_header.BitsPerSample;
    waveformat.cbSize          = 0 ;
         
    if (waveOutOpen (&hWaveOut, WAVE_MAPPER, &waveformat,
                     (DWORD) m_hWnd, 0, CALLBACK_WINDOW)
              != MMSYSERR_NOERROR)
    {
         free (pWaveHdr1) ;
         free (pWaveHdr2) ;
         free (pBuffer1) ;
         free (pBuffer2) ;

         hWaveOut = NULL ;
         // MessageBeep (MB_ICONEXCLAMATION) ;
         MessageBox ("Error opening waveform audio device!", "FIR Filters Demo", 
                      MB_ICONEXCLAMATION | MB_OK);
         return;
    }

         // Set up headers and prepare them

    pWaveHdr1->lpData          = (char *) pBuffer1 ;
    pWaveHdr1->dwBufferLength  = 2 * OUT_BUFFER_SIZE * sizeof (SAMPLE_TYPE) ;
    pWaveHdr1->dwBytesRecorded = 0 ;
    pWaveHdr1->dwUser          = 0 ;
    pWaveHdr1->dwFlags         = 0 ;
    pWaveHdr1->dwLoops         = 1 ;
    pWaveHdr1->lpNext          = NULL ;
    pWaveHdr1->reserved        = 0 ;
    
    waveOutPrepareHeader (hWaveOut, pWaveHdr1, 
                          sizeof (WAVEHDR)) ;

    pWaveHdr2->lpData          = (char *) pBuffer2 ;
    pWaveHdr2->dwBufferLength  = 2 * OUT_BUFFER_SIZE * sizeof (SAMPLE_TYPE) ;
    pWaveHdr2->dwBytesRecorded = 0 ;
    pWaveHdr2->dwUser          = 0 ;
    pWaveHdr2->dwFlags         = 0 ;
    pWaveHdr2->dwLoops         = 1 ;
    pWaveHdr2->lpNext          = NULL ;
    pWaveHdr2->reserved        = 0 ;
    
    waveOutPrepareHeader (hWaveOut, pWaveHdr2,
                          sizeof (WAVEHDR)) ;

    m_pb_Play.EnableWindow (false);
    m_pb_OpenFile.EnableWindow (false);
    m_pb_Stop.EnableWindow (true);
}


void CMFC_demoDlg::OnPbStop() 
{
	waveOutReset (hWaveOut);
    waveOutClose (hWaveOut);

    m_pb_Stop.EnableWindow (false);
    m_pb_Play.EnableWindow (true);
    m_pb_OpenFile.EnableWindow (true);
}


bool FillBuffer (SAMPLE_TYPE * pBuffer, const vector<double> & eq_levels);

BOOL CMFC_demoDlg::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	return CDialog::OnCommand(wParam, lParam);
}


void CMFC_demoDlg::On_MM_WOM_OPEN (WPARAM wParam, LPARAM lParam)
{
    static vector<double> eq_levels;

    eq_levels.clear();
    eq_levels.push_back(pow (2, (get_80Hz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_200Hz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_500Hz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_1kHz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_2kHz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_5kHz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_8kHz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_15kHz_level() + 5) / 20.0) / 32);

    FillBuffer (pBuffer1, eq_levels);
    waveOutWrite (hWaveOut, pWaveHdr1, sizeof (WAVEHDR));

    FillBuffer (pBuffer2, eq_levels) ;
    waveOutWrite (hWaveOut, pWaveHdr2, sizeof (WAVEHDR));
}


void CMFC_demoDlg::On_MM_WOM_DONE (WPARAM wParam, LPARAM lParam)
{
    static vector<double> eq_levels;

    eq_levels.clear();
    eq_levels.push_back(pow (2, (get_80Hz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_200Hz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_500Hz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_1kHz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_2kHz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_5kHz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_8kHz_level() + 5) / 20.0) / 32);
    eq_levels.push_back(pow (2, (get_15kHz_level() + 5) / 20.0) / 32);

    if (FillBuffer ((SAMPLE_TYPE *)(((PWAVEHDR) lParam)->lpData), eq_levels))
    {
        waveOutWrite (hWaveOut, (PWAVEHDR) lParam, sizeof (WAVEHDR));
    }
    else
    {
        struct wave_header open_audio_file (const char * filename);

        OnPbStop();
        open_audio_file (m_filename);  // ready to restart playing
    }
}

int CMFC_demoDlg::get_80Hz_level ()
{
    UpdateData ();
    return 100 - m_80Hz; 
}

int CMFC_demoDlg::get_200Hz_level ()
{
    UpdateData ();
    return 100 - m_200Hz; 
}

int CMFC_demoDlg::get_500Hz_level ()
{
    UpdateData ();
    return 100 - m_500Hz; 
}

int CMFC_demoDlg::get_1kHz_level ()
{
    UpdateData ();
    return 100 - m_1kHz; 
}

int CMFC_demoDlg::get_2kHz_level ()
{
    UpdateData ();
    return 100 - m_2kHz; 
}

int CMFC_demoDlg::get_5kHz_level ()
{
    UpdateData ();
    return 100 - m_5kHz; 
}

int CMFC_demoDlg::get_8kHz_level ()
{
    UpdateData ();
    return 100 - m_8kHz; 
}

int CMFC_demoDlg::get_15kHz_level ()
{
    UpdateData ();
    return 100 - m_15kHz; 
}
