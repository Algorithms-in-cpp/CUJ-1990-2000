// MFC_demoDlg.h : header file
//

#if !defined(AFX_MFC_DEMODLG_H__911468E6_49FA_11D3_8970_0080C8DD2A03__INCLUDED_)
#define AFX_MFC_DEMODLG_H__911468E6_49FA_11D3_8970_0080C8DD2A03__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "definitions.h"
#include <mmsystem.h>


/////////////////////////////////////////////////////////////////////////////
// CMFC_demoDlg dialog

class CMFC_demoDlg : public CDialog
{
// Construction
public:

	CMFC_demoDlg(CWnd* pParent = NULL);	// standard constructor

    int get_80Hz_level ();
    int get_200Hz_level ();
    int get_500Hz_level ();
    int get_1kHz_level ();
    int get_2kHz_level ();
    int get_5kHz_level ();
    int get_8kHz_level ();
    int get_15kHz_level ();

// Dialog Data
	//{{AFX_DATA(CMFC_demoDlg)
	enum { IDD = IDD_MFC_DEMO_DIALOG };
	CButton	m_pb_OpenFile;
	CButton	m_pb_Stop;
	CSliderCtrl	m_ctl_8kHz;
	CSliderCtrl	m_ctl_5kHz;
	CSliderCtrl	m_ctl_500Hz;
	CSliderCtrl	m_ctl_2kHz;
	CSliderCtrl	m_ctl_200Hz;
	CSliderCtrl	m_ctl_1kHz;
	CSliderCtrl	m_ctl_15kHz;
	CSliderCtrl	m_ctl_80Hz;
	CButton	m_pb_Play;
	int		m_80Hz;
	int		m_15kHz;
	int		m_1kHz;
	int		m_200Hz;
	int		m_2kHz;
	int		m_500Hz;
	int		m_5kHz;
	int		m_8kHz;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFC_demoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMFC_demoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPbOpenFile();
	afx_msg void OnPbPlay();
	afx_msg void OnPbStop();
	//}}AFX_MSG
    afx_msg void On_MM_WOM_OPEN (WPARAM wParam, LPARAM lParam);
    afx_msg void On_MM_WOM_DONE (WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	CString m_filename;

    HWAVEOUT     hWaveOut;
    HWND         hwndScroll;
    SAMPLE_TYPE  * pBuffer1, * pBuffer2;
    PWAVEHDR     pWaveHdr1, pWaveHdr2;
    WAVEFORMATEX waveformat;

    struct wave_header m_audio_file_header;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFC_DEMODLG_H__911468E6_49FA_11D3_8970_0080C8DD2A03__INCLUDED_)
