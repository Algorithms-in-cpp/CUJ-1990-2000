#include <iostream>
#include <fstream>
#include <valarray>
#include <cmath>
#include <ctime>
#include <limits>
#include <cassert>
#include <algorithm>
using namespace std;

#include "FIR.h"
#include "Signals.h"

template <class T>
void print_impulse_response (const basic_FIR<T> & filter, ostream & out)
{
    Signal<T> x;

    x << 1;
    out << x.filtered_output (filter);

    for (int i = 1; i < filter.length(); i++)
    {
        x << 0;
        out << x.filtered_output (filter) << endl;
    }
}


int main()
{
    typedef short int sample_type;
    typedef double filter_type;

    const int oversampling_factor = 8;
    const int buffer_size = 100000;

    static sample_type input_buffer [buffer_size];
    static filter_type output_buffer [oversampling_factor * buffer_size];
    filter_type * output_ptr = output_buffer;

    sample_type zeroes[oversampling_factor] = {0};

    const basic_FIR<filter_type> oversampling_filter (Low_pass (1, 2*oversampling_factor, 3*oversampling_factor), oversampling_factor * 65536);
    Signal<sample_type> signal1(1024), signal2(1024);

    for (int t = 0; t < buffer_size; t++)
    {
        convert (1000 * sin (t/10.0) + 1000 * sin(t/2.5), input_buffer[t]);
    }

    print_impulse_response (oversampling_filter, cout);


    cout << "\nStarting block processing... ";

    int i;
    int start = clock();
    
    for (i = 0; i < buffer_size; i++)
    {
        zeroes[0] = input_buffer[i];
        signal1.insert_block (zeroes, oversampling_factor);
        signal1.filtered_block (oversampling_filter, oversampling_factor, output_ptr);

        output_ptr += oversampling_factor;
    }

    int stop = clock();
    cout << "\nDone in " << static_cast<double>(stop - start) / CLK_TCK << "sec\n";


    cout << "\nStarting processing one sample at a time...";

    output_ptr = output_buffer;

    start = clock();

    for (i = 0; i < buffer_size; i++)
    {
        signal2 << input_buffer[i];
        *output_ptr++ = signal2.filtered_output(oversampling_filter);

        for (int z = 1; z < oversampling_factor; z++)
        {
            signal2 << 0;
            *output_ptr++ = signal2.filtered_output(oversampling_filter);
        }
    }

    stop = clock();
    cout << "\nDone in " << static_cast<double>(stop - start) / CLK_TCK << "sec\n";

    return 0;
}
