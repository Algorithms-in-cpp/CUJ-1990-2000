#include <stdio.h>
#include <math.h>
#include <time.h>
#include <assert.h>

typedef short int sample_type;
typedef double filter_type;

#define oversampling_factor 8
#define buffer_size 100000

filter_type filtered_output (sample_type x[], filter_type h[], int length)
{
    filter_type result = 0;
    int i;

    for (i = 0; i < length; i++)
    {
        result += h[i] * x[-i];
    }

    return result;
}


int main()
{
    static sample_type input_buffer [buffer_size];
    static sample_type expanded_input [oversampling_factor * buffer_size + 2000] = {0};
    static filter_type output_buffer [oversampling_factor * buffer_size + 2000];
    
    sample_type * input_ptr = expanded_input + 1000;
    filter_type * output_ptr = output_buffer + 1000;

    static filter_type filter[47] = 
        {-203,-412,-409,-364,-252,-95,16,-62,-488,-1357,-2620,-4026,-5105,
         -5224,-3694,66,6367,15110,25724,37203,48235,57417,63503,65633,63503,
         57417,48235,37203,25724,15110,6367,66,-3694,-5224,-5105,-4026,-2620,
         -1357,-488,-62,16,-95,-252,-364,-409,-412,-203};

    int t, i, start, stop;

    FILE * out_file;


    sample_type zeroes[oversampling_factor] = {0};

    for (t = 0; t < buffer_size; t++)
    {
        input_buffer[t] = 1000 * sin (t/10.0) + 1000 * sin(t/2.5);
    }


    printf ("\nStarting block processing... ");

    start = clock();

    for (i = 0; i < buffer_size; i++)
    {
        int z;
        zeroes[0] = input_buffer[i];
        memcpy (input_ptr, zeroes, sizeof (zeroes));

        for (z = 0; z < oversampling_factor; z++)
        {
            *output_ptr++ = filtered_output (input_ptr++, filter, 47);
        }
    }

    stop = clock();

    printf ("\nDone in %lf sec\n", (double)(stop - start) / CLK_TCK);

    out_file = fopen ("d:/temp/oversampling_results_c.txt", "w");
    assert (out_file != NULL);

    for (i = 0; i < 500; i++)
    {
        fprintf (out_file, "%lf\n", output_buffer[1000 + i]);
    }

    return 0;
}
