// Simple.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Simple.h"
#include "giodebug.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

BOOL TryMacros();

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		cout << "See file C:\\ASSERT.LOG"<< endl;
		nRetCode = 0;
	}

    TryMacros();

	return nRetCode;
}


// Do some assertions
BOOL TryMacros()
{
   CWnd * pWnd=NULL;
   SAFE(pWnd)->GetSafeHwnd(); // Will assert

   char buff[16];
   strcpy(SAFE(buff),"Hello From me"); // Will not assert
   ASSERT_LEN(buff);                   // Will not assert

   int Array[10],Index=10;
   ASSERT_ARRAYINDEX(Array,Index);   // Will assert
   Array[Index-1]=0;

   int x,y=1,z=0;
   x=y*6+y/SAFE(y-z)*2; // If denominator is 0, it will assert
   z=SAFE(y-1);  // Will assert
  
   if (0)
     return SAFE(FALSE); // Assert before returning
   
   if (!SAFE(y==1))      // Assert before returning
      return FALSE;

   ASSERT(z==11);
   VERIFY(y=0);
 
   int once=0;
   for (int i=0;i<10;i++)
       ASSERT_ONCE(once); // Will assert only once

   return SAFE(FALSE); // Will assert
}
