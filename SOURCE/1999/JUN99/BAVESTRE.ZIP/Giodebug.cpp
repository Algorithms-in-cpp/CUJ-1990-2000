#include "stdafx.h"
#include "giodebug.h"

//==============================================================================
// Some debugging macros by G.Bavestrelli     Copyright Techint S.p.A. 1994-1999 
// Any feedback is welcome, you can contact me at giovanni.bavestrelli@pomini.it
//==============================================================================


#ifdef _DEBUG

// Just display a warning on video to tell user of assert
static void ShowAssertWarning()
{
  CDC DC;
  DC.CreateDC("DISPLAY",NULL,NULL,NULL);

  COLORREF OldTextColor=DC.SetTextColor(RGB(255,0,0)); // Red
  COLORREF OldBkColor  =DC.SetBkColor(RGB(255,255,0)); // Yellow
  int      OldBkMode   =DC.SetBkMode(OPAQUE);

  CRect rect;
  DC.GetClipBox(&rect);
  rect.InflateRect(-2,-2); 

  LPCSTR str = " ASSERTION FAILURE: see file C:\\ASSERT.LOG ";
  DC.DrawText(str,lstrlen(str),&rect,DT_BOTTOM|DT_RIGHT|DT_SINGLELINE);

  DC.SetTextColor(OldTextColor);
  DC.SetBkColor(OldBkColor); 
  DC.SetBkMode(OldBkMode);
}

// Log information to assert log file
static void LogAssert(LPCSTR buff)
{
   try
   {
	CFile File;
	if (File.Open("C:\\ASSERT.LOG",CFile::modeCreate|CFile::modeNoTruncate|CFile::modeWrite|CFile::shareDenyWrite))
	{
	  File.SeekToEnd();
	  File.Write(buff,lstrlen(buff));
	  File.Close();
    }
    else
	  MessageBox(AfxGetMainWnd()->GetSafeHwnd(),buff,"GIODEBUG",MB_OK|MB_ICONERROR);
   }
   catch(...)
   {
      MessageBox(AfxGetMainWnd()->GetSafeHwnd(),buff,"GIODEBUG",MB_OK|MB_ICONERROR);
   }
}

// Show executable name, date and size
static void ShowInfoOfExecutable()
{
   WIN32_FIND_DATA data;
   char FileName[512];
   HANDLE handle;

   if (GetModuleFileName(NULL,FileName,sizeof(FileName)))
       if ((handle=FindFirstFile(FileName,&data))!=INVALID_HANDLE_VALUE)
       {
          SYSTEMTIME st;
          if (data.ftLastWriteTime.dwLowDateTime && FileTimeToSystemTime(&data.ftLastWriteTime,&st))
          {
             char buff[512];
             sprintf(buff,"Executable: %s date %u/%02u/%02u %02u:%02u%:%02u size %lu\r\n",
                           FileName,
                           st.wYear,st.wMonth,st.wDay,
                           st.wHour,st.wMinute,st.wSecond,
                           data.nFileSizeLow);
             LogAssert(buff); 
          }
          FindClose(handle);
       }
}

// This class is only used to log start and stop of program
struct StartStopAssertLog
{
    StartStopAssertLog();
   ~StartStopAssertLog();
};

// Say just once what executable is running
// The time logged here is the time of the first assertion,
// not the time of the start of the executable
StartStopAssertLog::StartStopAssertLog()
{
   CTime Time=CTime::GetCurrentTime();
   CString TimeString=Time.Format("%Y %B %d, %H:%M:%S");
   
   char buff[512];
   sprintf(buff,"\r\n\r\nNew Program Execution: %s on %s\r\n",
                    (LPCSTR)AfxGetAppName(),
                    (LPCSTR)TimeString);
   LogAssert(buff);    
   ShowInfoOfExecutable();
}

// When program terminates, if any assertion fired, say program terminated
StartStopAssertLog::~StartStopAssertLog()
{
   CTime Time=CTime::GetCurrentTime();
   CString TimeString=Time.Format("%Y %B %d, %H:%M:%S");

   char buff[512];
   sprintf(buff,"================================================================================\r\n"
                "Program Termination: %s on %s\r\n",
                    (LPCSTR)AfxGetAppName(),
                    (LPCSTR)TimeString);
   LogAssert(buff);
}

// Log assertion to file and issue warning but don't issue a message box
// Call stack trace assert if you want to
void GioAssertFailedLine(LPCSTR file, int line, LPCSTR code)
{
   static StartStopAssertLog Monitor;

   CTime Time=CTime::GetCurrentTime();
   CString TimeString=Time.Format("%Y %B %d, %H:%M:%S");
   
   char Description[1024];
   sprintf(Description,"================================================================================\r\n"
                       "ASSERTION FAILED\r\nProg : %s\r\nFile : %s\r\nLine : %i\r\nTime : %s\r\nExpr : %s\r\n",
            (LPCSTR)AfxGetAppName(),
            file?(LPCSTR)file:"?",
            (int)line,
            (LPCSTR)TimeString,
            code?(LPCSTR)code:"");

   TRACE0(Description);// Show it also on the debug trace

   try 
   { 
      static int EnableBreakpoint=1;
	  if (EnableBreakpoint) // Set EnableBreakpoint to 0 with debugger to disable breakpoint
         _asm int 3;        // Stop debugger on assertion
   } 
   catch(...)
   {
   }

   try
   {  
		CFile File;
		if (File.Open("C:\\ASSERT.LOG",CFile::modeCreate|CFile::modeNoTruncate|CFile::modeWrite|CFile::shareDenyWrite))
		{
		  File.SeekToEnd();
		  File.Write(Description,lstrlen(Description));

          // Do a stack trace, if you want to, using MFC's AfxDumpStack
		  // If you want a stack trace, just uncomment these four lines
		  // It is slow and boundschecker reports some warnings
		  // but it works
		  //CFile * pOldFile=afxDump.m_pFile;
		  //afxDump.m_pFile=&File;
          //AfxDumpStack();
          //afxDump.m_pFile=pOldFile;

		  File.Close();
        }
		else
		  MessageBox(AfxGetMainWnd()->GetSafeHwnd(),Description,"GIODEBUG",MB_OK|MB_ICONERROR); 
    }
    catch(...)
    {
        MessageBox(AfxGetMainWnd()->GetSafeHwnd(),Description,"GIODEBUG",MB_OK|MB_ICONERROR);
    }

   MessageBeep(0);
   ShowAssertWarning();
}


#endif // _DEBUG
