Better Assertions for MFC
Sample Code by Giovanni Bavestrelli

The reusable code lies in GIODEBUG.H and GIODEBUG.CPP
File SIMPLE.CPP uses it to fire some assertions

The project is for Visual C++ 6.0, but should be backward 
compatible with VC++ 5.0

You can contact me at giovanni.bavestrelli@pimini.it