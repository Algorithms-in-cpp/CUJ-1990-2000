#ifndef GIODEBUG_H
#define GIODEBUG_H


//==============================================================================
// Some debugging macros by G.Bavestrelli     Copyright Techint S.p.A. 1994-1999 
// Any feedback is welcome, you can contact me at giovanni.bavestrelli@pomini.it
//==============================================================================


/* Note:

MFC uses THIS_FILE to avoid inserting many strings with the same file name in assertions.
In all MFC sources, at the top you will find the following lines:

	#ifdef _DEBUG
	#undef THIS_FILE
	static char BASED_CODE THIS_FILE[] = __FILE__;
	#endif

If you don't do the same in your source files, you will have to replace
THIS_FILE with __FILE__ in the macros below.

*/



// Classic macro to find the size of an array
#define ARRAYSIZE(array)     (sizeof(array)/sizeof((array)[0]))                


//=============================================================================
// Assertion macros
//=============================================================================

// Undefine the standard MFC assertion macros
#undef  ASSERT
#undef  VERIFY


#ifdef _DEBUG
  // My assertion routine
  void    GioAssertFailedLine(LPCSTR file, int line, LPCSTR expression);

  // Main assert macros
  #define ASSERT(v)     (!(v) && (GioAssertFailedLine(THIS_FILE,__LINE__,#v),0))
  #define VERIFY(v)     ASSERT(v)
  #define SAFE(v)       (ASSERT(v),(v))

  // Secondary assert macros
  #define ASSERT_ONCE(v)         { static int k=0; (!(v) && !k++ && (GioAssertFailedLine(THIS_FILE,__LINE__,#v),0));}
  #define ASSERT_LEN(str)        ASSERT((str) && lstrlen(str)<sizeof(str))
  #define ASSERT_ARRAYINDEX(a,i) ASSERT((i)>=0 && (i)<ARRAYSIZE(a))
#else
  // Main assert macros in release mode disappear
  #define ASSERT(v)     ((void)(0))
  #define VERIFY(v)     ((void)(v))
  #define SAFE(v)       (v)

  // Secondary assert macros in release mode disappear
  #define ASSERT_ONCE(x)         {}
  #define ASSERT_LEN(str)        ((void)(0))
  #define ASSERT_ARRAYINDEX(a,i) ((void)(0))
#endif


#endif // GIODEBUG_H
