
#if !defined(AFX_SIMPLE_H)
#define AFX_SIMPLE_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#endif // !defined(AFX_SIMPLE_H__8A5DCC97_E104_11D2_8EF1_00805F850368__INCLUDED_)
