//Listing 2
#include <iostream>
#include <fstream>
#include <iterator>

using namespace std;
#include "crc.h"

int main( int argc, char* argv[] )
 {
 if( argc < 2 )
  {
  cerr << "Usage: CRC16 file1 file2...\n";
  return 1;
  }
 typedef cdm_crc::CRCGenerator<16, 0x8005, 0, 0, true> CRC16;
 CRC16 crc16;
 cout.setf( ios_base::hex, ios_base::basefield );
 cout.setf( ios_base::showbase );
 for( int i = 1; i < argc; i++ )
  {
  ifstream infile( argv[i] );
  infile.unsetf( ios_base::skipws );
  if( !infile )
   {
   cerr << "Error: unable to open " << argv[i] << '\n';
   continue;
   }
  crc16.Process( istream_iterator<unsigned char>( infile ),
   istream_iterator<unsigned char>() );
  unsigned long ncrcVal = crc16.GetNormalCRC();
  ncrcVal >>= (cdm_crc::CRCMaxBits-crc16.GetWidth() );
  cout << "File: " << argv[i] << '\t' << 
   "CRC-16 checksum: " << ncrcVal << '\n';
  }
 return 0;
 }
