// SampleClient.h : main header file for the SAMPLECLIENT application
//

#if !defined(AFX_SAMPLECLIENT_H__48383006_9EA5_11D2_B6F6_14A5F9C00000__INCLUDED_)
#define AFX_SAMPLECLIENT_H__48383006_9EA5_11D2_B6F6_14A5F9C00000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSampleClientApp:
// See SampleClient.cpp for the implementation of this class
//

class CSampleClientApp : public CWinApp
{
public:
	CSampleClientApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSampleClientApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSampleClientApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAMPLECLIENT_H__48383006_9EA5_11D2_B6F6_14A5F9C00000__INCLUDED_)
