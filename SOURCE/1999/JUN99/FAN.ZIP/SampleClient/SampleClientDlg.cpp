// SampleClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SampleClient.h"
//Customerized Code
#include "..\LoadBal\LoadBal.h"
#include "..\svrCompName\svrCompName.h"
//end of Customerized Code
#include "SampleClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//Customerized code
const IID IID_IObjMill = {0xF3460EEF,0x94D7,0x11D2,{0xB6,0xF6,0x00,0xC0,0x4F,0xEF,0x2F,0x84}};
const CLSID CLSID_ObjMill = {0xF3460EF0,0x94D7,0x11D2,{0xB6,0xF6,0x00,0xC0,0x4F,0xEF,0x2F,0x84}};
const IID IID_ICompName = {0x345894CF,0x9E92,0x11D2,{0xB6,0xF6,0x14,0xA5,0xF9,0xC0,0x00,0x00}};
const CLSID CLSID_CompName = {0x345894D0,0x9E92,0x11D2,{0xB6,0xF6,0x14,0xA5,0xF9,0xC0,0x00,0x00}};

//End customerized code

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSampleClientDlg dialog

CSampleClientDlg::CSampleClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSampleClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSampleClientDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSampleClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSampleClientDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSampleClientDlg, CDialog)
	//{{AFX_MSG_MAP(CSampleClientDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSampleClientDlg message handlers

BOOL CSampleClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//create the ObjMill server
	HRESULT hr;
	IObjMill* pObjMill = NULL;
	ICompName* pCompName = NULL;
	IUnknown* pIUnknown = NULL;

	BSTR bstrProgId = CString("CompName.CompName.1").AllocSysString();
	BSTR bstrMachineName;
	MULTI_QI qi = {&IID_IObjMill, NULL, 0};
	CWnd* pText = GetDlgItem(IDC_MACHINENAME);
	ASSERT(pText);

	COSERVERINFO serverinfo;
	COSERVERINFO* pServerInfo;

	serverinfo.dwReserved1 = 0;
	serverinfo.dwReserved2 = 0;
	serverinfo.pwszName = CString("ausadfred").AllocSysString();
	serverinfo.pAuthInfo = NULL;

	pServerInfo = &serverinfo;

	hr = CoCreateInstanceEx(CLSID_ObjMill, NULL, CLSCTX_ALL, pServerInfo, 1, &qi);
	
	if (!(SUCCEEDED(hr) && SUCCEEDED(qi.hr))) {
		//something is wrong
		return FALSE;
	}

//	pCompName = (ICompName*)qi.pItf;
	pObjMill = (IObjMill*)qi.pItf;
	if (pObjMill) {
		hr = pObjMill->CreateObject(bstrProgId, &pIUnknown);
		if (SUCCEEDED(hr)) {
			if (pIUnknown) {
				hr = pIUnknown->QueryInterface(IID_ICompName, (void**)&pCompName);
				if (SUCCEEDED(hr)) {
					pCompName->Name(&bstrMachineName);
					//set text
					pText->SetWindowText(CString(bstrMachineName));
				}
			}
		}
	}

	::SysFreeString(bstrMachineName);
	::SysFreeString(bstrProgId);
	if (pCompName) {
		pCompName->Release();
	}
	if (pObjMill) {
		pObjMill->Release();
	}

	if (pIUnknown) {
		pIUnknown->Release();
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSampleClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSampleClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSampleClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
