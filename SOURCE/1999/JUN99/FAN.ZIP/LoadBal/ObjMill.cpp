// ObjMill.cpp : Implementation of CObjMill
#include "stdafx.h"
#include "LoadBal.h"
#include "ObjMill.h"
#include <stdio.h>
/////////////////////////////////////////////////////////////////////////////
// CObjMill


STDMETHODIMP CObjMill::CreateObject(BSTR szProgID, IUnknown * * ppRetObj)
{
	// TODO: Add your implementation code here
	HRESULT hr;
	
	hr = CObjMill::CreateObjectAt(szProgID, 
							CObjMill::m_SvrInfo[CObjMill::m_nCurrentMachine].wstrName, 
							ppRetObj);

	WaitForSingleObject(CObjMill::m_hMutex, INFINITE);
	CObjMill::m_nCurrentMachine = (CObjMill::m_nCurrentMachine + 1) 
									% CObjMill::m_nCount;
	ReleaseMutex(CObjMill::m_hMutex);
	return hr;
}

/////////////////////////////////////////////////////////////////////////////
// Customerized Code Here
BOOL CObjMill::StartUp()
{
	FILE* lpFile;

	TCHAR szInitFile[_MAX_PATH];
	DWORD dwFileNameLen = _MAX_PATH;

	//get number of machines in the cluster &
	// init file location from the registry
	CRegKey key;
	LONG lRes = key.Open(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LoadBal"), KEY_READ);
	if (lRes != ERROR_SUCCESS) {
		_Module.LogEvent("Registry key HKEY_LOCAL_MACHINE\\SOFTWARE\\LoadBal can not be found\n");
		return FALSE;
	}

	if (ERROR_SUCCESS != key.QueryValue(CObjMill::m_nCount, _T("NumOfMachines"))) {
		_Module.LogEvent("Registry key HKEY_LOCAL_MACHINE\\SOFTWARE\\LoadBal\\NumOfMachines can not be found\n");
		return FALSE;
	};

	if (ERROR_SUCCESS != key.QueryValue(szInitFile, _T("InitFileName"), &dwFileNameLen)) {
		_Module.LogEvent("Registry key HKEY_LOCAL_MACHINE\\SOFTWARE\\LoadBal\\InitFileName can not be found\n");
		return FALSE;
	};

	CObjMill::m_hMutex = CreateMutex(NULL, FALSE, NULL);

	//fills up m_SvrInfo
	lpFile = fopen((const char*)szInitFile, "r");	
	
	if (NULL == lpFile) {
		//file not found...startup failed...
		//log event
		_Module.LogEvent("could not find LoadBal.ini file\n");
		return FALSE;
	}

	for (unsigned int i = 0; i < CObjMill::m_nCount; i++) {
		fscanf(lpFile, "%s\n", &CObjMill::m_SvrInfo[i].wstrName);
	}

	fclose(lpFile);

	return TRUE;
}

BOOL CObjMill::CleanUp()
{
	CloseHandle(CObjMill::m_hMutex);
	return TRUE;
}

HRESULT CObjMill::CreateObjectAt(LPCWSTR lpProgId, char* SvrName, IUnknown** pRetObj)
{
	char szMachineName[_MAX_PATH];
	CLSID clsid;
	unsigned long ulSize = sizeof(szMachineName);

	if (NULL == SvrName) {
		//if no svr name is specified, use the current machine
		GetComputerName((char*)szMachineName, &ulSize);
	} else {
		strcpy(szMachineName, SvrName);
	}
	
	HRESULT hr;
	//get CSLID
	hr = CLSIDFromProgID((const unsigned short*)lpProgId, &clsid);

	//create object

	USES_CONVERSION;

	IID IID_IUnknown;
	TCHAR szIID[_MAX_PATH] = _T("{00000000-0000-0000-C000-000000000046}");

	BSTR bstrIID = ::SysAllocString(T2OLE(szIID));

	IIDFromString(bstrIID, &IID_IUnknown);
	::SysFreeString(bstrIID);
	
	COSERVERINFO serverinfo;
	COSERVERINFO* pServerInfo;
	MULTI_QI qi = {&IID_IUnknown, NULL, 0};
	
	serverinfo.dwReserved1 = 0;
	serverinfo.dwReserved2 = 0;
	serverinfo.pwszName = ::SysAllocString(T2OLE(szMachineName));
	serverinfo.pAuthInfo = NULL;

	pServerInfo = &serverinfo;

	hr = CoCreateInstanceEx(clsid, 
							NULL, 
							CLSCTX_INPROC_SERVER | CLSCTX_INPROC_HANDLER | CLSCTX_LOCAL_SERVER | CLSCTX_REMOTE_SERVER,
							pServerInfo,
							1,
							&qi);
	if (SUCCEEDED(hr) && SUCCEEDED(qi.hr)) {
		*pRetObj = (IUnknown*)qi.pItf;
	} 
	hr = CoRevertToSelf();
	::SysFreeString(serverinfo.pwszName);
	return hr;
}

HANDLE CObjMill::m_hMutex = NULL;
unsigned long CObjMill::m_nCount = 0;
int CObjMill::m_nCurrentMachine = 0;
CObjMill::SERVER_INFO CObjMill::m_SvrInfo[] = 
{{NULL}, {NULL}, {NULL}, {NULL}, 
{NULL}, {NULL}, {NULL}, {NULL}};
