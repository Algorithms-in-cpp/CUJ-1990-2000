// ObjMill.h : Declaration of the CObjMill

#ifndef __OBJMILL_H_
#define __OBJMILL_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CObjMill
class ATL_NO_VTABLE CObjMill : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CObjMill, &CLSID_ObjMill>,
	public IDispatchImpl<IObjMill, &IID_IObjMill, &LIBID_LOADBALLib>
{
public:
	CObjMill()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_OBJMILL)

BEGIN_COM_MAP(CObjMill)
	COM_INTERFACE_ENTRY(IObjMill)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IObjMill
public:
	STDMETHOD(CreateObject)(/*[in]*/ BSTR szProgID, /*[out, retval]*/ IUnknown** ppRetObj);

// modified code here
public:
	static BOOL StartUp();
	static BOOL CleanUp();
private:
	struct SERVER_INFO {
		char wstrName[_MAX_PATH];
	};

	static HRESULT CreateObjectAt(LPCWSTR ProgId, char* SvrName, IUnknown** pRetObj);

	static SERVER_INFO m_SvrInfo[8];
	static unsigned long m_nCount;
	static int m_nCurrentMachine;
	static HANDLE m_hMutex;
};

#endif //__OBJMILL_H_
