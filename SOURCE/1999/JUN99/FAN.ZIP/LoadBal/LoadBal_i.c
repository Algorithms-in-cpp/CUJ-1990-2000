/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Sun Jan 03 11:10:42 1999
 */
/* Compiler settings for LoadBal.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IObjMill = {0xF3460EEF,0x94D7,0x11D2,{0xB6,0xF6,0x00,0xC0,0x4F,0xEF,0x2F,0x84}};


const IID LIBID_LOADBALLib = {0xF3460EE2,0x94D7,0x11D2,{0xB6,0xF6,0x00,0xC0,0x4F,0xEF,0x2F,0x84}};


const CLSID CLSID_ObjMill = {0xF3460EF0,0x94D7,0x11D2,{0xB6,0xF6,0x00,0xC0,0x4F,0xEF,0x2F,0x84}};


#ifdef __cplusplus
}
#endif

