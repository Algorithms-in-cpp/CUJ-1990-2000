// CompName.h : Declaration of the CCompName

#ifndef __COMPNAME_H_
#define __COMPNAME_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCompName
class ATL_NO_VTABLE CCompName : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCompName, &CLSID_CompName>,
	public IDispatchImpl<ICompName, &IID_ICompName, &LIBID_SVRCOMPNAMELib>
{
public:
	CCompName()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_COMPNAME)

BEGIN_COM_MAP(CCompName)
	COM_INTERFACE_ENTRY(ICompName)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ICompName
public:
	STDMETHOD(Name)(/*[out, retval]*/ BSTR* szComputerName);
};

#endif //__COMPNAME_H_
