/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Tue Dec 29 11:24:21 1998
 */
/* Compiler settings for svrCompName.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ICompName = {0x345894CF,0x9E92,0x11D2,{0xB6,0xF6,0x14,0xA5,0xF9,0xC0,0x00,0x00}};


const IID LIBID_SVRCOMPNAMELib = {0x345894C2,0x9E92,0x11D2,{0xB6,0xF6,0x14,0xA5,0xF9,0xC0,0x00,0x00}};


const CLSID CLSID_CompName = {0x345894D0,0x9E92,0x11D2,{0xB6,0xF6,0x14,0xA5,0xF9,0xC0,0x00,0x00}};


#ifdef __cplusplus
}
#endif

