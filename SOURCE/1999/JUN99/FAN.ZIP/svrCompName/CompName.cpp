// CompName.cpp : Implementation of CCompName
#include "stdafx.h"
#include "svrCompName.h"
#include "CompName.h"

/////////////////////////////////////////////////////////////////////////////
// CCompName


STDMETHODIMP CCompName::Name(BSTR * ComputerName)
{
	// TODO: Add your implementation code here
	TCHAR szMachineName[_MAX_PATH];
	DWORD dwSize = sizeof(szMachineName);

	USES_CONVERSION;
	if (FALSE == GetComputerName(szMachineName, &dwSize)) {
		return E_UNEXPECTED;
	};
	
	*ComputerName = ::SysAllocString(T2OLE(szMachineName));

	if (NULL == *ComputerName) {
		return E_OUTOFMEMORY;
	}
	return S_OK;
}
