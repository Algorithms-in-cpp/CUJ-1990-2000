// Global buffer of internal interrupt events
unsigned long event [NUM_EVENTS];
unsigned long eventCount = 0;

// Externally generated count of events
extern unsigned long externEventCounter;

// Interrupt being debugged
void myAsyncInterrupt ()
{
    // Save the external event counter
    event [eventCount] = externEventCounter;

    // Roll over the event counter as needed
    if (NUM_EVENTS == ++eventCount)
        eventCount = 0;

    // Regular interrupt processing
    ...
}


bool debugEvents = true;

// Regular task code for debugging the interrupt
Void myEventDebugCode()
{
    unsigned short localCount = 0;
    // Flag the first event by setting the last event to 0
    unsigned long lastEvent = 0;

    // Busy wait for a new event
    while (debugEvents) {
        // Check for a new event
        if (eventCount != localCount) {
            // Save the new event early
            unsigned long newEvent = event[localCount];

            // Only publish if we found something unexpected
            if(lastEvent +1 != newEvent && 0 != lastEvent)
                publish ("%d event expected, found %d\n",
                    lastEvent + 1, newEvent);
            lastEvent = newEvent;

            // Roll over the event counter as needed
            if (NUM_EVENTS == ++localCount)
                localCount = 0;
        }
    }
}

