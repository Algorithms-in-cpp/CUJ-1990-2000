// Const BSS in ROM: 
static const char sccsid[] = 
    "Example1.cc Copyright XYZ, 1999";
const double PI = 3.14159265359;

// Non-const BSS in RAM:
char myBuffer[64] = "";
int testValue = 127;

// Uninitialized DATA in RAM:
char bigBuffer[512];
unsigned long loopCount;

// TEXT in ROM:
double myPolar (double x)
{
    // Variable on stack in RAM:
    const double xSqr = x * x;

    return xSqr / log (x);
}
