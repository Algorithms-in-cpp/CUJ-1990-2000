// The GPIO Data Direction Register (1 = output, 0 = input)
volatile unsigned short* GPIO_DDR = 
    (volatile unsigned short*) 0x400102;
// The GPIO output control (1 = high, 0 = low)
volatile unsigned short* GPIO = 
    (volatile unsigned short*) 0x400104;
// The bit that controls the status LED output
const unsigned short STATUS_LED = 0x0040;

void myCodeToInstrument ()
{
    // Make the status LED GPIO line an output
    // Not necessary if the GPIO line is already configured
    *GPIO_DDR |= STATUS_LED;

    // Create the beginning two LED output edges
    // (LED on then LED off or LED off then LED on)
    *GPIO ^= STATUS_LED;
    *GPIO ^= STATUS_LED;

    // A block of interesting code
    {
        ...
    }

    // Create another LED output edge
    *GPIO ^= STATUS_LED;

    // A second block of interesting code
    {
        ...
    }

    // Create another LED output edge
    *GPIO ^= STATUS_LED;

    // A third block of interesting code
    {
        ...
    }

    // Create another LED output edge
    *GPIO ^= STATUS_LED;

    // The last block of interesting code
    {
        ...
    }

    // Create the final two LED output edges
    *GPIO ^= STATUS_LED;
    *GPIO ^= STATUS_LED;
}

