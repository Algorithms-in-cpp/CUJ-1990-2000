// RAM-based variables (upperLimit can be changed at run time) 
bool breakPointC = false;
int upperLimit = 5000;

// ROM-based code
void myAffectedFunction ()
{
    int partialResult = 0;

    // Some unaffected code that modifies partialResult
    ...

    // Now check for the intermittent bug.
    if (breakPointC && upperLimit < partialResult)
        RamBreakFunction (BrkPointC);

    // Rest of myAffectedFunction()
    ...
}
