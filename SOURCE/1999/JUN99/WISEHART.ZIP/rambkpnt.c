enum BrkPoints
{
    BrkPointA,
    BrkPointB,
    BrkPointC,
    ...
};

// RAM based variables
bool breakPointA = false;
bool breakPointB = false;

// RAM based code
void RamBreakFunction (BrkPoints brk)
{
// Set breakpoint here.
    switch (brk) {
        case BrkPointA:
            breakPointA = false;
            break;
        case BrkPointB:
            breakPointB = false;
            break;
// etc.
}
}

// ROM based code
void mySuspectFunction()
{
    if (breakPointA)
        RamBreakFunction (BrkPointA);
 
// More mySuspectFunction() code
    ...

    if (breakPointB)
        RamBreakFunction (BrkPointB);

// Rest of mySuspectFunction()
    ...
}

