// Use of global storage is fine
extern unsigned char checkChar (unsigned char); 
unsigned char myBuffer [2048], result [2048]; 
int intCount = 0;

void myInterruptToDebug (void)
{
    // Do not do this in an interrupt
    unsigned char myStackBuffer [2048];

    // Mutex give may be fine and can be a good way to notify
    // a debugging task of new activity
    mutex_give (&myMutex);

    // But mutex take may block and should not be used
    mutex_take (&myMutex, timeout);

    // sprintf() should be avoided because it is often slow 
    // and large
    sprintf (myBuffer, "Just entered myInterupt (%d).\n",
        ++intCount);

    // Do not do this in an interrupt-it takes too long.
    // Instead, wake up a regular task to do this processing.
    for (int i=0; i<10000; ++i)
        result[i] = checkChar (&myStackBuffer[i]);

    // Stay away from these if at all possible.
    IntLock();
    TaskLock();
    ...
    TaskUnlock();
    IntUnlock();

    // Check your OS manual for further interrupt limitations
}

