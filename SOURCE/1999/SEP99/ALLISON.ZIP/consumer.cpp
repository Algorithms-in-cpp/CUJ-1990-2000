// consumer.cpp: Illustrates a protected 
// resource
#include <iostream>

class Resource
{
    friend class Consumer;
private:
    Resource() {}
};

class Consumer
{
public:
    Consumer()
    {
        pRes = new Resource();
    }
    ~Consumer()
    {
        delete pRes;
    }
private:
    Resource* pRes;
};

int main()
{
    Consumer c;
    std::cout << "Consumer created\n";
}

/* Output:
Consumer created
*/
