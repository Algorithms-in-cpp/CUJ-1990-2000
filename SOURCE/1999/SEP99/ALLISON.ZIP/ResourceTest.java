// ResourceTest.java
class ResourceTest {
    public static void main(String[] args) {
        Consumer c = new Consumer();
        System.out.println("Consumer created");
    }
}

class Resource {
    Resource() {}
}

class Consumer
{
    public Consumer() {
        res = new Resource();
    }
    private Resource res;
};

