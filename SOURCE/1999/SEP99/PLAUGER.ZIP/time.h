#define CLOCKS_PER_SEC <integer constant expression >; 
#define NULL <either 0, 0L, or (void *)0>; [0 in C++]
     
typedef a-type clock_t;
typedef ui-type size_t;
typedef a-type time_t;
struct tm {
    int tm_sec;        seconds after the minute (from 0) 
    int tm_min;        minutes after the hour (from 0) 
    int tm_hour;       hour of the day (from 0)
    int tm_mday;       day of the month (from 1) 
    int tm_mon;        month of the year (from 0) 
    int tm_year;       years since 1900 (from 0) 
    int tm_wday;       days since Sunday (from 0) 
    int tm_yday;       day of the year (from 0) 
    int tm_isdst;      Daylight Saving Time flag 
    };
     
char *asctime(const struct tm *tptr); 
clock_t clock(void);
char *ctime(const time_t *tod);
double difftime(time_t t1, time_t t0); 
struct tm *gmtime(const time_t *tod); 
struct tm *localtime(const time_t *tod); 
time_t mktime(struct tm *tptr);
size_t strftime(char *s, size_t n, const char *format,
    const struct tm *tptr);
time_t time(time_t *tod);
