/*
  conapp.cpp  Win32 Console Application Class Library
  Copyright (C) 1998, Stan Mitchell

  Permission is granted to use this code without restriction 
  as long as this copyright notice appears in all source files.
*/

#include "conapp.h"
#include <iostream>
#include <algorithm>
using namespace std;

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "conres.h"

//
//  Splits the full path name for the module into its
//   component parts.
//
CModule::CModule()
{
    _TCHAR szFullPath[MAX_PATH], drive[_MAX_DRIVE],
           dir[_MAX_DIR], fname[_MAX_FNAME], ext[_MAX_EXT];

    if ( !GetModuleFileName( NULL, szFullPath, MAX_PATH ) )
    {
        DWORD errorcode = GetLastError();

        // Calling GetModuleFilenameW on Win9x platform?
        if ( errorcode == ERROR_CALL_NOT_IMPLEMENTED )
        {
            char lpBuffer[ 256 ];

            // Since the Unicode function failed we have
            //   to force the use of ANSI here
            LoadStringA( GetModuleHandleA(NULL),
                         IDS_OS_NOT_UNICODE,
                         lpBuffer,
                         sizeof( lpBuffer ) );

            fprintf( stderr, lpBuffer );
            exit( -1 );
        }
    }

    m_strProgramFullPath = szFullPath;
    if ( !m_strProgramFullPath.empty() )
    {
        _tsplitpath( szFullPath, drive, dir, fname, ext );    
        m_strProgramDir  =   drive;
        m_strProgramDir  +=  dir;
        m_strProgramName =   fname;
        m_strProgramName +=  ext;
        m_strBaseName    =   fname;
    }
}


//
// Parses the application command line into a 'list'
//  of CCmdArg tokens, the class member, 'arglist'.
//  'arglist' will be empty if the application does
//  have any command line arguments.
//
void 
CConsoleApp::ParseCmdline()
{
    LPTSTR pCmd = GetCommandLine();
    tstring cmdline = pCmd;
    tstring cmdarg;
    bool bFirstArg = true;

    tstring::size_type pos = 0;
    tstring::size_type pos_start = 0;
    tstring::size_type pos_end = cmdline.size();
    
    while( pos < pos_end )
    {
        if ( cmdline[pos] == _T(' ') || 
             cmdline[pos] == _T('\t')  )
        {
            cmdarg = cmdline.substr( pos_start, pos-pos_start );

            if ( bFirstArg ) bFirstArg = false;
            else AddToArglist( cmdarg );

            pos = pos_start = SkipWhitespace( cmdline, pos );
            continue;
        }

        else if ( cmdline[pos] == _T('\"') )
        {
            tstring::size_type look_ahead;
            look_ahead = cmdline.find_first_of( _T("\""), pos+1 );
            if ( look_ahead != tstring::npos && !bFirstArg )
            {
                cmdarg = cmdline.substr( pos_start, look_ahead-pos_start+1 );
                AddToArglist( cmdarg );
                pos = pos_start = SkipWhitespace( cmdline, ++look_ahead );
                continue;
            }
        }

        pos++;
    }

    if ( pos > pos_start && !bFirstArg )
    {
        cmdarg = cmdline.substr( pos_start, pos-pos_start );
        AddToArglist( cmdarg );
    }
}

// Skip ahead past whitespace
tstring::size_type
CConsoleApp::SkipWhitespace( tstring& cmdline,
                              tstring::size_type& pos )
{
    while ( cmdline[pos] == _T(' ') || 
            cmdline[pos] == _T('\t')  ) pos++;
    return pos;
}

// Given a tstring, construct a CCmdArg for it,
//   and add it to arglist
void
CConsoleApp::AddToArglist( tstring& cmdarg )
{
    // Create a CCmdArg object for each command line token
    //   and add them to the tail end of 'arglist'

    if ( cmdarg[0] == _T('-') || cmdarg[0] == _T('/') )
    {
        tstring::size_type pos = 0;
        pos = cmdarg.find_first_of( _T(':'), pos );
        if ( pos != tstring::npos )
        {
            tstring opt = cmdarg.substr( 1, pos-1 );
            tstring val = cmdarg.substr( pos+1 );
            CCmdArg carg( CCmdArg::CmdOption, opt, val );
            arglist.push_back( carg );
        }
        else
        {
            CCmdArg carg( CCmdArg::CmdSwitch, cmdarg.substr(1) );
            arglist.push_back( carg );
        }
    }
    else
    {
        CCmdArg carg( CCmdArg::CmdString, cmdarg );
        arglist.push_back( carg );
    }
}

//
//  Search 'arglist' for a specified switch name.
//
//  If found, 
//      - if remove_switch is true,
//          remove the CCmdArg object from 'arglist'
//      - set 'flag' to true
//      - return true.
//
//  Else
//      - flag remains unchanged
//      - return false.
//
bool 
CConsoleApp::GetSwitch( 
    bool& flag, 
    const tstring& swname,
    bool remove_switch
    )
{
    bool result = TestSwitch( swname, remove_switch );
    if ( result ) flag = true;
    return result;
}


//
//  Search 'arglist' for a specified switch name.
//
//  If found, 
//      - if remove_switch is true,
//          remove the CCmdArg object from 'arglist' 
//      - return true.
//
//  Else
//      - return false.
//
bool 
CConsoleApp::TestSwitch( 
    const tstring& swname,
    bool remove_switch
    )
{
    // iterators for traversing the argument list
    list<CCmdArg>::iterator iter_begin = arglist.begin();
    list<CCmdArg>::iterator iter_end = arglist.end();
    list<CCmdArg>::iterator iter;

    iter = find_if( iter_begin, iter_end,
        EqualArg( CCmdArg( CCmdArg::CmdSwitch, swname ) ) 
        );

    if ( iter != iter_end ) 
    {
        if ( remove_switch )
            arglist.erase( iter ); // remove the argument from the list
        return true;
    }

    return false;
}


//
//  Search 'arglist' for a specified option name.
//
//  If found, 
//      - if remove_option is true,
//          remove the CCmdArg object from 'arglist' 
//      - set 'flag' to true
//      - set 'optval' to the option's value
//      - return true.
//
//  Else
//      - return false.
//
bool 
CConsoleApp::GetOption( 
    bool& flag, 
    const tstring& optname,
    tstring& optval,
    bool remove_option
    )
{
    // iterators for traversing the argument list
    list<CCmdArg>::iterator iter_begin = arglist.begin();
    list<CCmdArg>::iterator iter_end = arglist.end();
    list<CCmdArg>::iterator iter;

    iter = find_if( iter_begin, iter_end,
        EqualArg( CCmdArg( CCmdArg::CmdOption, optname ) ) 
        );

    if ( iter != iter_end ) 
    {
        flag = true; // set the corresponding flag
        optval = (*iter).GetOptionValue();
        if ( remove_option )
            arglist.erase( iter ); // remove the argument from the list
        return true;
    }

    return false;
}


//
//  Get the first occurrence of a CmdString in 'arglist'.
// 
//  If found, 
//      - if remove_string is true,
//          remove the CCmdArg object from 'arglist' 
//      - assign the string in the CCmdArg to strValue
//      - return true.
//
//  Else
//      - return false.
//
bool 
CConsoleApp::GetString( tstring& strValue,
                        bool remove_string )
{
    // iterators for traversing the argument list
    list<CCmdArg>::iterator iter_begin = arglist.begin();
    list<CCmdArg>::iterator iter_end = arglist.end();
    list<CCmdArg>::iterator iter;

    iter = find_if( iter_begin, iter_end,
        EqualType( CCmdArg( CCmdArg::CmdString, tstring(_T("")) ) ) 
        );

    if ( iter != iter_end ) 
    {
        strValue = (*iter).GetString();
        if ( remove_string )
            arglist.erase( iter ); // remove the argument from the list
        return true;
    }

    return false;
}


void 
CConsoleApp::DumpArglist( void )
{
    // iterators for traversing the argument list
    list<CCmdArg>::iterator iter_begin = arglist.begin();
    list<CCmdArg>::iterator iter_end = arglist.end();
    list<CCmdArg>::iterator iter = iter_begin;

    while ( iter != iter_end ) 
    {
        tcout << " (" << (*iter).GetType() << ")"
              << (*iter).GetPart1();

        if ( (*iter).IsOption() )
            tcout << ":" << (*iter).GetOptionValue();

        iter++;
    }

    tcout << endl;
}    


//
// The following functions will have overrides in the application's
//  derived class
//

// initialization which completes before main() is called
bool CConsoleApp::init()   { return true; }

// the primary routine of the application
void CConsoleApp::main()    { }

// stuff done before the program exits
void CConsoleApp::deinit()  { } 

// emits output showing program usage
void CConsoleApp::usage()   { }

//
//  This is standard application entry point for every console app.
//  It is a friend function of the 'App' object.
//
extern "C" int __cdecl _tmain( int argc, _TCHAR* argv[] )
{
    CConsoleApp *pConApp = GetConApp();

    // Build 'arglist' from the command line
    pConApp->ParseCmdline();

    // Do initializations
    if ( !pConApp->init() )
    {
        if ( pConApp->m_ShowUsage ) pConApp->usage();
        return pConApp->m_ExitCode;
    }

    // Main function of the application
    pConApp->main();

    // Do cleanup before exit
    pConApp->deinit();

    return pConApp->m_ExitCode;
}
