/*
  conapp.h  Win32 Console Application Class Library
  Copyright (C) 1998, Stan Mitchell

  Permission is granted to use this code without restriction 
  as long as this copyright notice appears in all source files.
*/

#ifndef conapp_h
#define conapp_h

#ifdef  _MBCS
#undef  _MBCS   // enforce SBCS
#endif

#include <tchar.h>
#include <string>
#include <list>
using namespace std;

#ifdef _UNICODE
#ifndef  UNICODE
#define  UNICODE    1
#endif
#define  tcout      wcout
#define  tcerr      wcerr
#define  tstring    wstring
#else
#undef   UNICODE
#define  tcout      cout
#define  tcerr      cerr
#define  tstring    string
#endif


// Class CModule
// -------------
//
//  Encapsulates features of a Win32 module.
//
//  Todo:  hInstance
//         enforcement of single instance
// 
class CModule
{
    tstring m_strProgramFullPath;
    tstring m_strProgramDir;
    tstring m_strProgramName;
    tstring m_strBaseName;
public:
    const tstring GetProgramFullPath() { return m_strProgramFullPath; }
    const tstring GetProgramName()     { return m_strProgramName; } // file.ext
    const tstring GetProgramDir()      { return m_strProgramDir; }
    const tstring GetProgramBaseName() { return m_strBaseName; }
    CModule();
    ~CModule() { }
};

// Class CCmdArg
// -------------
//
// Class which represents the individual tokens which make
//  up the application's command line. The commmand line is 
//  parsed into arguments of three types: 
//           switches, options, and strings.
//
// A switch is a character or string immediately preceded
//  by '-' or '/'. The switch character is discarded before
//  the switch character or string is stored.
//
// An option is a string value which accompanies a switch
//  but is delimited by a ':'. For example, -a:23, is an
//  option, with 'a' as the switch character, and '23' as
//  the value.
//
// A string is any other token delimited by whitespace. It
//  might be a filename, path, etc. A quoted string may
//  contain whitespace.
//
class CCmdArg
{
  public:
    enum ArgType { CmdSwitch=1, CmdOption, CmdString };

    bool IsSwitch() { return m_type == CmdSwitch; }
    bool IsOption() { return m_type == CmdOption; }
    bool IsString() { return m_type == CmdString; }
    const ArgType&  GetType()        { return m_type;  }
    const tstring&  GetPart1()       { return m_part1; }
    const tstring&  GetSwitch()      { return m_part1; }
    const tstring&  GetOptionName()  { return m_part1; }
    const tstring&  GetOptionValue() { return m_part2; }
    const tstring&  GetString()      { return m_part1; }

    // Constructor which takes a single string and a type
    CCmdArg( ArgType t, const tstring& str1 ):
        m_type(t), m_part1(str1) {}

    // Constructor which takes two strings and a type
    CCmdArg( ArgType t, const tstring& str1, const tstring& str2 ):
        m_type(t), m_part1(str1), m_part2(str2) {}

    ~CCmdArg() { }

  private:
    ArgType  m_type;
    tstring  m_part1;
    tstring  m_part2;
};


// Class EqualArg
// --------------
//
//  Function object used for CCmdArg comparison
//
class EqualArg
{
public:
    EqualArg( CCmdArg arg ) : _arg(arg) {}
    bool operator()( CCmdArg& a1 )
    {
        return ( a1.GetType() == _arg.GetType() ) && 
               ( a1.GetPart1() == _arg.GetPart1() );
    }
private:
    CCmdArg  _arg;
};

// Class EqualType
// ---------------
//
//  Function object used for CCmdArg comparison
//
class EqualType
{
public:
    EqualType( CCmdArg arg ) : _arg(arg) {}
    bool operator()( CCmdArg& a1 )
    {
        return ( a1.GetType() == _arg.GetType() );
    }
private:
    CCmdArg  _arg;
};


extern "C" int __cdecl _tmain( int argc, _TCHAR* argv[] );

// Class CConsoleApp
// -----------------
//
// Class which represents a Win32 console application.
//
class CConsoleApp : public CModule
{
    int  m_ExitCode;  // application's exit code
    bool m_ShowUsage; // if true, usage() is called if init() fails

    friend int _tmain(int argc, _TCHAR* argv[]);   // standard app entry
    void ParseCmdline();            // executes before init() is called
    void AddToArglist( tstring& cmdarg );
    tstring::size_type SkipWhitespace( tstring& cmdline,
                                        tstring::size_type& pos );

protected:
    // Class members which user overrides
    virtual bool init();    // initialization which completes before main() is called
    virtual void main();    // the primary routine of the application
    virtual void deinit();  // stuff done before the program exits
    virtual void usage();   // emits output showing program usage

    list< CCmdArg >  arglist; // list of command line arguments
                              // in the order they are encountered
public:
    CConsoleApp() 
    { 
        m_ExitCode = 0;
        m_ShowUsage = true; // enable usage display if init() returns false
    }

    ~CConsoleApp() { }

    // Allow application to control display of usage screen
    void SetUsageFlag( bool enable ) { m_ShowUsage = enable; }

    // Set application's exit code
    void SetExitCode( int exitcode ) { m_ExitCode = exitcode; }

    // Look for a switch in 'arglist', if found set flag true,
    //   and if remove_switch is true, remove the CCmdArg from 'arglist'
    bool GetSwitch( bool& flag, const tstring& swname, bool remove_switch );

    // Look for a switch in 'arglist', if found return true,
    //   and if remove_switch is true, remove the CCmdArg from 'arglist'
    bool TestSwitch( const tstring& swname, bool remove_switch );

    // Look for an option in 'arglist', if found set flag true,
    //   get the option value to 'optval', 
    //   and if remove_option is true, remove the CCmdArg from 'arglist'
    bool GetOption( bool& flag, const tstring& optname, tstring& optval, bool remove_option );

    // Retrieve the next CmdString from the 'arglist',
    //    returns true if one is found, and the item is removed if remove_string is true
    bool GetString( tstring& strValue, bool remove_string );

    // Dumps the arglist to stdout
    void DumpArglist( void );

};

// This inline function is defined by each application
extern CConsoleApp* GetConApp();

#endif
