#ifndef testapp_h
#define testapp_h
#include "conapp.h"

class CTestApp : public CConsoleApp
{
public:
    virtual bool init();    // initialization which completes before main() is called
    virtual void main();    // the primary routine of the application
    virtual void deinit();  // stuff done before the program exits
    virtual void usage();   // emits output showing program usage

    CTestApp() : CConsoleApp() { }
    ~CTestApp() { }
};

#endif
