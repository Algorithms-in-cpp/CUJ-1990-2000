// testapp.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "testapp.h"
#include "conapp.h"
#include <iostream>
using namespace std;

// TestApp application class derived from CTestApp 
CTestApp App;

// Function required by Conlib framework, 
//   to get base class of CConsoleApp
inline CConsoleApp* GetConApp() { return &App; }


bool CTestApp::init()
{
    tcout << _T("\ninit called") << endl;

    LPTSTR pCmd = GetCommandLine();
    tcout << _T("Raw command line: ") 
        << pCmd 
        << endl;
    tcout << _T("App fullpath ")
        << GetProgramFullPath()
        << endl;
    tcout << _T("App dir ")
        << GetProgramDir()
        << endl;
    tcout << _T("App filename ")
        << GetProgramName()
        << endl;
    tcout << _T("App base name ")
        << GetProgramBaseName()
        << endl;

    return !arglist.empty();
}


void CTestApp::deinit()
{
    tcout << _T("\ndeinit called") << endl;
}

void CTestApp::usage()
{
    tcout << _T("\nusage called") << endl;
    tcout << _T("No arguments given.\n") << endl;
}

void CTestApp::main()
{
    list<CCmdArg>::iterator iter;

    tcout << _T("\nmain called") << endl;

    for ( 
        iter = arglist.begin();
        iter != arglist.end();
        iter++ 
        )
    {
        CCmdArg carg = *iter;

        switch( carg.GetType() )
        {
            case CCmdArg::CmdSwitch:
                tcout << _T("Switch ")
                    << carg.GetSwitch()
                    << endl;
                break;
            case CCmdArg::CmdOption:
                tcout << _T("Option ")
                    << carg.GetOptionName()
                    << _T(" = ")
                    << carg.GetOptionValue()
                    << endl;
                break;
            case CCmdArg::CmdString:
                tcout << _T("String ")
                    << carg.GetString()
                    << endl;
                break;
        }
    }
}

