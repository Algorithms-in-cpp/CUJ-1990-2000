// DynamicLibrary.h: Wraps dynamic linking capabilities
//                   of Win32, Solaris, and Linux.

#ifndef DYNAMICLIBRARY_H_INCLUDED
#define DYNAMICLIBRARY_H_INCLUDED

#include <vector>

typedef void(*DLPROC)();


class DynamicLibrary  
{
private:

	class cache_info
	{
	public:
		DLPROC	procAddr;
		bool	testFlag;

	public:
		cache_info(void) : procAddr(0), testFlag(false) {};
	};

private:

#ifdef _WIN32
	HMODULE						libHandle;
#else
	void*						libHandle;
#endif

	std::vector<cache_info>		cache;

protected:

	template<class T1, class T2> int DynamicCall_2_int(const char *pcName, int iCache, T1 arg1, T2 arg2)
	{
		int(*f)(T1, T2) = reinterpret_cast<int(*)(T1, T2)>(
			GetProcAddrCached(pcName, iCache));

		if (f)
			return f(arg1, arg2);

		return -1;
	};

	template<class T1, class T2> void DynamicCall_2_void(const char *pcName, int iCache, T1 arg1, T2 arg2)
	{
		void(*f)(T1, T2) = reinterpret_cast<void(*)(T1, T2)>(
			GetProcAddrCached(pcName, iCache));

		if (f)
			f(arg1, arg2);
	};

public:

	DynamicLibrary(void) : libHandle(0) {};
	DynamicLibrary(const char *libName);
	virtual ~DynamicLibrary(void);

	bool Load(const char *libName);
	bool Unload(void);
	bool IsLoaded(void) const { return (libHandle != 0); };

	DLPROC GetProcAddr(const char *procName) const;
	DLPROC GetProcAddrCached(const char *procName,
							 unsigned int procId);
#ifdef _WIN32
	DLPROC GetProcAddr(int ordinal) const;
	DLPROC GetProcAddrCached(int ordinal);
#endif

};

#endif


