// SimpleMath.cpp: Wraps functions exported by dynamic
//                 libraries supporting Simple Math API.

#ifdef _WIN32
#define NO_GDI
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#include "SimpleMath.h"

// indices for GetProcAddrCached() calls
enum eCallCacheIndex 
{
    CONST_simple_math_add,
    CONST_simple_math_sub,
    CONST_simple_math_mul,
    CONST_simple_math_div,
    CONST_simple_math_who
};

#define DYNAMIC_CALL_2_INT(FUNCTION_NAME, ARG1, ARG2) DynamicCall_2_int( #FUNCTION_NAME , CONST_##FUNCTION_NAME , ARG1, ARG2);
#define DYNAMIC_CALL_2_VOID(FUNCTION_NAME, ARG1, ARG2) DynamicCall_2_void( #FUNCTION_NAME , CONST_##FUNCTION_NAME , ARG1, ARG2);

int SimpleMath::Add(int x, int y)
{
	return DYNAMIC_CALL_2_INT( simple_math_add , x, y);
}

int SimpleMath::Sub(int x, int y)
{
	return DYNAMIC_CALL_2_INT( simple_math_sub , x, y);
}

int SimpleMath::Mul(int x, int y)
{
	return DYNAMIC_CALL_2_INT( simple_math_mul , x, y);
}

int SimpleMath::Div(int x, int y)
{
	return DYNAMIC_CALL_2_INT( simple_math_div , x, y);
}

void SimpleMath::Who(char *str, int nChars)
{
	DYNAMIC_CALL_2_VOID( simple_math_who , str, nChars);
}

