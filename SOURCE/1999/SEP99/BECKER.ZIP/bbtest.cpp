#define MAX_LEN 10000

typedef struct node
{
struct node *next;
int id;
};

struct node *create(void)
{
int i;
struct node *head = NULL;
for (i = 0; i < MAX_LEN; ++i)
    {
    struct node *new_node = 
        malloc(sizeof(struct node));
    if (new_node == NULL)
        return head;
    new_node->id = i;
    new_node->next = head;
    head = new_node;
    }
return head;
}

void destroy(struct node *list)
{
while (list != NULL)
    {
    struct node *temp = list;
    list = list->next;
    free(temp);
    }
}

struct node *add(struct node *list)
{
static int count = 0;
struct node *new_node = 
    malloc(sizeof(struct node));
if (new_node == NULL)
    return list;
new_node->next = list;
new_node->id = count++;
return new_node;
}

int main()
{
struct node *list1 = NULL;
struct node *list2 = NULL;
struct node *list3 = NULL;
int i;
for (i = 0; i < MAX_LEN; ++i)
    {
    list1 = add(list1);
    list2 = add(list2);
    list3 = add(list3);
    }
for(i = 0;; ++i)
    {
    destroy(list1);
    list1 = create();
    destroy(list2);
    list2 = create();
    destroy(list3);
    list3 = create();
    if (i % 100 == 0)
        putch(`.');
    }
return 0;
}

