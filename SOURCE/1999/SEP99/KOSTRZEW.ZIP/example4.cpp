//ex 4)
//-----
// Example of forward iterator operations using CMap iterator.
CMap<int*,int*,CString,CString> mp;
const CMap<int*,int*,CString,CString> &cmp = mp;

// default construction and copy construction
mfciter::cmap<int*,CString>::iterator ii;
mfciter::cmap<int*,CString>::const_iterator cii;
mfciter::cmap<int*,CString>::iterator cpy(mfciter::begin(mp));

// assignment (can assign an iterator of a mutable sequence to an iterator 
// of a const sequence, but not vice-versa)
ii = mfciter::begin(mp);
cii = mfciter::begin(cmp);
cii = ii;

// movement (through pre and post increment)
++ii;
cii++;

// comparison (can compare iterators and const_iterators)
bool done;
done = ii == mfciter::end(mp);
done = cii == mfciter::end(cmp);
if (ii == cii)
  std::cout << "both ii and cii refer to the same place";

// value querying
int *p;
CString s;
p = ii->first;
s = ii->second;
p = (*cii).first;
s = (*cii).second;

// value modification (only through the second field for an iterator
// on mutable sequences)
ii->second = "new value";


