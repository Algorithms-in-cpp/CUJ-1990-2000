//ex 1)
//-----
// Simple example of iterating over STL collections
std::vector<foo> stl_vfoo;
std::list<foo> stl_lfoo;
std::map<int,foo> stl_mfoo;

for (std::vector<foo>::iterator vii=stl_vfoo.begin(); vii!=stl_vfoo.end(); ++vii)
  ;
for (std::list<foo>::iterator lii=stl_lfoo.begin(); lii!=stl_lfoo.end(); ++lii)
  ;
for (std::map<int,foo>::iterator mii=stl_mfoo.begin(); mii!=stl_mfoo.end(); ++mii)
  ;

