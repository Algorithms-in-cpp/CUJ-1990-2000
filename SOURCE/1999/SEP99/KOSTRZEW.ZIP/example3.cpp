//ex 3)
//-----
// Iterating through a sample MFC list, array and map using mfciter
CStringList lst;
for (mfciter::slst::iterator lii=mfciter::begin(lst); lii!=mfciter::end(lst); ++lii)
  ;
CArray<int,int> arr;
for (mfciter::carr<int>::iterator aii=mfciter::begin(arr); aii!=mfciter::end(arr); ++aii)
  ;
CTypedPtrMap<CMapPtrToPtr,void*,foo*> mp;
for (mfciter::tppmap<void*,foo*>::iterator mii=mfciter::tpp_begin(mp); mii!=mfciter::tpp_end(mp); ++mii)
  ; 

