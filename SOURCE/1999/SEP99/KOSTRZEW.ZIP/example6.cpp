//ex 6)
//-----
// Example of random access iterator operations using CArray iterator.
// all of the list iteration operations, plus:
CArray<int,int> arr;
mfciter::carr<int>::iterator ii = mfciter::begin(arr);

        // movement (forward and backwards in large jumps)
ii += 5;
ii -= 5;
mfciter::carr<int>::iterator jj = ii + 1;

        // comparison (based on relative position)
if (ii > jj)
        std::cout << "ii is greater than jj";

        // difference querying
int diff = ii - jj;

        // value querying and modification (using subscripts).
ii[1] = jj[2];
*(jj+3) = 2050;



