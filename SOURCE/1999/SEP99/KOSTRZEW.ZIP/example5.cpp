//ex 5)
//-----
// Example of bidirectional iterator operations using CList iterator.
// all of the map iteration operations, plus:
CList<int,int> lst;
const CList<int,int> &clst = lst;

mfciter::clst<int>::iterator ii = mfciter::begin(lst);

        // movement (forward and backwards)
++ii;
--ii;
ii++;
ii--;

        // reverse iteration
mfciter::clst<int>::reverse_iterator rii = mfciter::rbegin(lst);
mfciter::clst<int>::const_reverse_iterator rcii = mfciter::rbegin(clst);

        // value modification
(*ii) = 1;
(*rii) = 2;


