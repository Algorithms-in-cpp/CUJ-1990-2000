/*///////////////////////////////////////////////////////////////////////////////
// Filename: arrIter.h
// Contains the following externally visible objects:
//  mfciter::[array type]::iterator
//  mfciter::[array type]::const_iterator 
//      random access iterators that move forwards through a sequence
//      returned by the accessor freestanding functions mfciter::begin() and mfciter::end()
//  mfciter::[array type]::reverse_iterator
//  mfciter::[array type]::const_reverse_iterator
//      random access iterators that move backwards through a sequence
//      returned by the accessor freestanding functions mfciter::rbegin() and mfciter::rend()
// Notes:
//  This header file inserts mutable and const iterators on MFC array containers into
// the mfciter namespace, as well as accessor functions begin(), end(), rbegin() and rend().
// As this is a complex template implementation in this header file, please do not 
// read through the template classes definition/implementation to try to understand the 
// class interface.
//  The iterators created iterate over MFC arrays as fully support the stdc++lib
// requirements of random access iterators, which therefore allows them to be used with any
// stdc++lib algorithm (found in header <algorithm>) that works upon random acecss 
// iterators.  
//
//  To access the iterators at the beginning and the ending of a MFC array sequence, call
// the freestanding functions mfciter::begin(), mfciter::end(), mfciter::rbegin(), or
// mfciter::rend(), (see note on a CTypedPtrArray caveat) passing the MFC array.  The 
// iterator returned will be either a mfciter::base_array::iterator, 
// mfciter::base_array::const_iterator, mfciter::base_array::reverse_iterator or 
// mfciter::base_array::const_reverse_iterator, depending upon the function called and 
// cv qualification of the MFC array.  Both mfciter::iterator and mfciter::reverse_iterator 
// allow modification of the array entry, while mfciter::const_iterator and 
// mfciter::const_reverse_iterator do not.
//
// [NOTE: Microsoft Visual C++ 6.0 generates an internal compiler error if the iterator
// accessor freestanding functions use the overloaded template function mfciter::begin(),
// mfciter::end(), mfciter::rbegin() and mfciter::rend() on CTypedPtrArray.  Until Microsoft 
// fixes this error, the accessor functions for CTypedPtrArray have to be prefixed with a 
// unique string.  Once the error is fixed, hopefully all CTypedPtrArray accessor functions 
// can be named mfciter::begin(), mfciter::end(), mfciter::rbegin() and mfciter::rend(). 
// See the table below to identify the appropriate name for the freestanding accessor function.]
// 
//  The real type of the iterator returned depends upon the MFC array that is passed
// into the mfciter::begin() or mfciter::end() function.  Use the following table
// to determine the correct array type.  Note that most of the types require template
// parameters to be filled in that describe the VALUE field of the MFC array.
//
//  iterator/const_iterator                                 MFC array
// mfciter::carr<VALUE>::iterator/const_iterator            CArray<VALUE,ARG_VALUE> template
// mfciter::tparr<VALUE>::iterator/const_iterator           CTypedPtrArray<CPtrArray,VALUE>
//      accessed by functions mfciter::tp_begin(), mfciter::tp_end(), mfciter::tp_rbegin() and mfciter::tp_rend()
// mfciter::toarr<VALUE>::iterator/const_iterator           CTypedPtrArray<CObArray,VALUE>
//      accessed by functions mfciter::to_begin(), mfciter::to_end(), mfciter::to_rbegin() and mfciter::to_rend()
// mfciter::oarr::iterator/const_iterator                   CObArray
// mfciter::barr::iterator/const_iterator                   CByteArray
// mfciter::dwarr::iterator/const_iterator                  CDWordArray
// mfciter::parr::iterator/const_iterator                   CPtrArray
// mfciter::sarr::iterator/const_iterator                   CStringArray
// mfciter::warr::iterator/const_iterator                   CWordArray
// mfciter::uiarr::iterator/const_iterator                  CUIntArray
//
//  The syntax for iterating through an MFC array is very similar to the syntax for
// iterating through a stdc++lib vector:
// ex) 
// std::vector<CObject*> myStdCppLibVector;
// for (std::vector<CObject*>::iterator ii=myStdCppLibVector.begin(); ii!=myStdCppLibVector.end(); ++ii)
//      ;
// CArray<CObject*,CObject*> myMfcArray;
// for (mfciter::clst<CObject*>::iterator jj=mfciter::begin(myMfcArray); jj!=mfciter::end(myMfcArray); ++jj)
//      ;
*/

#ifndef _INC_MFCITER_ARRITER_H_
#define _INC_MFCITER_ARRITER_H_

#include <iterator>

    // namespace which holds iterators on mfc collections
namespace mfciter
{
////////////////////////////////////////////////////////////////////////////////
// base_array definition/implementation
// non-instantiatable template struct that holds the member types iterator,
// const_iterator, reverse_iterator and const_reverse_iterator.  all template
// structs derived from this struct specialize the ARRAY template parameter.  This
// struct should not be used on the left hand side of the scope resolution operator
// when giving the type of an iterator.  Rather, a struct derived from this
// struct should be used.
template<class VALUE, class ARRAY>
struct base_array
    {
        // forward declarations
    class _iterator;
    class _const_iterator;

        // typedefs/consts for use inside this struct
    typedef VALUE value_tp;
    typedef const value_tp const_value_tp;
    typedef value_tp  mutable_value_tp;
    typedef ARRAY collection_tp;
    typedef int difference_tp;
    typedef int index_tp;
    enum { end_of_sequence=-1 };      // can't use "static const" because vc6 doesn't support that yet.

        // The main typedefs for use outside this struct
    typedef _const_iterator const_iterator;
    typedef _iterator iterator;
    typedef std::reverse_iterator<const_iterator, const_value_tp> const_reverse_iterator;
    typedef std::reverse_iterator<iterator, mutable_value_tp> reverse_iterator;

////////////////////////////////////////////////////////////////////////////////
// base_array<VALUE,MAP>::_const_iterator definition/implementation
// stdc++lib random access iterator on an MFC array.  Does not allow modification of the
// members that it iterates.  m_pos == -1 means that we are at the end of the iteration sequence.
    class _const_iterator : public std::iterator<std::random_access_iterator_tag, value_tp>
        {
    public:
        enum end_tp { end };        // Special tag to start our iterator at the end of the sequence, 
                                    // useful to reverse iterators

    public:
            // CREATORS
        _const_iterator() :
            m_col(NULL),
            m_pos(end_of_sequence)       
            {}
        explicit _const_iterator(const collection_tp &col) :
            m_col(const_cast<collection_tp *>(&col)),       // const_cast only to allow derived _iterator to mutate the array
            m_pos((col.GetSize()>0) ? 0 : end_of_sequence)
            {}
            // allow our iterator to start at the end of the sequence
        _const_iterator(const collection_tp &col, end_tp) :
            m_col(const_cast<collection_tp *>(&col)),       // const_cast only to allow derived _iterator to mutate the array
            m_pos(end_of_sequence)
            {}
        _const_iterator(const _const_iterator &other) :
            m_col(other.m_col),
            m_pos(other.m_pos)
            {}

    public:
            // MODIFIERS
        _const_iterator &operator=(const _const_iterator &other)
            {
            m_col = other.m_col;
            m_pos = other.m_pos;
            return *this;
            }

        _const_iterator &operator++()
            {
                // ASSERT:cannot advance through a sequence unless we have a valid
                // container and are not already pointing to the end of that sequence.
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));
            ASSERT(end_of_sequence != m_pos);

                // move to the next element of the sequence.  mark us as being at end_of_sequence if
                // we fall off the end.
            index_tp nextPos = m_pos+1;
            if (nextPos >= m_col->GetSize())
                nextPos = end_of_sequence;
            m_pos = nextPos;
            return *this;
            }
        const _const_iterator operator++(int)
            {
            const _const_iterator ret(*this);
            operator++();
            return ret;
            }
        _const_iterator &operator--()
            {
                // ASSERT:cannot move backwards through a sequence unless we have a valid container
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

                // move backwards, translating end_of_sequence to one past the last position 
            const index_tp pos = (end_of_sequence==m_pos) ? m_col->GetSize() : m_pos;
            m_pos = pos - 1;

                // ASSERT:can't move backwards before the beginning of a sequence
            ASSERT(m_pos >= 0);
            return *this;
            }
        const _const_iterator operator--(int)
            {
            const _const_iterator ret(*this);
            operator--();
            return ret;
            }

        _const_iterator &operator+=(index_tp n)
            {
                // ASSERT:cannot advance through a sequence unless we have a valid
                // container and are not already pointing to the end of that sequence.
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));
            ASSERT(end_of_sequence != m_pos);

                // move n steps through the sequence.  mark us as being at end_of_sequence if
                // we fall of the end.
            index_tp nextPos = m_pos+n;
            if (nextPos >= m_col->GetSize())
                nextPos = end_of_sequence;
            m_pos = nextPos;

                // ASSERT: cannot advance (using a negative index) before the beginning of a sequence
            ASSERT(end_of_sequence==m_pos || m_pos>=0);
            return *this;
            }
        _const_iterator &operator-=(index_tp n)
            {
                // ASSERT:cannot move backwards through a sequence unless we have a valid container.
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

                // move backwards, translating end_of_sequence to one past the last position
            const index_tp pos = (end_of_sequence==m_pos) ? m_col->GetSize() : m_pos;
            m_pos = pos - n;
            if (m_pos >= m_col->GetSize())      // Handle subtraction with a negative number pushing us past the end
                m_pos = end_of_sequence;

                // ASSERT:can't move backwards before the beginning of a sequence
            ASSERT(end_of_sequence!=m_pos || m_pos>=0);
            return *this;
            }

    public:
            // ACCESSORS
	    const_value_tp &operator*() const
            {
                // ASSERT:cannot access a value referred to by an iterator unless
                // we have a valid container and are not already pointing to the end
                // of that sequence.
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));
            ASSERT(end_of_sequence != m_pos);

                // use ElementAt() because that returns by-reference
	        return m_col->ElementAt(m_pos);
            }
        const_value_tp *operator->() const
            {
            return &operator*();
            }
        const_value_tp &operator[](index_tp n) const
            {
                // ASSERT:cannot access a value referred to by an iterator unless
                // we have a valid container and are not already pointing to the end
                // of that sequence and the index position requested is valid.
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));
            ASSERT(end_of_sequence != m_pos);
            ASSERT((m_pos+n)>=0 && (m_pos+n)<m_col->GetSize());

                // use ElementAt() because that returns by-reference
	        return m_col->ElementAt(m_pos+n);
            }

    protected:
            // DATA
            // All data is protected so derived _iterator can use it.
        collection_tp *m_col;           // array that we refer to, or NULL for empty iterator
        index_tp m_pos;                 // position in the array, or end_of_sequence

            // Our dear friends
        friend bool operator==(const _const_iterator &, const _const_iterator &);
        friend bool operator<(const _const_iterator &, const _const_iterator &);
        friend difference_tp operator-(const _const_iterator &, const _const_iterator &);
        };

////////////////////////////////////////////////////////////////////////////////
// _iterator definition/implementation
// ISA _const_iterator (which is a stdc++lib random access iterator).  Allows 
// modification of the VALUE member.
    class _iterator : public _const_iterator
        {
    public:
        typedef _const_iterator _baseclass;

    public:
            // CREATORS
        _iterator()
            {}
        explicit _iterator(const collection_tp &col) :
            _baseclass(col)
            {}
            // allows our iterator to start at the end of the sequence
        _iterator(const collection_tp &col, end_tp e) :
            _baseclass(col, e)
            {}
        _iterator(const _iterator &other) :
            _baseclass(other)
            {}

    public:
            // MODIFIERS
        _iterator &operator=(const _iterator &other)
            {
            _baseclass::operator=(other);
            return *this;
            }

        _iterator &operator++()
            {
            _baseclass::operator++();
            return *this;
            }
        const _iterator operator++(int)
            {
            const _iterator ret(*this);
            operator++();
            return ret;
            }
        _iterator &operator--()
            {
            _baseclass::operator--();
            return *this;
            }
        const _iterator operator--(int)
            {
            const _iterator ret(*this);
            operator--();
            return ret;
            }

        _iterator &operator+=(index_tp n)
            {
            _baseclass::operator+=(n);
            return *this;
            }
        _iterator &operator-=(index_tp n)
            {
            _baseclass::operator-=(n);
            return *this;
            }

    public:
            // ACCESSORS
        mutable_value_tp &operator*() const
            {
                // ASSERT:can only access the VALUE pointed to be an iterator if we've got a 
                // valid collection that does not point at the end of the sequence.
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));
            ASSERT(end_of_sequence != m_pos);

                // use ElementAt() because that returns by-reference
	        return m_col->ElementAt(m_pos);
            }
        mutable_value_tp *operator->() const
            {
            return &operator*();
            }
        mutable_value_tp &operator[](index_tp n) const
            {
                // ASSERT:cannot access a value referred to by an iterator unless
                // we have a valid container and are not already pointing to the end
                // of that sequence and the index position requested is valid.
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));
            ASSERT(end_of_sequence != m_pos);
	        ASSERT((m_pos+n)>=0 && (m_pos+n)<m_col->GetSize());

                // use ElementAt() because that returns by-reference
	        return m_col->ElementAt(m_pos+n);
            }
        };
    };

    // freestanding support operators
template<class VALUE, class ARRAY>
bool operator==(const base_array<VALUE,ARRAY>::_const_iterator &i1, const base_array<VALUE,ARRAY>::_const_iterator &i2)
    {
        // return true if both iterators are at the end of a sequence or both have
        // the same value for contained collection and position.
    return 
        (base_array<VALUE,ARRAY>::end_of_sequence==i1.m_pos && 
         base_array<VALUE,ARRAY>::end_of_sequence==i2.m_pos) ||
        (i1.m_pos==i2.m_pos && i1.m_col==i2.m_col);
    }
template<class VALUE, class ARRAY>
bool operator!=(const base_array<VALUE,ARRAY>::_const_iterator &i1, const base_array<VALUE,ARRAY>::_const_iterator &i2)
    {
    return !operator==(i1, i2);
    }
template<class VALUE, class ARRAY>
bool operator<(const base_array<VALUE,ARRAY>::_const_iterator &i1, const base_array<VALUE,ARRAY>::_const_iterator &i2)
    {
        // i1 is less than i2 if i2 is at the end and i1 is not, or
        // neither i1 nor i2 are at the end, and i1.m_pos < i2.m_pos
    return
        (base_array<VALUE,ARRAY>::end_of_sequence!=i1.m_pos && 
         base_array<VALUE,ARRAY>::end_of_sequence==i2.m_pos) ||
        (base_array<VALUE,ARRAY>::end_of_sequence!=i1.m_pos && 
         base_array<VALUE,ARRAY>::end_of_sequence!=i2.m_pos && 
         i1.m_pos<i2.m_pos);
    }
template<class VALUE, class ARRAY>
bool operator<=(const base_array<VALUE,ARRAY>::_const_iterator &i1, const base_array<VALUE,ARRAY>::_const_iterator &i2)
    {
    return !operator<(i2,i1);
    }
template<class VALUE, class ARRAY>
bool operator>(const base_array<VALUE,ARRAY>::_const_iterator &i1, const base_array<VALUE,ARRAY>::_const_iterator &i2)
    {
    return operator<(i2,i1);
    }
template<class VALUE, class ARRAY>
bool operator>=(const base_array<VALUE,ARRAY>::_const_iterator &i1, const base_array<VALUE,ARRAY>::_const_iterator &i2)
    {
    return !operator<(i1,i2);
    }
template<class VALUE, class ARRAY>
const base_array<VALUE,ARRAY>::_const_iterator 
    operator+(base_array<VALUE,ARRAY>::index_tp n, const base_array<VALUE,ARRAY>::_const_iterator &ii)
    {
    base_array<VALUE,ARRAY>::_const_iterator ret(ii);
    ret += n;
    return ret;
    }
template<class VALUE, class ARRAY>
const base_array<VALUE,ARRAY>::_const_iterator 
    operator+(const base_array<VALUE,ARRAY>::_const_iterator &ii, base_array<VALUE,ARRAY>::index_tp n)
    {
    return operator+(n,ii);
    }
template<class VALUE, class ARRAY>
const base_array<VALUE,ARRAY>::_const_iterator 
    operator-(const base_array<VALUE,ARRAY>::_const_iterator &ii, base_array<VALUE,ARRAY>::index_tp n)
    {
    base_array<VALUE,ARRAY>::_const_iterator ret(ii);
    ret -= n;
    return ret;
    }
template<class VALUE, class ARRAY>
base_array<VALUE,ARRAY>::difference_tp 
    operator-(const base_array<VALUE,ARRAY>::_const_iterator &i1, const base_array<VALUE,ARRAY>::_const_iterator &i2)
    {
    const base_array<VALUE,ARRAY>::index_tp pos1 = 
        (base_array<VALUE,ARRAY>::end_of_sequence==i1.m_pos) ? i1.m_col->GetSize() : i1.m_pos;
    const base_array<VALUE,ARRAY>::index_tp pos2 = 
        (base_array<VALUE,ARRAY>::end_of_sequence==i2.m_pos) ? i2.m_col->GetSize() : i2.m_pos;
    return pos1 - pos2;
    }
template<class VALUE, class ARRAY>
const base_array<VALUE,ARRAY>::_iterator 
    operator+(base_array<VALUE,ARRAY>::index_tp n, const base_array<VALUE,ARRAY>::_iterator &ii)
    {
    base_array<VALUE,ARRAY>::_iterator ret(ii);
    ret += n;
    return ret;
    }
template<class VALUE, class ARRAY>
const base_array<VALUE,ARRAY>::_iterator 
    operator+(const base_array<VALUE,ARRAY>::_iterator &ii, base_array<VALUE,ARRAY>::index_tp n)
    {
    return operator+(n,ii);
    }
template<class VALUE, class ARRAY>
const base_array<VALUE,ARRAY>::_iterator 
    operator-(const base_array<VALUE,ARRAY>::_iterator &ii, base_array<VALUE,ARRAY>::index_tp n)
    {
    base_array<VALUE,ARRAY>::_iterator ret(ii);
    ret -= n;
    return ret;
    }


////////////////////////////////////////////////////////////////////////////////
// carr definition/implementation.
// iterator containing struct used with MFC's CArray<> template
template<class VALUE,class ARG_VALUE=VALUE>
struct carr : public base_array<VALUE, CArray<VALUE, ARG_VALUE> >
    {
private:
    carr();     // not constructable
    };

template<class VALUE,class ARG_VALUE>
carr<VALUE,ARG_VALUE>::const_iterator
    begin(const CArray<VALUE,ARG_VALUE> &arr)
    {
    return carr<VALUE,ARG_VALUE>::const_iterator(arr);
    }
template<class VALUE,class ARG_VALUE>
carr<VALUE,ARG_VALUE>::iterator
    begin(CArray<VALUE,ARG_VALUE> &arr)
    {
    return carr<VALUE,ARG_VALUE>::iterator(arr);
    }
template<class VALUE,class ARG_VALUE>
carr<VALUE,ARG_VALUE>::const_iterator
    end(const CArray<VALUE,ARG_VALUE> &arr)
    {
    return carr<VALUE,ARG_VALUE>::const_iterator(arr, carr<VALUE,ARG_VALUE>::const_iterator::end);
    }
template<class VALUE,class ARG_VALUE>
carr<VALUE,ARG_VALUE>::iterator
    end(CArray<VALUE,ARG_VALUE> &arr)
    {
    return carr<VALUE,ARG_VALUE>::iterator(arr, carr<VALUE,ARG_VALUE>::iterator::end);
    }
template<class VALUE,class ARG_VALUE>
carr<VALUE,ARG_VALUE>::const_reverse_iterator
    rbegin(const CArray<VALUE,ARG_VALUE> &arr)
    {
    return carr<VALUE,ARG_VALUE>::const_reverse_iterator(end(arr));
    }
template<class VALUE,class ARG_VALUE>
carr<VALUE,ARG_VALUE>::reverse_iterator
    rbegin(CArray<VALUE,ARG_VALUE> &arr)
    {
    return carr<VALUE,ARG_VALUE>::reverse_iterator(end(arr));
    }
template<class VALUE,class ARG_VALUE>
carr<VALUE,ARG_VALUE>::const_reverse_iterator
    rend(const CArray<VALUE,ARG_VALUE> &arr)
    {
    return carr<VALUE,ARG_VALUE>::const_reverse_iterator(begin(arr));
    }
template<class VALUE,class ARG_VALUE>
carr<VALUE,ARG_VALUE>::reverse_iterator
    rend(CArray<VALUE,ARG_VALUE> &arr)
    {
    return carr<VALUE,ARG_VALUE>::reverse_iterator(begin(arr));
    }


////////////////////////////////////////////////////////////////////////////////
// tparr definition/implementation.
// iterator containing struct used with MFC's CTypedPtrArray<CPtrArray,> template.
// The accessor functions are all named tp_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template<class VALUE>
struct tparr : public base_array<VALUE, CTypedPtrArray<CPtrArray,VALUE> >
    {
private:
    tparr();        // not constructable
    };

template<class VALUE>
tparr<VALUE>::const_iterator
    tp_begin(const CTypedPtrArray<CPtrArray,VALUE> &arr)
    {
    return tparr<VALUE>::const_iterator(arr);
    }
template<class VALUE>
tparr<VALUE>::iterator
    tp_begin(CTypedPtrArray<CPtrArray,VALUE> &arr)
    {
    return tparr<VALUE>::iterator(arr);
    }
template<class VALUE>
tparr<VALUE>::const_iterator
    tp_end(const CTypedPtrArray<CPtrArray,VALUE> &arr)
    {
    return tparr<VALUE>::const_iterator(arr, tparr<VALUE>::const_iterator::end);
    }
template<class VALUE>
tparr<VALUE>::iterator
    tp_end(CTypedPtrArray<CPtrArray,VALUE> &arr)
    {
    return tparr<VALUE>::iterator(arr, tparr<VALUE>::iterator::end);
    }
template<class VALUE>
tparr<VALUE>::const_reverse_iterator
    tp_rbegin(const CTypedPtrArray<CPtrArray,VALUE> &arr)
    {
    return tparr<VALUE>::const_reverse_iterator(end(arr));
    }
template<class VALUE>
tparr<VALUE>::reverse_iterator
    tp_rbegin(CTypedPtrArray<CPtrArray,VALUE> &arr)
    {
    return tparr<VALUE>::reverse_iterator(end(arr));
    }
template<class VALUE>
tparr<VALUE>::const_reverse_iterator
    tp_rend(const CTypedPtrArray<CPtrArray,VALUE> &arr)
    {
    return tparr<VALUE>::const_reverse_iterator(begin(arr));
    }
template<class VALUE>
tparr<VALUE>::reverse_iterator
    tp_rend(CTypedPtrArray<CPtrArray,VALUE> &arr)
    {
    return tparr<VALUE>::reverse_iterator(begin(arr));
    }


////////////////////////////////////////////////////////////////////////////////
// toarr definition/implementation.
// iterator containing struct used with MFC's CTypedPtrArray<CObArray,> template.
// The accessor functions are all named to_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template<class VALUE>
struct toarr : public base_array<VALUE, CTypedPtrArray<CObArray,VALUE> >
    {
private:
    toarr();        // not constructable
    };

template<class VALUE>
toarr<VALUE>::const_iterator
    to_begin(const CTypedPtrArray<CObArray,VALUE> &arr)
    {
    return toarr<VALUE>::const_iterator(arr);
    }
template<class VALUE>
toarr<VALUE>::iterator
    to_begin(CTypedPtrArray<CObArray,VALUE> &arr)
    {
    return toarr<VALUE>::iterator(arr);
    }
template<class VALUE>
toarr<VALUE>::const_iterator
    to_end(const CTypedPtrArray<CObArray,VALUE> &arr)
    {
        // safe for comparison with iterator and const_iterator
    return toarr<VALUE>::const_iterator(arr, toarr<VALUE>::const_iterator::end);
    }
template<class VALUE>
toarr<VALUE>::iterator
    to_end(CTypedPtrArray<CObArray,VALUE> &arr)
    {
        // safe for comparison with iterator and const_iterator
    return toarr<VALUE>::iterator(arr, toarr<VALUE>::iterator::end);
    }
template<class VALUE>
toarr<VALUE>::const_reverse_iterator
    to_rbegin(const CTypedPtrArray<CObArray,VALUE> &arr)
    {
    return toarr<VALUE>::const_reverse_iterator(end(arr));
    }
template<class VALUE>
tparr<VALUE>::reverse_iterator
    to_rbegin(CTypedPtrArray<CObArray,VALUE> &arr)
    {
    return tparr<VALUE>::reverse_iterator(end(arr));
    }
template<class VALUE>
tparr<VALUE>::const_reverse_iterator
    to_rend(const CTypedPtrArray<CObArray,VALUE> &arr)
    {
    return tparr<VALUE>::const_reverse_iterator(begin(arr));
    }
template<class VALUE>
tparr<VALUE>::reverse_iterator
    to_rend(CTypedPtrArray<CObArray,VALUE> &arr)
    {
    return tparr<VALUE>::reverse_iterator(begin(arr));
    }


////////////////////////////////////////////////////////////////////////////////
// oarr definition/implementation.
// iterator containing struct used with MFC's CObArray container
struct oarr : public base_array<CObject *, CObArray>
    {
private:
    oarr();        // not constructable
    };

oarr::const_iterator begin(const CObArray &arr)
    {
    return oarr::const_iterator(arr);
    }
oarr::iterator begin(CObArray &arr)
    {
    return oarr::iterator(arr);
    }
oarr::const_iterator end(const CObArray &arr)
    {
    return oarr::const_iterator(arr, oarr::const_iterator::end);
    }
oarr::iterator end(CObArray &arr)
    {
    return oarr::iterator(arr, oarr::iterator::end);
    }
oarr::const_reverse_iterator rbegin(const CObArray &arr)
    {
    return oarr::const_reverse_iterator(end(arr));
    }
oarr::reverse_iterator rbegin(CObArray &arr)
    {
    return oarr::reverse_iterator(end(arr));
    }
oarr::const_reverse_iterator rend(const CObArray &arr)
    {
    return oarr::const_reverse_iterator(begin(arr));
    }
oarr::reverse_iterator rend(CObArray &arr)
    {
    return oarr::reverse_iterator(begin(arr));
    }


////////////////////////////////////////////////////////////////////////////////
// barr definition/implementation.
// iterator containing struct used with MFC's CByteArray container
struct barr : public base_array<BYTE, CByteArray>
    {
private:
    barr();        // not constructable
    };

barr::const_iterator begin(const CByteArray &arr)
    {
    return barr::const_iterator(arr);
    }
barr::iterator begin(CByteArray &arr)
    {
    return barr::iterator(arr);
    }
barr::const_iterator end(const CByteArray &arr)
    {
    return barr::const_iterator(arr, barr::const_iterator::end);
    }
barr::iterator end(CByteArray &arr)
    {
    return barr::iterator(arr, barr::iterator::end);
    }
barr::const_reverse_iterator rbegin(const CByteArray &arr)
    {
    return barr::const_reverse_iterator(end(arr));
    }
barr::reverse_iterator rbegin(CByteArray &arr)
    {
    return barr::reverse_iterator(end(arr));
    }
barr::const_reverse_iterator rend(const CByteArray &arr)
    {
    return barr::const_reverse_iterator(begin(arr));
    }
barr::reverse_iterator rend(CByteArray &arr)
    {
    return barr::reverse_iterator(begin(arr));
    }


////////////////////////////////////////////////////////////////////////////////
// dwarr definition/implementation.
// iterator containing struct used with MFC's CDWordArray container
struct dwarr : public base_array<DWORD, CDWordArray>
    {
private:
    dwarr();        // not constructable
    };

dwarr::const_iterator begin(const CDWordArray &arr)
    {
    return dwarr::const_iterator(arr);
    }
dwarr::iterator begin(CDWordArray &arr)
    {
    return dwarr::iterator(arr);
    }
dwarr::const_iterator end(const CDWordArray &arr)
    {
    return dwarr::const_iterator(arr, dwarr::const_iterator::end);
    }
dwarr::iterator end(CDWordArray &arr)
    {
    return dwarr::iterator(arr, dwarr::iterator::end);
    }
dwarr::const_reverse_iterator rbegin(const CDWordArray &arr)
    {
    return dwarr::const_reverse_iterator(end(arr));
    }
dwarr::reverse_iterator rbegin(CDWordArray &arr)
    {
    return dwarr::reverse_iterator(end(arr));
    }
dwarr::const_reverse_iterator rend(const CDWordArray &arr)
    {
    return dwarr::const_reverse_iterator(begin(arr));
    }
dwarr::reverse_iterator rend(CDWordArray &arr)
    {
    return dwarr::reverse_iterator(begin(arr));
    }


////////////////////////////////////////////////////////////////////////////////
// parr definition/implementation.
// iterator containing struct used with MFC's CPtrArray container
struct parr : public base_array<void *, CPtrArray>
    {
private:
    parr();        // not constructable
    };

parr::const_iterator begin(const CPtrArray &arr)
    {
    return parr::const_iterator(arr);
    }
parr::iterator begin(CPtrArray &arr)
    {
    return parr::iterator(arr);
    }
parr::const_iterator end(const CPtrArray &arr)
    {
    return parr::const_iterator(arr, parr::const_iterator::end);
    }
parr::iterator end(CPtrArray &arr)
    {
    return parr::iterator(arr, parr::iterator::end);
    }
parr::const_reverse_iterator rbegin(const CPtrArray &arr)
    {
    return parr::const_reverse_iterator(end(arr));
    }
parr::reverse_iterator rbegin(CPtrArray &arr)
    {
    return parr::reverse_iterator(end(arr));
    }
parr::const_reverse_iterator rend(const CPtrArray &arr)
    {
    return parr::const_reverse_iterator(begin(arr));
    }
parr::reverse_iterator rend(CPtrArray &arr)
    {
    return parr::reverse_iterator(begin(arr));
    }


////////////////////////////////////////////////////////////////////////////////
// parr definition/implementation.
// iterator containing struct used with MFC's CStringArray container
struct sarr : public base_array<CString, CStringArray>
    {
private:
    sarr();        // not constructable
    };

sarr::const_iterator begin(const CStringArray &arr)
    {
    return sarr::const_iterator(arr);
    }
sarr::iterator begin(CStringArray &arr)
    {
    return sarr::iterator(arr);
    }
sarr::const_iterator end(const CStringArray &arr)
    {
    return sarr::const_iterator(arr, sarr::const_iterator::end);
    }
sarr::iterator end(CStringArray &arr)
    {
    return sarr::iterator(arr, sarr::iterator::end);
    }
sarr::const_reverse_iterator rbegin(const CStringArray &arr)
    {
    return sarr::const_reverse_iterator(end(arr));
    }
sarr::reverse_iterator rbegin(CStringArray &arr)
    {
    return sarr::reverse_iterator(end(arr));
    }
sarr::const_reverse_iterator rend(const CStringArray &arr)
    {
    return sarr::const_reverse_iterator(begin(arr));
    }
sarr::reverse_iterator rend(CStringArray &arr)
    {
    return sarr::reverse_iterator(begin(arr));
    }


////////////////////////////////////////////////////////////////////////////////
// warr definition/implementation.
// iterator containing struct used with MFC's CWordArray container
struct warr : public base_array<WORD, CWordArray>
    {
private:
    warr();        // not constructable
    };

warr::const_iterator begin(const CWordArray &arr)
    {
    return warr::const_iterator(arr);
    }
warr::iterator begin(CWordArray &arr)
    {
    return warr::iterator(arr);
    }
warr::const_iterator end(const CWordArray &arr)
    {
    return warr::const_iterator(arr, warr::const_iterator::end);
    }
warr::iterator end(CWordArray &arr)
    {
    return warr::iterator(arr, warr::iterator::end);
    }
warr::const_reverse_iterator rbegin(const CWordArray &arr)
    {
    return warr::const_reverse_iterator(end(arr));
    }
warr::reverse_iterator rbegin(CWordArray &arr)
    {
    return warr::reverse_iterator(end(arr));
    }
warr::const_reverse_iterator rend(const CWordArray &arr)
    {
    return warr::const_reverse_iterator(begin(arr));
    }
warr::reverse_iterator rend(CWordArray &arr)
    {
    return warr::reverse_iterator(begin(arr));
    }

////////////////////////////////////////////////////////////////////////////////
// uiarr definition/implementation.
// iterator containing struct used with MFC's CUIntArray container
struct uiarr : public base_array<UINT, CUIntArray>
    {
private:
    uiarr();        // not constructable
    };

uiarr::const_iterator begin(const CUIntArray &arr)
    {
    return uiarr::const_iterator(arr);
    }
uiarr::iterator begin(CUIntArray &arr)
    {
    return uiarr::iterator(arr);
    }
uiarr::const_iterator end(const CUIntArray &arr)
    {
    return uiarr::const_iterator(arr, uiarr::const_iterator::end);
    }
uiarr::iterator end(CUIntArray &arr)
    {
    return uiarr::iterator(arr, uiarr::iterator::end);
    }
uiarr::const_reverse_iterator rbegin(const CUIntArray &arr)
    {
    return uiarr::const_reverse_iterator(end(arr));
    }
uiarr::reverse_iterator rbegin(CUIntArray &arr)
    {
    return uiarr::reverse_iterator(end(arr));
    }
uiarr::const_reverse_iterator rend(const CUIntArray &arr)
    {
    return uiarr::const_reverse_iterator(begin(arr));
    }
uiarr::reverse_iterator rend(CUIntArray &arr)
    {
    return uiarr::reverse_iterator(begin(arr));
    }

}   // end namespace mfciter

#endif  // _INC_MFCITER_ARRITER_H_
