/*///////////////////////////////////////////////////////////////////////////////
// Filename: lstIter.h
// Contains the following externally visible objects:
//  mfciter::[list type]::iterator          
//  mfciter::[list type]::const_iterator    
//      bidirectional iterators that move forwards through a sequence
//      returned by the accessor freestanding functions mfciter::begin() and mfciter::end()
//  mfciter::[list type]::reverse_iterator
//  mfciter::[list type]::const_reverse_iterator     
//      bidirectional iterators that move backwards through a sequence
//      returned by the accessor freestanding functions mfciter::rbegin() and mfciter::rend()
// Notes:
//  This header file inserts mutable and const iterators on MFC list containers into 
// the mfciter namespace, as well as accessor functions begin(), end(), rbegin() and rend().  
// As this is a complex template implementation in this header file, please do not 
// read through the template classes definition/implementation to try to understand the 
// class interface.
//  The iterators created iterate over MFC lists and fully support the stdc++lib requirements
// of bidirectional iterators, which therefore allows them to be used with any stdc++lib 
// algorithm (found in header <algorithm>) that works upon bidirectional iterators.
//
//  To access the iterators at the beginning and the ending of a MFC list sequence, call
// the freestanding functions mfciter::begin(), mfciter::end(), mfciter::rbegin(), or
// mfciter::rend(), (see note on a CTypedPtrList caveat) passing the MFC list.  The iterator 
// returned will be either a mfciter::base_list::iterator, mfciter::base_list::const_iterator, 
// mfciter::base_list::reverse_iterator or mfciter::base_list::const_reverse_iterator
// depending upon the function called and the cv qualification of the MFC list.  Both 
// mfciter::iterator and mfciter::reverse_iterator allow modification of the list entry, 
// while mfciter::const_iterator and mfciter::const_reverse_iterator do not.
//
// [NOTE: Microsoft Visual C++ 6.0 generates an internal compiler error if the iterator
// accessor freestanding functions use the overloaded template function mfciter::begin(),
// mfciter::end(), mfciter::rbegin() and mfciter::rend() on CTypedPtrList.  Until Microsoft 
// fixes this error, the accessor functions for CTypedPtrList have to be prefixed with a 
// unique string.  Once the error is fixed, hopefully all CTypedPtrList accessor functions 
// can be named mfciter::begin(), mfciter::end(), mfciter::rbegin() and mfciter::rend(). 
// See the table below to identify the appropriate name for the freestanding accessor function.]
//
//  The real type of the iterator returned depends upon the MFC list that is passed
// into the mfciter::begin() or mfciter::end() function.  Use the following table
// to determine the correct list type.  Note that most of the types require template
// parameters to be filled in that describe the VALUE field of the MFC list.
//
//  iterator/const_iterator                                 MFC list
// mfciter::clst<VALUE>::iterator/const_iterator            CList<VALUE,ARG_VALUE> template
// mfciter::tplst<VALUE>::iterator/const_iterator           CTypedPtrList<CPtrList, VALUE> template
//      accessed by functions mfciter::tp_begin(), mfciter::tp_end(), mfciter::tp_rbegin() and mfciter::tp_rend()
// mfciter::tolst<VALUE>::iterator/const_iterator           CTypedPtrList<CObList, VALUE> template
//      accessed by functions mfciter::to_begin(), mfciter::to_end(), mfciter::to_rbegin() and mfciter::to_rend()
// mfciter::plst::iterator/const_iterator                   CPtrList
// mfciter::olst::iterator/const_iterator                   CObList
// mfciter::slst::iterator/const_iterator                   CStringList
// 
//  The syntax for iterating through an MFC list is very similar to the syntax for
// iterating through a stdc++lib list:
// ex) 
// std::list<int> myStdCppLiblist;
// for (std::list<int>::iterator ii=myStdCppLiblist.begin(); ii!=myStdCppLiblist.end(); ++ii)
//      ;
// CList<int,int> myMfcList;
// for (mfciter::clst<int>::iterator jj=mfciter::begin(myMfcList); jj!=mfciter::end(myMfcList); ++jj)
//      ;
///////////////////////////////////////////////////////////////////////////////*/

#ifndef _INC_MFCITER_LSTITER_H_
#define _INC_MFCITER_LSTITER_H_

#include <iterator>

    // namespace which holds iterators on mfc collections
namespace mfciter
{
////////////////////////////////////////////////////////////////////////////////
// base_list definition/implementation
// non-instantiatable template struct that holds the member types iterator,
// const_iterator, reverse_iterator and const_reverse_iterator.  all template
// structs derived from this struct specialize the LIST template parameter.  This
// struct should not be used on the left hand side of the scope resolution operator
// when giving the type of an iterator.  Rather, a struct derived from this
// struct should be used.
template<class VALUE, class LIST>
struct base_list
    {
        // forward declarations
    class _const_iterator;
    class _iterator;
    class _reverse_iterator;
    class _modifiable_value;

        // typedefs/consts for use inside this struct
    typedef VALUE value_tp;
    typedef const VALUE const_value_tp;
    typedef _modifiable_value mutable_value_tp;
    typedef LIST collection_tp;
    typedef POSITION index_tp;
    enum { end_of_sequence=NULL };      // can't use "static const" because vc6 doesn't support that yet.

        // The main typedefs for use outside this struct
    typedef _const_iterator const_iterator;
    typedef _iterator iterator;
    typedef std::reverse_bidirectional_iterator<const_iterator, const_value_tp> const_reverse_iterator;
    typedef _reverse_iterator reverse_iterator;


////////////////////////////////////////////////////////////////////////////////
// base_list<VALUE,MAP>::_const_iterator definition/implementation
// stdc++lib bidirectional iterator on a MFC list.  Does not allow modification of the
// members that it iterates.  The member m_refRet allows operator*() and operator->()
// to return a reference to the current VALUE element.  m_pos == NULL means that we are at
// the end of the iteration sequence.
    class _const_iterator : public std::iterator<std::bidirectional_iterator_tag, value_tp>
        {        
    public:
        enum end_tp { end };        // Special tag to start our iterator at the end of the sequence, 
                                    // useful to reverse iterators

    public:
            // CREATORS
	    _const_iterator() :
            m_col(NULL),
	        m_pos(reinterpret_cast<index_tp>(end_of_sequence))
            {}
        explicit _const_iterator(const collection_tp &col) :
            m_col(const_cast<collection_tp *>(&col)),       // const_cast only to allow derived _iterator to mutate the list
            m_pos((col.GetCount()>0) ? col.GetHeadPosition() : reinterpret_cast<index_tp>(end_of_sequence))
            {}
            // allow our iterator to start at the end of the sequence
        _const_iterator(const collection_tp &col, end_tp) :
            m_col(const_cast<collection_tp *>(&col)),       // const_cast only to allow derived _iterator to mutate the list
            m_pos(reinterpret_cast<index_tp>(end_of_sequence))
            {}
        _const_iterator(const _const_iterator &other) :     // copy all members except for m_refRet, as that is not necessary
            m_col(other.m_col),
            m_pos(other.m_pos)
            {}
    
    public:
            // MODIFIERS
	    _const_iterator &operator=(const _const_iterator &other)
            {
	        m_col = other.m_col;        // copy all members except for m_refRet, as that is not necessary
	        m_pos = other.m_pos;
	        return *this;
            }
        _const_iterator &operator++()
            {
                // ASSERT:cannot advance through a sequence unless we have a valid
                // container and are not already pointing to the end of that sequence.
	        ASSERT(reinterpret_cast<index_tp>(end_of_sequence) != m_pos);
	        ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

                // move to the next entry in the sequence.  assumes (verified by the assertion) that 
                // end_of_sequence is the value returned from GetNext() when we are at the end of a sequence.
            index_tp posNext = m_pos;
	        m_col->GetNext(posNext);
            ASSERT((m_pos==m_col->GetTailPosition() && 
                    reinterpret_cast<index_tp>(end_of_sequence)==posNext) || 
                   reinterpret_cast<index_tp>(end_of_sequence)!=posNext);
            m_pos = posNext;
	        return *this;
            }
        const _const_iterator operator++(int)
            {
	        const _const_iterator ret(*this);
	        operator++();
	        return ret;
            }
        _const_iterator &operator--()
            {
                // ASSERT:cannot move backwards through a sequence unless we have a valid container.
	        ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

                // end_of_sequence - 1 puts us at the tail of the list.  otherwise, just use GetPrev().
            if (reinterpret_cast<index_tp>(end_of_sequence) == m_pos)
                m_pos = m_col->GetTailPosition();
            else
	            m_col->GetPrev(m_pos);
            return *this;
            }
        const _const_iterator operator--(int)
            {
	        const _const_iterator ret(*this);
	        operator--();
	        return ret;
            }

    public:
            // ACCESSORS
        const_value_tp &operator*() const
            {
                // ASSERT:cannot access a value referred to by an iterator unless
                // we have a valid container and are not already pointing to the end
                // of that sequence.
	        ASSERT(reinterpret_cast<index_tp>(end_of_sequence) != m_pos);
	        ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

                // m_refRet allows us to return by-reference, rather than returning by-value
	        m_refRet = m_col->GetAt(m_pos);
	        return m_refRet;
            }
        const_value_tp *operator->() const
            {
	        return &operator*();
            }

    protected:
            // DATA 
            // All data is protected so derived _iterator can use it.
	    collection_tp *m_col;           // list that we refer to, or NULL for empty iterator
	    index_tp m_pos;                 // position in the list, or end_of_sequence
	    mutable value_tp m_refRet;      // for functions that return iterated value by reference.
                                        // mutable to allow changing in operator* and operator-> const functions

            // Our dear friends
        friend bool operator==(const _const_iterator &, const _const_iterator &);
        };


////////////////////////////////////////////////////////////////////////////////
// _modifiable_value implementation
// Proxy class that allows the return of operator*()/operator->() from _iterator
// to have the VALUE field modifiable.  This is only constructable by friend _iterator.
    class _modifiable_value
        {
    private:
            // CREATORS 
            // (only creatable by friend _iterator)
        _modifiable_value() :
            m_col(NULL),
            m_pos(reinterpret_cast<index_tp>(end_of_sequence))
            {}
        _modifiable_value(collection_tp &col, index_tp pos) :
            m_col(&col),
            m_pos(pos)
            {}

    public:
            // MANIPULATORS
        _modifiable_value &operator=(const value_tp &val)
            {
                // ASSERT:can only assign to a _modifiable_value pointed to be an iterator
                // if we've got a valid collection that does not point at the end of the sequence.
	        ASSERT(reinterpret_cast<index_tp>(end_of_sequence) != m_pos);
	        ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

	        m_col->SetAt(m_pos, val);
	        return *this;
            }
    public:
            // ACCESSORS
        operator const VALUE &() const
            {
                // ASSERT:can only access the VALUE pointed to be an iterator if we've got a 
                // valid collection that does not point at the end of the sequence.
	        ASSERT(reinterpret_cast<index_tp>(end_of_sequence) != m_pos);
	        ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

	        return m_col->GetAt(m_pos);
            }
        VALUE *operator&() const
            {
                // ASSERT:can only access the VALUE pointed to be an iterator if we've got a 
                // valid collection that does not point at the end of the sequence.
	        ASSERT(reinterpret_cast<index_tp>(end_of_sequence) != m_pos);
	        ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

	        return &m_col->GetAt(m_pos);
            }
    
    private:
            // DATA
        collection_tp *m_col;           // referred to list (or NULL)
        index_tp m_pos;                 // position whose value we might change

            // Our dear friends
        friend class _iterator;
        friend class _reverse_iterator;
        };


////////////////////////////////////////////////////////////////////////////////
// _iterator definition/implementation
// ISA _const_iterator (which is a stdc++lib bidirectional iterator).  Allows 
// modification of the VALUE member through the proxy class _modifiable_value.
class _iterator : public _const_iterator
        {
    public:
        typedef _const_iterator _baseclass;

    public:
            // CREATORS
	    _iterator() 
            {}
        explicit _iterator(const collection_tp &col) :
            _baseclass(col)
            {}
            // allows our iterator to start at the end of the sequence
        _iterator(const collection_tp &col, end_tp e) :
            _baseclass(col, e)
            {}
        _iterator(const _iterator &other) :
            _baseclass(other)           // don't need to copy m_mutRet member
            {}

    public:
            // MODIFIERS
	    _iterator &operator=(const _iterator &other) 
            {
	        _baseclass::operator=(other);
            return *this;
            }

        _iterator &operator++()
            {
	        _baseclass::operator++();
	        return *this;
            }
        const _iterator operator++(int)
            {
	        const _iterator ret(*this);
	        operator++();
	        return ret;
            }
        _iterator &operator--()
            {
	        _baseclass::operator--();
	        return *this;
            }
        const _iterator operator--(int)
            {
	        const _iterator ret(*this);
	        operator--();
	        return ret;
            }
    
    public:
            // ACCESSORS
            // allows the value parameter to be modified
            // (both of these are const functions because const-ness means immobile with iterators)
	    mutable_value_tp &operator*() const
            {
                // ASSERT:cannot access a value referred to by an iterator unless
                // we have a valid container and are not already pointing to the end
                // of that sequence.
	        ASSERT(reinterpret_cast<index_tp>(end_of_sequence) != m_pos);
	        ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

	        m_mutRet = mutable_value_tp(*m_col, m_pos);
	        return m_mutRet;
            }
        mutable_value_tp *operator->() const
            {
	        return &operator*();
            }

    private:
        mutable mutable_value_tp m_mutRet;      // Return value from operator*() and operator->() to allow VALUE modification.
                                                // mutable to allow modification in those const member functions
        };


////////////////////////////////////////////////////////////////////////////////
// _reverse_iterator definition/implementation
// is implemented in terms of std::reverse_bidirectional_iterator<>
// We couldn't use the std::reverse_bidirectional_iterator adaptor because
// the return value from operator*()/operator->() was a reference/pointer, but the
// contained iterator that was used to get that value was destroyed on the stack
// before the return took place.
    class _reverse_iterator : public std::iterator<std::random_access_iterator_tag, value_tp>
        {
    public:
            // CREATORS
        _reverse_iterator() 
            {}
        explicit _reverse_iterator(const iterator &ii) :
            m_ii(ii)
            {}
        _reverse_iterator(const _reverse_iterator &other) :
            m_ii(other.m_ii)
            {}

    public:
            // MANIPULATORS
        _reverse_iterator &operator=(const _reverse_iterator &other) 
            {
            m_ii = other.m_ii;
            return *this;
            }

        _reverse_iterator &operator++()
            {
            --m_ii;
            return *this;
            }
        const _reverse_iterator operator++(int)
            {
            const _reverse_iterator ret(*this);
            operator++();
            return ret;
            }
        _reverse_iterator &operator--()
            {
            ++m_ii;
            return *this;
            }
        const _reverse_iterator operator--(int)
            {
            const _reverse_iterator ret(*this);
            operator--();
            return ret;
            }

    public:
            // ACCESSORS
        mutable_value_tp &operator*() const
            {
            iterator tmp = m_ii;
            m_mutRet = *(--tmp);
            return m_mutRet;
            }
        mutable_value_tp *operator->() const
            {
            return &operator*();
            }

    private:
        iterator m_ii;                          // Contained iterator where we apply the opposite direction function
        mutable mutable_value_tp m_mutRet;      // Return value from operator*() and operator->().

            // our dear friends
        friend bool operator==(const _reverse_iterator &, const _reverse_iterator &);
        };

private:
    base_list();
    };


    // freestanding support operators
template<class VALUE, class LIST> 
bool operator==(const base_list<VALUE,LIST>::_const_iterator &i1, const base_list<VALUE,LIST>::_const_iterator &i2)
    {
        // return true if both iterators are at the end of a sequence or both have
        // the same value for contained collection and position.
	return 
        (reinterpret_cast<base_list<VALUE,LIST>::index_tp>(base_list<VALUE,LIST>::end_of_sequence)==i1.m_pos && 
         reinterpret_cast<base_list<VALUE,LIST>::index_tp>(base_list<VALUE,LIST>::end_of_sequence)==i2.m_pos) || 
	    (i1.m_pos==i2.m_pos && i1.m_col==i2.m_col);
    }
template<class VALUE, class LIST> 
bool operator!=(const base_list<VALUE,LIST>::_const_iterator &i1, const base_list<VALUE,LIST>::_const_iterator &i2)
    {
    return !operator==(i1, i2);
    }
template<class VALUE, class LIST> 
bool operator==(const base_list<VALUE,LIST>::_reverse_iterator &i1, const base_list<VALUE,LIST>::_reverse_iterator &i2)
    {
    return i1.m_ii == i2.m_ii;
    }
template<class VALUE, class LIST> 
bool operator!=(const base_list<VALUE,LIST>::_reverse_iterator &i1, const base_list<VALUE,LIST>::_reverse_iterator &i2)
    {
    return !operator==(i1, i2);
    }


////////////////////////////////////////////////////////////////////////////////
// clst definition/implementation.
// iterator containing struct used with MFC's CList<> template
template <class VALUE, class ARG_VALUE=VALUE>
struct clst : public base_list<VALUE, CList<VALUE, ARG_VALUE> >
    {
private:
    clst();        // not constructable
    };

    // clst<> returning freestanding functions
template<class VALUE, class ARG_VALUE>
clst<VALUE,ARG_VALUE>::const_iterator
    begin(const CList<VALUE,ARG_VALUE> &lst)
    {
    return clst<VALUE, ARG_VALUE>::const_iterator(lst);
    }
template<class VALUE, class ARG_VALUE>
clst<VALUE,ARG_VALUE>::iterator
    begin(CList<VALUE,ARG_VALUE> &lst)
    {
    return clst<VALUE, ARG_VALUE>::iterator(lst);
    }
template<class VALUE, class ARG_VALUE>
clst<VALUE,ARG_VALUE>::const_iterator
    end(const CList<VALUE,ARG_VALUE> &lst)
    {
    return clst<VALUE, ARG_VALUE>::const_iterator(lst, clst<VALUE,ARG_VALUE>::const_iterator::end);     
    }
template<class VALUE, class ARG_VALUE>
clst<VALUE,ARG_VALUE>::iterator
    end(CList<VALUE,ARG_VALUE> &lst)
    {
    return clst<VALUE, ARG_VALUE>::iterator(lst, clst<VALUE,ARG_VALUE>::iterator::end);     
    }
template<class VALUE, class ARG_VALUE>
clst<VALUE,ARG_VALUE>::const_reverse_iterator
    rbegin(const CList<VALUE,ARG_VALUE> &lst)
    {
    return clst<VALUE,ARG_VALUE>::const_reverse_iterator(end(lst));
    }
template<class VALUE, class ARG_VALUE>
clst<VALUE,ARG_VALUE>::reverse_iterator
    rbegin(CList<VALUE,ARG_VALUE> &lst)
    {
    return clst<VALUE,ARG_VALUE>::reverse_iterator(end(lst));
    }
template<class VALUE, class ARG_VALUE>              
clst<VALUE,ARG_VALUE>::const_reverse_iterator
    rend(const CList<VALUE,ARG_VALUE> &lst)
    {
    return clst<VALUE,ARG_VALUE>::const_reverse_iterator(begin(lst));
    }
template<class VALUE, class ARG_VALUE>              
clst<VALUE,ARG_VALUE>::reverse_iterator
    rend(CList<VALUE,ARG_VALUE> &lst)
    {
    return clst<VALUE,ARG_VALUE>::reverse_iterator(begin(lst));
    }


////////////////////////////////////////////////////////////////////////////////
// CTypedPtrList<CPtrList> definition/implementation
// iterator containing struct used with MFC's CTypedPtrList<CPtrList,> template.
// The accessor functions are all named tp_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template <class VALUE>
struct tplst : public base_list<VALUE, CTypedPtrList<CPtrList, VALUE> >
    {
private:
    tplst();        // not constructable
    };

    // tplst<> returning freestanding functions
template<class VALUE>
tplst<VALUE>::const_iterator
    tp_begin(const CTypedPtrList<CPtrList, VALUE> &lst)
    {
    return tplst<VALUE>::const_iterator(lst);
    }
template<class VALUE>
tplst<VALUE>::iterator
    tp_begin(CTypedPtrList<CPtrList, VALUE> &lst)
    {
    return tplst<VALUE>::iterator(lst);
    }
template<class VALUE>
tplst<VALUE>::const_iterator
    tp_end(const CTypedPtrList<CPtrList, VALUE> &lst)
    {
    return tplst<VALUE>::const_iterator(lst, tplst<VALUE>::const_iterator::end);     
    }
template<class VALUE>
tplst<VALUE>::iterator
    tp_end(CTypedPtrList<CPtrList, VALUE> &lst)
    {
    return tplst<VALUE>::iterator(lst, tplst<VALUE>::iterator::end);     
    }
template<class VALUE>
tplst<VALUE>::const_reverse_iterator
    tp_rbegin(const CTypedPtrList<CPtrList, VALUE> &lst)
    {
    return tplst<VALUE>::const_reverse_iterator(end(lst));
    }
template<class VALUE>
tplst<VALUE>::reverse_iterator
    tp_rbegin(CTypedPtrList<CPtrList, VALUE> &lst)
    {
    return tplst<VALUE>::reverse_iterator(end(lst));
    }
template<class VALUE>              
tplst<VALUE>::const_reverse_iterator
    tp_rend(const CTypedPtrList<CPtrList, VALUE> &lst)
    {
    return tplst<VALUE>::const_reverse_iterator(begin(lst));
    }
template<class VALUE>              
tplst<VALUE>::reverse_iterator
    tp_rend(CTypedPtrList<CPtrList, VALUE> &lst)
    {
    return tplst<VALUE>::reverse_iterator(begin(lst));
    }


////////////////////////////////////////////////////////////////////////////////
// tolst definition/implementation
// iterator containing struct used with MFC's CTypedPtrList<CObList,> template.
// The accessor functions are all named to_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template <class VALUE>
struct tolst : public base_list<VALUE, CTypedPtrList<CObList, VALUE> >
    {
private:
    tolst();        // not constructable
    };

    // tolst<> returning freestanding functions
template<class VALUE>
tolst<VALUE>::const_iterator
    to_begin(const CTypedPtrList<CObList, VALUE> &lst)
    {
    return tolst<VALUE>::const_iterator(lst);
    }
template<class VALUE>
tolst<VALUE>::iterator
    to_begin(CTypedPtrList<CObList, VALUE> &lst)
    {
    return tolst<VALUE>::iterator(lst);
    }
template<class VALUE>
tolst<VALUE>::const_iterator
    to_end(const CTypedPtrList<CObList, VALUE> &lst)
    {
    return tolst<VALUE>::const_iterator(lst, tolst<VALUE>::const_iterator::end);     
    }
template<class VALUE>
tolst<VALUE>::iterator
    to_end(CTypedPtrList<CObList, VALUE> &lst)
    {
    return tolst<VALUE>::iterator(lst, tolst<VALUE>::iterator::end);     
    }
template<class VALUE>
tolst<VALUE>::const_reverse_iterator
    to_rbegin(const CTypedPtrList<CObList, VALUE> &lst)
    {
    return tolst<VALUE>::const_reverse_iterator(end(lst));
    }
template<class VALUE>
tolst<VALUE>::reverse_iterator
    to_rbegin(CTypedPtrList<CObList, VALUE> &lst)
    {
    return tolst<VALUE>::reverse_iterator(end(lst));
    }
template<class VALUE>              
tolst<VALUE>::const_reverse_iterator
    to_rend(const CTypedPtrList<CObList, VALUE> &lst)
    {
    return tolst<VALUE>::const_reverse_iterator(begin(lst));
    }
template<class VALUE>              
tolst<VALUE>::reverse_iterator
    to_rend(CTypedPtrList<CObList, VALUE> &lst)
    {
    return tolst<VALUE>::reverse_iterator(begin(lst));
    }


////////////////////////////////////////////////////////////////////////////////
// CPtrList definition/implementation
// iterator containing struct used with MFC's CPtrList container
struct plst : public base_list<void *, CPtrList>
    {
private:
    plst();     // not constructable
    };

    // plst returning freestanding functions
plst::const_iterator begin(const CPtrList &lst)
    {
    return plst::const_iterator(lst);
    }
plst::iterator begin(CPtrList &lst)
    {
    return plst::iterator(lst);
    }
plst::const_iterator end(const CPtrList &lst)
    {
    return plst::const_iterator(lst, plst::const_iterator::end);
    }
plst::iterator end(CPtrList &lst)
    {
    return plst::iterator(lst, plst::iterator::end);
    }
plst::const_reverse_iterator rbegin(const CPtrList &lst)
    {
    return plst::const_reverse_iterator(end(lst));
    }
plst::reverse_iterator rbegin(CPtrList &lst)
    {
    return plst::reverse_iterator(end(lst));
    }
plst::const_reverse_iterator rend(const CPtrList &lst)
    {
    return plst::const_reverse_iterator(begin(lst));
    }
plst::reverse_iterator rend(CPtrList &lst)
    {
    return plst::reverse_iterator(begin(lst));
    }


////////////////////////////////////////////////////////////////////////////////
// olst definition/implementation
// iterator containing struct used with MFC's CObList container
struct olst : public base_list<CObject *, CObList>
    {
private:
    olst();     // not constructable
    };

    // olst returning freestanding functions
olst::const_iterator begin(const CObList &lst)
    {
    return olst::const_iterator(lst);
    }
olst::iterator begin(CObList &lst)
    {
    return olst::iterator(lst);
    }
olst::const_iterator end(const CObList &lst)
    {
    return olst::const_iterator(lst, olst::const_iterator::end);
    }
olst::iterator end(CObList &lst)
    {
    return olst::iterator(lst, olst::iterator::end);
    }
olst::const_reverse_iterator rbegin(const CObList &lst)
    {
    return olst::const_reverse_iterator(end(lst));
    }
olst::reverse_iterator rbegin(CObList &lst)
    {
    return olst::reverse_iterator(end(lst));
    }
olst::const_reverse_iterator rend(const CObList &lst)
    {
    return olst::const_reverse_iterator(begin(lst));
    }
olst::reverse_iterator rend(CObList &lst)
    {
    return olst::reverse_iterator(begin(lst));
    }


////////////////////////////////////////////////////////////////////////////////
// CStringList implementation
// iterator containing struct used with MFC's CStringList container
struct slst : public base_list<CString, CStringList>
    {
private:
    slst();     // not constructable
    };
    
    // slst returning freestanding functions
slst::const_iterator begin(const CStringList &lst)
    {
    return slst::const_iterator(lst);
    }
slst::iterator begin(CStringList &lst)
    {
    return slst::iterator(lst);
    }
slst::const_iterator end(const CStringList &lst)
    {
    return slst::const_iterator(lst, slst::const_iterator::end);
    }
slst::iterator end(CStringList &lst)
    {
    return slst::iterator(lst, slst::iterator::end);
    }
slst::const_reverse_iterator rbegin(const CStringList &lst)
    {
    return slst::const_reverse_iterator(end(lst));
    }
slst::reverse_iterator rbegin(CStringList &lst)
    {
    return slst::reverse_iterator(end(lst));
    }
slst::const_reverse_iterator rend(const CStringList &lst)
    {
    return slst::const_reverse_iterator(begin(lst));
    }
slst::reverse_iterator rend(CStringList &lst)
    {
    return slst::reverse_iterator(begin(lst));
    }

}       // end of namespace mfciter

#endif      // _INC_MFCITER_LSTITER_H_
