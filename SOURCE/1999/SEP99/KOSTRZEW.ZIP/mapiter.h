/*///////////////////////////////////////////////////////////////////////////////
// Filename: mapIter.h
// Contains the following externally visible objects:
//  mfciter::[map type]::iterator
//  mfciter::[map type]::const_iterator 
//      forward iterators that move through a sequence
//      returned by the accessor freestanding functions mfciter::begin() and mfciter::end()
// Notes:
//  This header file inserts mutable and const iterators on MFC map containers into 
// the mfciter namespace, as well as accessor functions begin() and end().  As this is a complex 
// template implementation in this header file, please do not read through the template
// classes definition/implementation to try to understand the class interface.
//  The iterators created iterate over MFC maps and fully support the stdc++lib requirements
// of forward iterators, which therefore allows them to be used with any stdc++lib 
// algorithm (found in header <algorithm>) that works upon forward iterators.
//
//  To access the iterators at the beginning and the ending of a MFC map sequence, call
// the freestanding functions mfciter::begin() and mfciter::end() (see note on a CTypedPtrMap caveat), 
// passing the MFC map.  The iterator returned will either be a mfciter::base_map::iterator or 
// mfciter::base_map::const_iterator depending upon the cv qualification of the MFC map.  
// mfciter::iterator allows modification of the VALUE field of the map entry, while
// mfciter::const_iterator does not.  
//
// [NOTE: Microsoft Visual C++ 6.0 generates an internal compiler error if the iterator
// accessor freestanding functions use the overloaded template function mfciter::begin() and
// mfciter::end() on CTypedPtrMap.  Until Microsoft fixes this error, the accessor functions 
// for CTypedPtrMap have to be prefixed with a unique string.  Once the error is fixed, 
// hopefully all CTypedPtrMap accessor functions can be named mfciter::begin() and 
// mfciter::end(). See the table below to identify the appropriate name for the freestanding 
// accessor function.]
//
//  The real type of the iterator returned depends upon the MFC map that is passed
// into the mfciter::begin() or mfciter::end() function.  Use the following table
// to determine the correct map type.  Note that most of the types require template
// parameters to be filled in that describe the KEY and VALUE fields of the MFC map.
//
//  iterator/const_iterator                                 MFC map
// mfciter::cmap<KEY,VALUE>::iterator/const_iterator        CMap<KEY,ARG_KEY,VALUE,ARG_VALUE> template
// mfciter::tppmap<KEY,VALUE>::iterator/const_iterator      CTypedPtrMap<CMapPtrToPtr, KEY, VALUE> template
//      accessed by functions mfciter::tpp_begin() and mfciter::tpp_end()
// mfciter::tpwmap<KEY,VALUE>::iterator/const_iterator      CTypedPtrMap<CMapPtrToWord, KEY, VALUE> template
//      accessed by functions mfciter::tpw_begin() and mfciter::tpw_end()
// mfciter::tsomap<KEY,VALUE>::iterator/const_iterator      CTypedPtrMap<CMapStringToOb, KEY, VALUE> template
//      accessed by functions mfciter::tso_begin() and mfciter::tso_end()
// mfciter::tspmap<KEY,VALUE>::iterator/const_iterator      CTypedPtrMap<CMapStringToPtr, KEY, VALUE> template
//      accessed by functions mfciter::tsp_begin() and mfciter::tsp_end()
// mfciter::twomap<KEY,VALUE>::iterator/const_iterator      CTypedPtrMap<CMapWordToOb, KEY, VALUE> template
//      accessed by functions mfciter::two_begin() and mfciter::two_end()
// mfciter::twpmap<KEY,VALUE>::iterator/const_iterator      CTypedPtrMap<CMapWordToPtr, KEY, VALUE> template
//      accesesd by functions mfciter::twp_begin() and mfciter::twp_end()
// mfciter::ppmap::iterator/const_iterator                  CMapPtrToPtr
// mfciter::pwmap::iterator/const_iterator                  CMapPtrToWord
// mfciter::somap::iterator/const_iterator                  CMapStringToOb
// mfciter::spmap::iterator/const_iterator                  CMapStringToPtr
// mfciter::ssmap::iterator/const_iterator                  CMapStringToString
// mfciter::womap::iterator/const_iterator                  CMapWordToOb
// mfciter::wpmap::iterator/const_iterator                  CMapWordToPtr
// 
//  The syntax for iterating through an MFC map is very similar to the syntax for
// iterating through a stdc++lib map:
// ex) 
// std::map<int,CFoo> myStdCppLibMap;
// for (std::map<int,CFoo>::iterator ii=myStdCppLibMap.begin(); ii!=myStdCppLibMap.end(); ++ii)
//      ;
// CMap<int,int,CFoo*,CFoo*> myMfcMap;
// for (mfciter::cmap<int,CFoo*>::iterator jj=mfciter::begin(myMfcMap); jj!=mfciter::end(myMfcMap); ++jj)
//      ;
///////////////////////////////////////////////////////////////////////////////*/

#ifndef _INC_MFCITER_MAPITER_H_
#define _INC_MFCITER_MAPITER_H_

#include <iterator>

    // namespace which holds iterators on mfc collections
namespace mfciter
{
////////////////////////////////////////////////////////////////////////////////
// base_map definition/implementation
// non-instantiatable template struct that holds the member types iterator
// and const_iterator.  all template structs derived from this struct specialize
// at least the MAP template parameter.  This struct should not be used on the 
// left hand side of the scope resolution operator when giving the type of an iterator.
// Rather, a struct derived from this struct should be used.
template<class KEY, class VALUE, class MAP>
struct base_map
    {
        // forward declarations
    class _iterator;
    class _const_iterator;
    class _modifiable_value;

        // typedefs/consts for use inside this struct
    typedef std::pair<KEY, VALUE> value_tp;      
    typedef const std::pair<KEY, VALUE> const_value_tp;
    typedef std::pair<const KEY, _modifiable_value> mutable_value_tp;  
    typedef MAP collection_tp;
    typedef POSITION index_tp;
    enum { end_of_sequence=NULL };      // can't use "static const" because vc6 doesn't support that yet.

        // The main typedefs for use outside this struct
    typedef _iterator iterator;                      
    typedef _const_iterator const_iterator;


////////////////////////////////////////////////////////////////////////////////
// base_map<KEY,VALUE,MAP>::_const_iterator definition/implementation
// stdc++lib forward iterator on a MFC map.  Does not allow modification of the
// members that it iterates.  The member m_refRet allows operator*() and operator->()
// to return a reference to the KEY,VALUE pair.  m_pos == NULL means that 
// we are at the end of the iteration sequence.
    class _const_iterator : public std::iterator<std::forward_iterator_tag, value_tp>
        {
    public:
            // CREATORS
        _const_iterator() : 
            m_col(NULL), 
            m_pos(reinterpret_cast<index_tp>(end_of_sequence)) 
            {}
        explicit _const_iterator(const collection_tp &col) : 
            m_col(const_cast<collection_tp *>(&col)),  // const_cast only to allow derived _iterator to mutate the map
            m_pos((col.GetCount()>0) ? col.GetStartPosition() : reinterpret_cast<index_tp>(end_of_sequence))
            {}   
        _const_iterator(const _const_iterator &other) :   // copy all except for m_refRet, as that is not necessary
            m_col(other.m_col),
            m_pos(other.m_pos)
            {}

    public:
            // MODIFIERS
        _const_iterator &operator=(const _const_iterator &other)
            {
                // copy all members except for m_refRet, as that is not necessary
            m_col = other.m_col;
            m_pos = other.m_pos;
            return *this;
            }
        _const_iterator &operator++() 
            {
                // ASSERT:cannot advance through a sequence unless we have a valid 
                // container and are not already pointing to the end of that sequence.
            ASSERT(reinterpret_cast<index_tp>(end_of_sequence) != m_pos);
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

                // Create temporary KEY/VALUE pair on the stack because advancement 
                // through an MFC map requires access to the current KEY/VALUE pair
            KEY k; 
            VALUE v;     
            m_col->GetNextAssoc(m_pos, k, v);
            return *this;
            }
        const _const_iterator operator++(int)
            {
            const _const_iterator ret(*this);
            operator++();
            return ret;
            }

    public:
            // ACCESSORS
        const_value_tp &operator*() const           
            {
                // ASSERT:cannot access a value referred to by an iterator unless
                // we have a valid container and are not already pointing to the end
                // of that sequence.
            ASSERT(reinterpret_cast<index_tp>(end_of_sequence) != m_pos);
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

                // Create a temporary index_tp on the stack because access of an 
                // element of an MFC map requires advancement through the map.
            index_tp posIgnored(m_pos);
            m_col->GetNextAssoc(posIgnored, m_refRet.first, m_refRet.second);
                // m_refRet allows us to return by-reference, rather than returning by-value
            return m_refRet;
            }
        const_value_tp *operator->() const
            {
            return &operator*();
            }

    protected:
            // DATA 
            // All data is protected so derived _iterator can use it.
        collection_tp *m_col;                       // map that we refer to, or NULL for empty iterator
        index_tp m_pos;                             // position in our map, or end_of_sequence
        mutable value_tp m_refRet;                  // for functions that return iterated value by reference.
                                                    // mutable to allow changing in operator* and operator-> const functions

            // Our dear friends
        friend bool operator==(const _const_iterator &i1, const _const_iterator &i2);
        };


////////////////////////////////////////////////////////////////////////////////
// _modifiable_value implementation
// Proxy class that allows the return of operator*()/operator->() from _iterator
// to have the VALUE field (but not the KEY field) modifiable.  The version that does
// work (the MAP/KEY constructor) is only creatable by friend _iterator.  The default
// version is creatable by all clients, so _iterator can have a pair<KEY,_mutate_value_tp> 
// (template pair<> is the constructor).
    class _modifiable_value
        {
    public:
            // CREATORS
        _modifiable_value() : 
            m_col(NULL) 
            {}
    private:
        _modifiable_value(collection_tp &col, const KEY &ky) :      // only version of this object that does actual work.
            m_col(&col), 
            m_key(ky) 
            {}

    public:
            // MODIFIERS
            // proxy function of this class to allow modification of VALUE to flow to the contained MFC map
        _modifiable_value &operator=(const VALUE &val) 
            {
            m_col->SetAt(m_key, val);
            return *this;
            }

            // ACCESSORS
            // These functions make this class acts like a VALUE instance.
        operator const VALUE &() const
            {
            return (*m_col)[m_key];
            }
        const VALUE *operator&() const
            {
            return &(*m_col)[m_key];
            }

    private:
            // DATA 
        collection_tp *m_col;           // referred to map (or NULL)
        KEY m_key;                      // key whose value we might change

            // Our dear friends
        friend class _iterator;      // to allow _iterator to call the private constructor
        };


////////////////////////////////////////////////////////////////////////////////
// _iterator definition/implementation
// ISA _const_iterator (which is a stdc++lib forward iterator).  Allows 
// modification of the VALUE member through the proxy class _modifiable_value.
// KEY is not modifiable because mutable_value_tp has a const KEY type for
// the first parameter.
    class _iterator : public _const_iterator
        {
    public:
        typedef _const_iterator _baseclass;

    public:
            // CREATORS
        _iterator() 
            {}
        explicit _iterator(const collection_tp &col) : 
            _baseclass(col) 
            {}
        _iterator(const _iterator &other) : 
            _baseclass(other)       // don't need to copy m_mutRet member
            {}

    public:
            // MODIFIERS
        _iterator &operator=(const _iterator &other) 
            { 
            _baseclass::operator=(other); 
            return *this; 
            }

        _iterator &operator++() 
            { 
            _baseclass::operator++(); 
            return *this; 
            }
        const _iterator operator++(int) 
            { 
            const _iterator ret(*this); 
            operator++(); 
            return ret; 
            }

    public:
            // ACCESSORS
            // Allows the VALUE parameter to be modified.
            // (both of these are const functions because const-ness means immobile with iterators)
        mutable_value_tp &operator*() const
            {
                // ASSERT:cannot access a value referred to by an iterator unless
                // we have a valid container and are not already pointing to the end
                // of that sequence.
            ASSERT(reinterpret_cast<index_tp>(end_of_sequence) != m_pos);
            ASSERT(AfxIsValidAddress(m_col, sizeof(*m_col), FALSE));

                // Use placement delete and then placement new to change the value in m_mutRet.
                // We cannot use assignment because the returned pair<> has a const KEY field.
                // Without the const KEY field, the caller could modify the KEY member of the return field
            m_mutRet.~pair<const KEY, _modifiable_value>();
            new (&m_mutRet) 
                mutable_value_tp(
                    make_pair(_const_iterator::operator*().first, 
                              _modifiable_value(*m_col, _const_iterator::operator*().first) )
                                  );
            return m_mutRet;
            }
        mutable_value_tp *operator->() const
            {
            return &operator*();
            }

            // operators == and != are "inherited" from baseclass _const_iterator
    private:
        mutable mutable_value_tp m_mutRet;          // Return value from operator*() and operator->() to allow VALUE modification
                                                    // mutable to allow modification in const member function.
        };

private:
        // don't call
    base_map();     
    };


    // freestanding support operators
template<class KEY, class VALUE, class MAP> 
bool operator==(const base_map<KEY,VALUE,MAP>::_const_iterator &i1, const base_map<KEY,VALUE,MAP>::_const_iterator &i2) 
    {
        // return true if both iterators are at the end of a sequence or both have
        // the same value for contained collection and position.
    return 
        (reinterpret_cast<base_map<KEY,VALUE,MAP>::index_tp>(base_map<KEY,VALUE,MAP>::end_of_sequence)==i1.m_pos &&       
         reinterpret_cast<base_map<KEY,VALUE,MAP>::index_tp>(base_map<KEY,VALUE,MAP>::end_of_sequence)==i2.m_pos) ||               
        (i1.m_col==i2.m_col && i1.m_pos==i2.m_pos);
    }
template<class KEY, class VALUE, class MAP> 
bool operator!=(const base_map<KEY,VALUE,MAP>::_const_iterator &i1, const base_map<KEY,VALUE,MAP>::_const_iterator &i2)
    {
    return !operator==(i1, i2);
    }


////////////////////////////////////////////////////////////////////////////////
// cmap definition/implementation
// iterator containing struct used with MFC's CMap<> template 
template<class KEY,class VALUE,class ARG_KEY=KEY, class ARG_VALUE=VALUE>
struct cmap : public base_map<KEY, VALUE, CMap<KEY,ARG_KEY,VALUE,ARG_VALUE> >
    {
private:
    cmap();     // not constructable
    };

    // cmap<> returning freestanding functions
template<class KEY,class VALUE, class ARG_KEY,class ARG_VALUE>
cmap<KEY,VALUE,ARG_KEY,ARG_VALUE>::const_iterator
    begin(const CMap<KEY,ARG_KEY,VALUE,ARG_VALUE> &mp) 
    {
    return cmap<KEY,VALUE,ARG_KEY,ARG_VALUE>::const_iterator(mp);
    }
template<class KEY,class VALUE, class ARG_KEY,class ARG_VALUE>
cmap<KEY,VALUE,ARG_KEY,ARG_VALUE>::iterator
    begin(CMap<KEY,ARG_KEY,VALUE,ARG_VALUE> &mp)
    {
    return cmap<KEY,VALUE,ARG_KEY,ARG_VALUE>::iterator(mp);
    }
template<class KEY,class VALUE, class ARG_KEY,class ARG_VALUE>
cmap<KEY,VALUE,ARG_KEY,ARG_VALUE>::const_iterator
    end(const CMap<KEY,ARG_KEY,VALUE,ARG_VALUE> &)
    {
    return cmap<KEY,VALUE,ARG_KEY,ARG_VALUE>::const_iterator();   
    }
template<class KEY,class VALUE, class ARG_KEY,class ARG_VALUE>
cmap<KEY,VALUE,ARG_KEY,ARG_VALUE>::iterator
    end(CMap<KEY,ARG_KEY,VALUE,ARG_VALUE> &)
    {
    return cmap<KEY,VALUE,ARG_KEY,ARG_VALUE>::iterator();   
    }


////////////////////////////////////////////////////////////////////////////////
// tppmap definition/implementation
// iterator containing struct used with MFC's CTypedPtrMap<CMapPtrToPtr> template.
// The accessor functions are all named tpp_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template<class KEY, class VALUE>
struct tppmap : public base_map<KEY, VALUE, CTypedPtrMap<CMapPtrToPtr, KEY, VALUE> >
    {
private:
    tppmap();   // not constructable
    };

    // tppmap<> returning freestanding functions
template<class KEY,class VALUE>
tppmap<KEY,VALUE>::const_iterator
    tpp_begin(const CTypedPtrMap<CMapPtrToPtr,KEY,VALUE> &mp) 
    {
    return tppmap<KEY,VALUE>::const_iterator(mp);
    }
template<class KEY,class VALUE>
tppmap<KEY,VALUE>::iterator
    tpp_begin(CTypedPtrMap<CMapPtrToPtr,KEY,VALUE> &mp) 
    {
    return tppmap<KEY,VALUE>::iterator(mp);
    }
template<class KEY,class VALUE>
tppmap<KEY,VALUE>::const_iterator
    tpp_end(const CTypedPtrMap<CMapPtrToPtr,KEY,VALUE> &) 
    {
    return tppmap<KEY,VALUE>::const_iterator();
    }
template<class KEY,class VALUE>
tppmap<KEY,VALUE>::iterator
    tpp_end(CTypedPtrMap<CMapPtrToPtr,KEY,VALUE> &) 
    {
    return tppmap<KEY,VALUE>::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// tpwmap definition/implementation
// iterator containing struct used with MFC's CTypedPtrMap<CMapPtrToWord> template.
// The accessor functions are all named tpw_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template<class KEY, class VALUE>
struct tpwmap : public base_map<KEY, VALUE, CTypedPtrMap<CMapPtrToWord, KEY, VALUE> >
    {
private:
    tpwmap();   // not constructable
    };

    // tpwmap<> returning freestanding functions
template<class KEY,class VALUE>
tpwmap<KEY,VALUE>::const_iterator
    tpw_begin(const CTypedPtrMap<CMapPtrToWord,KEY,VALUE> &mp) 
    {
    return tpwmap<KEY,VALUE>::const_iterator(mp);
    }
template<class KEY,class VALUE>
tpwmap<KEY,VALUE>::iterator
    tpw_begin(CTypedPtrMap<CMapPtrToWord,KEY,VALUE> &mp) 
    {
    return tpwmap<KEY,VALUE>::iterator(mp);
    }
template<class KEY,class VALUE>
tpwmap<KEY,VALUE>::const_iterator
    tpw_end(const CTypedPtrMap<CMapPtrToWord,KEY,VALUE> &) 
    {
    return tpwmap<KEY,VALUE>::const_iterator();
    }
template<class KEY,class VALUE>
tpwmap<KEY,VALUE>::iterator
    tpw_end(CTypedPtrMap<CMapPtrToWord,KEY,VALUE> &) 
    {
    return tpwmap<KEY,VALUE>::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// tsomap definition/implementation
// iterator containing struct used with MFC's CTypedPtrMap<CMapStringToOb> template.
// The accessor functions are all named tso_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template<class KEY, class VALUE>
struct tsomap : public base_map<KEY, VALUE, CTypedPtrMap<CMapStringToOb, KEY, VALUE> >
    {
private:
    tsomap();   // not constructable
    };

    // tsomap<> returning freestanding functions
template<class KEY,class VALUE>
tsomap<KEY,VALUE>::const_iterator
    tso_begin(const CTypedPtrMap<CMapStringToOb,KEY,VALUE> &mp) 
    {
    return tsomap<KEY,VALUE>::const_iterator(mp);
    }
template<class KEY,class VALUE>
tsomap<KEY,VALUE>::iterator
    tso_begin(CTypedPtrMap<CMapStringToOb,KEY,VALUE> &mp) 
    {
    return tsomap<KEY,VALUE>::iterator(mp);
    }
template<class KEY,class VALUE>
tsomap<KEY,VALUE>::const_iterator
    tso_end(const CTypedPtrMap<CMapStringToOb,KEY,VALUE> &) 
    {
    return tsomap<KEY,VALUE>::const_iterator();
    }
template<class KEY,class VALUE>
tsomap<KEY,VALUE>::iterator
    tso_end(CTypedPtrMap<CMapStringToOb,KEY,VALUE> &) 
    {
    return tsomap<KEY,VALUE>::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// tspmap definition/implementation
// iterator containing struct used with MFC's CTypedPtrMap<CMapStringToPtr> template.
// The accessor functions are all named tsp_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template<class KEY, class VALUE>
struct tspmap : public base_map<KEY, VALUE, CTypedPtrMap<CMapStringToPtr, KEY, VALUE> >
    {
private:
    tspmap();   // not constructable
    };

    // tspmap<> returning freestanding functions
template<class KEY,class VALUE>
tspmap<KEY,VALUE>::const_iterator
    tsp_begin(const CTypedPtrMap<CMapStringToPtr,KEY,VALUE> &mp) 
    {
    return tspmap<KEY,VALUE>::const_iterator(mp);
    }
template<class KEY,class VALUE>
tspmap<KEY,VALUE>::iterator
    tsp_begin(CTypedPtrMap<CMapStringToPtr,KEY,VALUE> &mp) 
    {
    return tspmap<KEY,VALUE>::iterator(mp);
    }
template<class KEY,class VALUE>
tspmap<KEY,VALUE>::const_iterator
    tsp_end(const CTypedPtrMap<CMapStringToPtr,KEY,VALUE> &) 
    {
    return tspmap<KEY,VALUE>::const_iterator();
    }
template<class KEY,class VALUE>
tspmap<KEY,VALUE>::iterator
    tsp_end(CTypedPtrMap<CMapStringToPtr,KEY,VALUE> &) 
    {
    return tspmap<KEY,VALUE>::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// twomap definition/implementation
// iterator containing struct used with MFC's CTypedPtrMap<CMapWordToOb> template.
// The accessor functions are all named two_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template<class KEY, class VALUE>
struct twomap : public base_map<KEY, VALUE, CTypedPtrMap<CMapWordToOb, KEY, VALUE> >
    {
private:
    twomap();   // not constructable
    };

    // twomap<> returning freestanding functions
template<class KEY,class VALUE>
twomap<KEY,VALUE>::const_iterator
    two_begin(const CTypedPtrMap<CMapWordToOb,KEY,VALUE> &mp) 
    {
    return twomap<KEY,VALUE>::const_iterator(mp);
    }
template<class KEY,class VALUE>
twomap<KEY,VALUE>::iterator
    two_begin(CTypedPtrMap<CMapWordToOb,KEY,VALUE> &mp) 
    {
    return twomap<KEY,VALUE>::iterator(mp);
    }
template<class KEY,class VALUE>
twomap<KEY,VALUE>::const_iterator
    two_end(const CTypedPtrMap<CMapWordToOb,KEY,VALUE> &) 
    {
    return twomap<KEY,VALUE>::const_iterator();
    }
template<class KEY,class VALUE>
twomap<KEY,VALUE>::iterator
    two_end(CTypedPtrMap<CMapWordToOb,KEY,VALUE> &) 
    {
    return twomap<KEY,VALUE>::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// twpmap definition/implementation
// iterator containing struct used with MFC's CTypedPtrMap<CMapWordToPtr> template.
// The accessor functions are all named twp_[function] to deal with an internal
// compiler error discussed in the comments at the top of the file.
template<class KEY, class VALUE>
struct twpmap : public base_map<KEY, VALUE, CTypedPtrMap<CMapWordToPtr, KEY, VALUE> >
    {
private:
    twpmap();   // not constructable
    };

    // twpmap<> returning freestanding functions
template<class KEY,class VALUE>
twpmap<KEY,VALUE>::const_iterator
    twp_begin(const CTypedPtrMap<CMapWordToPtr,KEY,VALUE> &mp) 
    {
    return twpmap<KEY,VALUE>::const_iterator(mp);
    }
template<class KEY,class VALUE>
twpmap<KEY,VALUE>::iterator
    twp_begin(CTypedPtrMap<CMapWordToPtr,KEY,VALUE> &mp) 
    {
    return twpmap<KEY,VALUE>::iterator(mp);
    }
template<class KEY,class VALUE>
twpmap<KEY,VALUE>::const_iterator
    twp_end(const CTypedPtrMap<CMapWordToPtr,KEY,VALUE> &) 
    {
    return twpmap<KEY,VALUE>::const_iterator();
    }
template<class KEY,class VALUE>
twpmap<KEY,VALUE>::iterator
    twp_end(CTypedPtrMap<CMapWordToPtr,KEY,VALUE> &) 
    {
    return twpmap<KEY,VALUE>::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// ppmap definition/implementation
// iterator containing struct used with MFC's CMapPtrToPtr container
struct ppmap : public base_map<void *, void *, CMapPtrToPtr>
    {
private:
    ppmap();    // not constructable
    };

    // ppmap returning freestanding functions
ppmap::const_iterator begin(const CMapPtrToPtr &mp)
    {
    return ppmap::const_iterator(mp);
    }
ppmap::iterator begin(CMapPtrToPtr &mp)
    {
    return ppmap::iterator(mp);
    }
ppmap::const_iterator end(const CMapPtrToPtr &)
    {
    return ppmap::const_iterator();
    }
ppmap::iterator end(CMapPtrToPtr &)
    {
    return ppmap::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// pwmap definition/implementation
// iterator containing struct used with MFC's CMapPtrToWord container
struct pwmap : public base_map<void *, WORD, CMapPtrToWord>
    {
private:
    pwmap();    // not constructable
    };

    // pwmap returning freestanding functions
pwmap::const_iterator begin(const CMapPtrToWord &mp)
    {
    return pwmap::const_iterator(mp);
    }
pwmap::iterator begin(CMapPtrToWord &mp)
    {
    return pwmap::iterator(mp);
    }
pwmap::const_iterator end(const CMapPtrToWord &)
    {
    return pwmap::const_iterator();
    }
pwmap::iterator end(CMapPtrToWord &)
    {
    return pwmap::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// somap definition/implementation
// iterator containing struct used with MFC's CMapStringToOb container
struct somap : public base_map<CString, CObject *, CMapStringToOb>
    {
private:
    somap();    // not constructable
    };

    // somap returning freestanding functions
somap::const_iterator begin(const CMapStringToOb &mp)
    {
    return somap::const_iterator(mp);
    }
somap::iterator begin(CMapStringToOb &mp)
    {
    return somap::iterator(mp);
    }
somap::const_iterator end(const CMapStringToOb &)
    {
    return somap::const_iterator();
    }
somap::iterator end(CMapStringToOb &)
    {
    return somap::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// spmap definition/implementation
// iterator containing struct used with MFC's CMapStringToPtr container
struct spmap : public base_map<CString, void *, CMapStringToPtr>
    {
private:
    spmap();    // not constructable
    };

    // spmap returning freestanding functions
spmap::const_iterator begin(const CMapStringToPtr &mp)
    {
    return spmap::const_iterator(mp);
    }
spmap::iterator begin(CMapStringToPtr &mp)
    {
    return spmap::iterator(mp);
    }
spmap::const_iterator end(const CMapStringToPtr &)
    {
    return spmap::const_iterator();
    }
spmap::iterator end(CMapStringToPtr &)
    {
    return spmap::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// ssmap definition/implementation
// iterator containing struct used with MFC's CMapStringToString container
struct ssmap : public base_map<CString, CString, CMapStringToString>
    {
private:
    ssmap();    // not constructable
    };

    // ssmap returning freestanding functions
ssmap::const_iterator begin(const CMapStringToString &mp)
    {
    return ssmap::const_iterator(mp);
    }
ssmap::iterator begin(CMapStringToString &mp)
    {
    return ssmap::iterator(mp);
    }
ssmap::const_iterator end(const CMapStringToString &)
    {
    return ssmap::const_iterator();
    }
ssmap::iterator end(CMapStringToString &)
    {
    return ssmap::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// womap definition/implementation
// iterator containing struct used with MFC's CMapWordToOb container
struct womap : public base_map<WORD, CObject *, CMapWordToOb>
    {
private:
    womap();    // not constructable
    };

    // womap returning freestanding functions
womap::const_iterator begin(const CMapWordToOb &mp)
    {
    return womap::const_iterator(mp);
    }
womap::iterator begin(CMapWordToOb &mp)
    {
    return womap::iterator(mp);
    }
womap::const_iterator end(const CMapWordToOb &)
    {
    return womap::const_iterator();
    }
womap::iterator end(CMapWordToOb &)
    {
    return womap::iterator();
    }


////////////////////////////////////////////////////////////////////////////////
// wpmap definition/implementation
// iterator containing struct used with MFC's CMapWordToPtr container
struct wpmap : public base_map<WORD, void *, CMapWordToPtr>
    {
private:
    wpmap();    // not constructable
    };

    // wpmap returning freestanding functions
wpmap::const_iterator begin(const CMapWordToPtr &mp)
    {
    return wpmap::const_iterator(mp);
    }
wpmap::iterator begin(CMapWordToPtr &mp)
    {
    return wpmap::iterator(mp);
    }
wpmap::const_iterator end(const CMapWordToPtr &)
    {
    return wpmap::const_iterator();
    }
wpmap::iterator end(CMapWordToPtr &)
    {
    return wpmap::iterator();
    }

}   // end namespace mfciter

#endif  // _INC_MFCITER_MAPITER_H_
