//ex 2)
//-----
// Simple example of iterating over MFC collections
CArray<foo*, foo*> mfc_afoo;
CList<foo*, foo*> mfc_lfoo;
CMap<int,int, foo*,foo*> mfc_mfoo;

for (int aii=0; aii<mfc_afoo.GetSize(); ++aii)
  ;
for (POSITION lpos=mfc_lfoo.GetHeadPosition(); lpos!=NULL; )
  foo *p = mfc_lfoo.GetNext(lpos);

int i;
foo *p;
for (POSITION mpos=mfc_mfoo.GetStartPosition(); 
     mpos!=NULL; 
     mfc_mfoo.GetNextAssoc(mpos, i, p))
  ;


