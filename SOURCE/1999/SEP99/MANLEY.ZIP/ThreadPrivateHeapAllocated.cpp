#include "ThreadPrivateHeapAllocated.h"

DWORD CThreadPrivateHeapAllocated::m_dwTlsIndex = 0xffffffff;

CThreadPrivateHeapAllocated::~CThreadPrivateHeapAllocated() {}


