#include <windows.h>

// -------------------------------------------------------------
// -------------------------------------------------------------
class CThreadPrivateHeapAllocated {
public:

  virtual ~CThreadPrivateHeapAllocated() = 0; 

  void* operator new( size_t size )
    { return alloc( size ); }

  void* operator new[]( size_t size )
    { return alloc( size ); }

  void  operator delete( void* p )
    { dealloc( p ); }
        
  void operator delete[]( void* p )
    { dealloc( p ); }

  static void SetTlsIndex( DWORD dwIndex )
    { m_dwTlsIndex=dwIndex; }
                 
  static DWORD GetTlsIndex() 
    { return m_dwTlsIndex; }
                 
protected:
  static inline void* alloc( size_t size );
  static inline void dealloc( void* p );
  static DWORD m_dwTlsIndex;
};

// -------------------------------------------------------------
// -------------------------------------------------------------
inline void* CThreadPrivateHeapAllocated::alloc( size_t size )
{
  #ifdef _DISABLE_PRIVATE_THREAD_HEAPS
    return ::operator new( size ); 
  #else
    HANDLE hHeap = ::TlsGetValue( m_dwTlsIndex ); 
    return ::HeapAlloc( hHeap, HEAP_NO_SERIALIZE, size );
  #endif
}

// -------------------------------------------------------------
// -------------------------------------------------------------
inline void CThreadPrivateHeapAllocated::dealloc( void* p )
{
  #ifdef _DISABLE_PRIVATE_THREAD_HEAPS
    ::operator delete( p );
  #else
    HANDLE hHeap = ::TlsGetValue( m_dwTlsIndex ); 
    ::HeapFree( hHeap, HEAP_NO_SERIALIZE, p );
  #endif
}


