// sequence.h

#include "deep.h"

class sequence
    {
public:
    // functions to be determined
private:
    struct list_node;
    deep_pointer<list_node> first, last;
    };
