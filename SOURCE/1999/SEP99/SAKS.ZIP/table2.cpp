// table.cpp

#include <stdio.h>
#include <string.h>

#include "deep.h"
#include "table.h"
#include "sequence.h"

struct cross_reference_table::tree_node
    {
    deep_pointer<char> word;
    line_number_sequence lines;
    deep_pointer<tree_node> left, right;
    };

// the rest is the same as in Listing 2
