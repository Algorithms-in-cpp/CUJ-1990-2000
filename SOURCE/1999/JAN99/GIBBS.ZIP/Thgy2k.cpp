#include <string.h>
#include <ctype.h>

/* These two array declarations allow for portability, and
   therefore allow these functions to not rely on the ascii
   character set. */

const char letters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const char digits[] = "0123456789";

/* Compresses the year into two characters and stores it into
   compressed */
void toCompressed( int year, char* compressed )
{
  int century = year / 100;
  year = year - century * 100;
  int decade = year / 10;

  /* If the century is the 20th (1900s) then just store the
     last two digits in a character format. */
  if( century == 19 )
  {
    compressed[0] = digits[ decade ];
    compressed[1] = digits[ year - decade * 10 ];
  }
  /* Else if the century is the 21st(2000s) then change the
     first digit to its corresponding letter and append the last
     digit after converting it to a letter. */
  else if( century == 20 )
  {
    compressed[0] = letters[ decade ];
    compressed[1] = digits [ year - decade * 10 ];
  }
  /* Else if the century is the 22nd(2100s) then change the first
     digit to the letter ten places higher than the 21st
     century's corresponding letter and append the last digit. */
  else if( century == 21 )
  {
    compressed[0] = letters[ decade + 10 ];
    compressed[1] = digits [ year - decade * 10 ];
  }
}

/* Return the year obtained from decompressing a character array
   that was compressed by toCompressed */
int fromCompressed( const char* compressed )
{
  char century = compressed[0];
  int to_return, decade;
  int year = strchr( digits, compressed[1] ) - digits;
  /* If the century was a digit, then it must be the 1900s */
  if( isdigit( century ) )
  {
    decade = strchr( digits, century ) - digits;
    to_return = 1900 + decade * 10 + year;
  }
  else
  {
    decade = strchr( letters, century ) - letters;
    /* If the decade was greater than 10,
       then it was the 2100s */
    if( decade >= 10 )
    {
      to_return = 2100 + ( decade - 10 ) * 10 + year;
    }
    /* Else it was the 2000s */
    else
    {
      to_return = 2000 + decade * 10 + year;
    }
  }
  return to_return;
}
