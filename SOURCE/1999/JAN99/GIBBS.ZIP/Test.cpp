#include <iostream.h>
#include "thgy2k.cpp"

int testyears[] = { 2000, 2015, 2145, 1986, 2053, 1903, 2176,
                    2098, 2076 };
char testcompressed[9][2];
void main()
{
  for( int i = 0; i < 9; i++ )
  {
    toCompressed( testyears[i], testcompressed[i] );
    cout << " YEAR: " << testyears[i] << " GOES TO: " <<
      testcompressed[i] << endl;
    cout << " FROM: " << testcompressed[i] << " TO: " <<
      fromCompressed( testcompressed[i] ) << endl;
  }
  cout << "Press any key to continue.";
  cin.get();
}

