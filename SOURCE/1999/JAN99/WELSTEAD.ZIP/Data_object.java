// File: Data_object.java Data object classes
import java.awt.*;
import Yes_no_radio_dlg;
import TextField_dlg;
     
abstract class Data_object {
        public String descr_str,display_str;
  int display_length;
        Data_object (String the_descr_str,int length) {
                descr_str = the_descr_str;
    display_length = length; }
     
        public String get_value_str() {
                return (String)null; }
     
        public String get_display_str () {
                StringBuffer sb = new StringBuffer();
                sb.append(descr_str).append(": ").
                        append(get_value_str());
          return sb.toString(); }
     
        public void get_new_value(Frame parent) {}
} // end class
     
// Define specific data object types here. In addition
// to the ones shown here, may want to define
// text_object, int_object, color_object, etc.
class Float_object extends Data_object {
        public float value;
        Float_object (float the_value,String the_descr_str,
      int length) {
                super(the_descr_str,length);
                value = the_value;  }
     
        public void get_new_value (Frame parent) {
    Float_dlg fl_dlg = new Float_dlg(parent,descr_str,
      "Edit " + descr_str + ":",value,display_length);
    if (fl_dlg.execute()) // True if user hits 'OK'
                     value = fl_dlg.get_value();
    fl_dlg.dispose();    }
     
        public float get_value() { return value; }
     
        public String get_value_str() {
                return Float.toString(value);   }
} // end class
     
class Boolean_object extends Data_object {
  public boolean value;
  Boolean_object (boolean the_value,
    String the_descr_str) {
                super(the_descr_str,3);
                value = the_value; }
     
        public void get_new_value (Frame parent) {
    Yes_no_radio_dlg  bool_dlg = new Yes_no_radio_dlg(
     parent,descr_str,"Edit " + descr_str + ":",value);
    if (bool_dlg.execute()) // True if user hits 'OK'
       value = bool_dlg.get_state();
    bool_dlg.dispose();   }
     
        public boolean get_value() { return value;      }
     
        public String get_value_str() {
    if (value) return "Yes";
                return "No"; }
}  // end class
     
class Filename_object extends Data_object {
  public String value,init_dir;
  Filename_object (String the_value,
    String the_descr_str,String the_init_dir) {
    super(the_descr_str,10);
                value = the_value;
    init_dir = the_init_dir; }
     
        public void get_new_value (Frame parent) {
     FileDialog file_dlg = new FileDialog (parent,
          descr_str,0);
     file_dlg.setDirectory(init_dir);
     file_dlg.setFile(value);
     file_dlg.show();
     if (file_dlg.getFile() != null) // Cancelled
        value = file_dlg.getDirectory() +
                    file_dlg.getFile();
     init_dir = file_dlg.getDirectory();
     file_dlg.dispose(); }
     
        public String get_value() { return value; }
     
        public String get_value_str() { return value; }
}  // end class
     
class Multiple_data_object {
        public int data_type;
        public Object the_object;
  final static int FLOAT_DATA = 1;
        final static int BOOLEAN_DATA = 2;
        final static int PATH_DATA = 3;
// Add other data types here: TEXT_DATA, INT_DATA, etc.
        Multiple_data_object (float value,String descr,
       int length) {
                data_type = FLOAT_DATA;
                the_object = new Float_object(value,descr,length);}
     
        Multiple_data_object (boolean value,String descr) {
                data_type = BOOLEAN_DATA;
                the_object = new Boolean_object(value,descr);   }
     
  Multiple_data_object (String value,String descr,
       String init_dir) {
                data_type = PATH_DATA;
                the_object = new Filename_object(value,descr,
       init_dir);       }
     
public String get_value_str () {
  switch (data_type){
  case FLOAT_DATA:
  return ((Float_object)the_object).get_value_str();
  case BOOLEAN_DATA:
  return ((Boolean_object)the_object).get_value_str();
  case PATH_DATA:
  return ((Filename_object)the_object).get_value_str();
  } // end switch
  return "Data type not valid";
        }   // end method
     
public void get_new_value (Frame parent) {
  switch (data_type){
  case FLOAT_DATA:
  ((Float_object)the_object).get_new_value(parent);
  return;
  case BOOLEAN_DATA:
  ((Boolean_object)the_object).get_new_value(parent);
  return;
  case PATH_DATA:
  ((Filename_object)the_object).get_new_value(parent);
  return; }
        return; }
     
public String get_display_str () {
  switch (data_type){
  case FLOAT_DATA:
  return ((Float_object)the_object).get_display_str();
  case BOOLEAN_DATA:
  return ((Boolean_object)the_object).get_display_str();
  case PATH_DATA:
  return ((Filename_object)the_object).get_display_str();
  }
        return "Data type not valid"; }  // end method
}  // end class
