// Object_list.java: Maintains an array of Objects.
// Note that the first item in the list as
// has index '1', not '0'.
class Object_list {
   public Object[] the_list;
   public int item_count;
   public int max_count;
     
Object_list (int max_items) {
      the_list = new Object[max_items+1];
      max_count = max_items;
      item_count = 0; }
     
 int add_item (Object item) {
    if (item_count >= max_count) return 0;
    the_list[item_count + 1] = item;
    item_count++;
    return item_count; }
     
/* A more useful version of this class
   would include insert_item(int index,Object item)
   and delete_item(int index) methods. However,
   we don't need them for this example. */
     
  Object at (int index) {
    if (index <= 0) return null;
    if (index > item_count) return null;
    return (Object)the_list[index]; }
     
  int get_count () {
    return item_count; }
}  // end class
