// Yes_no_radio_dlg.java Yes/no checkbox dialog
import java.awt.*;
import Standard_dlg;
     
class Yes_no_radio_dlg extends Standard_dlg {
        CheckboxGroup cbg = new CheckboxGroup();
        Checkbox yes_box,no_box;
        public boolean answer_is_yes;
     
        Yes_no_radio_dlg(Frame f,String title,
                        String s,boolean init_state) {
                super((Frame) f,title,s);
                Label blank = new Label("  ");
                Panel east_panel = new Panel();
                Panel west_panel = new Panel();
                Panel choice_panel = new Panel();
                answer_is_yes = init_state;
                east_panel.add(blank);
                west_panel.add(blank);
                choice_panel.setLayout(new GridLayout(2,1));
                choice_panel.add(yes_box =
         new Checkbox("Yes",cbg,answer_is_yes));
                choice_panel.add(no_box =
         new Checkbox("No",cbg,!answer_is_yes));
                add("East",east_panel);
                add("Center",choice_panel);
                add("West",west_panel);
                pack(); }
     
  public void ok_response () {
    if (cbg.getSelectedCheckbox() == yes_box)
                                answer_is_yes = true;
    else answer_is_yes = false;
        super.ok_response();
    return; }   // end method
     
  public void cancel_response () {
    // Reset the Checkboxes to previous values:
    if (answer_is_yes) {
       yes_box.setState(true);
       no_box.setState(false); } // end if
    else {
       yes_box.setState(false);
       no_box.setState(true); }  // end else
    super.cancel_response(); }   // end method
     
        public boolean get_state() {
                return answer_is_yes;   }
}  // end class
