// Standard_dlg.java  Standard dialog class
import java.awt.*;
import java.awt.event.*;

class Standard_dlg extends Dialog {
        public Label label;
        Button ok_button, cancel_button;
        Frame parent;
        public boolean response = true;
        Panel label_panel, button_panel;
        Standard_dlg(Frame f,String title,
                       String label_string) {
                super((Frame) f,title,true);
                label = new Label();
    ok_button = new Button("OK");
    cancel_button = new Button("Cancel");
    label_panel = new Panel();
    button_panel = new Panel();
                parent = f;
                // Put a little extra space between components:
                setLayout (new BorderLayout(8,8));
                label_panel.setLayout(new FlowLayout
                                 (FlowLayout.LEFT));
                label_panel.add(label);
                button_panel.setLayout(new FlowLayout());
    button_panel.add(ok_button);
                button_panel.add(cancel_button);
                add("North",label_panel);
                add("South",button_panel);
                label.setText(label_string);
    ok_button.addActionListener(new Ok_listener(this));
    cancel_button.addActionListener
                       (new Cancel_listener(this));
    }
  // Define "OK" and "Cancel" behavior here. Override
  // these methods in descendant classes, so we don't
  // have to deal with ActionListener's in descendant
  // dialog classes.
  public void ok_response () {
      response = true;
      setVisible(false); }
     
  public void cancel_response () {
                        response = false;
      setVisible(false); }
     
  public boolean execute () {
    setVisible(true);
                return response; }
}  // end class
     
class Ok_listener implements ActionListener {
  Standard_dlg std_dlg;
  Ok_listener (Standard_dlg the_dlg) {
    std_dlg = the_dlg; }
     
  public void actionPerformed (ActionEvent e) {
     std_dlg.ok_response();
     return; }
  }  // end class
     
class Cancel_listener implements ActionListener {
  Standard_dlg std_dlg;
  Cancel_listener (Standard_dlg the_dlg) {
    std_dlg = the_dlg; }
     
  public void actionPerformed (ActionEvent e) {
     std_dlg.cancel_response();
     return; }
  }  // end class
