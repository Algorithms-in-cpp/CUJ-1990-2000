// Textfield_dlg.java Input dialog with textfield
import java.awt.*;
import Standard_dlg;

class TextField_dlg extends Standard_dlg {
        TextField fld;
        String value_str;

        TextField_dlg(Frame f,String title,
                        String s,String init_string,int length) {
                super((Frame) f,title,s);
                Panel field_panel = new Panel();
                field_panel.setLayout(new FlowLayout());
                fld = new TextField(init_string,length);
                value_str = init_string;
                field_panel.add(fld);
                add("Center",field_panel);
                pack(); }
     
  public /* boolean */ void ok_response () {
    value_str = fld.getText();
    /* return */ super.ok_response(); }
     
  public /* boolean */ void cancel_response () {
    fld.setText(value_str);
    /* return */ super.cancel_response(); }
}  // end class
     
// Define dialogs for specific object types here:
class Float_dlg extends TextField_dlg {
    float value;
    Float_dlg(Frame f,String title,String s,
      float init_value,int length) { super(f,title,
              s,Float.toString(init_value),length);
                value = init_value;     }
     
  public void ok_response () {
    String input_str = fld.getText();
    try {value =
           Float.valueOf(input_str).floatValue();}
    catch (NumberFormatException e) {
      System.err.println("Float_dlg: " +
           "Non-numeric input string: " + input_str);
      fld.setText(value_str);
      return; } // end catch
    super.ok_response();
    return; }  // end ok_response
     
        public float get_value() {
                return value; }
}  // end class
