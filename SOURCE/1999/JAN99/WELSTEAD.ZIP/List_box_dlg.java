// List_box_dlg.java  List box dialogs
import java.awt.*;
import java.awt.event.*;
import Standard_dlg;
import Object_list;
import Data_object;
     
class List_box_dlg extends Standard_dlg {
        static List list;
        Object_list obj_list;
        public int init_item,selected_item;
        List_box_dlg(Frame f,String title,
                        String label_string,Object_list the_obj_list,
                        int scroll_size,int the_init_item) {
                super((Frame) f,title,label_string);
                Panel list_panel = new Panel(new FlowLayout());
                obj_list = the_obj_list;
                list = new List (scroll_size, false);
                init_item = the_init_item;
    selected_item = the_init_item;
    for (int i=0;i<obj_list.get_count();i++)
                    list.addItem (get_item_string(i+1));
                list.select(init_item-1);
                list.makeVisible(init_item-1);
    list_panel.add(list);
                add("Center",list_panel);
                pack(); }
     
  public void ok_response () {
    selected_item = list.getSelectedIndex()+1;
    super.ok_response(); }
     
        public int get_selected () {
                return selected_item;   }
     
        public String get_item_string(int i) {
                // Assumes object items are strings.
                // Override this for more complex items.
                return (String)obj_list.at(i); }
}  // end class
     
class Data_list_dlg extends List_box_dlg {
        Data_list_dlg(Frame f,String title,
                        String label_string,Object_list the_obj_list,
                        int scroll_size,int the_init_item) {
    super(f,title,label_string,the_obj_list,
        scroll_size,the_init_item);
    list.addActionListener(new List_action (this));}
     
        public String get_item_string(int i) {
                return ((Multiple_data_object)obj_list.at(i)).
               get_display_str(); }
}  // end class
     
class List_action implements ActionListener {
  Data_list_dlg dlg;
  public List_action (Data_list_dlg the_dlg) {
     dlg = the_dlg; }
// This defines the response to a double-click action:
  public void actionPerformed (ActionEvent e) {
    int selected = dlg.list.getSelectedIndex()+1;
    ((Multiple_data_object)(dlg.obj_list.
        at(selected))).get_new_value(dlg.parent);
    dlg.list.replaceItem(
        dlg.get_item_string(selected),selected - 1);
    dlg.list.select(selected-1);
    return; }
  } // end class
