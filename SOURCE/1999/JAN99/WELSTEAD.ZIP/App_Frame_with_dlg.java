// App_Frame_with_dlg Frame window for application
import java.awt.*;
import List_box_dlg;
import Data_object;

class App_Frame_with_dlg extends Frame {
        private Data_list_dlg the_list_dlg;
        public Object_list obj_list;
        public boolean list_dlg_response = true;
  private MenuBar the_MenuBar;
  private Object selected_menu_item;

  App_Frame_with_dlg() {
     super("Test List Dialog Frame");
     the_MenuBar = new MenuBar();
     Menu file_menu = new Menu("File");
     file_menu.add(new MenuItem("Exit"));
     the_MenuBar.add(file_menu);
     Menu edit_menu = new Menu("Edit");
     edit_menu.add(new MenuItem("Setup..."));
     the_MenuBar.add(edit_menu);
     setMenuBar(the_MenuBar);

                 int no_of_list_items = 6, scroll_size = 4,
         init_item = 1,float_display_size = 5;
     obj_list = new Object_list(no_of_list_items);

     for (int i=1;i<=4;i++)
         obj_list.add_item( new Multiple_data_object(
       (float)(i+0.5),"Float #",float_display_size));

     obj_list.add_item(
                        new Multiple_data_object(true,"Answer is"));

     obj_list.add_item(
        new Multiple_data_object("filename.dat",
              "Input File","C:\\"));

                 the_list_dlg = new Data_list_dlg (this,
      "List Dialog","Sample data object list dialog:",
      obj_list,scroll_size,init_item); }

  public boolean action(Event event, Object obj) {
     selected_menu_item = obj;
     if (selected_menu_item == "Exit") {
        dispose();
        System.exit(0);
        return true; }
     if (selected_menu_item == "Setup...")
        list_dlg_response = the_list_dlg.execute();
        repaint();
        return true; }

  public void paint(Graphics g) {
     String s1 = "No menu item selected", s2 = " ";
     if (selected_menu_item == "Setup...") {
        if (list_dlg_response) {
          int item = the_list_dlg.get_selected();
          s1 = "List Box Item #" + item + " selected.";
          s2 = ((Multiple_data_object)the_list_dlg.
                obj_list.at(item)).get_display_str(); }
        else {
           s1 = "List Box canceled.";
           s2 = " "; }  // end else
        } // end if
     // Center the string in the window:
     Dimension dim_window = getSize();
     FontMetrics fm = getFontMetrics(getFont());
     int string_height = fm.getHeight();
     int s1_width  = fm.stringWidth(s1);
     int s2_width  = fm.stringWidth(s2);
     int max_width = s1_width;
     if (max_width < s2_width) max_width = s2_width;
     int left_offset = (dim_window.width-max_width)/2;
     int top_offset=(dim_window.height+string_height)/2;
     g.drawString(s1,left_offset,top_offset);
     g.drawString(s2,left_offset,top_offset +
          2*string_height); }
}  // end class
