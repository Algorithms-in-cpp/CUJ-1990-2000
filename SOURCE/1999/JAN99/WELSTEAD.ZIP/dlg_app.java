// dlg_app.java  Frame with dialog application
import java.awt.*;
import App_Frame_with_dlg;
     
public class dlg_app {
        public static void main(String[] args) {
        App_Frame_with_dlg app_frame;
        app_frame = new App_Frame_with_dlg();
  app_frame.setSize(400,200); // Pick arbitrary size
        app_frame.show(); }
}  // end class
