package com.crosoft.iom;

import com.crosoft.iom.SwitchBoardListener;

public class SubscriberHookup
{
    private String              _subscription; // subscribed to
    private SwitchBoardListener _subscriber;   // who is listening

    public 
    SubscriberHookup(String subscription, 
        SwitchBoardListener subscriber)
    {
        _subscription = subscription;
        _subscriber   = subscriber;
    }

    public final String getSubscription() 
    { return(_subscription); }
    public final SwitchBoardListener getSubscriber() 
    { return(_subscriber);   }
}
