package com.crosoft.iom;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import com.crosoft.iom.SwitchBoardListener;
import com.crosoft.iom.SubscriberHookup;



public class SwitchBoard
{
    private static SwitchBoard _instance = null; // singleton 
                                                 // handle
    private Hashtable          _subscriptions = new Hashtable();


    // -- singleton management ---------------------------------
    ////
    private SwitchBoard()
    {
        _instance = this;  // save the singleton handle
    }

    public static SwitchBoard instance()
    {
        if (_instance == null)
            _instance = new SwitchBoard();
        return(_instance);
    }


    // -- utilities --------------------------------------------
    ////
    protected Vector _getSubscriberHookups(String subscription)
    {
        Vector hookups = (Vector)_subscriptions.get(subscription);
        if (hookups == null)
        {
            // create a new entry for this subscription
            hookups = new Vector();
            _subscriptions.put(subscription, hookups);
        }
        return(hookups);
    }


    // -- subscription management ------------------------------
    ////
    public static SubscriberHookup 
    subscribeTo(String subscription, SwitchBoardListener listener)
    {
        SwitchBoard self = instance();
        Vector hookups = self._getSubscriberHookups(subscription);
        SubscriberHookup hookup = 
            new SubscriberHookup(subscription, listener);
        hookups.addElement(hookup);
        return(hookup);
    }

    public static void 
    unsubscribeFrom(String subscription, 
        SwitchBoardListener listener)
    {
        SwitchBoard self = instance();
        Vector hookups = self._getSubscriberHookups(subscription);
        for (Enumeration e = hookups.elements(); 
             e.hasMoreElements(); )
        {
            SubscriberHookup hookup = 
                (SubscriberHookup)e.nextElement();
            // find all the instances of a listener and remove 
            // them for this subscription
            if (hookup.getSubscriber() == listener)
                hookups.removeElement(hookup);
        }
    }

    public static void unsubscribe(SubscriberHookup hookup)
    {
        unsubscribeFrom(hookup.getSubscription(), 
            hookup.getSubscriber());
    }


    // -- notification (message deliver) -----------------------
    ////
    public static boolean notify(String subscription)
    {
        boolean delivered = false;
        SwitchBoard self = instance();
        Vector hookups = 
            (Vector)self._subscriptions.get(subscription);
        if (hookups != null)
        for (Enumeration e = hookups.elements(); 
             e.hasMoreElements(); )
        {
            ((SubscriberHookup)e.nextElement()).
                getSubscriber().deliver(subscription);
            delivered = true;
        }
        return(delivered);
    }

    public static boolean notify(String subscription, String msg)
    {
        boolean delivered = false;
        SwitchBoard self = instance();
        Vector hookups = 
            (Vector)self._subscriptions.get(subscription);
        if (hookups != null)
            for (Enumeration e = hookups.elements(); 
                 e.hasMoreElements(); )
            {
                ((SubscriberHookup)e.nextElement()).
                    getSubscriber().deliver(subscription, msg);
                delivered = true;
            }
        return(delivered);
    }

    public static boolean notify(String subscription, Object obj)
    {
        boolean delivered = false;
        SwitchBoard self = instance();
        Vector hookups = 
            (Vector)self._subscriptions.get(subscription);
        if (hookups != null)
            for (Enumeration e = hookups.elements(); 
                 e.hasMoreElements(); )
            {
                ((SubscriberHookup)e.nextElement()).
                    getSubscriber().deliver(subscription, obj);
                delivered = true;
            }
        return(delivered);
    }
}

// End of File SwitchBoard.java

