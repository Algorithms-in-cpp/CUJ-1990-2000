package com.crosoft.iom;

public interface SwitchBoardListener
{
  public void deliver(String subscription);
  public void deliver(String subscription,
                      Object client_data);
  public void deliver(String subscription, 
                      String client_data);
}


public class SwitchBoardAdapter implements   
  SwitchBoardListener
{
  public void deliver(String subscription) { }
  public void deliver(String subscription, 
                      Object client_data) { }
  public void deliver(String subscription,
                      String client_data) { }
}
