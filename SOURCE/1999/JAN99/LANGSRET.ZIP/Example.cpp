#include <afxwin.h>
#include "WordStream.hpp"
#include <objbase.h> // defines CoInitialize and CUninitialize

void DoExample();

int main()
{
	HRESULT res = CoInitialize(NULL);
	if (!SUCCEEDED(res))
		return 1;
	DoExample();
	CoUninitialize();
	return 0;
}

void DoExample()
{
	CWordStream Example;
	Example.SetUnderLine(WSTR_UL_SINGLE );
	Example.SetBold(TRUE);
	Example.SetJustification(WSTR_JU_CENTER );
	Example.SetItalic(FALSE);
	Example.AddText("Single underline, bold, centered, no italics\n\n");
	Example.SetUnderLine( WSTR_UL_NONE );
	Example.SetBold(FALSE);
	Example.SetJustification(WSTR_JU_LEFT);
	Example.AddText("Left justified, not bold, not italic\n");
	Example.SaveAs("c:\\example.doc");
}