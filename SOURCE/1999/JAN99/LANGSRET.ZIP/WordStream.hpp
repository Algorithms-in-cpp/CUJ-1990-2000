//
// Listing 2 - WordStream.hpp
//
#ifndef _WSTR_
#define _WSTR_

const UINT WSTR_UL_NONE = 0;
const UINT WSTR_UL_SINGLE = 1;
const UINT WSTR_UL_DOUBLE = 2;
const UINT WSTR_UL_THICK = 3;

const UINT WSTR_OKAY = 0;
const UINT WSTR_FAIL = 1;

const UINT WSTR_JU_CENTER = 0;
const UINT WSTR_JU_RIGHT = 1;
const UINT WSTR_JU_LEFT = 2;
const UINT WSTR_JU_RIGHTLEFT=3;

class CWordStream {
	protected:
		UINT m_nUnderLine;
		UINT m_nJustification;
		BOOL m_bBold;
		BOOL m_bItalic;
		IUnknown *m_pUnknown;
		BOOL m_bError;
		CString m_szError;
		float m_fFontSize;
	public:
		CWordStream();
		~CWordStream();
		UINT AddText( const CString &str );
		UINT SetUnderLine( UINT underlinetype );
		UINT SetJustification( UINT justifytype );
		UINT SetBold(BOOL bold);
		UINT SetItalic(BOOL italic);
		UINT SaveAs( const CString &str );
		UINT PrintOut();
		float GetFontSize();
		void SetFontSize(float usesize);
};

#endif