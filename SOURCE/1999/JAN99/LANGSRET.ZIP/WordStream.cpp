//
// Listing 1 - WordStream.cpp
//

#include <afxwin.h>
#import "mso97.dll" no_namespace rename\
	("DocumentProperties", "DocumentPropertiesXL")
#import "vbeext1.olb" no_namespace
#import "ven2232.olb"  
#import "msword8.olb" rename\
	("ExitWindows","ExitWindowsWRD")
using namespace Word;
#include "WordStream.hpp"

WdUnderline mapUnderLineCodes[] = {
	wdUnderlineNone,
	wdUnderlineSingle,
	wdUnderlineDouble,
	wdUnderlineThick};

WdParagraphAlignment mapJustificationCodes[] = {
	wdAlignParagraphCenter,
	wdAlignParagraphRight,
	wdAlignParagraphLeft,
	wdAlignParagraphJustify};

CWordStream::CWordStream()
{
	m_nUnderLine = WSTR_UL_NONE;
	m_nJustification = WSTR_JU_CENTER;
	m_bBold = FALSE;
	m_bItalic = FALSE;
	INT nLastSize = 0;
	INT nCurrentSize = 0;

    _Document *pDoc=NULL;
    REFCLSID clsid = __uuidof(Document);
    REFIID iid = __uuidof(_Document);
	
	// Create an empty Word document; the
	// result is an interface of type _Document.
    HRESULT res = CoCreateInstance(
					clsid, 
					NULL,
					CLSCTX_LOCAL_SERVER,
					iid,
					(void**)&pDoc);

    if (SUCCEEDED(res)) {
		m_pUnknown = NULL;
		REFIID iid2 = __uuidof(IUnknown);
		// Retrieve an IUnknown pointer to the object.
		res = pDoc->QueryInterface(iid2,(void**)&m_pUnknown);
		if (!SUCCEEDED(res)) {
			m_bError = TRUE;
			m_szError = _T("Cannot get IUnknown interface.");
		}
		m_fFontSize = pDoc->GetContent()->GetFont()->GetSize();
	} else {
		m_bError = TRUE;
		m_szError = _T("Cannot create document object.");
	}
}

CWordStream::~CWordStream()
{
	_Document *pDoc=NULL;
    REFIID iid = __uuidof(_Document);
	// Retrieve a _Document interface 
	// using the saved IUnknown interface.
    HRESULT res;
	res = m_pUnknown->QueryInterface(iid,(void**)&pDoc);
	ASSERT(SUCCEEDED(res));
	if (!m_bError)	{
		_variant_t doNotSaveDocument(long(wdDoNotSaveChanges),VT_I4 );
		_variant_t docWordFormat(long(wdWordDocument),VT_I4);
		_variant_t dontRouteDocument(long(0),VT_I4);
		pDoc->Close(
			&doNotSaveDocument,
			&docWordFormat,
			&dontRouteDocument);
		m_pUnknown->Release();
	}
}

UINT CWordStream::AddText( const CString &str )
{
	_Document *pDoc=NULL;
    REFIID iid = __uuidof(_Document);
    HRESULT res;
	res = m_pUnknown->QueryInterface(iid,(void**)&pDoc);
    if (!SUCCEEDED(res)) {
		m_bError = TRUE;
		m_szError = _T("Error getting _Document interface.");
		return WSTR_FAIL;
	}
				
	// Define a range containing the entire document
	RangePtr range = pDoc->GetContent();
	bstr_t bstr = str;
	LONG nLastSize = range->GetStoryLength()-1;
	// Add the string to the end of the document.
	range->InsertAfter(bstr);
	LONG nCurrentSize = range->GetStoryLength()-1;
	_variant_t vbegin( nLastSize,    VT_I4 );
	_variant_t vend  ( nCurrentSize, VT_I4 );
	// Define a range containing the text just inserted.
	range = pDoc->Range(&vbegin,&vend);
	// Set attributes on the range.
    range->PutItalic(m_bItalic);
    range->PutBold(m_bBold);
	range->PutUnderline(mapUnderLineCodes[m_nUnderLine]);
	range->GetFont()->PutSize(m_fFontSize);
	// We need a ParagraphFormat object to define the text
	// alignment.
    _ParagraphFormatPtr pformat = range->GetParagraphFormat();
    pformat->PutAlignment(
		mapJustificationCodes[m_nJustification]);

	return WSTR_OKAY;
}

UINT CWordStream::SetUnderLine( UINT underlinetype )
{
	if ( underlinetype <= WSTR_UL_THICK ) {
		m_nUnderLine = underlinetype;
		return WSTR_OKAY;
	}
	m_szError = _T("Invalid underline type.");
	m_bError = TRUE;
	return WSTR_FAIL;
}

UINT CWordStream::SetJustification( UINT justifytype )
{
	if ( justifytype <= WSTR_JU_RIGHTLEFT ) {
		m_nJustification = justifytype;
		return WSTR_OKAY;
	}
	m_szError = _T("Invalid justification type.");
	m_bError = TRUE;
	return WSTR_FAIL;
}

UINT CWordStream::SetBold(BOOL bold)
{
	m_bBold = bold;
	return WSTR_OKAY;
}

UINT CWordStream::SetItalic(BOOL italic)
{
	m_bItalic = italic;
	return WSTR_OKAY;
}

UINT CWordStream::SaveAs( const CString &str )
{
	_Document *pDoc=NULL;
    REFIID iid = __uuidof(_Document);
    HRESULT res;
	res = m_pUnknown->QueryInterface(iid,(void**)&pDoc);
    if (!SUCCEEDED(res)) {
		m_bError = TRUE;
		m_szError = _T("Error getting _Document interface.");
		return WSTR_FAIL;
	}

	_variant_t filename ( str );
	res = pDoc->SaveAs( &filename );
	if (SUCCEEDED(res))
		return WSTR_OKAY;
	m_bError = TRUE;
	m_szError = _T("SaveAs failed.");
	return WSTR_FAIL;
}

UINT CWordStream::PrintOut()
{
	_Document *pDoc=NULL;
    REFIID iid = __uuidof(_Document);
    HRESULT res;
	res = m_pUnknown->QueryInterface(iid,(void**)&pDoc);
    if (!SUCCEEDED(res)) {
		m_bError = TRUE;
		m_szError = _T("Error getting _Document interface.");
		return WSTR_FAIL;
	}
    _variant_t doNotBackgroundPrint(long(0),VT_I4);
    pDoc->PrintOut(&doNotBackgroundPrint);
	return WSTR_OKAY;
}

float CWordStream::GetFontSize()
{
	_Document *pDoc=NULL;
    REFIID iid = __uuidof(_Document);
    HRESULT res;
	res = m_pUnknown->QueryInterface(iid,(void**)&pDoc);
    if (!SUCCEEDED(res)) {
		return 0.0;
	}
	RangePtr range = pDoc->GetContent();
	_FontPtr font = range->GetFont();
	float ret = font->GetSize();
	return ret;
}

void CWordStream::SetFontSize(float usesize)
{
	m_fFontSize = usesize;
}
