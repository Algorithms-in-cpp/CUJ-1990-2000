The following files from the Office 97 distribution are required to
build this code. They should be copied to the workspace directory:

07/11/97  06:00p             3,782,416 MSO97.DLL
11/17/96  03:00p               459,776 MSWORD8.OLB
11/17/96  03:00p                31,744 VBEEXT1.OLB

The following file is also required but should be found
automatically by the compiler:

07/11/97  01:00a                37,376 VEN2232.OLB


