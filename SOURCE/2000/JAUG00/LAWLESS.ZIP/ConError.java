// Jim Lawless -jimbo@radiks.net

// ConError is a subclass of ErrorBase which will
// display error messages on the console screen.

public class ConError extends ErrorBase {
   public void display(String s) {
      System.out.println("Error: " + s );
   }
}
