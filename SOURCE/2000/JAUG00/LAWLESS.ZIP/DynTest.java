// Jim Lawless - jimbo@radiks.net

// This program will dynamically utilize the ConError 
// or GUIError objects as defined by the property
// file "DynTest.prop".

import java.io.*;
import java.util.Properties;

public class DynTest {
   public static void main(String[] args) {
      Properties props=new Properties();
      
          // load property settings.
      try {
         props.load( new FileInputStream(
            new File("DynTest.prop")));
      }
      catch(IOException x) {
         System.err.println(
            "Unable to open property file.");
         System.exit(1);
      }

      String s=(String) props.get("ErrorDriver");

         // create generic reference to ErrorBase
         // family using the base class.

      ErrorBase e=null;

         // Dynamically load the class and instantiate
         // an object
      try {
         e=(ErrorBase)
            Class.forName(s).newInstance();
      }
      catch(ClassNotFoundException x) {
         System.err.println("Class not found.");
         System.exit(1);
      }
      catch(InstantiationException x) {
         System.err.println("Can't create object.");
         System.exit(1);
      }
      catch(IllegalAccessException x) {
         System.err.println("Access violation.");
         System.exit(1);
      }

         // Display error message
      e.display("This is a dynamic message.");
      System.exit(0);

   }
}
