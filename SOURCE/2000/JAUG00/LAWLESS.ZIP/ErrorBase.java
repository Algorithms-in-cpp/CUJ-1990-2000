// Jim Lawless - jimbo@radiks.net

// ErrorBase is an abstract base class for our
// error message driver architecture.

public abstract class ErrorBase {
   public abstract void display(String s);
}
