// Jim Lawless - jimbo@radiks.net

// ErrTest will test both the ConError
// class and the GUIError class.

public class ErrTest {
   public static void main(String[] args) {
      ConError c=new ConError();
      GUIError g=new GUIError();

      c.display("This is a console message.");
      g.display("This is a GUI message.");

      System.exit(0);
   }
}
