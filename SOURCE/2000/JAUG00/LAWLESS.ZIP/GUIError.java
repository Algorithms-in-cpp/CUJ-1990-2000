// Jim Lawless - jimbo@radiks.net

// GUIError is a subclass of ErrorBase which displays
// error message strings in a Swing GUI message box.

import javax.swing.*;

public class GUIError extends ErrorBase {
   public void display(String s) {
      JOptionPane.showMessageDialog(null,
          "Error: " + s);
   }
}
