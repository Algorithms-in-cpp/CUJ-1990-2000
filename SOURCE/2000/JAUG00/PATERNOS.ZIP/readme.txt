SYNCHRONIZING THREADS

An excerpt from the javadoc documentation for the Component class's repaint() method reveals a potential problem:

"This method causes a call to this component's update method as soon as possible."

The key phrase here is "as soon as possible." Because animation threads run in a continuous tight loop, the system thread (the thread processing your program's events) bundles multiple successive repaint() requests together so that only the most current repaint() method is executed. This bundling results in jerky animations. One way to prevent this is by calling the Thread class's sleep() method after issuing a repaint(). This slows the animation thread down enough to prevent the bundling of repaint() requests. However, because the sleep() method requires a long indicating the number of milliseconds to sleep, finding the ideal number is problematic (your program will run on different processors and operating systems which may need to use a different number). Ideally you need to synchronize the animation thread and the system thread:

public synchronized void run()
{
    while(<condition true>)
    {
        //effect change
        repaint();
        try
        {
            wait();
            Thread.sleep(10); //optional
        }
        catch(InterrupedException ie)
        {
            //no op
        }
    }
}

public void paint(Graphics g)
{
    //drawing operations
    synchronized(this)
    {
        notifyAll();
    }
}

After the repaint() method is called the animation thread goes into a wait state via a call to the Object class's wait() method. The animation thread cannot continue until all the paint() method's drawing operations are completed and the Object class's notifyAll() method is called to wake the animation thread. The sleep() method is optional and is included to prevent the animation program from monopolizing the processor.
