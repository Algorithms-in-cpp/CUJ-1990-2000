// QMonitor.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "QMonitor.h"
#include "QMonitorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#pragma data_seg("Shared")
LONG UsageCount = -1;
#pragma data_seg()
#pragma comment(linker,"/section:Shared,rws")

int nPort;

/////////////////////////////////////////////////////////////////////////////
// CQMonitorApp

BEGIN_MESSAGE_MAP(CQMonitorApp, CWinApp)
	//{{AFX_MSG_MAP(CQMonitorApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
//	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQMonitorApp construction

CQMonitorApp::CQMonitorApp()
{
	InterlockedIncrement((PLONG)&UsageCount);
}

CQMonitorApp::~CQMonitorApp()
{
	InterlockedDecrement((PLONG)&UsageCount);
}
/////////////////////////////////////////////////////////////////////////////
// The one and only CQMonitorApp object

CQMonitorApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CQMonitorApp initialization

BOOL CQMonitorApp::InitInstance()
{
	HWND hWnd = FindWindow(NULL, _T("QMonitor"));
	if (UsageCount == 1 || hWnd != NULL)
	{
		::SetForegroundWindow(hWnd);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

    nPort = theApp.GetProfileInt(_T("TCP/IP"), _T("Port"), 5001);

	CQMonitorDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();
	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
