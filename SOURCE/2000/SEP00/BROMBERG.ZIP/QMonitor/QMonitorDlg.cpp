// QMonitorDlg.cpp : implementation file
// Author: Boris Bromberg
// Created 24/8/99

#include "stdafx.h"
#include "QMonitor.h"
#include "QMonitorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAX_LINES 4096

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CQMonitorDlg dialog

CQMonitorDlg::CQMonitorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CQMonitorDlg::IDD, pParent),
	  m_BrowseOn(false)
{
	//{{AFX_DATA_INIT(CQMonitorDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CQMonitorDlg::~CQMonitorDlg()
{
}

void CQMonitorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQMonitorDlg)
	DDX_Control(pDX, IDC_LIST_VIEW, m_TextCtrl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CQMonitorDlg, CDialog)
	//{{AFX_MSG_MAP(CQMonitorDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_COPYDATA()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQMonitorDlg message handlers

BOOL CQMonitorDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	ASSERT((IDM_SAVE & 0xFFF0) == IDM_SAVE);
	ASSERT(IDM_SAVE < 0xF000);

	ASSERT((IDM_BROWSE & 0xFFF0) == IDM_BROWSE);
	ASSERT(IDM_BROWSE < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
		CString strSaveMenu,
			    strBrowseMenu,
				strClearMenu;
		strSaveMenu.LoadString(IDS_SAVE);
		strBrowseMenu.LoadString(IDS_BROWSE);
		strClearMenu.LoadString(IDS_CLEAR);
		if (!strSaveMenu.IsEmpty() && !strBrowseMenu.IsEmpty() && !strClearMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_SAVE, strSaveMenu);
			pSysMenu->AppendMenu(MF_STRING | MF_UNCHECKED, IDM_BROWSE, strBrowseMenu);
			pSysMenu->AppendMenu(MF_STRING, IDM_CLEAR, strClearMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

// Prepare window control rectangle attributes
// for future resizing
	RECT rc;
	GetClientRect(&rc);
	m_dx2  = rc.right;
	m_dy2  = rc.bottom;
	m_TextCtrl.GetWindowRect(&rc);
	ScreenToClient(&rc);
	m_dx1  = rc.left;
	m_dy1  = rc.top;
	m_dx2 -= rc.right;
	m_dy2 -= rc.bottom;
	m_LinesPerPage = rc.bottom - rc.top;
	m_TextCtrl.GetItemRect(0, &rc);
	m_h    = rc.bottom + 2;
	m_LinesPerPage /= m_h;  // number of visible lines

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CQMonitorDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else if ((nID & 0xFFF0) == IDM_SAVE) // Save in file
	{
		CFileDialog dlgSave(FALSE,
							"log",
							NULL,
							OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
							"Log file (*.log)");
		if (dlgSave.DoModal() == IDOK)
		{
			CString fs = dlgSave.GetPathName();
			CFile   fh((LPCTSTR)fs, CFile::modeCreate | CFile::modeWrite);
			int i, lineCount = m_TextCtrl.GetCount();
			char buf[1024];
			for (i = 0; i < lineCount; i++)
			{
				m_TextCtrl.GetText(i, buf);
				strcat(buf, "\r\n");
				fh.Write(buf, strlen(buf));
			}
			fh.Close();
		}
	}
	else if ((nID & 0xFFF0) == IDM_BROWSE) // Toggle browse mode
	{
		m_BrowseOn = !m_BrowseOn;
		CMenu* pSysMenu = GetSystemMenu(FALSE);
		if (pSysMenu != NULL)
			pSysMenu->CheckMenuItem(IDM_BROWSE,
									(m_BrowseOn ? MF_CHECKED : MF_UNCHECKED) | MF_BYCOMMAND);
	}
	else if ((nID & 0xFFF0) == IDM_CLEAR) // Clear content
	{
		m_TextCtrl.ResetContent();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CQMonitorDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CQMonitorDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CQMonitorDlg::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct) 
{
	if (pCopyDataStruct->cbData > 0)
	{
// Format line
		DWORD n = pCopyDataStruct->cbData;
		char* buf = new char[n + 16 + 22];
		if (buf == NULL)
			return FALSE;
		SYSTEMTIME dt;
		GetLocalTime(&dt);
		sprintf(buf, "%02d/%02d/%0004d %02d:%02d:%02d PID=%d : %s",
				dt.wMonth,
				dt.wDay,
				dt.wYear,
				dt.wHour,
				dt.wMinute,
				dt.wSecond,
				pCopyDataStruct->dwData,
				pCopyDataStruct->lpData);

// Add line, keeping total line count less or equal MAX_LINES
// to limit consumed memory
		int lineCount = m_TextCtrl.GetCount();
		if (lineCount == MAX_LINES)
			m_TextCtrl.DeleteString(0);
		else
			lineCount++;
// Make added line visible if in stream mode
		if (lineCount >= m_LinesPerPage && !m_BrowseOn)
			m_TextCtrl.SetTopIndex(lineCount - m_LinesPerPage + 1);
		m_TextCtrl.AddString(buf);
		delete buf;

// Adjust horizontal scroll bar
		static int dx = 0;
		CDC*  pDC = m_TextCtrl.GetDC();
		CSize sz  = pDC -> GetTextExtent(buf);
		m_TextCtrl.ReleaseDC(pDC);
		if (sz.cx > dx)
		{
			dx = sz.cx;
			m_TextCtrl.SetHorizontalExtent(dx);
		}
		return TRUE;
	}
	return FALSE;
}

void CQMonitorDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	if (::IsWindow(m_TextCtrl.m_hWnd))
	{
		m_TextCtrl.MoveWindow(m_dx1,
							  m_dy1,
							  cx - m_dx1 - m_dx2,
							  cy - m_dy1 - m_dy2);
		m_LinesPerPage = (cy - m_dy2) / m_h; 
	}
}
