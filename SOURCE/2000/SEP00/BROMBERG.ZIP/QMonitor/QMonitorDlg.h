// QMonitorDlg.h : header file
//

#if !defined(AFX_QMONITORDLG_H__16B7A8F2_5A23_11D3_9981_00104B72A27C__INCLUDED_)
#define AFX_QMONITORDLG_H__16B7A8F2_5A23_11D3_9981_00104B72A27C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CQMonitorDlg dialog

class CQMonitorDlg : public CDialog
{
// Construction
public:
	CQMonitorDlg(CWnd* pParent = NULL);	// standard constructor
	~CQMonitorDlg();

// Dialog Data
	//{{AFX_DATA(CQMonitorDlg)
	enum { IDD = IDD_QMONITOR_DIALOG };
	CListBox	m_TextCtrl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQMonitorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	bool  m_BrowseOn;
	int   m_dx1, m_dy1, m_dx2, m_dy2, m_LinesPerPage, m_h;

	// Generated message map functions
	//{{AFX_MSG(CQMonitorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg BOOL OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QMONITORDLG_H__16B7A8F2_5A23_11D3_9981_00104B72A27C__INCLUDED_)
