#include <stdio.h>
#include "QMonitorAPI.h"

void Display(const char* frmt,...)
{
	HWND hwnd = ::FindWindow(NULL, "QMonitor");
	if (hwnd != NULL)
	{
		char temp[1024];
		va_list args;
		va_start(args, frmt);
		vsprintf(temp, frmt, args);
		va_end(args);

		COPYDATASTRUCT cs;
		cs.dwData = GetCurrentProcessId();
		cs.lpData = (PVOID)temp;
		cs.cbData = strlen(temp) + 1;
		::SendMessage(hwnd, WM_COPYDATA, (WPARAM)NULL, (LPARAM)&cs);
	}
}

Tracer::Tracer(const char* szTitle)
{
	pTitle = new char[strlen(szTitle) + 1];
	strcpy(pTitle, szTitle);
	Display("Enter %s", szTitle);
}

Tracer::~Tracer()
{
	Display("Exit %s", pTitle);
	delete pTitle;
}

Timer::Timer() : pTitle(NULL)
{
	QueryPerformanceFrequency(&frq);
}

Timer::~Timer()
{
	if (pTitle)
		delete pTitle;
}

void Timer::Start(const char* szTitle)
{
	delete pTitle;
	pTitle = new char[strlen(szTitle) + 1];
	strcpy(pTitle, szTitle);
	Display("%s : Start", pTitle);
	QueryPerformanceCounter(&start);
}

void Timer::Stop()
{
	QueryPerformanceCounter(&stop);
	__int64 elapsed = ((stop.QuadPart - start.QuadPart) * 1000000 / frq.QuadPart);
	Display("%s : Stop. Elapsed=%d (1000 ns)", pTitle, elapsed);
	delete pTitle;
	pTitle = NULL;
}
