#ifndef _QMONITOR_API_
#define _QMONITOR_API_

#include <windows.h>

void Display(const char* frmt,...);

class Tracer
{
private:
	char* pTitle;

public:
	Tracer(const char* szTitle);
	~Tracer();
};

class Timer
{
private:
	LARGE_INTEGER start, stop, frq;
	char* pTitle;

public:
	Timer();
	~Timer();
	void Start(const char* szTitle);
	void Stop();
};

#endif