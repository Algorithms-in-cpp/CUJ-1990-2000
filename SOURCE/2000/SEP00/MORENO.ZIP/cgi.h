/********************************************************

   File: cgi.h
   Author: Carlos Moreno
   Description:
       Misc. functions related to CGI processing.

*********************************************************/

#ifndef __CGI_H__
#define __CGI_H__

#include <string>
#include <vector>
#include <sstream>
#include <map>
using namespace std;

const string get = "GET";
const string post = "POST";
const string any = "";

map<string, string> cgi_parameters (const string & allowed_method = post);

string get_cgi_string (const string & allowed_method = post);
const string & decode_cgi_string (string &);
string encode_cgi_string (const string & s);

vector<string> tokens (const string & s, const string & separators);

string request_method ();
string content_length ();

// ***********  Misc. functions  ************
void send_error_page (const string & error_message);

string lcase (const string & s);
string removed_separators (const string & s);

#endif

