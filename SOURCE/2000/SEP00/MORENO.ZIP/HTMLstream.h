/********************************************************

   File: HTMLstream.h
   Author: Carlos Moreno
   Description:
       Class declaration for HTMLstream, representing
       dynamically generated HTML documents.

*********************************************************/

#ifndef __HTMLSTREAM_H__
#define __HTMLSTREAM_H__

#include <iostream>
#include <string>
using namespace std;

class HTMLstream
{
public:
    HTMLstream () {}
    HTMLstream (const string & filename);

    void open (const string & filename);

    void send (ostream & = cout) const;

    void
    set_field (const string & field, const string & content);
    void
    add_option (const string & select_field,
        const string & option);
    void remove_table_row (const string & table, int row);

    HTMLstream & operator<< (const string &);

    void save (const string & filename) const;

private:
    string html_code;

    static const int tag_not_found = -1;

    int
    tag_position (const string & tag,
        const string & name) const;

    // compares HTML substrings:  case insensitive,
    // no separators considered
    static bool
    html_substrings_equal (const string & s1, const string & s2);
        
};

#endif

