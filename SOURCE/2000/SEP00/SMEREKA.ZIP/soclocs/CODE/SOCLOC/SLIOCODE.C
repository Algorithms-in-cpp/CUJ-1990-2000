/* Socket locate code translation module.
   Rick Smereka, Copyright (C) 2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original version for CodeWarrior V4 under Windows 32bit.
   Feb/2000, Rick Smereka */

#include "stdhead.h"
#include "flsocket.h"
#include "socloc.h"
#include "sliocode.h"

void sl_code_string(int ret, char *mes)
{
   /* Translate a socket locate status code to an English string.
      String is returned in 'mes' which must be already
      allocated to suficient length. */

   switch(ret)
      {
      case SL_OK:
         strcpy(mes, "ok");
         break;

      case SL_VC_ERROR:
         strcpy(mes, "socket communication error");
         break;

      case SL_BAD_IP:
         strcpy(mes, "bad/invalid IP address");
         break;

      case SL_ACCESS_DENIED:
         strcpy(mes, "access denied");
         break;

      case SL_MEMORY_FAIL:
         strcpy(mes, "memory allocation failure");
         break;

      case SL_INVALID_FUNCTION:
         strcpy(mes, "invalid function/operation");
         break;

      case SL_INTERNAL_ERROR:
         strcpy(mes, "internal error");
         break;

      case SL_NOT_FOUND:
         strcpy(mes, "not found");
         break;

      case SL_INVALID_PARAMETER:
         strcpy(mes, "invalid parameter");
         break;

      case SL_PORT_EXIST:
         strcpy(mes, "TCP/IP port already in use");
         break;

      case SL_NO_SUCH_SOCLOC:
         strcpy(mes, "no such socloc server");
         break;

      case SL_NO_INIT:
         strcpy(mes, "no active socloc connection");
         break;

      case SL_LOG_ALREADY_OFF:
         strcpy(mes, "log already off");
         break;

      case SL_LOG_ALREADY_ON:
         strcpy(mes, "log already on");
         break;

      case SL_LOG_ERROR:
         strcpy(mes, "error opening log file");
         break;

      case SL_CONFIG_PARAMETER_MISSING:
         strcpy(mes, "config parameter missing");
         break;

      case SL_CONFIG_UNABLE_TO_OPEN:
         strcpy(mes, "unable to open config file");
         break;

      case SL_CONFIG_INTERNAL_PARSE_ERROR:
         strcpy(mes, "config internal parse error");
         break;

      case SL_CONFIG_PORT_NOT_NUMERIC:
         strcpy(mes, "config port number not numeric decimal");
         break;

      case SL_CONFIG_PORT_OUT_OF_RANGE:
         strcpy(mes, "port number out of range");
         break;

      case SL_CONFIG_HOST_EXIST:
         strcpy(mes, "config host name already defined");
         break;

      case SL_NOT_A_SOCLOC_SERVER:
         strcpy(mes, "not a socloc server");
         break;

      default:
         strcpy(mes, "unknown status code");
      };
}
