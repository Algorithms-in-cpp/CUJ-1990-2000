/* 'sconnect' parsing API defines.
   Rick Smereka, Copyright (C) 2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original Windows 32bit version under CodeWarrior V4 Jan/2000,
   Rick Smereka

   Added include of 'comcode.h' which contains common send and reply
   codes. Added 'extern "C"' sections in the case of a C++ compiler.
   Apr/2000, Rick Smereka */

/* common send/reply code definitions */

#include "comcode.h"

/* parsing return codes */

#define SP_OK SOCKET_RC_OK
#define SP_INVALID_PARAMETER 1
#define SP_MEMORY_FAIL 2
#define SP_INTERNAL_ERROR 3
#define SP_SERVICE_NOT_ALLOWED 4
#define SP_SERVICE_MISSING 5

/* maximum size of socket send/receive buffer */

#define SP_MAXCOMMAND 32767

/* function prototypes */

#ifdef __cplusplus
extern "C"
{
#endif

int sconnect_parse(char *, int, char *, char *, int *, char *);
int sconnect_build(char *, char *, int *, char *, char *);
void sp_code_string(int, char *);

#ifdef __cplusplus
}
#endif
