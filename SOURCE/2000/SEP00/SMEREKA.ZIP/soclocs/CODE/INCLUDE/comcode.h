/* Common send and reply codes.
   Rick Smereka, Copyright (C) 2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   These send codes should be common to all clients and servers,
   they allow any client or server to query another. This is especially
   important for the socket locate server ('socloc'). The send codes
   are only used in multi-user applications. The common reply
   codes are used in all applications.

   Original 32bit Windows version Dec/98, Rick Smereka */
   
#ifndef COMCODE_HXX
#define COMCODE_HXX

#define SOCKET_SEND_STATUS 999
#define SOCKET_SEND_TERM 998
#define SOCKET_SEND_LOG_OFF 997
#define SOCKET_SEND_LOG_ON 996
#define SOCKET_SEND_LOG_STATUS 995
#define SOCKET_SEND_SERVICE_NAME 994
#define SOCKET_SEND_VERSION 993

/* Common receive/reply codes, ditto */

#define SOCKET_RC_OK 0
#define SOCKET_RC_VC_ERROR 900

#endif