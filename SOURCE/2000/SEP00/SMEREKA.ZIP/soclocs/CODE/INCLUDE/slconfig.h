/* Socket locate config settings handler header file.
   Rick Smereka, Copyright (C) 2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original 32bit Windows version Jan/2000, Rick Smereka */

/* list of socket locator servers is contained in this
   link list */

struct sl_config_entry
   {
   char *host_name;               /* host name */
   int port_number;               /* port number */
   char *ip_addr;                 /* IP adress (optional) */
   
   /* is this the current local server?
      used by 'socloc' server only */
      
   int is_local_server;
   struct sl_config_entry *next;
   };

/* name of socket locator config file */

#define SL_CONFIG_FILE_NAME "socloc.ipc"

#ifdef __cplusplus
extern "C"
{
#endif

int sl_config_read(char *);
int sl_config_get_first(char *, int *, char *);
int sl_config_get_nentries(int *);
int sl_config_get_nth(int pos, char *, int *, char *);
int sl_config_find(char *, int *, char *);
int sl_config_add(char *, int, char *);
int sl_config_port_exist(int);
int sl_config_host_exist(char *);
int sl_config_delete(int);
void sl_config_delete_all(void);
int sl_config_get_list(char *);
int sl_config_put_list(char *);
int sl_config_write_file(void);
int sl_config_get_ils(int, int *);
int sl_config_set_ils(int, int);
void sl_config_list(void);
void sl_config_debug(void);

#ifdef __cplusplus
}
#endif