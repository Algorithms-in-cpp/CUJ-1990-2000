/* Socket locate defines.
   Rick Smereka, Copyright (C) 1999-2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original Windows 32bit version under CodeWarrior V4 Oct/99,
   Rick Smereka
   
   Added include of 'comcode.h' which contains common send and reply
   codes. Apr/2000, Rick Smereka */

/* define common send/reply codes */

#include "comcode.h"

/* client/server return/reply codes */

#define SL_OK SOCKET_RC_OK
#define SL_VC_ERROR SOCKET_RC_VC_ERROR
#define SL_ACCESS_DENIED 1
#define SL_MEMORY_FAIL 2
#define SL_INVALID_FUNCTION 3
#define SL_INTERNAL_ERROR 4
#define SL_NOT_FOUND 5
#define SL_INVALID_PARAMETER 6
#define SL_PORT_EXIST 7
#define SL_NO_SUCH_SOCLOC 8
#define SL_BAD_IP 10
#define SL_NO_INIT 11
#define SL_LOG_ALREADY_OFF 12
#define SL_LOG_ALREADY_ON 13
#define SL_LOG_ERROR 14
#define SL_NOT_A_SOCLOC_SERVER 15

/* client/server configuration return/reply codes */

#define SL_CONFIG_PARAMETER_MISSING 20
#define SL_CONFIG_UNABLE_TO_OPEN 21
#define SL_CONFIG_INTERNAL_PARSE_ERROR 22
#define SL_CONFIG_PORT_NOT_NUMERIC 23
#define SL_CONFIG_PORT_OUT_OF_RANGE 24
#define SL_CONFIG_HOST_EXIST 25

/* client/server send message types */

#define SL_SEND_ADD 60
#define SL_SEND_DELETE 61
#define SL_SEND_CONFIG_ADD 62
#define SL_SEND_CONFIG_DELETE 63
#define SL_SEND_FIND 64
#define SL_SEND_CONFIG_FIND 65
#define SL_SEND_FIND_LIST 66
#define SL_SEND_GET_LIST 67
#define SL_SEND_PUT_LIST 68
#define SL_SEND_CONFIG_GET_LIST 69
#define SL_SEND_CONFIG_PUT_LIST 70
#define SL_SEND_DUMP_DEBUG 71
#define SL_SEND_CONFIG_DUMP_DEBUG 72
#define SL_SEND_TERM SOCKET_SEND_TERM
#define SL_SEND_STATUS SOCKET_SEND_STATUS
#define SL_SEND_LOG_OFF SOCKET_SEND_LOG_OFF
#define SL_SEND_LOG_ON SOCKET_SEND_LOG_ON
#define SL_SEND_LOG_STATUS SOCKET_SEND_LOG_STATUS
#define SL_SEND_SERVICE_NAME SOCKET_SEND_SERVICE_NAME
#define SL_SEND_VERSION SOCKET_SEND_VERSION

/* maximum size of socket send/receive buffer */

#define SL_MAXCOMMAND 32767

/* delimiter used for get/put list */

#define SL_LIST_DELIM '^'

/* service name */

#define SL_SERVICE_NAME "socloc"
