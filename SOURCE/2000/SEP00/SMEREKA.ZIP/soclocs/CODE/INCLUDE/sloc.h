/* Defines for the high level API of 'socloc'.
   Rick Smereka, Copyright (C) 2000.
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.
   
   Original Windows 32bit version Jan/2000, Rick Smereka */   

#ifdef __cplusplus
extern "C"
{
#endif

int sloc_initialize(void);
int sloc_log_off(void);
int sloc_log_on(char *);
int sloc_log_status(int *, char *);
int sloc_add(char *, char *, int, char *);
int sloc_config_add(char *, int, char *);
int sloc_config_delete(int);
int sloc_status(void);
int sloc_custom_status(char *, int);
int sloc_service_name(char *);
int sloc_version(char *);
int sloc_connect(char *, int);
int sloc_delete(int);
int sloc_find(char *, char *, int *, char *);
int sloc_find_list(char *, char *);
int sloc_ll_find(char *, char *, int *, char *);
int sloc_ll_find_list(char *, char *, int *, char *, char *);
int sloc_get_list(char *);
int sloc_put_list(char *);
int sloc_config_update(void);
int sloc_config_get_list(char *);
int sloc_config_put_list(char *);
int sloc_bcast_add(char *, char *, int, char *);
int sloc_bcast_delete(int);
int sloc_bcast_config_add(char *, int, char *);
int sloc_bcast_config_delete(int);
int sloc_dump_debug(void);
int sloc_config_dump_debug(void);
int sloc_terminate(char *);
void sloc_get_active_socloc(char *, int *);
int sloc_set_active_socloc(char *, int);
int sloc_find_first_active(void);
int sloc_is_init(void);

#ifdef __cplusplus
}
#endif