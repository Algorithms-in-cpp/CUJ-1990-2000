/* Dumb Socket Server defines.
   Rick Smereka, Copyright (C) 1999-2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original Windows 32bit version under CodeWarrior V4 Oct/99,
   Rick Smereka */

/* client/server return/reply codes */

#define DM_OK SOCKET_RC_OK
#define DM_VC_ERROR SOCKET_RC_VC_ERROR
#define DM_ACCESS_DENIED 1
#define DM_MEMORY_FAIL 2
#define DM_INVALID_FUNCTION 3
#define DM_INTERNAL_ERROR 4
#define DM_INVALID_PARAMETER 5
#define DM_LOG_ALREADY_OFF 6
#define DM_LOG_ALREADY_ON 7
#define DM_NO_SERVER 8
#define DM_NOT_FOUND 9
#define DM_LOG_ERROR 10

/* send messages, note that this really dumb socket
   server only responds to messages that are common
   amoung all Future Lab socket servers */

#define DM_SEND_TERM SOCKET_SEND_TERM
#define DM_SEND_STATUS SOCKET_SEND_STATUS
#define DM_SEND_LOG_OFF SOCKET_SEND_LOG_OFF
#define DM_SEND_LOG_ON SOCKET_SEND_LOG_ON
#define DM_SEND_LOG_STATUS SOCKET_SEND_LOG_STATUS
#define DM_SEND_SERVICE_NAME SOCKET_SEND_SERVICE_NAME
#define DM_SEND_VERSION SOCKET_SEND_VERSION

/* command line codes */

#define DMCOM_TERM 1
#define DMCOM_STATUS 2
#define DMCOM_CLIENT_LOG_OFF 3
#define DMCOM_CLIENT_LOG_ON 4
#define DMCOM_CLIENT_LOG_STATUS 5
#define DMCOM_SERVER_LOG_OFF 6
#define DMCOM_SERVER_LOG_ON 7
#define DMCOM_SERVER_LOG_STATUS 8
#define DMCOM_CONNECT 9
#define DMCOM_SOCLOC_GET_LIST 10
#define DMCOM_SOCLOC_CONFIG_GET_LIST 11
#define DMCOM_SOCLOC_GET 12
#define DMCOM_SOCLOC_LOG_OFF 13
#define DMCOM_SOCLOC_LOG_ON 14
#define DMCOM_SOCLOC_LOG_STATUS 15
#define DMCOM_SOCLOC_VERSION 16
#define DMCOM_VERSION 17
#define DMCOM_NOT_FOUND -1
#define DMCOM_OFF -2
#define DMCOM_MAXCOM 17

/* maximum size of socket send/receive buffer */

#define DM_MAXCOMMAND 32767

/* service name for 'socloc' */

#define DM_SERVICE_NAME "dumsocks"
