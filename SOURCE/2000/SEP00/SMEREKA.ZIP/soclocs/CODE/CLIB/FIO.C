/* File I/O function library module,
   Rick Smereka, Copyright (C) 1995-2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original DOS version Feb/95, Rick Smereka

   Port to QNX V4.23a Dec/97, Rick Smereka

   Changed the 'unique' function to create a file in the
   indicated directory. Also changed the return type to
   'int' to indicate the success or failure of the file
   name generation. Dec/97, Rick Smereka

   Added function 'qrename' specific to QNX. This function
   attempts to perform a normal rename. If that failes with
   a 'EXDEV' 'errno' (cannot move across devices), an OS
   copy is performed. Nov/98, Rick Smereka

   Ported to 32bit Windows under CodeWarrior V4.
   Ported to HP-UX under GNU C 2.8.1.
   Jan/99, Rick Smereka

   Ported to Red Hat Linux 5.2, Jul/99, Rick Smereka */

#include "stdhead.h"

int unique(char *dir, char *fname)
{
   /* Create a unique file name. File will be created in the
      directory 'dir'. Do not end 'dir' with a path separator.
      'dir' can be a null string but not a NULL pointer.
      Name of the new file is returned in 'fname' minus the
      directory name. */

   long now;
   int rnd_part1, rnd_part2, ex = TRUE;
   int dir_len, total_len;
   char *total_f;
   char rname[13];

   if (dir == (char *)NULL)
      return(FALSE);

   dir_len = strlen(dir);

   if (dir_len && dir[dir_len - 1] == PATH_SEP)
      return(FALSE);

   if (fname == (char *)NULL)
      return(FALSE);

   /* calculate length of total string required */

   total_len = dir_len + 14;

   /* allocate total file name string */

   if ((total_f = (char *)malloc(total_len + 1)) == (char *)NULL)
      return(FALSE);

   while(ex)
      {
      srand(time(&now) % 37);
      rnd_part1 = rand() % 32000;
      rnd_part2 = rand() % 998;
      sprintf(rname, "tmp%05d.%03d", rnd_part1, rnd_part2);

      if (dir_len)
         sprintf(total_f, "%s%c%s", dir, PATH_SEP, rname);
      else
         strcpy(total_f, rname);

      ex = exist(total_f);
      }

   free(total_f);
   strcpy(fname, rname);
   return(TRUE);
}

int exist(char *file)
{
   /* Test for file existance. Under Unix/QNX, the POSIX
      'access' function is used. Since CodeWarrior does not
      support this function and DOS directory functions are
      also not supported, we test for file existance by
      attempting to open the file. Note that the Unix/QNX
      version makes no assumption on the read/write status
      of the file whereas the Windows 32bit version specifically
      opens the file for read. Function returns 'TRUE' upon success,
      'FALSE' otherwise. */
#ifdef OS_DOS
struct ffblk dconst;
struct ffblk *dta = &dconst;
#endif

#ifdef OS_WIN32
   FILE *in;
#endif

   if (!strlen(file))
      return(FALSE);

#ifdef OS_WIN32
   if ((in = fopen(file, "r")) == (FILE *)NULL)
      return(FALSE);

   fclose(in);
   return(TRUE);
#endif

#ifdef OS_UNIX
   if (!access(file, F_OK))
      return(TRUE);

   return(FALSE);
#endif

#ifdef OS_DOS
   if (!findfirst(file, dta, FA_NORMAL))
      return(TRUE);

   return(FALSE);
#endif
}

int numrecs(FILE *fi)
{
   /* Count the number of records in a file. */

   char *buf;
   int numrec = 0;

   if ((buf = (char *)malloc(BUFSIZE + 1)) == NULL)
      return(0);

   rewind(fi);
   get_rec(fi, buf);

   while(!feof(fi))
      {
      numrec++;
      get_rec(fi, buf);
      }

   rewind(fi);
   free(buf);
   return(numrec);
}

void get_nrec(int recno, FILE *fi, char *buf)
{
   /* Read the 'recno' record from 'fi' into 'buf' and strip any
      line feeds. 'Buf' will contain zero bytes on failure.
      'Buf' must be statically allocated by the caller to an
      appropriate size. */

   register int i;
   char *ptr;

   rewind(fi);

   for(i = 0; i < recno; i++)
      {
      fgets(buf, BUFSIZE, fi);

      if (feof(fi))
         {
         buf[0] = EOS;
         return;
         }
      }

   if ((ptr = strchr(buf, EOL)) != NULL)
      *ptr = EOS;
}

void get_rec(FILE *fi, char *buf)
{
   /* Read a record from 'fi' into 'buf' and strip any
      line feeds. */

   char *ptr;

   fgets(buf, BUFSIZE, fi);

   if ((ptr = strchr(buf, EOL)) != NULL)
      *ptr = EOS;
}

int zcreate(char *fname)
{
   /* Create a zero byte file called 'fname'. Function
      returns TRUE on success, FALSE otherwise. */

   FILE *fi;

   if ((fi = fopen(fname,"w")) == (FILE *)NULL)
      return(FALSE);

   fclose(fi);
   return(TRUE);
}

#ifdef OS_UNIX
int isdirectory(char *path)
{
   /* Check for 'path' being a directory. Uses POSIX 'access'
      function with the 'X_OK' test. Note that this test can
      be fooled by an executable program. Function returns
      'TRUE' if 'path' resolves to a directory, 'FALSE'
      otherwise. Since the 'access' function nor the DOS
      directory search routines are supported under CodeWarrior,
      there currently is no version of this function for
      Windows 32bit. Jan/99, Rick Smereka */
      
   if (strlen(path))
      return(FALSE);
      
   if (!access(path, X_OK))
      return(TRUE);
      
   return(FALSE);
}
#endif

int filecopy(char *src, char *dest)
{
   /* Copy a file from 'src' to 'dest'. If 'dest' file
      exists, it will be overwritten. A 32kb buffer is
      used to copy the data. Function returns 'TRUE'
      upon success, 'FALSE' otherwise. Dec/98,
      Rick Smereka. */

   int inhandle, outhandle, bufsiz, ret, done = FALSE;
   char *ptr;

   if (!strlen(src) || !strlen(dest))
      return(FALSE);

   bufsiz = 32760;

   if ((ptr = (char *)malloc(bufsiz)) == (char *)NULL)
      return(FALSE);

   if ((inhandle = open(src, O_RDONLY)) < 0)
      {
      free(ptr);
      return(FALSE);
      }

   if ((outhandle = open(dest, O_WRONLY | O_CREAT | O_TRUNC)) < 0)
      {
      close(inhandle);
      free(ptr);
      return(FALSE);
      }

   /* swap until end of file or error */

   do
      {
      ret = read(inhandle, ptr, bufsiz);

      /* trap read errors */

      if (ret < 0)
         {
         close(inhandle);
         close(outhandle);
         free(ptr);
         return(FALSE);
         }

      if (write(outhandle, ptr, ret) != ret)
         {
         close(inhandle);
         close(outhandle);
         free(ptr);
         return(FALSE);
         }

      /* if we read less than a buffer size, assume done */

      if (ret < bufsiz)
         done = TRUE;
      }
   while(!done);

   close(inhandle);
   close(outhandle);
   free(ptr);
   return(TRUE);
}

int qrename(char *src, char *dest)
{
   /* Rename a file. This version will rename a file
      anywhere (same directory, different directory on
      same volume, different directory on different
      disk/volume). Function returns 'TRUE' upon
      success, 'FALSE' otherwise. Dec/98,
      Rick Smereka */
      
   int lensrc, lendest;
#ifdef OS_QNX
   int ret;
#endif
   
   // reasonableness checks
   
   if (src == (char *)NULL || dest == (char *)NULL)
      return(FALSE);
      
   lensrc = strlen(src);
   lendest = strlen(dest);
   
   if (!lensrc || !lendest)
      return(FALSE);
      
   // first, attempt a normal 'rename'
   
   if (!rename(src, dest))
      return(TRUE);

#ifdef OS_QNX
   ret = errno;
   
   if (ret != EXDEV)
      return(FALSE);
#endif
      
   // normal rename failed, use copy
   
   if (!filecopy(src, dest))
      return(FALSE);
      
   // delete source file
   
   (void)unlink(src);
   return(TRUE);
}
