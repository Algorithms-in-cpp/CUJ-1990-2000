/* Socket routines for a connection oriented TCP
   iterative server.
   Rick Smereka, Copyright (C) 1998-2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original version for CodeWarrior V4 under Windows 32bit.
   Dec/98, Rick Smereka

   Ported to HP-UX under GNU C 2.8.1.
   Jan/99, Rick Smereka

   Ported to Red Hat Linux 5.2, Jul/99, Rick Smereka

   Modified for Windows 32bit only. Removed the 'WSADATA' structure
   and all 'WSAStartup()' and WSACleanup()' function calls after I
   realized that the 'WSACleanup()' call would shutdown all WinSock
   operations. This causes trouble for socket servers which also
   perform client socket operations before replying to the cient.
   It is now the responsibility of the socket server to call
   'WSAStartup()' and 'WSACleanup()'. Also renamed 'clientSocket'
   to 'srvclientSocket' since CodeWarrior gets 'confused' with
   module globals with the same name. Dec/99, Rick Smereka */

#include "stdhead.h"
#include "flsocket.h"
#include "ipcomm.h"
#include "ipcsrv.h"

// global (to module) socket data

#ifdef OS_WIN32
SOCKET serverSocket;					// main server socket
SOCKET srvclientSocket;          // client socket
SOCKADDR_IN sockServerAddr; 		// server address structure
SOCKADDR_IN sockClientAddr;		// client address structure
#endif

#ifdef OS_UNIX
int serverSocket;
int srvclientSocket;
struct sockaddr_in sockServerAddr;
struct sockaddr_in sockClientAddr;
#endif

int ipc_init(char *host_name, int port_number)
{
   /* Initialize the server for communication. The port
      that the server listens to is expected in 'port_number'.
      Function returns 'TRUE' upon success,'FALSE' otherwise.
      Note that upon success, the local host name is returned
      in 'host_name' which must be already allocated to
      sufficient size. */

   char *localHost;

	if (port_number <= 0)
	   {
	   log_file_date("ipc_init:invalid port. Program abort");
	   return(FALSE);
	   }

   if (host_name == (char *)NULL)
      {
      log_file_date("ipc_init:host name parm is NULL pointer");
      return(FALSE);
      }

   host_name[0] = EOS;

	if ((localHost = (char *)malloc(1024)) == (char *)NULL)
	   {
	   log_file_date("ipc_init:alloc fail 'localHost'. Program abort.");
	   return(FALSE);
	   }

	// attempt to resolve the local host name

	if (gethostname(localHost, 1023))
	   {
	   free(localHost);
	   log_file_date("ipc_init:unable to resolve local host name. Program abort");
	   return(FALSE);
	   }

	log_file_date("ipc_init:server on host %s, port is %d", localHost, port_number);

#ifdef OS_WIN32
	serverSocket = socket(PF_INET, SOCK_STREAM, DEFAULT_PROTOCOL);
#endif

#ifdef OS_UNIX
	serverSocket = socket(AF_INET, SOCK_STREAM, DEFAULT_PROTOCOL);
#endif

	if (serverSocket == INVALID_SOCKET)
	   {
	   log_file_date("ipc_init:unable to create server socket. Program abort");
	   free(localHost);
	   return(FALSE);
	   }

	// populate server address structure

   memset(&sockServerAddr, 0,	sizeof(sockServerAddr));
	sockServerAddr.sin_family = AF_INET;
	sockServerAddr.sin_addr.s_addr = INADDR_ANY;
	sockServerAddr.sin_port = htons(port_number);

	// bind the server socket

#ifdef OS_WIN32
	if (bind(serverSocket,(LPSOCKADDR)&sockServerAddr,sizeof(sockServerAddr))
	   == SOCKET_ERROR)
#endif

#ifdef OS_UNIX
	if (bind(serverSocket, &sockServerAddr, sizeof(sockServerAddr))
	   == SOCKET_ERROR)
#endif

	   {
	   free(localHost);
	   log_file_date("ipc_init:unable to bind server socket.");
	   return(FALSE);
	   }

	// listen on port

	if (listen(serverSocket, QUEUE_SIZE) == SOCKET_ERROR)
	   {
	   free(localHost);
	   log_file_date("ipc_init:unable to listen. Program abort");
	   return(FALSE);
	   }

	srvclientSocket = INVALID_SOCKET;
	strcpy(host_name, localHost);
	free(localHost);
	return(TRUE);
}

int ipc_server_wait(void)
{
	/* Accept a client connection. Function
		returns 'TRUE' if a client connection
		was successful, 'FALSE' otherwise. */

#ifdef OS_WIN32
   int len = sizeof(SOCKADDR);
#else
   int len = sizeof(sockClientAddr);
#endif

	srvclientSocket = INVALID_SOCKET;

#ifdef OS_WIN32
	srvclientSocket = accept(serverSocket, (LPSOCKADDR)&sockClientAddr,
	                      (LPINT)&len);
#endif

#ifdef OS_UNIX
	srvclientSocket = accept(serverSocket, &sockClientAddr, &len);
#endif

	if (srvclientSocket == INVALID_SOCKET)
	   {
		log_file_date("ipc_server_wait:error accepting a connection");
		return(FALSE);
		}

	return(TRUE);
}

int ipc_recv_data(char *buf)
{
   /* Receive server data into 'buf' which must be allocated
      to sufficient size. Function returns the number of
      bytes read upon success, zero otherwise. */

   return(ipc_recv(srvclientSocket, buf));
}

int ipc_send_data(char *buf)
{
	/* Send client data. All data in 'buf' will be sent.
      Function returns the number of bytes sent upon
      success, zero otherwise. */

	return(ipc_send(srvclientSocket, buf));
}

int ipc_close_client(void)
{
   /* Close the client socket in use by the server.
      Function returns 'TRUE' upon success, 'FALSE'
      otherwise. */

   if (srvclientSocket == INVALID_SOCKET)
      return(FALSE);

#ifdef OS_WIN32
   if (closesocket(srvclientSocket) == SOCKET_ERROR)
      return(FALSE);
#endif

#ifdef OS_UNIX
   close(srvclientSocket);
#endif

   srvclientSocket = INVALID_SOCKET;
   return(TRUE);
}

int ipc_close(void)
{
   /* Close all sockets in use by the server.
      Function returns 'TRUE' upon success, 'FALSE'
      otherwise. */

   if (srvclientSocket != INVALID_SOCKET)
#ifdef OS_WIN32
      if (closesocket(srvclientSocket) == SOCKET_ERROR)
         return(FALSE);
#endif

#ifdef OS_UNIX
      close(srvclientSocket);
#endif

#ifdef OS_WIN32
   if (closesocket(serverSocket) == SOCKET_ERROR)
         return(FALSE);
#endif

#ifdef OS_UNIX
   close(serverSocket);
#endif

   return(TRUE);
}

void ipc_display_client(void)
{
   // Display client socket pointer. For debuging.

#ifdef OS_WIN32
   printf("ipc_display_client:%p\n", (void *)srvclientSocket);
#endif

#ifdef OS_UNIX
   printf("ipc_display_client:%d\n", srvclientSocket);
#endif
}
