/* Low level TCP socket routines. These routines are used by both
   client and server API's.
   Rick Smereka, Copyright (C) 1998-2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original version for CodeWarrior V4 under Windows 32bit.
   Dec/98, Rick Smereka

   Ported to HP-UX under GNU C 2.8.1.
   Jan/99, Rick Smereka

   Ported to Red Hat Linux 5.2, Jul/99, Rick Smereka */

#include "stdhead.h"
#include "flsocket.h"
#include "ipcomm.h"

#ifdef OS_WIN32
int ipc_recv(SOCKET sock, char *buf)
#endif

#ifdef OS_UNIX
int ipc_recv(int sock, char *buf)
#endif
{
   /* Receive up to 'IPC_MAXREC' - 1 bytes from the
      socket which is assumed to be open. Function
      returns the number of bytes read upon success,
      zero otherwise. */

   char *fbuf;
   int charRecv, pos = 0, done = FALSE;

   if ((fbuf = (char *)malloc(IPC_SR_BUFSIZE)) == (char *)NULL)
      return(FALSE);

   while(!done)
   	{
#ifdef OS_WIN32
   	charRecv = recv(sock, (LPSTR)fbuf, (IPC_SR_BUFSIZE - 1), NO_FLAGS);
#endif

#ifdef OS_UNIX
   	charRecv = recv(sock, fbuf, (IPC_SR_BUFSIZE - 1), NO_FLAGS);
#endif

   	if (charRecv == SOCKET_ERROR)
   	   {
   	   free(fbuf);
         return(0);
         }

		fbuf[charRecv] = EOS;
		//log_file_date("ipc_recv:received %d byte(s)", charRecv);

		if ((strlen(fbuf) + strlen(buf)) >= IPC_MAXREC)
		   {
		   //log_file_date("ipc_recv:too much data");
		   free(fbuf);
		   return(0);
		   }

      strncpy(&buf[pos], fbuf, charRecv);

   	if (charRecv > 0)
   	   pos += charRecv;

   	buf[pos] = EOS;

   	if (charRecv < (IPC_SR_BUFSIZE - 1))
   	   done = TRUE;
   	}

   free(fbuf);
   //log_file_date("ipc_recv:received total of %d byte(s)", pos);
   return(pos);
}

#ifdef OS_WIN32
int ipc_send(SOCKET sock, char *buf)
#endif

#ifdef OS_UNIX
int ipc_send(int sock, char *buf)
#endif
{
	/* Send data to the socket. Function returns the
		number of bytes sent upon success, zero
		otherwise. */

	char *fbuf;
	int len, charSent, pos = 0, bytesToGo, done = FALSE;
	int chunk;

	len = strlen(buf);

	if (!len)
		return(0);

	// if less than 'IPC_SR_BUFSIZE' to send, use one shot

	if (len < IPC_SR_BUFSIZE)
	   {
		if ((charSent = send(sock, buf, len, NO_FLAGS)) == SOCKET_ERROR)
		   return(FALSE);

	   return(charSent);
	   }

	if ((fbuf = (char *)malloc(IPC_SR_BUFSIZE)) == (char *)NULL)
	   return(FALSE);

	bytesToGo = len;

	// send one buffer length at a time

	while(!done)
	   {
	   if (bytesToGo > (IPC_SR_BUFSIZE - 1))
	   	chunk = IPC_SR_BUFSIZE - 1;
	  	else
	  		chunk = bytesToGo;

	  	strncpy(fbuf, &buf[pos], chunk);
	  	fbuf[chunk] = EOS;

		if ((charSent = send(sock, fbuf, chunk, NO_FLAGS)) == SOCKET_ERROR)
			{
	   	pos = 0;
	   	break;
	   	}

	   bytesToGo -= chunk;
	   pos += charSent;

	   if (bytesToGo <= 0)
	      done = TRUE;
	   }

	free(fbuf);
	//log_file_date("ipc_send:sent total of %d byte(s)", pos);
	return(pos);
}
