/* dumsocks - A dumb socket server. This TCP/IP connection oriented
   iterative socket server is used for testing.
   Rick Smereka, Copyright (C) 2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Like the name says...dumb. This server will accept only a
   generic status request, a termination request and log on/off
   requests. This server is coded to use 'socloc'. It is a fatal
   error if there are no 'socloc' servers running. Syntax:
   
      dumsocks [-l log_file] port
      
   
   Where 'port' is the TCP/IP port to listen and '-l log_file'
   is the optional name of the server log file. If no log file
   is given, the log file name will be 'DUM_LOG_FILE' in the
   current directory. Note that the switch character ('-')
   is based on the platform (see include file 'stdhead.h').
   
   Original Windows 32bit version under CodeWarrior V4. Feb/2000,
   Rick Smereka
   
   Re-compiled after re-structuring the definition of the common
   send and repy codes. Added '-q' comand line option to suppress
   console/screen output. Program syntax now:
   
      dumsocks [-q] [-l log_file] port
      
   Apr/2000, Rick Smereka
   
   Modified the function 'srv_initialize' to obtain the IP address
   and pass this to the 'sloc_add' socloc function. Jul/2000,
   Rick Smereka */

#include "stdhead.h"
#include "flsocket.h"                 /* generic socket definitions */
#include "socloc.h"                   /* socket locate defines */
#include "ipcsrv.h"                   /* TCP server routines */
#include "ip.h"                       /* IP library routines */
#include "sloc.h"                     /* 'socloc' client API */
#include "dumsocks.h"                 /* dumb socket server defines */

#define VERSION "1.01.01-2000.07.03"  /* version ID */
#define DM_TERM_PASSWD "rdsWin32"     /* terminate server password */

/* private log file definition */

#define DUM_LOG_FILE "dumsocks.log"

/* WinSock specific global data structure */

#ifdef OS_WIN32
WSADATA wsaData;                      /* struct used by 'WSAStartup()' */
#endif

/* global data */

int server_port = 0;                  /* TCP port that server is using */
int console_output = TRUE;            /* log messages to screen? */
char d_log_file[256];                 /* path/name of log file */
char localHost[256];                  /* host name of this machine */

/* function prototypes */

void main(int, char **);
int parse_comline(int, char **);
int srv_initialize(void);
int process_request(void);
int do_comm(int, char *);
int s_terminate(char *);
void s_log_off(void);
void s_log_on(char *);
void s_log_status(void);
int do_reply_code(int);
int do_reply_char(int, char *);
void usage();
   
void main(int argc, char **argv)
{
   int isterm;

   if (argc == 1)
      {
      usage();
      exit(0);
      }

   if (!parse_comline(argc, argv))
      exit(0);

   /* initialize private logging */

   if (!log_start(d_log_file))
      {
      printf("%s:error initializing log file. Program abort\n",
             DM_SERVICE_NAME);
      exit(0);
      }

   /* set logger console output flag */
   
   log_console(console_output);
   
   /* build logo string based on platform */
   
#ifndef OS_UNIX
   /* non-Unix */
   
   log_file_date("%s Server for %s Version %s", DM_SERVICE_NAME, 
                 PLATFORM_STRING, VERSION);
#else
   /* Unix */
   
   log_file_date("%s Server for %s Version %s", DM_SERVICE_NAME,
                 SUB_PLATFORM_STRING,VERSION);
#endif
   
   log_file_date("By Rick Smereka, Copyright (c) 2000");
   
   /* read IPC config file and validate other 'socloc' servers
      (if any) */
      
   if (!srv_initialize())
      {
      log_end();
      exit(4);
      }
   
   log_file_date("%s:server on \"%s\" servicing TCP port %d (decimal)",
                 DM_SERVICE_NAME, localHost, server_port);   
   log_file_date("%s:server started", DM_SERVICE_NAME);   
   log_file_date("%s comes with ABSOLUTELY NO WARRANTY", DM_SERVICE_NAME);   
   log_file_date("This is free software, and you are welcome to redistribute it");   
   log_file_date("under certain conditions; see \"gpl.txt\" for information."); 
   
   /* turn off log as this is used only for debugging */
   
   log_end();
   
   // process each connection (infinite loop)

   while(1)
      {
      /* 'accept' will block until connection */
      
      if (ipc_server_wait())
         {
         isterm = process_request();
         (void)ipc_close_client();
         }
                 
      if (isterm)
         break;
      }

#ifdef OS_WIN32
      WSACleanup();
#endif 

   exit(0);
}

int parse_comline(int c_count, char **c_parm)
{
   /* Parse the command line for parameters. Function
      returns 'TRUE' if no error was detected, 'FALSE'
      otherwise. */
      
   int parms = 1, done = FALSE;

   /* set default log file */
   
   strcpy(d_log_file, DUM_LOG_FILE);
      
   while(!done)
      {      
      if (c_parm[parms][0] == SWITCH_CHAR)      
         {
         switch(toupper(c_parm[parms][1]))
            {
            case 'L':
               if (strlen(c_parm[parms]) > 2)
                  printf("%s:extraneous input with log switch, ignoring\n",
                         DM_SERVICE_NAME);
               
               parms++;
            
               if (parms >= c_count)
                  {
                  printf("%s:log switch with no file name, "
                         "program abort\n", DM_SERVICE_NAME);
                  return(FALSE);
                  }
               
               strcpy(d_log_file, c_parm[parms]);
               parms++;
               break;
               
            case 'Q':
               console_output = FALSE;
               parms++;
               break;
               
            default:
               printf("%s:unknown switch[%s], program abort\n",
                      DM_SERVICE_NAME, c_parm[parms]);
               return(FALSE);
            };
         }
      else
         {
         if (!qatoi(c_parm[parms], &server_port))
            {
            printf("%s:server port is non-numeric, "
                   "program abort\n", DM_SERVICE_NAME);
            return(FALSE);
            }
            
         if (server_port <= 0)
            {
            printf("%s:server port is out of range, "
                   "program abort\n", DM_SERVICE_NAME);
            return(FALSE);
            }
            
         parms++;
         }
         
      if (parms >= c_count)
         done = TRUE;
      }

   if (server_port == 0)
      {
      printf("%s:server port missing, program abort\n", DM_SERVICE_NAME);
      return(FALSE);
      }
            
   return(TRUE);
}

int srv_initialize(void)
{
   /* Initialize the server. Function returns 'TRUE' upon
      success, 'FALSE' otherwise. */
   
   char mname[] = "srv_initialize";      
   char localHost[128], mes[128];
   int ret;

   log_file_date("%s:enter", mname);
                                        
   /* startup WinSock (if Windoze) */
   
#ifdef OS_WIN32
   if (WSAStartup(WINSOCK_VERSION, &wsaData))
      {
      log_file_date("%s:unable to start WinSock, "
                    "program abort", mname);      
      WSACleanup();
      return(FALSE);
      }
#endif		  

   /* initialize the server on the TCP socket level, note that
      the hostname 'localhost' is returned to us */
      
   if (!ipc_init(localHost, server_port))
      {
      log_file_date("%s:socket initialization failure, "
                    "program abort\n", mname);
#ifdef OS_WIN32
      WSACleanup();
#endif
                    
      return(FALSE);
      }

   /* initialize 'socloc' client API */
   
   if ((ret = sloc_initialize()) != SL_OK)
      {
      sl_code_string(ret, mes);
      log_file_date("%s:bad rc[%s] from 'sloc_initialize'", mname, mes);

#ifdef OS_WIN32
      WSACleanup();
#endif

      return(FALSE);
      }
    
    /* get IP address of this machine */
   
   if (!ip_host2ip(localHost, mes))
      {
      printf("%s:unable to obtain IP address of this machine\n", mname);
      printf("%s:program abort\n", mname);
      
#ifdef OS_WIN32
      WSACleanup();
#endif

      return(FALSE);
      }
              
   /* register with 'socloc' */
   
   if ((ret = sloc_add(DM_SERVICE_NAME, localHost, server_port,
       mes)) != SL_OK)
      {
      sl_code_string(ret, mes);
      log_file_date("%s:bad rc[%s] from 'sloc_add'", mname, mes);
      
#ifdef OS_WIN32
      WSACleanup();
#endif

      return(FALSE);
      }
                        	      
   log_file_date("%s:normal exit[TRUE]", mname);
   return(TRUE);
}

void s_log_off(void)
{
   /* Turn all loggging off. Of course, check for logging
      already off. */

   char mname[] = "s_log_off";      
   int ret;
   
   log_file_date("%s:enter", mname);
   
   if (!is_log_active())
      ret = DM_LOG_ALREADY_OFF;
   else
      {
      log_end();
      ret = DM_OK;
      }
      
   (void)do_reply_code(ret);
   log_file_date("%s:normal exit rc[%d]", mname, ret);
}
 

void s_log_on(char *comm)
{
   /* Turn server logging on using either the supplied log file name
      or the global log file name. Of course, check for logging
      already on. */
      
   char mname[] = "s_log_on";
   int ret;
   
   log_file_date("%s:enter", mname);
   
   if (is_log_active())
      ret = DM_LOG_ALREADY_ON;
   else
      {
      if (command_words(comm) > 1)
         {
         if (!command_word(comm, d_log_file, 2))
            {
            log_file_date("%s:error getting log file name", mname);
            (void)do_reply_code(DM_INTERNAL_ERROR);
            return;
            }
         }
      else
         strcpy(d_log_file, DUM_LOG_FILE);
                     
      if (!log_start(d_log_file))
         {
         (void)do_reply_code(DM_LOG_ERROR);
         return;
         }
         
      ret = DM_OK;
      }
       
   (void)do_reply_code(ret);
   log_file_date("%s:normal exit rc[%d]", mname, ret);
}

void s_log_status(void)
{
   /* Get the current log status (on or off). */
   
   char mname[] = "s_log_status";
   int ret;
   
   log_file_date("%s:enter", mname);
   
   if (is_log_active())
      ret = DM_LOG_ALREADY_ON;
   else
      ret = DM_LOG_ALREADY_OFF;
      
   (void)do_reply_code(ret);
   log_file_date("%s:normal exit rc[%d]", mname, ret);
}
      
int process_request(void)
{
   /* Process a single request. Function returns 'FALSE' if
      termination signal was not encountered, 'TRUE'
      otherwise. */

   char mname[] = "process_request";
   char *messbuf, tmp[128];
   int ret, nbytes, nwords, mestype;

   log_file_date("%s:enter", mname);
   
   if ((messbuf = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
      {
      (void)do_reply_code(DM_MEMORY_FAIL);
      log_file_date("%s:alloc fail[messbuf]", mname);
      return(FALSE);
      }
           
   memset(messbuf, 0, DM_MAXCOMMAND);
   
   // get the message from the client

   if ((nbytes = ipc_recv_data(messbuf)) == 0)
      {
      free(messbuf);
      (void)do_reply_code(DM_VC_ERROR);
      log_file_date("%s:socket error receiving client data", mname);
      return(FALSE);
      }
    
   messbuf[nbytes] = EOS;
   log_file_date("%s:recv %s,l=%d", mname, messbuf, strlen(messbuf));
   nwords = command_words(messbuf);
      
   // no command words, empty string
       
   if (!nwords)
      {
      (void)do_reply_code(DM_INVALID_FUNCTION);
      free(messbuf);
      log_file_date("%s:empty command", mname);
      return(FALSE);
      }
   
   // first command word must be a number

   if (!command_word(messbuf, tmp, 1))
      {
      free(messbuf);
      (void)do_reply_code(DM_INTERNAL_ERROR);
      log_file_date("%s:error getting first command word", mname);
      return(FALSE);
      }
   
   if (!qatoi(tmp, &mestype))
      {
      (void)do_reply_code(DM_INVALID_FUNCTION);
      log_file_date("%s:command signature not a number", mname);
      free(messbuf);
      return(FALSE);
      }      
   
   /* pass entire string including command number */
      
   ret = do_comm(mestype, messbuf);
   free(messbuf);
   log_file_date("%s:normal exit,rc=%d", mname, ret);
   return(ret);   
}

int do_comm(int mestype, char *slm)
{
   /* High level server command dispatcher. 
      Function returns 'TRUE' if a terminate
      request was encountered, 'FALSE'
      otherwise. */
   
   char mname[] = "do_comm";
   int ret;

   log_file_date("%s:enter", mname);
   ret = FALSE;

   switch(mestype)
      {                               
      case DM_SEND_STATUS:
         (void)do_reply_code(DM_OK);
         break;
                                                
      case SL_SEND_TERM:
         if (s_terminate(slm))
            ret = TRUE;
            
         break;
         
      case DM_SEND_LOG_OFF:
         s_log_off();
         break;
         
      case DM_SEND_LOG_ON:
         s_log_on(slm);
         break;

      case DM_SEND_LOG_STATUS:
         s_log_status();
         break;

      case DM_SEND_SERVICE_NAME:
         (void)do_reply_char(DM_OK, DM_SERVICE_NAME);
         break;

      case DM_SEND_VERSION:
         (void)do_reply_char(DM_OK, VERSION);
         break;
                           
      default:
         log_file_date("%s:received unknown code=%d", mname, mestype);
         (void)do_reply_code(DM_INVALID_FUNCTION);
         break;
      };

   log_file_date("%s:exit[%d]", mname, ret);
   return(ret);
}

int s_terminate(char *comm)
{
   /* Terminate the server. Check the supplied password first.
      Syntax:
      
         SL_SEND_TERM password
         
      Function returns 'TRUE' if correct password was supplied,
      'FALSE' otherwise. */
      
   char mname[] = "s_terminate";
   char wrd[256];
   int ret;

   log_file_date("%s:enter", mname);
      
   if (command_words(comm) < 2)
      {
      (void)do_reply_code(DM_INVALID_FUNCTION);
      log_file_date("%s:no password", mname);
      return(FALSE);
      }

   if (!command_word(comm, wrd, 2))
      {
      (void)do_reply_code(DM_INTERNAL_ERROR);
      log_file_date("%s:error getting password", mname);
      return(FALSE);
      }
         
   if (!strcmp(wrd, DM_TERM_PASSWD))
      {            
      (void)do_reply_code(DM_OK);
      
      /* close server socket */
      
      if (!ipc_close())
         log_file_date("%s:error closing sockets", mname);
      
      /* de-register with 'socloc', note that even if the delete
         fails (for whatever reason), the shutdown continous */
      
      if ((ret = sloc_delete(server_port)) != SL_OK)
         log_file_date("%s:bad rc[%d] from 'sloc_delete'",
                       mname, ret);      
      
      log_file_date("%s:server down,rc from 'socloc' delete[%d]", mname, ret);
      return(TRUE);
      }
            
   log_file_date("%s:illegal terminate request", mname);
   (void)do_reply_code(DM_ACCESS_DENIED);
   return(FALSE);
}

int do_reply_code(int reply_code)
{
   /* Send a reply to a request which returns the reply code. Function
      returns 'SL_OK' upon success, an error code otherwise. */

   char reply_char[50];
         
   memset(reply_char, 0, 50);
   sprintf(reply_char, "%d", reply_code);
   log_file_date("do_reply_code:reply=%s,l=%d", reply_char, 
                 strlen(reply_char));
   
   if (ipc_send_data(reply_char) == 0)
      return(DM_VC_ERROR);
      
   return(DM_OK);
}

int do_reply_char(int reply_code, char *parm)
{
   /* Send a reply to a request which returns the reply code and
      possibly a string. Function returns 'SL_OK' upon success,
      an error code otherwise. */

   char *reply;
         
   if ((reply = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
      return(DM_MEMORY_FAIL);
         
   memset(reply, 0, DM_MAXCOMMAND);
   
   if (parm != (char *)NULL && strlen(parm))      
      sprintf(reply, "%d '%s'", reply_code, parm);
   else
      sprintf(reply, "%d", reply_code);
      
   log_file_date("do_reply_char:reply=%s,l=%d", reply, strlen(reply));
   
   if (ipc_send_data(reply) == 0)
      {
      free(reply);
      return(DM_VC_ERROR);
      }
      
   free(reply);
   return(DM_OK);
}
   
void usage(void)
{
   /* Display program usage. */
   
   printf("usage:%s [%cq] [%cl log_file] port\n", DM_SERVICE_NAME,
          SWITCH_CHAR, SWITCH_CHAR);
}
