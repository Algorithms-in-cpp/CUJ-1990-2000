/* dumsockc - A command line for the dumb socket server 'dumsocks'.
   Rick Smereka, Copyright (C) 2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original Windows 32bit version Feb/2000, Rick Smereka
   
   Re-compiled after re-structuring the definition of the common
   send and repy codes. Apr/2000, Rick Smereka
   
   Re-compiled after adding the new 'clib' module 'ip.c'.
   Jul/2000, Rick Smereka */

#include "stdhead.h"
#include "flsocket.h"
#include "socloc.h"                   /* socket locate defines */
#include "ipclient.h"                 /* TCP client routines */
#include "sloc.h"                     /* 'socloc' client API */
#include "sconnect.h"                 /* parse connect string */
#include "dumsocks.h"                 /* dumb socket server defines */

#define VERSION "1.02.01-2000.07.03"  /* version ID */

/* default private log file definition */

#define DUM_LOG_FILE "dumsockc.log"

/* global data */

#ifdef OS_WIN32
WSADATA wsaData;                     /* struct used by 'WSAStartup()' */
SOCKET dmclientSocket;               /* client socket */
SOCKADDR_IN sockClientAddr;          /* client address structure */
LPHOSTENT lpHostEnt;                 /* host info structure */
#endif

#ifdef OS_UNIX
int dmclientSocket;
struct sockaddr_in sockClientAddr;
struct hostent *lpHostEnt;
#endif

int serverport = 0;                  /* TCP port that server is using */
int socloc_port;                     /* TCP port that 'socloc' is using */
char serverhost[256];                /* 'dumsocks' server host name */
char d_log_file[256];                /* name of client log file */

void main(void);
int d_initialize(void);
void d_term(char *);
void d_status(void);
void d_client_log_on(char *);
void d_client_log_off(void);
void d_client_log_status(void);
void d_server_log_on(char *);
void d_server_log_off(void);
void d_server_log_status(void);
void d_socloc_log_on(char *);
void d_socloc_log_off(void);
void d_socloc_log_status(void);
void d_connect(char *);
void d_socloc_get_list(void);
void d_socloc_config_get_list(void);
void d_socloc_get(void);
void d_socloc_version(void);
void d_version(void);
void d_failover(int);
void d_code_string(int, char *);
int d_sr_code(int, char *);
int d_sr_char(int, char *, char *);
int d_client_connect(void);
int get_token(char *);
void d_header(char *);
void d_out(char *,...);

void main(void)
{
   char *comm;
   int done = FALSE;

   /* allocate command line buffer */

   if ((comm = malloc(DM_MAXCOMMAND + 1)) == NULL)
      {
      printf("dumsockc:insufficient memory to run program\n");
      exit(0);
      }

   /* build logo string based on platform */

#ifndef OS_UNIX
   /* non-Unix */

   sprintf(comm, "dumsockc for %s Version %s", PLATFORM_STRING,
           VERSION);
#else
   /* Unix */

   sprintf(comm, "dumsockc for %s Version %s", SUB_PLATFORM_STRING,
           VERSION);
#endif

   printf("%s\n", comm);
   printf("By Rick Smereka, Copyright (c) 2000");

   /* initialize */

   if (!d_initialize())
      {
      free(comm);
      exit(0);
      }

   printf("dumsockc comes with ABSOLUTELY NO WARRANTY\n");
   printf("This is free software, and you are welcome to redistribute it\n");
   printf("under certain conditions; see 'gpl.txt' for information.\n");

   /* interpret loop */

   while(!done)
      {
      printf("dumsockc/%s[%d]> ", serverhost, serverport);
      gets(comm);

      if (!do_comm(comm))
         done = TRUE;
      }

   free(comm);

#ifdef OS_WIN32
   WSACleanup();
#endif
   printf("exit dumsockc\n");
   exit(0);
}

int d_initialize(void)
{
   /* Start socket communication, locate a 'socloc' server
      and connect to a 'dumsocks' server. Function returns
      'TRUE' if the initialization was successful, 'FALSE'
      otherwise. */

   char mname[] = "d_initialize";
   char *thelist, mes[128];
   int ret;

   log_file_date("%s:enter", mname);

   /* startup WinSock (if Windoze) */

#ifdef OS_WIN32
   if (WSAStartup(WINSOCK_VERSION, &wsaData))
      {
      d_out("%s:unable to start WinSock. "
            "Program abort", mname);
      WSACleanup();
      return(FALSE);
      }
#endif

   /* attempt to connect to a 'socloc' server */

   if ((ret = sloc_initialize()) != SL_OK)
      {
      sl_code_string(ret, mes);
      d_out("%s:bad rc[%s] from 'sloc_initialize'. "
            "Program abort", mname, mes);
#ifdef OS_WIN32
      WSACleanup();
#endif
      return(FALSE);
      }

   /* locate a 'dumsocks' server */

   if ((ret = sloc_find(DM_SERVICE_NAME, serverhost, &serverport,
        (char *)NULL)) != SL_OK)
      {
      sl_code_string(ret, mes);
      d_out("%s:bad rc[%s] from 'sloc_find'. Program abort", mname, mes);
#ifdef OS_WIN32
      WSACleanup();
#endif
      return(FALSE);
      }

   d_out("%s:found 'dumsocks' server on host '%s' port %d", mname,
         serverhost, serverport);

   /* get config list from 'socloc' server and update
      the client list with it */
      
   if ((thelist = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
      {
      d_out("%s:alloc fail[thelist]", mname);
#ifdef OS_WIN32
      WSACleanup();
#endif
      return(FALSE);
      }

   if ((ret = sloc_config_get_list(thelist)) != SL_OK)
      {
      free(thelist);
      sl_code_string(ret, mes);
      d_out("%s:bad rc[%s] from 'sloc_config_get_list'", mname, mes);
#ifdef OS_WIN32
      WSACleanup();
#endif
      return(FALSE);
      }
      
   if ((ret = sl_config_put_list(thelist)) != SL_OK)
      {
      sl_code_string(ret, mes);
      d_out("%s:bad rc[%s] from 'sl_config_put_list'",
                    mname, mes);
      free(thelist);
#ifdef OS_WIN32
      WSACleanup();
#endif
      return(FALSE);
      }

   /* load the port that the current 'socloc' server is
      using */
      
   sloc_get_active_socloc(thelist, &socloc_port);
   free(thelist);   
   strcpy(d_log_file, DUM_LOG_FILE);
   return(TRUE);
}

int do_comm(char *comm)
{
   /* Dispatch a 'dumsockc' command. Function always returns
      'TRUE' except when the 'off' command is detected. */

   char mname[] = "do_comm";
   char *keywrd;                 /* command keyword */
   int token;                    /* keyword token */
   int nwords;                   /* number of words */
   int len;                      /* length of command */

   log_file_date("%s:enter", mname);
   len = strlen(comm);

   if (!len)
      {
      d_out("empty command");
      return(TRUE);
      }

   /* allocate to max as this string is re-used for the return
      status string */

   if ((keywrd = malloc(DM_MAXCOMMAND + 1)) == NULL)
      {
      d_out("%s:alloc fail[keywrd]", mname);
      return(TRUE);
      }

   if (!word(comm, keywrd, 1))
      {
      d_out("%s:error while retreving keyword, line skipped", mname);
      free(keywrd);
      return(TRUE);
      }

   nwords = words(comm);

   if ((token = get_token(keywrd)) == DMCOM_NOT_FOUND)
      {
      d_out("%s:unknown keyword[%s]", mname, keywrd);
      free(keywrd);
      return(TRUE);
      }

   /* process command */

   switch(token)
      {
      case DMCOM_TERM:
         d_term(comm);
         break;

      case DMCOM_STATUS:
         d_status();
         break;

      case DMCOM_CLIENT_LOG_ON:
         d_client_log_on(comm);
         break;
      
      case DMCOM_CLIENT_LOG_OFF:
         d_client_log_off();
         break;

      case DMCOM_CLIENT_LOG_STATUS:
         d_client_log_status();
         break;
         
      case DMCOM_SERVER_LOG_ON:
         d_server_log_on(comm);
         break;
      
      case DMCOM_SERVER_LOG_OFF:
         d_server_log_off();
         break;

      case DMCOM_SERVER_LOG_STATUS:
         d_server_log_status();
         break;
                  
      case DMCOM_CONNECT:
         d_connect(comm);
         break;
         
      case DMCOM_SOCLOC_GET_LIST:
         d_socloc_get_list();
         break;

      case DMCOM_SOCLOC_CONFIG_GET_LIST:
         d_socloc_config_get_list();
         break;
        
      case DMCOM_SOCLOC_GET:
         d_socloc_get();
         break;

      case DMCOM_SOCLOC_LOG_OFF:
         d_socloc_log_off();
         break;
         
      case DMCOM_SOCLOC_LOG_ON:
         d_socloc_log_on(comm);
         break;
         
      case DMCOM_SOCLOC_LOG_STATUS:
         d_socloc_log_status();
         break;

      case DMCOM_SOCLOC_VERSION:
         d_socloc_version();
         break;
         
      case DMCOM_VERSION:
         d_version();
         break;
                                     
      case DMCOM_OFF:
         return(FALSE);
         break;

      default:
         d_out("%s:command not found", mname);
         free(keywrd);
         return(TRUE);
      };

   free(keywrd);         
   return(TRUE);
}

void d_term(char *comm)
{
   /* Terminate a 'dumsocks' server. Syntax:
   
         term passwd
         
      Where 'passwd' is the termination password. */

   char mname[] = "d_term";
   char passwd[128], parm[128];
   int ret;

   d_header(mname);

   if (command_words(comm) < 2)
      {
      d_out("%s:no password,access denied", mname);
      return;
      }

   if (!command_word(comm, passwd, 2))
      {
      d_out("%s:error getting password", mname);
      return;
      }

   if (words(passwd) > 1)
      sprintf(parm, "'%s'", passwd);
   else
      strcpy(parm, passwd);
      
   ret = d_sr_code(DM_SEND_TERM, parm);

   /* if a socket error, failover */

   if (ret == DM_VC_ERROR)
      {
      d_out("%s:socket communication error", mname);
      d_failover(TRUE);
      return;
      }

   /* if shutdown was successful, failover to
      next 'dumsocks' server */

   if (ret == DM_OK)
      {
      d_out("%s:'dumsocks' server '%s' is down", mname, serverhost);
      d_failover(FALSE);
      return;
      }

   if (is_log_active())      
      log_file_date("%s:normal exit rc[%d]", mname, ret);
   else
      {
      d_code_string(ret, parm);
      printf("%s\n", parm);
      }
}

void d_status(void)
{
   /* Get 'dumsocks' server status. Syntax:
   
         status */        

   char mname[] = "d_status";
   char mes[128];
   int ret;

   d_header(mname);
   ret = d_sr_code(DM_SEND_STATUS, (char *)NULL);

   /* if a socket error, failover */

   if (ret == DM_VC_ERROR)
      {
      d_out("%s:socket communication error", mname);
      d_failover(TRUE);
      return;
      }

   if (is_log_active())
      log_file_date("%s:normal exit rc[%d]", mname, ret);
   else
      {
      d_code_string(ret, mes);
      printf("%s\n", mes);
      }
}

void d_client_log_on(char *comm)
{
   /* Turn client logging on with optional log file name.
      Syntax:
      
         client.log.on[ log.fname]
         
      Where 'log.fname' is the optional log file name. If no
      log file name is given 'DUM_LOG_FILE' will be used.
      It is an error if client logging is already on. */
      
   char mname[] = "d_client_log_on"; 

   d_header(mname);

   if (is_log_active())
      {
      d_out("%s:log already on", mname);
      return;
      }

   if (command_words(comm) > 1)
      {
      if (!command_word(comm, d_log_file, 2))
         {
         d_out("%s:error getting log file name", mname);
         return;
         }
       }
    else
       strcpy(d_log_file, DUM_LOG_FILE);
         
   if (!log_start(d_log_file))
      {
      d_out("%s:error writing log file", mname);
      return;
      }
      
   if (is_log_active())
      log_file_date("%s:normal exit[0]", mname);
   else
      printf("ok\n");
}

void d_client_log_off(void)
{
   /* Turn client logging off. Syntax:
   
         client.log.off
         
      It is an error if client logging is already off. */
      
   char mname[] = "d_client_log_off";   

   d_header(mname);

   if (!is_log_active())
      {
      d_out("%s:log already off", mname);
      return;
      }

   if (is_log_active())
      log_file_date("%s:normal exit[0]", mname);
   else
      printf("ok\n");
      
   log_end();
}

void d_client_log_status(void)
{
   /* Display status of client logging. Syntax:
   
         client.log.status */         
      
   char mname[] = "d_client_log_status";
   
   d_header(mname);
   
   if (is_log_active())
      log_file_date("%s:client log is on", mname);
   else   
      printf("%s:client log is off\nok\n", mname);      
}
   
void d_server_log_on(char *comm)
{  
   /* Tell server to turn its logging on. Syntax:
   
         server.log.on[ log_fname]

      If no 'log_fname' is given, the default sever log file
      name will be used. It is an error if server logging is
      already on. */

   char mname[] = "d_server_log_on";
   char tmp[256], slog[256];
   int ret;

   d_header(mname);
   
   if (command_words(comm) > 1)
      {
      if (!command_word(comm, tmp, 2))
         {
         d_out("%s:error getting server log file name", mname);
         return;
         }
         
      if (words(tmp) > 1)
         sprintf(slog, "'%s'", tmp);
      else
         strcpy(slog, tmp);
         
      ret = d_sr_code(DM_SEND_LOG_ON, slog);
      }
   else
      ret = d_sr_code(DM_SEND_LOG_ON, (char *)NULL);

   /* if a socket error, failover */

   if (ret == DM_VC_ERROR)
      {
      d_out("%s:socket communication error", mname);
      d_failover(TRUE);
      return;
      }
         
   if (is_log_active())
      log_file_date("%s:normal exit rc[%d]", mname, ret);
   else
      {
      d_code_string(ret, tmp);
      printf("%s\n", tmp);
      }
}

void d_server_log_off(void)
{
   /* Tell server to turn its logging off. Syntax:
   
         server.log.off
         
      It is an error if the server log is already off. */

   char mname[] = "d_server_log_off";
   char mes[128];
   int ret;

   d_header(mname);
   ret = d_sr_code(DM_SEND_LOG_OFF, (char *)NULL);

   /* if a socket error, failover */

   if (ret == DM_VC_ERROR)
      {
      d_out("%s:socket communication error", mname);
      d_failover(TRUE);
      return;
      }
   
   if (is_log_active())
      log_file_date("%s:normal exit rc[%d]", mname, ret);
   else
      {
      d_code_string(ret, mes);
      printf("%s\n", mes);
      }
}

void d_server_log_status(void)
{
   /* Get status of server logging. Syntax:
   
         server.log.status */         
   
   char mname[] = "d_server_log_status";
   char mes[128];
   int ret;
   
   d_header(mname);
   ret = d_sr_code(DM_SEND_LOG_STATUS, (char *)NULL);

   /* if a socket error, failover */

   if (ret == DM_VC_ERROR)
      {
      d_out("%s:socket communication error", mname);
      d_failover(TRUE);
      return;
      }
      
   if (ret == DM_LOG_ALREADY_ON)
      {
      d_out("%s:server log is active", mname);
      
      if (is_log_active())
         log_file_date("%s:normal exit,rc[0]", mname);
         
      return;
      } 
         
   if (ret == DM_LOG_ALREADY_OFF)
      {
      d_out("%s:server log is inactive", mname);
      
      if (is_log_active())
         log_file_date("%s:normal exit,rc[0]", mname);
         
      return;
      }
      
   d_code_string(ret, mes);
   
   if (is_log_active())
      log_file_date("%s:normal exit,rc[%d]", mname, ret);
   else
      {
      d_code_string(ret, mes);
      printf("%s\n", mes);
      }
}

void d_socloc_log_on(char *comm)
{  
   /* Tell 'socloc' server to turn its logging on. Syntax:
   
         socloc.log.on[ log_fname]

      If no 'log_fname' is given, the default sever log file
      name will be used. It is an error if server logging is
      already on. */

   char mname[] = "d_socloc_log_on";
   char tmp[256], slog[256];
   int ret;

   d_header(mname);
   
   if (command_words(comm) > 1)
      {
      if (!command_word(comm, tmp, 2))
         {
         d_out("%s:error getting server log file name", mname);
         return;
         }
         
      if (words(tmp) > 1)
         sprintf(slog, "'%s'", tmp);
      else
         strcpy(slog, tmp);
         
      ret = sloc_log_on(slog);
      }
   else
      ret = sloc_log_on((char *)NULL);
         
   if (is_log_active())
      log_file_date("%s:normal exit rc[%d]", mname, ret);
   else
      {
      sl_code_string(ret, tmp);
      printf("%s\n", tmp);
      }
}

void d_socloc_log_off(void)
{
   /* Tell 'socloc' server to turn its logging off. Syntax:
   
         socloc.log.off
         
      It is an error if the server log is already off. */

   char mname[] = "d_socloc_log_off";
   char mes[128];
   int ret;

   d_header(mname);
   ret = sloc_log_off();
   
   if (is_log_active())
      log_file_date("%s:normal exit rc[%d]", mname, ret);
   else
      {
      sl_code_string(ret, mes);
      printf("%s\n", mes);
      }
}

void d_socloc_log_status(void)
{
   /* Get status of 'socloc' server logging. Syntax:
   
         socloc.log.status */
   
   char mname[] = "d_socloc_log_status";
   char mes[128];
   int ret, lflag;
   
   d_header(mname);
   ret = sloc_log_status(&lflag, mes);
    
   if (ret != SL_OK)
      {
      if (is_log_active())
         log_file_date("%s:normal exit,rc[%d]", mname, ret);
      else
         {
         sl_code_string(ret, mes);
         printf("%s\n", mes);
         }
         
      return;
      }
      
   if (lflag)
      d_out("%s:socloc server log is active,log is %s", mname, mes);
   else
      d_out("%s:socloc server log is inactive,log is %s", mname, mes);
      
   if (is_log_active())
      log_file_date("%s:normal exit,rc[0]", mname);
}
   
void d_connect(char *comm)
{
   /* Connect to any 'dumsocks' server. Syntax is:
   
         connect [host host_name][ port port_num][ ip ip_ad]
         
      All parameters except 'connect' keyword are optional. If no
      server details are supplied, a re-connect will be attempted
      to the first 'dumsocks' server. */
      
   char mname[] = "d_connect";
   char mes[128], *hname, *ip_ad;   
   int pos, ret, port, nwords;

   d_header(mname);
   nwords = command_words(comm);

   if (nwords < 2)
      {
      /* if only 'connect' keyword, re-lookup first 'dumsocks' server */

      if ((ret = sloc_find(DM_SERVICE_NAME, serverhost, &serverport,
           (char *)NULL)) != SL_OK)
         {
         d_out("%s:bad rc[%d] from 'sloc_find'", mname, ret);
         return;
         }

      d_status();         
      return;
      }

   /* alloc details */

   if ((hname = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
      {
      d_out("%s:alloc fail[hname]", mname);
      return;
      } 

   if ((ip_ad = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
      {
      d_out("%s:alloc fail[ip_ad]", mname);
      free(hname);      
      return;
      }   

   /* get the position of the second command word */
   
   pos = command_indxword(comm, 2);
   
   /* if the first char in the second word is a quote,
      'command_indxword' will skip over this, we need to
      backup one position */
      
   if (comm[pos - 1] == '\"' || comm[pos - 1] == '\'')
      pos--;

   /* parse the connect string */
   
   if ((ret = sconnect_parse(&comm[pos], FALSE, (char *)NULL, hname,
                             &port, ip_ad)) != SP_OK)
      {
      sp_code_string(ret, mes);
      d_out("%s:bad rc[%d,%s] from 'sconnect_parse'", mname, ret, mes);         
      free(hname);
      free(ip_ad);      
      return;
      }
      
   /* locate the 'dumsocks' server based on supplied details */
   
   if ((ret = sloc_ll_find(DM_SERVICE_NAME, hname, &port, ip_ad)) != SL_OK)
      {
      sl_code_string(ret, mes);
      d_out("%s:bad rc[%d,%s] from 'sloc_ll_find'", mname, ret, mes);         
      free(hname);
      free(ip_ad);
      return;
      }

   strcpy(serverhost, hname);
   serverport = port;
   d_status();
   free(hname);
   free(ip_ad);

   if (is_log_active())   
      log_file_date("%s:normal exit rc[%d]", mname, ret);
}

void d_socloc_get_list(void)
{
   /* Get the list of available 'dumsocks' servers from 'socloc'.
      Syntax:
      
         socloc.get.list */         
      
   char mname[] = "d_socloc_get_list";
   char *list_out, *entry, *hname, *port_char, *ip_ad;
   int ret, nentries, i;

   d_header(mname);
   
   if ((list_out = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
      {
      d_out("%s:alloc fail[list_out]", mname);
      return;
      } 

   ret = sloc_find_list(DM_SERVICE_NAME, list_out);
                           
   if (ret == DM_OK)
      {
      d_out("current 'dumsocks' servers");
      nentries = ll_words(list_out, SL_LIST_DELIM);
      
      if ((entry = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
         {
         d_out("%s:alloc fail[entry]", mname);
         free(list_out);
         return;
         }
         
      if ((hname = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
         {
         d_out("%s:alloc fail[hname]", mname);
         free(list_out);
         free(entry);
         return;
         }

      if ((port_char = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
         {
         d_out("%s:alloc fail[port_char]", mname);
         free(list_out);
         free(entry);
         free(hname);
         return;
         }

      if ((ip_ad = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
         {
         d_out("%s:alloc fail[ip_ad]", mname);
         free(list_out);
         free(entry);
         free(hname);
         free(port_char);
         return;
         }

      for(i = 1; i <= nentries; i++)
         {
         if (!ll_word(list_out, entry, i, SL_LIST_DELIM))
            {
            d_out("%s:error geting list entry[%d]", mname, i);
            free(list_out);
            free(entry);
            free(hname);
            free(port_char);
            free(ip_ad);
            return;
            }

         /* service name is first command word, we bypass this */
                     
         if (!command_word(entry, hname, 2))
            {
            d_out("%s:error getting host from entry[%d]", mname, i);
            free(list_out);
            free(entry);
            free(hname);
            free(port_char);
            free(ip_ad);
            return;
            }
            
         if (!command_word(entry, port_char, 3))
            {
            d_out("%s:error getting port from entry[%d]", mname, i);
            free(list_out);
            free(entry);
            free(hname);
            free(port_char);
            free(ip_ad);
            return;
            }
            
         if (command_words(entry) > 3)
            {
            if (!command_word(entry, ip_ad, 4))
               {
               d_out("%s:error getting ip from entry[%d]", mname, i);
               free(list_out);
               free(entry);
               free(hname);
               free(port_char);
               free(ip_ad);
               return;
               }
            }
         else
            ip_ad[0] = EOS;                        
         
         if (strlen(ip_ad))
            d_out("dumsocks[%d]:host=%s,port=%s,ip=%s", i, hname,
                  port_char, ip_ad);
         else
            d_out("dumsocks[%d]:host=%s,port=%s", i, hname, port_char);
         }
         
      free(entry);
      free(hname);
      free(port_char);
      free(ip_ad);
      }   
      
   if (is_log_active())
      log_file_date("%s:normal exit rc[%d]", mname, ret);
   else
      {
      sl_code_string(ret, list_out);
      printf("%s\n", list_out);
      }

   free(list_out);
}
 
void d_socloc_config_get_list(void)
{
   /* Get the list of available 'socloc' servers.
      Syntax:
      
         socloc.config.get.list */         
      
   char mname[] = "d_socloc_config_get_list";
   char *list_out, *entry, *hname, *port_char, *ip_ad;
   int ret, nentries, i;

   d_header(mname);
   
   if ((list_out = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
      {
      d_out("%s:alloc fail[list_out]", mname);
      return;
      } 

   ret = sloc_config_get_list(list_out);
                           
   if (ret == DM_OK)
      {
      d_out("current 'socloc' servers");
      nentries = ll_words(list_out, SL_LIST_DELIM);
      
      if ((entry = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
         {
         d_out("%s:alloc fail[entry]", mname);
         free(list_out);
         return;
         }
         
      if ((hname = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
         {
         d_out("%s:alloc fail[hname]", mname);
         free(list_out);
         free(entry);
         return;
         }

      if ((port_char = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
         {
         d_out("%s:alloc fail[port_char]", mname);
         free(list_out);
         free(entry);
         free(hname);
         return;
         }

      if ((ip_ad = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
         {
         d_out("%s:alloc fail[ip_ad]", mname);
         free(list_out);
         free(entry);
         free(hname);
         free(port_char);
         return;
         }

      for(i = 1; i <= nentries; i++)
         {
         if (!ll_word(list_out, entry, i, SL_LIST_DELIM))
            {
            d_out("%s:error geting list entry[%d]", mname, i);
            free(list_out);
            free(entry);
            free(hname);
            free(port_char);
            free(ip_ad);
            return;
            }
            
         if (!command_word(entry, hname, 1))
            {
            d_out("%s:error getting host from entry[%d]", mname, i);
            free(list_out);
            free(entry);
            free(hname);
            free(port_char);
            free(ip_ad);
            return;
            }
            
         if (!command_word(entry, port_char, 2))
            {
            d_out("%s:error getting port from entry[%d]", mname, i);
            free(list_out);
            free(entry);
            free(hname);
            free(port_char);
            free(ip_ad);
            return;
            }
            
         if (command_words(entry) > 2)
            {
            if (!command_word(entry, ip_ad, 3))
               {
               d_out("%s:error getting ip from entry[%d]", mname, i);
               free(list_out);
               free(entry);
               free(hname);
               free(port_char);
               free(ip_ad);
               return;
               }
            }
         else
            ip_ad[0] = EOS;
                        
         if (strlen(ip_ad))
            d_out("socloc[%d]:host=%s,port=%s,ip=%s", i, hname, 
                  port_char, ip_ad);
         else
            d_out("socloc[%d]:host=%s,port=%s", i, hname, port_char);
         }
         
      free(entry);
      free(hname);
      free(port_char);
      free(ip_ad);
      }   
      

   if (is_log_active())
      log_file_date("%s:normal exit rc[%d]", mname, ret);
   else
      {
      sl_code_string(ret, list_out);
      printf("%s\n", list_out);
      }

   free(list_out);
}

void d_socloc_get(void)
{
   /* Get and display the current 'socloc' server. Syntax:
   
         socloc.get */         
      
   char mname[] = "d_socloc_get";
   char hname[256];
   int port;
   
   d_header(mname);
   hname[0] = EOS;
   port = 0;
   sloc_get_active_socloc(hname, &port);
   
   if (strlen(hname))
      d_out("connected to 'socloc' server '%s' on port %d", hname, port);
   else
      d_out("no current 'socloc' server");
      
   log_file_date("%s:normal exit", mname);
}   

void d_socloc_version(void)
{
   /* Get the version ID of the current 'socloc' server.
      Syntax:
      
         socloc.version */
         
   char mname[] = "d_socloc_version";
   char versionid[128];
   int ret;
   
   d_header(mname);
   ret = sloc_version(versionid);
   
   if (ret == SL_OK)
      d_out("'socloc' version ID is '%s'", versionid);
   else
      {
      d_code_string(ret, versionid);
      d_out("%s", versionid);
      }
      
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
}

void d_version(void)
{
   /* Get the 'dumsocks' server version ID. Syntax:
   
         version */
         
   char mname[] = "d_version";
   char versionid[128];
   int ret;
   
   d_header(mname);
   ret = d_sr_char(DM_SEND_VERSION, (char *)NULL, versionid);
   
   if (ret == DM_OK)
      d_out("'dumsocks' version ID is '%s'", versionid);
   else
      {
      d_code_string(ret, versionid);
      d_out("%s", versionid);
      }
      
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
}
   
void d_failover(int dflag)
{
   /* Failover to another 'dumsocks' server. The flag 'dflag'
      indicates whether we should get 'socloc' to delete the
      old entry. */
   
   char mname[] = "d_failover";
   char mes[138];
   int ret;

   d_header(mname);

   if (dflag)
      if ((ret = sloc_delete(serverport)) != SL_OK)
         {
         sl_code_string(ret, mes);
         d_out("%s:bad rc[%s] from 'sloc_delete'", mname, mes);
         }

   if ((ret = sloc_find(DM_SERVICE_NAME, serverhost, &serverport,
        (char *)NULL)) != SL_OK)
      {
      sl_code_string(ret, mes);
      d_out("%s:bad rc[%s] from 'sloc_find'", mname, mes);
      return;
      }

   if (is_log_active())
      log_file_date("%s:normal exit,failover ok,h=%s,p=%d", mname,
                    serverhost, serverport);
   else
      printf("failover to host '%s' on port %d successful\n",
             serverhost, serverport);
}

void d_code_string(int ret, char *mes)
{
   /* Translate a 'dumsocks' return code to English. 'mes' must
      already be allocated to sufficient size. */

   switch(ret)
      {
      case DM_OK:
         strcpy(mes, "ok");
         break;

      case DM_ACCESS_DENIED:
         strcpy(mes, "access denied");
         break;

      case DM_MEMORY_FAIL:
         strcpy(mes, "memory allocation error");
         break;

      case DM_INVALID_FUNCTION:
         strcpy(mes, "invalid function");
         break;

      case DM_INTERNAL_ERROR:
         strcpy(mes, "internal server error");
         break;

      case DM_INVALID_PARAMETER:
         strcpy(mes, "invalid parameter");
         break;

      case DM_VC_ERROR:
         strcpy(mes, "socket communication error");
         break;

      case DM_LOG_ALREADY_OFF:
         strcpy(mes, "log already off");
         break;

      case DM_LOG_ALREADY_ON:
         strcpy(mes, "log already on");
         break;

      case DM_NO_SERVER:
         strcpy(mes, "not connected to dumsocks server");
         break;

      case DM_NOT_FOUND:
         strcpy(mes, "not found");
         break;

      case DM_LOG_ERROR:
         strcpy(mes, "error writing to log file");
         break;
         
      default:
         strcpy(mes, "unknown code");
      };
}

int d_sr_code(int typ, char *parm)
{
   /* Send and recveive a message to the 'dumsocks' server that returns
      only a return code. Its ok if 'parm' is NULL or empty.
      Function returns a 'dumsocks' code. */

   char *mess;
   int len, full_len, ret;

   /* make sure we are connected */

   if (!serverport || serverhost == (char *)NULL || !strlen(serverhost))
      return(DM_NO_SERVER);

   if ((ret = d_client_connect()) != DM_OK)
      return(ret);

   // estimate length and alloc send/receive buffer

   len = (parm == (char *)NULL) ? 0 : strlen(parm);
   full_len = len + 5;

   if ((mess = (char *)malloc(full_len)) == (char *)NULL)
      {
#ifdef OS_WIN32
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif

      return(DM_MEMORY_FAIL);
      }

   memset(mess, 0, full_len);

   // format send string

   if (parm == (char *)NULL || !len)
      sprintf(mess, "%d", typ);
   else
      sprintf(mess, "%d %s", typ, parm);

   // send message

   if (!ipc_send(dmclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif

      free(mess);
      return(DM_VC_ERROR);
      }

   memset(mess, 0, full_len);

   // receive return code

   if (!ipc_recv(dmclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif

      free(mess);
      return(DM_VC_ERROR);
      }

   // make sure its a number

   if (!qatoi(mess, &ret))
      {
#ifdef OS_WIN32      
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif
      
      free(mess);
      return(DM_INTERNAL_ERROR);
      }

#ifdef OS_WIN32      
   (void)closesocket(dmclientSocket);
#else
   close(dmclientSocket);
#endif
   
   free(mess);
   return(ret);
}

int d_sr_char(int typ, char *parm, char *char_out)
{
   /* Send and recveive a message to the 'dumsocks' server that
      returns a string as well as a return code. 'char_out' must
      already be allocated to sufficient size for the receiving string.
      Its ok if 'parm' is NULL or empty. Function returns a
      'dumsocks' code. */

   char *mess, tmp[50];
   int len, full_len, nwords, pos, ret;

   if (!serverport || serverhost == (char *)NULL || !strlen(serverhost))
      return(DM_NO_SERVER);

   if ((ret = d_client_connect()) != DM_OK)
      return(ret);

   char_out[0] = EOS;
      
   // estimate length and alloc send/receive buffer
      
   len = (parm == (char *)NULL) ? 0 : strlen(parm);
   full_len = len + 5;
   
   if ((mess = (char *)malloc(full_len)) == (char *)NULL)
      {
#ifdef OS_WIN32      
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif
      
      return(DM_MEMORY_FAIL);
      }
      
   memset(mess, 0, full_len);
   
   // format send string
   
   if (parm == (char *)NULL || !len)
      sprintf(mess, "%d", typ);
   else
      sprintf(mess, "%d %s", typ, parm);
      
   // send message
   
   if (!ipc_send(dmclientSocket, mess))
      {
#ifdef OS_WIN32      
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif
      
      free(mess);
      return(DM_VC_ERROR);
      }

   free(mess);
   
   // re-allocate 'mess' for receive buffer (max size)
   
   if ((mess = (char *)malloc(DM_MAXCOMMAND)) == (char *)NULL)
      {
#ifdef OS_WIN32      
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif
      
      return(DM_MEMORY_FAIL);
      }
           
   memset(mess, 0, DM_MAXCOMMAND);
   
   // receive reply
   
   if (!ipc_recv(dmclientSocket, mess))
      {
#ifdef OS_WIN32      
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif
      
      free(mess);
      return(DM_VC_ERROR);
      }

   // s/b two words in reply
   
   nwords = command_words(mess);

   // s/b reply code in word one
   
   if (!command_word(mess, tmp, 1))
      {
#ifdef OS_WIN32      
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif
      
      free(mess);
      return(DM_INTERNAL_ERROR);
      }
      
   // make sure its a number
    
   if (!qatoi(tmp, &ret))
      {
#ifdef OS_WIN32      
      (void)closesocket(dmclientSocket);
#else
      close(dmclientSocket);
#endif
      
      free(mess);
      return(DM_INTERNAL_ERROR);
      }
      
   // if reply is 'ok', load 'char_out'
   
   if (ret == DM_OK)
      {
      if (nwords < 2)
         {
#ifdef OS_WIN32      
         (void)closesocket(dmclientSocket);
#else
         close(dmclientSocket);
#endif
         
         free(mess);
         return(DM_INTERNAL_ERROR);
         }
   
      // 'char_value' is from the end of the first word
      
      if ((pos = command_indxword(mess, 2)) == -1)
         {
#ifdef OS_WIN32      
         (void)closesocket(dmclientSocket);
#else
         close(dmclientSocket);
#endif
         
         free(mess);
         return(DM_INTERNAL_ERROR);
         }         

      /* if second command word starts with quote backup one */
      
      if (mess[pos - 1] == '\'' || mess[pos - 1] == '"')
         pos -= 1;
         
      len = strlen(mess) - pos;
      strncpy(char_out, &mess[pos], len);
      char_out[len] = EOS;
      }

#ifdef OS_WIN32      
   (void)closesocket(dmclientSocket);
#else
   close(dmclientSocket);
#endif
      
   free(mess);         
   return(ret);
}

int d_client_connect(void)
{
   /* Connect to the 'dumsocks' server. An attempt to open the TCP
      socket is made. The host name 'serverhost' and the
      TCP port 'serverport' are assumed to be already loaded.
      Function returns 'DM_OK' if a successful connection was
      made, a 'dumsocks' code otherwise. */   

   /* make sure host name and port are loaded */
   
   if (!serverport || !strlen(serverhost))
      return(DM_NO_SERVER);     
                 
   /* resolve server host name */
   
   lpHostEnt = gethostbyname(serverhost);     
   
   if (!lpHostEnt)    
      return(DM_VC_ERROR);
           
   /* create the socket */
   
#ifdef OS_WIN32   
   dmclientSocket = socket(PF_INET, SOCK_STREAM, DEFAULT_PROTOCOL);
#endif   
        
#ifdef OS_UNIX
   dmclientSocket = socket(AF_INET, SOCK_STREAM, DEFAULT_PROTOCOL);
#endif   
   
   if (dmclientSocket == INVALID_SOCKET)
      return(DM_VC_ERROR);
     
   /* load client address data */

   memset(&sockClientAddr, 0, sizeof(sockClientAddr));         
   sockClientAddr.sin_family = AF_INET;
   sockClientAddr.sin_port = htons(serverport);
   
#ifdef OS_WIN32   
   sockClientAddr.sin_addr = *((LPIN_ADDR)*lpHostEnt->h_addr_list);
#endif   
   
#ifdef OS_UNIX
   sockClientAddr.sin_addr.s_addr = ((struct in_addr *)(lpHostEnt->h_addr))->s_addr;
#endif
      
   /* connect to server */
     
#ifdef OS_WIN32   
   if (connect(dmclientSocket, (LPSOCKADDR)&sockClientAddr, sizeof(sockClientAddr)))
#endif

#ifdef OS_UNIX
   if (connect(dmclientSocket, &sockClientAddr, sizeof(sockClientAddr)) == SOCKET_ERROR)
#endif   

      return(DM_VC_ERROR);
           
   return(DM_OK);
}

int get_token(char *keywrd)
{
   /* Get keyword token. */

   char mname[] = "get_token";
   int i;
   int token = DMCOM_NOT_FOUND;

   /* static array of command words, notice the dummy zero position */

   static char *coms[] = { " ", "TERM", "STATUS", "CLIENT.LOG.OFF",
                           "CLIENT.LOG.ON", "CLIENT.LOG.STATUS",
                           "SERVER.LOG.OFF", "SERVER.LOG.ON",
                           "SERVER.LOG.STATUS", "CONNECT",
                           "SOCLOC.GET.LIST", "SOCLOC.CONFIG.GET.LIST",
                           "SOCLOC.GET", "SOCLOC.LOG.OFF",
                           "SOCLOC.LOG.ON", "SOCLOC.LOG.STATUS",
                           "SOCLOC.VERSION", "VERSION" };

   log_file_date("%s:enter,keywrd='%s'", mname, keywrd);
   
   /* check for 'OFF' keyword separately */

   if (!stricmp(keywrd, "OFF"))
      {
      log_file_date("%s:found 'OFF' keyword", mname);      
      return(DMCOM_OFF);
      }

   for(i = 1; i <= DMCOM_MAXCOM; i++)      
      if (!stricmp(keywrd, coms[i]))
         {
         token = i;        
         break;
         }

   log_file_date("%s:normal exit,token=%d", mname, token);
   return(token);
}

void d_header(char *mname)
{
   /* Output the function enter header if logging. */
   
   if (strlen(serverhost) && serverport != 0)
      log_file_date("%s:enter,sh=%s,sp=%d", mname, serverhost, serverport);
   else
      log_file_date("%s:enter,no connection", mname);
}
      
void d_out(char *fmt,...)
{
   /* Output a message to the screen or use 'log_file_date' to
      log the message. Output method depends on personal (client)
      logging status. Do not put a cr/lf at the end of the message.
      This will be automatically written to the end of the message. */

   char mes[MAXMES];
   va_list argptr;

   va_start(argptr, fmt);
   vsprintf(mes, fmt, argptr);
   
   if (is_log_active())
      log_file_date(mes);
   else
      printf("%s\n", mes);
}