/* A high level client api module for the socket locate service.
   Rick Smereka, Copyright (C) 2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   This API is used by both 'socloc' server and client applications.

   Original Windows 32bit version under CodeWarrior V4. Feb/2000,
   Rick Smereka

   Changed function 'sloc_log_status' to accept the returned log
   file name in addition to the code. Mar/2000, Rick Smereka

   Corrected 'sloc_client_connect' to obtain the first config
   entry using the function 'sl_config_get_first'. Modified function
   'sloc_failover' to save the current 'spos' count before entering
   the 'sloc_config_delete' loop. Jun/2000, Rick Smereka */

#include "stdhead.h"          /* standard include */
#include "flsocket.h"         /* standard socket defines */
#include "ipcomm.h"           /* low level socket send/receive */
#include "sloc.h"             /* defines for this module */
#include "socloc.h"           /* global socket locator defines */
#include "slconfig.h"         /* socket locate config management */
#include "sconnect.h"         /* connect string parse/build API */

/* global (to module) data */

#ifdef OS_WIN32
SOCKET slclientSocket;        /* client socket */
SOCKADDR_IN sockClientAddr;   /* client address structure */
LPHOSTENT lpHostEnt;          /* host info structure */
#endif

#ifdef OS_UNIX
int slclientSocket;
struct sockaddr_in sockClientAddr;
struct hostent *lpHostEnt;
#endif

char sloc_hostname[128];      /* host name of 'socloc' server */
int sloc_port = 0;            /* port 'socloc' is using */
int spos;                     /* 'staleport' array position */
int staleport[25];            /* array of dead 'socloc' ports */
int splimit = 25;             /* max of 25 dead ports allowed */
int has_failover = FALSE;     /* 'socloc' failover flag */

/* private functions */

static int sloc_ll_status(void);
static int sloc_sr_int(int, char *, int *, int);
static int sloc_sr_long(int, char *, long *, int);
static int sloc_sr_code(int typ, char *, int);
static int sloc_sr_char(int, char *, char *, int);
static int sloc_failover(void);
static int sloc_client_connect(void);
static int sloc_ll_client_connect(void);

int sloc_initialize(void)
{
   /* Initialize the client for communication with the
      socket locate server. An attempt to get the server status
      is made. Nodeid (host name), port number and optionally the
      IP address are expected in the configuration file
      'SL_CONFIG_FILE_NAME'. The format of this file is discussed
      in 'slconfig.c'. Function returns 'SL_OK' if a successful
      connection was made, a socket locate code otherwise. */

   char mname[] = "sloc_initialize";
   char hname[SL_MAXCOMMAND];
   int ret, port;

   log_file_date("%s:enter", mname);

   if ((ret = sl_config_read(SL_CONFIG_FILE_NAME)) != SL_OK)
      {
      log_file_date("%s:bad rc from 'sl_config_read',rc[%d]", mname, ret);
      return(ret);
      }

   /* manually load the first entry and call status */

   if ((ret = sl_config_get_first(hname, &port, (char *)NULL)) != SL_OK)
      {
      log_file_date("%s:bad rc from 'sl_config_get_first',rc[%d]",
                    mname, ret);
      return(ret);
      }

   strcpy(sloc_hostname, hname);
   sloc_port = port;

   if ((ret = sloc_status()) != SL_OK)
      {
      log_file_date("%s:bad rc from 'status',rc[%d]", mname, ret);
      return(ret);
      }

   log_file_date("%s:normal exit,server responding is '%s' on "
                 "port %d", mname, sloc_hostname, sloc_port);
   return(SL_OK);
}

int sloc_log_off(void)
{
   /* Turn 'socloc' server logging off.
      Function returns 'SL_OK' upon success, an error code
      otherwise. */

   char mname[] = "sloc_log_off";
   int ret;

   log_file_date("%s:enter,host=%s,port=%d", mname, sloc_hostname,
                 sloc_port);
   ret = sloc_sr_code(SL_SEND_LOG_OFF, (char *)NULL, TRUE);
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

int sloc_log_on(char *lname)
{
   /* Turn 'socloc; server logging on. Log file name 'lname'
      is optional. Function returns 'SL_OK'
      upon success, a 'socloc' code otherwise. */

   char mname[] = "sloc_log_on";
   int ret;

   log_file_date("%s:enter", mname);
   ret = sloc_sr_code(SL_SEND_LOG_ON, lname, TRUE);
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

int sloc_log_status(int *lflag, char *lfname)
{
   /* Get staus of 'socloc' server logging. Function returns
      the log status (0=off,1=on) in 'lflag' and the current
      log file name in 'lfname' upon success. Function returns a 'socloc'
      code. */

   char mname[] = "sloc_log_status";
   char reply[128], flag_char[25];
   int ret, flag;

   log_file_date("%s:enter,host=%s,port=%d", mname, sloc_hostname,
                 sloc_port);

   if (lflag == (int *)NULL)
      {
      log_file_date("%s:null pointer[lflag]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (lfname == (char *)NULL)
      {
      log_file_date("%s:null pointer[lfname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   lfname[0] = EOS;
   *lflag = 0;

   if ((ret = sloc_sr_char(SL_SEND_LOG_STATUS, (char *)NULL, reply, TRUE))
       != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sloc_sr_char'", mname, ret);
      return(ret);
      }

   if (!command_word(reply, flag_char, 1))
      {
      log_file_date("%s:error getting 'flag_char'", mname);
      return(SL_INTERNAL_ERROR);
      }

   if (!qatoi(flag_char, &flag))
      {
      log_file_date("%s:status flag is non-numeric", mname);
      return(SL_INTERNAL_ERROR);
      }

   if (flag != 0 && flag != 1)
      {
      log_file_date("%s:status flag has incorrect value", mname);
      return(SL_INTERNAL_ERROR);
      }

   *lflag = flag;

   if (!command_word(reply, lfname, 2))
      {
      log_file_date("%s:error getting 'lfname'", mname);
      return(SL_INTERNAL_ERROR);
      }

   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

int sloc_add(char *sname, char *hname, int port, char *ip_ad)
{
   /* Add a socket server entry to 'socloc'. The IP address ('ip_ad')
      may be null but if it is not null, it must be a valid
      IP address. Function returns 'SL_OK' upon success,
      a 'socloc' code otherwise. */

   char mname[] = "sloc_add";
   char *parm, *tsname, *thname;
   int len, ret;

   log_file_date("%s:enter", mname);

   if (sname == (char *)NULL || !strlen(sname))
      {
      log_file_date("%s:null or empty parm[sname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (hname == (char *)NULL || !strlen(hname))
      {
      log_file_date("%s:null or empty parm[hname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (port <= 0)
      {
      log_file_date("%s:parm out of range[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* make sure IP address (if present) is valid */

   if (ip_ad != (char *)NULL)
      if (!isip(ip_ad))
         {
         log_file_date("%s:invalid ip address", mname);
         return(SL_BAD_IP);
         }

   /* calc total length of parameter
      length of service name + host name + port + ip_ad + 5 */

   len = strlen(sname) + strlen(hname) + 30;

   if ((parm = (char *)malloc(len)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[parm]", mname);
      return(SL_MEMORY_FAIL);
      }

   /* load each string into tmp strings, expanding
      string with quotes if spaces are present */

   if ((tsname = (char *)malloc(len)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[tsname]", mname);
      free(parm);
      return(SL_MEMORY_FAIL);
      }

   if (words(sname) > 1)
      sprintf(tsname, "'%s'", sname);
   else
      strcpy(tsname, sname);

   if ((thname = (char *)malloc(len)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[thname]", mname);
      free(parm);
      free(tsname);
      return(SL_MEMORY_FAIL);
      }

   if (words(hname) > 1)
      sprintf(thname, "'%s'", hname);
   else
      strcpy(thname, hname);

   /* build final parameter string, we send a one as the
      first parameter to indicate the originating client */

   if (ip_ad != (char *)NULL)
      sprintf(parm, "1 %s %s %d %s", tsname, thname, port, ip_ad);
   else
      sprintf(parm, "1 %s %s %d", tsname, thname, port);

   free(tsname);
   free(thname);
   log_file_date("%s:parm=%s", mname, parm);
   ret = sloc_sr_code(SL_SEND_ADD, parm, TRUE);
   log_file_date("%s:exit,rc[%d]", mname, ret);
   free(parm);
   return(ret);
}

int sloc_config_add(char *hname, int port, char *ip_ad)
{
   /* Add a config entry to 'socloc'. The IP address ('ip_ad')
      may be null. Function returns 'SL_OK' upon success,
      a 'socloc' code otherwise. */

   char mname[] = "sloc_config_add";
   char *parm, *thname;
   int len, ret;

   log_file_date("%s:enter", mname);

   if (hname == (char *)NULL || !strlen(hname))
      {
      log_file_date("%s:null or empty parm[hname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (port <= 0)
      {
      log_file_date("%s:parm out of range[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* make sure IP address (if present) is valid */

   if (ip_ad != (char *)NULL)
      if (!isip(ip_ad))
         {
         log_file_date("%s:invalid ip address", mname);
         return(SL_BAD_IP);
         }

   /* calc total length of parameter
      length of host name + port + ip_ad + 5 */

   len = strlen(hname) + 30;

   if ((parm = (char *)malloc(len)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[parm]", mname);
      return(SL_MEMORY_FAIL);
      }

   /* load host name into tmp strings, expanding
      string with quotes if spaces are present */

   if ((thname = (char *)malloc(len)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[thname]", mname);
      free(parm);
      return(SL_MEMORY_FAIL);
      }

   if (words(hname) > 1)
      sprintf(thname, "'%s'", hname);
   else
      strcpy(thname, hname);

   /* build final parameter string, we send a one as the
      first parameter to indicate the originating client */

   if (ip_ad != (char *)NULL)
      sprintf(parm, "1 %s %d %s", thname, port, ip_ad);
   else
      sprintf(parm, "1 %s %d", thname, port);

   free(thname);
   ret = sloc_sr_code(SL_SEND_CONFIG_ADD, parm, TRUE);
   log_file_date("%s:exit,parm=%s,rc[%d]", mname, parm, ret);
   free(parm);
   return(ret);
}

int sloc_config_delete(int port)
{
   /* Delete a config 'socloc' entry. Function returns 'SL_OK'
      upon success, a 'socloc' code otherwise. */

   char mname[] = "sloc_config_delete";
   char parm[25];
   int ret;

   log_file_date("%s:enter", mname);

   if (port <= 0)
      {
      log_file_date("%s:parm out of range[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   sprintf(parm,"1 %d", port);
   ret = sloc_sr_code(SL_SEND_CONFIG_DELETE, parm, TRUE);
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

int sloc_status(void)
{
   /* Get 'socloc' server status.
      Function returns 'SL_OK' upon success, an error code
      otherwise. */

   char mname[] = "sloc_status";
   int ret;

   log_file_date("%s:enter,host=%s,port=%d", mname, sloc_hostname,
                 sloc_port);
   ret = sloc_sr_code(SL_SEND_STATUS, (char *)NULL, TRUE);
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

int sloc_custom_status(char *hname, int port)
{
   /* Query the status of any socket server on any port.
      Socket server must understand the status command
      code (see 'flsocket.h'). This function is mostly
      used by the 'socloc' server. Function returns
      'SL_OK' if the server is responding, a 'socloc'
      code otherwise. */

   char mname[] = "sloc_custom_status";
   char thost[128];
   int ret, tport;

   log_file_date("%s:enter", mname);

   if (hname == (char *)NULL || !strlen(hname))
      {
      log_file_date("%s:null or empty[hname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (port <= 0)
      {
      log_file_date("%s:negative or zero value[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* save current host name and port */

   strcpy(thost, sloc_hostname);
   tport = sloc_port;

   /* load new values */

   strcpy(sloc_hostname, hname);
   sloc_port = port;

   /* call low level status */

   if ((ret = sloc_ll_status()) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sloc_ll_status'", mname, ret);
      strcpy(sloc_hostname, thost);
      sloc_port = tport;
      return(ret);
      }

   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   strcpy(sloc_hostname, thost);
   sloc_port = tport;
   return(ret);
}

int sloc_service_name(char *sname)
{
   /* Get the service name of a 'socloc' server.
      Upon success, the service name will be loaded into
      'sname' which must already be allocated to sufficient
      size. Function returns a 'socloc' code. */

   char mname[] = "sloc_service_name";
   int ret;

   log_file_date("%s:enter", mname);

   if (sname == (char *)NULL)
      {
      log_file_date("%s:null[sname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if ((ret = sloc_sr_char(SL_SEND_SERVICE_NAME, (char *)NULL, sname, TRUE))
       != SL_OK)
      {
      log_file_date("%s:rc[%d] from 'sloc_sr_char'", mname, ret);
      return(ret);
      }

   return(SL_OK);
}

int sloc_version(char *version)
{
   /* Get the version of a 'socloc' server.
      Upon success, the version string will be loaded into
      'version' which must already be allocated to sufficient
      size. Function returns a 'socloc' code. */

   char mname[] = "sloc_version";
   int ret;

   log_file_date("%s:enter", mname);

   if (version == (char *)NULL)
      {
      log_file_date("%s:null[version]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if ((ret = sloc_sr_char(SL_SEND_VERSION, (char *)NULL, version, TRUE))
       != SL_OK)
      {
      log_file_date("%s:rc[%d] from 'sloc_sr_char'", mname, ret);
      return(ret);
      }

   return(SL_OK);
}

int sloc_connect(char *hname, int port)
{
   /* Attempt to connect to any 'socloc' server. Host name is
      expected in 'hname' and TCP/IP port number is expected
      in 'port'. Upon connection, the service name will be
      verified. Upon success, the 'socloc' API
      host name and port number will be set. Function returns a
      'socloc' code. */

   char mname[] = "sloc_connect";
   char thname[128], sname[128];
   int tport, ret;

   log_file_date("%s:enter", mname);

   if (hname == (char *)NULL || !strlen(hname))
      {
      log_file_date("%s:null or empty[hname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (port <= 0)
      {
      log_file_date("%s:out of range[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* save current connection values */

   strcpy(thname, sloc_hostname);
   tport = sloc_port;

   /* load new values */

   strcpy(sloc_hostname, hname);
   sloc_port = port;

   /* attempt a connection by getting service name, note that
      we do not use the function 'sloc_service_name' as it
      automatically fails over to another 'socloc' server */

   if ((ret = sloc_sr_char(SL_SEND_SERVICE_NAME, (char *)NULL, sname, FALSE))
       != SL_OK)
      {
      /* put host name and port back */

      strcpy(sloc_hostname, thname);
      sloc_port = tport;
      log_file_date("%s:bad rc[%d] from 'sloc_sr_char'", mname, ret);
      return(ret);
      }

   /* verify that this is a 'socloc' server */

   if (strcmp(sname, SL_SERVICE_NAME))
      {
      strcpy(sloc_hostname, thname);
      sloc_port = tport;
      log_file_date("%s:not a 'socloc' server", mname);
      return(SL_NOT_A_SOCLOC_SERVER);
      }

   return(SL_OK);
}

int sloc_delete(int port)
{
   /* Delete a socket server entry. Function returns 'SL_OK'
      upon success, a 'socloc' code otherwise. */

   char mname[] = "sloc_delete";
   char parm[25];
   int ret;

   log_file_date("%s:enter,port=%d", mname, port);

   if (port <= 0)
      {
      log_file_date("%s:parm out of range[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* indicate a client send with 'orig_flag' set to one */

   sprintf(parm,"1 %d", port);
   ret = sloc_sr_code(SL_SEND_DELETE, parm, TRUE);
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

int sloc_find(char *sname, char *hname, int *port, char *ip_ad)
{
   /* Find a 'socloc' entry. Only the service name is used.
      The IP address ('ip_ad') may be null. Upon success, details
      are loaded into 'hname', 'port' and optionally 'ip_ad'.
      Function returns a 'socloc' code. */

   char mname[] = "sloc_find";
   int ret;

   log_file_date("%s:enter", mname);

   if (sname == (char *)NULL || !strlen(sname))
      {
      log_file_date("%s:service name null or empty", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (hname == (char *)NULL)
      {
      log_file_date("%s:host name null", mname);
      return(SL_INVALID_PARAMETER);
      }


   if (port == (int *)NULL)
      {
      log_file_date("%s:port null", mname);
      return(SL_INVALID_PARAMETER);
      }

   hname[0] = EOS;
   *port = 0;

   if (ip_ad != (char *)NULL)
      ip_ad[0] = EOS;

   ret = sloc_ll_find(sname, hname, port, ip_ad);
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

int sloc_config_find(char *hname, int *port, char *ip_ad)
{
   /* Find a 'socloc' config entry by one or more details.
      At least one detail must be present.Upon success,
      missing details are loaded into 'hname', 'port'
      and optionally 'ip_ad'. Function returns a 'socloc' code. */

   char mname[] = "sloc_config_find";
   char *buildstr, *reply, mes[128];
   int ret, ishname, isport, isip;

   log_file_date("%s:enter", mname);
   ishname = isport = isip = TRUE;

   if (hname == (char *)NULL || !strlen(hname))
      ishname = FALSE;

   if (port == (int *)NULL || *port <= 0)
      isport = FALSE;

   if (ip_ad == (char *)NULL || !strlen(ip_ad))
      isip = FALSE;

   if (!ishname && !isport && !isip)
      {
      log_file_date("%s:no parameters", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* use 'sconnect_build' to form the connect string */

   if ((buildstr = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[buildstr]", mname);
      return(SL_MEMORY_FAIL);
      }

   if ((ret = sconnect_build((char *)NULL, hname, port, ip_ad, buildstr))
        != SP_OK)
      {
      free(buildstr);
      sp_code_string(ret, mes);
      log_file_date("%s:bad rc[%s] from 'sconnect_build'", mname, mes);
      return(SL_INVALID_PARAMETER);
      }

   if ((reply = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[reply]", mname);
      free(buildstr);
      return(SL_MEMORY_FAIL);
      }

   log_file_date("%s:parm=%s,l=%d", mname, buildstr, strlen(buildstr));
   ret = sloc_sr_char(SL_SEND_CONFIG_FIND, buildstr, reply, TRUE);
   free(buildstr);

   if (ret != SL_OK)
      {
      log_file_date("%s:exit bad rc[%d]", mname, ret);
      free(reply);
      return(ret);
      }

   log_file_date("%s:server returned=%s,l=%d", mname, reply, strlen(reply));

   /* take apart the return string and load only the missing pieces */

   if (command_words(reply) < 2)
      {
      log_file_date("%s:incorrect number of words returned", mname);
      free(reply);
      return(SL_INTERNAL_ERROR);
      }

   if ((buildstr = (char *)malloc(strlen(reply) + 1)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[buildstr]", mname);
      free(reply);
      return(SL_MEMORY_FAIL);
      }

   if (!ishname && hname != (char *)NULL)
      if (!command_word(reply, hname, 1))
         {
         log_file_date("%s:error getting host name", mname);
         free(reply);
         free(buildstr);
         return(SL_INTERNAL_ERROR);
         }

   if (!isport && port != (int *)NULL)
      {
      if (!command_word(reply, buildstr, 2))
         {
         log_file_date("%s:error getting port char", mname);
         free(reply);
         free(buildstr);
         return(SL_INTERNAL_ERROR);
         }

      if (!qatoi(buildstr, port))
         {
         log_file_date("%s:server returned port that is not a number", mname);
         free(reply);
         free(buildstr);
         return(SL_INTERNAL_ERROR);
         }
      }

   if (command_words(reply) > 2)
      if (!isip && ip_ad != (char *)NULL)
         if (!command_word(reply, ip_ad, 3))
            {
            log_file_date("%s:error getting ip address", mname);
            free(reply);
            free(buildstr);
            return(SL_INTERNAL_ERROR);
            }

   free(reply);
   free(buildstr);
   log_file_date("%s:normal exit,rc[0]", mname);
   return(SL_OK);
}

int sloc_find_list(char *sname, char *list_out)
{
   /* Find one or more 'socloc' entries by service name. All entries
      matching the service name will be loaded into 'list_out'.
      The list is delimited by 'SL_LIST_DELIM'. Function returns
      a 'socloc' code. */

   char mname[] = "sloc_find_list";
   int ret;

   log_file_date("%s:enter", mname);

   if (sname == (char *)NULL || !strlen(sname))
      {
      log_file_date("%s:service name null or empty", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (list_out == (char *)NULL)
      {
      log_file_date("%s:null 'list_out'", mname);
      return(SL_INVALID_PARAMETER);
      }

   ret = sloc_ll_find_list(sname, (char *)NULL, (int *)NULL, (char *)NULL,
                           list_out);
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

int sloc_ll_find(char *sname, char *hname, int *port, char *ip_ad)
{
   /* Find a 'socloc' entry. All parameters are optional. At least
      one parameter must be specified. The lookup will use all
      supplied parameters to perform the lookup. If you just want
      to find by service name, do not call this function, use
      'sloc_find' instead. Upon success, the missing items will
      be loaded. Function returns 'SL_OK' upon success, a
      'socloc' code otherwise. */

   char mname[] = "sloc_ll_find";
   char *buildstr, *parm, *wrd, mes[128];
   int ret;

   log_file_date("%s:enter", mname);

   if (sname == (char *)NULL)
      {
      log_file_date("%s:parm null[sname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (hname == (char *)NULL)
      {
      log_file_date("%s:parm null[hname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (port == (int *)NULL)
      {
      log_file_date("%s:parm null[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (!strlen(sname) && !strlen(hname) && *port <= 0 &&
       (ip_ad == (char *)NULL || !strlen(ip_ad)))
      {
      log_file_date("%s:at least one parameter must be supplied", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* use 'sconnect_build' to form the connect string */

   if ((buildstr = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[buildstr]", mname);
      return(SL_MEMORY_FAIL);
      }

   if ((ret = sconnect_build(sname, hname, port, ip_ad, buildstr))
        != SP_OK)
      {
      free(buildstr);
      sp_code_string(ret, mes);
      log_file_date("%s:bad rc[%s] from 'sconnect_build'", mname, mes);
      return(SL_INVALID_PARAMETER);
      }

   if ((wrd = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[wrd]", mname);
      free(buildstr);
      return(SL_MEMORY_FAIL);
      }

   log_file_date("%s:buildstr=%s,l=%d", mname, buildstr, strlen(buildstr));
   ret = sloc_sr_char(SL_SEND_FIND, buildstr, wrd, TRUE);
   free(buildstr);

   if (ret != SL_OK)
      {
      log_file_date("%s:exit bad rc[%d]", mname, ret);
      free(wrd);
      return(ret);
      }

   log_file_date("%s:server returned=%s,l=%d", mname, wrd, strlen(wrd));

   /* take apart the return string and load only the missing pieces */

   if (command_words(wrd) < 2)
      {
      log_file_date("%s:incorrect number of words returned", mname);
      log_file_date("%s:wrd=%s,l=%d", mname, wrd, strlen(wrd));
      free(wrd);
      return(SL_INTERNAL_ERROR);
      }

   if ((parm = (char *)malloc(strlen(wrd) + 1)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[parm]", mname);
      free(wrd);
      return(SL_MEMORY_FAIL);
      }

   if (!strlen(sname))
      if (!command_word(wrd, sname, 1))
         {
         log_file_date("%s:error getting service name", mname);
         free(wrd);
         free(parm);
         return(SL_INTERNAL_ERROR);
         }

   if (!strlen(hname))
      if (!command_word(wrd, hname, 2))
         {
         log_file_date("%s:error getting host name", mname);
         free(wrd);
         free(parm);
         return(SL_INTERNAL_ERROR);
         }

   if (*port == 0)
      {
      if (!command_word(wrd, parm, 3))
         {
         log_file_date("%s:error getting port char", mname);
         free(wrd);
         free(parm);
         return(SL_INTERNAL_ERROR);
         }

      if (!qatoi(parm, port))
         {
         log_file_date("%s:server returned port that is not a number", mname);
         free(wrd);
         free(parm);
         return(SL_INTERNAL_ERROR);
         }
      }

   if (command_words(wrd) > 3)
      if (ip_ad != (char *)NULL && !strlen(ip_ad))
         if (!command_word(wrd, ip_ad, 4))
            {
            log_file_date("%s:error getting ip address", mname);
            free(wrd);
            free(parm);
            return(SL_INTERNAL_ERROR);
            }

   free(wrd);
   free(parm);
   log_file_date("%s:normal exit,rc[0]", mname);
   return(SL_OK);
}

int sloc_ll_find_list(char *sname, char *hname, int *port, char *ip_ad,
                      char *list_out)
{
   /* Find one or more 'socloc' entries. All parameters are optional
      except 'list_out' which is the output list. The output list is
      delimited by 'SL_LIST_DELIM' The lookup will use all supplied
      parameters to perform the lookup. If you just want to find a list
      of socket servers by service name, do not call this function,
      use 'sloc_find_list' instead. Function returns
      'SL_OK' upon success, a 'socloc' code otherwise. */

   char mname[] = "sloc_ll_find_list";
   char *parm, mes[128];
   int ret;

   log_file_date("%s:enter", mname);

   if (sname == (char *)NULL && hname == (char *)NULL && port == (int *)NULL
       && ip_ad == (char *)NULL)
      {
      log_file_date("%s:all null parameters", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (list_out == (char *)NULL)
      {
      log_file_date("%s:null 'list_out'", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* use 'sconnect_build' to form the connect string */

   if ((parm = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[parm]", mname);
      return(SL_MEMORY_FAIL);
      }

   if ((ret = sconnect_build(sname, hname, port, ip_ad, parm))
        != SP_OK)
      {
      free(parm);
      sp_code_string(ret, mes);
      log_file_date("%s:bad rc[%s] from 'sconnect_build'", mname, mes);
      return(SL_INVALID_PARAMETER);
      }

   log_file_date("%s:parm=%s,l=%d", mname, parm, strlen(parm));
   ret = sloc_sr_char(SL_SEND_FIND_LIST, parm, list_out, TRUE);
   free(parm);
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

int sloc_get_list(char *list_out)
{
   /* Get the 'socloc' list. The delimited list is
      returned in 'list_out' which must already be allocated
      by the caller to sufficient size. Function returns
      'SL_OK' upon success, a 'socloc' code otherwise. */

   char mname[] = "sloc_get_list";
   int ret;

   if (list_out == (char *)NULL)
      {
      log_file_date("%s:invalid parameter[list_out]", mname);
      return(SL_INVALID_PARAMETER);
      }

   ret = sloc_sr_char(SL_SEND_GET_LIST, (char *)NULL, list_out, TRUE);
   log_file_date("%s:normal exit,rc=%d", mname, ret);
   return(ret);
}

int sloc_put_list(char *list_in)
{
   /* Put/write a 'socloc' list to a server. The delimited
      list (delimited by 'SL_LIST_DELIM') is expected in
      'list_in'. Function returns 'SL_OK' upon success,
      a 'socloc' code otherwise. */

   char mname[] = "sloc_put_list";
   int ret;

   if (list_in == (char *)NULL || !strlen(list_in))
      {
      log_file_date("%s:invalid parameter[list_in]", mname);
      return(SL_INVALID_PARAMETER);
      }

   ret = sloc_sr_code(SL_SEND_PUT_LIST, list_in, TRUE);
   log_file_date("%s:normal exit,rc=%d", mname, ret);
   return(ret);
}

int sloc_config_update(void)
{
   /* Get the current config list from the first active
      'socloc' server and use this list to update the
      config list in memory and write a new config file.
      Function returns 'SL_OK' upon success, a 'socloc'
      code otherwise. */

   char mname[]= "sloc_config_update";
   char *thelist;
   int ret;

   log_file_date("%s:enter", mname);

   if ((thelist = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[thelist]", mname);
      return(SL_MEMORY_FAIL);
      }

   /* get the config list from the first active server */

   if ((ret = sloc_config_get_list(thelist)) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sloc_config_get_list'",
                    mname, ret);
      free(thelist);
      return(ret);
      }

   /* create a new list in memory */

   if ((ret = sl_config_put_list(thelist)) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sl_config_put_list'",
                    mname, ret);
      free(thelist);
      return(ret);
      }

   free(thelist);

   /* write this new list to the config file */

   if ((ret = sl_config_write_file()) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sl_config_write_file'",
                    mname, ret);
      return(ret);
      }

   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(SL_OK);
}

int sloc_config_get_list(char *list_out)
{
   /* Get the 'socloc' config list. The delimited list is
      returned in 'list_out' which must already be allocated
      by the caller to sufficient size. Function returns
      'SL_OK' upon success, a 'socloc' code otherwise. */

   char mname[] = "sloc_config_get_list";
   int ret;

   log_file_date("%s:enter", mname);

   if (list_out == (char *)NULL)
      {
      log_file_date("%s:invalid parameter[list_out]", mname);
      return(SL_INVALID_PARAMETER);
      }

   ret = sloc_sr_char(SL_SEND_CONFIG_GET_LIST, (char *)NULL, list_out, TRUE);
   log_file_date("%s:normal exit,rc=%d", mname, ret);
   return(ret);
}

int sloc_config_put_list(char *list_in)
{
   /* Put/write a 'socloc' config list to a server. The delimited
      list (delimited by 'SL_LIST_DELIM') is expected in
      'list_in'. Function returns 'SL_OK' upon success,
      a 'socloc' code otherwise. */

   char mname[] = "sloc_config_put_list";
   int ret;

   log_file_date("%s:enter", mname);

   if (list_in == (char *)NULL || !strlen(list_in))
      {
      log_file_date("%s:invalid parameter[list_in]", mname);
      return(SL_INVALID_PARAMETER);
      }

   ret = sloc_sr_code(SL_SEND_CONFIG_PUT_LIST, list_in, TRUE);
   log_file_date("%s:normal exit,rc=%d", mname, ret);
   return(ret);
}

int sloc_bcast_add(char *sname, char *hname, int port, char *ip_ad)
{
   /* Send an add command to each known 'socloc' server.
      This function should only be used by a 'socloc' server.
      Note that it is not considered an error if a 'socloc'
      server does not respond or responds with an error.
      Function returns a 'socloc' code. */

   char mname[] = "sloc_bcast_add";
   char thost[128], *aentry;
   int tport, nentries, i, ret;

   log_file_date("%s:enter", mname);

   if (sname == (char *)NULL || !strlen(sname))
      {
      log_file_date("%s:invalid parameter[sname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (hname == (char *)NULL || !strlen(hname))
      {
      log_file_date("%s:invalid parameter[hname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (port <= 0)
      {
      log_file_date("%s:invalid parameter[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* save current server host name and port */

   strcpy(thost, sloc_hostname);
   tport = sloc_port;

   if ((ret = sl_config_get_nentries(&nentries)) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sl_config_get_nentries'",
                    mname, ret);
      return(ret);
      }

   log_file_date("%s:number of config entries is %d", mname, nentries);

   if ((aentry = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[aentry]", mname);
      return(SL_MEMORY_FAIL);
      }

   if (ip_ad != (char *)NULL && strlen(ip_ad))
      sprintf(aentry, "0 '%s' '%s' %d %s", sname, hname, port, ip_ad);
   else
      sprintf(aentry, "0 '%s' '%s' %d", sname, hname, port);

   /* go through list of servers, sending an add command to each
      with the 'orig_flag' set to a server (0) */

   for(i = 1; i <= nentries; i++)
      {
      if ((ret = sl_config_get_nth(i, sloc_hostname, &sloc_port, (char *)NULL)) == SL_OK)
         {
         ret = sloc_sr_code(SL_SEND_ADD, aentry, FALSE);
         log_file_date("%s[%s,%d]rc=%d", mname, sloc_hostname,
                       sloc_port, ret);
         }
      }

   /* put back current entry */

   strcpy(sloc_hostname, thost);
   sloc_port = tport;
   free(aentry);
   log_file_date("%s:normal exit", mname);
   return(SL_OK);
}

int sloc_bcast_delete(int port)
{
   /* Send a delete command to each known 'socloc' server.
      This function should only be used by a 'socloc' server.
      Note that it is not considered an error if a 'socloc'
      server does not respond or responds with an error.
      Function returns a 'socloc' code. */

   char mname[] = "sloc_bcast_delete";
   char thost[128], *aentry;
   int tport, nentries, i, ret;

   log_file_date("%s:enter,port=%d", mname, port);

   if (port <= 0)
      {
      log_file_date("%s:invalid parameter[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* save current server host name and port */

   strcpy(thost, sloc_hostname);
   tport = sloc_port;

   if ((ret = sl_config_get_nentries(&nentries)) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sl_config_get_nentries'",
                    mname, ret);
      return(ret);
      }

   log_file_date("%s:number of config entries is %d", mname, nentries);

   if ((aentry = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[aentry]", mname);
      return(SL_MEMORY_FAIL);
      }

   /* indicate a server send with the initial 'orig_flag' set to zero */

   sprintf(aentry, "0 %d", port);

   /* go through list of servers, sending a config add command to each */

   for(i = 1; i <= nentries; i++)
      {
      if ((ret = sl_config_get_nth(i, sloc_hostname, &sloc_port, (char *)NULL)) == SL_OK)
         {
         ret = sloc_sr_code(SL_SEND_DELETE, aentry, FALSE);
         log_file_date("%s[%s,%d]rc=%d", mname, sloc_hostname,
                       sloc_port, ret);
         }
      }

   /* put back current entry */

   strcpy(sloc_hostname, thost);
   sloc_port = tport;
   free(aentry);
   log_file_date("%s:normal exit", mname);
   return(SL_OK);
}

int sloc_bcast_config_add(char *hname, int port, char *ip_ad)
{
   /* Send a config add command to each known 'socloc' server.
      This function should only be used by a 'socloc' server.
      Note that it is not considered an error if a 'socloc'
      server does not respond or responds with an error.
      Function returns a 'socloc' code. */

   char mname[] = "sloc_bcast_config_add";
   char thost[128], *aentry;
   int tport, nentries, i, ret;

   log_file_date("%s:enter", mname);

   if (hname == (char *)NULL || !strlen(hname))
      {
      log_file_date("%s:invalid parameter[hname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (port <= 0)
      {
      log_file_date("%s:invalid parameter[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* save current server host name and port */

   strcpy(thost, sloc_hostname);
   tport = sloc_port;

   if ((ret = sl_config_get_nentries(&nentries)) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sl_config_get_nentries'",
                    mname, ret);
      return(ret);
      }

   log_file_date("%s:number of config entries is %d", mname, nentries);

   if ((aentry = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[aentry]", mname);
      return(SL_MEMORY_FAIL);
      }

   /* indicate a server send with the initial 'orig_flag' set to zero */

   if (ip_ad != (char *)NULL && strlen(ip_ad))
      sprintf(aentry, "0 '%s' %d %s", hname, port, ip_ad);
   else
      sprintf(aentry, "0 '%s' %d", hname, port);

   /* go through list of servers, sending a config add command to each */

   for(i = 1; i <= nentries; i++)
      {
      if ((ret = sl_config_get_nth(i, sloc_hostname, &sloc_port, (char *)NULL)) == SL_OK)
         {
         ret = sloc_sr_code(SL_SEND_CONFIG_ADD, aentry, FALSE);
         log_file_date("%s[%s,%d]rc=%d", mname, sloc_hostname,
                       sloc_port, ret);
         }
      }

   /* put back current entry */

   strcpy(sloc_hostname, thost);
   sloc_port = tport;
   free(aentry);
   log_file_date("%s:normal exit", mname);
   return(SL_OK);
}

int sloc_bcast_config_delete(int port)
{
   /* Send a config delete command to each known 'socloc' server.
      This function should only be used by a 'socloc' server.
      Note that it is not considered an error if a 'socloc'
      server does not respond or responds with an error.
      Function returns a 'socloc' code. */

   char mname[] = "sloc_bcast_config_delete";
   char thost[128], *aentry;
   int tport, nentries, i, ret;

   log_file_date("%s:enter", mname);

   if (port <= 0)
      {
      log_file_date("%s:invalid parameter[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   /* save current server host name and port */

   strcpy(thost, sloc_hostname);
   tport = sloc_port;

   if ((ret = sl_config_get_nentries(&nentries)) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sl_config_get_nentries'",
                    mname, ret);
      return(ret);
      }

   log_file_date("%s:number of config entries is %d", mname, nentries);

   if ((aentry = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[aentry]", mname);
      return(SL_MEMORY_FAIL);
      }

   sprintf(aentry, "0 %d", port);

   /* go through list of servers, sending a config add command to each */

   for(i = 1; i <= nentries; i++)
      {
      if ((ret = sl_config_get_nth(i, sloc_hostname, &sloc_port, (char *)NULL)) == SL_OK)
         {
         ret = sloc_sr_code(SL_SEND_CONFIG_DELETE, aentry, FALSE);
         log_file_date("%s[%s,%d]rc=%d", mname, sloc_hostname,
                       sloc_port, ret);
         }
      }

   /* put back current entry */

   strcpy(sloc_hostname, thost);
   sloc_port = tport;
   free(aentry);
   log_file_date("%s:normal exit", mname);
   return(SL_OK);
}

int sloc_dump_debug(void)
{
   /* Command server to display and log debug information.
      Function returns 'SL_OK' upon success, an error code
      otherwise. */

   char mname[] = "sloc_dump_debug";
   int ret;

   log_file_date("%s:enter,host=%s,port=%d", mname, sloc_hostname,
                 sloc_port);
   ret = sloc_sr_code(SL_SEND_DUMP_DEBUG, (char *)NULL, TRUE);
   log_file_date("%s:normal exit,rc=%d", mname, ret);
   return(ret);
}

int sloc_config_dump_debug(void)
{
   /* Command server to display and log config debug information.
      Function returns 'SL_OK' upon success, an error code
      otherwise. */

   char mname[] = "sloc_config_dump_debug";
   int ret;

   log_file_date("%s:enter,host=%s,port=%d", mname, sloc_hostname,
                 sloc_port);
   ret = sloc_sr_code(SL_SEND_CONFIG_DUMP_DEBUG, (char *)NULL, TRUE);
   log_file_date("%s:normal exit,rc=%d", mname, ret);
   return(ret);
}

int sloc_terminate(char *passwd)
{
   /* Terminate a 'socloc' server. Function returns 'SL_OK'
      upon success, a 'socloc' code otherwise. */

   char mname[] = "sloc_terminate";
   int ret;

   log_file_date("%s:enter", mname);

   if (passwd == (char *)NULL || !strlen(passwd))
      {
      log_file_date("%s:invalid parameter[passwd]", mname);
      return(SL_INVALID_PARAMETER);
      }

   ret = sloc_sr_code(SL_SEND_TERM, passwd, TRUE);
   log_file_date("%s:normal exit,rc=%d", mname, ret);
   return(ret);
}

void sloc_get_active_socloc(char *hname, int *port)
{
   /* Get and return the active 'socloc' server host name
      and port number. 'hname' must be allocated by the
      caller to sufficient size. */

   if (hname == (char *)NULL || port == (int *)NULL)
      return;

   hname[0] = EOS;
   *port = 0;

   if (!strlen(sloc_hostname) || sloc_port == 0)
      return;

   strcpy(hname, sloc_hostname);
   *port = sloc_port;
}

int sloc_set_active_socloc(char *hname, int port)
{
   /* Set the current active 'socloc' server. Connection is
      tested and service name is verified. Function returns
      a 'socloc' code. */

   char mname[] = "sloc_set_active_socloc";
   int ret;

   log_file_date("%s:enter", mname);

   if (hname == (char *)NULL || !strlen(hname))
      {
      log_file_date("%s:null or empty[hname]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if (port <= 0)
      {
      log_file_date("%s:out of range[port]", mname);
      return(SL_INVALID_PARAMETER);
      }

   if ((ret = sloc_connect(hname, port)) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sloc_connect'", mname, ret);
      return(ret);
      }

   /* replace global host name and port */

   strcpy(sloc_hostname, hname);
   sloc_port = port;
   log_file_date("%s:normal exit,rc[0]", mname);
   return(SL_OK);
}

int sloc_find_first_active(void)
{
   /* Traverse through the list of socket locate servers and
      find the first one active. The active server host name
      and port number will be loaded into the globals
      'sloc_hostname' and 'sloc_port' upon success. Any entry
      in the list not found to be active will be deleted. Function
      returns 'SL_OK' upon success, a socket locate code
      otherwise. */

   char mname[] = "sloc_find_first_active";
   int nentries;
   int ret;

   log_file_date("%s:enter", mname);

   while(1)
      {
      if ((ret = sl_config_get_nentries(&nentries)) != SL_OK)
         {
         log_file_date("%s:bad rc from 'sl_config_get_nentries',rc=%d",
                       mname, ret);
         return(ret);
         }

      log_file_date("%s:number of config entries is %d", mname, nentries);

      /* load host name and port number for this entry */

      if ((ret = sl_config_get_first(sloc_hostname, &sloc_port,
                                   (char *)NULL)) != SL_OK)
         {
         log_file_date("%s:bad rc from 'sl_config_get_first,rc=%d",
                       mname, ret);
         return(ret);
         }

      log_file_date("%s:config entry:sloc_hostname=%s,sloc_port=%d",
                    mname, sloc_hostname, sloc_port);

      /* get status of server */

      if ((ret = sloc_ll_status()) == SL_OK)
         {
         log_file_date("%s:exit:server '%s' responding", mname, sloc_hostname);
         return(ret);
         }

      log_file_date("%s:server '%s' not responding", mname, sloc_hostname);

      /* if not responding delete entry */

      if ((ret = sl_config_delete(sloc_port)) != SL_OK)
         {
         log_file_date("%s:bad rc from 'sl_config_delete,rc=%d",
                       mname, ret);
         return(ret);
         }
      }

   /* we should never get here but just in case */

   sloc_hostname[0] = EOS;
   sloc_port = 0;
   log_file_date("%s:unanticipated wacky exit,rc=%d", mname,
                 SL_NO_SUCH_SOCLOC);
   return(SL_NO_SUCH_SOCLOC);
}

int sloc_is_init(void)
{
   /* Determine whether the 'socloc' API has been initialized.
      The API is considered initialized when there is an active
      host name in 'sloc_hostname' and a positive port number in
      'sloc_port'. Function returns 'SL_OK' if the API has been
      initialized, 'SL_NO_INIT' otherwise. */

   char mname[] = "sloc_is_init";
   int ret;

   log_file_date("%s:enter", mname);

   if (!sloc_port || sloc_hostname == (char *)NULL || !strlen(sloc_hostname))
      ret = SL_NO_INIT;
   else
      ret = SL_OK;

   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

/* private functions */

static int sloc_ll_status(void)
{
   /* Low level 'status' function. This function operates similiar
      to the 'sloc_status' function except that only the currently
      loaded 'socloc' server is queried. Function returns
      'SL_OK' upon success, a 'socloc' code otherwise. */

   char mname[] = "sloc_ll_status";
   int ret;

   log_file_date("%s:enter:host=%s,port=%d", mname, sloc_hostname,
                 sloc_port);
   ret = sloc_sr_code(SL_SEND_STATUS, (char *)NULL, FALSE);
   log_file_date("%s:normal exit,rc[%d]", mname, ret);
   return(ret);
}

static int sloc_sr_int(int typ, char *parm, int *intvalue, int autoflag)
{
   /* Send and receive a message to the 'socloc' server that returns
      an int in addition to the return code. It's ok if 'parm' is NULL
      or empty. 'autoflag' indicates whether a 'socloc' server should
      be located automatically. Function returns a 'socloc' code. */

   char *mess, tmp[50];
   int len, full_len, nwords, ret;

   /* if port is zero, init has not been called, exit error */

   if (!sloc_port || sloc_hostname == (char *)NULL || !strlen(sloc_hostname))
      return(SL_NO_INIT);

   *intvalue = 0;

   /* connect to server based on 'autoflag' */

   if (autoflag)
      ret = sloc_client_connect();
   else
      ret = sloc_ll_client_connect();

   if (ret != SL_OK)
      return(ret);

   // estimate length and alloc send/receive buffer

   len = (parm == (char *)NULL) ? 0 : strlen(parm);
   full_len = len + 5;

   if ((mess = (char *)malloc(full_len)) == (char *)NULL)
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      return(SL_MEMORY_FAIL);
      }

   memset(mess, 0, full_len);

   // format send string

   if (parm == (char *)NULL || !len)
      sprintf(mess, "%d", typ);
   else
      sprintf(mess, "%d %s", typ, parm);

   // send message

   if (!ipc_send(slclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_VC_ERROR);
      }

   free(mess);

   // re-allocate 'mess' for receive buffer (max size)

   if ((mess = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      return(SL_MEMORY_FAIL);
      }

   memset(mess, 0, SL_MAXCOMMAND);

   // receive reply

   if (!ipc_recv(slclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_VC_ERROR);
      }

   // s/b two words in reply

   nwords = words(mess);

   // s/b reply code in word one

   if (!word(mess, tmp, 1))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_INTERNAL_ERROR);
      }

   // make sure its a number

   if (!qatoi(tmp, &ret))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_INTERNAL_ERROR);
      }

   if (ret == SL_OK)
      {
      if (nwords < 2)
         {
#ifdef OS_WIN32
         (void)closesocket(slclientSocket);
#else
         close(slclientSocket);
#endif

         free(mess);
         return(SL_INTERNAL_ERROR);
         }

      // value is in second word

      if (!word(mess, tmp, 2))
         {
#ifdef OS_WIN32
         (void)closesocket(slclientSocket);
#else
         close(slclientSocket);
#endif

         free(mess);
         return(SL_INTERNAL_ERROR);
         }

      if (!qatoi(tmp, intvalue))
         {
#ifdef OS_WIN32
         (void)closesocket(slclientSocket);
#else
         close(slclientSocket);
#endif

         free(mess);
         return(SL_INTERNAL_ERROR);
         }
      }

#ifdef OS_WIN32
   (void)closesocket(slclientSocket);
#else
   close(slclientSocket);
#endif

   free(mess);

   /* check for 'socloc' failover */

   if (has_failover)
      (void)sloc_failover();

   return(ret);
}

static int sloc_sr_long(int typ, char *parm, long *longvalue,
                        int autoflag)
{
   /* Send and recveive a message to the 'socloc' server that returns
      a long in addition to the return code. Its ok if 'parm' is NULL
      or empty. 'autoflag' indicates whether a 'socloc' server should
      be located automatically. Function returns a 'socloc' code. */

   char *mess, tmp[50];
   int len, full_len, nwords, ret;

   /* if port is zero, init has not been called, exit error */

   if (!sloc_port || sloc_hostname == (char *)NULL || !strlen(sloc_hostname))
      return(SL_NO_INIT);

   *longvalue = 0L;

   /* connect to server based on 'autoflag' */

   if (autoflag)
      ret = sloc_client_connect();
   else
      ret = sloc_ll_client_connect();

   if (ret != SL_OK)
      return(ret);

   // estimate length and alloc send/receive buffer

   len = (parm == (char *)NULL) ? 0 : strlen(parm);
   full_len = len + 5;

   if ((mess = (char *)malloc(full_len)) == (char *)NULL)
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      return(SL_MEMORY_FAIL);
      }

   memset(mess, 0, full_len);

   // format send string

   if (parm == (char *)NULL || !len)
      sprintf(mess, "%d", typ);
   else
      sprintf(mess, "%d %s", typ, parm);

   // send message

   if (!ipc_send(slclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_VC_ERROR);
      }

   free(mess);

   // re-allocate 'mess' for receive buffer (max size)

   if ((mess = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      return(SL_MEMORY_FAIL);
      }

   memset(mess, 0, SL_MAXCOMMAND);

   // receive reply

   if (!ipc_recv(slclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_VC_ERROR);
      }

   // s/b two words in reply

   nwords = words(mess);

   // s/b reply code in word one

   if (!word(mess, tmp, 1))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_INTERNAL_ERROR);
      }

   // make sure its a number

   if (!qatoi(tmp, &ret))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_INTERNAL_ERROR);
      }

   if (ret == SL_OK)
      {
      if (nwords < 2)
         {
#ifdef OS_WIN32
         (void)closesocket(slclientSocket);
#else
         close(slclientSocket);
#endif

         free(mess);
         return(SL_INTERNAL_ERROR);
         }

      // value is in second word

      if (!word(mess, tmp, 2))
         {
#ifdef OS_WIN32
         (void)closesocket(slclientSocket);
#else
         close(slclientSocket);
#endif

         free(mess);
         return(SL_INTERNAL_ERROR);
         }

      if (!qatol(tmp, longvalue))
         {
#ifdef OS_WIN32
         (void)closesocket(slclientSocket);
#else
         close(slclientSocket);
#endif

         free(mess);
         return(SL_INTERNAL_ERROR);
         }
      }

#ifdef OS_WIN32
   (void)closesocket(slclientSocket);
#else
   close(slclientSocket);
#endif

   free(mess);

   /* check for 'socloc' failover */

   if (has_failover)
      (void)sloc_failover();

   return(ret);
}

static int sloc_sr_code(int typ, char *parm, int autoflag)
{
   /* Send and recveive a message to the 'socloc' server that returns
      only a return code. Its ok if 'parm' is NULL or empty.
      'autoflag' indicates whether a 'socloc' server should
      be located automatically. Function returns a 'socloc' code. */

   char *mess;
   int len, full_len, ret;

   /* if port is zero, init has not been called, exit error */

   if (!sloc_port || sloc_hostname == (char *)NULL || !strlen(sloc_hostname))
      return(SL_NO_INIT);

   /* connect to server based on 'autoflag' */

   if (autoflag)
      ret = sloc_client_connect();
   else
      ret = sloc_ll_client_connect();

   if (ret != SL_OK)
      return(ret);

   // estimate length and alloc send/receive buffer

   len = (parm == (char *)NULL) ? 0 : strlen(parm);
   full_len = len + 5;

   if ((mess = (char *)malloc(full_len)) == (char *)NULL)
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      return(SL_MEMORY_FAIL);
      }

   memset(mess, 0, full_len);

   // format send string

   if (parm == (char *)NULL || !len)
      sprintf(mess, "%d", typ);
   else
      sprintf(mess, "%d %s", typ, parm);

   // send message

   if (!ipc_send(slclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_VC_ERROR);
      }

   memset(mess, 0, full_len);

   // receive return code

   if (!ipc_recv(slclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_VC_ERROR);
      }

   // make sure its a number

   if (!qatoi(mess, &ret))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_INTERNAL_ERROR);
      }

#ifdef OS_WIN32
   (void)closesocket(slclientSocket);
#else
   close(slclientSocket);
#endif

   free(mess);

   /* check for 'socloc' failover */

   if (has_failover)
      (void)sloc_failover();

   return(ret);
}

static int sloc_sr_char(int typ, char *parm, char *char_out,
                        int autoflag)
{
   /* Send and recveive a message to the 'socloc' server that returns a
      string as well as a return code. 'char_out' must already
      be allocated to sufficient size for the receiving string.
      Its ok if 'parm' is NULL or empty. 'autoflag' indicates
      whether a 'socloc' server should be located automatically.
      Function returns a 'socloc' code. */

   char *mess, tmp[50];
   int len, full_len, nwords, pos, ret;

   /* if port is zero, init has not been called, exit error */

   if (!sloc_port || sloc_hostname == (char *)NULL || !strlen(sloc_hostname))
      return(SL_NO_INIT);

   char_out[0] = EOS;

   /* connect to server based on 'autoflag' */

   if (autoflag)
      ret = sloc_client_connect();
   else
      ret = sloc_ll_client_connect();

   if (ret != SL_OK)
      return(ret);

   // estimate length and alloc send/receive buffer

   len = (parm == (char *)NULL) ? 0 : strlen(parm);
   full_len = len + 5;

   if ((mess = (char *)malloc(full_len)) == (char *)NULL)
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      return(SL_MEMORY_FAIL);
      }

   memset(mess, 0, full_len);

   // format send string

   if (parm == (char *)NULL || !len)
      sprintf(mess, "%d", typ);
   else
      sprintf(mess, "%d %s", typ, parm);

   // send message

   if (!ipc_send(slclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_VC_ERROR);
      }

   free(mess);

   // re-allocate 'mess' for receive buffer (max size)

   if ((mess = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      return(SL_MEMORY_FAIL);
      }

   memset(mess, 0, SL_MAXCOMMAND);

   // receive reply

   if (!ipc_recv(slclientSocket, mess))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_VC_ERROR);
      }

   // s/b two words in reply

   nwords = command_words(mess);

   // s/b reply code in word one

   if (!command_word(mess, tmp, 1))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_INTERNAL_ERROR);
      }

   // make sure its a number

   if (!qatoi(tmp, &ret))
      {
#ifdef OS_WIN32
      (void)closesocket(slclientSocket);
#else
      close(slclientSocket);
#endif

      free(mess);
      return(SL_INTERNAL_ERROR);
      }

   // if reply is 'ok', load 'char_out'

   if (ret == SL_OK)
      {
      if (nwords < 2)
         {
#ifdef OS_WIN32
         (void)closesocket(slclientSocket);
#else
         close(slclientSocket);
#endif

         free(mess);
         return(SL_INTERNAL_ERROR);
         }

      // 'char_value' is from the end of the first word

      if ((pos = command_indxword(mess, 2)) == -1)
         {
#ifdef OS_WIN32
         (void)closesocket(slclientSocket);
#else
         close(slclientSocket);
#endif

         free(mess);
         return(SL_INTERNAL_ERROR);
         }

      /* if second command word starts with quote backup one */

      if (mess[pos - 1] == '\'' || mess[pos - 1] == '"')
         pos -= 1;

      len = strlen(mess) - pos;
      strncpy(char_out, &mess[pos], len);
      char_out[len] = EOS;
      }

#ifdef OS_WIN32
   (void)closesocket(slclientSocket);
#else
   close(slclientSocket);
#endif

   free(mess);

   /* check for 'socloc' failover */

   if (has_failover)
      (void)sloc_failover();

   return(ret);
}

static int sloc_failover(void)
{
   /* Send a config delete command to the active
      'socloc' server for each dead port found.
      Also, update the client config list. */

   char mname[] = "sloc_failover";
   char *thelist;
   int i, ret, tspos;

   log_file_date("%s:enter,spos=%d", mname, spos);
   tspos = spos;

   for(i = 0; i < tspos; i++)
      (void)sloc_config_delete(staleport[i]);

   if ((thelist = (char *)malloc(SL_MAXCOMMAND)) == (char *)NULL)
      {
      log_file_date("%s:alloc fail[thelist]", mname);
      return(SL_MEMORY_FAIL);
      }

   /* get the config list from the first active server */

   if ((ret = sloc_config_get_list(thelist)) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sloc_config_get_list'",
                    mname, ret);
      free(thelist);
      return(ret);
      }

   /* create a new list in memory */

   if ((ret = sl_config_put_list(thelist)) != SL_OK)
      {
      log_file_date("%s:bad rc[%d] from 'sl_config_put_list'",
                    mname, ret);
      free(thelist);
      return(ret);
      }

   free(thelist);
   has_failover = FALSE;
   spos = 0;
   return(SL_OK);
}

static int sloc_client_connect(void)
{
   /* Attempt to connect to a 'socloc' server. The host name
      and port number should have already been initialized by
      calling 'sloc_initialize'. If the initialization routine
      has not been called, it is an error. If the current 'socloc'
      server has been found to be not responding, another
      'socloc' server will attempt to be found. Function
      returns 'SL_OK' if a connection was made to any
      'socloc' server, a 'socloc' code otherwise. */

   char mname[] = "sloc_client_connect";
   int ret;

   log_file_date("%s:enter,sloc_hostname=%s,sloc_port=%d", mname,
                 sloc_hostname, sloc_port);
   spos = 0;
   has_failover = FALSE;

   /* if port is zero, init has not been called, exit error */

   if (!sloc_port)
      {
      log_file_date("%s:no host or port,exit rc[%d]", mname,
                    SL_NO_INIT);
      return(SL_NO_INIT);
      }

   /* loop which attempts to connect to currently listed
      'socloc' server, if this fails, get next active and
      try */

   while(1)
      {
      if ((ret = sloc_ll_client_connect()) == SL_OK)
         {
         log_file_date("%s:exit,connected to server '%s'", mname,
                       sloc_hostname);
         return(ret);
         }

      log_file_date("%s:server '%s' not responding,rc=%d", mname,
                    sloc_hostname, ret);

      /* indicate a failover and store port number of
         non-responding server */

      has_failover = TRUE;

      if (spos >= splimit)
         {
         log_file_date("%s:exceeded max of dead 'socloc' ports", mname);
         return(SL_INTERNAL_ERROR);
         }

      staleport[spos++] = sloc_port;

      /* delete the current entry and get new top of list */

      if ((ret = sl_config_delete(sloc_port)) != SL_OK)
         {
         log_file_date("%s:bad rc from 'sl_config_delete',rc=%d",
                       mname, ret);
         return(ret);
         }

      /* wipe out current host name and port */

      sloc_hostname[0] = EOS;
      sloc_port = 0;

      if ((ret = sl_config_get_first(sloc_hostname, &sloc_port,
           (char *)NULL)) != SL_OK)
         {
         log_file_date("%s:bad rc from 'sl_config_get_first',rc=%d",
                       mname, ret);
         return(ret);
         }
      }

   /* we should never get here, but just in case */

   log_file_date("%s:unanticipated wacky exit 'SL_NO_SUCH_SOCLOC'", mname);
   return(SL_NO_SUCH_SOCLOC);
}

static int sloc_ll_client_connect(void)
{
   /* Connect to the 'socloc' server. An attempt to open the TCP
      socket is made. The host name 'sloc_hostname' and the
      TCP port 'sloc_port' are assumed to be already loaded
      via 'sloc_initialize'. Function returns 'SL_OK' if a
      successful connection was made, a 'socloc' code otherwise.
      Private function. */

   // make sure host name and port are loaded

   if (!sloc_port || !strlen(sloc_hostname))
      return(SL_NO_INIT);

   // resolve server host name

   lpHostEnt = gethostbyname(sloc_hostname);

   if (!lpHostEnt)
      return(SL_VC_ERROR);

   // create the socket

#ifdef OS_WIN32
   slclientSocket = socket(PF_INET, SOCK_STREAM, DEFAULT_PROTOCOL);
#endif

#ifdef OS_UNIX
   slclientSocket = socket(AF_INET, SOCK_STREAM, DEFAULT_PROTOCOL);
#endif

   if (slclientSocket == INVALID_SOCKET)
      return(SL_VC_ERROR);

   // load client address data

   memset(&sockClientAddr, 0, sizeof(sockClientAddr));
   sockClientAddr.sin_family = AF_INET;
   sockClientAddr.sin_port = htons(sloc_port);

#ifdef OS_WIN32
   sockClientAddr.sin_addr = *((LPIN_ADDR)*lpHostEnt->h_addr_list);
#endif

#ifdef OS_UNIX
   sockClientAddr.sin_addr.s_addr = ((struct in_addr *)(lpHostEnt->h_addr))->s_addr;
#endif

   // connect to server

#ifdef OS_WIN32
   if (connect(slclientSocket, (LPSOCKADDR)&sockClientAddr, sizeof(sockClientAddr)))
#endif

#ifdef OS_UNIX
   if (connect(slclientSocket, &sockClientAddr, sizeof(sockClientAddr)) == SOCKET_ERROR)
#endif

      return(SL_VC_ERROR);

   return(SL_OK);
}
