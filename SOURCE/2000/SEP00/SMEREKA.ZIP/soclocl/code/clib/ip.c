/* TCP/IP utility library.
   Rick Smereka, Copyright (C) 2000.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, get a copy via the Internet at
   http://gnu.org/copyleft/gpl.html or write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307 USA

   You can contact the author via email at rsmereka@future-lab.com.

   Original CodeWarrior V4 Windows 32-bit version Jul/2000,
   Rick Smereka */

#include "stdhead.h"
#include "flsocket.h"
#include "ip.h"
   
#ifdef OS_WIN32
LPHOSTENT ipHostEnt;					// host info structure
#else
struct hostent *ipHostEnt;
#endif

int ip_host2ip(char *hostname, char *ipaddr)
{
   /* Resolve a host name to an IP address. Upon
      success, the IP address is returned in
      'ipaddr' which must be allocated by the
      caller to sufficient size. Function returns
      'TRUE' upon success, 'FALSE' otherwise. */

#ifdef OS_WIN32
   LPSTR ipstr;
#else
   struct in_addr ipbin;
   char *ipstr;
#endif

   if (hostname == (char *)NULL || !strlen(hostname))
      return(FALSE);
      
   if (ipaddr == (char *)NULL)
      return(FALSE);
      
   ipaddr[0] = EOS;
   
   // get host details based on name

   ipHostEnt = gethostbyname(hostname);

   if (!ipHostEnt)      
      return(FALSE);      

   // take the binary IP address and convert it to a dotted string

#ifdef OS_WIN32
   ipstr = inet_ntoa(*(LPIN_ADDR)*(ipHostEnt->h_addr_list));
#else
   ipbin.s_addr = ((struct in_addr *)(ipHostEnt->h_addr))->s_addr;
   ipstr = inet_ntoa(ipbin);
#endif

   strcpy(ipaddr, ipstr);
   return(TRUE);
}      

int ip_ip2host(char *ipstr, char *hostname)
{
   /* Resolve an IP address to a host name. Upon success,
      the resolved host name will be loaded into
      'hostname' which must already be allocated to
      sufficient size by the caller. Function returns
      'TRUE' upon success, 'FALSE' otherwise. */

#ifdef OS_WIN32
   DWORD ipbin;
#else
   struct in_addr ipbin;
#endif

   if (ipstr == (char *)NULL || !strlen(ipstr))
      return(FALSE);
      
   if (hostname == (char *)NULL)
      return(FALSE);
      
   hostname[0] = EOS;

   // convert IP address to a binary number   

#ifdef OS_WIN32
   ipbin = inet_addr((LPSTR)ipstr);

   if (ipbin == INADDR_NONE)
#else
   ipbin.s_addr = inet_addr(ipstr);

   if (ipbin.s_addr == INADDR_NONE)
#endif      
      return(FALSE);      

   // get host name by 32-bit IP address
   
#ifdef OS_WIN32
   ipHostEnt = gethostbyaddr((LPSTR)&ipbin, 4, AF_INET);
#else
   ipHostEnt = gethostbyaddr((char *)&ipbin, 4, AF_INET);
#endif

   if (!ipHostEnt)   
      return(FALSE);      

   strcpy(hostname, ipHostEnt->h_name);
   return(TRUE);
}

int isip(char *str)
{
   /* Determine whether the string is an IP address. We assume
      a valid IP address if the string has four period delimited
      words of integers between zero and 255. Function returns
     'TRUE' if the string is a valid IP address, 'FALSE' otherwise. */

   char aword[1024];
   int nwords, i, anum;

   nwords = ll_words(str, '.');

   if (nwords != 4)
      return(FALSE);

   for(i = 1; i <= 4; i++)
      {
      if (!ll_word(str, aword, i, '.'))
         return(FALSE);

      if (!qatoi(aword, &anum))
         return(FALSE);

      if (anum < 0 || anum > 255)
         return(FALSE);
      }

    return(TRUE);
}
