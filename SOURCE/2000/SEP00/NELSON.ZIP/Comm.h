//comm.h for C/C++ Users Journal by Erik L. Nelson
//this code may be used freely with no restrictions on use

#ifndef COMMUNICATE_HEADER
#define COMMUNICATE_HEADER


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef _WIN32
   #include <sys/types.h>
   #include <sys/socket.h>
   #include <netinet/in.h>
   #include <unistd.h>
   #include <netdb.h>
   #include <arpa/inet.h>
   #define SOCKET   int
   #define INVALID_SOCKET -1
   #define closesocket close
   #include <pthread.h>
#else
   #include <winsock.h>
   #define socklen_t int
   // try to tell linker where WinSock library is
   #if defined(_MSC_VER)
      #pragma comment(lib,"wsock32.lib")
   #elif defined(__BORLANDC__)
      #pragma(lib,"mswsock.lib")
   #endif
#endif

class CComm{
public:
   CComm();
  ~CComm();
   bool SendMsg(char *Msg, int Len, char *host, short port);
   bool Listen(int PortNum);
private:
   static void *ListenThread(void *data);
   SOCKET ListenSocket;  // the socket that we're listening for connections on
   sockaddr_in srv;  // the address that the server is listening on
   sockaddr_in client;  // the address that the last message was received from
};

#endif








