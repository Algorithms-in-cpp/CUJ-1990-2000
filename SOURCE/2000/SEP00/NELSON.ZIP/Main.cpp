//developed for C/C++ Users Journal by Erik L. Nelson
//this code may be used freely with no restrictions on use

// Linux: cc *.cpp -o udp -lpthread
// Win32: cl *.cpp -o udp.exe  (for Microsoft compiler)

#include "comm.h"
#include <stdio.h>

int main(int argc, char *argv[]){
   char buf[4096];
   short listeningport;
   short destport;
   char *desthost;
   if(argc != 4 || !(listeningport=atoi(argv[1])) || !(destport=atoi(argv[3]))){
      printf("Usage: udp [listen port number] [destination machine] [destination port]\n");
      return 0;
      }
   desthost=argv[2];
   CComm Comm;
   if(! Comm.Listen(listeningport)){
      printf("Error listening to UDP port\n");
      return 0;
      }
   while(fgets(buf,sizeof(buf),stdin)){
      Comm.SendMsg(buf, strlen(buf),desthost,destport);
      }  // end of while loop
   return 0;
}






