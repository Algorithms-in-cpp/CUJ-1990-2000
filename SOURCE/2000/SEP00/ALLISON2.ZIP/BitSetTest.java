import java.util.*;

class BitSetTest
{
    static void printBits(BitSet b)
    {
        System.out.println(
            "size: " + b.size() +
            ", length: " + b.length() +
            ", bits: " + b);
    }
    public static void main (String[] args)
    {
        BitSet b1 = new BitSet();
        printBits(b1);
        b1.set(1);
        printBits(b1);
        b1.set(3);
        printBits(b1);
        b1.set(5);
        printBits(b1);

        BitSet b2 = new BitSet();
        printBits(b2);
        for (int i = 0; i < 4; ++i)
            b2.set(i);
        printBits(b2);
        b1.and(b2);
        printBits(b1);
    }
}

/* Output:
size: 64, length: 0, bits: {}
size: 64, length: 2, bits: {1}
size: 64, length: 4, bits: {1, 3}
size: 64, length: 6, bits: {1, 3, 5}
size: 64, length: 0, bits: {}
size: 64, length: 4, bits: {0, 1, 2, 3}
size: 64, length: 4, bits: {1, 3}
*/

