import java.util.*;

class VectorTest2
{
    static void printVector(Vector v)
    {
        System.out.println("Vector = {");
        Enumeration e = v.elements();
        for (int idx = 0; e.hasMoreElements(); ++idx)
            System.out.println("\t" + idx + ": "
                             + e.nextElement());
        System.out.println("}");
    }
    static void search(Vector v, Object o)
    {
        System.out.print(o);
        if (!v.contains(o))
            System.out.print(" not");
        System.out.println(" found");
    }
    public static void main(String[] args)
    {
        // Build Vector:
        Vector v = new Vector();
        v.addElement(new Integer(88));
        v.addElement(new Integer(17));
        v.addElement(new Integer(-10));
        v.addElement(new Integer(34));
        v.addElement(new Integer(27));
        v.addElement(new Integer(0));
        v.addElement(new Integer(-2));
        printVector(v);

        // Search:
        search(v, new Integer(0));
        search(v, new Integer(1));
    }
}

/* Output:
Vector = {
        0: 88
        1: 17
        2: -10
        3: 34
        4: 27
        5: 0
        6: -2
}
0 found
1 not found
*/

