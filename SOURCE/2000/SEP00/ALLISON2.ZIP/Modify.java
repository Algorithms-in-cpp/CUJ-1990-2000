import java.util.*;

class Modify
{
    public static void main(String[] args)
    {
        // Build Array:
        ArrayList a = new ArrayList();
        a.add(new Integer(1));
        a.add(new Integer(2));
        a.add(new Integer(3));
        System.out.println(a);

        // Modify via iterator:
        ListIterator p =
            (ListIterator) a.listIterator();
        while (p.hasNext())
        {
            Integer i = (Integer) p.next();
            p.set(new Integer(i.intValue()
                              + 1));
        }
        System.out.println(a);
    }
}

/* Output:
[1, 2, 3]
[2, 3, 4]
*/

