import java.util.*;

class VectorTest
{
    static void search(Vector v, Object o)
    {
        int idx = v.indexOf(o);
        System.out.print(o + " ");
        if (idx < 0)
            System.out.println("not found");
        else
            System.out.println("found in position " + idx);
    }
    public static void main(String[] args)
    {
        // Build Vector:
        Vector v = new Vector();
        v.addElement(new Integer(88));
        v.addElement(new Integer(17));
        v.addElement(new Integer(-10));
        v.addElement(new Integer(34));
        v.addElement(new Integer(27));
        v.addElement(new Integer(0));
        v.addElement(new Integer(-2));
        System.out.println(v);

        // Search:
        search(v, new Integer(0));
        search(v, new Integer(1));
    }
}

/* Output:
[88, 17, -10, 34, 27, 0, -2]
0 found in position 5
1 not found
*/

