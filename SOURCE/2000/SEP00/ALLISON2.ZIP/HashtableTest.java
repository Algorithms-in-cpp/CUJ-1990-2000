import java.util.*;
class HashtableTest
{
    public static void main(String[] args)
    {
        Hashtable h = new Hashtable();
        h.put("Alabama", "Montgomery");
        h.put("Tennesee", "Nashville");
        h.put("Georgia", "Savannah");
        // The following value replaces "Savannah":
        h.put("Georgia", "Atlanta");
        System.out.println(h);
        test(h);
        iterate(h);
    }

    static void test(Hashtable h)
    {
        if (h.containsKey("Alabama"))
            System.out.println("Alabama is a key");
        if (h.contains("Montgomery"))
            System.out.println("Montgomery is a value");
        System.out.println("m[Georgia] = " +
                           h.get("Georgia"));
        System.out.println("m[Michigan] = " +
                           h.get("Michigan"));
    }

    static void iterate(Hashtable h)
    {
        Enumeration e = h.keys();
        System.out.println("Keys:");
        while (e.hasMoreElements())
        {
            System.out.print("\t");
            System.out.println(e.nextElement());
        }

        System.out.println("Values:");
        e = h.elements();
        while (e.hasMoreElements())
        {
            System.out.print("\t");
            System.out.println(e.nextElement());
        }
    }
}

/* Output:
{Tennesee=Nashville, Georgia=Atlanta, Alabama=Montgomery}
Alabama is a key
Montgomery is a value
m[Georgia] = Atlanta
m[Michigan] = null
Keys:
        Tennesee
        Georgia
        Alabama
Values:
        Nashville
        Atlanta
        Montgomery
*/
