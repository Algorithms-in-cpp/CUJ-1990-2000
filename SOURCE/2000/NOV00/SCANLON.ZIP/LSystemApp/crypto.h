
unsigned short BinstockRexCRC(unsigned short crc,  short data);
unsigned short ComputeCRC(long data);
bool Encrypt(const char* data, const char* key, char *ret,  long size);
bool Decrypt(const char *data, const char *key, char *ret,  long size);

