// CryptoLicense.cpp : Implementation of CCryptoLicense
#include "stdafx.h"
#include "LSystemCOMServer.h"
#include "CryptoLicense.h"
#include "crypto.h"

/////////////////////////////////////////////////////////////////////////////
// CCryptoLicense

STDMETHODIMP CCryptoLicense::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ICryptoLicense
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CCryptoLicense::GrantLicense(BSTR cookie, BSTR *license)
{
	long lCookie = 0;
	char szLicense[64];
	ZeroMemory(szLicense,64);
	char szTmp[13];
	ZeroMemory(szTmp,13);
	unsigned short crc = 0;
	
	USES_CONVERSION;
	
	//Decrypt the cookie
	Decrypt(W2A(cookie),"UnbreakableKey",szLicense, 64);
	
	//Validate the cookie's crc
	sscanf(szLicense,"%08X%04X",&lCookie,&crc);
	if (!crc || ComputeCRC(lCookie) != crc)
	{
		char err[]="Error: Cookie invalid\n";
		Error(err);
		*license = T2BSTR("0");
		return E_FAIL;
	}
	
	//Compute the new license
	lCookie = lCookie + 30*86400;
	
	//Append a crc
	sprintf(szTmp,"%08X%04X",lCookie,ComputeCRC(lCookie));
	
	//Encrypt the new license
	ZeroMemory(szLicense,64);
	Encrypt(szTmp,"UnbreakableKey",szLicense, 64);
	*license = T2BSTR(szLicense);
	
	return S_OK;
}
