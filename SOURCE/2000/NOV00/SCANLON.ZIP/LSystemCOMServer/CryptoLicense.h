// CryptoLicense.h : Declaration of the CCryptoLicense

#ifndef __CRYPTOLICENSE_H_
#define __CRYPTOLICENSE_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCryptoLicense
class ATL_NO_VTABLE CCryptoLicense : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCryptoLicense, &CLSID_CryptoLicense>,
	public ISupportErrorInfo,
	public IDispatchImpl<ICryptoLicense, &IID_ICryptoLicense, &LIBID_LSYSTEMCOMSERVERLib>
{
public:
	CCryptoLicense()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CRYPTOLICENSE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCryptoLicense)
	COM_INTERFACE_ENTRY(ICryptoLicense)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ICryptoLicense
public:
	STDMETHOD(GrantLicense)(/*[in]*/ BSTR cookie, /*[out,retval]*/ BSTR *license);
};

#endif //__CRYPTOLICENSE_H_
