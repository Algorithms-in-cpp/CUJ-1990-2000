/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Sep 22 10:22:53 2000
 */
/* Compiler settings for C:\Mike\LicensingStuff\zip\LSystemCOMServer\LSystemCOMServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __LSystemCOMServer_h__
#define __LSystemCOMServer_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ICryptoLicense_FWD_DEFINED__
#define __ICryptoLicense_FWD_DEFINED__
typedef interface ICryptoLicense ICryptoLicense;
#endif 	/* __ICryptoLicense_FWD_DEFINED__ */


#ifndef __CryptoLicense_FWD_DEFINED__
#define __CryptoLicense_FWD_DEFINED__

#ifdef __cplusplus
typedef class CryptoLicense CryptoLicense;
#else
typedef struct CryptoLicense CryptoLicense;
#endif /* __cplusplus */

#endif 	/* __CryptoLicense_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ICryptoLicense_INTERFACE_DEFINED__
#define __ICryptoLicense_INTERFACE_DEFINED__

/* interface ICryptoLicense */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICryptoLicense;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6AB9188D-8A67-11D4-AD7F-00C04F41258E")
    ICryptoLicense : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GrantLicense( 
            /* [in] */ BSTR cookie,
            /* [retval][out] */ BSTR __RPC_FAR *license) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICryptoLicenseVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICryptoLicense __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICryptoLicense __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICryptoLicense __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICryptoLicense __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICryptoLicense __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICryptoLicense __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICryptoLicense __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GrantLicense )( 
            ICryptoLicense __RPC_FAR * This,
            /* [in] */ BSTR cookie,
            /* [retval][out] */ BSTR __RPC_FAR *license);
        
        END_INTERFACE
    } ICryptoLicenseVtbl;

    interface ICryptoLicense
    {
        CONST_VTBL struct ICryptoLicenseVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICryptoLicense_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICryptoLicense_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICryptoLicense_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICryptoLicense_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICryptoLicense_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICryptoLicense_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICryptoLicense_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICryptoLicense_GrantLicense(This,cookie,license)	\
    (This)->lpVtbl -> GrantLicense(This,cookie,license)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICryptoLicense_GrantLicense_Proxy( 
    ICryptoLicense __RPC_FAR * This,
    /* [in] */ BSTR cookie,
    /* [retval][out] */ BSTR __RPC_FAR *license);


void __RPC_STUB ICryptoLicense_GrantLicense_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICryptoLicense_INTERFACE_DEFINED__ */



#ifndef __LSYSTEMCOMSERVERLib_LIBRARY_DEFINED__
#define __LSYSTEMCOMSERVERLib_LIBRARY_DEFINED__

/* library LSYSTEMCOMSERVERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_LSYSTEMCOMSERVERLib;

EXTERN_C const CLSID CLSID_CryptoLicense;

#ifdef __cplusplus

class DECLSPEC_UUID("6AB9188E-8A67-11D4-AD7F-00C04F41258E")
CryptoLicense;
#endif
#endif /* __LSYSTEMCOMSERVERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
