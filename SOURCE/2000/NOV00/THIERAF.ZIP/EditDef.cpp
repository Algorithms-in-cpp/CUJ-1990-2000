// EditDef.cpp : implementation file
//

#include "stdafx.h"
#include "scandat.h"
#include "EditDef.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditDef dialog


CEditDef::CEditDef(CWnd* pParent /*=NULL*/)
	: CDialog(CEditDef::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditDef)
	x1v = 0.0;
	x1x = 0;
	x1y = 0;
	x2v = 0.0;
	x2x = 0;
	x2y = 0;
	y1x = 0;
	y1v = 0.0;
	y1y = 0;
	y2v = 0.0;
	y2x = 0;
	y2y = 0;
	//}}AFX_DATA_INIT
}


void CEditDef::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditDef)
	DDX_Text(pDX, IDC_EDIT_X1V, x1v);
	DDX_Text(pDX, IDC_EDIT_X1X, x1x);
	DDX_Text(pDX, IDC_EDIT_X1Y, x1y);
	DDX_Text(pDX, IDC_EDIT_X2V, x2v);
	DDX_Text(pDX, IDC_EDIT_X2X, x2x);
	DDX_Text(pDX, IDC_EDIT_X2Y, x2y);
	DDX_Text(pDX, IDC_EDIT_Y1X, y1x);
	DDX_Text(pDX, IDC_EDIT_Y1V, y1v);
	DDX_Text(pDX, IDC_EDIT_Y1Y, y1y);
	DDX_Text(pDX, IDC_EDIT_Y2V, y2v);
	DDX_Text(pDX, IDC_EDIT_Y2X, y2x);
	DDX_Text(pDX, IDC_EDIT_Y2Y, y2y);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditDef, CDialog)
	//{{AFX_MSG_MAP(CEditDef)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditDef message handlers
