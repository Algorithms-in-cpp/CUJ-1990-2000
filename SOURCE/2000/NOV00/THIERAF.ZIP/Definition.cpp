// Definition.cpp : implementation file
//

#include "stdafx.h"
#include "scandat.h"
#include "Definition.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDefinition dialog


CDefinition::CDefinition(CWnd* pParent /*=NULL*/)
	: CDialog(CDefinition::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDefinition)
	_x1v = 0.0;
	_x1x = 0;
	_x1y = 0;
	_x2v = 0.0;
	_x2x = 0;
	_x2y = 0;
	_y1v = 0.0;
	_y1x = 0;
	_y1y = 0;
	_y2v = 0.0;
	_y2x = 0;
	_y2y = 0;
	//}}AFX_DATA_INIT
}


void CDefinition::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDefinition)
	DDX_Text(pDX, IDC_EDIT_X1V, _x1v);
	DDX_Text(pDX, IDC_EDIT_X1X, _x1x);
	DDX_Text(pDX, IDC_EDIT_X1Y, _x1y);
	DDX_Text(pDX, IDC_EDIT_X2V, _x2v);
	DDX_Text(pDX, IDC_EDIT_X2X, _x2x);
	DDX_Text(pDX, IDC_EDIT_X2Y, _x2y);
	DDX_Text(pDX, IDC_EDIT_Y1V, _y1v);
	DDX_Text(pDX, IDC_EDIT_Y1X, _y1x);
	DDX_Text(pDX, IDC_EDIT_Y1Y, _y1y);
	DDX_Text(pDX, IDC_EDIT_Y2V, _y2v);
	DDX_Text(pDX, IDC_EDIT_Y2X, _y2x);
	DDX_Text(pDX, IDC_EDIT_Y2Y, _y2y);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDefinition, CDialog)
	//{{AFX_MSG_MAP(CDefinition)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDefinition message handlers
