// scanView.h : interface of the CScanView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCANVIEW_H__C523B65E_53CA_11D4_BF8E_005004508160__INCLUDED_)
#define AFX_SCANVIEW_H__C523B65E_53CA_11D4_BF8E_005004508160__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CScanView : public CScrollView
{
protected: // create from serialization only
	CScanView();
	DECLARE_DYNCREATE(CScanView)

// Attributes
public:
	CScanDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScanView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CScanView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CScanView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void DrawAxisPoint (CDC *pDC, CPoint &point);
	void DrawDataPoint (CDC *pDC, CDataPoint &DataPoint);
	CPoint ConvertMyPoint (CPoint &point);
	CPoint ConvertPoint (CPoint &point);
	void HandlePoint (CPoint &point, CScanDoc *ptDoc);
	void HandleDefinition (CPoint &point, CScanDoc *ptDoc);
   int nOffx, nOffy;
};

#ifndef _DEBUG  // debug version in scanView.cpp
inline CScanDoc* CScanView::GetDocument()
   { return (CScanDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCANVIEW_H__C523B65E_53CA_11D4_BF8E_005004508160__INCLUDED_)
