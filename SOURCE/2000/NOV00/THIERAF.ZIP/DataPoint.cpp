// DataPoint.cpp: implementation of the CDataPoint class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ScanDat.h"
#include "DataPoint.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_SERIAL(CDataPoint, CObject, 1)

CDataPoint::CDataPoint() : pt(0,0), xerr(0,0), yerr(0,0)
{

}

CDataPoint::CDataPoint(CPoint &p) : pt(p), xerr(p), yerr(p)
{

}

CDataPoint::~CDataPoint()
{

}

//////////////////////////////////////////////////////////////////////
// Class Access
//////////////////////////////////////////////////////////////////////
void CDataPoint::SetXErr(CPoint &point)
{
   xerr = point;
}

void CDataPoint::SetYErr(CPoint &point)
{
   yerr = point;
}

void CDataPoint::SetPoint(CPoint &point)
{
   pt = point;
}

CPoint CDataPoint::GetPoint()
{
   return pt;
}

CPoint CDataPoint::GetXErr()
{
   return xerr;
}

CPoint CDataPoint::GetYErr()
{
   return yerr;
}

//////////////////////////////////////////////////////////////////////
// Serialization            
//////////////////////////////////////////////////////////////////////
void CDataPoint::Serialize(CArchive &ar)
{
	if (ar.IsStoring())
	{
		ar << pt;
		ar << xerr;
		ar << yerr;
	}
	else
	{
		ar >> pt;
		ar >> xerr;
		ar >> yerr;
	}
}

