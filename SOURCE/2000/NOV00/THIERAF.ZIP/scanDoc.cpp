// scanDoc.cpp : implementation of the CScanDoc class
//

#include "stdafx.h"
#include "scandat.h"
#include "bmap.h"
#include "mainfrm.h"
#include "math.h"
#include "editdef.h"

#include "scanDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScanDoc

IMPLEMENT_DYNCREATE(CScanDoc, CDocument)

BEGIN_MESSAGE_MAP(CScanDoc, CDocument)
	//{{AFX_MSG_MAP(CScanDoc)
	ON_COMMAND(ID_FILE_IMPORT, OnFileImport)
	ON_COMMAND(ID_VIEW_NORMAL, OnViewNormal)
	ON_COMMAND(ID_VIEW_ZOOM, OnViewZoom)
	ON_COMMAND(ID_OPTIONS_XERR, OnOptionsXerr)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_XERR, OnUpdateOptionsXerr)
	ON_COMMAND(ID_OPTIONS_YERR, OnOptionsYerr)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_YERR, OnUpdateOptionsYerr)
	ON_COMMAND(ID_OPTIONS_XLOG, OnOptionsXlog)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_XLOG, OnUpdateOptionsXlog)
	ON_COMMAND(ID_OPTIONS_YLOG, OnOptionsYlog)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_YLOG, OnUpdateOptionsYlog)
	ON_COMMAND(ID_EDIT_XA, OnEditX1)
	ON_COMMAND(ID_EDIT_XB, OnEditX2)
	ON_COMMAND(ID_EDIT_YA, OnEditY1)
	ON_COMMAND(ID_EDIT_YB, OnEditY2)
	ON_COMMAND(ID_EDIT_ACQUIRE_DATA, OnEditAcquireData)
	ON_COMMAND(ID_FILE_EXPORT, OnFileExport)
	ON_COMMAND(ID_EDIT_EDIT, OnEditEdit)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NORMAL, OnUpdateViewNormal)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOM, OnUpdateViewZoom)
	ON_UPDATE_COMMAND_UI(ID_FILE_EXPORT, OnUpdateFileExport)
	ON_UPDATE_COMMAND_UI(ID_EDIT_EDIT, OnUpdateEditEdit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_ACQUIRE_DATA, OnUpdateEditAcquireData)
	ON_UPDATE_COMMAND_UI(ID_EDIT_XA, OnUpdateEditX1)
	ON_UPDATE_COMMAND_UI(ID_EDIT_XB, OnUpdateEditX2)
	ON_UPDATE_COMMAND_UI(ID_EDIT_YA, OnUpdateEditY1)
	ON_UPDATE_COMMAND_UI(ID_EDIT_YB, OnUpdateEditY2)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REDO, OnUpdateEditRedo)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_COMMAND(ID_EDIT_REDO, OnEditRedo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScanDoc construction/destruction

CScanDoc::CScanDoc() : ptBitMap (NULL), MAX_ZOOM (3.0)
{
}

CScanDoc::~CScanDoc()
{
   if (ptBitMap != NULL)
   {
      delete ptBitMap;
   }
}

BOOL CScanDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

   dZoom = 1.0;
   fErrorX = FALSE;
   fErrorY = FALSE;
   state = IDLE;
   ptBitMap = NULL;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CScanDoc serialization

void CScanDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
      ar << fErrorX;
      ar << fErrorY;
      ar << dZoom;
	}
	else
	{
      ar >> fErrorX;
      ar >> fErrorY;
      ar >> dZoom;
      if (ptBitMap != NULL)
      {
         delete ptBitMap;
      }
      ptBitMap = new CBMap;
	}
   X.Serialize (ar);
   Y.Serialize (ar);
   lstDataPoint.Serialize (ar);
   lstUndo.Serialize (ar);
   ptBitMap->Serialize (ar);
   UpdateAllViews (NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CScanDoc diagnostics

#ifdef _DEBUG
void CScanDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CScanDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScanDoc commands

void CScanDoc::OnFileImport() 
{
   CFileDialog aFileDialog (TRUE, "bmp", "*.bmp");
   
   if (aFileDialog.DoModal() == IDOK)
   {
      CString PathName = aFileDialog.GetPathName ();
      if (ptBitMap != NULL)
      {
         delete ptBitMap;
      }
      ptBitMap = new CBMap;
      ptBitMap->ReadFromFile (PathName);
      UpdateAllViews(NULL);
   }
}

void CScanDoc::OnViewNormal() 
{
   dZoom = 1.0;
   UpdateAllViews (NULL, ZOOM);
}

void CScanDoc::OnViewZoom() 
{
   dZoom = 3.0;	
   UpdateAllViews (NULL);
}

void CScanDoc::OnOptionsXerr() 
{
   fErrorX = !fErrorX;	
}

void CScanDoc::OnUpdateOptionsXerr(CCmdUI* pCmdUI) 
{
   pCmdUI->SetCheck (fErrorX);	
}

void CScanDoc::OnOptionsYerr() 
{
   fErrorY = !fErrorY;
}

void CScanDoc::OnUpdateOptionsYerr(CCmdUI* pCmdUI) 
{
   pCmdUI->SetCheck (fErrorY);	
}

void CScanDoc::OnOptionsXlog() 
{
   X.SetLogScale (!X.IsLogScale () );	
   X.SetScale();
}

void CScanDoc::OnUpdateOptionsXlog(CCmdUI* pCmdUI) 
{
   pCmdUI->SetCheck (X.IsLogScale () );	
}

void CScanDoc::OnOptionsYlog() 
{
   Y.SetLogScale (!Y.IsLogScale() );	
   Y.SetScale();
}

void CScanDoc::OnUpdateOptionsYlog(CCmdUI* pCmdUI) 
{
   pCmdUI->SetCheck (Y.IsLogScale ());	
}

void CScanDoc::OnEditX1() 
{
   SetStatusText ("Left click a point on the physical x axis");
   state = X1;	
}

void CScanDoc::OnEditX2() 
{
   SetStatusText ("Left click a point on the physical x axis");
   state = X2;	
}

void CScanDoc::OnEditY1() 
{
   SetStatusText ("Left click a point on the physical y axis");
   state = Y1;	
}

void CScanDoc::OnEditY2() 
{
   SetStatusText ("Left click a point on the physical y axis");
   state = Y2;	
}

void CScanDoc::SetStatusText(CString str)
{
   CMainFrame *ptFrame = (CMainFrame *) AfxGetApp()->m_pMainWnd;
   CStatusBar *ptStatus = &ptFrame->m_wndStatusBar;
   if (ptStatus)
   {
      ptStatus->SetPaneText (0, str);
   }
}

CDataPoint * CScanDoc::NewDataPoint(CPoint &point)
{
   CDataPoint *ptDataPoint = new CDataPoint (point);
   lstDataPoint.AddTail (ptDataPoint);
   return ptDataPoint;
}

void CScanDoc::OnEditAcquireData() 
{
   state = POINT;	
}

void CScanDoc::OnFileExport() 
{
	// get the filename from the user
	CFileDialog dlg(FALSE, "TXT", "*.TXT");
	if (dlg.DoModal()!= IDOK)
	{
		return;
	}

	// Open the correspondig File
	CStdioFile file; 
	if(!file.Open (dlg.GetPathName(), CFile::modeWrite | CFile::modeCreate ))
	{
		AfxMessageBox("The file could not be opened");
		return;
	}

	// Write the data to the file
	POSITION pos = lstDataPoint.GetHeadPosition();
   CString str;
	double dy, dx;
	while (pos != NULL)
	{
      CDataPoint *ptDataPoint = lstDataPoint.GetNext(pos);

      double x = X.GetPhysVal (ptDataPoint->GetPoint());
      double y = Y.GetPhysVal (ptDataPoint->GetPoint());
      str.Format ("%f %f", x, y);      

		if (fErrorX)
		{
			double ex = X.GetPhysVal (ptDataPoint->GetXErr ());
			
			dx = sqrt ( (ex - x)*(ex - x) );
         CString add;
         add.Format (" %f",dx);
         str += add;
		}

		if (fErrorY)
		{
			double ey = Y.GetPhysVal (ptDataPoint->GetYErr ());

         dy = sqrt ( (ey - y)*(ey - y) );
         CString add;
         add.Format (" %f",dy);
         str += add;
		}

		file.WriteString(str);
      file.WriteString("\n");
	}
	file.Close();
}

void CScanDoc::OnEditEdit() 
{
   CEditDef dlg;
   
   dlg.x1v = X.vA;
   dlg.x1x = X.A.x;
   dlg.x1y = X.A.y;

   dlg.x2v = X.vB;
   dlg.x2x = X.B.x;
   dlg.x2y = X.B.y;

   dlg.y1v = Y.vA;
   dlg.y1x = Y.A.x;
   dlg.y1y = Y.A.y;

   dlg.y2v = Y.vB;
   dlg.y2x = Y.B.x;
   dlg.y2y = Y.B.y;

   dlg.DoModal();

   X.vA = dlg.x1v;
   X.vB = dlg.x2v;
   Y.vA = dlg.y1v;
   Y.vB = dlg.y2v;
   
}

void CScanDoc::OnUpdateViewNormal(CCmdUI* pCmdUI) 
{
   if (dZoom == 1.0)
   {
      pCmdUI->SetCheck (TRUE);
   }
   else
   {
      pCmdUI->SetCheck (FALSE);
   }
}

void CScanDoc::OnUpdateViewZoom(CCmdUI* pCmdUI) 
{
   if (dZoom == 3.0)
   {
      pCmdUI->SetCheck (TRUE);
   }
   else
   {
      pCmdUI->SetCheck (FALSE);
   }
}

void CScanDoc::OnUpdateFileExport(CCmdUI* pCmdUI) 
{
   if (ptBitMap == NULL)
   {
      pCmdUI->Enable (FALSE);
      return;
   }
   if (!X.SetScale () )
   {
      pCmdUI->Enable (FALSE);
      return;
   }
   if (!Y.SetScale () )
   {
      pCmdUI->Enable (FALSE);
      return;
   }
   if (lstDataPoint.IsEmpty ())
   {
      pCmdUI->Enable (FALSE);
      return;
   }
   pCmdUI->Enable (TRUE);
}

void CScanDoc::OnUpdateEditEdit(CCmdUI* pCmdUI) 
{
   if (!X.SetScale () )
   {
      pCmdUI->Enable (FALSE);
      return;
   }
   if (!Y.SetScale () )
   {
      pCmdUI->Enable (FALSE);
      return;
   }
   pCmdUI->Enable (TRUE);
}

void CScanDoc::OnUpdateEditAcquireData(CCmdUI* pCmdUI) 
{
   if (!X.SetScale () )
   {
      pCmdUI->Enable (FALSE);
      return;
   }
   if (!Y.SetScale () )
   {
      pCmdUI->Enable (FALSE);
      return;
   }
   pCmdUI->Enable (TRUE);
}

void CScanDoc::OnUpdateEditX1(CCmdUI* pCmdUI) 
{
   if (ptBitMap == NULL)
   {
      pCmdUI->Enable (FALSE);
   }
   else
   {
      pCmdUI->Enable (TRUE);
   }
}

void CScanDoc::OnUpdateEditX2(CCmdUI* pCmdUI) 
{
   if (ptBitMap == NULL)
   {
      pCmdUI->Enable (FALSE);
   }
   else
   {
      pCmdUI->Enable (TRUE);
   }
}

void CScanDoc::OnUpdateEditY1(CCmdUI* pCmdUI) 
{
   if (ptBitMap == NULL)
   {
      pCmdUI->Enable (FALSE);
   }
   else
   {
      pCmdUI->Enable (TRUE);
   }
}

void CScanDoc::OnUpdateEditY2(CCmdUI* pCmdUI) 
{
   if (ptBitMap == NULL)
   {
      pCmdUI->Enable (FALSE);
   }
   else
   {
      pCmdUI->Enable (TRUE);
   }
}

void CScanDoc::OnUpdateEditUndo(CCmdUI* pCmdUI) 
{
   if (lstDataPoint.IsEmpty () )
   {
      pCmdUI->Enable (FALSE);
   }
   else
   {
      pCmdUI->Enable (TRUE);
   }
}

void CScanDoc::OnUpdateEditRedo(CCmdUI* pCmdUI) 
{
   if (lstUndo.IsEmpty () )
   {
      pCmdUI->Enable (FALSE);
   }
   else
   {
      pCmdUI->Enable (TRUE);
   }
}

void CScanDoc::OnEditUndo() 
{
   CDataPoint *ptLast = lstDataPoint.GetTail ();
   lstUndo.AddHead (ptLast);
   lstDataPoint.RemoveTail ();
   UpdateAllViews (NULL);
}

void CScanDoc::OnEditRedo() 
{
   CDataPoint *ptNext = lstUndo.GetHead ();
   lstDataPoint.AddTail (ptNext);
   lstUndo.RemoveHead ();
   UpdateAllViews (NULL);
}
