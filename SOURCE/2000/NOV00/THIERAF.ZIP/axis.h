// Axis.h: interface for the CAxis class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Axis_H__072DA323_903A_11D2_9725_8B2D4AC81B3C__INCLUDED_)
#define AFX_Axis_H__072DA323_903A_11D2_9725_8B2D4AC81B3C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif 

class CAxis : public CObject
{
   DECLARE_SERIAL(CAxis)

   friend class CScanDoc;

   public:
	   CAxis();
	   virtual ~CAxis();
	   BOOL SetScale ();
	   void SetLogScale (bool );
	   BOOL IsLogScale (void);
	   double GetPhysVal (CPoint &);
	   void SetValueB (double &);
	   void SetValueA (double &);
	   BOOL GetPointB (CPoint &, double &);
	   BOOL GetPointA (CPoint &, double &);
	   void SetPointB (CPoint &, double );
	   void SetPointA (CPoint &, double );
   	virtual void Serialize (CArchive &);

   private:
	   BOOL fBDefined;
	   BOOL fADefined;
	   CPoint A, B;
      double vA, vB;
      BOOL   fLogScale;
	   double s, m, M, c;
	   double get_physical_value (double , double );
	   void project_data_point (CPoint &, double &, double &);
};

#endif 
