// Axis.cpp: implementation of the CAxis class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ScanDat.h"
#include "Axis.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_SERIAL(CAxis, CObject, 1)

CAxis::CAxis() : A(0,0), B(0,0), vA(0.0), vB(0.0), fLogScale (FALSE), fADefined (FALSE), fBDefined (FALSE)
{
}

CAxis::~CAxis()
{
}

//////////////////////////////////////////////////////////////////////
// Class Operations          
//////////////////////////////////////////////////////////////////////
BOOL CAxis::SetScale()
{
   if (!fADefined) return FALSE;
   if (!fBDefined) return FALSE;
   if (A == B) return FALSE;
   if (vA == vB) return FALSE;

   //
   // Calculates the slopes of the axis and the projection line
   // using the factoid that the projection line is orthogonal
   // to the axis, therefore M = -1/m.
   // If either the axis or the projection line is vertical
   // in the device coordinate system, we set it's slope to
   // 100000 (which is almost infinity).
   // Also calculates the scaling factor s
   //
   double E = B.y - A.y;
   double F = B.x - A.x;
   if ( F == 0.0)
   {
      m = 100000.0;
      M = 0.0;
   }
   else if ( E == 0.0 )
   {
      m = 0;
      M = 100000.0;
   }
   else
   {
      m = E / F;
      M = -1.0 / m;
   }

   // calculate the y axis cutouts of the axis
   c = (double) A.y - m * (double) A.x;

   // calculate the scale factor between physical and device axis
   double Delta = (B.x - A.x) * (B.x - A.x);
   Delta += (B.y - A.y) * (B.y - A.y);
   Delta = sqrt(Delta);
   if (fLogScale)
   {
      s = ( log(vB) - log(vA) ) / Delta ;
   }
   else
   {
      s = (vB - vA) / Delta ;
   }
   return TRUE;
}

double CAxis::GetPhysVal(CPoint &D)
{
   double v = 0, Px, Py;

   //
   // calcualate the physical value of the device coordinate
   // point D in two steps:
   // - Project D onto the axis yielding point P in device
   //   coordinates
   // - translate the device coordinates of P into a physical
   //   value
   //
   project_data_point (D, Px, Py);
   v = get_physical_value (Px, Py);
   return v;
}

void CAxis::project_data_point (CPoint &D, double &Px, double &Py)
{
   //
   // This method projects a given data point D onto the axis
   // resulting in point P.
   // The device coordinates Px and Py of P are calculated and
   // returned
   //
   //
   // 
   // First, we need the equation for the projection line p(x)
   // Like any line, p(x) is given by:
   //
   // P(x) = M * x + C
   //
   // M is the slope and is given by -1/m, where m is the 
   // slope of the axis.
   //
   // We need to calculate the y axis coutout C of the projection
   // line
   //
   double C = (double) D.y - M * (double) D.x;

   //
   // Now we need to calculate the device coordintates of
   // the point of intersection between the axis and the
   // projection  In other words:
   // We need to solve the following equation for x:
   //
   //              g(x)  =  p(x)                   <==>
   //         m * x + c  =  M * x + C              <==>
   //       (m - M) * x  =  C - c                  <==>
   //                 x  = (C - c) / (m - M)       <==>
   //
   // x is the x coordinate of the projection point P. 
   // x = P.x = Px
   // 
   //                Px  = (C - c) / (m - M)       <==>
   //
   // To calculate the y coordinate of P (i. e. P.y or Py)
   // we substitute Px as x into either g(x) or p(x)
   //
   //     Py  = g(P.x)       =  p(P.x)             <==>
   //     Py  = m * P.x + c  =  M * P.x + C
   //                
   Px = (C - c)/(m - M);
   Py = m * Px + c;
}

double CAxis::get_physical_value (double Px, double Py)
{
   double v;

   //
   // PA_d is the distance between the points P and A 
   // in device coordinates. It is calculated using the
   // Law of Pythagoras for the distance between to points
   // in a cartesian coordinate system:
   //
   double PA_d = (Px - (double) A.x) * (Px - (double) A.x);
   PA_d += (Py - (double) A.y) * (Py - (double) A.y);
   PA_d = sqrt(PA_d);

   //
   // We are interested in the distance between P and A 
   // in physical coordinates (PA_p). (PA_p) is obtained
   // by multiplying (PA_d) with the scale factor s, which 
   // is defined in the SetScale method of CAxis.
   //
   // (PA_p) = (PA_d) * s
   //
   //
   //
   // The physical value v is then obtained by adding the
   // "directional" distance between P and A in physical 
   // coordinates to the physical coordinate value of A. 
   //
   // Crudely speaking, if P is to the right of A we add,
   // if P is to the left of A we subtract. 
   //
   double signum = (Px - A.x)*(B.x - A.x) + (Py - A.y)*(B.y - A.y);
   double PA_p = PA_d * s;
   if (fLogScale)
   {
      if (signum > 0)
      {
         v = PA_d * s + log (vA);
      }
      else
      {
         v = -PA_d * s + log (vA);
      }
      v = exp (v);
   }
   else
   {
      if (signum > 0)
      {
         v = PA_d * s + vA;
      }
      else
      {
         v = -PA_d * s + vA;
      }  
   }
   return v;
}

//////////////////////////////////////////////////////////////////////
// Class Access              
//////////////////////////////////////////////////////////////////////
void CAxis::SetLogScale(bool fLog)
{
   fLogScale = fLog;
}

BOOL CAxis::IsLogScale()
{
   return fLogScale;
}

void CAxis::SetPointA(CPoint &P1, double V1)
{
   A = P1;
   vA = V1;
   fADefined = TRUE;
}

void CAxis::SetPointB(CPoint &P2, double V2)
{
   B = P2;
   vB = V2;
   fBDefined = TRUE;
}

BOOL CAxis::GetPointA(CPoint &point, double &value)
{
   point = A;
   value = vA;
   return fADefined;
}

BOOL CAxis::GetPointB(CPoint &point, double &value)
{
   point = B;
   value = vB;
   return fBDefined;
}

void CAxis::SetValueA(double &value)
{
   vA = value;
}

void CAxis::SetValueB(double &value)
{
   vB = value;
}

//////////////////////////////////////////////////////////////////////
// Serialization          
//////////////////////////////////////////////////////////////////////
void CAxis::Serialize(CArchive &ar)
{
	if (ar.IsStoring())
	{
		ar << A;
		ar << B;
		ar << vA;
      ar << vB;
      ar << fLogScale;
      ar << fADefined;
      ar << fBDefined;
	}
	else
	{
		ar >> A;
		ar >> B;
		ar >> vA;
      ar >> vB;
      ar >> fLogScale;
      ar >> fADefined;
      ar >> fBDefined;
	}
}

