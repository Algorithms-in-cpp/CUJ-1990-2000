#if !defined(AFX_BMAP_H__C523B66C_53CA_11D4_BF8E_005004508160__INCLUDED_)
#define AFX_BMAP_H__C523B66C_53CA_11D4_BF8E_005004508160__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif 

class CBMap : public CObject
{
   DECLARE_SERIAL(CBMap)

   public:
	   CBMap();
   	virtual ~CBMap();
	   BOOL ReadFromFile (CString &);
	   void Draw (CDC *, int );
	   BOOL Init ();
	   BOOL SetNumColors();
	   BOOL SetPalette ();
	   CSize GetDim();
	   void Serialize (CArchive &);

   private:
	   LPBITMAPINFOHEADER lpBitMap;
	   DWORD dwBitMapSize, dwColors;
	   CPalette *pPalette;
	   CSize Dimension;
};

#endif 