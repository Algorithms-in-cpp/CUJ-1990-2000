// scanView.cpp : implementation of the CScanView class
//

#include "stdafx.h"
#include "scandat.h"
#include "scanDoc.h"
#include "scanView.h"
#include "datapoint.h"
#include "physval.h"
#include "mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScanView

IMPLEMENT_DYNCREATE(CScanView, CScrollView)

BEGIN_MESSAGE_MAP(CScanView, CScrollView)
	//{{AFX_MSG_MAP(CScanView)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScanView construction/destruction

CScanView::CScanView() : nOffx(0), nOffy(0)
{
}

CScanView::~CScanView()
{
}

BOOL CScanView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CScanView drawing

void CScanView::OnDraw(CDC* pDC)
{
	CScanDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

   // draw the bitmap (if there is one)
   if (pDoc->ptBitMap == NULL) return;
   pDoc->ptBitMap->Draw(pDC, (int) pDoc->dZoom);

   // Get the offset
   nOffx = GetScrollPos (SB_HORZ);
   nOffy = GetScrollPos (SB_VERT);

   // draw the axis points A and B for both axes (if defined)
   CPoint point;
   double value;
   CClientDC dc(this);
   if (pDoc->X.GetPointA (point, value))
   {
      DrawAxisPoint (&dc, point);
   }
   if (pDoc->X.GetPointB (point, value))
   {
      DrawAxisPoint (&dc, point);
   }
   if (pDoc->Y.GetPointA (point, value))
   {
      DrawAxisPoint (&dc, point);
   }
   if (pDoc->Y.GetPointB (point, value))
   {
      DrawAxisPoint (&dc, point);
   }

   // draw the datapoints which the user has marked
   CTypedPtrList <CObList, CDataPoint *> &Data = pDoc->lstDataPoint;
   POSITION pos = Data.GetHeadPosition ();
   while (pos != NULL)
   {
      CDataPoint *ptDataPoint = Data.GetNext (pos);
      DrawDataPoint (&dc, *ptDataPoint);
   }
}

void CScanView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

   // set the scroll sizes. Keeps MFC happy
	SetScrollSizes(MM_TEXT, CSize (100, 100));
}

/////////////////////////////////////////////////////////////////////////////
// CScanView diagnostics

#ifdef _DEBUG
void CScanView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CScanView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CScanDoc* CScanView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CScanDoc)));
	return (CScanDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScanView message handlers

void CScanView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
   CScrollView::OnUpdate (pSender, lHint, pHint);
   CScanDoc *pDoc = GetDocument();

   // set scroll sizes in relation to the imported bitmap (if any)
   CSize sizeTotal (100, 100);
   if (pDoc->ptBitMap != NULL)
   {
      sizeTotal = pDoc->ptBitMap->GetDim ();
   }
   CSize sizePage (100, 100); 
   CSize sizeLine (10, 10);
   sizeTotal.cx *= (int) pDoc->dZoom;
   sizeTotal.cy *= (int) pDoc->dZoom;
   SetScrollSizes (MM_TEXT, sizeTotal, sizePage, sizeLine);

   // if the user switched from a larger zoom factor to a smaller one
   // the scroll bar positions may no longer be valid. Jump to top left
   // corner.
   if ( (int) lHint == CScanDoc::ZOOM)
   {
      OnVScroll (SB_TOP, 0, NULL);
      OnHScroll (SB_LEFT, 0, NULL);
   }
}

void CScanView::OnLButtonDown(UINT nFlags, CPoint point) 
{
   CScanDoc *ptDoc = GetDocument();
   CPoint MyPoint = ConvertPoint (point);

   if (ptDoc->state <= CScanDoc::Y2)
   {
      HandleDefinition (MyPoint, ptDoc);
   }
   else 
   {
      HandlePoint (MyPoint, ptDoc);
   }
	CScrollView::OnLButtonDown(nFlags, point);
}

void CScanView::HandleDefinition(CPoint &point, CScanDoc *ptDoc)
{
   // have the user enter the physical value
   CPhysVal dlg;
   dlg.DoModal ();
   switch (ptDoc->state)
   {
      case CScanDoc::X1:
         ptDoc->X.SetPointA (point, dlg.dValue);
         break;
      case CScanDoc::X2:
         ptDoc->X.SetPointB (point, dlg.dValue);
         break;
      case CScanDoc::Y1:
         ptDoc->Y.SetPointA (point, dlg.dValue);
         break;
      case CScanDoc::Y2:
         ptDoc->Y.SetPointB (point, dlg.dValue);
         break;
   }
   ptDoc->SetModifiedFlag ();
   ptDoc->UpdateAllViews(NULL);
   ptDoc->state = CScanDoc::IDLE;
}

void CScanView::HandlePoint(CPoint &point, CScanDoc *ptDoc)
{
   CClientDC dc(this);
   static CDataPoint *ptCurrentDataPoint;

   switch (ptDoc->state)
   {
      case CScanDoc::XERR:
         ptCurrentDataPoint->SetXErr(point);
         ptDoc->state = CScanDoc::POINT;
         break;
      case CScanDoc::YERR:
         ptCurrentDataPoint->SetYErr(point);
         if (ptDoc->fErrorX)
         {
            ptDoc->state = CScanDoc::XERR;
         }
         else
         {
            ptDoc->state = CScanDoc::POINT;
         }
         break;

      case CScanDoc::POINT:
         ptCurrentDataPoint = ptDoc->NewDataPoint (point);
         if (ptDoc->fErrorY )
         {
            ptDoc->state = CScanDoc::YERR;
         }
         else if (ptDoc->fErrorX )
         {
            ptDoc->state = CScanDoc::XERR;
         }
         else
         {
            ptDoc->state = CScanDoc::POINT;
         }
         break;
      default:
         return;
         break;
   }
   DrawDataPoint (&dc, *ptCurrentDataPoint);
   ptDoc->SetModifiedFlag ();
}

void CScanView::DrawAxisPoint(CDC *pDC, CPoint &point)
{
	CPen *SavePen;
	CPen aPen;

   // let's draw in blue
	aPen.CreatePen(PS_SOLID, 1, RGB(0,0,255));
	SavePen = pDC->SelectObject(&aPen);

   // convert the data point to pixels
   CPoint pt = ConvertMyPoint (point);

   // draw the axis point
	pDC->Ellipse(pt.x-3, pt.y-3, pt.x+3, pt.y+3);

   // restore the old pen
	pDC->SelectObject(SavePen);
}

void CScanView::DrawDataPoint(CDC *pDC, CDataPoint &DataPoint)
{
	CPen *SavePen;
	CPen aPen;

   // let's draw in red
	aPen.CreatePen(PS_SOLID, 1, RGB(255,0,0));
	SavePen = pDC->SelectObject(&aPen);

   // convert the data point to pixels
   CPoint pt = ConvertMyPoint (DataPoint.GetPoint () );
   CPoint xerr = ConvertMyPoint (DataPoint.GetXErr () );
   CPoint yerr = ConvertMyPoint (DataPoint.GetYErr () );

   // draw the data point
	pDC->Ellipse(pt.x-3, pt.y-3, pt.x+3, pt.y+3);

   // draw the error bars (if any)
	if (pt != xerr)
	{
		int dx = xerr.x - pt.x;
		pDC->MoveTo(pt.x, pt.y );
		pDC->LineTo(pt.x + dx, pt.y );
		pDC->MoveTo(pt.x, pt.y );
		pDC->LineTo(pt.x - dx, pt.y );
	}
	if (pt != yerr)
	{
		int dy = yerr.y - pt.y;
		pDC->MoveTo(pt.x, pt.y );
		pDC->LineTo(pt.x, pt.y + dy );
		pDC->MoveTo(pt.x, pt.y );
		pDC->LineTo(pt.x, pt.y - dy );
	}

   // restore the old pen
	pDC->SelectObject(SavePen);
}

CPoint CScanView::ConvertPoint(CPoint &point)
{
	CScanDoc *pDoc = GetDocument();
   CPoint MyPoint, offset (nOffx, nOffy);

   if (pDoc->dZoom == 1.0)
   {
      MyPoint = point + offset;
      MyPoint.x = (long) ( (double) MyPoint.x * 3.0 );
      MyPoint.y = (long) ( (double) MyPoint.y * 3.0 );
   }
   else
   {
      MyPoint = point + offset;
   }

   return MyPoint;
}

CPoint CScanView::ConvertMyPoint(CPoint &MyPoint)
{
	CScanDoc *pDoc = GetDocument();
   CPoint point(MyPoint), offset (nOffx, nOffy);

   if (pDoc->dZoom == 1.0)
   {
      point.x = (long) ( (double) point.x / 3.0 );
      point.y = (long) ( (double) point.y / 3.0 );
      point = point - offset;
   }
   else
   {
      point = MyPoint - offset;
   }
   return point;
}


void CScanView::OnMouseMove(UINT nFlags, CPoint point) 
{
	CScanDoc *pDoc = GetDocument();

   if ( (pDoc->state < CScanDoc::POINT) ||
        (pDoc->state > CScanDoc::YERR)     )
   {
      return;
   }

	CMainFrame *pFrame = (CMainFrame *) AfxGetApp()->m_pMainWnd;
	CStatusBar *pStatus = &pFrame->m_wndStatusBar;

	if (pStatus)
	{
   	CString str;
      CClientDC dc(this);
      CPoint MyPoint = ConvertPoint (point);
      double vx = pDoc->X.GetPhysVal (MyPoint);
      double vy = pDoc->Y.GetPhysVal (MyPoint);
		str.Format ("x = %5d y = %5d  x = %f, y = %f", 
                  MyPoint.x, 
                  MyPoint.y, 
                  vx,
                  vy);
		pStatus->SetPaneText(0, str);
	}

	
	CScrollView::OnMouseMove(nFlags, point);
}

