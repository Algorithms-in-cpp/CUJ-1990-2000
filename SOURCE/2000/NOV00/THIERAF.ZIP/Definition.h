#if !defined(AFX_DEFINITION_H__93C8E836_5222_11D4_BF8A_005004508160__INCLUDED_)
#define AFX_DEFINITION_H__93C8E836_5222_11D4_BF8A_005004508160__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Definition.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDefinition dialog

class CDefinition : public CDialog
{
// Construction
public:
	CDefinition(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDefinition)
	enum { IDD = IDD_EDIT_DEFINITIONS };
	double	_x1v;
	int		_x1x;
	int		_x1y;
	double	_x2v;
	int		_x2x;
	int		_x2y;
	double	_y1v;
	int		_y1x;
	int		_y1y;
	double	_y2v;
	int		_y2x;
	int		_y2y;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDefinition)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDefinition)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEFINITION_H__93C8E836_5222_11D4_BF8A_005004508160__INCLUDED_)
