// EditDef.h : header file
//
#if !defined(AFX_EDITDEF_H__9D0411B4_544B_11D4_BF91_005004508160__INCLUDED_)
#define AFX_EDITDEF_H__9D0411B4_544B_11D4_BF91_005004508160__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif 


class CEditDef : public CDialog
{
   public:
   	CEditDef(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEditDef)
	enum { IDD = IDD_EDIT_DEFINITIONS };
	double	x1v;
	int		x1x;
	int		x1y;
	double	x2v;
	int		x2x;
	int		x2y;
	int		y1x;
	double	y1v;
	int		y1y;
	double	y2v;
	int		y2x;
	int		y2y;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditDef)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditDef)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITDEF_H__9D0411B4_544B_11D4_BF91_005004508160__INCLUDED_)
