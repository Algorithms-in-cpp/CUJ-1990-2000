// Scale.cpp: implementation of the Scale class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "scandat.h"
#include "Scale.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Scale::Scale(CAxis &x, CAxis &y) : X(x), Y(y)
{
}

Scale::~Scale()
{

}

BOOL Scale::PointToPhysical(CPoint &DataPoint, double &dPhysX, double &dPhysY)
{
   return TRUE;
}
