// scanDoc.h : interface of the CScanDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCANDOC_H__C523B65C_53CA_11D4_BF8E_005004508160__INCLUDED_)
#define AFX_SCANDOC_H__C523B65C_53CA_11D4_BF8E_005004508160__INCLUDED_

#include "axis.h"	// Added by ClassView
#include "BMap.h"	// Added by ClassView
#include "datapoint.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CScanDoc : public CDocument
{
   friend class CScanView;

protected: // create from serialization only
	CScanDoc();
	DECLARE_DYNCREATE(CScanDoc)

// Attributes
public:
   enum State { X1, X2, Y1, Y2, POINT, XERR, YERR, IDLE };
   enum Update { STANDARD = 0, ZOOM };
   const double MAX_ZOOM;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScanDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CScanDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CScanDoc)
	afx_msg void OnFileImport();
	afx_msg void OnViewNormal();
	afx_msg void OnViewZoom();
	afx_msg void OnOptionsXerr();
	afx_msg void OnUpdateOptionsXerr(CCmdUI* pCmdUI);
	afx_msg void OnOptionsYerr();
	afx_msg void OnUpdateOptionsYerr(CCmdUI* pCmdUI);
	afx_msg void OnOptionsXlog();
	afx_msg void OnUpdateOptionsXlog(CCmdUI* pCmdUI);
	afx_msg void OnOptionsYlog();
	afx_msg void OnUpdateOptionsYlog(CCmdUI* pCmdUI);
	afx_msg void OnEditX1();
	afx_msg void OnEditX2();
	afx_msg void OnEditY1();
	afx_msg void OnEditY2();
	afx_msg void OnEditAcquireData();
	afx_msg void OnFileExport();
	afx_msg void OnEditEdit();
	afx_msg void OnUpdateViewNormal(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewZoom(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileExport(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditEdit(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditAcquireData(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditX1(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditX2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditY1(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditY2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditRedo(CCmdUI* pCmdUI);
	afx_msg void OnEditUndo();
	afx_msg void OnEditRedo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CDataPoint * NewDataPoint (CPoint &point);
	void SetStatusText (CString str);
	CAxis Y;
	CAxis X;
	BOOL fErrorX;
	BOOL fErrorY;
   double dZoom;
   State state;
	CBMap *ptBitMap;
   CTypedPtrList <CObList, CDataPoint *> lstDataPoint;
   CTypedPtrList <CObList, CDataPoint *> lstUndo;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCANDOC_H__C523B65C_53CA_11D4_BF8E_005004508160__INCLUDED_)
