/////////////////////////////////////////////////////////////////////////////
// CBMap
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "scandat.h"
#include "BMap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CBMap, CObject, 1)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CBMap::CBMap() : lpBitMap (NULL), Dimension (CSize(0,0)), pPalette (NULL)
{
}

CBMap::~CBMap()
{
   if (lpBitMap != NULL)
   {
      free (lpBitMap);
   }
   if (pPalette != NULL)
   {
      delete pPalette;
   }
}

//////////////////////////////////////////////////////////////////////
// Class Operations          
//////////////////////////////////////////////////////////////////////
BOOL CBMap::ReadFromFile(CString &strFileName)
{
	BITMAPFILEHEADER bmfHeader;
	DWORD dwSize, dwBytesRead;
   CFile BitMapFile;

   // lets see if we can open this file
   if (!BitMapFile.Open (strFileName,
                         CFile::modeRead | CFile::shareDenyWrite) )
   {
      return FALSE;
   }
	dwSize = BitMapFile.GetLength();

   // read and check the bitmap file header
	dwBytesRead = BitMapFile.Read( (LPSTR)&bmfHeader, sizeof(bmfHeader) );
   if (dwBytesRead != sizeof(bmfHeader))
   {
		return FALSE;
   }
   if (memcmp ( (LPVOID) &bmfHeader, (LPVOID) "BM", 2) != 0)
   {
      return FALSE;
   }

   // load the bitmap into memory
   if (lpBitMap != NULL)
   {
      free (lpBitMap);
   }
   lpBitMap = (LPBITMAPINFOHEADER) malloc (dwSize);
   if (lpBitMap == NULL)
   {
      return FALSE;
   }
	dwBitMapSize = BitMapFile.Read(lpBitMap, dwSize - sizeof(BITMAPFILEHEADER) );
   if (dwBitMapSize != (dwSize - sizeof(BITMAPFILEHEADER) ) )
	{
      free (lpBitMap);
      lpBitMap = NULL;
		return FALSE;
	}
   return Init();
}

BOOL CBMap::SetPalette(void)
{
	LPLOGPALETTE lpPal;     
   LPBITMAPINFO lpBMInfo;
   BOOL fSuccess = FALSE;
	int i;                  

	if (lpBitMap == NULL)
   {
	  return FALSE;
   }
   lpBMInfo = (LPBITMAPINFO) lpBitMap;

   if (dwColors != 0)
   {
		// allocate memory for logical palette 
		lpPal = (LPLOGPALETTE) malloc ( sizeof(LOGPALETTE) + sizeof(PALETTEENTRY) * dwColors );
		if (lpPal == NULL)
		{
			return FALSE;
		}

		// set version and number of palette entries
		lpPal->palVersion = 0x0300;
		lpPal->palNumEntries = (WORD) dwColors;
		for (i = 0; i < (int) dwColors; i++)
		{
			lpPal->palPalEntry[i].peRed = lpBMInfo->bmiColors[i].rgbRed;
			lpPal->palPalEntry[i].peGreen = lpBMInfo->bmiColors[i].rgbGreen;
			lpPal->palPalEntry[i].peBlue = lpBMInfo->bmiColors[i].rgbBlue;
			lpPal->palPalEntry[i].peFlags = 0;
		}

		// create the palette 
      if (pPalette != NULL)
      {
         delete pPalette;
      }
      pPalette = new CPalette;    
		fSuccess = pPalette->CreatePalette(lpPal);
      free (lpPal);
	}
	return fSuccess;

}

BOOL CBMap::SetNumColors()
{
   if (lpBitMap == NULL)
   {
      return FALSE;
   }

   WORD wBitCount = lpBitMap->biBitCount;
   DWORD dwClrUsed = lpBitMap->biClrUsed;
	if(dwClrUsed == 0) 
   {
		switch(wBitCount) 
      {
			case 1:
				dwColors = 2;
				break;
			case 4:
			   dwColors = 16;
				break;
			case 8:
				dwColors = 256;
				break;
			default:
				dwColors = 0;
            break;
		}
	}
	else 
   {
		dwColors = dwClrUsed;
	}
   return TRUE;
}

void CBMap::Draw(CDC *ptDC, int nZoom)
{
   if (lpBitMap == NULL)
   {
      return;
   }

   DWORD    dwSize = lpBitMap->biSize ;
	HPALETTE hPal=NULL, hOldPal=NULL;      
	BOOL     bSuccess=FALSE;    
	LPVOID   lpvBits;           

   // find the bits of the bitmap
	lpvBits = (LPVOID) ( ((char *)lpBitMap) + dwSize + dwColors * sizeof (RGBQUAD));

   int nOffset = (char *) lpvBits - (char *) lpBitMap;

	// Select the bitmaps palette into the device context
	if (pPalette != NULL)
	{
		hPal = (HPALETTE) pPalette->m_hObject;
		hOldPal = ::SelectPalette(ptDC->m_hDC, hPal, TRUE);
	}
   else
   {
      return;
   }

   // Stretch the bitmap onto the client window area
	::SetStretchBltMode(ptDC->m_hDC, COLORONCOLOR);
   bSuccess = ::StretchDIBits(ptDC->m_hDC,                  
      							   0,               
   	   						   0,                
	  	   					      nZoom * Dimension.cx,          
	 		   				      nZoom * Dimension.cy,         
				   			      0,              
					   		      0,               
						   	      Dimension.cx,         
							         Dimension.cy,        
							         lpvBits,                      
   							      (LPBITMAPINFO)lpBitMap,       
	   						      DIB_RGB_COLORS,               
		   					      SRCCOPY);                     

	/* Reselect old palette */
	if (hOldPal != NULL)
	{
		::SelectPalette(ptDC->m_hDC, hOldPal, TRUE);
	}
}

BOOL CBMap::Init()
{
   Dimension.cx = lpBitMap->biWidth;
   Dimension.cy = lpBitMap->biHeight;
   SetNumColors ();
	return SetPalette();
}

//////////////////////////////////////////////////////////////////////
// Class Access              
//////////////////////////////////////////////////////////////////////
CSize CBMap::GetDim()
{
   return Dimension;
}

//////////////////////////////////////////////////////////////////////
// Serialization             
//////////////////////////////////////////////////////////////////////
void CBMap::Serialize(CArchive &ar)
{
	if (ar.IsStoring())
	{
		ar << Dimension;
		ar << dwColors;
		ar << dwBitMapSize;
      ar.Write ( (LPVOID) lpBitMap, dwBitMapSize);
	}
	else
	{
		ar >> Dimension;
		ar >> dwColors;
		ar >> dwBitMapSize;
      if (lpBitMap != NULL)
      {
         free (lpBitMap);
      }
      lpBitMap = (LPBITMAPINFOHEADER) malloc (dwBitMapSize);
      if (lpBitMap == NULL)
      {
         return;
      }
      ar.Read ( (LPVOID) lpBitMap, dwBitMapSize);
      Init();
	}
}

