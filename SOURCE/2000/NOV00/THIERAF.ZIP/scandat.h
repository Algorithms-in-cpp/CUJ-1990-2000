// scandat.h : main header file for the SCANDAT application
//

#if !defined(AFX_SCANDAT_H__C523B654_53CA_11D4_BF8E_005004508160__INCLUDED_)
#define AFX_SCANDAT_H__C523B654_53CA_11D4_BF8E_005004508160__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CScanApp:
// See scandat.cpp for the implementation of this class
//

class CScanApp : public CWinApp
{
public:
	CScanApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScanApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CScanApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCANDAT_H__C523B654_53CA_11D4_BF8E_005004508160__INCLUDED_)
