// PhysVal.cpp : implementation file
//

#include "stdafx.h"
#include "scandat.h"
#include "PhysVal.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPhysVal dialog


CPhysVal::CPhysVal(CWnd* pParent /*=NULL*/)
	: CDialog(CPhysVal::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPhysVal)
	dValue = 0.0;
	//}}AFX_DATA_INIT
}


void CPhysVal::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPhysVal)
	DDX_Text(pDX, IDC_EDIT_PHYS_VAL, dValue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPhysVal, CDialog)
	//{{AFX_MSG_MAP(CPhysVal)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhysVal message handlers
