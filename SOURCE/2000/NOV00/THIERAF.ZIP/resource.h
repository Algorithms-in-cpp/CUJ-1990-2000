//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by scandat.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SCANDATYPE                  129
#define IDD_PHYS_VAL                    130
#define IDD_EDIT_DEFINITIONS            131
#define IDC_EDIT_PHYS_VAL               1000
#define IDC_EDIT_X1X                    1001
#define IDC_EDIT_X1Y                    1002
#define IDC_EDIT_X2X                    1003
#define IDC_EDIT_X2Y                    1004
#define IDC_EDIT_Y1X                    1005
#define IDC_EDIT_Y1Y                    1006
#define IDC_EDIT_Y2X                    1007
#define IDC_EDIT_Y2Y                    1008
#define IDC_EDIT_X1V                    1009
#define IDC_EDIT_X2V                    1010
#define IDC_EDIT_Y1V                    1011
#define IDC_EDIT_Y2V                    1012
#define ID_FILE_IMPORT                  32771
#define ID_VIEW_NORMAL                  32772
#define ID_VIEW_ZOOM                    32773
#define ID_EDIT_X1                      32774
#define ID_EDIT_X2                      32775
#define ID_EDIT_Y1                      32776
#define ID_EDIT_Y2                      32777
#define ID_EDIT_EDIT                    32778
#define ID_EDIT_ACQUIRE_DATA            32779
#define ID_OPTIONS_XLOG                 32780
#define ID_OPTIONS_YLOG                 32781
#define ID_OPTIONS_XERR                 32782
#define ID_OPTIONS_YERR                 32783
#define ID_FILE_EXPORT                  32784
#define ID_EDIT_XA                      32785
#define ID_EDIT_XB                      32786
#define ID_EDIT_YA                      32787
#define ID_EDIT_YB                      32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
