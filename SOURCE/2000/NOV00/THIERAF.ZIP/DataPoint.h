// DataPoint.h: interface for the CDataPoint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DataPoint_H__072DA323_903A_11D2_9725_8B2D4AC81B3C__INCLUDED_)
#define AFX_DataPoint_H__072DA323_903A_11D2_9725_8B2D4AC81B3C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif

class CDataPoint : public CObject
{
   DECLARE_SERIAL(CDataPoint)

   public:
	   CDataPoint();
      CDataPoint(CPoint &);
	   virtual ~CDataPoint();
	   void SetPoint (CPoint &point);
	   void SetYErr (CPoint &point);
	   void SetXErr (CPoint &point);
	   CPoint GetYErr();
	   CPoint GetXErr();
	   CPoint GetPoint ();
   	virtual void Serialize (CArchive &ar);

   private:
	   CPoint yerr, xerr, pt;
};

#endif 
