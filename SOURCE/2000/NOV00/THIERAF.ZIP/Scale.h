// Scale.h: interface for the Scale class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCALE_H__94F4E313_5520_11D4_BF93_005004508160__INCLUDED_)
#define AFX_SCALE_H__94F4E313_5520_11D4_BF93_005004508160__INCLUDED_

#include "axis.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Scale  
{
   public:
	   BOOL PointToPhysical (CPoint &DataPoint, double &dPhysX, double &dPhysY);
   	Scale(CAxis &x, CAxis &y);
	   virtual ~Scale();

   private:
	   CAxis &X;
	   CAxis &Y;
};

#endif
