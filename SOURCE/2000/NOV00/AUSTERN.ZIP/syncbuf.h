class syncbuf : public std::streambuf {
public:
   syncbuf(FILE*);

protected:
   virtual int overflow(int c = EOF);
   virtual int underflow();
   virtual int uflow();
   virtual int pbackfail(int c = EOF);
   virtual int sync();

private:
   FILE* fptr;
};

syncbuf::syncbuf(FILE* f)
   : std::streambuf(), fptr(f) {}

int syncbuf::overflow(int c) {
   return c != EOF ? fputc(c, fptr) : EOF;
}

int syncbuf::underflow() {
   int c = getc(fptr);
   if (c != EOF)
      ungetc(c, fptr);
   return c;
}

int syncbuf::uflow() {
   return getc(fptr);
}

int syncbuf::pbackfail(int c) {
   return c != EOF ? ungetc(c, fptr) : EOF;
}

int syncbuf::sync() {
   return fflush(fptr);
}

