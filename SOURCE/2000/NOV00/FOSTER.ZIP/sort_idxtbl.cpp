#include <vector>
#include <algorithm>
#include <iostream>

template <class random_iterator>
class IndexedComparison
{
public:
   IndexedComparison (random_iterator begin,
                      random_iterator end)
      : p_begin (begin), p_end (end) {}
   bool operator () (unsigned int a, unsigned int b) const
   { return *(p_begin + a) < *(p_begin + b); }

private:
   random_iterator const p_begin;
   random_iterator const p_end;
};

// Setup and reporting code below by Craig Hicks

int main()
{
   unsigned int i;
   int ai[10] = { 15,12,13,14,18,11,10,17,16,19 };

   std::cout << "#################" << std::endl;
   std::vector<int> vecai(ai, ai+10);

   std::vector<unsigned int> indices(vecai.size ());
   for (i = 0; i < indices.size (); i++)
      indices [i] = i;

   std::sort (indices.begin (), indices.end (),
              IndexedComparison<std::vector<int>::const_iterator>
                 (vecai.begin (), vecai.end ()));

   for (i=0; i<10; i++)
      std::cout << "i=" << i
                << ", aidxtbl[i]=" << indices[i]
                << ", ai[aidxtbl[i]]=" << ai[indices[i]]
                << std::endl;
   std::cout << "#################" << std::endl;
   return 0;
}



