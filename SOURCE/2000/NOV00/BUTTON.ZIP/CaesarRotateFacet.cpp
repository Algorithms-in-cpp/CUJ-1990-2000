#include "CaesarRotateFacet.h"

CaesarRotateCvt::CaesarRotateCvt( std::size_t refs )
  : std::codecvt<char, char, std::mbstate_t>( refs )
{
}

CaesarRotateCvt::~CaesarRotateCvt( )
{
}

std::codecvt_base::result 
CaesarRotateCvt::do_unshift( std::mbstate_t & state,
													   char * to,
													   char * to_limit,
													   char *& to_next ) const
{
	return std::codecvt_base::ok;
}

int CaesarRotateCvt::do_max_length( ) const 
{
	return 1;
}

int CaesarRotateCvt::do_length( const std::mbstate_t & state,
                                const char * from,
                                const char * from_end,
                                std::size_t max ) const
{
	return ( max < ( from_end - from ) ? max : ( from_end - from ));
}

int CaesarRotateCvt::do_encoding( ) const
{
	return 1;
}

bool CaesarRotateCvt::do_always_noconv( ) const
{
	return false;
}

std::codecvt_base::result
CaesarRotateCvt::do_in( std::mbstate_t & state,
                        const char * from,
                        const char * from_end,
                        const char *& from_next,
                        char * to,
                        char * to_limit,
                        char *& to_next ) const
{
  return do_out( state, from, from_end, from_next, to, to_limit, to_next );
}

std::codecvt_base::result
CaesarRotateCvt::do_out( std::mbstate_t & state,
                         const char * from,
                         const char * from_end,
                         const char *& from_next,
                         char * to,
                         char * to_limit,
                         char *& to_next ) const
{
	std::locale classic( "C" );
	const std::ctype<char> & fac = std::use_facet<std::ctype<char> >( classic );
	
	int len = length( state, from, from_end, to_limit - to );
	for( int i = 0; i < len; i++ )
	{
		if( fac.is( std::ctype_base::alpha, from[ i ] ))
		{
			if( fac.is( std::ctype_base::upper, from[ i ] ))
			{
				to[ i ] = (( from[ i ] - 'A' + 13 ) % 26 ) + 'A';
			}
			else
			{
				to[ i ] = (( from[ i ] - 'a' + 13 ) % 26 ) + 'a';
			}
		}
		else
		{
			to[ i ] = from[ i ];
		}
	}

	from_next = from + len + 1;
	to_next = to + len + 1;

	return std::codecvt_base::ok;
}
