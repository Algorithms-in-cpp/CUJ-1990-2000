#ifndef CAESAR_ROTATE_FACET_H
#define CAESAR_ROTATE_FACET_H

#include  <locale>
#include  <cstddef>

class CaesarRotateCvt : public std::codecvt<char, char, std::mbstate_t>
{
  public:
    explicit CaesarRotateCvt( std::size_t refs = 0 );

  protected:
    virtual ~CaesarRotateCvt( );

    virtual std::codecvt_base::result do_in( std::mbstate_t & state,
                                             const char * from,
                                             const char * from_end, 
                                             const char *& from_next,
                                             char * to, 
                                             char * to_limit, 
                                             char *& to_next ) const;
    
    virtual std::codecvt_base::result do_out( std::mbstate_t & state,
                                              const char * from,
                                              const char * from_end,
                                              const char *& from_next,
                                              char * to,
                                              char * to_limit,
                                              char *& to_next ) const;
    
    virtual std::codecvt_base::result do_unshift( std::mbstate_t & state,
                                                  char * to,
                                                  char * to_limit,
                                                  char *& to_next ) const;

    virtual int do_encoding( ) const throw( );

    virtual bool do_always_noconv( ) const throw( );

    virtual int do_length( const std::mbstate_t &,
                           const char * from,
                           const char * end,
                           std::size_t max ) const;

    virtual int do_max_length( ) const throw( );
};

#endif
