#include	"CaesarRotateFacet.h"

#include  <locale>
#include  <iostream>
#include  <fstream>

int main( int, char ** argv )
{
  CaesarRotateCvt * c = new CaesarRotateCvt( 0 );
  std::locale caesarRotate( std::cout.getloc( ), c );
  std::cout.imbue( caesarRotate );
  	
  std::basic_ifstream<char> ifs( argv[ 1 ] );
  ifs >> std::cout.rdbuf( );
  std::cout.flush( ); 
  	
  return 0;
}
