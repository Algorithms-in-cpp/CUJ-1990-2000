import java.io.*;

class NumberLines2
{
    public static void main(String[] args)
        throws IOException
    {
        LineNumberReader fin =
            new LineNumberReader(
                new InputStreamReader(
                    System.in
                    )
                );

        String line;
        while ((line = fin.readLine()) != null)
            System.out.println(fin.getLineNumber() +
                               "\t" + line);

        fin.close();
    }
}

/* Output from "java NumberLines2 < log1.txt":
1          line 1,1
2          line 1,2
3          line 1,3
*/

