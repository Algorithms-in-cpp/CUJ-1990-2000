import java.io.*;

class ParseClassNames
{
    public static void main(String[] args)
        throws IOException
    {
        // Read Standard Input:
        StreamTokenizer in =
            new StreamTokenizer(
                new InputStreamReader(System.in)
                );

        in.slashSlashComments(true);
        in.slashStarComments(true);

        while (in.nextToken() !=
                   StreamTokenizer.TT_EOF)
            if (in.ttype == StreamTokenizer.TT_WORD &&
                in.sval.equals("class"))
            {
                // Attempt to read class name:
                if (in.nextToken() ==
                        StreamTokenizer.TT_EOF)
                {
                    System.err.println("Unexpected EOF");
                    System.exit(1);
                }
                else if (in.ttype !=
                             StreamTokenizer.TT_WORD)
                {
                    System.err.println(
                        "Syntax error in line " +
                        in.lineno()
                        );
                    System.exit(1);
                }
                else
                    System.out.println("Found class " +
                                       in.sval);
            }
    }
}

/* Output from processing SerializationTest.java:
Found class Name
Found class CarbonUnit
Found class Person
Found class SerializationTest
*/

