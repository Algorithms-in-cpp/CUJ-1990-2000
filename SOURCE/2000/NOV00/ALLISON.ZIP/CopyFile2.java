import java.io.*;

class CopyFile2
{
    public static void main(String[] args)
        throws IOException
    {
        InputStream fin = System.in;
        if (args.length > 0)
            fin = new FileInputStream(args[0]);
        OutputStream fout = System.out;
        if (args.length > 1)
            fout = new FileOutputStream(args[1]);

        int b;
        while ((b = fin.read()) != -1)
            fout.write(b);

        fin.close();
        fout.close();
    }
}

