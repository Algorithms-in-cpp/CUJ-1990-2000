import java.io.*;

class NumberLines
{
    public static void main(String[] args)
        throws IOException
    {
        BufferedReader fin =
            new BufferedReader(
                new InputStreamReader(
                    System.in
                    )
                );

        int lineno = 0;
        String line;
        while ((line = fin.readLine()) != null)
            System.out.println(++lineno + "\t"
                               +line);

        fin.close();
    }
}

/* Output from "java NumberLines < log1.txt":
1      line 1,1
2      line 1,2
3      line 1,3
*/

