/*
----------------------------------------------
Copyright (c) 2000 by Early Ehlinger

Permission is granted to use this code without 
restriction as long as this copyright notice 
appears in all source files.
----------------------------------------------
This module implements the classes used by the
sample program.
*/
#include <factory_dll.h>
#include "../engine/engine.h" // for operation, stack, and FACTORY_PREFIX

#define stack calculator_stack

class plus : public operation
  {
  public:
    virtual int operate( stack* p_stack )
      {
      int _l = p_stack->pop( );
      int _r = p_stack->pop( );
      int _result = _l + _r;
      p_stack->push( _result );
      return _result;
      }
    virtual void destroy( ) { delete this; }
  };
FACTORY_ENTRY( plus , plus )
FACTORY_ENTRY( plus , add ) // Create an alias for class plus.

class minus : public operation
  {
  public:
    virtual int operate( stack* p_stack )
      {
      int _l = p_stack->pop( );
      int _r = p_stack->pop( );
      int _result = _l - _r;
      p_stack->push( _result );
      return _result;
      }
    virtual void destroy( ) { delete this; }
  };
FACTORY_ENTRY( minus , minus )

class pop : public operation
  {
  public:
    virtual int operate( stack* p_stack )
      {
      return p_stack->pop( );
      }
    virtual void destroy( ) { delete this; }
  };
FACTORY_ENTRY( pop , pop )
FACTORY_ENTRY( pop , discard ) // create an alias for class pop

class top : public operation
  {
  public:
    virtual int operate( stack* p_stack )
      {
      return p_stack->top( );
      }
    virtual void destroy( ) { delete this; }
  };
FACTORY_ENTRY( top , top  )
FACTORY_ENTRY( top , peek ) // create an alias for class top

class multiply : public operation
  {
  public:
    virtual int operate( stack* p_stack )
      {
      int _l = p_stack->pop( );
      int _r = p_stack->pop( );
      int _result = _l * _r;
      p_stack->push( _result );
      return _result;
      }
    virtual void destroy( ) { delete this; }
  };
FACTORY_ENTRY( multiply , multiply ) 
FACTORY_ENTRY( multiply , mult ) // create an alias for class multiply

class size : public operation
  {
  public:
    virtual int operate( stack* p_stack )
      {
      return p_stack->size( );
      }
    virtual void destroy( ) { delete this; }
  };
FACTORY_ENTRY( size , size )
