/*
engine.cpp
----------------------------------------------
Copyright (c) 2000 by Early Ehlinger

Permission is granted to use this code without 
restriction as long as this copyright notice 
appears in all source files.
----------------------------------------------
This module implements a simple program
that shows how to use the class factory 
described in the article.  Basically, it 
provides a simple stack-based calculator.
Each line received from cin is checked to
see if it is an operation.  If it is, then the
appropriate operation is instantiated via the
class factory and executed.  If it is not, the
line is converted into an integer and pushed
onto the stack.  If the line cannot be converted,
0 is pushed onto the stack.

This is not a "production" program - there is
little to no error checking.  Rather, it is
intended to illustrate how simple and
maintainable class-factory based code can be.
Adding new operations is a simple matter of
opening dll.cpp (located in ../dll/), and
adding a short class that implements the 
operation.  There is no need to modify engine
at all to accomplish this goal.  In fact, it
is just as simple a task to remove operations
or to provide aliases for an operation; just 
open ../dll/dll.cpp, and add or remove the 
appropriate class or FACTORY_ENTRY macro
invocation.

On dlsym-based platforms, this program expects
a DLL named ./dll to exist.  On Win32 platforms,
this program expects a DLL named dll.dll to exist
in the startup directory.  Aside from this
exception, this module relies on <dllwrap.h> 
to encapsulate all platform-specific code.
*/
#include <factory.h>
#include "engine.h"

#include <iostream>
#include <string>
#include <stack>
using namespace std;

#ifdef _WIN32
  string const factory_dll( "dll.dll" );
#elif defined( _DLSYM )
  const factory_dll( "./dll" );
#else
  #error Unsupported Platform.  Please port me
#endif

class stackimpl : public calculator_stack
  {
  public:
    virtual void push( int i ) { m_data.push( i ); }
    virtual int pop( )
      {
      if ( m_data.size() )
        {
        int _i = top( );
        m_data.pop( );
        return _i;
        }
      return 0;
      } // pop( )
    virtual int top( ) 
      { 
      if ( m_data.size() ) 
        return m_data.top( ); 
      else 
        return 0;
      } // top( )
    virtual int size( ) { return m_data.size(); }
  private:
    stack< int > m_data;
  }; // stackimpl

typedef factory< operation > op_factory;


int main( int , char** )
  {
  stackimpl    _numbers;
  string       _line;
  op_factory   _factory( factory_dll , STRING( FACTORY_PREFIX ) );
 
  while( 1 )
    {
    cin >> _line;
    if ( _line == "bye" )
      break;
    if ( _factory.class_exists( _line ) )
      {
      op_factory::object_ptr _object( _factory.instantiate( _line ) );
      cout << _object->operate( &_numbers ) << endl;
      }
    else
      {
      int _number = atoi( _line.c_str() );
      _numbers.push( _number );
      }
    }

  return 0;  
  }
