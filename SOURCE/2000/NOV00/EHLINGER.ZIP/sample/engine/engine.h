/*
engine.h
----------------------------------------------
Copyright (c) 2000 by Early Ehlinger

Permission is granted to use this code without 
restriction as long as this copyright notice 
appears in all source files.
----------------------------------------------
This header is the interface between the 
engine program (./engine.cpp) and the classes 
in the DLL (../dll/dll.cpp).
*/

#ifndef _ENGINE_H_
#define _ENGINE_H_

template<class object> class dll_object_ref;

class calculator_stack
  {
  public:
    virtual void push( int ) = 0;
    virtual int pop( ) = 0;
    virtual int top( ) = 0;
    virtual int size( ) = 0;
  }; // calculator_stack

class operation
  {
  public:
    virtual int operate( calculator_stack* p_stack ) = 0;
  private:
    friend class dll_object_ref< operation >;
    virtual void destroy( ) = 0;
  }; // operation

#define FACTORY_PREFIX op_
#define FACTORY_PREFIX_STR STRING( FACTORY_PREFIX )
#define FACTORY_ENTRY( class , alias ) FACTORYFUNC( operation , class , op_ , alias )

#define STRING( x ) _STRING( x )
#define _STRING( x ) #x

#endif
