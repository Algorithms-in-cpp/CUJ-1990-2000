/*
factory_dll.h
----------------------------------------------
Copyright (c) 2000 by Early Ehlinger

Permission is granted to use this code without 
restriction as long as this copyright notice 
appears in all source files.
----------------------------------------------
This header provides some macros that make it
easy to implement a class library that can be
used with a class factory.
*/
#ifndef _FACTORY_H_
#define _FACTORY_H_

/*
DLLFUNC
Tells the compiler to export a function
on _WIN32 platform.
*/
#ifdef _WIN32
  #define DLLFUNC __declspec( dllexport )
#elif defined( _GNU_C )
  #define DLLFUNC
#else
  #error Unsupported Platform.  Please port me.
#endif

/*
DLLCALL
Tells the compiler which "calling convention"
to use.
*/
#ifdef _WIN32
  #define DLLCALL __stdcall
#elif defined( _GNU_C )
  #define DLLCALL
#else
  #error Unsupported Platform.  Please port me.
#endif

#define EXTERNC extern "C"

/*
FACTORYFUNC
 Creates an entry in the DLL function export table
 for a factory-compatible class instantiation routine.

Parameters:
 * base      - type of class the factory expects.
 * the_class - type of class the classid corresponds to.
 * prefix    - function name prefix.  Can be used to allow
               multiple factories access to the same DLL.
 * classid   - class identifier.
*/
#define FACTORYFUNC( base , the_class , prefix , classid ) \
  EXTERNC DLLFUNC base* DLLCALL prefix##classid( void )    \
    { return new the_class; } 

#endif

