/*
factory.h
----------------------------------------------
Copyright (c) 2000 by Early Ehlinger

Permission is granted to use this code without 
restriction as long as this copyright notice 
appears in all source files.
----------------------------------------------
This module contains an implementation of 
factory<object>, which is a DLL-based class 
factory.
*/
#ifndef _FACTORY_H_
#define _FACTORY_H_

#include "dllwrap.h"

template
<class object>
class factory
  {
  public:
    typedef dll_object_ptr< object > object_ptr;

    factory
      ( std::string const& dll_name 
      , std::string const& prefix = "instantiate_" )
      : m_dll( dll_name )
      , m_prefix( prefix )
      { }

    object_ptr instantiate( std::string const& class_name )
      {
      return object_ptr( m_dll , decorate( class_name ) );
      }

    bool class_exists( std::string const& class_name )
      { 
      return m_dll.func_exists( decorate( class_name ) );
      }

  private:

    std::string decorate( std::string const& class_name )
      {
      #ifdef _WIN32
        return "_" + m_prefix + class_name + "@0";
      #elif defined( _DLSYM )
        return m_prefix + class_name;
      #else
        #error Unsupported Platform.  Please port me
      #endif
      }

  private:
    dll_sentinel m_dll;
    std::string m_prefix;
  };


#endif
