/*
dllwrap.h
----------------------------------------------
Copyright (c) 2000 by Early Ehlinger

Permission is granted to use this code without 
restriction as long as this copyright notice 
appears in all source files.
----------------------------------------------
This module provides rudimentary wrapping of
DLL client code.  It handles the loading and 
unloading of DLLs and finding functions in
those DLLs.  Further support is provided to
make using C++ objects from a DLL easier, by
providing classes that guarantee the DLL is
kept in memory until all instances of a class
are destroyed.
*/
#ifndef _dllwrap_h_
#define _dllwrap_h_

// include necessary function definitions
#ifdef _WIN32
  #include <windows.h>
#elif defined( _DLSYM )
  // dlsym-based API.  Most Unix variants, with the 
  // notable exception of HP-UX, provide a dlsym-based API.
  #include <dlfcn.h>
#else
  #error Unsupported platform.  Please port me.
#endif

#include <exception>
#include <string>
#include <assert.h>

template
< class object >
class dll_object_ptr;

class dll_exception : public std::exception
  {
  public:
    dll_exception( char const* msg )
      : m_msg( msg )
      { }
    virtual char const* what( ) const
      { return m_msg; }
  private:
    char const* m_msg;
  }; // dll_exception

class dll_sentinel
  {
  public:
    dll_sentinel( std::string const& dll_name )
      : m_dll_name( dll_name )
      , m_instance( NULL )
      { init( ); }

    dll_sentinel( dll_sentinel const& source )
      : m_dll_name( source.m_dll_name )
      , m_instance( NULL )
      { init( ); }

    virtual ~dll_sentinel( )
      { reset( ); }

    void reset( )
      {
      if ( m_instance )
        {
        #ifdef _WIN32
          FreeLibrary( m_instance );
        #elif defined( _DLSYM )
          dlclose( m_instance );
        #else
          #error Unsupported Platform.  Please port me
        #endif

        m_instance = NULL;
        m_dll_name = std::string( );
        }
      } // reset( )

    void* find_func( std::string const& name ) const
      {
      assert( m_instance );

      #ifdef _WIN32
        FARPROC _result = GetProcAddress
          ( m_instance 
          , name.c_str() );
      #elif defined( _DLSYM )
        void* _result = dlsym
          ( m_instance
          , name.c_str() );
      #else
        #error Unsupported Platform.  Please port me
      #endif

      return reinterpret_cast<void*>( _result );

      } // find_func( std::string const& )

    bool func_exists( std::string const& name ) const
      {
      assert( m_instance );
      #ifdef _WIN32
        FARPROC _result = GetProcAddress
          ( m_instance 
          , name.c_str() );
      #elif defined( _DLSYM )
        void* _result = dlsym
          ( m_instance
          , name.c_str() );
      #else
        #error Unsupported Platform.  Please port me
      #endif

      return _result ? true : false;
      }

    bool is_open( )
      {
      return m_instance ? true : false;
      }

  private: // interface
    void init( )
      {
      #ifdef _WIN32
        m_instance = LoadLibrary( m_dll_name.c_str() );
      #elif defined( _DLSYM )
        m_instance = dlopen( m_dll_name.c_str() , RTLD_NOW );
      #else
        #error Unsupported Platform.  Please port me
      #endif

      if ( !m_instance ) 
        throw dll_exception( "DLL Not Found" );
      } // init( )

  private: // data
    std::string m_dll_name;
    #ifdef _WIN32
      HMODULE m_instance;
    #elif defined( _DLSYM )
      void*   m_instance;
    #else
      #error Unsupported Platform.  Please port me
    #endif

  }; // class dll_sentinel

template
< class object >
class dll_object_ref
  {
    friend class dll_object_ptr< object >;
    inline bool invariant( )
      {
      assert( m_dll.is_open() );
      assert( m_obj );
      return true;
      }

  private:

    dll_object_ref
      ( dll_sentinel&      dll
      , std::string const& function_name )
      : m_dll( dll )
      , m_count( 1 )
      , m_obj( NULL )
      {
      #ifdef _WIN32
        typedef object* (WINAPI* p_instantiate)( );
      #elif defined( _DLSYM )
        typedef object* (* p_instantiate)( );
      #else
        #error Unsupported Platform.  Please port me
      #endif

      void* _pvfunc = m_dll.find_func( function_name );
      if ( !_pvfunc )
        throw dll_exception( "Could not find instantiation routine." );

      p_instantiate _pfunc = *reinterpret_cast<p_instantiate*>( &_pvfunc );
      m_obj = _pfunc( );

      assert( invariant() );
      } // dll_object_ref( std::string const& , std::string const& )

    virtual ~dll_object_ref( )
      {
      assert( invariant() );
      m_obj->destroy();
      m_obj = NULL;
      } // ~dll_object_ref( )

    // ref gives the caller partial ownership of this.
    dll_object_ref* ref( )
      {
      ++m_count;
      return this;
      } // ref( )

    // Note: Whether delete this is defined or not
    // has been a much-debated fact on the newsgroups.
    // Marshal Cline's C++ FAQ, at 
    // http://www.awtechnologies.com/bytes/c++/faq-lite/
    // indicates that it's valid, given some caveats that
    // we adhere to in this code.
    void unref( )
      {
      if (0==--m_count)
        delete this; 
        // after deleting this, *this does not
        // exist.  DO NOT ACCESS ANY MEMBERS
        // FROM HERE ON IN.
      } // unref( )

  private: // data

    dll_sentinel  m_dll;
    object*       m_obj;
    unsigned long m_count;

  }; // class dll_object_ref< >

template
< class object >
class dll_object_ptr
  {
    typedef dll_object_ref< object > ref_type;
  public:
    dll_object_ptr( )
      : m_obj( NULL )
      { }

    dll_object_ptr( dll_object_ptr const& copy )
      : m_obj( copy.m_obj->ref( ) )
      { }

    dll_object_ptr
      ( dll_sentinel&      dll
      , std::string const& func_name )
      : m_obj( new ref_type( dll , func_name ) )
      { }

    // release( ) symantics are ever-so-slightly different
    // from those provided by std::auto_ptr<>.  std::auto_ptr<>'s
    // release will return the actual pointer to the object and
    // set its copy to NULL.
    //
    // dll_object_ptr<>'s release will effectively return a copy of
    // itself.
    //
    // In both cases, release causes the x_ptr object to lose
    // ownership of the current object, while leaving the current
    // object in existence.  However, dll_object_ptr<>'s release
    // maintains the guarantee that the referenced object will
    // eventually be deleted, by returning a new object that has
    // partial ownership of the object.
    dll_object_ptr release( )
      {
      dll_object_ptr _result( *this );
      reset( );
      return _result;
      } // release( );

    // Unlike std::auto_ptr<>, reset( ) is split into two 
    // overloaded versions in dll_object_ptr<>.  This is because
    // std::auto_ptr<>'s reset is often used for two distinct
    // purposes.  The first is to cause the auto_ptr<> to destroy
    // its object "prematurely"  This is done by calling
    // std::auto_ptr<>::reset( NULL ).  The second is to cause the
    // auto_ptr<> to point to a different object, say p_new.  This
    // is done by calling std::auto_ptr<>::reset( p_new );
    // 
    // dll_object_ptr<> cannot provide this type of interface because
    // the pointed-to object, dll_object_ref, cannot be allocated 
    // by anybody other than a dll_object_ptr<>.  Therefore it is
    // nonsensical to provide a reset function that takes anything
    // besides another dll_object_ptr<>.
    //
    // The side effect is that we lose the ability to say 
    // dll_object_ptr<>::reset( NULL ), so we add the ability to say
    // dll_object_ptr<>::reset( ), instead.
    void reset( dll_object_ptr const& copy )
      { 
      reset( );
      m_obj = copy.m_obj->ref( );
      } // reset( dll_object_ptr const& )

    void reset( )
      {
      if ( m_obj )
        {
        m_obj->unref( );
        m_obj = NULL;
        }
      } // reset( )

    virtual ~dll_object_ptr( )
      { reset( ); }
    
    object* operator->( )
      {
      assert( m_obj );
      return m_obj->m_obj;
      } // operator->( )

    object* get( )
      {
      assert( m_obj );
      return m_obj->m_obj;
      } // get( )

    object& operator*( )
      {
      assert( m_obj );
      return m_obj->m_obj;
      } // operator*( )

  private: // data

    ref_type*    m_obj;

  }; // class dll_object_ptr< >

#endif // _dllwrap_h_
