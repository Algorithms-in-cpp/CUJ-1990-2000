// ContoursDoc.cpp : implementation of the CContoursDoc class
//

#include "stdafx.h"
#include "math.h"
#include "Contours.h"
#include "ContoursDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContoursDoc

IMPLEMENT_DYNCREATE(CContoursDoc, CDocument)

BEGIN_MESSAGE_MAP(CContoursDoc, CDocument)
	//{{AFX_MSG_MAP(CContoursDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContoursDoc construction/destruction

CContoursDoc::CContoursDoc()
{
	// TODO: add one-time construction code here
}

CContoursDoc::~CContoursDoc()
{
}

BOOL CContoursDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CContoursDoc serialization

void CContoursDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CContoursDoc diagnostics

#ifdef _DEBUG
void CContoursDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CContoursDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CContoursDoc commands

void CContoursDoc::CreateTextureObjet()
{
	// Define texture image
	unsigned char Texture8[8][3] =
	{
		{ 0x00, 0x00, 0xa0 },	// Dark Blue 
		{ 0x00, 0x00, 0xff },	// Blue 
		{ 0x00, 0xa0, 0xff },	// Indigo 
		{ 0x00, 0xa0, 0x40 },	// Dark Green 
		{ 0x00, 0xff, 0x00 },	// Green 
		{ 0xff, 0xff, 0x00 },	// Yellow 
		{ 0xff, 0xcc, 0x00 },	// Orange 
		{ 0xff, 0x00, 0x00 }	// Red 
	};

	// Set pixel storage mode 
	::glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	// Generate a texture name
	::glGenTextures(1, m_nTexName);

	// Create a texture object
	::glBindTexture(GL_TEXTURE_1D, m_nTexName[0]);
	::glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER,
		GL_NEAREST);
	::glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER,
		GL_NEAREST);
	::glTexImage1D(GL_TEXTURE_1D, 0, 3, 8, 0, GL_RGB, 
		GL_UNSIGNED_BYTE, Texture8);
}

void CContoursDoc::CreateTriangleList(UINT nList)
{
	::glNewList(nList, GL_COMPILE);
	::glNormal3f(0.0f, 0.0f, 1.0f);

	::glBegin(GL_TRIANGLES); 
		::glTexCoord1f(0.1f);
		::glVertex3d(-1, -1, 0);
		::glTexCoord1f(0.7f);
		::glVertex3d(-1, 1, 0);
		::glTexCoord1f(1.0f);
		::glVertex3d( 1, 0.8, 0);
	::glEnd();
	::glEndList();
}

void CContoursDoc::CreateGraph3DList(UINT nList)
{
	::glNewList(nList , GL_COMPILE);
	for(int nX(0); nX < m_aSurfaceNormal.GetSize(); nX++)
	{
		float fx = (nX*m_fStep - 1)*m_fWidth;
		::glBegin(GL_TRIANGLE_STRIP); 
		for(int nY(0); nY < m_aSurfaceNormal.GetSize(); nY++) 
		{
			float fNormal[3];
			m_aVertexNormal[nX][nY].GetVector(fNormal);
			::glNormal3fv(fNormal);
			float fy = (nY*m_fStep - 1)*m_fWidth;
			float fz = GetZ(fx, fy);
			::glTexCoord1f((fz+1)/2);
			::glVertex3d(fx, fy, fz/2);

			m_aVertexNormal[nX+1][nY].GetVector(fNormal);
			::glNormal3fv(fNormal);
			float fx2 = fx+m_fStep;
			fz = GetZ(fx2, fy);
			::glTexCoord1f((fz+1)/2);
			::glVertex3d(fx2, fy, fz/2);
		}
		::glEnd();
	}
	::glEndList();
}

void CContoursDoc::Generate3DData()
{
	m_fWidth = 1.0f;
	m_fStep = 0.05f;
	int nSurface = 2*Round(m_fWidth/m_fStep);
	int nVertex = nSurface + 1;

	m_aSurfaceNormal.SetSize(nSurface);
	for (int nSur(0); nSur<nSurface; nSur++)
		m_aSurfaceNormal[nSur].SetSize(nSurface);

	m_aVertexNormal.SetSize(nVertex);
	for (int nVer(0); nVer<nVertex; nVer++)
		m_aVertexNormal[nVer].SetSize(nVertex);
	
	// Vertex coordinates
	for(int nX(0); nX < m_aVertexNormal.GetSize(); nX ++)
		for(int nY(0); nY < m_aVertexNormal.GetSize(); nY ++) 
		{
			float fx = (nX*m_fStep - 1)*m_fWidth;
			float fy = (nY*m_fStep - 1)*m_fWidth;
			m_aVertexNormal[nX][nY] = C3DVector(fx, fy, GetZ(fx, fy));;
		}
	
	// Surface Normal
	for(nX = 0; nX < m_aSurfaceNormal.GetSize(); nX ++)
		for(int nY(0); nY < m_aSurfaceNormal.GetSize(); nY ++) 
			CalculateNormal(m_aVertexNormal[nX][nY], m_aVertexNormal[nX+1][nY],
				m_aVertexNormal[nX+1][nY+1], m_aSurfaceNormal[nX][nY]);
	
	// Vertex Normal
	for(nX = 0; nX < m_aSurfaceNormal.GetSize(); nX ++)
		for(int nY(0); nY < m_aSurfaceNormal.GetSize(); nY ++) 
		{
			m_aVertexNormal[nX][nY] += m_aSurfaceNormal[nX][nY];
			m_aVertexNormal[nX+1][nY] += m_aSurfaceNormal[nX][nY];
			m_aVertexNormal[nX][nY+1] += m_aSurfaceNormal[nX][nY];
			m_aVertexNormal[nX+1][nY+1] += m_aSurfaceNormal[nX][nY];
		}
	for(nX = 0; nX < m_aVertexNormal.GetSize(); nX ++)
		for(int nY(0); nY < m_aVertexNormal.GetSize(); nY ++) 
			m_aVertexNormal[nX][nY].Average();
}

float CContoursDoc::GetZ(float x, float y)
{
	return float(sin(3*x)*cos(3*y));
}

BOOL CContoursDoc::CalculateNormal(C3DVector& fPoint1, C3DVector& fPoint2, C3DVector& fPoint3, C3DVector& fNormal)
{
	float fx = (fPoint2.GetY()-fPoint1.GetY())*(fPoint3.GetZ()-fPoint2.GetZ())-
		(fPoint3.GetY()-fPoint2.GetY())*(fPoint2.GetZ()-fPoint1.GetZ());
	
	float fy = (fPoint3.GetX()-fPoint2.GetX())*(fPoint2.GetZ()-fPoint1.GetZ())-
		(fPoint2.GetX()-fPoint1.GetX())*(fPoint3.GetZ()-fPoint2.GetZ());
	
	float fz = (fPoint2.GetX()-fPoint1.GetX())*(fPoint3.GetY()-fPoint2.GetY())-
		(fPoint3.GetX()-fPoint2.GetX())*(fPoint2.GetY()-fPoint1.GetY());
	
	float fd = (float) sqrt(fx*fx + fy*fy + fz*fz);

	fNormal.SetVector(fx/fd, fy/fd, fz/fd);

	return TRUE;
}

