// ContoursDoc.h : interface of the CContoursDoc class
//

#if !defined(AFX_CONTOURSDOC_H__C3D7976_DF2C_11D3_85EC_2930B0CE__INCLUDED_)
#define AFX_CONTOURSDOC_H__C3D7976_DF2C_11D3_85EC_2930B0CE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "3DVector.h"
			  
class CContoursView;

class CContoursDoc : public CDocument
{
protected: // create from serialization only
	CContoursDoc();
	DECLARE_DYNCREATE(CContoursDoc)

// Attributes
public:

// Operations
public:

	float m_fWidth; // Width of graph
	float m_fStep;

	typedef	CArray<C3DVector, C3DVector> a3DVector;
	CArray<a3DVector, a3DVector> m_aVertexNormal;
	CArray<a3DVector, a3DVector> m_aSurfaceNormal;
	CArray<a3DVector, a3DVector> m_aVertexCoord;

	GLuint m_nTexName[1];
	void CreateTextureObjet();
	void CreateTriangleList(UINT nList);
	void CreateGraph3DList(UINT nList);
	void Generate3DData();

	BOOL CalculateNormal(C3DVector& fPoint1, C3DVector& fPoint2, C3DVector& fPoint3, C3DVector& fNormal);
	float GetZ(float x, float y);
	inline int Round(float f) { return int(f + 0.5f); }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContoursDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CContoursDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CContoursDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif