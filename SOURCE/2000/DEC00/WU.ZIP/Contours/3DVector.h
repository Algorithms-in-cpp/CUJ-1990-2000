#ifndef AFX_C3DVECTOR_H__35D2A504_96F51D3_969E_0000C0E26D57__INCLUDED_
#define AFX_C3DVECTOR_H__35D2A504_96F51D3_969E_0000C0E26D57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// 3DVector.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// C3DVector command target

class C3DVector : public CCmdTarget
{
	DECLARE_DYNCREATE(C3DVector)

	C3DVector();   
	C3DVector(float fX, float fY, float fZ);
// Attributes
public:

// Operations
public:
	void SetVector(float fX, float fY, float fZ);
	void GetVector(float* fNormal);

	void Average();

	C3DVector& operator = (const C3DVector& Vec);
	C3DVector& operator += (const C3DVector& Vec);

	float GetX() { return m_fX; };
	float GetY() { return m_fY; };
	float GetZ() { return m_fZ; };

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(C3DVector)
	//}}AFX_VIRTUAL

// Implementation
	virtual ~C3DVector();

	// Generated message map functions
	//{{AFX_MSG(C3DVector)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	float m_fX;
	float m_fY;
	float m_fZ;
	int m_nCount;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_C3DVECTOR_H__35D2A504_96F51D3_969E_0000C0E26D57__INCLUDED_)
