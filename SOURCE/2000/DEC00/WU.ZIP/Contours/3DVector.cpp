// 3DVector.cpp : implementation file
//

#include "stdafx.h"
#include "3DVector.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// C3DVector

IMPLEMENT_DYNCREATE(C3DVector, CCmdTarget)

C3DVector::C3DVector()
{
	m_nCount = 0;
}

C3DVector::C3DVector(float fX, float fY, float fZ)
{
	m_fX = fX;
	m_fY = fY;
	m_fZ = fZ;
	m_nCount = 0;
}

C3DVector::~C3DVector()
{
}


BEGIN_MESSAGE_MAP(C3DVector, CCmdTarget)
	//{{AFX_MSG_MAP(C3DVector)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// C3DVector message handlers

void C3DVector::SetVector(float fX, float fY, float fZ)
{
	m_fX = fX;
	m_fY = fY;
	m_fZ = fZ;
}

void C3DVector::GetVector(float* fNormal)
{
	*fNormal = m_fX;
	*(fNormal + 1) = m_fY;
	*(fNormal + 2) = m_fZ;
}

C3DVector& C3DVector::operator = (const C3DVector& Vec)
{
	m_fX = Vec.m_fX;
	m_fY = Vec.m_fY;
	m_fZ = Vec.m_fZ;

	return *this;
}

C3DVector& C3DVector::operator += (const C3DVector& Vec)
{
	m_fX += Vec.m_fX;
	m_fY += Vec.m_fY;
	m_fZ += Vec.m_fZ;

	m_nCount++;

	return *this;
}

void C3DVector::Average()
{
	if(m_nCount > 0)
	{
		m_fX /= m_nCount;
		m_fY /= m_nCount;
		m_fZ /= m_nCount;
	}
}
