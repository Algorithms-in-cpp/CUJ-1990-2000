// ContoursView.cpp : implementation of the CContoursView class
//

#include "stdafx.h"
#include "math.h"
#include "Contours.h"
#include "ContoursDoc.h"
#include "ContoursView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CContoursView

IMPLEMENT_DYNCREATE(CContoursView, CView)

BEGIN_MESSAGE_MAP(CContoursView, CView)
	//{{AFX_MSG_MAP(CContoursView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, OnFilePrintPreview)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_DEMO_LINE, OnLine)
	ON_COMMAND(ID_DEMO_FILL, OnFill)
	ON_COMMAND(ID_DEMO_ANIMATION, OnAnimation)
	ON_UPDATE_COMMAND_UI(ID_DEMO_LINE, OnUpdateLine)
	ON_UPDATE_COMMAND_UI(ID_DEMO_FILL, OnUpdateFill)
	ON_UPDATE_COMMAND_UI(ID_DEMO_ANIMATION, OnUpdateAnimation)
	ON_WM_TIMER()
	ON_COMMAND(ID_DEMO_GRAPH3D, OnGraph3d)
	ON_UPDATE_COMMAND_UI(ID_DEMO_GRAPH3D, OnUpdateGraph3d)
	ON_COMMAND(ID_DEMO_LIGHTING, OnLighting)
	ON_UPDATE_COMMAND_UI(ID_DEMO_LIGHTING, OnUpdateLighting)
	ON_COMMAND(ID_DEMO_LIGHT0, OnLight0)
	ON_UPDATE_COMMAND_UI(ID_DEMO_LIGHT0, OnUpdateLight0)
	ON_COMMAND(ID_DEMO_LIGHT1, OnLight1)
	ON_UPDATE_COMMAND_UI(ID_DEMO_LIGHT1, OnUpdateLight1)
	ON_COMMAND(ID_DEMO_BLEND, OnBlend)
	ON_UPDATE_COMMAND_UI(ID_DEMO_BLEND, OnUpdateBlend)
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_DEMO_TRIANGLE, OnDemoTriangle)
	ON_UPDATE_COMMAND_UI(ID_DEMO_TRIANGLE, OnUpdateDemoTriangle)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContoursView construction/destruction

CContoursView::CContoursView()
{
	m_pDC = NULL;
	m_hRC = NULL;
	m_dFovY = 40.0;
	m_dNearPlane   = 1.0; 
	m_dFarPlane    = 10.0; 
	m_dMaxObjSize  = 5.0; 
	m_eProjection = PROJ_PERSPECTIVE;
	m_dRadius    = m_dNearPlane + m_dMaxObjSize / 2.0; 
	m_xRotate = -20;
	m_yRotate = 0;
	m_zRotate = -135;
	m_bFill = TRUE;
	m_bAnimation = FALSE;
	m_eGraph = TRIANGLE;
}

CContoursView::~CContoursView()
{
}

BOOL CContoursView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
	//  the CREATESTRUCT cs
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CContoursView drawing

void CContoursView::OnDraw(CDC* pDC)
{
	if(m_hRC)
		RenderScene();
}

/////////////////////////////////////////////////////////////////////////////
// CContoursView printing

void CContoursView::OnPrint(CDC* pDC, CPrintInfo* pInfo)
{
	CView::OnPrint(pDC, pInfo);
}


BOOL CContoursView::OnPreparePrinting(CPrintInfo* pInfo)
{	
	return DoPreparePrinting(pInfo);
}

/////////////////////////////////////////////////////////////////////////////
// CContoursView diagnostics

#ifdef _DEBUG
void CContoursView::AssertValid() const
{
	CView::AssertValid();
}

void CContoursView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CContoursDoc* CContoursView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CContoursDoc)));
	return (CContoursDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CContoursView message handlers

int CContoursView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if(CView::OnCreate(lpCreateStruct) == -1)
		return -1;

    Initialization();	
	
	return 0;
}

void CContoursView::Initialization()
{
	CContoursDoc* pDoc = (CContoursDoc*) GetDocument();
	ASSERT(pDoc);

	PIXELFORMATDESCRIPTOR pfd;

    m_pDC = new CClientDC(this);
    ASSERT(m_pDC != NULL);

    if(!SetupPixelFormat(m_pDC->GetSafeHdc()))
        return;

    int nPixelFormatIndex;
    nPixelFormatIndex = ::GetPixelFormat(::wglGetCurrentDC());
    ::DescribePixelFormat(::wglGetCurrentDC(), 
		nPixelFormatIndex, sizeof(pfd), &pfd);

    m_hRC = ::wglCreateContext(m_pDC->GetSafeHdc()); 
    ::wglMakeCurrent(m_pDC->GetSafeHdc(), m_hRC);  

	::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	::glEnable(GL_DEPTH_TEST);
	::glDrawBuffer(GL_BACK);

	// Setup light 0
	GLfloat  fLightAmbient0[] = { 0.7f, 0.0f, 0.1f, 0.5f };
	GLfloat  fLightDiffuse0[] = { 0.1f, 0.3f, 0.7f, 0.5f };
	GLfloat	 fLightPosition0[] = { 10.0f, 10.0f, 10.0f, 1.0f };
	
	::glLightfv(GL_LIGHT0, GL_AMBIENT, fLightAmbient0);
	::glLightfv(GL_LIGHT0, GL_DIFFUSE, fLightDiffuse0);
	::glLightfv(GL_LIGHT0, GL_POSITION, fLightPosition0);
	
	// Enable light 1
	::glEnable(GL_LIGHT0);

	// Setup light 1
	GLfloat  fLightAmbient1[] = { 0.1f, 0.3f, 0.5f, 0.5f };
	GLfloat  fLightDiffuse1[] = { 0.3f, 0.0f, 0.1f, 0.5f };
	GLfloat	 fLightPosition1[] = { -10.0f, 5.0f, -1.0f, 1.0f };

	::glLightfv(GL_LIGHT1, GL_AMBIENT, fLightAmbient1);
	::glLightfv(GL_LIGHT1, GL_DIFFUSE, fLightDiffuse1);
	::glLightfv(GL_LIGHT1, GL_POSITION, fLightPosition1);

	// Enable light 1
	::glEnable(GL_LIGHT1);

	// Enable lighting
	::glEnable(GL_LIGHTING);

	// Enable 1D texture 
	::glEnable(GL_TEXTURE_1D);
	::glShadeModel(GL_SMOOTH);

	// Setup material
	GLfloat materialSpecular[] = { 0.9f,  0.9f,  0.9f,  0.5f };
	GLfloat materialAmbDiff[] = { 0.6f, 0.6f, 0.6f, 0.5f };
	GLfloat materialShininess[1] = { 20.0f };
	::glMaterialfv( GL_FRONT, GL_SPECULAR, materialSpecular );
	::glMaterialfv( GL_FRONT, GL_AMBIENT_AND_DIFFUSE, 
		materialAmbDiff);
	::glMaterialfv( GL_FRONT, GL_SHININESS, materialShininess);

	// Create texture image
	pDoc->CreateTextureObjet();

	// Generate 3d data.
	pDoc->Generate3DData();

	// Create OpenGL display list.
	pDoc->CreateTriangleList(TRIANGLE);
	pDoc->CreateGraph3DList(GRAPH_3D);

	// Setup alpha blending, which will be enabled later on.
    ::glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	SetTimer(0,10,NULL);
}

void CContoursView::OnDestroy() 
{
	CView::OnDestroy();
	
	m_hRC = ::wglGetCurrentContext();
    ::wglMakeCurrent(NULL,  NULL);
    if(m_hRC)
        ::wglDeleteContext(m_hRC);
    if(m_pDC)
        delete m_pDC;	
}

void CContoursView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	if(cx<=0 || cy<=0)
		return;
	
	ResetView(cx, cy);
}

void CContoursView::ResetView(int nWidth, int nHeight)
{
	// Calculate the aspect ratio of the screen
	if (nHeight > 0)
		m_dAspectDisplay = (GLfloat)nWidth/(GLfloat)nHeight;
	else
		m_dAspectDisplay = (GLfloat)nWidth;

	if(nWidth <= nHeight) 
	{
		m_dLeftPlane   = -m_dNearPlane;
		m_dRightPlane  =  m_dNearPlane;
		m_dBottomPlane = -m_dNearPlane*nHeight/nWidth;
		m_dTopPlane    =  m_dNearPlane*nHeight/nWidth;
	}
	else
	{
		m_dLeftPlane   = -m_dNearPlane*nWidth/nHeight;
		m_dRightPlane  =  m_dNearPlane*nWidth/nHeight;
		m_dBottomPlane = -m_dNearPlane;
		m_dTopPlane    =  m_dNearPlane;
	}

	// Set Viewport to window dimensions
	::glViewport(0, 0, nWidth, nHeight);
	SetProjection(m_eProjection);
}

void CContoursView::SetProjection(int nType)
{
	// Reset the projection matrix.
	::glMatrixMode(GL_PROJECTION);
	::glLoadIdentity();
	switch(nType)
	{
	case PROJ_PERSPECTIVE:
		::gluPerspective(m_dFovY, m_dAspectDisplay, m_dNearPlane, m_dFarPlane); 
		break;
	case PROJ_ORTHO:
		::glOrtho(m_dLeftPlane, m_dRightPlane, m_dBottomPlane, m_dTopPlane, m_dNearPlane, m_dFarPlane);	
		break;
	}

	// Reset the ModelView matrix.
	::glMatrixMode(GL_MODELVIEW);
	::glLoadIdentity();
	InvalidateRect(NULL, FALSE);
}

BOOL CContoursView::SetupPixelFormat(HDC hdc)
{
    static PIXELFORMATDESCRIPTOR pfd =
	{
        sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
        1,                              // version number
        PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER,
		PFD_TYPE_RGBA,                  // RGBA type
        16,                             // 16-bit color depth
        0, 0, 0, 0, 0, 0,               // color bits ignored
        0,                              // no alpha buffer
        0,                              // shift bit ignored
        0,                              // no accumulation buffer
        0, 0, 0, 0,                     // accum bits ignored
        16,                             // 16-bit z-buffer
        0,                              // no stencil buffer
        0,                              // no auxiliary buffer
        PFD_MAIN_PLANE,                 // main layer
        0,                              // reserved
        0, 0, 0                         // layer masks ignored
    };

    int nGLPixelIndex;
    if((nGLPixelIndex = ::ChoosePixelFormat(hdc, &pfd)) == 0)
    {
        TRACE0("ChoosePixelFormat failed");
        return FALSE;
    }
	TRACE("ChoosePixelFormat = %d\n", nGLPixelIndex);

	if(nGLPixelIndex==0) 
	{
		nGLPixelIndex = 1;	
		if(::DescribePixelFormat(hdc, nGLPixelIndex, sizeof(PIXELFORMATDESCRIPTOR), &pfd)==0)
			return FALSE;
	}

    if(::SetPixelFormat(hdc, nGLPixelIndex, &pfd) == FALSE)
    {
		DWORD dwErr = GetLastError();
		TRACE0("SetPixelFormat failed\n");
        return FALSE;
    }

    return TRUE;
}

void CContoursView::RenderScene()
{
	::glClearColor(0.4f, 0.6f, 1.0f, 1.0f);
	::glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    ::glPushMatrix();
    ::glTranslated(0.0, 0.0, -m_dRadius);

	// Rotation
	::glRotated(m_xRotate, 1.0, 0.0, 0.0);
	::glRotated(m_yRotate, 0.0, 1.0, 0.0);
	::glRotated(m_zRotate, 0.0, 0.0, 1.0);

	::glCallList(m_eGraph);

	::glPopMatrix();

    ::glFinish();
    ::SwapBuffers(::wglGetCurrentDC());
}

void CContoursView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView) 
{

	if (!bActivate)
        ::wglMakeCurrent(NULL, NULL);
    else
        ::wglMakeCurrent(m_pDC->GetSafeHdc(), m_hRC);
	
	CView::OnActivateView(bActivate, pActivateView, pDeactiveView);
}

void CContoursView::OnFilePrintPreview() 
{
	// TODO: Add your command handler code here

	CView::OnFilePrintPreview();
}

void CContoursView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if((nFlags & MK_LBUTTON) == TRUE)
	{
		CSize rotate = m_LeftDownPos - point;
		m_LeftDownPos = point;
		m_xRotate -= rotate.cy/4;
		m_zRotate -= rotate.cx/4;
		InvalidateRect(NULL, FALSE);
	}

	CView::OnMouseMove(nFlags, point);
}

void CContoursView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_LeftDownPos = point;
	
	CView::OnLButtonDown(nFlags, point);
}

void CContoursView::OnLine() 
{
	if(m_bFill)
	{
		::glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		m_bFill = FALSE;
		InvalidateRect(NULL, FALSE);
	}
}

void CContoursView::OnFill() 
{
	if(!m_bFill)
	{
		::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		m_bFill = TRUE;
		InvalidateRect(NULL, FALSE);
	}
}

void CContoursView::OnUpdateLine(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(!m_bFill);
}

void CContoursView::OnUpdateFill(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bFill);
}

void CContoursView::OnAnimation() 
{
	m_bAnimation = !m_bAnimation;
	if(m_bAnimation)
		SetTimer(1, 10, NULL);
	else
		KillTimer(1);	
}

void CContoursView::OnUpdateAnimation(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bAnimation);
}

void CContoursView::OnTimer(UINT nIDEvent) 
{
	switch(nIDEvent)
	{
		case 1: // Animation
			m_zRotate -= 3;
			InvalidateRect(NULL, FALSE);
			break;
	}
	CView::OnTimer(nIDEvent);
}

void CContoursView::OnGraph3d() 
{
	m_eProjection = PROJ_PERSPECTIVE;
	m_eGraph = GRAPH_3D;
	m_xRotate = -60;
	m_yRotate = 0;
	m_zRotate = -135;
	InvalidateRect(NULL, FALSE);
}

void CContoursView::OnUpdateGraph3d(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_eGraph == GRAPH_3D);
}

void CContoursView::OnLighting() 
{
	if(::glIsEnabled(GL_LIGHTING))
		::glDisable(GL_LIGHTING);
	else
		::glEnable(GL_LIGHTING);
	InvalidateRect(NULL, FALSE);
}

void CContoursView::OnUpdateLighting(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(::glIsEnabled(GL_LIGHTING));
}

void CContoursView::OnLight0() 
{
	if(::glIsEnabled(GL_LIGHT0))
		::glDisable(GL_LIGHT0);
	else
		::glEnable(GL_LIGHT0);
	InvalidateRect(NULL, FALSE);
}

void CContoursView::OnUpdateLight0(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(::glIsEnabled(GL_LIGHT0));
	pCmdUI->Enable(::glIsEnabled(GL_LIGHTING));
}

void CContoursView::OnLight1() 
{
	if(::glIsEnabled(GL_LIGHT1))
		::glDisable(GL_LIGHT1);
	else
		::glEnable(GL_LIGHT1);
	InvalidateRect(NULL, FALSE);
}

void CContoursView::OnUpdateLight1(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(::glIsEnabled(GL_LIGHT1));
	pCmdUI->Enable(::glIsEnabled(GL_LIGHTING));
}

void CContoursView::OnBlend() 
{
	// TODO: Add your command handler code here
	if(::glIsEnabled(GL_BLEND))
	  ::glDisable(GL_BLEND);
	else
	  ::glEnable(GL_BLEND);
	InvalidateRect(NULL, FALSE);
}

void CContoursView::OnUpdateBlend(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(::glIsEnabled(GL_BLEND));	
}

void CContoursView::OnDemoTriangle() 
{
	// TODO: Add your command handler code here
	m_eProjection = PROJ_ORTHO;
	m_eGraph = TRIANGLE;
	m_xRotate = -20;
	m_yRotate = 0;
	m_zRotate = -135;
	InvalidateRect(NULL, FALSE);	
}

void CContoursView::OnUpdateDemoTriangle(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_eGraph == TRIANGLE);	
}
