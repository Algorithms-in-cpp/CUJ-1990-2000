// OGLMDIView.h : interface of the CContoursView class
//
#ifndef AFX_CONTOURSVIEW_H_GJI875R_C4I6ER7UT_5AYAMADA6_7KRYMNCL45_I4UITCJ34_
#define AFX_CONTOURSVIEW_H_GJI875R_C4I6ER7UT_5AYAMADA6_7KRYMNCL45_I4UITCJ34_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CContoursView : public CView
{
protected: // create from serialization only
	CContoursView();
	DECLARE_DYNCREATE(CContoursView)

// Attributes
public:
	CContoursDoc* GetDocument();

private:
	CDC*		m_pDC;
	HGLRC		m_hRC;
	double		m_dRadius;
	double		m_dFovY;
	double		m_dNearPlane; 
	double		m_dFarPlane; 
	double		m_dMaxObjSize; 
	double		m_dAspectDisplay;
	double		m_dLeftPlane;
	double		m_dRightPlane;
	double		m_dTopPlane;
	double		m_dBottomPlane;
	CPoint		m_LeftDownPos;
	double		m_xRotate;
	double		m_yRotate;
	double		m_zRotate;
	BOOL		m_bFill; 
	BOOL		m_bAnimation;

	enum OGL_LIST { TRIANGLE = 1, GRAPH_3D };
	OGL_LIST	m_eGraph;

	// Operations
	void Initialization();
    BOOL SetupPixelFormat(HDC hdc);
    void RenderScene();
	void SetProjection(int nType);
	void ResetView(int nWidth, int nHeight);

	enum eProj { PROJ_PERSPECTIVE, PROJ_ORTHO };
	eProj m_eProjection;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContoursView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CContoursView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CContoursView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnFilePrintPreview();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLine();
	afx_msg void OnFill();
	afx_msg void OnAnimation();
	afx_msg void OnUpdateLine(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFill(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAnimation(CCmdUI* pCmdUI);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnGraph2d();
	afx_msg void OnGraph3d();
	afx_msg void OnUpdateGraph2d(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGraph3d(CCmdUI* pCmdUI);
	afx_msg void OnLighting();
	afx_msg void OnUpdateLighting(CCmdUI* pCmdUI);
	afx_msg void OnLight0();
	afx_msg void OnUpdateLight0(CCmdUI* pCmdUI);
	afx_msg void OnLight1();
	afx_msg void OnUpdateLight1(CCmdUI* pCmdUI);
	afx_msg void OnBlend();
	afx_msg void OnUpdateBlend(CCmdUI* pCmdUI);
	afx_msg void OnDemoTriangle();
	afx_msg void OnUpdateDemoTriangle(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OGLMDIView.cpp
inline CContoursDoc* CContoursView::GetDocument()
   { return (CContoursDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

#endif
