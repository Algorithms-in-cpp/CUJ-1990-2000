//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Contours.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CONTOUTYPE                  129
#define IDC_BUTTON1                     1000
#define ID_GRAPH_LINE                   32771
#define ID_DEMO_LINE                    32771
#define ID_GRAPH_FILL                   32772
#define ID_DEMO_FILL                    32772
#define ID_GRAPH_ANIMATION              32773
#define ID_DEMO_ANIMATION               32773
#define ID_GRAPH_GRAPH2D                32774
#define ID_DEMO_GRAPH2D                 32774
#define ID_GRAPH_GRAPH3D                32775
#define ID_DEMO_GRAPH3D                 32775
#define ID_DEMO_BLEND                   32778
#define ID_DEMO_8CONTOURS               32779
#define ID_DEMO_32CONTOURS              32780
#define ID_DEMO_TRIANGLE                32781
#define ID_GRAPH_LIGHTING               32783
#define ID_DEMO_LIGHTING                32783
#define ID_GRAPH_LIGHT1                 32787
#define ID_DEMO_LIGHT1                  32787
#define ID_GRAPH_LIGHT0                 32788
#define ID_DEMO_LIGHT0                  32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
