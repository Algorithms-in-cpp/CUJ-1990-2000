_TCHAR ReadCharFromConsole()
{

  HANDLE hConsoleInput = GetStdHandle(STD_INPUT_HANDLE);
  SetConsoleMode(hConsoleInput, 0);
  
  _TCHAR cIn = '\0';
  LPVOID lpBuffer = &cIn;
  DWORD dwNumberOfCharsRead;
  ReadConsole( 
    hConsoleInput, 
    lpBuffer, 
    1, 
    &dwNumberOfCharsRead,
    NULL
    ); 

  return cIn;

}