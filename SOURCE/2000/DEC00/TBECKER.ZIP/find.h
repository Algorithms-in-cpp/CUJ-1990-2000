 // TEMPLATE FUNCTION find
template<class _II, class _Ty> inline
_II find(_II _F, _II _L, const _Ty& _V)
{
  for (; _F != _L; ++_F)
    if (*_F == _V)
      break;
  return (_F); 
}
