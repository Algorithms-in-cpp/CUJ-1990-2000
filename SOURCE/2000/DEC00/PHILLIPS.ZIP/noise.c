

    /***********************************************
    *
    *    file noise.c
    *
    *    Functions: This file contains
    *       main
    *       calculate_histogram
    *       show_histogram
    *       show_fhistogram
    *
    *    Purpose:
    *       This program creates noise images
    *       from histograms.
    *
    *    External Calls:
    *       gpcips.c - my_clear_text_screen
    *       imageio.c
    *
    *    Modifications:
    *       22 June 2000 - created
    *
    ***********************************************/

#include "cips.h"





main(argc, argv)
   int argc;
   char *argv[];
{
   char     name[80];
   char     *cc;
   char     response[80];
   char     type[80];
   long     alpha, beta;
   int      count, i, ie, il, j, le, l, ll, k, w;
   int      ok = 0;
   long     cols, rows;
   struct   tiff_header_struct image_header;
   struct   bmpfileheader      bmp_file_header;
   struct   bitmapheader       bmheader;
   unsigned long total_pixels, histogram[GRAY_LEVELS+1], 
            hist2[GRAY_LEVELS+1], hist3[GRAY_LEVELS+1], sum;
   float    fhistogram[GRAY_LEVELS+1];
   float    probability;
   int      lower_limit, trying, upper_limit;
   int      other, pepper, salt;
   short    background;
   short **out_image;
   double   standard_deviation, mean, 
            variance, denominator, exponent;

      /******************************************
      *
      *   Obtain the command line parameters
      *
      *   This program will generate either
      *   equal probability noise,
      *   gaussian noise, or salt and pepper
      *   noise.
      *
      ******************************************/

   if(argc < 6 ){
      printf("\nusage: noise file-name "
             "type length width"
             "\n\ttype is Equal - Saltpepper - Gaussian\n");
      printf("\n"
      "\nnoise file-name equal length width"
      " upper_limit lower_limit");
      printf("\n"
      "\nnoise file-name salt length width"
      " salt pepper other");
      printf("\n"
      "\nnoise file-name gaussian length width"
      " std_deviation mean (floats)");
      exit(-1);
   }  /* ends if argc */

   strcpy(name, argv[1]);
   strcpy(type, argv[2]);
   l = atoi(argv[3]);
   w = atoi(argv[4]);
   total_pixels = l*w;

      /**************************************
      *                      
      *   Pre Processing
      *
      *   Create the output image.  It will
      *   either be a tif or a bmp file.
      *                      
      **************************************/

   cc = strstr(argv[1], ".tif");
   if(cc != NULL){  /* create a tif */
      ok = 1;
      image_header.lsb            = 1;
      image_header.bits_per_pixel = 8;
      image_header.image_length   = l;
      image_header.image_width    = w;;
      image_header.strip_offset   = 1000;
      rows = image_header.image_length;
      cols = image_header.image_width;
      create_allocate_tiff_file(argv[1], 
                                &image_header);
   }  /* ends tif */

   cc = strstr(argv[1], ".bmp");
   if(cc != NULL){  /* create a bmp */
      ok = 1;
      bmheader.height = l;
      bmheader.width  = w;
      rows = bmheader.height;
      cols = bmheader.width;
      create_allocate_bmp_file(argv[1], 
                               &bmp_file_header, 
                               &bmheader);
   }  /* ends bmp */

   if(ok == 0){
      printf("\nERROR input file neither tiff nor bmp");
      exit(0);
   }

   out_image = allocate_image_array(l, w);

      /******************************************
      *                      
      *   Processing
      *
      *   For the type of noise chosen,
      *   fill a floating point histogram
      *   array with probabilities for that
      *   pixel value.  For example, if
      *   20% of the pixels should be gray
      *   level 11, then the 11th place of
      *   the floating point histogram array
      *   will equal 0.2.
      *
      *   Then fill an integer histogram 
      *   with numbers that equal the
      *   probability * total number of pixels
      *                      
      ******************************************/



      /******************************************
      *                      
      *   Equal Probability case 
      *
      *   Fill the histogram with equal numbers
      *   of values between the upper and lower
      *   limits.
      *
      ******************************************/

   if(type[0] == 'e' || type[0] == 'E'){
   upper_limit =  atoi(argv[5]);
   lower_limit =  atoi(argv[6]);
   probability = 1.0/((float)(upper_limit-lower_limit-1));
printf("\nprobability=%12.9f", probability);
   for(i=0; i<GRAY_LEVELS+1; i++){
      fhistogram[i] = 0.0;
      if(i>lower_limit && i<upper_limit)
         fhistogram[i] = probability;
   }  /* ends loop over i */

   for(i=0; i<GRAY_LEVELS+1; i++){
      histogram[i] = total_pixels*fhistogram[i];
if(histogram[i] != 0) printf("\n[%d]=%ld",i,histogram[i]);
   }  /* ends loop over i */
   }  /* ends if type */
   


      /******************************************
      *                      
      *   Salt and Pepper Noise case 
      *
      *   There are three non-zero values in
      *   the histogram: salt, pepper, and
      *   background.  Salt and pepper will have
      *   equal probabilities and the background
      *   will have the remainder.
      *
      ******************************************/

   if(type[0] == 's' || type[0] == 'S'){
printf("\nSalt and Pepper case");
   other       = atoi(argv[7]);
   salt        = atoi(argv[5]);
   pepper      = atoi(argv[6]);
printf("\nSalt=%d Pepper=%d other=%d",salt,pepper,other);
   probability = 0.10; /* might make this a parameter */

   for(i=0; i<GRAY_LEVELS+1; i++)
      fhistogram[i] = 0.0;

   fhistogram[salt]   = probability;
   fhistogram[pepper] = probability;
   fhistogram[other]  = 1.0 - 2.0*probability;

   for(i=0; i<GRAY_LEVELS+1; i++){
      histogram[i] = total_pixels*fhistogram[i];
if(histogram[i] != 0) printf("\n[%d]=%ld",i,histogram[i]);
   }  /* ends loop over i */
   }  /* ends if type */



      /******************************************
      *                      
      *   Gaussian Noise case 
      *
      *   This section uses the equation for a
      *   Guassian or normal distribution.  The
      *   parameters are the standard deviation
      *   and the mean.
      *
      ******************************************/

   if(type[0] == 'g' || type[0] == 'G'){
   standard_deviation = atof(argv[5]);
   mean               = atof(argv[6]);
   variance           = standard_deviation*standard_deviation;
   denominator        = standard_deviation*(sqrt(2.0*PI));
   sum                = 0;
   
   for(i=0; i<GRAY_LEVELS+1; i++){
      fhistogram[i] = 0.0;
      exponent      = -1.0*((i-mean)*(i-mean)/variance);
      fhistogram[i] = (exp(exponent))/denominator;
      histogram[i]  = total_pixels*fhistogram[i];
      sum           = sum + histogram[i];
if(fhistogram[i] != 0.0) printf("\n[%d]=%ld %f",i,histogram[i],fhistogram[i]);
   }  /* ends loop over i */
printf("\ntotalPix=%ld sum=%ld",total_pixels, sum);
   }  /* ends if type */


      /******************************************
      *                      
      *   This section of code creates
      *   an image from an integer 
      *   histogram by placing the pixels 
      *   randomly throughout the image array.
      *   This runs quickly at first, then slows
      *   as it becomes harder to find pixels
      *   places that have not been filled.
      *
      ******************************************/

   background = -1;
   for(i=0; i<rows; i++)
      for(j=0; j<cols; j++)
         out_image[i][j] = background;

   for(i=0; i<GRAY_LEVELS+1; i++){
      while(histogram[i] != 0){
         trying = 1;
         while(trying){
            alpha = random()%rows;
            beta  = random()%cols;
            alpha = alpha % rows;
            beta  = beta  % cols;
            if(out_image[alpha][beta] == background){
               out_image[alpha][beta] = i;
               trying                 = 0;
               histogram[i]--;
            }  /* ends if not background */
         }  /* ends while trying */
      }  /* ends while histogram[i] != 0 */
      if(i%10 == 0) printf("\n");
      printf(" [%d]", i);
   }  /* ends loop over i */

      /******************************************
      *                      
      *   This last loop through the image 
      *   ensures that there are no background
      *   values left in the output image.  This
      *   is a patch because for some reason, 
      *   the program does not correctly fill
      *   all the pixel locations in the output
      *   image.
      *
      ******************************************/
   
   for(i=0; i<rows; i++)
      for(j=0; j<cols; j++)
         if(out_image[i][j] == background)
            out_image[i][j] = out_image[i-1][j];

      /**************************************
      *                      
      *   Write the noise image to a file
      *   and free the image array.
      *                      
      **************************************/

   write_image_array(name, out_image);
   free_image_array(out_image, l, w);

}  /* ends main */



   /*********************************************
   *
   *   Following are three histogram routines
   *   calculate_histogram, show_histogram,
   *   and show_fhistogram used by the noise
   *   program.
   *
   *********************************************/


calculate_histogram(image, histogram, 
                    length, width)
   int    length, width;
   short  **image;
   unsigned long histogram[];
{
   long  i,j;
   short k;
   for(i=0; i<length; i++){
      for(j=0; j<width; j++){
         k = image[i][j];
         histogram[k] = histogram[k] + 1;
      }
   }
}  /* ends calculate_histogram */


show_histogram(histogram)
   unsigned long histogram[];
{
   int i;
   for(i=0; i<GRAY_LEVELS+1; i++){
      if(histogram[i] != 0)
      printf("\nh[%3d] = %ld", i, histogram[i]);
   }
}  /* ends show_histogram */


show_fhistogram(histogram, h2)
   float histogram[], h2[];
{
   int i;
   for(i=0; i<GRAY_LEVELS+1; i++){
      printf("\nh[%3d] = %ld theoretical=%ld", 
               i, h2[i], histogram[i]);
   }
}  /* ends show_fhistogram */


