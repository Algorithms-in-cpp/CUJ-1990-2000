
    /***********************************************
    *
    *    file afilter.c
    *
    *    Functions: This file contains
    *       moments
    *       mmse
    *       dwmtm
    *       sam
    *
    *    Purpose:
    *       These functions implement the
    *       adaptive filters.
    *
    *    External Calls:
    *       utility.c - fix_edges
    *       fitler.c - median_of
    *
    *    Modifications:
    *       15 June 2000 - created
    *
    *************************************************/

#include "cips.h"




     /*******************************************
     *
     *   moments(...
     *
     *   This function calculates and returns
     *   the first_moment (mean), second_moment,
     *   variance, and sigma of an area of
     *   an image array.
     *
     *******************************************/


moments(the_image, out_image,
        rows, cols, 
        rows_size, cols_size, 
        il, ie,
        first_moment, second_moment,
        variance, sigma)
   short  il, ie,
          **the_image,
          **out_image;
   long   rows, cols,
          rows_size, cols_size;
   float  *first_moment, *second_moment,
          *sigma, *variance;
{
   int      i, j;
   int      csd2, rsd2;
   float    mean;
   unsigned long count, sum1, sum2;
  
   char response[80];


   rsd2 = rows_size/2;
   csd2 = cols_size/2;

   if(((il+rsd2) > rows)   ||
      ((ie+csd2) > cols)   ||
      ((il-rsd2) < 0)      ||
      ((ie-csd2) < 0)) {
      printf("\nmoments> ERROR: OUT OF BOUNDS");
      *first_moment  = -1.0;
      *second_moment = -1.0;
      *variance      = -1.0;
      *sigma         = -1.0;
   }  /* ends too big */

   else{ /* else not out of bounds */
      sum1  = 0;
      sum2  = 0;
      count = 0;
      for(i=il-rsd2; i<il+rsd2; i++){
         for(j=ie-csd2; j<ie+csd2; j++){
            count++;
            sum1 = sum1 + the_image[i][j];
            sum2 = sum2 + the_image[i][j]*the_image[i][j];
         }  /* ends loop over j */
      }  /* ends loop over i */
      *first_moment  = (float)(sum1/count);
      *second_moment = (float)(sum2/count);
      mean           = *first_moment;
      *variance      = *second_moment - mean*mean;
      *sigma         = sqrt(*variance);
   }  /* ends else not out of bounds */
}  /* ends moments */




    /*******************************************
    *
    *   mmse(..
    *
    *   This function performs the minimum
    *   mean-square error filter on an image.
    *   size is the size of the local area
    *   being used (3x3, 5x5, 7x7, etc.).
    *
    *******************************************/

mmse(the_image, out_image,
     rows, cols, size,
     noise_variance)
   int    size;
   float  noise_variance;
   short  **the_image,
          **out_image;
   long   rows, cols;
{
   float  first_moment, nvdv, second_moment,
          sigma, variance;
   int    i, j, sd2;
   char response[80];

   sd2 = size/2;

/************************
printf("\nDEBUG> start of MMSE");
printf("\nDEBUG> size=%d sd2=%d noiseV=%f",size,sd2,noise_variance);
printf("\nDEBUG> rows=%d cols=%d", rows, cols);
printf("\nDEBUG> HIT ENTER");
gets(response);
************************/

      /***************************
      *
      *   Loop over image array
      *
      ****************************/

   printf("\nmmse>");
   for(i=sd2; i<rows-sd2; i++){
      if( (i%10) == 0) printf("%d ", i);
      for(j=sd2; j<cols-sd2; j++){
         moments(the_image, out_image,
                 rows, cols, 
                 size, size,
                 i, j, 
                 &first_moment, &second_moment,
                 &variance, &sigma);
         if(variance == -1.0){
            out_image[i][j] = the_image[i][j];
         }  /* ends if moments was out of bounds */
         else{ /* else moments not out of bounds */
            if(variance != 0.0){
               nvdv = noise_variance/variance;
               out_image[i][j] = (1.0-nvdv)*(float)(the_image[i][j]) +
                                 (nvdv)*first_moment;
            }  /* ends if variance not zero */
            else
               out_image[i][j] = the_image[i][j];
         }  /* ends if moments not out of bounds */
         if(out_image[i][j] < 0)
            out_image[i][j] = first_moment;
         if(out_image[i][j] > GRAY_LEVELS)
            out_image[i][j] = first_moment;
/************************************
if( i%10==0 && j%10==0 ) {
printf("\nDEBUG> input[%d][%d]=%d output=%d",
i, j, the_image[i][j], out_image[i][j]);
printf("\nDEBUG> noiseV=%f localV=%f localMean=%f",
noise_variance, variance, first_moment);
}
printf("\nDEBUG> HIT ENTER");
gets(response);i
***********************/
      }  /* ends loop over j */
   }  /* ends loop over i */

   fix_edges(out_image, sd2, rows-1, cols-1);

}  /* ends mmse */





    /*******************************************
    *
    *   dwmtm(..
    *
    *   This function performs the double
    *   window-modified trimmed mean filter.
    *   This function uses two windows defined
    *   by the little_size and big_size
    *   parameters.  k ranges from 1.5 to 2.5.
    *
    *******************************************/

dwmtm(the_image, out_image,
      rows, cols, 
      little_size, big_size,
      noise_sd, k)
   int    big_size, little_size;
   float  k, noise_sd;
   short  **the_image,
          **out_image;
   long   rows, cols;
{
   float ksd;
   int   a, b, count, i, j, ss;
   int   bsd2, bsd2p1, lsd2, lsd2p1;
   short *elements, 
         lower_range, 
         sum, 
         this_mean, 
         this_median, 
         upper_range;

      /**********************************************
      *
      *   Allocate the elements array large enough
      *   to hold little_size*little_size shorts.
      *
      **********************************************/

   ss       = little_size*little_size;
   elements = (short *) malloc(ss * sizeof(short));

   bsd2   = big_size/2;
   bsd2p1 = bsd2+1;
   lsd2   = little_size/2;
   lsd2p1 = lsd2+1;
   ksd    = k*noise_sd;

      /***************************
      *
      *   Loop over image array
      *
      ****************************/

   printf("\ndwmtm>");
   for(i=bsd2; i<rows-bsd2; i++){
      if( (i%10) == 0) printf("%d ", i);
      for(j=bsd2; j<cols-bsd2; j++){
            
            /************************************
            *
            *   Compute the median for the 
            *   little_size square about 
            *   the_image[i][j].
            *
            ************************************/
         
         count = 0;
         for(a=-lsd2; a<lsd2p1; a++){
            for(b=-lsd2; b<lsd2p1; b++){
               elements[count] = the_image[i+a][j+b];
               count++;
            }
         }
         this_median = median_of(elements, &ss);
            
            /************************************
            *
            *   Compute the mean for the 
            *   big_size square about 
            *   the_image[i][j].  Exclude any
            *   pixels whose value is "near"
            *   the median (near means only
            *   plus or minus ksd).
            *
            ************************************/

         lower_range = this_median - (int)(ksd);
         upper_range = this_median + (int)(ksd);
         count       = 0;
         sum         = 0;
         for(a=-bsd2; a<bsd2p1; a++){
            for(b=-bsd2; b<bsd2p1; b++){
               if((the_image[i+a][j+b] > lower_range)  &&
                  (the_image[i+a][j+b] < upper_range)){
                  sum = sum + the_image[i+a][j+b];
                  count++;
               }  /* ends if in range */
            }
         }
         this_mean = sum/count;
         out_image[i][j] = this_mean;
         

      }  /* ends loop over j */
   }  /* ends loop over i */

   fix_edges(out_image, bsd2, rows-1, cols-1);
   free(elements);

}  /* ends dwmtm */





    /*******************************************
    *
    *   sam(..
    *
    *   This function implements a signal
    *   adaptive median filter.  It calls
    *   both low pass and high pass filters.
    *   The konstant is greater than or equal
    *   to zero.  When konstant is zero,
    *   sam become a low pass filter.  As 
    *   konstant grows, sam nears a high pass
    *   filter.
    *
    *******************************************/

sam(the_image, out_image,
    low_pass_image, high_pass_image,
    rows, cols,
    noise_variance, konstant,
    size, 
    low_pass_type, high_pass_type)

   float konstant, noise_variance;
   int   high_pass_type, low_pass_type, size;
   long  cols, rows;
   short **the_image, **out_image,
         **low_pass_image, **high_pass_image;
{
   char  low_or_high[MAX_NAME_LENGTH];
   float first_moment, k, 
         local_variance, second_moment, sigma;
   int   a, b, i, j, sd2;
   short filter[3][3];

   sd2 = size/2;
      
      /**************************************
      *
      *   Create the low pass and high pass
      *   filter outputs.
      *
      **************************************/

   low_or_high[0] = 'l';
   filter_image(the_image, low_pass_image,
                rows, cols, 8, 
                filter, low_pass_type, 
                low_or_high);

   low_or_high[0] = 'h';
   filter_image(the_image, high_pass_image,
                rows, cols, 8, 
                filter, high_pass_type, 
                low_or_high);

   for(i=sd2; i<rows-sd2; i++){
      for(j=sd2; j<cols-sd2; j++){
         moments(the_image, out_image,
                 rows, cols, 
                 size, size,
                 i, j, 
                 &first_moment, &second_moment,
                 &local_variance, &sigma);
         if(konstant*noise_variance >= local_variance)
            k = 0.0;
         else
            k = 1.0 - konstant*(noise_variance/local_variance);
         out_image[i][j] = low_pass_image[i][j] +
                           k*high_pass_image[i][j];
         if(out_image[i][j] < 0) 
            out_image[i][j] = 0;
         if(out_image[i][j] > GRAY_LEVELS)
            out_image[i][j] = GRAY_LEVELS;
/************************************
if( i%10==0 && j%10==0 ) {
printf("\nnoiseV=%f localV=%f konstant=%f k=%f low=%d hi=%d",
noise_variance,local_variance,konstant,k,
low_pass_image[i][j], high_pass_image[i][j]);
printf("\n     input[%d][%d]=%d output=%d",
i, j, the_image[i][j], out_image[i][j]);
}
printf("\nDEBUG> HIT ENTER");
gets(response);i
***********************/
 
      }  /* ends loop over j */
   }  /* ends loop over i */

}  /* ends sam */
