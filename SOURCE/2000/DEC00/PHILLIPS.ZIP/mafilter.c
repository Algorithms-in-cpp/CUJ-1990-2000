


       /***********************************************
       *
       *   file mafilter.c
       *
       *   Functions: This file contains
       *      main
       *
       *   Purpose:
       *      This is the main calling program for
       *      a set of adaptive filtering routines.
       *
       *   External Calls:
       *      imageio.c - create_image_file
       *                  read_image_array
       *                  write_image_array
       *                  get_image_size
       *                  get_bitsperpixel
       *                  allocate_image_array
       *                  free_image_array
       *      afilter.c - moments
       *                  dwmtm
       *                  mmse
       *                  sam
       *
       *   Modifications:
       *      15 June 2000 - created
       *
       ***********************************************/



#include "cips.h"


main(argc, argv)
   int argc;
   char *argv[];
{
   char     name1[MAX_NAME_LENGTH];
   char     name2[MAX_NAME_LENGTH];
   char     low_high[MAX_NAME_LENGTH];
   char     op[MAX_NAME_LENGTH];
   int      i, j, size, type;
   int      il, ie, cols_size, rows_size;
   int      low_pass_type, hi_pass_type;
   int      big_size, little_size;
   long     bits_per_pixel, length, width;
   short    **the_image, **out_image, filter[3][3];
   short    **high_pass_image, **low_pass_image;

   float  first_moment, k, second_moment, variance, sigma;
   float  konstant, noise_stddev, noise_variance;
   
      /******************************************
      *
      *   Ensure the command line is correct.
      *
      ******************************************/


   if(argc < 3){
      afilter_usage();
      exit(-1);
   }


   strcpy(name1, argv[1]);
   strcpy(name2, argv[2]);
   strcpy(op,  argv[3]);

   if(does_not_exist(name1)){
      printf("\nERROR input file %s does not exist",
             name1);
      exit(0);
   }  /* ends if does_not_exist */
   
      /******************************************
      *
      *   Read the input image header, allocate
      *   the image arrays, create the output
      *   image, and read the input image.
      *
      ******************************************/

   create_image_file(name1, name2);
   get_image_size(name1, &length, &width);
   get_bitsperpixel(name1, &bits_per_pixel);
   the_image = allocate_image_array(length, width);
   out_image = allocate_image_array(length, width);
   read_image_array(name1, the_image);



   
      /******************************************
      *
      *   Call the proper image filter function
      *   per the command line.
      *
      ******************************************/

      /* moments case */
   if(op[0] == 'm' || op[0] == 'M'){
      il        = atoi(argv[4]);
      ie        = atoi(argv[5]);
      rows_size = atoi(argv[6]);
      cols_size = atoi(argv[7]);
      moments(the_image, out_image,
              length, width, 
              rows_size, cols_size,
              il, ie,
              &first_moment, &second_moment,
              &variance, &sigma);
      printf("\nmean=%f variance=%f sigma=%f",
      first_moment, variance, sigma);
   }  /* ends if op */




      /* sam case */
   if(op[0] == 's' || op[0] == 'S'){
      low_pass_image  = allocate_image_array(length, width);
      high_pass_image = allocate_image_array(length, width);
      variance      = atof(argv[4]);
      konstant      = atof(argv[5]);
      size          = atoi(argv[6]);
      low_pass_type = atoi(argv[7]);
      hi_pass_type  = atoi(argv[8]);
      sam(the_image, out_image,
          low_pass_image, high_pass_image,
          length, width,
          variance, konstant,
          size,
          low_pass_type, hi_pass_type);
      free_image_array(low_pass_image, length);
      free_image_array(high_pass_image, length);
   }  /* ends if op */




      /* mmse case */
   if(op[0] == 'e' || op[0] == 'E'){
      size           = atoi(argv[4]);
      noise_variance = atof(argv[5]);
      mmse(the_image, out_image,
           length, width,
           size,
           noise_variance);
   }  /* ends if op */




      /* dwmtm case */
   if(op[0] == 'd' || op[0] == 'D'){
      little_size  = atoi(argv[4]);
      big_size     = atoi(argv[5]);
      noise_stddev = atof(argv[6]);
      k            = atof(argv[7]);
      dwmtm(the_image, out_image,
            length, width, 
            little_size, big_size,
            noise_stddev, k);
   }  /* ends if op */

      /******************************************
      *
      *   Write the result and free the image
      *   arrays.
      *
      ******************************************/
   
   write_image_array(name2, out_image);
   free_image_array(the_image, length);
   free_image_array(out_image, length);

}  /* ends main */





afilter_usage()
{
printf("
\nmafilter input_file output_file type..."

"\n\nmafilter input_file output_file Moments il ie rows_size cols_size"

"\n\nmafilter input_file output_file Sam noise_variance "
"konstant size lowpass hipass"
"\n\tlowpass=6,9,10,16,32  hipass=1,2,3"
"\n\t0.0<konstant<3.0    noise_variance is also a float"

"\n\nmafilter input_file output_file mmsE size noise_variance"
"\n\tsize is 3x3 5x5 7x7 etc.    noise_variance is a float"

"\n\nmafilter input_file output_file Dwmtm small_size big_size noise_stddev k"
"\n\tnoise_stddev is a float    1.5 <= k <= 2.5"


"\n\nmafilter input_file output_file moments il ie rows_size cols_size"
"\n");

}  /* ends afilter_usage */





/************ test the sam

sam(the_image, out_image,
    low_pass_image, high_pass_image,
    rows, cols,
    noise_variance, konstant,
    size, 
    low_pass_type, high_pass_type)

   float konstant, noise_variance;
   int   high_pass_type, low_pass_type, size;
   long  cols, rows;
   short **the_image, **out_image,
         **low_pass_filter, **high_pass_filter;


try noise_variance=100.0
    konstant=1.0
    size=3
    low pass filter type=6
    high pass filter type=1

****************************************/

/********** test the mmse, use a noise variance of 1500 just for fun

   mmse(the_image, out_image, 
        length, width, 
        3, 150.0);

****************************************/

/******* test the dwmtm

dwmtm(the_image, out_image,
      rows, cols, 
      little_size, big_size,
      noise_sd, k)

dwmtm(the_image, out_image, length, width,
      3, 5, 10.0, 2.0);
********************************/



/********************* testing the moments routine
for(i=3; i<333; i++){
   moments(the_image, out_image,
           length, width, 
           3, 3,
           i, i,
           &first_moment, &second_moment,
           &variance, &sigma);
   printf("\nFor 3 by 3 area starting at %d %d", i, i);
   printf("\nfirstM=%f secondM=%f variance=%f sigma=%f",
          first_moment, second_moment, variance, sigma);
}

   moments(the_image, out_image,
           length, width, 
           length, width,
           0, 0,
           &first_moment, &second_moment,
           &variance, &sigma);
   printf("\n\n\nFor the whole image");
   printf("\nfirstM=%f secondM=%f variance=%f sigma=%f",
          first_moment, second_moment, variance, sigma);





   moments(the_image, out_image,
           length, width, 
           length, width,
           0, 0,
           &first_moment, &second_moment,
           &variance, &sigma);
   printf("\nFor the whole image");
   printf("\nfirstM=%f secondM=%f variance=%f sigma=%f",
          first_moment, second_moment, variance, sigma);

   moments(the_image, out_image,
           length, width, 
           3, 3,
           5, 5,
           &first_moment, &second_moment,
           &variance, &sigma);
   printf("\nFor 3 by 3 area starting at 5 and 5");
   printf("\nfirstM=%f secondM=%f variance=%f sigma=%f",
          first_moment, second_moment, variance, sigma);

   moments(the_image, out_image,
           length, width, 
           3, 3,
           50, 50,
           &first_moment, &second_moment,
           &variance, &sigma);
   printf("\nFor 3 by 3 area starting at 50 and 50");
   printf("\nfirstM=%f secondM=%f variance=%f sigma=%f",
          first_moment, second_moment, variance, sigma);

   moments(the_image, out_image,
           length, width, 
           3, 3,
           100, 100, 
           &first_moment, &second_moment,
           &variance, &sigma);
   printf("\nFor 3 by 3 area starting at 100 and 100");
   printf("\nfirstM=%f secondM=%f variance=%f sigma=%f",
          first_moment, second_moment, variance, sigma);

   moments(the_image, out_image,
           length, width, 
           3, 3,
           200, 200, 
           &first_moment, &second_moment,
           &variance, &sigma);
   printf("\nFor 3 by 3 area starting at 200 and 200");
   printf("\nfirstM=%f secondM=%f variance=%f sigma=%f",
          first_moment, second_moment, variance, sigma);
*****************************************************/


/*************************************************
moments(the_image, out_image,
        rows, cols, 
        rows_size, cols_size, 
        il, ie,
        first_moment, second_moment,
        variance, sigma)
   short  il, ie,
          **the_image,
          **out_image;
   long   rows, cols,
          rows_size, cols_size;
   float  *first_moment, *second_moment,
          *sigma, *variance;
**************************************************/

/**************** test sam

   low_pass_image  = allocate_image_array(length, width);
   high_pass_image = allocate_image_array(length, width);
   sam(the_image, out_image,
       low_pass_image, high_pass_image,
       length, width,
       100.0, 2.0,
       3,
       6, 1);
   free_image_array(low_pass_image, length);
   free_image_array(high_pass_image, length);

sam(the_image, out_image,
    low_pass_image, high_pass_image,
    rows, cols,
    noise_variance, konstant,
    size, 
    low_pass_type, high_pass_type)

   float konstant, noise_variance;
   int   high_pass_type, low_pass_type, size;
   long  cols, rows;
   short **the_image, **out_image,
         **low_pass_image, **high_pass_image;
*******************************************************/

