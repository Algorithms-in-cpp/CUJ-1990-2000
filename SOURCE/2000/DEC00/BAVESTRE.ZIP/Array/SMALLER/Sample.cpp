#ifndef   ARRAY_H
#include "array.h"
#endif

#include <iostream>

//*****************************************************************************
// This is just a silly test program, to test the code presented in the article
//*****************************************************************************

int main(int argc, char* argv[])
{
   unsigned int k=0,x,y,z;

   // Array sizes 
   unsigned int Sizes2[]={10,20};
   unsigned int Sizes3[]={10,20,30};
   unsigned int Sizes5[]={5,6,7,8,9};

   // Define some arrays 
   Array<int, 2> A2;               // Two-dimensional
   Array<int, 3> A3(Sizes3);       // Three-dimensional
   Array<int, 4> A4(ArraySizes(10)(20)(40)(50));   // Four-dimensional
   const Array<int, 5> A5(Sizes5); // Five-dimensional constant array

   // Traverse the Array a'la STL and fill it in
   for (Array<int, 3>::iterator it=A3.begin();it<A3.end();it++)
       *it=++k;

   // Create some more arrays
   Array<int,3> CopyOfA3(A3);  // Test copy constructor
   CopyOfA3=A3;                // Test assignment operator
   CopyOfA3=CopyOfA3;          // Assignment to self 
   CopyOfA3.swap(A3);          // Test Swap

   A2.resize(Sizes2); // Resize currently empty Array   
   A3.resize(ArraySizes(10)(20)(30)); // Resize Array, loose elements 

   A2[1][2]=A2[2][1]+1;         // Indexing 2D Array
   A3[0][0][0]=10;              // Indexing 3D Array
   A4[1][2][3][4]++;            // Indexing 4D Array
   int aaa=A5[1][2][3][4][5];   // Indexing 5D Array
   


   k=0;
   // Traverse the Array with nested loops
   for (x=0;x<A3.size(1);x++)
    for (y=0;y<A3.size(2);y++)
     for (z=0;z<A3.size(3);z++)
     {
       A3[x][y][z]=++k;

       // Assert that values are the same as when we used iterators above
       assert(A3[x][y][z]==CopyOfA3[x][y][z]);
     } 

   unsigned int Sizes3Big[]={20,30,40};
   CopyOfA3.resize(Sizes3Big,0,true);
   CopyOfA3.resize(Sizes3,0,true);
   assert(A3==CopyOfA3);

   // Call getsubarray and equality for subarrays
   assert(A3[0]==CopyOfA3[0]);
   assert(A3[0][0]!=CopyOfA3[0][1]);
   assert(A3[0][0][0]==CopyOfA3[0][0][0]);

   // Test equality and inequality operators
   int old=A3[1][2][3];
   A3[1][2][3]=56;
   assert(A3!=CopyOfA3);
   A3[1][2][3]=old;
   assert(A3==CopyOfA3);

   k=0;
   // Traverse Array with nested loops in a much faster way
   for (x=0;x<A3.size(1);x++)
   {
     RefArray<int,2> Z2=A3[x];
     for (y=0;y<A3.size(2);y++)
     {
       RefArray<int,1> Z1=Z2[y];
       for (z=0;z<A3.size(3);z++)
       {
          Z1[z]=++k;

          // Assert that values are the same as when we used iterators above
          assert(Z1[z]==A3[x][y][z]);
          assert(Z1[z]==CopyOfA3[x][y][z]);
       }
     }
   }   

   // Play some games with indexing
   old=A3[1][2][3];
   A3[1][2][3]=1;
   A3[1][++A3[1][2][3]][3]=old;
   assert(A3[1][2][3]==old);

   // Play with standard C Arrays
   typedef int ARR[20][30];
   ARR * MyArr = new ARR[10];
   
   k=0;

   // Traverse a C array
   for (x=0;x<10;x++)
    for (y=0;y<20;y++)
     for (z=0;z<30;z++)
     {
        MyArr[x][y][z]=++k;

        assert(MyArr[x][y][z]==A3[x][y][z]);
     }
 
   // Finished playing with C array
   delete [] MyArr;
   MyArr=NULL;

   // Call some member functions
   int s =A3.size();

   // Use STL non mutating algorithm on entire array
   int * pMaximum=std::max_element(A3.begin(),A3.end());

   // Use STL mutating algorithm on entire array
   std::replace(A3.begin(),A3.end(),10,100);

   // Use STL algorithm on constant Array
   std::count(A5.begin(),A5.end(),1);

   // Traverse RefArray using iterator for faster access
   for (Array<int,3>::iterator az=A3[0].begin(), zz=A3[0].end();az!=zz;az++)
       *az=1;

   // Check the size of a RefArray
   assert(A3[0].size()==600);

   // Try RefArray's size function
   RefArray<int,2> Z2=A3[0];
   assert(Z2.size()==Z2.size(1)*Z2.size(2));

   // Explicit clear
   A3.clear();

   std::cout<<"Done!\r\n";

   return 0;
}
