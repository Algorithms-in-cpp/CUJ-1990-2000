#include <windows.h>
#include <stdio.h>
#include <vector.h>
#include "array.h"


#define SIZEDIM 100
#define REPEATIT 50

using namespace std;

//************************************************************************************
// This is just a test program, to test the speed of the code presented in the article
//************************************************************************************



int main(int argc, char* argv[])
{
   unsigned int k,x,y,z,t;

   DWORD StartTime;
   DWORD EndTime;

   // My 3D array array   
   unsigned int Sizes3[]={SIZEDIM,SIZEDIM,SIZEDIM}; // Array sizes 
   Array<int, 3> A3(Sizes3);      

   // C Array
   typedef int ARR[SIZEDIM][SIZEDIM];
   ARR * MyCArray = NULL;

   // std::vector 3D
   vector< vector< vector<int> > > MyVector(SIZEDIM, vector< vector<int> >(SIZEDIM,vector<int>(SIZEDIM)));

   printf("\r\nTest Allocation and Initialization\r\n\r\n");


   // Allocate standard C array
   StartTime=GetTickCount();
   for (t=0;t<REPEATIT;t++)
   {
      delete [] MyCArray;
      MyCArray = new ARR[SIZEDIM];
      memset(MyCArray,0,sizeof(ARR)*SIZEDIM);
   }
   EndTime=GetTickCount();
   printf("Allocated C Array      : Time=%li\r\n",long(EndTime-StartTime));


   // Allocate a three dimensional std::vector
   StartTime=GetTickCount();
   for (t=0;t<REPEATIT;t++)
   {
      vector< vector< vector<int> > > V(SIZEDIM, vector< vector<int> >(SIZEDIM,vector<int>(SIZEDIM)));
   }
   EndTime=GetTickCount();
   printf("Allocated std::vector  : Time=%li\r\n",long(EndTime-StartTime));




   // Allocate my Array class
   StartTime=GetTickCount();
   for (t=0;t<REPEATIT;t++)
   {
       Array<int, 3> A(Sizes3);
   }
   EndTime=GetTickCount();
   printf("Allocated my Array     : Time=%li\r\n",long(EndTime-StartTime));







   printf("\r\nTest Indexing\r\n\r\n");





   // Index a C array
   StartTime=GetTickCount();
   for (t=0,k=0;t<REPEATIT;t++)
     for (x=0;x<SIZEDIM;x++)
      for (y=0;y<SIZEDIM;y++)
       for (z=0;z<SIZEDIM;z++)
         MyCArray[x][y][z]=++k;
   EndTime=GetTickCount();
   printf("Indexing normal C array: K=%i Time=%li\r\n",int(k),long(EndTime-StartTime));




   // Index an std::vector
   StartTime=GetTickCount();
   for (t=0,k=0;t<REPEATIT;t++)
     for (x=0;x<SIZEDIM;x++)
      for (y=0;y<SIZEDIM;y++)
       for (z=0;z<SIZEDIM;z++)
          MyVector[x][y][z]=++k;
   EndTime=GetTickCount();
   printf("Indexing an std::vector: K=%i Time=%li\r\n",int(k),long(EndTime-StartTime));




   // Index my Array with nested loops
   StartTime=GetTickCount();
   for (t=0,k=0;t<REPEATIT;t++)
     for (x=0;x<SIZEDIM;x++)
       for (y=0;y<SIZEDIM;y++)
         for (z=0;z<SIZEDIM;z++)
           A3[x][y][z]=++k;
   EndTime=GetTickCount(); 
   printf("Index my array normally: K=%i Time=%li\r\n",int(k),long(EndTime-StartTime));




   // Index my Array using the iterator
   StartTime=GetTickCount();
   for (t=0,k=0;t<REPEATIT;t++)
       for (Array<int, 3>::iterator it=A3.begin(), end=A3.end();it<end;it++)
          *it=++k;
   EndTime=GetTickCount();
   printf("Index using iterator   : K=%i Time=%li\r\n",int(k),long(EndTime-StartTime));





   // Index my Array with nested loops in a much faster way
   StartTime=GetTickCount();
   for (t=0,k=0;t<REPEATIT;t++)
     for (x=0;x<SIZEDIM;x++)
     {
       RefArray<int,2> Z2=A3[x];
       for (y=0;y<SIZEDIM;y++)
       {
         RefArray<int,1> Z1=Z2[y];
         for (z=0;z<SIZEDIM;z++)
         { 
            Z1[z]=++k;
         }
       }
   }   
   EndTime=GetTickCount();
   printf("Index with SubArray ref: K=%i Time=%li\r\n",int(k),long(EndTime-StartTime));






   printf("\r\nCompleted Job\r\n");



   // Finished playing with C array
   delete [] MyCArray;
   MyCArray=NULL;

   return 0;
}

