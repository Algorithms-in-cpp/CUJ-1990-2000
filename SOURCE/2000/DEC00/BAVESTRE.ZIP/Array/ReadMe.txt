Generic Resizable N Dimensional Array, by G. Bavestrelli
========================================================

The ZIP file contains five project directories, with five versions of the Array and RefArray classes. If you have Visual C++, only one version will work for you. If you don't have Visual C++, and you have a compiler that adheres well to the latest C++ standard, and specifically supports partial template specialization, you can pick any of the other four versions.

Each subdirectory contains a different version. In each version, file ARRAY.H contains all the class template definitions, and SAMPLE.CPP is just a small test program I used to test the classes.

Note that in the article listings I used class SubArray, while in the code you can download I renamed it into RefArray. I did this as I believe the term RefArray is more appropriate, as it indicates that the class is a reference to an Array (not necessarily a subarray), while I believe the term SubArray is more intuitive, and helps to understand the discussion, so I left it in the article. I did say I renamed SubArray into RefArray close to the end of the article.

The following are the five different versions:

(1) VisualC
This version is the only one that works for Visual C++, and it uses RefArrays nested within class Array, using total specialization.

(2) Standard
This version is the version presented in the article, for Standard C++. Each operator [] returns a new RefArray. The compiler must support partial specialization. It is the simplest and neatest version, but not the fastest.

(3) Faster
This is the version I based on Andrei Alexandrescu's idea, where each RefArray<T,N> inherits from RefArray<T,N-1>, so that subarrays are returned by reference for better efficiency. It also uses partial specialization, and is slightly faster.

(4) Fastest
This is like the above version but here I keep a single RefArray<T,N-1> inside Array<T,N>, so that I return it in Array<T,N>::operator []. All indexing is done by returning the same RefArray<T,N-1> object. This avoids the creation of any RefArray during the indexing process, making the Array very fast. This version is not thread-safe and is potentially dangerous, so I suggest you use one of the other versions in multithreaded Applications, and anyway test it very well.
 
(5) Smaller
This is the standard version with a modification. I derived my Array<T,N> class from RefArray<T,N>. This allowed me to remove a lot of code from class Array, as it is inherited from RefArray, and lets me pass an Array to functions that expect a RefArray. This seems to be a nice solution, but has some defects. Mainly, I cannot add a (virtual) destructor for performance reasons, so this solution is open to misuse. 

In the root directory, you can also find SPEED.CPP, a simple test program I used to test the efficiency of my classes, along with a set of results, in RESULTS.TXT

Version (1) has been tested with Microsoft Visual C++ 6.0, while the other four versions have been tested with Comeau C/C++ 4.2.42 and GNU C++ 2.95.2. From the user point of view, all the five versions of the classes work almost identically. 

An earlier version of the classes was tested also using MetroWerks CodeWarrior. The current version of my classes will not compile correctly with MetroWerks CodeWarrior, until you make (at least) two modifications. You will have to remove "explicit" from the Array constructor, and remove the template arguments "<T,N>" in the definition of constructors and destructors (i.e. Array(){} instead of Array<T,N>(){} ). I did not do these modifications to my code as I believe it is correct the way I did it.

I suggest you read the full article on CUJ's web site, as the article on the printed magazine is not complete. The discussion of the different implementations of the Array classes, contained in the five directories described above, is only in the article on the web. 

I hope you enjoy using the classes as much as I enjoyed developing them. I'd really like receiving your feedback at gbavestrelli@yahoo.com


Giovanni Bavestrelli
