#include <stdio.h>

typedef void (*CallbackFuncPtr)();

void TestCallback(CallbackFuncPtr pFunc)
    {
    pFunc();
    }

int main()
    {
    struct CFoo
        {
        void operator ()()
            {
            printf("test");
            }
        };
    CFoo aFoo;
    TestCallback(aFoo);
    return 0;
    }
