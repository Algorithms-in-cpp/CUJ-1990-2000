#include <stdio.h>

class X
    {
public:
    X()
        {
        }
    X(X const &that)
        {
        if (this == &that)
            throw this;
        }
    };

int main()
    {
    try
        {
        X x1;      // OK
        X x2 = x1; // OK
        X x3 = x3; // throws
        }
    catch (...)
        {
        printf("catch\n");
        }
    }


