#include <stdio.h>

class CFoo
{
public:
    CFoo()
        {
        printf("CFoo::CFoo\n");
        }
    void Func1()
        {
        i = 123;
        printf("CFoo::Func1\n");
        }
private:
    int i;
    };

int main()
    {
    CFoo *pFoo;
    pFoo->Func1();
    return 0;
    }
