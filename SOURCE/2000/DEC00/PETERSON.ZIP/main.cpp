#include <windows.h>
#include <process.h>
#include <iostream>
#include <vector>
#include <assert.h>

using namespace std;

// Thread Base Class
class CThread
{
private:
    HANDLE hThread;
    size_t stackSize;
    bool bAutoDelete;

    virtual void run() = 0;
    static void _cdecl threadFnct(void *pVoid)
    {
        CThread *pData = static_cast<CThread*>(pVoid);
        if(pData != NULL)
        {
            pData->run();
            if(pData->bAutoDelete)
                delete(pData);
        }
    }

protected:
    void setStackSize( size_t s ) { stackSize = s; }

public:
    virtual ~CThread() { }
    CThread()
    {
        hThread = NULL;
        bAutoDelete = false;
        stackSize = 0;
    }
    HANDLE launch(bool bAutoDelete)
    {
        assert(hThread == NULL);
        this->bAutoDelete = bAutoDelete;
        return hThread = 
           (HANDLE)_beginthread(threadFnct, stackSize, this);
    }
    HANDLE handle() { return hThread; }
};

// Test by subclassing the thread base class
class CHelloWorld : public CThread
{
protected:
    virtual void run()
    {
        for(int n = 1; n < 10; n++)
        {
            cout << (10 - n) << " . ";
            Sleep(1000);
        }
        cout << endl << "Hello, World!" << endl;
    }
};

int main()
{
    vector<HANDLE> threads;

    // Test heap allocation
    CHelloWorld *pHello1 = new CHelloWorld;
    threads.push_back( pHello1->launch(true) );

    // Test stack allocation
    CHelloWorld Hello2;
    threads.push_back( Hello2.launch(false) );

    // Wait until both threads terminate
    WaitForMultipleObjects(threads.size(),
        threads.begin(), TRUE, INFINITE);
}


