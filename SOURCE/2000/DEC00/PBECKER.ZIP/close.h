#include <iostream>
#include <limits>
#include <math.h>

template<class FP>
bool close_enough(FP f1, FP f2, int NROUNDS)
{
return abs((f1 - f2) / (f2 == FP(0.0) ? FP(1.0) : f2)
	< FP(NROUNDS) * std::numeric_limits<FP>::epsilon());
}

int main()
{
double tenth = 1.0/10.0;
if (tenth * 10.0 == 1.0)
	std::cout << "equal\n";
else
	std::cout << "not equal\n";
if (close_enough(tenth * 10.0, 1.0, 1))
	std::cout << "equal\n";
else
	std::cout << "not equal\n";
return 0;
}

