#include <ctype.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include "fp.h"

typedef enum
	{
	plus = '+',
	minus = '-',
	star = '*',
	slash = '/',
	lpar = '(',
	rpar = ')',
	number = '0',
	eol = '\0'
	} token;

const token tokens[] =
	{
	plus,
	minus,
	star,
	slash,
	lpar,
	rpar,
	number,
	eol
	};

const char *t_names[] =
	{
	"'+' or '-'",
	"'+' or '-'",
	"'*' or '/'",
	"'*' or '/'",
	"'('",
	"')'",
	"number",
	"end of line"
	};

const char *desc(token tok)
	{
	for (int i = 0; i < sizeof(tokens) / sizeof(*tokens); ++i)
		{
		if (tokens[i] == tok)
			return t_names[i];
		}
	return "unknown";	
	}

static token cur_tok;
static const char *cmd;
static const char *cur_ch;
static double val;

void error(const char *msg1, const char *msg2 = 0)
	{
	std::cerr << "Error: " << msg1 << (msg2 ? msg2 : "") << '\n';
	std::cerr << cmd << '\n';
	std::cerr << std::setw(cur_ch - cmd) << "^" << '\n';
	exit(1);
	}

void expect(token tok)
	{
	if (cur_tok != tok)
		error("expected ", desc(tok));
	}

token parse_number()
	{
	char *end;
	val = strtod(cur_ch, &end);
	cur_ch = end;
	return cur_tok = number;
	}

token next_token()
	{
	while (isspace(*cur_ch))
		++cur_ch;
	if (isdigit(*cur_ch))
		return parse_number();
	else
		return cur_tok = (token)*cur_ch++;	
	}

fp term();

fp expr()
	{
	fp res = fp(1.0);
	switch (cur_tok)
		{
		case lpar:
			next_token();
			res = term();
			expect(rpar);
			break;
		case minus:
			res = fp(-1.0);
		case plus:
			next_token();
		case number:
			res *= fp(val);
			break;
		default:
			expect(number);
		}
	next_token();
	return res;
	}

fp unary()
	{
	fp sign = fp(1.0);
	switch (cur_tok)
		{
		case minus:
			sign = fp(-1.0);
		case plus:
			next_token();
		default:
			return sign * expr();
		}
	}

fp factor()
	{
	fp res = unary();
	for (;;)
		{
		switch (cur_tok)
			{
			case star:
				next_token();
				res *= unary();
				break;
			case slash:
				next_token();
				res /= unary();
				break;
			default:
				return res;
			}
		}
	}

fp term()
	{
	fp res = factor();
	for (;;)
		{
		switch (cur_tok)
			{
			case plus:
				next_token();
				res += factor();
				break;
			case minus:
				next_token();
				res -= factor();
				break;
			default:
				return res;
			}
		}
	}

int main(int argc, char *argv[])
	{
	cmd = argv[1];
	cur_ch = argv[1];
	if (argc != 2)
		error("invalid command line");
	next_token();
	fp res = term();
	expect(eol);
	std::cout << res << std::endl;
	return 0;
	}