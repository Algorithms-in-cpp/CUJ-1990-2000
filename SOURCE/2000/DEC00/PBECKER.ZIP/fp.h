//	class fp

#ifndef FP_H
#define FP_H

#include <iosfwd>
#include <limits>
#include <string>

class fp;
template <> class std::numeric_limits<fp>;

class fp
{	// naive floating point implementation

public:

	fp();
	explicit fp(const char *);
	explicit fp(double);
	
	fp& operator += (const fp&);
	fp& operator -= (const fp&);
	fp& operator *= (const fp&);
	fp& operator /= (const fp&);
	friend fp operator - (const fp&);
	bool neg() const { return is_neg; }
	
	friend bool operator == (const fp&, const fp&);
	friend bool operator != (const fp&, const fp&);
	friend bool operator <  (const fp&, const fp&);
	friend bool operator <= (const fp&, const fp&);
	friend bool operator >  (const fp&, const fp&);
	friend bool operator >= (const fp&, const fp&);

	static const fp zero;
	static const fp one;
	static const fp two;

	friend std::string to_string(const fp&);
	friend std::ostream& operator << (std::ostream&, const fp&);

	enum round_mode
		{	// rounding direction
		rm_nearest,
		rm_down,
		rm_up,
		rm_zero
		};
	static void set_round(round_mode m) {rm = m;}
	static round_mode get_round() {return rm;}

	enum fp_exception
		{	// bit flags to identify exceptions
		div_by_zero		= 0x01,
		exp_underflow	= 0x02,
		exp_overflow	= 0x04,
		inexact			= 0x08,
		invalid			= 0x10
		};
	typedef fp (*exc_hnd)(fp_exception, fp);
	static void set_flag(fp_exception);
	static bool get_flag(fp_exception);
	static void clear_flags();
	static void set_flags(int);
	static int get_flags();
	static exc_hnd set_handler(fp_exception, exc_hnd);
	static exc_hnd get_handler(fp_exception);

	enum cmp_res { cmp_lt, cmp_eq, cmp_gt, cmp_un };
	static cmp_res cmp(const fp&, const fp&);

	static bool eq(const fp& f1, const fp& f2);
	static bool ne(const fp& f1, const fp& f2);
	static bool gt(const fp& f1, const fp& f2);
	static bool ge(const fp& f1, const fp& f2);
	static bool lt(const fp& f1, const fp& f2);
	static bool le(const fp& f1, const fp& f2);
	static bool un(const fp& f1, const fp& f2);
	static bool lg(const fp& f1, const fp& f2);
	static bool leg(const fp& f1, const fp& f2);
	static bool ug(const fp& f1, const fp& f2);
	static bool uge(const fp& f1, const fp& f2);
	static bool ul(const fp& f1, const fp& f2);
	static bool ule(const fp& f1, const fp& f2);
	static bool ue(const fp& f1, const fp& f2);
	
private:
	friend class std::numeric_limits<fp>;
	fp(int e, int f, bool neg);

	fp& add(const fp&, const fp&);
	fp& normalize(int, long);
	bool round(long&);
	void convert(double);
	long lf() const;
	
	enum fpx
		{ dbz, exu, exo, ine, inv, EXC_COUNT };
	static fpx to_fpx(fp_exception);
	static fp exception(fpx, fp);

	bool is_neg;
	unsigned char exp;
	int frac;

	static round_mode rm;
	static exc_hnd exc_hndlrs[EXC_COUNT];
	static const exc_hnd def_hndlrs[EXC_COUNT];
	static unsigned char exc_flg;
	
	static const fp pinf;
	static const fp ninf;
	static const fp qnan;
	static const fp snan;
	static const fp pmax;
	static const fp nmax;
	static const fp nzero;
	
	static fp ex_dbz(fp_exception, fp);
	static fp ex_exu(fp_exception, fp);
	static fp ex_exo(fp_exception, fp);
	static fp ex_ine(fp_exception, fp);
	static fp ex_inv(fp_exception, fp);

	friend fp def_dbz(fp_exception, fp);
	friend fp def_exu(fp_exception, fp);
	friend fp def_exo(fp_exception, fp);
	friend fp def_ine(fp_exception, fp);
	friend fp def_inv(fp_exception, fp);
	
	friend class std::numeric_limits<fp>;
};

fp operator + (const fp&, const fp&);
fp operator - (const fp&, const fp&);
fp operator * (const fp&, const fp&);
fp operator / (const fp&, const fp&);

inline bool operator == (const fp& f1, const fp& f2)
	{	// return f1 equal to f2
	return fp::eq(f1, f2);
	}

inline bool operator != (const fp& f1, const fp& f2)
	{	// return f1 not equal to f2
	return fp::ne(f1, f2);
	}

inline bool operator <  (const fp& f1, const fp& f2)
	{	// return f1 less than f2
	return fp::lt(f1, f2);
	}

inline bool operator <= (const fp& f1, const fp& f2)
	{	// return f1 less than or equal to f2
	return fp::le(f1, f2);
	}

inline bool operator >  (const fp& f1, const fp& f2)
	{	// return f1 greater than f2
	return fp::gt(f1, f2);
	}

inline bool operator >= (const fp& f1, const fp& f2)
	{	// return f1 greater than or equal to f2
	return fp::ge(f1, f2);
	}

inline bool not_gt(const fp& f1, const fp& f2)
	{ return !fp::gt(f1, f2); }
inline bool not_ge(const fp& f1, const fp& f2)
	{ return !fp::ge(f1, f2); }
inline bool not_lt(const fp& f1, const fp& f2)
	{ return !fp::lt(f1, f2); }
inline bool not_le(const fp& f1, const fp& f2)
	{ return !fp::le(f1, f2); }
inline bool not_un(const fp& f1, const fp& f2)
	{ return !fp::un(f1, f2); }
inline bool not_lg(const fp& f1, const fp& f2)
	{ return !fp::lg(f1, f2); }
inline bool not_leg(const fp& f1, const fp& f2)
	{ return !fp::leg(f1, f2); }
inline bool not_ug(const fp& f1, const fp& f2)
	{ return !fp::ug(f1, f2); }
inline bool not_uge(const fp& f1, const fp& f2)
	{ return !fp::uge(f1, f2); }
inline bool not_ul(const fp& f1, const fp& f2)
	{ return !fp::ul(f1, f2); }
inline bool not_ule(const fp& f1, const fp& f2)
	{ return !fp::ule(f1, f2); }
inline bool not_ue(const fp& f1, const fp& f2)
	{ return !fp::ue(f1, f2); }

template <> class std::numeric_limits<fp>
{	// specialization of std::numeric_limits for class fp
public:
	static const bool is_specialized = true;
	static fp min()
		{	// return minimum normalized value
		return fp(min_exponent, 0x4000, false);
		}
	static fp max()
		{	// return maximum finite value
		return fp(max_exponent, 0x7fff, false);
		}
	static const int digits = 15;
	static const int digits10 = 4;
	static const bool is_signed = true;
	static const bool is_integer = false;
	static const bool is_exact = false;
	static const int radix = 2;
	static fp epsilon()
		{	// return f - 1.0, where f is smallest value
			// greater than 1.0 that can be represented
		return fp(-13, 0x4000, false);
		}
	static fp round_error()
		{	// return estimate of the maximum rounding error
		return fp(0.5);
		}

	static const int min_exponent = -128;
	static const int min_exponent10 = -38;
	static const int max_exponent = 127;
	static const int max_exponent10 = 38;

	static const bool has_infinity = true;
	static const bool has_quiet_NaN = true;
	static const bool has_signaling_NaN = true;
	static const std::float_denorm_style has_denorm = std::denorm_absent;
	static const bool has_denorm_loss = false;
	static fp infinity() throw() { return fp::pinf; }
	static fp quiet_NaN() throw() { return fp::qnan; }
	static fp signaling_NaN() throw() { return fp::snan; }
	static fp denorm_min()
		{	// return minimum denormalized value
		return fp(min_exponent, 0x0001, false);
		}

	static const bool is_iec559 = true;
	static const bool is_bounded = false;
	static const bool is_modulo = false;

	static const bool traps = true;
	static const bool tinyness_before = false;
	static const std::float_round_style round_style = std::round_to_nearest;
};

#endif	/* FP_H */
