#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <sstream>
#include "fp.h"

const int BIAS = 127;
const int MIN_EXP = 0;
const int MAX_EXP = 255;
const int P = 15;
const long MIN_NORM = 1L << (P - 1);
const long ONE = 1L << P;
const int QF = 1;
const int SF = 2;

#define IS_ZERO(fp) ((fp).exp == 0 && (fp).frac == 0)
#define IS_INF(fp) ((fp).exp == MAX_EXP && (fp).frac == 0)
#define IS_QNAN(fp) ((fp).exp == MAX_EXP && (fp).frac == QF)
#define IS_SNAN(fp) ((fp).exp == MAX_EXP && (fp).frac == SF)
#define IS_NAN(fp) ((fp).exp == MAX_EXP && (fp).frac != 0)

#define ARG(x) (IS_SNAN(x) ? exception(inv, x) : x)

inline long fp::lf() const
	{	// sign-extend fraction and convert to long
	return long(is_neg ? -frac : frac);
	}

fp::fp()
	{	// construct
	convert(0.0);
	}

fp::fp(const char *str)
	{	// construct from string
	convert(strtod(str, NULL));
	}

fp::fp(double d)
	{	// construct from double
	convert(d);
	}

fp::fp(int e, int f, bool neg)
	{	// construct from exponent, fraction, and sign
	is_neg = neg;
	frac = f;
	exp = e + BIAS;
	}

bool fp::eq(const fp& f1, const fp& f2)
	{	// return true if f1 equals f2
	return cmp(ARG(f1), ARG(f2)) == cmp_eq;
	}

bool fp::ne(const fp& f1, const fp& f2)
	{	// return true if f1 does not equal f2
	return cmp(ARG(f1), ARG(f2)) != cmp_eq;
	}

bool fp::gt(const fp& f1, const fp& f2)
	{	// return true if f1 is greater than f2
	cmp_res res = cmp(ARG(f1), ARG(f2));
	if (res == cmp_un)
		exception(inv, f1);
	return res == cmp_gt;	
	}

bool fp::ge(const fp& f1, const fp& f2)
	{	// return true if f1 is greater than or equal to f2
	cmp_res res = cmp(ARG(f1), ARG(f2));
	if (res == cmp_un)
		exception(inv, f1);
	return res == cmp_gt || res == cmp_eq;	
	}

bool fp::lt(const fp& f1, const fp& f2)
	{	// return true if f1 is less than f2
	cmp_res res = cmp(ARG(f1), ARG(f2));
	if (res == cmp_un)
		exception(inv, f1);
	return res == cmp_lt;
	}

bool fp::le(const fp& f1, const fp& f2)
	{	// return true if f1 is less than or equal to f2
	cmp_res res = cmp(ARG(f1), ARG(f2));
	if (res == cmp_un)
		exception(inv, f1);
	return res == cmp_lt || res == cmp_eq;	
	}

bool fp::un(const fp& f1, const fp& f2)
	{
	return cmp(ARG(f1), ARG(f2)) == cmp_un;
	}

bool fp::lg(const fp& f1, const fp& f2)
	{
	cmp_res res = cmp(ARG(f1), ARG(f2));
	if (res == cmp_un)
		exception(inv, f1);
	return res == cmp_lt || res == cmp_gt;	
	}

bool fp::leg(const fp& f1, const fp& f2)
	{
	cmp_res res = cmp(ARG(f1), ARG(f2));
	if (res == cmp_un)
		exception(inv, f1);
	return res == cmp_lt || res == cmp_eq || res == cmp_gt;
	}

bool fp::ug(const fp& f1, const fp& f2)
	{
	cmp_res res = cmp(ARG(f1), ARG(f2));
	return res == cmp_un || res == cmp_gt;
	}

bool fp::uge(const fp& f1, const fp& f2)
	{
	cmp_res res = cmp(ARG(f1), ARG(f2));
	return res == cmp_un || res == cmp_gt || res == cmp_eq;
	}

bool fp::ul(const fp& f1, const fp& f2)
	{
	cmp_res res = cmp(ARG(f1), ARG(f2));
	return res == cmp_un || res == cmp_lt;
	}

bool fp::ule(const fp& f1, const fp& f2)
	{
	cmp_res res = cmp(ARG(f1), ARG(f2));
	return res == cmp_un || res == cmp_lt || res == cmp_eq;
	}

bool fp::ue(const fp& f1, const fp& f2)
	{
	cmp_res res = cmp(ARG(f1), ARG(f2));
	return res == cmp_un || res == cmp_eq;
	}

fp::cmp_res fp::cmp(const fp& f1, const fp& f2)
	{
	if (IS_NAN(f1) || IS_NAN(f2))
		return cmp_un;
	else if (IS_ZERO(f1) && IS_ZERO(f2)
		|| f1.is_neg == f2.is_neg && f1.frac == f2.frac && f1.exp == f2.exp)
		return cmp_eq;
	else if (f1.is_neg != f2.is_neg)
		return f1.is_neg ? cmp_lt : cmp_gt;
	else if (f1.exp != f2.exp)
		return f1.exp < f2.exp != f1.is_neg ? cmp_lt : cmp_gt;
	else
		return f1.frac < f2.frac != f1.is_neg ? cmp_lt : cmp_gt;
	}

fp operator + (const fp& f1, const fp& f2)
	{	// add f1 to f2
	fp res = f1;
	res += f2;
	return res;
	}

fp& fp::operator += (const fp& f)
	{	// add f to this fp object
	return f.exp <= exp
		? add(ARG(*this), ARG(f))
		: add(ARG(f), ARG(*this));	
	}

fp operator - (const fp& f1, const fp& f2)
	{	// subtract f2 from f1
	fp res = f1;
	return res -= f2;
	}

fp& fp::operator -= (const fp& f)
	{	// subtract f from this fp object
	return f.exp <= exp
		? add(ARG(*this), -ARG(f))
		: add(-ARG(f), ARG(*this));	
	}

fp operator - (const fp& f)
	{	// negate f
	return fp(f.exp - BIAS, f.frac, !f.is_neg);
	}

fp operator * (const fp& f1, const fp& f2)
	{	// multiply f1 by f2
	fp res = f1;
	res *= f2;
	return res;
	}

fp& fp::operator *= (const fp& f)
	{	// multiply this fp object by f
	fp f1 = ARG(*this);
	fp f2 = ARG(f);
	if (IS_NAN(f1))
		*this = f1;
	else if (IS_NAN(f2))
		*this = f2;
	else if (IS_INF(f1) && IS_ZERO(f2) || IS_ZERO(f1) && IS_INF(f2))
		*this = exception(inv, f1);
	else if (IS_ZERO(f1))
		f1.is_neg = f1.is_neg != f2.is_neg;
	else if (IS_ZERO(f2))
		{	// handle zero second argument
		exp = 0;
		frac = 0;
		is_neg = is_neg != f2.is_neg;
		}
	else if (IS_INF(f1) || IS_INF(f2))
		*this = f1.is_neg == f2.is_neg ? pinf : ninf;
	else
		normalize(f1.exp + f2.exp - BIAS, f1.lf() * f2.lf());
	return *this;	
	}

fp operator / (const fp& f1, const fp& f2)
	{	// divide f1 by f2
	fp res = f1;
	res /= f2;
	return res;
	}

fp& fp::operator /= (const fp& f)
	{	// divide this fp object by f
	fp f1 = ARG(*this);
	fp f2 = ARG(f);
	if (IS_NAN(f1))
		*this = f1;
	else if (IS_NAN(f2))
		*this = f2;
	else if (IS_INF(f1) && IS_INF(f2) || IS_ZERO(f1) && IS_ZERO(f2))
		*this = exception(inv, f1);
	if (IS_ZERO(f1))
		f1.is_neg = f1.is_neg != f2.is_neg;
	else if (IS_ZERO(f2))
		*this = exception(dbz, f1);
	else if (IS_INF(f1))
		*this = f1.is_neg == f2.is_neg ? pinf : ninf;
	else if (IS_INF(f2))
		*this = f1.is_neg == f2.is_neg ? zero : nzero;
	else
		normalize(f1.exp - f2.exp + BIAS,
			((f1.lf() << P) / f2.lf()) << P);
	return *this;	
	}

fp& fp::add(const fp& f1, const fp& f2)
	{	// set this object to sum of f1 and f2
	if (IS_NAN(f1))
		*this = f1;
	else if (IS_NAN(f2))
		*this = f2;
	else if (IS_INF(f1) && IS_INF(f2) && f1.is_neg != f2.is_neg)
		*this = exception(inv, f1);
	else if (IS_INF(f1))
		*this = f1;
	else if (IS_INF(f2))
		*this = f2;
	else
		{	// compute sum
		long fracr = f1.lf() << P;
		if (f1.exp - f2.exp < P + 2)
			fracr += ((f2.lf() << P) >> (f1.exp - f2.exp));
		normalize(f1.exp, fracr);
		}
	return *this;	
	}

void fp::convert(double d)
	{	// convert double to fp object
	int e;
	double f = frexp(d, &e);
	if (f == 0.0)
		{	// handle zero specially
		exp = 0;
		frac = 0;
		is_neg = false;
		}
	else
		normalize(e + BIAS, long(f * (1L << P)) << P);
	}

fp& fp::normalize(int e, long fr)
	{	// set this object to normalized value of
		// exponent e and fraction fr
	if (fr == 0)
		{	// handle zero specially
		exp = 0;
		frac = 0;
		return *this;
		}
	is_neg = fr < 0;
	fr = abs(fr);
	if ((ONE << P) <= fr)
		{	// handle fraction overflow
		fr >>= 1;
		++e;
		}
	else
		while (fr < (MIN_NORM << P))
			{	// scale left
			fr <<= 1;
			--e;
			}
	bool inx = round(fr);
	if ((ONE << P) <= fr)
		{	// handle fraction overflow
		fr >>= 1;
		++e;
		}
	if (e < MIN_EXP)
		*this = inx ? exception(exu, fp(e - BIAS + 192, fr >> P, is_neg))
			: fp(0 - BIAS, fr >> (P - e), is_neg);
	else	
		*this =
			MAX_EXP <= e ? exception(exo, fp(e - BIAS - 192, fr >> P, is_neg))
			: inx 		 ? exception(ine, fp(e - BIAS, fr >> P, is_neg))
			: fp(e - BIAS, fr >> P, is_neg);
	return *this;
	}

inline long low_bits(long fr)
	{	// return bits that will be discarded when truncated
	return fr & ((1L << P) - 1);
	}

bool fp::round(long& fr)
	{	// round infinite-precision result to fit representation
	bool inx = low_bits(fr) != 0;
	switch (rm)
		{	// select appropriate code for rounding mode
		case rm_zero:
			// empty
			break;
		case rm_up:
			if (!is_neg && low_bits(fr))
				fr += 1L << P;
			break;
		case rm_down:
			if (is_neg && low_bits(fr))
				fr += 1L << P;
			break;
		case rm_nearest:
			if ((fr & (1L << (P - 1))) == 0)
				;
			else if (low_bits(fr) == (1L << (P - 1))
				&& ((fr & (1L << P)) == 0))
				;
			else	
				fr += 1L << P;
			break;
		}
	return inx;
	}

std::ostream& operator << (std::ostream& out, const fp& f)
	{	// insert into stream
	double d;
	if (IS_NAN(f))
		return out << "NaN " << to_string(f);
	else if (IS_INF(f))
		return out << (f.is_neg ? "-" : "") << "Inf " << to_string(f);
	else if (IS_ZERO(f))
		d = 0.0;
	else
		{	// convert non-zero value to double
		d = f.frac;
		d /= (1 << P);
		int e = f.exp - BIAS;
		if (e == 0)
			;
		else if (e < 0)
			for (int i = 0; i < -e; ++i)
				d /= 2;
		else	
			for (int i = 0; i < e; ++i)
				d *= 2;
		if (f.is_neg)
			d = -d;
		}
	return out << d << ' ' << to_string(f);
	}

std::string to_string(const fp& f)
	{	// convert to text representation of internal data
	std::ostringstream str;
	str << '(' << (f.is_neg ? "-," : "+,")
		<< (int)(f.exp - BIAS) << ','
		<< std::hex << f.frac << std::dec << ')';
	return str.str();
	}

fp::round_mode fp::rm = fp::rm_nearest;

void fp::set_flag(fp_exception except)
	{	// set the exception flag corresponding to except
	exc_flg |= except;
	}

bool fp::get_flag(fp_exception except)
	{	// return true if the exception flag corresponding
		// to except is on
	return (exc_flg & except) != 0;
	}

void fp::clear_flags()
	{	// clear all exception flags
	exc_flg = 0;
	}

void fp::set_flags(int flg)
	{	// set all exception flags to match flg
	exc_flg = flg & 0xff;
	}

int fp::get_flags()
	{	// return exception flags
	return exc_flg;
	}

fp fp::exception(fpx except, fp arg)
	{	// handle floating point exceptions
	return exc_hndlrs[except]((fp_exception)(1 << except), arg);
	}

const fp fp::pinf(MAX_EXP - BIAS, 0, false);
const fp fp::ninf(MAX_EXP - BIAS, 0, true);
const fp fp::qnan(MAX_EXP - BIAS, QF, false);
const fp fp::snan(MAX_EXP - BIAS, SF, false);
const fp fp::pmax(MAX_EXP - BIAS - 1, 0x7fff, false);
const fp fp::nmax(MAX_EXP - BIAS - 1, 0x7fff, true);
const fp fp::nzero(BIAS, 0, true);

fp fp::ex_dbz(fp::fp_exception except, fp arg)
	{	// handle divide by zero exception
	set_flag(except);
	return arg.is_neg ? fp::ninf : fp::pinf;
	}

fp fp::ex_exu(fp::fp_exception except, fp arg)
	{	// handle underflow exception
	set_flag(except);
	int ex = arg.exp - BIAS - 192;
	int fr = arg.frac;
	while (ex < 0)
		{	// denormalize
		++ex;
		fr /= 2;
		}
	return fp(ex - BIAS, fr, arg.is_neg);
	}

fp fp::ex_exo(fp::fp_exception except, fp arg)
	{	// handle overflow exception
	set_flag(except);
	return rm == rm_nearest
			? arg.is_neg ? ninf : pinf
		: rm == rm_zero
			? arg.is_neg ? nmax : pmax
		: rm == rm_down
			? arg.is_neg ? ninf : pmax
			: arg.is_neg ? nmax : pinf;
	}

fp fp::ex_ine(fp::fp_exception except, fp arg)
	{	// handle inexact exception
	set_flag(except);
	return arg;
	}

fp fp::ex_inv(fp::fp_exception except, fp)
	{	// handle invalid exception
	set_flag(except);
	return qnan;
	}

static fp def_dbz(fp::fp_exception except, fp arg)
	{	// default handler for divide by zero exception
	return fp::ex_dbz(except, arg);
	}

static fp def_exu(fp::fp_exception except, fp arg)
	{	// default handler for underflow exception
	return fp::ex_exu(except, arg);
	}

static fp def_exo(fp::fp_exception except, fp arg)
	{	// default handler for overflow exception
	return fp::ex_exo(except, arg);
	}

static fp def_ine(fp::fp_exception except, fp arg)
	{	// default handler for inexact exception
	return fp::ex_ine(except, arg);
	}

static fp def_inv(fp::fp_exception except, fp arg)
	{	// default handler for invalid exception
	return fp::ex_inv(except, arg);
	}

static inline fp::fpx fp::to_fpx(fp::fp_exception exc)
	{	// translate exception bit flag to table index
	return exc & div_by_zero ? dbz
		: exc & exp_underflow ? exu
		: exc & exp_overflow ? exo
		: exc & inexact ? ine
		: inv;
	}

fp::exc_hnd fp::set_handler(fp::fp_exception except, fp::exc_hnd hnd)
	{	// install user-specified exception handler
	fpx exc = to_fpx(except);
	exc_hnd prev = exc_hndlrs[exc];
	exc_hndlrs[exc] = hnd ? hnd : def_hndlrs[exc];
	return prev == def_hndlrs[exc] ? 0 : prev;
	}

fp::exc_hnd fp::get_handler(fp_exception except)
	{	// return pointer to user-specified exception handler
	fpx exc = to_fpx(except);
	return exc_hndlrs[exc] == def_hndlrs[exc]
		? 0 : exc_hndlrs[exc];
	}

fp::exc_hnd fp::exc_hndlrs[EXC_COUNT] =
	{ def_dbz, def_exu, def_exo, def_ine, def_inv };

const fp::exc_hnd fp::def_hndlrs[EXC_COUNT] =
	{ def_dbz, def_exu, def_exo, def_ine, def_inv };

unsigned char fp::exc_flg;

const fp fp::zero(0.0);
const fp fp::one(1.0);
const fp fp::two(2.0);
