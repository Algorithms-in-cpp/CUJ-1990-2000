//////////////////////////////////////////////////////////////////////
//
//  Component.h
//
//  Base class of a component in a network.
//
//  Michael L Perry
//  3/21/00
//

#if !defined(AFX_COMPONENT_H__9FA8C68C_FF6E_11D3_9D65_444553540000__INCLUDED_)
#define AFX_COMPONENT_H__9FA8C68C_FF6E_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CEqSystem;

class CComponent  
{
public:
	CComponent();
	virtual ~CComponent();

	virtual void AddToSystemPrimary( CEqSystem &rSystem ) = 0;
	virtual void AddToSystemSecondary( CEqSystem &rSystem );
    virtual void Dump() = 0;
};

#endif // !defined(AFX_COMPONENT_H__9FA8C68C_FF6E_11D3_9D65_444553540000__INCLUDED_)
