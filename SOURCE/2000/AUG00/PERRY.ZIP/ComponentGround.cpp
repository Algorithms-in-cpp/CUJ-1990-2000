//////////////////////////////////////////////////////////////////////
//
//  ComponentGround.cpp
//
//  Ground component in a network.
//
//  Michael L Perry
//  3/21/00
//

#include "stdhdr.h"
#include "ComponentGround.h"

CComponentGround::CComponentGround()
{
}

CComponentGround::~CComponentGround()
{
}

void CComponentGround::Dump()
{
    Trace( "Ground:\n" );
    Trace( "  Current: " );
    Trace( m_pLeg->GetCurrent() );
    Trace( ".\n" );
}

double CComponentGround::CalculateValue()
{
    // EMF must be zero.
    return m_pLeg->GetEMF();
}

bool CComponentGround::DependsUpon(IEqUnknown *pUnknown)
{
    // Equation depends upon EMF only.
    return m_pLeg->RepresentsEMF( pUnknown );
}
