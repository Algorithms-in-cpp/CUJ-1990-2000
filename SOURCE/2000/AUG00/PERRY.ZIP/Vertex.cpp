//////////////////////////////////////////////////////////////////////
//
//  Vertex.cpp
//
//  A point of inconnection within a network.
//
//  Michael L Perry
//  3/21/00
//

#include <stdhdr.h>
#include "Vertex.h"

double LegStruct::GetValue()
{
    // The leg represents an unknown current in the equations.
    return dCurrent;
}

void LegStruct::SetValue(double dValue)
{
    dCurrent = dValue;
}

CVertex::CVertex() :
    m_dEMF(0.0)
{
}

CVertex::~CVertex()
{
    // Delete all remaining legs.
    LegStructList::iterator itLegStruct;
    for ( itLegStruct = m_lLegs.begin();
        itLegStruct != m_lLegs.end();
        itLegStruct++ )
    {
        delete (*itLegStruct)->pLeg;
        delete *itLegStruct;
    }
}

CLeg * CVertex::NewLeg()
{
    // Create a new leg and add it to the list.
    LegStruct *pLegStruct = new LegStruct;
    pLegStruct->pLeg = new CLeg( this );
    pLegStruct->dCurrent = 0.0;
    m_lLegs.push_back( pLegStruct );
    return pLegStruct->pLeg;
}

void CVertex::ReleaseLeg(CLeg *pLeg)
{
    LegStructList::iterator itLegStruct = FindLegStruct( pLeg );

    ASSUMING ( itLegStruct != m_lLegs.end() )
    {
        // Remove the leg from the list and delete.
        delete (*itLegStruct)->pLeg;
        delete *itLegStruct;
        m_lLegs.erase( itLegStruct );
    }
}

double CVertex::GetEMF()
{
    return m_dEMF;
}

double CVertex::GetCurrent( CLeg *pLeg )
{
    LegStructList::iterator itLegStruct = FindLegStruct( pLeg );

    ASSUMING ( itLegStruct != m_lLegs.end() )
    {
        if ( *itLegStruct == m_lLegs.back() )
        {
            // Enforce Kirchhoff's first law.
            double dCurrent = 0.0;
            for ( itLegStruct = m_lLegs.begin();
                (*itLegStruct)->pLeg != pLeg;
                itLegStruct++ )
            {
                dCurrent -= (*itLegStruct)->dCurrent;
            }
            return dCurrent;
        }
        else
        {
            // Get the current through the selected leg.
            return (*itLegStruct)->dCurrent;
        }
    }
    return 0.0;
}

bool CVertex::RepresentsEMF(IEqUnknown *pUnknown)
{
    // The vertex itself represents EMF.
    return pUnknown == this;
}

bool CVertex::RepresentsCurrent(CLeg *pLeg, IEqUnknown *pUnknown)
{
    LegStructList::iterator itLegStruct = FindLegStruct( pLeg );

    ASSUMING ( itLegStruct != m_lLegs.end() )
    {
        if ( *itLegStruct == m_lLegs.back() )
        {
            // Current through the last leg depends upon
            // all others.
            for ( itLegStruct = m_lLegs.begin();
                (*itLegStruct)->pLeg != pLeg;
                itLegStruct++ )
            {
                if ( *itLegStruct == pUnknown )
                    return true;
            }
            return false;
        }
        else
        {
            // Each leg structure represents an unknown current.
            return *itLegStruct == pUnknown;
        }
    }
    return false;
}

void CVertex::AddToSystemPrimary( CEqSystem &rSystem )
{
    ASSUMING ( !m_lLegs.empty() )
    {
        // Add unknowns for EMF and all but the last current.
        // The last current is calculated to enforce
        // Kirchhoff's first law.
        rSystem.AddUnknown( this );    // for EMF.
        LegStruct *pLastLeg = m_lLegs.back();
        LegStructList::iterator itLegStruct;
        for ( itLegStruct = m_lLegs.begin();
            *itLegStruct != pLastLeg;
            itLegStruct++ )
        {
            rSystem.AddUnknown( *itLegStruct );
        }
    }
}

double CVertex::GetValue()
{
    // The vertex represents an unknown EMF in the equations.
    return m_dEMF;
}

void CVertex::SetValue(double dValue)
{
    m_dEMF = dValue;
}

CVertex::LegStructList::iterator CVertex::FindLegStruct( CLeg *pLeg )
{
    // Find the leg struct that contains this leg.
    LegStructList::iterator itLegStruct;
    for ( itLegStruct = m_lLegs.begin();
        itLegStruct != m_lLegs.end();
        itLegStruct++ )
    {
        if ( (*itLegStruct)->pLeg == pLeg )
            break;
    }
    return itLegStruct;
}
