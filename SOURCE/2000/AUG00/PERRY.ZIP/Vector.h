//////////////////////////////////////////////////////////////////////
//
//  Vector.h
//
//  An nx1 vector of numbers.
//
//  Michael L Perry
//  8/29/99
//

#if !defined(AFX_VECTOR_H__6DB32DE4_5E20_11D3_9D65_444553540000__INCLUDED_)
#define AFX_VECTOR_H__6DB32DE4_5E20_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// Vector class.
// Represents a column of doubles.
class CVector
{
public:
    // Default, copy, and sizing constructors.
    CVector();
    CVector(const CVector &that);
    CVector(int nSize);
    ~CVector();

    // Comparison and assignment operators.
    bool operator ==(const CVector &that) const;
    bool operator !=(const CVector &that) const;
    const CVector &operator =(const CVector &that);

    // Get the size of the matrix.
    int Size() const;

    // Get and set elements.
    double operator()(int nRow) const;
    double &operator()(int nRow);

    // Other operators.
    CVector operator -() const;
    CVector operator +(const CVector &that) const;
    CVector operator -(const CVector &that) const;
    double InnerProduct(const CVector &that) const;

    void Dump() const;

private:
    // Put the data into a shared structure for lazy copy.
    class CVectorData
    {
    public:
        // Default, copy, and sizing constructors.
        CVectorData();
        CVectorData(const CVectorData &that);
        CVectorData(int nSize);
        ~CVectorData();

        // Reference counting.
        void AddRef();
        void Release();
        bool IsShared() const;

        // Get the size of the vector.
        int Size() const;

        // Comparison.
        bool Equals(const CVectorData *pThat);

        // Get and set elements.
        double Element(int nRow) const;
        double &Element(int nRow);
    private:
        int     m_nSize;
        double *m_pElements;

        int     m_nRefCount;
    } *m_pVectorData;
};

CVector operator *(double dScalar, const CVector &vVector);

#endif // !defined(AFX_VECTOR_H__6DB32DE4_5E20_11D3_9D65_444553540000__INCLUDED_)
