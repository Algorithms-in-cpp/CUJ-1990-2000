//////////////////////////////////////////////////////////////////////
//
//  ComponentResistor.cpp
//
//  Resistor component in a network.
//
//  Michael L Perry
//  3/21/00
//

#include "stdhdr.h"
#include "ComponentResistor.h"

CComponentResistor::CComponentResistor() :
    m_dResistance( 1.0 )
{
}

CComponentResistor::~CComponentResistor()
{
}

double CComponentResistor::GetResistance()
{
    return m_dResistance;
}

void CComponentResistor::SetResistance( double dResistance )
{
    m_dResistance = dResistance;
}

void CComponentResistor::Dump()
{
    Trace( "Resistor:\n" );
    Trace( "  Resistance: " );
    Trace( m_dResistance );
    Trace( ".\n" );
    Trace( "  Current: " );
    Trace( m_pLeg1->GetCurrent() );
    Trace( ".\n" );
}

double CComponentResistor::CalculateValueEMF()
{
    // Ohms law.
    return m_pLeg1->GetCurrent() * m_dResistance -
        m_pLeg1->GetEMF() + m_pLeg2->GetEMF();
}

bool CComponentResistor::DependsUponEMF(IEqUnknown *pUnknown)
{
    // Equation depends upon one current and both EMFs.
    return
        m_pLeg1->RepresentsCurrent( pUnknown ) ||
        m_pLeg1->RepresentsEMF( pUnknown ) ||
        m_pLeg2->RepresentsEMF( pUnknown );
}
