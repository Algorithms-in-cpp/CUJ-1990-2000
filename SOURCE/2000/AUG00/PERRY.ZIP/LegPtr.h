//////////////////////////////////////////////////////////////////////
//
//  LegPtr.h
//
//  Smart pointer to a leg.
//
//  Michael L Perry
//  3/21/00
//

#if !defined(AFX_LEGPTR_H__9FA8C691_FF6E_11D3_9D65_444553540000__INCLUDED_)
#define AFX_LEGPTR_H__9FA8C691_FF6E_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Vertex.h"
#include "Leg.h"

class CLegPtr
{
public:
	CLegPtr();
	virtual ~CLegPtr();

	void Attach( CVertex *pVertex );
    operator bool();
    CLeg *operator->();

private:
    CVertex *m_pVertex;
    CLeg *m_pLeg;
};

#endif // !defined(AFX_LEGPTR_H__9FA8C691_FF6E_11D3_9D65_444553540000__INCLUDED_)
