//////////////////////////////////////////////////////////////////////
//
//  LegPtr.cpp
//
//  Smart pointer to a leg.
//
//  Michael L Perry
//  3/21/00
//

#include "stdhdr.h"
#include "LegPtr.h"

CLegPtr::CLegPtr() :
    m_pVertex( NULL ),
    m_pLeg( NULL )
{
}

CLegPtr::~CLegPtr()
{
    if ( m_pVertex )
        m_pVertex->ReleaseLeg( m_pLeg );
}

void CLegPtr::Attach(CVertex *pVertex)
{
    // First detach from the previous vertex.
    if ( m_pVertex )
        m_pVertex->ReleaseLeg( m_pLeg );

    m_pLeg = NULL;
    m_pVertex = pVertex;

    // Attach to the next vertex.
    if ( m_pVertex )
        m_pLeg = m_pVertex->NewLeg();
}

CLegPtr::operator bool()
{
    return m_pLeg != NULL;
}

CLeg *CLegPtr::operator->()
{
    ASSERT( m_pLeg != NULL );
    return m_pLeg;
}
