//////////////////////////////////////////////////////////////////////
//
//  Component.cpp
//
//  Base class of a component in a network.
//
//  Michael L Perry
//  3/21/00
//

#include "stdhdr.h"
#include "Component.h"

CComponent::CComponent()
{
}

CComponent::~CComponent()
{
}

void CComponent::AddToSystemSecondary( CEqSystem &rSystem )
{
    // No secondary constraints required.
}
