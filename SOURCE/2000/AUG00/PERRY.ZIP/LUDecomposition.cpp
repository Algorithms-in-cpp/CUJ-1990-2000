//////////////////////////////////////////////////////////////////////
//
//  LUDecomposition.cpp
//
//  An LU decomposition of a matrix.
//
//  Michael L Perry
//  8/29/99
//

#include "stdhdr.h"
#include "LUDecomposition.h"

#include <math.h>
#include <algorithm>

CLUDecomposition::CLUDecomposition(const CMatrix &matrix) :
    m_mLU(matrix),
    m_bValid(false)
{
    static const double TINY = 1e-20;

    // Allocate the permutation vector.
    int nSize = matrix.Size();
    m_pPermutation = new int[nSize];

    // Calculate the decomposition with permutation.
    int i,imax,j,k;
    double big,dum,sum,temp;

    CVector vFactor(nSize);

    // Calculate the scaling factor for each row.
    // This implements implicit scaling for partial pivoting.
    for (i=0;i<nSize;i++)
    {
        big=0.0;
        for (j=0;j<nSize;j++)
            if ((temp=fabs(m_mLU(i, j))) > big)
                big=temp;
        if (big == 0.0)
            return;
        vFactor(i)=1.0/big;
    }

    // Use Crout's method to solve the LU system of equations where
    // each element of the diagonal of L is 1.0.
    for (j=0;j<nSize;j++)
    {
        // Solve where i < j (U without the diagonal).
        for (i=0;i<j;i++)
        {
            sum=m_mLU(i, j);
            for (k=0;k<i;k++)
                sum -= m_mLU(i, k)*m_mLU(k, j);
            m_mLU(i, j)=sum;
        }

        // Solve where i >= j (L) and find the pivot.
        big=0.0;
        for (i=j;i<nSize;i++)
        {
            sum=m_mLU(i, j);
            for (k=0;k<j;k++)
                sum -= m_mLU(i, k)*m_mLU(k, j);

            m_mLU(i, j)=sum;
            if ( (dum=vFactor(i)*fabs(sum)) >= big)
            {
                big=dum;
                imax=i;
            }
        }

        // Pivot if necessary.
        if (j != imax)
        {
            for ( i = 0; i < nSize; i++ )
            {
                std::swap(m_mLU(imax, i), m_mLU(j, i));
            }
            vFactor(imax)=vFactor(j);
        }
        m_pPermutation[j]=imax;

        // If the matrix is close to singular, push it away just a bit.
        if (m_mLU(j, j) == 0.0)
            m_mLU(j, j)=TINY;
        // Divide by the pivot element.
        if (j != nSize-1)
        {
            dum=1.0/(m_mLU(j, j));
            for (i=j+1;i<nSize;i++)
                m_mLU(i, j) *= dum;
        }
    }

    m_bValid = true;
}

CLUDecomposition::~CLUDecomposition()
{
    if ( m_pPermutation != NULL )
        delete[] m_pPermutation;
}

bool CLUDecomposition::Solve( CVector &v ) const
{
    if ( !m_bValid )
        return false;

    int nSize = m_mLU.Size();
    if ( nSize != v.Size() )
        return false;

    int i,j;
    int nFirstNonZero = -1;

    // Permute the vector.
    for ( int nRow = 0; nRow < nSize; nRow++ )
    {
        if ( m_pPermutation[nRow] != nRow )
        {
            std::swap( v(m_pPermutation[nRow]), v(nRow) );
        }
    }

    // Forward substitute the L matrix.
    for (i=0;i<nSize;i++)
    {
        // Solving LU decomposition with the elementary unit vectors
        // yields the inverse, so we optimize for that possibility by
        // skipping the initial zeros.
        if ( nFirstNonZero >= 0 )
        {
            for (j=nFirstNonZero;j<i;j++)
                v(i) -= m_mLU(i, j)*v(j);
        }
        else if ( v(i) != 0.0 )
        {
            nFirstNonZero = i;
        }
    }

    // Then back substitute the U matrix.
    v(nSize-1) /= m_mLU(nSize-1, nSize-1);
    for (i=nSize-2;i>=0;i--)
    {
        for (double sum=0.0,j=i+1;j<nSize;j++)
            sum += m_mLU(i, j)*v(j);
        v(i)=(v(i)-sum)/m_mLU(i, i);
    }

    return true;
}

