//////////////////////////////////////////////////////////////////////
//
//  Leg.h
//
//  A link between a vertex and a component.
//
//  Michael L Perry
//  3/21/00
//

#if !defined(AFX_LEG_H__9FA8C68B_FF6E_11D3_9D65_444553540000__INCLUDED_)
#define AFX_LEG_H__9FA8C68B_FF6E_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EqSystem.h"

class CVertex;

class CLeg
{
public:
	CLeg( CVertex *pVertex );
	virtual ~CLeg();

	double GetEMF();
	double GetCurrent();
	bool RepresentsEMF( IEqUnknown *pUnknown );
	bool RepresentsCurrent( IEqUnknown *pUnknown );

private:
    CVertex *m_pVertex;
};

#endif // !defined(AFX_LEG_H__9FA8C68B_FF6E_11D3_9D65_444553540000__INCLUDED_)
