//////////////////////////////////////////////////////////////////////
//
//  ComponentBinary.cpp
//
//  A component that connects two vertices.
//
//  Michael L Perry
//  3/22/00
//

#include "stdhdr.h"
#include "ComponentBinary.h"

CComponentBinary::CComponentBinary()
{
}

CComponentBinary::~CComponentBinary()
{
}

void CComponentBinary::Attach1(CVertex *pVertex)
{
    m_pLeg1.Attach( pVertex );
}

void CComponentBinary::Attach2(CVertex *pVertex)
{
    m_pLeg2.Attach( pVertex );
}

void CComponentBinary::AddToSystemPrimary( CEqSystem &rSystem )
{
    // Add two equations, one for Kirchhoff's first
    // law and another specific to the component type.
    rSystem.AddEquation( (IEqEquationKirchhoff *)this );
    rSystem.AddEquation( (IEqEquationEMF *)this );
}

double CComponentBinary::CalculateValueKirchhoff()
{
    // Enforce Kirchhoff's first law:
    // the total current into a component is equal to the
    // total current out.
    return m_pLeg1->GetCurrent() + m_pLeg2->GetCurrent();
}

bool CComponentBinary::DependsUponKirchhoff(IEqUnknown *pUnknown)
{
    // Kirchhoff's first law depends only upon the two currents.
    return
        m_pLeg1->RepresentsCurrent(pUnknown) ||
        m_pLeg2->RepresentsCurrent(pUnknown);
}
