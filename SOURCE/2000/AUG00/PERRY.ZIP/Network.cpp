//////////////////////////////////////////////////////////////////////
//
//  Network.cpp
//
//  An object that represents a network of components.
//
//  Michael L Perry
//  3/21/00
//

#include "stdhdr.h"
#include "Network.h"
#include "ComponentGround.h"
#include "ComponentWire.h"
#include "ComponentWireKnown.h"
#include "ComponentBattery.h"
#include "ComponentResistor.h"
#include "ComponentResistorUnknown.h"

CNetwork::CNetwork()
{
}

CNetwork::~CNetwork()
{
    CComponentList::iterator itComponent;
    for ( itComponent = m_lComponents.begin();
    	itComponent != m_lComponents.end();
    	itComponent++ )
    {
        delete *itComponent;
    }

    CVertexList::iterator itVertex;
    for ( itVertex = m_lVertices.begin();
    	itVertex != m_lVertices.end();
    	itVertex++ )
    {
        delete *itVertex;
    }
}

CVertex * CNetwork::NewVertex()
{
    CVertex *pVertex = new CVertex;
    m_lVertices.push_back( pVertex );
    return pVertex;
}

CComponentGround * CNetwork::NewComponentGround()
{
    CComponentGround *pComponentGround = new CComponentGround;
    m_lComponents.push_back( pComponentGround );
    return pComponentGround;
}

CComponentWire * CNetwork::NewComponentWire()
{
    CComponentWire *pComponentWire = new CComponentWire;
    m_lComponents.push_back( pComponentWire );
    return pComponentWire;
}

CComponentWireKnown * CNetwork::NewComponentWireKnown()
{
    CComponentWireKnown *pComponentWireKnown = new CComponentWireKnown;
    m_lComponents.push_back( pComponentWireKnown );
    return pComponentWireKnown;
}

CComponentBattery * CNetwork::NewComponentBattery()
{
    CComponentBattery *pComponentBattery = new CComponentBattery;
    m_lComponents.push_back( pComponentBattery );
    return pComponentBattery;
}

CComponentResistor * CNetwork::NewComponentResistor()
{
    CComponentResistor *pComponentResistor = new CComponentResistor;
    m_lComponents.push_back( pComponentResistor );
    return pComponentResistor;
}

CComponentResistorUnknown * CNetwork::NewComponentResistorUnknown()
{
    CComponentResistorUnknown *pComponentResistorUnknown = new CComponentResistorUnknown;
    m_lComponents.push_back( pComponentResistorUnknown );
    return pComponentResistorUnknown;
}

void CNetwork::AddToSystemPrimary( CEqSystem &rSystem )
{
    // Add all vertices and components to the system.
    CVertexList::iterator itVertex;
    for ( itVertex = m_lVertices.begin();
    	itVertex != m_lVertices.end();
    	itVertex++ )
    {
        (*itVertex)->AddToSystemPrimary(rSystem);
    }

    CComponentList::iterator itComponent;
    for ( itComponent = m_lComponents.begin();
    	itComponent != m_lComponents.end();
    	itComponent++ )
    {
        (*itComponent)->AddToSystemPrimary(rSystem);
    }
}

void CNetwork::AddToSystemSecondary( CEqSystem &rSystem )
{
    // Add all components' secondary constraints to the system.
    CComponentList::iterator itComponent;
    for ( itComponent = m_lComponents.begin();
    	itComponent != m_lComponents.end();
    	itComponent++ )
    {
        (*itComponent)->AddToSystemSecondary(rSystem);
    }
}

void CNetwork::Dump()
{
    // Dump all components in the network.
    CComponentList::iterator itComponent;
    for ( itComponent = m_lComponents.begin();
    	itComponent != m_lComponents.end();
    	itComponent++ )
    {
        (*itComponent)->Dump();
    }
}
