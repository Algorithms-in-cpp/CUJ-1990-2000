//////////////////////////////////////////////////////////////////////
//
//  Matrix.cpp
//
//  A square matrix of numbers.
//
//  Michael L Perry
//  8/22/99
//

#include "stdhdr.h"
#include "Matrix.h"

#include <memory.h>

//////////////////////////////////////////////////////////////////////
// CMatrixData
inline CMatrix::CMatrixData::CMatrixData()
{
    // Make an empty matrix.
    m_nSize = 0;
    m_pElements = NULL;
    m_nRefCount = 0;
}

inline CMatrix::CMatrixData::CMatrixData(const CMatrixData &that)
{
    // Copy the elements from the other matrix.
    m_nSize = that.m_nSize;
    int nElementCount = m_nSize*m_nSize;
    m_pElements = new double[nElementCount];
    memcpy( m_pElements, that.m_pElements, nElementCount*sizeof(double) );
    m_nRefCount = 0;
}

inline CMatrix::CMatrixData::CMatrixData(int nSize)
{
    // Allocate a square matrix and initialize the elements to zero.
    m_nSize = nSize;
    int nElementCount = m_nSize*m_nSize;
    m_pElements = new double[nElementCount];
    memset( m_pElements, 0, nElementCount*sizeof(double) );
    m_nRefCount = 0;
}

inline CMatrix::CMatrixData::~CMatrixData()
{
    if ( m_pElements != NULL )
        delete[] m_pElements;
}

inline void CMatrix::CMatrixData::AddRef()
{
    m_nRefCount++;
}

inline void CMatrix::CMatrixData::Release()
{
    // When the reference count reaches zero, delete the object.
    if ( --m_nRefCount == 0 )
    {
        delete this;
    }
}

inline bool CMatrix::CMatrixData::IsShared() const
{
    return m_nRefCount > 1;
}

inline int CMatrix::CMatrixData::Size() const
{
    return m_nSize;
}

inline bool CMatrix::CMatrixData::Equals(const CMatrix::CMatrixData *pThat)
{
    // Must be the same size.
    if ( m_nSize != pThat->m_nSize )
        return false;

    return memcmp(
        m_pElements,
        pThat->m_pElements,
        m_nSize*m_nSize*sizeof(double) ) == 0;
}

inline double CMatrix::CMatrixData::Element(int nRow, int nCol) const
{
    // Verify that we are still in range.
    ASSUMING (
        nRow >= 0 && nRow < m_nSize &&
        nCol >= 0 && nCol < m_nSize )
    {
        return m_pElements[nRow*m_nSize + nCol];
    }
    return 0.0;
}

inline double &CMatrix::CMatrixData::Element(int nRow, int nCol)
{
    static double dDummy = 0.0;

    // Verify that we are still in range.
    ASSUMING (
        nRow >= 0 && nRow < m_nSize &&
        nCol >= 0 && nCol < m_nSize )
    {
        return m_pElements[nRow*m_nSize + nCol];
    }
    // Satisfy the compiler.
    return dDummy;
}


//////////////////////////////////////////////////////////////////////
// CMatrix
CMatrix CMatrix::Identity(int nSize)
{
    // The sizing constructor fills the matrix with zeros.
    CMatrix ret(nSize);
    int nElement;

    // All we need to worry about are the diagonal elements.
    for ( nElement = 0; nElement < nSize; nElement++ )
    {
        ret(nElement, nElement) = 1.0;
    }

    return ret;
}

CMatrix::CMatrix()
{
    // Create an empty matrix.
    m_pMatrixData = NULL;
}

CMatrix::CMatrix(const CMatrix &that)
{
    // Refer to the same data - lazy copy.
    m_pMatrixData = that.m_pMatrixData;
    m_pMatrixData->AddRef();
}

CMatrix::CMatrix(int nSize)
{
    // Create matrix data if the size is valid.
    if ( nSize > 0 )
    {
        m_pMatrixData = new CMatrixData(nSize);
        m_pMatrixData->AddRef();
    }
    else
    {
        m_pMatrixData = NULL;
    }
}

CMatrix::~CMatrix()
{
    // Release my reference on the data.
    if ( m_pMatrixData != NULL )
        m_pMatrixData->Release();
}

bool CMatrix::operator ==(const CMatrix &that) const
{
    // First determine if they share data.
    if ( m_pMatrixData == that.m_pMatrixData )
        return true;

    // If not, make sure they both have data.
    if ( m_pMatrixData == NULL ||
         that.m_pMatrixData == NULL )
        return false;

    return m_pMatrixData->Equals(that.m_pMatrixData);
}

bool CMatrix::operator !=(const CMatrix &that) const
{
    return !operator ==(that);
}

const CMatrix &CMatrix::operator =(const CMatrix &that)
{
    // Release the old matrix data.
    if ( m_pMatrixData != NULL )
        m_pMatrixData->Release();

    // Share the data.
    m_pMatrixData = that.m_pMatrixData;
    if ( m_pMatrixData != NULL )
        m_pMatrixData->AddRef();

    return that;
}

int CMatrix::Size() const
{
    if ( m_pMatrixData == NULL )
        return 0;

    return m_pMatrixData->Size();
}

double CMatrix::operator()(int nRow, int nCol) const
{
    // Verify that we have data.
    ASSUMING ( m_pMatrixData != NULL )
    {
        return m_pMatrixData->Element(nRow, nCol);
    }
    return 0.0;
}

double &CMatrix::operator()(int nRow, int nCol)
{
    static double dDummy = 0.0;
    // Verify that we have data.
    ASSUMING ( m_pMatrixData != NULL )
    {
        // Make a copy if the data is shared.
        if ( m_pMatrixData->IsShared() )
        {
            CMatrixData *pCopy = new CMatrixData(*m_pMatrixData);

            // Release the old matrix data.
            m_pMatrixData->Release();

            // Use the copy.
            m_pMatrixData = pCopy;
            m_pMatrixData->AddRef();
        }
        return m_pMatrixData->Element(nRow, nCol);
    }
    // Appease the compiler.
    return dDummy;
}

CMatrix CMatrix::operator *(const CMatrix &that) const
{
    CMatrix mResult;
    int nSize;

    // Make sure both have data, and are the same size.
    ASSUMING ( m_pMatrixData != NULL && that.m_pMatrixData != NULL &&
        (nSize = m_pMatrixData->Size()) == that.m_pMatrixData->Size() )
    {
        int nSize = m_pMatrixData->Size();
        mResult = CMatrix(nSize);

        // Calculate each element of the result matrix.
        int nRow, nCol, nIndex;
        for ( nRow = 0; nRow < nSize; nRow++ )
        {
            for ( nCol = 0; nCol < nSize; nCol++ )
            {
                double dElement = 0.0;
                for ( nIndex = 0; nIndex < nSize; nIndex++ )
                {
                    dElement +=
                        m_pMatrixData->Element(nRow, nIndex) *
                        that.m_pMatrixData->Element(nIndex, nCol);
                }
                mResult(nRow, nCol) = dElement;
            }
        }
    }

    return mResult;
}

CVector CMatrix::operator *(const CVector &that) const
{
    int nSize;
    CVector mResult;

    // Make sure both have data, and are the same size.
    ASSUMING ( m_pMatrixData != NULL &&
        (nSize = m_pMatrixData->Size()) == that.Size() )
    {
        mResult = CVector(nSize);

        // Calculate each element of the result vector.
        int nRow, nIndex;
        for ( nRow = 0; nRow < nSize; nRow++ )
        {
            double dElement = 0.0;
            for ( nIndex = 0; nIndex < nSize; nIndex++ )
            {
                dElement +=
                    m_pMatrixData->Element(nRow, nIndex) *
                    that(nIndex);
            }
            mResult(nRow) = dElement;
        }
    }

    return mResult;
}

CMatrix CMatrix::Transpose() const
{
    int nSize = m_pMatrixData->Size();
    CMatrix mResult(nSize);

    int nRow, nCol;
    for ( nRow = 0; nRow < nSize; nRow++ )
    {
        for ( nCol = 0; nCol < nSize; nCol++ )
        {
            mResult(nRow, nCol) = m_pMatrixData->Element(nCol, nRow);
        }
    }

    return mResult;
}

void CMatrix::Dump() const
{
    int nSize = m_pMatrixData->Size();

    int nRow, nCol;
    for ( nRow = 0; nRow < nSize; nRow++ )
    {
        Trace( "[ " );
        for ( nCol = 0; nCol < nSize; nCol++ )
        {
            Trace( m_pMatrixData->Element(nRow, nCol) );
            Trace( " " );
        }
        Trace( "]\n" );
    }
}
