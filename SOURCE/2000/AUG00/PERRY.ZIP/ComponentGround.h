//////////////////////////////////////////////////////////////////////
//
//  ComponentGround.h
//
//  Ground component in a network.
//
//  Michael L Perry
//  3/21/00
//

#if !defined(AFX_COMPONENTGROUND_H__9FA8C68D_FF6E_11D3_9D65_444553540000__INCLUDED_)
#define AFX_COMPONENTGROUND_H__9FA8C68D_FF6E_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ComponentUnary.h"

class CComponentGround : public CComponentUnary
{
public:
	CComponentGround();
	virtual ~CComponentGround();

	void Dump();

protected:
	double CalculateValue();
	bool DependsUpon(IEqUnknown *pUnknown);
};

#endif // !defined(AFX_COMPONENTGROUND_H__9FA8C68D_FF6E_11D3_9D65_444553540000__INCLUDED_)
