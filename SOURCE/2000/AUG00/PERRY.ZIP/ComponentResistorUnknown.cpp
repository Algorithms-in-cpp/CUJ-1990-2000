//////////////////////////////////////////////////////////////////////
//
//  ComponentResistorUnknown.cpp
//
//  A resistor with an unknown resistance.
//
//  Michael L Perry
//  3/26/00
//

#include "stdhdr.h"
#include "ComponentResistorUnknown.h"

CComponentResistorUnknown::CComponentResistorUnknown()
{
}

CComponentResistorUnknown::~CComponentResistorUnknown()
{
}

void CComponentResistorUnknown::AddToSystemSecondary(CEqSystem &rSystem)
{
    // Let the base class add its pieces to the system.
    CComponentResistor::AddToSystemSecondary( rSystem );
    // Add the unknown resistance.
    rSystem.AddUnknown( (IEqUnknownResistance *)this );
}

bool CComponentResistorUnknown::DependsUponEMF(IEqUnknown *pUnknown)
{
    // EMF also depends upon resistance.
    return
        pUnknown == (IEqUnknownResistance *)this ||
        CComponentResistor::DependsUponEMF( pUnknown );
}

double CComponentResistorUnknown::GetValueResistance()
{
    // Make resistance an unknown.
    return GetResistance();
}

void CComponentResistorUnknown::SetValueResistance(double dValue)
{
    SetResistance( dValue );
}
