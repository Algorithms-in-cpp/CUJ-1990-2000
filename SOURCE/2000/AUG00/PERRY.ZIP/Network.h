//////////////////////////////////////////////////////////////////////
//
//  Network.h
//
//  An object that represents a network of components.
//
//  Michael L Perry
//  3/21/00
//

#if !defined(AFX_NETWORK_H__9FA8C687_FF6E_11D3_9D65_444553540000__INCLUDED_)
#define AFX_NETWORK_H__9FA8C687_FF6E_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Vertex.h"
#include "Component.h"
#include <list>

class CComponentGround;
class CComponentWire;
class CComponentWireKnown;
class CComponentBattery;
class CComponentResistor;
class CComponentResistorUnknown;

class CNetwork  
{
public:
	CNetwork();
	virtual ~CNetwork();

	CVertex * NewVertex();
	CComponentGround * NewComponentGround();
	CComponentWire * NewComponentWire();
	CComponentWireKnown * NewComponentWireKnown();
	CComponentBattery * NewComponentBattery();
	CComponentResistor * NewComponentResistor();
	CComponentResistorUnknown * NewComponentResistorUnknown();

	void AddToSystemPrimary( CEqSystem &rSystem );
	void AddToSystemSecondary( CEqSystem &rSystem );
	void Dump();

private:
    typedef std::list< CVertex * > CVertexList;
    CVertexList m_lVertices;
    typedef std::list< CComponent * > CComponentList;
    CComponentList m_lComponents;
};

#endif // !defined(AFX_NETWORK_H__9FA8C687_FF6E_11D3_9D65_444553540000__INCLUDED_)
