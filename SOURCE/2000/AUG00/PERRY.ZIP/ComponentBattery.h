//////////////////////////////////////////////////////////////////////
//
//  ComponentBattery.h
//
//  Battery component in a network.
//
//  Michael L Perry
//  3/21/00
//

#if !defined(AFX_COMPONENTBATTERY_H__9FA8C68F_FF6E_11D3_9D65_444553540000__INCLUDED_)
#define AFX_COMPONENTBATTERY_H__9FA8C68F_FF6E_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ComponentBinary.h"

class CComponentBattery : public CComponentBinary
{
public:
	CComponentBattery();
	virtual ~CComponentBattery();

	double GetVoltage();
	void SetVoltage( double dVoltage );
	void Dump();

protected:
	double CalculateValueEMF();
	bool DependsUponEMF(IEqUnknown *pUnknown);

private:
    double m_dVoltage;
};

#endif // !defined(AFX_COMPONENTBATTERY_H__9FA8C68F_FF6E_11D3_9D65_444553540000__INCLUDED_)
