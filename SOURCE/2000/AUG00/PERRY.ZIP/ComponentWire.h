//////////////////////////////////////////////////////////////////////
//
//  ComponentWire.h
//
//  Wire component in a network.
//
//  Michael L Perry
//  3/21/00
//

#if !defined(AFX_COMPONENTWIRE_H__9FA8C68E_FF6E_11D3_9D65_444553540000__INCLUDED_)
#define AFX_COMPONENTWIRE_H__9FA8C68E_FF6E_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ComponentBinary.h"

class CComponentWire : public CComponentBinary
{
public:
	CComponentWire();
	virtual ~CComponentWire();

	void Dump();

protected:
	double CalculateValueEMF();
	bool DependsUponEMF(IEqUnknown *pUnknown);
};

#endif // !defined(AFX_COMPONENTWIRE_H__9FA8C68E_FF6E_11D3_9D65_444553540000__INCLUDED_)
