//////////////////////////////////////////////////////////////////////
//
//  stdhdr.h
//
//  Common header files.
//
//  Michael L Perry
//  8/22/99
//

#pragma warning (disable : 4786)

#include <crtdbg.h>
#define ASSERT(c) _ASSERT(c)
#define ASSUMING(c) if (!(c)) { _ASSERT(false); } else

inline double square(double x)
{
    return x*x;
}

void Trace(char *strOut);
void Trace(double dValue);
