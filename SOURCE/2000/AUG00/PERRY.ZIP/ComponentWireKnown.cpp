//////////////////////////////////////////////////////////////////////
//
//  ComponentWireKnown.cpp
//
//  A wire with a known current.
//
//  Michael L Perry
//  3/26/00
//

#include "stdhdr.h"
#include "ComponentWireKnown.h"

CComponentWireKnown::CComponentWireKnown() :
    m_dCurrent( 1.0 )
{
}

CComponentWireKnown::~CComponentWireKnown()
{
}

double CComponentWireKnown::GetCurrent()
{
    return m_dCurrent;
}

void CComponentWireKnown::SetCurrent(double dCurrent)
{
    m_dCurrent = dCurrent;
}

void CComponentWireKnown::AddToSystemSecondary(CEqSystem &rSystem)
{
    // Let the base class add its pieces to the system.
    CComponentWire::AddToSystemSecondary( rSystem );
    // Add the known current.
    rSystem.AddEquation( (IEqEquationCurrent *)this );
}

double CComponentWireKnown::CalculateValueCurrent()
{
    // Current from first leg must match target current.
    return m_pLeg1->GetCurrent() - m_dCurrent;
}

bool CComponentWireKnown::DependsUponCurrent(IEqUnknown *pUnknown)
{
    // The equation depends upon leg current.
    return m_pLeg1->RepresentsCurrent( pUnknown );
}
