//////////////////////////////////////////////////////////////////////
//
//  Vertex.h
//
//  A point of inconnection within a network.
//
//  Michael L Perry
//  3/21/00
//

#if !defined(AFX_VERTEX_H__9FA8C688_FF6E_11D3_9D65_444553540000__INCLUDED_)
#define AFX_VERTEX_H__9FA8C688_FF6E_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Leg.h"
#include <list>

//////////////////////////////////////////////////////////////////////
// LegStruct
// Associates a current with a leg.
struct LegStruct : public IEqUnknown
{
    CLeg *pLeg;
    double dCurrent;

    // IEqUnknown for current.
    double GetValue();
    void SetValue(double dValue);
};

class CEqSystem;

//////////////////////////////////////////////////////////////////////
// CVertex
// A connection point for legs.
class CVertex :
    private IEqUnknown // for EMF.
{
public:
	CVertex();
	virtual ~CVertex();

	CLeg * NewLeg();
	void ReleaseLeg( CLeg *pLeg );

    double GetEMF();
    double GetCurrent( CLeg *pLeg );
	bool RepresentsEMF( IEqUnknown *pUnknown );
	bool RepresentsCurrent( CLeg *pLeg, IEqUnknown *pUnknown );

	void AddToSystemPrimary( CEqSystem &rSystem );

private:
    // IEqUnknown for EMF.
    double GetValue();
    void SetValue(double dValue);

    // EMF at the vertex (Kirchhoff's second law).
    double m_dEMF;
    // List of legs attached to this vertex.
    typedef std::list< LegStruct * > LegStructList;
    LegStructList m_lLegs;

    LegStructList::iterator FindLegStruct( CLeg *pLeg );
};

#endif // !defined(AFX_VERTEX_H__9FA8C688_FF6E_11D3_9D65_444553540000__INCLUDED_)
