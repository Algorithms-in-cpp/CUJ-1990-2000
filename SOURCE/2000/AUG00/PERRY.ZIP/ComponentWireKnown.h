//////////////////////////////////////////////////////////////////////
//
//  ComponentWireKnown.h
//
//  A wire with a known current.
//
//  Michael L Perry
//  3/26/00
//

#if !defined(AFX_COMPONENTWIREKNOWN_H__FBA3F361_0306_11D4_9D65_444553540000__INCLUDED_)
#define AFX_COMPONENTWIREKNOWN_H__FBA3F361_0306_11D4_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ComponentWire.h"

// Interface interpreter for current.
class IEqEquationCurrent: public IEqEquation
{
public:
    virtual double CalculateValueCurrent() = 0;
    virtual bool DependsUponCurrent(IEqUnknown *pUnknown) = 0;

    double CalculateValue()
        { return CalculateValueCurrent(); }
    bool DependsUpon(IEqUnknown *pUnknown)
        { return DependsUponCurrent(pUnknown); }
};

class CComponentWireKnown : public CComponentWire,
    private IEqEquationCurrent
{
public:
	CComponentWireKnown();
	virtual ~CComponentWireKnown();

	double GetCurrent();
	void SetCurrent( double dCurrent );

	void AddToSystemSecondary(CEqSystem &rSystem);

private:
    // IEqEquationCurrent.
	double CalculateValueCurrent();
	bool DependsUponCurrent( IEqUnknown *pUnknown );

    // Known target current.
    double m_dCurrent;
};

#endif // !defined(AFX_COMPONENTWIREKNOWN_H__FBA3F361_0306_11D4_9D65_444553540000__INCLUDED_)
