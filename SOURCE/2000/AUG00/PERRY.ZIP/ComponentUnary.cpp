//////////////////////////////////////////////////////////////////////
//
//  ComponentUnary.cpp
//
//  A component that connects only one vertex.
//
//  Michael L Perry
//  3/22/00
//

#include "stdhdr.h"
#include "ComponentUnary.h"

CComponentUnary::CComponentUnary()
{
}

CComponentUnary::~CComponentUnary()
{
}

void CComponentUnary::Attach(CVertex *pVertex)
{
    m_pLeg.Attach( pVertex );
}

void CComponentUnary::AddToSystemPrimary( CEqSystem &rSystem )
{
    // A unary component adds only one equation to the system.
    rSystem.AddEquation( this );
}
