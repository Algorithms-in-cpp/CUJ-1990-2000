//////////////////////////////////////////////////////////////////////
//
//  ComponentBinary.h
//
//  A component that connects two vertices.
//
//  Michael L Perry
//  3/22/00
//

#if !defined(AFX_COMPONENTBINARY_H__BF28EDE0_0019_11D4_9D65_444553540000__INCLUDED_)
#define AFX_COMPONENTBINARY_H__BF28EDE0_0019_11D4_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Component.h"
#include "EqSystem.h"
#include "LegPtr.h"

// Interface interpreter for Kirchhoff's first law.
class IEqEquationKirchhoff: public IEqEquation
{
public:
    virtual double CalculateValueKirchhoff() = 0;
    virtual bool DependsUponKirchhoff(IEqUnknown *pUnknown) = 0;

    double CalculateValue()
        { return CalculateValueKirchhoff(); }
    bool DependsUpon(IEqUnknown *pUnknown)
        { return DependsUponKirchhoff(pUnknown); }
};

class IEqEquationEMF: public IEqEquation
{
public:
    virtual double CalculateValueEMF() = 0;
    virtual bool DependsUponEMF(IEqUnknown *pUnknown) = 0;

    double CalculateValue()
        { return CalculateValueEMF(); }
    bool DependsUpon(IEqUnknown *pUnknown)
        { return DependsUponEMF(pUnknown); }
};

class CComponentBinary : public CComponent,
    private IEqEquationKirchhoff,
    protected IEqEquationEMF
{
public:
    CComponentBinary();
    virtual ~CComponentBinary();

    void Attach1( CVertex *pVertex );
    void Attach2( CVertex *pVertex );

    void AddToSystemPrimary( CEqSystem &rSystem );

private:
    // IEqEquationKirchhoff implementation.
    double CalculateValueKirchhoff();
    bool DependsUponKirchhoff(IEqUnknown *pUnknown);

protected:
    CLegPtr m_pLeg1;
    CLegPtr m_pLeg2;
};

#endif // !defined(AFX_COMPONENTBINARY_H__BF28EDE0_0019_11D4_9D65_444553540000__INCLUDED_)
