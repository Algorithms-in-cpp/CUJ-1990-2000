//////////////////////////////////////////////////////////////////////
//
//  ComponentResistor.h
//
//  Resistor component in a network.
//
//  Michael L Perry
//  3/21/00
//

#if !defined(AFX_COMPONENTRESISTOR_H__9FA8C690_FF6E_11D3_9D65_444553540000__INCLUDED_)
#define AFX_COMPONENTRESISTOR_H__9FA8C690_FF6E_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ComponentBinary.h"

class CComponentResistor : public CComponentBinary
{
public:
	CComponentResistor();
	virtual ~CComponentResistor();

	double GetResistance();
	void SetResistance( double dResistance );

	void Dump();

protected:
	double CalculateValueEMF();
	bool DependsUponEMF(IEqUnknown *pUnknown);

private:
    double m_dResistance;
};

#endif // !defined(AFX_COMPONENTRESISTOR_H__9FA8C690_FF6E_11D3_9D65_444553540000__INCLUDED_)
