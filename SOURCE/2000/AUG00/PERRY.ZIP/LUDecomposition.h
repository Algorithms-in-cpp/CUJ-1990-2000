//////////////////////////////////////////////////////////////////////
//
//  LUDecomposition.h
//
//  An LU decomposition of a matrix.
//
//  Michael L Perry
//  8/29/99
//

#if !defined(AFX_LUDECOMPOSITION_H__6DB32DE3_5E20_11D3_9D65_444553540000__INCLUDED_)
#define AFX_LUDECOMPOSITION_H__6DB32DE3_5E20_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Matrix.h"

// LU decomposition object.
// Decomposes a matrix in the constructor, then uses the results to
// solve with a given vector.
class CLUDecomposition  
{
public:
    CLUDecomposition(const CMatrix &matrix);
    ~CLUDecomposition();

    bool Solve( CVector &v ) const;

private:
    int         *m_pPermutation;
    CMatrix     m_mLU;
    bool        m_bValid;
};

#endif // !defined(AFX_LUDECOMPOSITION_H__6DB32DE3_5E20_11D3_9D65_444553540000__INCLUDED_)
