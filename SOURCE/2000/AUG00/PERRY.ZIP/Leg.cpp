//////////////////////////////////////////////////////////////////////
//
//  Leg.cpp
//
//  A link between a vertex and a component.
//
//  Michael L Perry
//  3/21/00
//

#include "stdhdr.h"
#include "Leg.h"
#include "Vertex.h"

CLeg::CLeg( CVertex *pVertex ) :
    m_pVertex( pVertex )
{
}

CLeg::~CLeg()
{
}

double CLeg::GetEMF()
{
    return m_pVertex->GetEMF();
}

double CLeg::GetCurrent()
{
    return m_pVertex->GetCurrent( this );
}

bool CLeg::RepresentsEMF(IEqUnknown *pUnknown)
{
    return m_pVertex->RepresentsEMF( pUnknown );
}

bool CLeg::RepresentsCurrent(IEqUnknown *pUnknown)
{
    return m_pVertex->RepresentsCurrent( this, pUnknown );
}
