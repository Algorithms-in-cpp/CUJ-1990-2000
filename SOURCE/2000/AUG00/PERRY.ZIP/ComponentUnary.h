//////////////////////////////////////////////////////////////////////
//
//  ComponentUnary.h
//
//  A component that connects only one vertex.
//
//  Michael L Perry
//  3/22/00
//

#if !defined(AFX_COMPONENTUNARY_H__BF28EDE1_0019_11D4_9D65_444553540000__INCLUDED_)
#define AFX_COMPONENTUNARY_H__BF28EDE1_0019_11D4_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Component.h"
#include "LegPtr.h"
#include "EqSystem.h"

class CComponentUnary : public CComponent,
    protected IEqEquation
{
public:
	CComponentUnary();
	virtual ~CComponentUnary();

	void Attach( CVertex *pVertex );

	void AddToSystemPrimary( CEqSystem &rSystem );

protected:
    CLegPtr m_pLeg;
};

#endif // !defined(AFX_COMPONENTUNARY_H__BF28EDE1_0019_11D4_9D65_444553540000__INCLUDED_)
