//////////////////////////////////////////////////////////////////////
//
//  EqSystem.h
//
//  A system of equations and unknowns.
//
//  Michael L Perry
//  9/1/99
//

#if !defined(AFX_EQSYSTEM_H__8905A1A3_60AE_11D3_9D65_444553540000__INCLUDED_)
#define AFX_EQSYSTEM_H__8905A1A3_60AE_11D3_9D65_444553540000__INCLUDED_

#include "Vector.h" // Added by ClassView
#include "Matrix.h" // Added by ClassView
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <vector>

// Represent an unknown.
// The solver gets and sets its values.
class IEqUnknown
{
public:
    virtual double GetValue() = 0;
    virtual void SetValue(double dValue) = 0;
};

// Represents an equation.
// The solver calculates equations and
// queries its dependencies.
class IEqEquation
{
public:
    virtual double CalculateValue() = 0;
    virtual bool DependsUpon(IEqUnknown *pUnknown) = 0;
};

// The solver engine.
// The application implements the above interfaces
// and adds them to the system object, then kicks
// off the solution.
class CEqSystem  
{
public:
    CEqSystem();

    void AddUnknown(IEqUnknown *pUnknown);
    void AddEquation(IEqEquation *pEquation);
    bool Solve();

private:
    void CalcNorm( CVector &vY );
    bool Converged( const CVector &vY );
    CMatrix CalcJacobian(
        const CVector &vX,
        const CVector &vY );
    bool LineSearch(
        const CVector &vX,
        CVector &vXNew,
        CVector &vY,
        const CVector &vStep,
        const CVector &vGradF);

private:
    std::vector<IEqUnknown *>   m_vUnknowns;
    std::vector<IEqEquation *>  m_vEquations;

    double                      m_dMaxLength;
    double                      m_dNorm;
};

#endif // !defined(AFX_EQSYSTEM_H__8905A1A3_60AE_11D3_9D65_444553540000__INCLUDED_)
