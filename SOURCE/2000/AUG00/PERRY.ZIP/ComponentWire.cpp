//////////////////////////////////////////////////////////////////////
//
//  ComponentWire.cpp
//
//  Wire component in a network.
//
//  Michael L Perry
//  3/21/00
//

#include "stdhdr.h"
#include "ComponentWire.h"

CComponentWire::CComponentWire()
{
}

CComponentWire::~CComponentWire()
{
}

void CComponentWire::Dump()
{
    Trace( "Wire:\n" );
    Trace( "  Current: " );
    Trace( m_pLeg1->GetCurrent() );
    Trace( ".\n" );
}

double CComponentWire::CalculateValueEMF()
{
    // There is no voltage drop across a wire.
    return m_pLeg1->GetEMF() - m_pLeg2->GetEMF();
}

bool CComponentWire::DependsUponEMF(IEqUnknown *pUnknown)
{
    // Equation depends on EMF at both ends.
    return
        m_pLeg1->RepresentsEMF(pUnknown) ||
        m_pLeg2->RepresentsEMF(pUnknown);
}
