//////////////////////////////////////////////////////////////////////
//
//  ComponentBattery.cpp
//
//  Battery component in a network.
//
//  Michael L Perry
//  3/21/00
//

#include "stdhdr.h"
#include "ComponentBattery.h"

CComponentBattery::CComponentBattery() :
    m_dVoltage( 1.0 )
{
}

CComponentBattery::~CComponentBattery()
{
}

double CComponentBattery::GetVoltage()
{
    return m_dVoltage;
}

void CComponentBattery::SetVoltage(double dVoltage)
{
    m_dVoltage = dVoltage;
}

void CComponentBattery::Dump()
{
    Trace( "Battery:\n" );
    Trace( "  Voltage: " );
    Trace( m_dVoltage );
    Trace( ".\n" );
    Trace( "  Current: " );
    Trace( m_pLeg1->GetCurrent() );
    Trace( ".\n" );
}

double CComponentBattery::CalculateValueEMF()
{
    // The voltage gain of negative minus positive is
    // equal to the battery's voltage.
    return m_pLeg2->GetEMF() - m_pLeg1->GetEMF() -
        m_dVoltage;
}

bool CComponentBattery::DependsUponEMF(IEqUnknown *pUnknown)
{
    // The voltage equation depends upon the EMF at both ends.
    return
        m_pLeg1->RepresentsEMF( pUnknown ) ||
        m_pLeg2->RepresentsEMF( pUnknown );
}
