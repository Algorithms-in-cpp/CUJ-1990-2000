//////////////////////////////////////////////////////////////////////
//
//  Main.cpp
//
//  Main program file.
//
//  Michael L Perry
//  3/21/00
//

#include "stdhdr.h"

#include "Network.h"
#include "EqSystem.h"
#include "ComponentBattery.h"
#include "ComponentResistor.h"
#include "ComponentResistorUnknown.h"
#include "ComponentGround.h"
#include "ComponentWireKnown.h"

#include <fstream>

std::fstream trace("output.txt", std::ios_base::out);

void Trace(char *strOut)
{
    trace << strOut;
}

void Trace(double dValue)
{
    char strValue[20];

    sprintf(strValue, "%f", dValue);
    Trace(strValue);
}

void Circuit1()
{
    // Create a simple grounded circuit.
    CNetwork net;
    CEqSystem sys;

    // Create the components.
    CComponentBattery *pBattery =
        net.NewComponentBattery();
    CComponentResistor *pResistor1 =
        net.NewComponentResistor();
    CComponentResistor *pResistor2 =
        net.NewComponentResistor();
    CComponentGround *pGround =
        net.NewComponentGround();

    // Set component attributes.
    pBattery->SetVoltage( 10.0 );
    pResistor1->SetResistance( 15.0 );
    pResistor2->SetResistance( 5.0 );

    // Attach the components through vertices.
    CVertex *pVertex = NULL;

    pVertex = net.NewVertex();
    pBattery->Attach1( pVertex );
    pResistor1->Attach1( pVertex );
    pResistor2->Attach1( pVertex );
    pGround->Attach( pVertex );

    pVertex = net.NewVertex();
    pBattery->Attach2( pVertex );
    pResistor1->Attach2( pVertex );
    pResistor2->Attach2( pVertex );

    // Solve for reasonable initial conditions.
    net.AddToSystemPrimary( sys );
    net.AddToSystemSecondary( sys );
    sys.Solve();                // Solve the system.
    net.Dump();                 // Display the results.
}

void Circuit2()
{
    // Create a complex circuit with an unknown resistor.
    CNetwork net;
    CEqSystem sys;

    // Create the components.
    CComponentBattery *pBattery1 =
        net.NewComponentBattery();
    CComponentBattery *pBattery2 =
        net.NewComponentBattery();
    CComponentResistorUnknown *pResistor1 =
        net.NewComponentResistorUnknown();
    CComponentResistor *pResistor2 =
        net.NewComponentResistor();
    CComponentResistor *pResistor3 =
        net.NewComponentResistor();
    CComponentGround *pGround =
        net.NewComponentGround();
    CComponentWireKnown *pWire =
        net.NewComponentWireKnown();

    // Set component attributes.
    pBattery1->SetVoltage( 5.0 );
    pBattery2->SetVoltage( 5.0 );
    pResistor2->SetResistance( 10.0 );
    pResistor3->SetResistance( 20.0 );
    pWire->SetCurrent( 0.1 );

    // Attach the components through vertices.
    CVertex *pVertex = NULL;

    pVertex = net.NewVertex();
    pBattery1->Attach1( pVertex );
    pResistor1->Attach1( pVertex );
    pGround->Attach( pVertex );

    pVertex = net.NewVertex();
    pBattery1->Attach2( pVertex );
    pWire->Attach2( pVertex );
    pBattery2->Attach1( pVertex );

    pVertex = net.NewVertex();
    pBattery2->Attach2( pVertex );
    pResistor2->Attach2( pVertex );

    pVertex = net.NewVertex();
    pResistor1->Attach2( pVertex );
    pResistor2->Attach1( pVertex );
    pResistor3->Attach1( pVertex );

    pVertex = net.NewVertex();
    pResistor3->Attach2( pVertex );
    pWire->Attach1( pVertex );

    // Solve for reasonable initial conditions.
    net.AddToSystemPrimary( sys );
    sys.Solve();                // Solve the system.
    Trace( "Initial conditions:\n" );
    net.Dump();                 // Display the results.

    // Solve the complete problem.
    net.AddToSystemSecondary( sys );
    sys.Solve();                // Solve the system.
    net.Dump();                 // Display the results.
}

void main()
{
    Circuit2();
}
