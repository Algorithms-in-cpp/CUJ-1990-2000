//////////////////////////////////////////////////////////////////////
//
//  ComponentResistorUnknown.h
//
//  A resistor with an unknown resistance.
//
//  Michael L Perry
//  3/26/00
//

#if !defined(AFX_COMPONENTRESISTORUNKNOWN_H__FBA3F360_0306_11D4_9D65_444553540000__INCLUDED_)
#define AFX_COMPONENTRESISTORUNKNOWN_H__FBA3F360_0306_11D4_9D65_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ComponentResistor.h"

// Interface interpreter for resistance.
class IEqUnknownResistance : public IEqUnknown
{
public:
    virtual double GetValueResistance() = 0;
    virtual void SetValueResistance(double dValue) = 0;

    double GetValue()
        { return GetValueResistance(); }
    void SetValue(double dValue)
        { SetValueResistance( dValue ); }
};


class CComponentResistorUnknown : public CComponentResistor,
    private IEqUnknownResistance
{
public:
	CComponentResistorUnknown();
	virtual ~CComponentResistorUnknown();

	void AddToSystemSecondary( CEqSystem &rSystem );

protected:
	bool DependsUponEMF(IEqUnknown *pUnknown);

private:
    // IEqUnknownResistance.
	double GetValueResistance();
	void SetValueResistance( double dValue );
};

#endif // !defined(AFX_COMPONENTRESISTORUNKNOWN_H__FBA3F360_0306_11D4_9D65_444553540000__INCLUDED_)
