//////////////////////////////////////////////////////////////////////
//
//  EqSystem.cpp
//
//  A system of equations and unknowns.
//
//  Michael L Perry
//  9/1/99
//

#include "stdhdr.h"
#include "EqSystem.h"
#include "LUDecomposition.h"

#include <math.h>
#include <iostream>
#include <algorithm>

CEqSystem::CEqSystem() :
    m_dMaxLength(0.0),
    m_dNorm(0.0)
{
}

void CEqSystem::AddUnknown(IEqUnknown * pUnknown)
{
    m_vUnknowns.push_back(pUnknown);
}

void CEqSystem::AddEquation(IEqEquation * pEquation)
{
    m_vEquations.push_back(pEquation);
}

bool CEqSystem::Solve()
{
    // First make sure that the system is well defined.
    if ( m_vUnknowns.empty() ||
         m_vUnknowns.size() != m_vEquations.size() )
    {
        return false;
    }

    // Gather the initial values of the unknowns.
    int nCount = m_vUnknowns.size();
    CVector vX(nCount);
    double dSum = 0.0;
    int nUnknown;
    for ( nUnknown = 0; nUnknown < nCount; nUnknown++ )
    {
        dSum += square( vX(nUnknown) = m_vUnknowns[nUnknown]->GetValue() );
    }
    Trace( "X =\n" );
    vX.Dump();

    // Calculate the system at the first guess.
    CVector vY(nCount);
    CalcNorm(vY);

    // Calculate the maximum step for line searches.
    m_dMaxLength = 100.0 * std::_MAX( sqrt(dSum), (double)nCount );

    // Iterate until the system converges.
    while ( !Converged(vY) )
    {
        // Calculate the Jacobian matrix.
        CMatrix mJacobian = CalcJacobian( vX, vY );

        // Compute grad. f = Jt y for the line search.
        CVector vGradF = mJacobian.Transpose() * vY;

        // Solve the system to find the next candidate point.
        CVector vStep = -vY;
        if ( !CLUDecomposition(mJacobian).Solve(vStep) )
        {
            Trace( "Jacobian is singular.\n" );
            return false;
        }

        // Line search if the next point is not closer.
        CVector vXNew;
        if ( !LineSearch( vX, vXNew, vY, vStep, vGradF ) )
        {
            // The line search failed to get closer, so check for a zero gradient.
            double d1_Denominator = 1.0/std::_MAX( m_dNorm, 0.5*(double)nCount );
            int nEquation;
            for ( nEquation = 0;
                nEquation < nCount;
                nEquation++ )
            {
                double dVal = fabs(vGradF(nEquation)) *
                    std::_MAX( fabs(vX(nEquation)), 1.0 ) * d1_Denominator;

                // Failed to converge.
                if ( dVal > 1e-6 )
                {
                    Trace( "Found a local minimum.\n" );
                    return false;
                }
            }

            // The gradient is zero, so we are close enough.
            Trace( "Converged by zero gradient.\n" );
            return true;
        }
        else
        {
            // Finally, check to see if we've stopped moving.
            for ( nUnknown = 0; nUnknown < nCount; nUnknown++ )
            {
                if ( vX(nUnknown) == vXNew(nUnknown) )
                    continue;
                double dVal =
                    fabs( vX(nUnknown) - vXNew(nUnknown) ) /
                    std::_MAX( fabs( vX(nUnknown) ), fabs( vXNew(nUnknown) ) );
                if ( dVal > 1e-6 )
                    break;
            }

            // If we made it all the way through the loop, x hasn't changed much.
            if ( nUnknown == nCount )
            {
                Trace( "Converged by zero step.\n" );
                return true;
            }
        }
        vX = vXNew;
    }
    // end while ( !Converged(vY) )

    Trace( "Converged by zero Y.\n" );
    return true;
}

void CEqSystem::CalcNorm( CVector &vY )
{
    // Run through all equations and calculate a vector.
    int nCount = m_vEquations.size();
    double dSum = 0.0;

    int nEquation;
    for ( nEquation = 0; nEquation < nCount; nEquation++ )
    {
        dSum += square(
            vY(nEquation) = m_vEquations[nEquation]->CalculateValue() );
    }

    // Calculate half the size of the vector for use in line search.
    m_dNorm = 0.5*dSum;

    Trace( "Y = \n" );
    vY.Dump();
    Trace( "Norm = " );
    Trace( m_dNorm );
    Trace( ".\n" );
}

bool CEqSystem::Converged(const CVector & vY)
{
    const double dEpsilon = 1e-7;

    // Compare every value to zero.
    int nCount = vY.Size();
    int nIndex;
    for ( nIndex = 0; nIndex < nCount; nIndex++ )
    {
        if ( fabs( vY(nIndex) ) > dEpsilon )
            return false;
    }
    return true;
}

CMatrix CEqSystem::CalcJacobian(
    const CVector &vX, const CVector &vY )
{
    const double dEpsilon = 1e-7;
    int nCount = m_vUnknowns.size();
    CMatrix mJacobian(nCount);

    // Use finite difference to estimate the derivatives.
    int nUnknown;
    for ( nUnknown = 0; nUnknown < nCount; nUnknown++ )
    {
        // Calculate the target value.
        double dTargetX = vX(nUnknown);
        double dDeltaX = fabs(dTargetX) * dEpsilon;
        if ( dDeltaX == 0.0 )
            dDeltaX = dEpsilon;
        dTargetX += dDeltaX;
        // Reevaluate the delta to account for round-off.
        dDeltaX = dTargetX - vX(nUnknown);

        // Calculate the functions that depend upon the unknown.
        IEqUnknown *pUnknown = m_vUnknowns[nUnknown];
        pUnknown->SetValue(dTargetX);
        int nEquation;
        for ( nEquation = 0; nEquation < nCount; nEquation++ )
        {
            if ( m_vEquations[nEquation]->DependsUpon(pUnknown) )
            {
                mJacobian(nEquation, nUnknown) =
                    ( m_vEquations[nEquation]->CalculateValue() -
                      vY(nEquation) ) /
                    dDeltaX;
            }
            else
            {
                mJacobian(nEquation, nUnknown) = 0.0;
            }
        }

        // Restore the original value.
        pUnknown->SetValue( vX(nUnknown) );
    }

    Trace( "Jacobian =\n" );
    mJacobian.Dump();
    return mJacobian;
}

bool CEqSystem::LineSearch(
    const CVector &vX,
    CVector &vXNew,
    CVector &vY,
    const CVector &vStep,
    const CVector &vGradF)
{
    const double dTollerance = 1e-7;

    // Limit the step size.
    double dLength = sqrt( vStep.InnerProduct(vStep) );
    double dStepFactor = 1.0;
    if ( dLength > m_dMaxLength )
    {
        dStepFactor = m_dMaxLength / dLength;
    }

    // Calculate the slope of the function in the descent direction.
    double dSlope = dStepFactor * vGradF.InnerProduct(vStep);
    ASSERT ( dSlope <= 0.0 );

    // Calculate the smallest acceptable fraction of a step.
    double dLambdaMin = 0.0;
    int nSize = vStep.Size();
    int nElement;
    for ( nElement = 0; nElement < nSize; nElement++ )
    {
        double dTemp;
        if ( fabs(vX(nElement)) < 1.0 )
            dTemp = fabs(vStep(nElement));
        else
            dTemp = fabs(vStep(nElement)) / fabs(vX(nElement));
        if ( dTemp > dLambdaMin )
            dLambdaMin = dTemp;
    }
    if ( dLambdaMin != 0.0 )
        dLambdaMin = dTollerance / (dStepFactor*dLambdaMin);

    // Iterate until an acceptable step is found.
    double dLambda  = 1.0;
    double dLambda2 = 0.0;
    double dNorm2   = 0.0;
    double dNormOld = m_dNorm;
    bool bFirst = true;
    while (true)
    {
        if ( dLambda < dLambdaMin )
        {
            // Lambda is too small.  Check for convergence.
            Trace( "The step is too small.\n" );
            return false;
        }

        vXNew = vX + dLambda*dStepFactor*vStep;
        Trace( "Take a step.\n" );
        vXNew.Dump();

        // Put the new guess into the system, and calculate it.
        for ( nElement = 0; nElement < nSize; nElement++ )
        {
            m_vUnknowns[nElement]->SetValue( vXNew(nElement) );
        }
        CalcNorm( vY );

        if ( m_dNorm <= dNormOld+1e-4*dLambda*dSlope )
        {
            // The function has decreased sufficiently.
            Trace( "The step is good.\n" );
            return true;
        }

        double dLambdaNext = 0.0;
        if ( bFirst )
        {
            // Minimize the function using a quadratic.
            bFirst = false;
            dLambdaNext = -dSlope/(2.0*(m_dNorm-dNormOld-dSlope));
        }
        else
        {
            // Minimize the function using a cubic.
            double dRhs1 = m_dNorm-dNormOld-dLambda*dSlope;
            double dRhs2 = dNorm2-dNormOld-dLambda2*dSlope;
            double a=(dRhs1/(dLambda*dLambda)-dRhs2/(dLambda2*dLambda2))/(dLambda-dLambda2);
            double b=(-dLambda2*dRhs1/(dLambda*dLambda)+dLambda*dRhs2/(dLambda2*dLambda2))/(dLambda-dLambda2);
            
            if (a == 0.0)
                dLambdaNext = -dSlope/(2.0*b);
            else
            {
                double dDisc = b*b-3.0*a*dSlope;
                if (dDisc < 0.0)
                    dLambdaNext=0.5*dLambda;
                else if (b <= 0.0)
                    dLambdaNext=(-b+sqrt(dDisc))/(3.0*a);
                else
                    dLambdaNext=-dSlope/(b+sqrt(dDisc));
            }
        }

        // Limit the range of the next fraction so it moves quickly enough.
        if (dLambdaNext > 0.5*dLambda)
            dLambdaNext=0.5*dLambda;
        else if (dLambdaNext < 0.1*dLambda)
            dLambdaNext=0.1*dLambda;

        dLambda2 = dLambda;
        dNorm2   = m_dNorm;
        dLambda  = dLambdaNext;

        Trace( "The step is bad, try a smaller one.\n" );
    }

    return false;
}
