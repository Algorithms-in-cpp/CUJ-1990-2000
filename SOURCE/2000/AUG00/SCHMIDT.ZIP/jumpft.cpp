#include <stdio.h>

class member
    {
public:
    member()
        {
        printf("throw from member ctor\n");
        throw 1;
        }
    };

class container
    {
public:
    container() try : m()
        {
        resume:
        printf("continuing in container ctor\n");
        }
    catch (...)
        {
        printf("catch in container ctor\n");
        goto resume;
        }
private:
    member m;
    };

int main()
    {
    container c;
    }
