#include <iostream>
#include <string>

struct oops
    {
    std::string creator;
    std::string reason;
    };

void f()
    {
    bool some_problem_occurred(false);
    oops e;
    // ...
    if (some_problem_occurred)
        {
        e.creator = "void f()";
        e.reason = "some problem occurred";
        throw e;
        }
    }

// ...

int main()
    {
    try
        {
        f();
        }
    catch (oops const &e)
        {
        std::cout << e.creator <<
                " threw because " <<
                e.reason << std::endl;
        }
    }
