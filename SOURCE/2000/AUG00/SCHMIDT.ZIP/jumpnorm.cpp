#include <stdio.h>

class member
    {
    };

class container
    {
public:
    container() : m()
        {
        try
            {
            throw 1;
            resume:
            printf("continuing in container ctor\n");
            }
        catch (...)
            {
            printf("catch in container ctor\n");
            goto resume;
            }
        }
private:
    member m;
    };

int main()
    {
    container c;
    return 0;
    }
