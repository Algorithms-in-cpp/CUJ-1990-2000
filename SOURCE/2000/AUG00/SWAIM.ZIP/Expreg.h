/*  expreg.h
    Exponential Regression calculation class
    derived from the Linear Regression class
    by: David C. Swaim II

    This class inplements an exponential regression on
    experimental data using least squares fit. Calculates
    coefficients a and b of the equation:

                        y = a * exp( b * x )

    It does this by inheriting the Linear Regression class.
    Converts data to match a straight line graph.

                        ln(y) = ln(a) + b * x
*/
#ifndef _EXPREG_H_
#define _EXPREG_H_

#include <math.h>
#include "linreg.h"

class ExponentialRegression : public LinearRegression
{
    friend ostream& operator<<(ostream& out, 
                               ExponentialRegression& er);

    public:
        ExponentialRegression(Point2D *p = 0, long size = 0);
        ExponentialRegression(double *x, double *y, 
                              long size = 0);

virtual void addXY(const double& x, const double& y)
        {
            LinearRegression::addXY(x, log(y));
        }

virtual double getA() const { return exp(a); }

virtual double estimateY(double x) const
        {
            return (exp(a) * exp(b * x));
        }
};

#endif                      // end of expreg.h
