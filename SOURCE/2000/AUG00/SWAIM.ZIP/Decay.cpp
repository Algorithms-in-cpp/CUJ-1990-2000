/*
    DECAY.CPP - Calculations related to nuclear decay
    by: David Swaim

    Demonstration of using the ExponentialRegression class.
*/
#include <iostream.h>
#include <iomanip.h>
#include "expreg.h"

// Au 198 Counts/minute vs elapsed time in hours
double countrate[] = {4810.0, 4215.0, 3705.0, 3281.0, 2850.0,
                      2520.0, 2211.0, 1998.0, 1775.0, 1502.0};
double elapstime[] = {   0.0,   12.0,   24.0,   36.0,   48.0,
                        60.0,   72.0,   84.0,   96.0,  108.0};

// Unknown isotope decay
Point2D p[] = { Point2D(  0.0, 605.0),
                Point2D( 10.0, 530.0),
                Point2D( 20.0, 497.0),
                Point2D( 30.0, 434.0),
                Point2D( 40.0, 402.0),
                Point2D( 50.0, 364.0),
                Point2D( 60.0, 330.0),
                Point2D( 70.0, 297.0),
                Point2D( 80.0, 268.0)};

void main()
{
    int i;

    cout << "Isotope Decay of Gold 198 and an Unknown Isotope"
         << endl << endl;
    cout << "Determination of Decay Constant of Au 198\n"
         << endl;

    ExponentialRegression au( elapstime, countrate, 10);
    cout << "Number of experimental points = "
         << au.items() << endl;
    cout << au << endl;
    cout << "Decay Constant = "
         << au.getB() * -1.0 << " per hour" << endl;
    cout << "The half-life of Au 198 is "
         << log(2) / (au.getB() * -1.0)
         << " hours" << endl;
    cout << "Coefficient of Determination = "
         << au.getCoefDeterm() << endl;
    cout << "Coefficient of Correlation = "
         << au.getCoefCorrel() << endl;
    cout << "Standard Error of Estimate = "
         << au.getStdErrorEst() << endl;

    cout << "\nDetermination of Decay Constant "
         << "for Unknown Isotope\n"
         << endl;

    ExponentialRegression unknown( p, 9);
    cout << "Number of experimental points = "
         << unknown.items() << endl;
    cout << unknown << endl;
    cout << "Decay Constant = "
         << unknown.getB() * -1.0 << " per hour" << endl;
    cout << "The half-life of Unknown Isotope is "
         << log(2) / (-1.0 * unknown.getB())
         << " hours" << endl;
    cout << "Coefficient of Determination = "
         << unknown.getCoefDeterm() << endl;
    cout << "Coefficient of Correlation = "
         << unknown.getCoefCorrel() << endl;
    cout << "Standard Error of Estimate = "
         << unknown.getStdErrorEst() << endl;
}

