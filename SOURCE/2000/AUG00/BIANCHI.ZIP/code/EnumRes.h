//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#ifndef EnumResH
#define EnumResH
//---------------------------------------------------------------------------

void ExtractResInfo(char *sz_file_name);


#endif
