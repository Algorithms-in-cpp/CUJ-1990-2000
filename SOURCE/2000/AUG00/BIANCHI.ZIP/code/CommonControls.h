//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#ifndef CommonControlsH
#define CommonControlsH
//---------------------------------------------------------------------------
#include "PVISUALCONTROL.H"

#include <commctrl.h>


class pCommCtrl : public pVisualControl
{
	public:
		pCommCtrl(char *_sz_type, char *_sz_name, char *_sz_family, char *_sz_dwICC);
		static StringSet ss_dwICC;
};





class pTreeView : public pCommCtrl
{  	int nIndent;

		string strBorderStyle;
      
	public:
		pTreeView(char *_sz_name);
};


class pListView : public pCommCtrl
{     bool bCheckboxes;
      bool bGridLines;
      bool bMultiSelect;
      bool bRowSelect;

      string strViewStyle;
      string strBorderStyle;

      StrList slCols;

		bool ParseVisual(FILE *fin, char *sss);
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);


	public:
		pListView(char *_sz_name);
		bool SetMoreAttr();
};


class pHeaderControl : public pCommCtrl
{		string strStyle;

      StrList slCols;

		bool ParseVisual(FILE *fin, char *sss);
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);

	public:
		pHeaderControl(char *_sz_name);
};


class pTrackBar : public pCommCtrl
{		string strTickMarks;
		string strTickStyle;
      string strOrientation;
      int nMin;
      int nMax;
      int nSelStart;
      int nSelEnd;
      int nPosition;
      int nFrequency;

		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
	public:
		pTrackBar(char *_sz_name);
};


class pProgressBar : public pCommCtrl
{		int nMin;
		int nMax;
      int nPosition;
      bool bSmooth;
      
      string strOrientation;

		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
      bool SetMoreAttr();

	public:
		pProgressBar(char *_sz_name);
};



class pStatusBar : public pCommCtrl
{		string strSimpleText;
		bool bSimplePanel;
      bool bSizeGrip;

      StrList slPanels;

		bool ParseVisual(FILE *fin, char *sss);
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);

	public:
		pStatusBar(char *_sz_name);
};


class pAnimate : public pCommCtrl
{
   int nStopFrame;
   bool bActive;
   bool bCenter;
   string strFileName;

 	public:
		pAnimate(char *_sz_name);
		string GetClassString();
      bool SetMoreAttr();
};


class pToolBar : public pCommCtrl
{	public:
		pToolBar(char *_sz_name);
};


class pUpDownBase : public pCommCtrl
{
	protected:
      int nMin;
      int nMax;
      int nPosition;

      bool bWrap;

		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);

	public:
		pUpDownBase(char *sz_type, char *_sz_name);
};



class pUpDown : public pUpDownBase
{
	public:
		pUpDown(char *_sz_name);
};



class pSpinEdit : public pUpDownBase
{
		bool bReadOnly;

	public:
   	pSpinEdit(char *_sz_name);
		bool SetMoreAttr();
		bool OnVisualParseEnd();
		bool WriteRcRh(StrList& sl_rc, StrList& sl_rh);
      sl_It WriteInit(StrList& sl_cpp, StrList& sl_hpp);
};


class pMonthCal: public pCommCtrl
{
	public:
   	pMonthCal(char * _sz_name);
};



class pDateTimePick: public pCommCtrl
{
	public:
   	pDateTimePick(char * _sz_name);
};


class pPager: public pCommCtrl
{
	public:
   	pPager(char * _sz_name);
};


class pReBarWindow: public pCommCtrl
{
	public:
   	pReBarWindow(char * _sz_name);
};



class pHotKey : public pCommCtrl
{
	public:
   	pHotKey(char *_sz_name);
};



class pTabControl : public pCommCtrl
{		string strStyle;
		string strTabPosition;
      bool bMultiLine;
      int nTabIndex;

      StrList slTabs;

		bool ParseVisual(FILE *fin, char *sss);
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
		bool SetMoreAttr();

	public:
   	pTabControl(char * _sz_name);
};



class pImageList : public pCommCtrl
{		string strFileName;
		string strForm;
	public:
   	pImageList(char *_sz_name, const char *_sz_form);
  		bool ParseVisual(FILE *fin, char *sss);
		bool WriteRcRh(StrList& sl_rc, StrList& sl_rh);
};


//////////////////////

#endif
