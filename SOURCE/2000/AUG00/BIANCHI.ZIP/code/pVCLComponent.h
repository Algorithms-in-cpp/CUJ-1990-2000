//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#ifndef PVCLCOMPONENTH
#define PVCLCOMPONENTH

#include "StlUtils.h"
//---------------------------------------------------------------------------


#define BEFORE_DIALOG_RC 		("//BEFORE_DIALOG_RC")
#define BEFORE_DIALOG_PROC 	("//BEFORE_DIALOG_PROC")

#define INSIDE_DIALOG_PROC 	("//INSIDE_DIALOG_PROC")
#define INSIDE_SWITCH_MESSAGE ("//INSIDE_SWITCH_MESSAGE")
#define INSIDE_WM_COMMAND		("//INSIDE_WM_COMMAND")
#define INSIDE_WM_PAINT			("//INSIDE_WM_PAINT")
#define INSIDE_HPP 				("//INSIDE_HPP")

#define OUT_OF_DIALOG_PROC 	("//OUT_OF_DIALOG_PROC")
#define OUT_OF_SWITCH_MESSAGE ("//OUT_OF_SWITCH_MESSAGE")



class pVCLComponent
{
	public:
		pVCLComponent(const char *_sz_type, const char *_sz_name, const char *_sz_include);
      virtual ~pVCLComponent();

   	bool Parse(FILE *fin, char *sss, int level);
		int ParseItems(FILE *fin, StrList& items);
		int ParseCollection(FILE *fin, StrList& items);
		unsigned char TwoChToByte(FILE *fin, char& ch);

      int GetLevel();
      virtual bool OnParseEnd();
      string GetName();
      const char *GetType();

		void LookForInt(const char *prop, int *dest, int def_val = 0);
		void LookForBool(const char *prop, bool *dest, bool def_val = true);
		void LookForText(const char *prop, string* dest, string def_val = "");
      void LookForInfo(const char *prop, string* dest, string def_val = "");
		virtual bool WriteCppHpp(StrList& sl_cpp, StrList& sl_hpp);
      static StringSet ss_include;

   protected:
		inline void NextChar(FILE *fin, char ch);
		virtual bool ParseMore(FILE *fin, char *sss);
		sl_It HandleMessage(StrList& sl, const string& msg, const string& code);

   	string strName;
   	string strType;

   	IntMap im;
      StringMap sm_info;
      StringMap sm_text;
      BoolMap bm;
      int level;
};




#endif
