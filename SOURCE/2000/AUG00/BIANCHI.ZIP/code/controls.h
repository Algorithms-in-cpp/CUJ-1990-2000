//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#ifndef ControlsH
#define ControlsH
//---------------------------------------------------------------------------

#include "pVisualControl.h"
#include <dir.h>


class pStatic : public pVisualControl
{	public:
		pStatic(const char *_sz_type, char *_sz_name);
};


class pLabel : public pStatic
{		string strAlignment;
	public:
   	pLabel(char *sz_name);
};


class pPanel : public pStatic
{  	string strBevelInner;
	  	string strBevelOuter;

	public:
		pPanel(char *sz_name);
		sl_It WriteCppHppMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
};


class pBevel : public pStatic
{  	string strStyle;
		string strShape;

      bool OnVisualParseEnd();
	public:
   	pBevel(char *sz_name);
};




class pButtonBase : public pVisualControl
{	public:
		pButtonBase(char *_sz_type, char *_sz_name);
};


class pButton : public pButtonBase
{	public:
		pButton(char *_sz_name);
};


class pRadioButton : public pButtonBase
{		bool bChecked;
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
	public:
		pRadioButton(char *_sz_name);
};


class pCheckBox : public pButtonBase
{		bool bChecked;
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
	public:
		pCheckBox(char *_sz_name);
};

class pSpeedButton : public pButtonBase
{		string strFileName;
		string strForm;
	public:
		pSpeedButton(char *_sz_name, const char *_sz_form);
		bool WriteRcRh(StrList& sl_rc, StrList& sl_rh);
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
		sl_It WriteCppHppMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
		bool ParseVisual(FILE *fin, char *sss);
};


class pBitBtn : public pButtonBase
{		string strKind;
		string to_do;

		sl_It WriteCppHppMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
      bool OnVisualParseEnd();
	public:
		pBitBtn(char *_sz_name);
};



class pRadioGroup : public pVisualControl
{		StrList items;
		int nItemIndex;
	public:
		pRadioGroup(char *_sz_name);
      bool ParseVisual(FILE *fin, char *sss);
		bool WriteRcRh(StrList& sl_rc, StrList& sl_rh);
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
      bool OnVisualParseEnd();
};


class pImage : public pStatic
{		string strFileName;
		string strForm;
      string strClass;
	public:
		pImage(char *_sz_name, const char *_sz_form);
		bool WriteRcRh(StrList& sl_rc, StrList& sl_rh);
		bool ParseVisual(FILE *fin, char *sss);
};


class pListBox : public pVisualControl
{		StrList items;
		bool bMultiSelect;
      int nItemHeight;
      bool bSorted;

		string strBorderStyle;
	protected:
		bool SetMoreAttr();
      bool ParseVisual(FILE *fin, char *sss);
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);

	public:
		pListBox(char *_sz_name);
};


class pComboBox : public pVisualControl
{		StrList items;
      int nItemHeight;
      int nDropDownCount;
      bool bSorted;
      string strStyle;

	protected:
		bool SetMoreAttr();
      bool ParseVisual(FILE *fin, char *sss);
      bool OnVisualParseEnd();
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);

	public:
		pComboBox(char *_sz_name);
      bool WriteSetup(FILE *fout);
};


class pEdit : public pVisualControl
{
		bool bReadOnly;
		bool bHideSelection;
      bool bOEMConvert;

	   string strCharCase;
      string strText;
	public:
		pEdit(char *_sz_name);

   protected:
		bool SetMoreAttr();
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
};


class pMemo : public pVisualControl
{
		bool bReadOnly;
		string strScrollBars;
      StrList sl_Lines;
	public:
   	pMemo(char *_sz_name);

   protected:
		bool SetMoreAttr();
      bool ParseVisual(FILE *fin, char *sss);
		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);

};


class pGroupBox : public pVisualControl
{	public:
		pGroupBox(char *_sz_name);
};


class pRichEdit : public pVisualControl
{		StrList sl_Lines;
		string    strBorderStyle;

	public:
		pRichEdit(char *_sz_name);
      ~pRichEdit();
      bool ParseVisual(FILE *fin, char *sss);

   protected:
  		sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);

	private :
		static bool bDllLoad;
};


class pScrollBar : public pVisualControl
{  	int nPageSize;
	private:
		bool SetMoreAttr();
	public:
		pScrollBar(char *_sz_name);
};


//////////////////////

#endif
