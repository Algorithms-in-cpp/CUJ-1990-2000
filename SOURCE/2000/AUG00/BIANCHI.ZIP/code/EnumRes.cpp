//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include <dir>
#include <string>
#include "EnumRes.h"
using namespace std;


BOOL EnumNamesFunc(HANDLE hModule, LPCSTR lpType, LPSTR lpName, LONG lParam)
{  HANDLE hResInfo = FindResourceEx(hModule, lpType, lpName, MAKELANGID(LANG_NEUTRAL, SUBLANG_NEUTRAL));

	if (!hResInfo)
   	return TRUE;

   char *res_ptr = (char *) LoadResource(hModule, hResInfo);
   char sz_name[255];

   for (int i = 0; i < 4; i++)
      sz_name[i] = res_ptr[i];
   sz_name[4] = '\0';

   if (!strcmp(sz_name, "TPF0"))
   {  int lung = res_ptr[4];
      for (int i = 0; i < lung; i++)
         sz_name[i] = (char)toupper(res_ptr[i + 5]);
      sz_name[lung] = '\0';

      char sz_dfm_file_name[MAXPATH];
      wsprintf(sz_dfm_file_name, "vcl%s.dfm", sz_name);

      HANDLE hFileDfm = CreateFile(sz_dfm_file_name,
         GENERIC_READ | GENERIC_WRITE, 0, //do not share object
         (LPSECURITY_ATTRIBUTES) NULL, CREATE_ALWAYS,
         FILE_ATTRIBUTE_NORMAL, (HANDLE) NULL);

      DWORD cbWritten;

      BYTE bytes1[3] = {0xFF, 0x0A, 0x00};
      BYTE bytes2[3] = {0x00, 0x30, 0x10};
	   DWORD dwSize = SizeofResource(hModule, hResInfo);
      WriteFile(hFileDfm, bytes1, (DWORD) sizeof(bytes1), &cbWritten, NULL);
      WriteFile(hFileDfm, sz_name, (DWORD) strlen(sz_name), &cbWritten, NULL);
      WriteFile(hFileDfm, bytes2, (DWORD) sizeof(bytes2), &cbWritten, NULL);
      WriteFile(hFileDfm, &dwSize, sizeof(dwSize), &cbWritten, NULL);
      WriteFile(hFileDfm, res_ptr, dwSize, &cbWritten, NULL);

   	CloseHandle(hFileDfm);
   }

   return TRUE;
}




void ExtractResInfo(char *sz_file_name)
{	HINSTANCE hMod = LoadLibraryEx(sz_file_name, NULL, LOAD_LIBRARY_AS_DATAFILE);

	if (!hMod)
   {  MessageBox(NULL, "Could not load File", "ERROR", MB_OK);
      return;
   }

	EnumResourceNames(hMod, RT_RCDATA, (ENUMRESNAMEPROC)EnumNamesFunc, 0);
	FreeLibrary(hMod);
}
