//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "DialogBox.h"
#include "controls.h"
#include "CommonControls.h"
#include "CommonDialogs.h"
#include "pmenu.h"

#include <vector>

typedef list <pVisualControl*> VCList;
typedef VCList::iterator VC_iter;

typedef list <pVCLComponent*> ObjList;
typedef ObjList::iterator OL_iter;

typedef list <pMenuBase*> MBList;
typedef MBList::iterator MB_iter;


struct LowerTab
{	bool operator()(pVisualControl* vc1, pVisualControl* vc2)
	{	return vc1->GetTabIndex() < vc2->GetTabIndex();		}
}	lower_tab;


struct LowerLevel
{	bool operator()(pVisualControl* vc1, pVisualControl* vc2)
	{	return vc1->GetLevel() < vc2->GetLevel();		}
}	lower_level;


pVCLComponent* GetVCLComponent(char* szName, char *sz_orig_type,
										const char* dlg_box_name)
{	pVCLComponent *cmp = NULL;

	char szPath[MAXPATH], drive[MAXDRIVE], dir[MAXDIR],
   		file[MAXFILE], ext[MAXEXT], sz_type[64];

   GetModuleFileName(0, szPath, sizeof(szPath));
   fnsplit(szPath, drive, dir, file, ext);

   wsprintf(szPath, "%s%sconvert.xfr", drive, dir);

   GetPrivateProfileString(sz_orig_type, "Into", &sz_orig_type[1], sz_type, sizeof(sz_type), szPath);

   if (!strcmpi(sz_type, "Ignore"))
   	return NULL;

   if (!strcmpi(sz_type, "Animate")) cmp = new pAnimate(szName);
   if (!strcmpi(sz_type, "Bevel")) cmp = new pBevel(szName);
   if (!strcmpi(sz_type, "BitBtn")) cmp = new pBitBtn(szName);
   if (!strcmpi(sz_type, "Button")) cmp = new pButton(szName);
   if (!strcmpi(sz_type, "CheckBox")) cmp = new pCheckBox(szName);
   if (!strcmpi(sz_type, "ComboBox")) cmp = new pComboBox(szName);
   if (!strcmpi(sz_type, "DateTimePicker")) cmp = new pDateTimePick(szName);
   if (!strcmpi(sz_type, "Edit")) cmp = new pEdit(szName);
   if (!strcmpi(sz_type, "GroupBox")) cmp = new pGroupBox(szName);
   if (!strcmpi(sz_type, "Header")) cmp = new pHeaderControl(szName);
   if (!strcmpi(sz_type, "HotKey")) cmp = new pHotKey(szName);
   if (!strcmpi(sz_type, "Image")) cmp = new pImage(szName, dlg_box_name);
   if (!strcmpi(sz_type, "Label")) cmp = new pLabel(szName);
   if (!strcmpi(sz_type, "ListBox")) cmp = new pListBox(szName);
   if (!strcmpi(sz_type, "ListView")) cmp = new pListView(szName);
   if (!strcmpi(sz_type, "Memo")) cmp = new pMemo(szName);
   if (!strcmpi(sz_type, "MonthCalendar")) cmp = new pMonthCal(szName);
   if (!strcmpi(sz_type, "Panel")) cmp = new pPanel(szName);
   if (!strcmpi(sz_type, "ProgressBar")) cmp = new pProgressBar(szName);
   if (!strcmpi(sz_type, "RadioButton")) cmp = new pRadioButton(szName);
   if (!strcmpi(sz_type, "RadioGroup")) cmp = new pRadioGroup(szName);
   if (!strcmpi(sz_type, "RichEdit")) cmp = new pRichEdit(szName);
   if (!strcmpi(sz_type, "ScrollBar")) cmp = new pScrollBar(szName);
   if (!strcmpi(sz_type, "SpeedButton")) cmp = new pSpeedButton(szName, dlg_box_name);
   if (!strcmpi(sz_type, "SpinEdit")) cmp = new pSpinEdit(szName);
   if (!strcmpi(sz_type, "StatusBar")) cmp = new pStatusBar(szName);
   if (!strcmpi(sz_type, "ToolBar")) cmp = new pToolBar(szName);
   if (!strcmpi(sz_type, "TabControl")) cmp = new pTabControl(szName);
   if (!strcmpi(sz_type, "TrackBar")) cmp = new pTrackBar(szName);
   if (!strcmpi(sz_type, "TreeView")) cmp = new pTreeView(szName);
   if (!strcmpi(sz_type, "UpDown")) cmp = new pUpDown(szName);

   if (!strcmpi(sz_type, "MenuItem")) cmp = new pMenuItem(szName);
   if (!strcmpi(sz_type, "MainMenu")) cmp = new pMenu("MAINMENU", szName);
   if (!strcmpi(sz_type, "PopupMenu")) cmp = new pMenu("POPUPMENU", szName);

   if (!strcmpi(sz_type, "FontDialog")) cmp = new pFontDlg(szName);
   if (!strcmpi(sz_type, "FindDialog")) cmp = new pFindDlg(szName);
   if (!strcmpi(sz_type, "ReplaceDialog")) cmp = new pReplaceDlg(szName);
   if (!strcmpi(sz_type, "ColorDialog")) cmp = new pColorDlg(szName);
   if (!strcmpi(sz_type, "OpenDialog")) cmp = new pOpenFileDlg(szName);
   if (!strcmpi(sz_type, "SaveDialog")) cmp = new pSaveFileDlg(szName);

   if (!cmp) MessageBox(NULL, sz_type, "Unknown!", MB_OK);

   return cmp;
}


bool SkipComponent(FILE *fin, int pos)
{	char ch4[4] = {0,0,0,0};

   while (!feof(fin))
   { 	for (int i = 0; i <= pos; i++)
         ch4[0] = fgetc(fin);

      fscanf(fin, "%2s", &ch4[1]);
      if (!strcmpi(ch4, "end"))
			return true;
      else
      {	ch4[0] = fgetc(fin);
		   while (ch4[0] != '\n')
      		ch4[0] = fgetc(fin);
      }
   }
	return false;
}




void RecurseFile(FILE *fin, ObjList& ol, char *sz,
			char *szName, char *szType, const char *szForm)
{
  	int pos;
   while (!feof(fin))
   {  if (!strcmpi(sz, "object"))
      {  fscanf(fin, "%s", szName);
      	if (szName[strlen(szName) - 1] == ':')
         {	szName[strlen(szName) - 1] = 0;
         	fscanf(fin, "%s", szType);
         }
         else
         {	strcpy(szType, szName);
         	wsprintf(szName, "UnnamedObj%d", ol.size());
         }

         pVCLComponent *obj = NULL;
         obj = GetVCLComponent(szName, szType, szForm);

         fscanf(fin, "%s%n", sz, &pos);
         pos -= (3 + strlen(sz));

         if (obj)
         {	ol.push_back(obj);
	        	obj->Parse(fin, sz, pos / 2);
	         if (!strcmpi(sz, "object"))
   	        	RecurseFile(fin, ol, sz, szName, szType, szForm);
         }
         else
         	SkipComponent(fin, pos);
      }
     	fscanf(fin, "%s", sz);
	}
}


//////////////////////
//////////////////////
int DfmConvert(char *szFnDfm, int form_id, int ctl_id_base,
					int ratio_x, int ratio_y)
{  char sss[256], sz_name[256], sz_type[256];
   char drv[MAXDRIVE], dir[MAXDIR], file[MAXFILE], ext[MAXEXT];
   char szFnTxt[MAXPATH], szFnCpp[MAXPATH], szFnHpp[MAXPATH];
   char szFnRc[MAXPATH], szFnRh[MAXPATH];

	VCList vc_list;
   MBList mb_list;
   ObjList obj_list;

   fnsplit(szFnDfm, drv, dir, file, ext);

	string str_file = file;

   fnmerge(szFnTxt, drv, dir, file, ".txt");
	fnmerge(szFnRc, drv, dir, file, ".rc");
	fnmerge(szFnRh, drv, dir, file, ".rh");

   if (!strcmpi(".dfm", ext))
   {  TFileStream *dfm = new TFileStream(szFnDfm, fmOpenRead);
      TFileStream *txt = new TFileStream(szFnTxt, fmCreate);
      ObjectResourceToText(dfm, txt);
      delete dfm;
      delete txt;
   }
   else
   	if (strcmpi(".txt", ext))
      	return -10;

	wsprintf(szFnCpp, "%s%sAPI_%s.cpp", drv, dir, file);
   wsprintf(szFnHpp, "%s%sAPI_%s.hpp", drv, dir, file);

	FILE *fin = fopen(szFnTxt, "rt");
   if (!fin) return -20;

   fscanf(fin, "%*s %*s %s %s", sz_name, sss);
//the first component is the Form
   pVisualObject::global_id = form_id;
   pDialogBox *dlg_box = new pDialogBox(sz_name, "");
   dlg_box->Parse(fin, sss, 0);

   obj_list.push_back(dlg_box);

   pVisualObject::global_id = ctl_id_base;

   RecurseFile(fin, obj_list, sss, sz_name, sz_type,
   				dlg_box->GetName().c_str());
   fclose(fin);

   for (OL_iter i = obj_list.begin(); i != obj_list.end(); i++)
   {  pVisualControl *vc = dynamic_cast <pVisualControl*>(*i);
      pMenuBase *mb = dynamic_cast <pMenuBase *> (*i);

      if (vc) vc_list.push_back(vc);
      if (mb) mb_list.push_back(mb);
   }

 //offset
	vector <pPoint> pv;
   for (VC_iter i = vc_list.begin(); i != vc_list.end(); i++)
   { 	int level = (*i)->GetLevel() - 1;

      if (level >= pv.size())
         pv.push_back((*i)->GetTopLeft());
      else
	     	pv[level] = (*i)->GetTopLeft();

      if (level > 0)
      	for (int n = 0; n < level; n++)
				(*i)->OffsetBy(pv[n]);
   }

   ///////
   ///////

 	long dbu = GetDialogBaseUnits();
   float r_x = 4. / (float)LOWORD(dbu) * ratio_x / 100.;
   float r_y = 8. / (float)HIWORD(dbu) * ratio_y / 100.;

   for (VC_iter i = vc_list.begin(); i != vc_list.end(); i++)
   	(*i)->Resize(r_x, r_y);

	dlg_box->Resize(r_x, r_y);

   StrList SL_RC, SL_RH, SL_CPP, SL_HPP;

   SL_RC.Append("//VCL Form Converter, by Luigi Bianchi\n\n");
   SL_RC.Append("#include \"" + str_file + ".rh\"\n\n");
   SL_RH.Append("#if !defined " + str_file +
   					"_hpp_\n\t#define " + str_file + "_hpp_\n\n");

   int curr_level, prev_level = -1;
   pMenuItem *mi_prev = NULL;
   bool bNewMenu = false;
   for (MB_iter i = mb_list.begin(); i != mb_list.end(); i++)
   {  curr_level = (*i)->GetLevel();
   	if (prev_level == -1)
      	prev_level = curr_level;

   	pMenuItem *mi = dynamic_cast<pMenuItem*>(*i);
   	if (mi)
      {  bNewMenu = false;
      	if (mi_prev)
         	mi_prev->SetIndent(curr_level - prev_level);

         prev_level = curr_level;
         mi_prev = mi;
      }
      else   // new menu
      {  if (bNewMenu)  // Borland uses empty menus in BCB
      	{	MB_iter p = i--;
         	mb_list.remove(*p);
            continue;
         }

      	bNewMenu = true;
      	if (mi_prev)
      	{	mi_prev->SetIndent(curr_level - prev_level);
      		mi_prev = NULL;
            prev_level = curr_level;
         }
      }
   }
   if (mi_prev)
     	mi_prev->SetIndent(1 - prev_level);
   if (bNewMenu)  // Borland uses empty menus in BCB
   	mb_list.pop_back();

   for (MB_iter i = mb_list.begin(); i != mb_list.end(); i++)
   	(*i)->WriteRcRh(SL_RC, SL_RH);

   SL_RC.Append("\n\n");
   SL_RH.Append("\n\n");

   vc_list.sort(lower_tab);
   vc_list.sort(lower_level);

  	dlg_box->WriteRcRh(SL_RC, SL_RH);

   for (VC_iter i = vc_list.begin(); i != vc_list.end(); i++)
     	(*i)->WriteRcRh(SL_RC, SL_RH);

   SL_RC.Append("}\n\n//VCL Form Converter, by Luigi Bianchi");
   SL_RH.Append("\n\n#endif");

 	SL_RC.WriteFile(szFnRc);
 	SL_RH.WriteFile(szFnRh);

//CPP
   SL_CPP.Append("#include <windows.h>\n");

   for (ss_iter i = pVCLComponent::ss_include.begin();
   			i != pVCLComponent::ss_include.end(); i++)
      			SL_CPP.Append("#include " + string(*i));

   SL_CPP.Append("\n#include \"API_" + str_file + ".hpp\"\n");

   SL_CPP.Append("//{{Implementation}}\n");
   SL_CPP.Append("// ---------------------------------------");
   SL_CPP.Append("// " + dlg_box->GetName());
   SL_CPP.Append("// ~~~~~~~~~~~");
   SL_CPP.Append("//\n\n");
//	HPP	///////////////////////////////////////////////

	string str_def = "api_" + dlg_box->GetName() + "_hpp";
   SL_HPP.Append("#if !defined(" + str_def + ")");
   SL_HPP.Append("#define api_" + str_def);
   SL_HPP.Append("\n#include \"" + str_file + ".rh\"");
   SL_HPP.Append(INSIDE_HPP);
   SL_HPP.Append("#endif  // " + str_file + "_h sentry");

   for (OL_iter i = obj_list.begin(); i != obj_list.end(); i++)
      (*i)->WriteCppHpp(SL_CPP, SL_HPP);

   SL_CPP.WriteFile(szFnCpp);
   SL_HPP.WriteFile(szFnHpp);

   for (OL_iter i = obj_list.begin(); i != obj_list.end(); i++)
     	delete (*i);

  return 0;
}

