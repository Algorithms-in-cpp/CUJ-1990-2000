//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#ifndef processH
#define processH
//---------------------------------------------------------------------------

int DfmConvert(char *sz_file_in, int form_id, int ctl_id_base, int ratio_x, int ratio_y);

#endif
