//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#ifndef pResComponent_H
#define pResComponent_H
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
#include "PVCLCOMPONENT.h"

class pResComponent : public pVCLComponent
{
	public:
		pResComponent(const char *_sz_type, const char *_sz_name, const char *_sz_include);
      virtual ~pResComponent();
		virtual bool WriteRcRh(StrList& sl_rc, StrList& sl_rh);

		static int global_id;

	protected :
		sl_It HandleWmCommand(StrList& sl, const string& code);
		const char* GetId();

		string strId;
		int id;
};

#endif