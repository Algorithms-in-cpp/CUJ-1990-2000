//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include "pCommDialogs.h"
#include <dir.h>


string pCommDialogs::strFileOptions;


pCommDialogs::pCommDialogs(char *_sz_type, char *_sz_name, char *_sz_struct, char *_sz_include) : pVCLComponent(_sz_type, _sz_name, _sz_include)
{  strStructName = _sz_struct;

	if (!strFileOptions.size())
   {
		char szPath[MAXPATH], drive[MAXDRIVE], dir[MAXDIR], file[MAXFILE], ext[MAXEXT];

   	GetModuleFileName(0, szPath, sizeof(szPath));
   	fnsplit(szPath, drive, dir, file, ext);

      strFileOptions = drive + string(dir) + "commdlg.opt";
   }
}


pCommDialogs::~pCommDialogs()
{	}


bool pCommDialogs::ParseMore(FILE *fin, char *sss)
{	if (!strcmpi(sss, "Options"))
   {  slOptions.clear();
   	ParseCollection(fin, slOptions);
      return true;
   }
	return ParseCommDlg(fin, sss);
}


bool pCommDialogs::ParseCommDlg(FILE *fin, char *sss)
{	return false;	}



bool pCommDialogs::OnParseEnd()
{  const int buf_size = 512;
	char sz_flag[buf_size];

   GetPrivateProfileString(strStructName.c_str(), "Always", "0x0000", sz_flag, buf_size, strFileOptions.c_str());
   strFlags = sz_flag;

   if (slOptions.size())
   {
	   for (sl_It i = slOptions.begin(); i != slOptions.end(); i++)
   	{ 	if (GetPrivateProfileString(strStructName.c_str(), (*i).c_str(), "", sz_flag, buf_size, strFileOptions.c_str()))
   			strFlags += string(" | " + string(sz_flag));
	   }
   }
   else
	{ 	if (GetPrivateProfileString(strStructName.c_str(), "Default", "", sz_flag, buf_size, strFileOptions.c_str()))
	   	strFlags += sz_flag;
   }

	return OnParseCommDlgEnd();
}


bool pCommDialogs::OnParseCommDlgEnd()
{
	return false;
}


bool pCommDialogs::WriteCppHpp(StrList& sl_cpp, StrList& sl_hpp)
{  sl_cpp.Insert_A_After_B("\tstatic " + strStructName + " " + strName + ";", INSIDE_DIALOG_PROC);

	string str = "\n\t\t\tZeroMemory(&" + strName + ", sizeof(" + strStructName + "));";
	sl_It pos = HandleMessage(sl_cpp, "WM_INITDIALOG", str);
   pos = sl_cpp.Insert(++pos, "\t\t\t" + strName + ".hwndOwner = hWnd;");
   pos = sl_cpp.Insert(++pos, "\t\t\t" + strName + ".lStructSize = sizeof(" + strStructName + ");");
   pos = sl_cpp.Insert(++pos, "\t\t\t" + strName + ".Flags = " + strFlags + ";");

	return WriteCommDlgCppHpp(sl_cpp, sl_hpp, pos);
}


bool pCommDialogs::WriteCommDlgCppHpp(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{
   return false;
}

