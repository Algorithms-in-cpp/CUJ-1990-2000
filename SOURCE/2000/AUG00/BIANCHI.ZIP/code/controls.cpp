//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include "Controls.h"

/////////////////pStaticBase
/////////////////pStaticBase
pStatic::pStatic(const char *_sz_type, char *_sz_name) : pVisualControl(_sz_type, _sz_name, "static")
{	strCaption = "";	}


////////////////pLabel
////////////////pLabel
pLabel::pLabel(char *_sz_name) : pStatic("Label", _sz_name)
{	LookForAttr("Alignment", &strAlignment, "taLeftJustify");	}


/////////////////pPanel
/////////////////pPanel
pPanel::pPanel(char *_sz_name) : pStatic("Panel", _sz_name)
{	LookForInfo("BevelInner", &strBevelInner);
	LookForInfo("BevelOuter", &strBevelOuter);

   bVisible = false;
}





sl_It pPanel::WriteCppHppMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{
	string strRect = "rect" + strName;
   string value = "RECT " + strRect + ";";

   value += "\n\t\t\t" + strRect + ".left = " + (top_left.x) + ";";
   value += "\n\t\t\t" + strRect + ".top = " + (top_left.y) + ";";
   value += "\n\t\t\t" + strRect + ".right = " + (top_left.x + width) + ";";
   value += "\n\t\t\t" + strRect + ".bottom = " + (top_left.y + height) + ";";
   value += "\n\t\t\tMapDialogRect(hWnd, &" + strRect + ");";

	string strEdge = "0x00";

   if ((strBevelInner == "bvRaised") || (strBevelInner == "bvSpace"))
   	strEdge += " | BDR_RAISEDINNER";
   else if (strBevelInner == "bvLowered") strEdge += " | BDR_SUNKENINNER";

   if ((strBevelOuter == "bvRaised") || (strBevelOuter == "bvSpace"))
   	strEdge += " | BDR_RAISEDOUTER";
   else if (strBevelOuter == "bvLowered") strEdge += " | BDR_SUNKENOUTER";

   value += "\n\t\t\tDrawEdge(ps.hdc, &" + strRect + ", " + strEdge + ", BF_RECT	);\n";
	return HandleWmPaint(sl_cpp, value);
}

/////////////////pBevel
/////////////////pBevel
pBevel::pBevel(char *_sz_name) : pStatic("Bevel", _sz_name)
{	LookForAttr("Style", &strStyle, "bsLowered");
	LookForAttr("Shape", &strShape, "bsBox");
}


bool pBevel::OnVisualParseEnd()
{  if (strShape == "bsBottomLine")
   {	top_left.y += height;
      height = 1;
   }

   if (strShape == "bsTopLine")
      height = 1;

   if (strShape == "bsLeftLine")
      width = 1;

   if (strShape == "bsRightLine")
   {	top_left.x += width;
      width = 1;
   }
   return true;
}


//---------------------------------------------------------------------------
/////////////////pButtonBase
/////////////////pButtonBase
pButtonBase::pButtonBase(char *_sz_type, char *_sz_name) : pVisualControl(_sz_type, _sz_name, "button")
{}



/////////////////pButton
/////////////////pButton
pButton::pButton(char *_sz_name) : pButtonBase("Button", _sz_name)
{}



/////////////////pBitBtn
/////////////////pBitBtn
pBitBtn::pBitBtn(char *_sz_name) : pButtonBase("BitBtn", _sz_name)
{	LookForAttr("Kind", &strKind, "bkCancel");	}


bool pBitBtn::OnVisualParseEnd()
{
	if (strKind == "bkCancel")
   {	to_do = "EndDialog(hWnd, IDCANCEL);";
   	strCaption = "Cancel";
   }
   else
		if (strKind == "bkOK")
      {	to_do = "EndDialog(hWnd, IDOK);";
      	strCaption = "OK";
      }
      else
			if (strKind == "bkYes")
         {	to_do = "EndDialog(hWnd, IDYES);";
         	strCaption = "Yes";
         }
	      else
				if (strKind == "bkNo")
            {	to_do = "EndDialog(hWnd, IDNO);";
            	strCaption = "no";
            }
	return true;
}


sl_It pBitBtn::WriteCppHppMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{
	return HandleWmCommand(sl_cpp, to_do);
}




////////////////pCheckBox
////////////////pCheckBox
pCheckBox::pCheckBox(char *_sz_name) : pButtonBase("CheckBox", _sz_name)
{	LookForBool("Checked", &bChecked, false);	}


sl_It pCheckBox::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  if (bChecked)
		pos = sl_cpp.Insert(++pos, "\t\t\tCheckDlgButton(hWnd, " + strId + (bChecked ? ", BST_CHECKED);" : ", BST_UNCHECKED);"));
	return pos;
}




////////////////pRadioButton
////////////////pRadioButton
pRadioButton::pRadioButton(char *_sz_name) : pButtonBase("RadioButton", _sz_name)
{	LookForBool("Checked", &bChecked, false);	}

sl_It pRadioButton::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  if (bChecked)
		pos = sl_cpp.Insert(++pos, "\t\t\tCheckRadioButton(hWnd, " + strId + ", " + strId + ", " + strId + ");");
	return pos;
}



/////////////////pSpeedButton
/////////////////pSpeedButton
pSpeedButton::pSpeedButton(char *_sz_name, const char *_sz_form) : pButtonBase("SpeedButton", _sz_name)
{	strForm = _sz_form;	}


bool pSpeedButton::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Glyph.Data"))
   {  NextChar(fin, '\n');

      char ch = fgetc(fin);
      while(ch == ' ') ch = fgetc(fin);

      for (int i = 0; i < 8; i++)
      	ch = fgetc(fin);

		strFileName = strForm + strName + ".bmp";
      AddAttr("BS_BITMAP");

      FILE *fout = fopen(strFileName.c_str(), "wb");

      if (fout)
      {  while (ch != '}')
         { 	fprintf(fout, "%c", TwoChToByte(fin, ch));
            while ((ch == ' ') || (ch == '\n'))
               ch = fgetc(fin);
         }
	      fclose(fout);
      }
      else NextChar(fin, '}');

      NextChar(fin, '\n');
      return true;
   }

   return false;
}


bool pSpeedButton::WriteRcRh(StrList& sl_rc, StrList& sl_rh)
{ 	if (strFileName.size())
   {	sl_It i = find(sl_rc.begin(), sl_rc.end(), BEFORE_DIALOG_RC);
   	if (i != sl_rc.end())
   		sl_rc.insert(i, strId + " BITMAP " + strFileName);
   }

   string str_rc = " CONTROL ";
   if (strFileName.size())
	   str_rc += "\"\", ";
   else
   	str_rc += "\"" + strCaption + "\", ";
   str_rc += strId + ", \"" + strCtlFamily + "\", WS_CHILD";

   for (sl_It i = sl_attr.begin(); i != sl_attr.end(); i++)
   	str_rc += " | " + (*i);

   sl_rc.push_back(str_rc + ", " + top_left.x + ", " + top_left.y + ", " + width + ", " + height);

   sl_rh.push_back("#define " + strId + " " + id);

   return true;
}


sl_It pSpeedButton::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{
	if (strFileName.size())
   {
      string strBmp = "hBmp" + strName;
      sl_cpp.Insert_A_After_B( "\tstatic HBITMAP " + strBmp + ";", INSIDE_DIALOG_PROC);

      string str2 = "\t\t\t" + strBmp + " = LoadBitmap(GetModuleHandle(0), MAKEINTRESOURCE(" + strId + "));";
      pos = sl_cpp.insert(++pos, str2);
      string str3 = "\t\t\tSendMessage(" + strCtlHWND + ", BM_SETIMAGE, IMAGE_BITMAP, (LPARAM) " + strBmp + ");";
      pos = sl_cpp.insert(++pos, str3);
   }

   return pos;
}


sl_It pSpeedButton::WriteCppHppMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{	return HandleWmCommand(sl_cpp, "//write code here");	}




/////////////////pRadioGroup      //questo va fatto bene
/////////////////pRadioGroup
pRadioGroup::pRadioGroup(char *_sz_name) : pVisualControl("RadioGroup",  _sz_name, "button")
{	LookForInt("ItemIndex", &nItemIndex);	}


bool pRadioGroup::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Items.Strings"))
   { 	ParseItems(fin, items);
      return true;
   }
   return false;
}


bool pRadioGroup::OnVisualParseEnd()
{	global_id += items.size();
   return true;
}


bool pRadioGroup::WriteRcRh(StrList& sl_rc, StrList& sl_rh)
{  string str_rc = " CONTROL \"" + GetClassString() + "\", " + strId + ", \"" + strCtlFamily + "\", WS_CHILD";

   for (sl_It i = sl_attr.begin(); i != sl_attr.end(); i++)
     str_rc += " | " + (*i);

   sl_rc.push_back(str_rc + ", " + top_left.x + ", " + top_left.y + ", " + width + ", " + height);
   sl_rh.push_back("#define " + strId + " " + id);

//here the
   int pos = 0;
   int step_y = height / (float)(items.size() + 1);

	for (sl_It i = items.begin(); i != items.end(); i++, pos++)
   { 	string new_id = strId + "_ITEM_" + (pos + 1);
   	sl_rc.push_back(" CONTROL \"" + (*i) + "\", " + new_id +
      	", \"button\", BS_AUTORADIOBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP" + ((i == items.begin()) ? " | WS_GROUP" : "") + ", " +
         (top_left.x + 5) + ", " + (top_left.y + pos * step_y + 4 * step_y / 5) + ", " + (width - 7) + ", " + step_y);

	   sl_rh.push_back("#define " + new_id + " " + (id + pos + 1));
   }

   return true;
}


sl_It pRadioGroup::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  return sl_cpp.Insert(++pos, "\t\t\tCheckRadioButton(hWnd, " +
								strId + "_ITEM_1, " + strId + "_ITEM_" + items.size() +
                        ", " + strId + "_ITEM_" + (nItemIndex + 1 ) + ");");
}

/////////////////pImage
/////////////////pImage


pImage::pImage(char *_sz_name, const char *_sz_form) : pStatic("Static", _sz_name)
{	strForm = _sz_form;	}


bool pImage::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Picture.Data"))
   {  NextChar(fin, '\n');

      char ch = fgetc(fin);
      while(ch == ' ')
      	ch = fgetc(fin);

      char sz_type[64];
      int lun = TwoChToByte(fin, ch);
      for (int i = 0; i < lun; i++)
      	sz_type[i] = TwoChToByte(fin, ch);
      sz_type[lun] = '\0';

      strFileName = strForm + strName;

      if (!strcmpi("TBitmap", sz_type))
      {  strFileName += ".bmp";
      	strClass = "BITMAP";
			AddAttr("SS_BITMAP");
      	for (int i = 0; i < 4; i++)
				TwoChToByte(fin, ch);
      }
      else
         if (!strcmpi("TIcon", sz_type))
         { 	strFileName += ".ico";
            AddAttr("SS_ICON");
            strClass = "ICON";
         }
         else
            if (!strcmpi("TMetafile", sz_type))
            {  strFileName += ".emf";
               strClass = "ENHMETAFILE";
               AddAttr("SS_ENHMETAFILE");
               for (int i = 0; i < 4; i++)
                  TwoChToByte(fin, ch);
            }
            else
               if (!strcmpi("TGIFImage", sz_type))
               {  strFileName += ".gif";
                  for (int i = 0; i < 4; i++)
                     TwoChToByte(fin, ch);
               }
               else
               {  strFileName += ".xxx";
                  for (int i = 0; i < 4; i++)
                     TwoChToByte(fin, ch);
               }


      FILE *fout = NULL;
      if (strFileName.size())
      	fout = fopen(strFileName.c_str(), "wb");

      if (fout)
      {  while (ch != '}')
         { 	fprintf(fout, "%c", TwoChToByte(fin, ch));
            while ((ch == ' ') || (ch == '\n'))
               ch = fgetc(fin);
         }
	      fclose(fout);
      }
      else
      	NextChar(fin, '}');

      NextChar(fin, '\n');
      return true;
   }

   return false;
}


bool pImage::WriteRcRh(StrList& sl_rc, StrList& sl_rh)
{  if (!strClass.size()) return false;		//	that is, just extract the resource if possible

	sl_It i = find(sl_rc.begin(), sl_rc.end(), BEFORE_DIALOG_RC);
   if (i != sl_rc.end())
   	sl_rc.insert(i, strId + " " + strClass + " " + strFileName);

   string str_rc = " CONTROL " + strId + ", -1, \"" + strCtlFamily + "\", WS_CHILD";

   for (sl_It i = sl_attr.begin(); i != sl_attr.end(); i++)
     str_rc += " | " + (*i);

   sl_rc.push_back(str_rc + ", " + top_left.x + ", " + top_left.y + ", " + width + ", " + height);

   sl_rh.push_back("#define " + strId + " " + id);

   return true;
}


/////////////////pListBox
/////////////////pListBox
pListBox::pListBox(char *_sz_name) : pVisualControl("ListBox", _sz_name, "listbox")
{  LookForBool("MultiSelect", &bMultiSelect, false);
   LookForBool("Sorted", &bSorted, false);

   LookForInt("ItemHeight", &nItemHeight, 8);

   LookForAttr("BorderStyle", &strBorderStyle, "bsSingle");
}


bool pListBox::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Items.Strings"))
   { 	ParseItems(fin, items);
      return true;
   }
   return false;
}



bool pListBox::SetMoreAttr()
{	if (bSorted) AddAttr("CBS_SORT");
	if (bMultiSelect) AddAttr("LBS_MULTIPLESEL");

	return true;
}


sl_It pListBox::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  for (sl_It i = items.begin(); i != items.end(); i++)
		pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)\"" + (*i) + "\");");

	return pos;                
}

/////////////////pComboBox
/////////////////pComboBox
pComboBox::pComboBox(char *_sz_name) : pVisualControl("ComboBox", _sz_name, "combobox")
{  LookForInt("DropDownCount", &nDropDownCount, 8);
   LookForInt("ItemHeight", &nItemHeight, 16);

   LookForBool("Sorted", &bSorted, false);

   LookForAttr("Style", &strStyle, "csDropDown");
}


bool pComboBox::SetMoreAttr()
{	if (bSorted) AddAttr("CBS_SORT");
	return true;
}


bool pComboBox::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Items.Strings"))
   { 	ParseItems(fin, items);
      return true;
   }
   return false;
}


bool pComboBox::OnVisualParseEnd()
{  height += nDropDownCount * nItemHeight;
   return true;
}


sl_It pComboBox::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  for (sl_It i = items.begin(); i != items.end(); i++)
		pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)\"" + (*i) + "\");");

	return pos;
}

/////////////////pEdit
/////////////////pEdit
pEdit::pEdit(char *_sz_name) : pVisualControl("Edit", _sz_name, "edit")
{  LookForAttr("CharCase", &strCharCase, "ecNormal");
	LookForText("Text", &strText);

   LookForBool("ReadOnly", &bReadOnly, false);
   LookForBool("HideSelection", &bHideSelection, true);
   LookForBool("OEMConvert", &bOEMConvert, true);

   bBorder = true;
}


bool pEdit::SetMoreAttr()
{	if (bReadOnly) AddAttr("ES_READONLY");
	if (bHideSelection) AddAttr("ES_NOHIDESEL");
	if (bOEMConvert) AddAttr("ES_OEMCONVERT");
	return true;
}


sl_It pEdit::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  return sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", WM_SETTEXT, 0, (LPARAM) (LPCTSTR)\"" + strText + "\");");	}

/////////////////pMemo
/////////////////pMemo
pMemo::pMemo(char *_sz_name) : pVisualControl("Memo", _sz_name, "edit")
{  LookForBool("ReadOnly", &bReadOnly, false);

	LookForAttr("ScrollBars", &strScrollBars, "sbVert");
}


bool pMemo::SetMoreAttr()
{	if (bReadOnly) AddAttr("ES_READONLY");

	return true;
}

bool pMemo::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Lines.Strings"))
   { 	ParseItems(fin, sl_Lines);
      return true;
   }
   return false;
}

sl_It pMemo::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{
	string strLen = "n" + strName + "Len";
   pos = sl_cpp.Insert(++pos, "\t\t\tint " + strLen + ";");

	for (sl_It i = sl_Lines.begin(); i != sl_Lines.end(); i++)
   {
	   pos = sl_cpp.Insert(++pos, "\t\t\t" + strLen + " = GetWindowTextLength(" + strCtlHWND + ");");

	   pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", EM_SETSEL, (WPARAM)" + strLen + ", (LPARAM)" + strLen + ");");
      if (i == sl_Lines.begin())
		   pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", EM_REPLACESEL, 0, (LPARAM) ((LPSTR) \"" + (*i) + "\"));");
      else
		   pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", EM_REPLACESEL, 0, (LPARAM) ((LPSTR) \"\\r\\n" + (*i) + "\"));");
   }

   return pos;
}


/////////////////pGroupBox
/////////////////pGroupBox
pGroupBox::pGroupBox(char *_sz_name) : pVisualControl("GroupBox", _sz_name, "button")
{}


/////////////////pRichEdit
/////////////////pRichEdit

bool pRichEdit::bDllLoad = false;

pRichEdit::pRichEdit(char *_sz_name) : pVisualControl("RichEdit", _sz_name, "RichEdit")
{	bDllLoad = true;

   LookForAttr("BorderStyle", &strBorderStyle, "bsSingle");
}


pRichEdit::~pRichEdit()
{	   }


bool pRichEdit::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Lines.Strings"))
   { 	ParseItems(fin, sl_Lines);
      return true;
   }
   return false;
}



sl_It pRichEdit::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{
	string strLen = "n" + strName + "Len";
   pos = sl_cpp.Insert(++pos, "\t\t\tint " + strLen + ";");

	for (sl_It i = sl_Lines.begin(); i != sl_Lines.end(); i++)
   {
	   pos = sl_cpp.Insert(++pos, "\t\t\t" + strLen + " = GetWindowTextLength(" + strCtlHWND + ");");

      if (i == sl_Lines.begin())
      {
	   	pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND +
         	", EM_SETSEL, (WPARAM) 0, (LPARAM)" + strLen + ");");
		   pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND +
         	", EM_REPLACESEL, 0, (LPARAM) ((LPSTR) \"""\"));");
      }

	   pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND +
      	", EM_SETSEL, (WPARAM)" + strLen + ", (LPARAM)" + strLen + ");");

      if (i == sl_Lines.begin())
		   pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", EM_REPLACESEL, 0, (LPARAM) ((LPSTR) \"" + (*i) + "\"));");
      else
		   pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", EM_REPLACESEL, 0, (LPARAM) ((LPSTR) \"\\r\\n" + (*i) + "\"));");
   }

   return pos;
}
/////////////////pScrollBar
/////////////////pScrollBar
pScrollBar::pScrollBar(char *_sz_name) : pVisualControl("ScrollBar", _sz_name, "scrollbar")
{  LookForInt("PageSize", &nPageSize, 0);		}


bool pScrollBar::SetMoreAttr()
{	AddAttr((width > height) ? "SBS_HORZ" : "SBS_VERT");
	return true;
}



