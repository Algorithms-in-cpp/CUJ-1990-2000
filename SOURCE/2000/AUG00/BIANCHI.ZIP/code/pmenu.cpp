//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#include "pmenu.h"
//---------------------------------------------------------------------------

bool pMenuBase::OnParseEnd() 
{	string ret_string;
	for (int i = 0; i < strMenuText.size(); i++)
   	if (strMenuText[i] != '"')
      	ret_string += strMenuText[i];
      else
      	ret_string += "\\\"";

   strMenuText = ret_string;
}


pMenuBase::pMenuBase(char * sz_type, char *sz_name) : pResComponent(sz_type, sz_name, "")
{	LookForText("Caption", &strMenuText);
	bCommand = false;
}


////////pMenuItem
pMenuItem::pMenuItem(char *sz_name) : pMenuBase("MENUITEM", sz_name)
{	indent = 0;	}


void pMenuItem::SetIndent(int _indent)
{	indent = _indent;	}


bool pMenuItem::WriteRcRh(StrList& sl_rc, StrList& sl_rh)
{	if (strMenuText[0] == '-')
   {	sl_rc.push_back("MENUITEM SEPARATOR");
      for (int i = 0; i > indent; i--)
         sl_rc.push_back("}");
   }
   else
   {
   	if (indent > 0)
	   	sl_rc.push_back("POPUP \"" + strMenuText + "\"\n{");
      else
      { 	sl_rc.push_back("MENUITEM \"" + strMenuText + "\", " + strId);
         sl_rh.push_back("#define " + strId + " " + id);
         bCommand = true;

         for (int i = 0; i > indent; i--)
            sl_rc.push_back("}");
      }
   }
   return true;
}


bool pMenuItem::WriteCppHpp(StrList& sl_cpp, StrList& sl_hpp)
{  if (bCommand)
		HandleWmCommand(sl_cpp, "//write menu response code here");
	return true;
}


////////pMenu
pMenu::pMenu(char *sz_type, char *sz_name) : pMenuBase(sz_type, sz_name)
{}


bool pMenu::WriteRcRh(StrList& sl_rc, StrList& sl_rh)
{	sl_rc.push_back("\n\n" + strId + " MENUEX\n{");
   sl_rh.push_back("\n\n#define " + strId + " " + id);
   return true;
}
