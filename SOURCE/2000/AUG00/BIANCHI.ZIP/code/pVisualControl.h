//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."


#ifndef PVISUALCONTROL_H
#define PVISUALCONTROL_H

#include "pvisual.h"
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------

class pVisualControl	: public pVisualObject
{
  	public:
      pVisualControl(const char *_sz_type, const char *_sz_name, const char *sz_family, const char *_sz_include = "");
      virtual bool WriteRcRh(StrList& sl_rc, StrList& sl_rh);
		virtual bool WriteCppHpp(StrList& sl_cpp, StrList& sl_hpp);
      int GetTabIndex();

   protected :
		virtual sl_It WriteDecl(StrList& sl_cpp, StrList& sl_hpp);
		virtual sl_It WriteDeclMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
		virtual sl_It WriteInit(StrList& sl_cpp, StrList& sl_hpp);
		virtual sl_It WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
		virtual sl_It WriteCppHppMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);
		virtual sl_It HandleWmPaint(StrList& sl, const string& value);

		bool SetMoreAttr();

      bool bBorder;
      bool bEnabled;
      bool bTabstop;

      int tab_index;

		string strCtlFamily;
		string strCtlHWND;
};

#endif