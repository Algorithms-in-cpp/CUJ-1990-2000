//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#ifndef _pcommdlgs_h
#define _pcommdlgs_h



#include "PCOMMDIALOGS.H"



class pColorDlg : public pCommDialogs
{	public:
		pColorDlg(char *_sz_name, char *_sz_include = "");
};


class pOpenSaveFileDlg : public pCommDialogs
{ 		string strDefaultExt;
      string strTitle;
      string strFilter;
      string strInitialDir;
      string strFileName;

      int nFilterIndex;

	public:
		pOpenSaveFileDlg(char *_sz_type, char *_sz_name, char *_sz_include = "");
};


class pOpenFileDlg : public pOpenSaveFileDlg
{
	public:
		pOpenFileDlg(char *_sz_name, char *_sz_include = "");
};


class pSaveFileDlg : public pOpenSaveFileDlg
{
	public:
		pSaveFileDlg(char *_sz_name, char *_sz_include = "");
};


class pFontDlg : public pCommDialogs
{	public:
		pFontDlg(char *_sz_name, char *_sz_include = "");

	protected :
		bool ParseCommDlg(FILE *fin, char *sss);


	private :
		int nMaxFontSize;
		int nMinFontSize;

		StrList slFontStyle;

		string strFontCharSet;
		string strFontColor;
		string strFontHeight;
		string strFontName;
		string strDevice;
};



class pFindDlg : public pCommDialogs
{     string strFindText;
	public:
		pFindDlg(char *_sz_name, char *_sz_include = "");
};



class pReplaceDlg : public pCommDialogs
{     string strFindText;
		string strReplaceText;
	public:
		pReplaceDlg(char *_sz_name, char *_sz_include = "");
};



#endif