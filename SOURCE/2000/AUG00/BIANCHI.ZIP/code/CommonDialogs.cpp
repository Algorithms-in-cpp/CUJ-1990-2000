//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include "CommonDialogs.h"

//pColorDlg
//pColorDlg
pColorDlg::pColorDlg(char *_sz_name, char *_sz_include) : pCommDialogs("ColorDlg", _sz_name, "CHOOSECOLOR", _sz_include)
{

}

//pOpenSaveFileDlg
//pOpenSaveFileDlg
pOpenSaveFileDlg::pOpenSaveFileDlg(char *_sz_type, char *_sz_name, char *_sz_include) : pCommDialogs(_sz_type, _sz_name, "OPENFILENAME", _sz_include)
{
	LookForText("Title", &strTitle);
   LookForText("DefaultExt", &strDefaultExt);
   LookForText("Filter", &strFilter);
   LookForText("InitialDir", &strInitialDir);
   LookForText("FileName", &strFileName);

   LookForInt("FilterIndex", &nFilterIndex);
}



//pOpenFileDlg
//pOpenFileDlg
pOpenFileDlg::pOpenFileDlg(char *_sz_name, char *_sz_include) : pOpenSaveFileDlg("OpenFileDlg", _sz_name, _sz_include)
{

}


//pSaveFileDlg
//pSaveFileDlg
pSaveFileDlg::pSaveFileDlg(char *_sz_name, char *_sz_include) : pOpenSaveFileDlg("SaveFileDlg", _sz_name, _sz_include)
{

}



//pFontDlg
//pFontDlg
pFontDlg::pFontDlg(char *_sz_name, char *_sz_include) : pCommDialogs("FontDlg", _sz_name, "CHOOSEFONT", _sz_include)
{
	LookForInt("MaxFontSize", &nMaxFontSize);
	LookForInt("MinFontSize", &nMinFontSize);
	LookForInfo("Device", &strDevice);
	LookForInfo("Font.Charset", &strFontCharSet);
	LookForInfo("Font.Color", &strFontColor);
	LookForInfo("Font.Height", &strFontHeight);
	LookForText("Font.Name", &strFontName);
}


bool pFontDlg::ParseCommDlg(FILE *fin, char *sss)
{
	if (!strcmpi(sss, "Font.Style"))
   { 	ParseCollection(fin, slFontStyle);
      return true;
   }
   return false;

}


//pFindDlg
//pFindDlg

pFindDlg::pFindDlg(char *_sz_name, char *_sz_include) : pCommDialogs("FindDlg", _sz_name, "FINDREPLACE", _sz_include)
{
	LookForText("FindText", &strFindText);
}

//pReplaceDlg
//pReplaceDlg

pReplaceDlg::pReplaceDlg(char *_sz_name, char *_sz_include) : pCommDialogs("ReplaceDlg", _sz_name, "FINDREPLACE", _sz_include)
{
	LookForText("FindText", &strFindText);
	LookForText("ReplaceText", &strReplaceText);
}
