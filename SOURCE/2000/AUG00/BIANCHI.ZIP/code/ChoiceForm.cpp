//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
                                                                   
#include "ChoiceForm.h"
#include "process.h"
#include "enumres.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)	: TForm(Owner)
{	}
//---------------------------------------------------------------------------

void __fastcall TForm2::ExitClick(TObject *Sender)
{  Close();	}

//---------------------------------------------------------------------------
void __fastcall TForm2::ProcessClick(TObject *Sender)
{  if (OpenDfmDialog->Execute() == mrOk)
   	DfmConvert(OpenDfmDialog->FileName.c_str(), udDialogID->Position, udCtlIdBase->Position, udRatioX->Position, udRatioY->Position);
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ExtractClick(TObject *Sender)
{  if (OpenExeDialog->Execute() == mrOk)
      ExtractResInfo(OpenExeDialog->FileName.c_str());
}
//---------------------------------------------------------------------------





