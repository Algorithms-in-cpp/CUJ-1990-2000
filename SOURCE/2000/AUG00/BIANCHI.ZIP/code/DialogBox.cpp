//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include "DialogBox.h"

#include <dir.h>

bool pDialogBox::ResizeMore(float fx, float fy) 
{
	nClientWidth *= fx;
   nClientHeight *= fy;
   return true;
}

bool pDialogBox::SetMoreAttr() 
{
   if (bCtl3D) AddAttr("DS_3DLOOK");
   if (b_fixedsys) AddAttr("DS_FIXEDSYS");

   char sz_attr[255], sz_attr_ex[255];
   for (sl_It i = BorderIcons.begin(); i != BorderIcons.end(); i++)
   { 	GetPrivateProfileString(strType.c_str(), (*i).c_str(), "", sz_attr, sizeof(sz_attr), strAttrFile.c_str());
    	GetPrivateProfileString(strType.c_str(), (*i).c_str(), "", sz_attr_ex, sizeof(sz_attr_ex), strAttrExFile.c_str());
   	AddAttr(sz_attr);
   	AddAttrEx(sz_attr_ex);
   }

   return true;
}

pDialogBox::pDialogBox(const char *_sz_name, const char *_sz_include) : pVisualObject("DialogBox", _sz_name, _sz_include)
{  width = 0;
   height = 0;

   b_fixedsys = true;

   LookForInt("ClientWidth", &nClientWidth, 0);
   LookForInt("ClientHeight", &nClientHeight, 0);
   LookForInt("PixelsPerInch", &nPixelsPerInch, 96);

   LookForBool("Ctl3D", &bCtl3D, true);

   LookForAttr("Menu", &strMenuName, "");
   LookForAttr("Position", &strPosition, "poCenter");
   LookForAttr("BorderStyle", &strBorderStyle, "bsDialog");
   LookForAttr("FormStyle", &strFormStyle, "fsNormal");
   LookForAttr("WindowState", &strWindowState, "wsNormal");
}


bool pDialogBox::WriteRcRh(StrList& sl_rc, StrList& sl_rh)
{  sl_rc.push_back(BEFORE_DIALOG_RC);
   sl_rc.push_back("//\n//\n");
   sl_rc.push_back("//BEGIN");

   if (width == 0) width = nClientWidth;
   if (height == 0) height = nClientHeight;

   sl_rc.push_back(strId + " DIALOGEX " + top_left.x + " " + top_left.y + " " + width + " " + height);

   string str;
   if (sl_attr_ex.size())
   {  str = "EXSTYLE 0x00";
	   for (sl_It i = sl_attr_ex.begin(); i != sl_attr_ex.end(); i++)
   		str += " | " + (*i);
	   sl_rc.push_back(str);
   }

   if (strMenuName.size())
   {  for (int i = 0; i < strMenuName.size(); i++)
   		strMenuName[i] = toupper(strMenuName[i]);
   	sl_rc.push_back("MENU IDC_" + strMenuName);
   }


   str = "STYLE 0x00";
   for (sl_It i = sl_attr.begin(); i != sl_attr.end(); i++)
   	str += " | " + (*i);

   sl_rc.push_back(str);
   sl_rc.push_back("CAPTION \"" + strCaption + "\"");

////////////aggiungere i fonts   
   char sz_font[255];
   wsprintf(sz_font, "FONT %d, \"%s\", %d, %d\n{", -MulDiv(72, nFntHeight, nPixelsPerInch), strFntName.c_str(), bFntBold ? FW_BOLD : FW_NORMAL, bFntItalic);
   sl_rc.push_back(sz_font);

   sl_rh.push_back("#define " + strId + " " + id);

	return true;
}

bool pDialogBox::ParseVisual(FILE *fin, char *sss)
{	if (!strcmpi(sss, "BorderIcons"))
   { 	ParseCollection(fin, BorderIcons);
      return true;
   }

   if (!strcmpi(sss, "Icon.Data"))
   {  NextChar(fin, '\n');

      char ch = fgetc(fin);
      while(ch == ' ') ch = fgetc(fin);

		strIconFileName = strName + "Icon.ico";

      FILE *fout = fopen(strIconFileName.c_str(), "wb");

      if (fout)
      {  while (ch != '}')
         { 	fprintf(fout, "%c", TwoChToByte(fin, ch));
            while ((ch == ' ') || (ch == '\n'))
               ch = fgetc(fin);
         }
	      fclose(fout);
      }
      else NextChar(fin, '}');

      NextChar(fin, '\n');
      return true;
   }

   return false;
}





bool pDialogBox::WriteCppHpp(StrList& sl_cpp, StrList& sl_hpp)
{
	string str = "BOOL CALLBACK " + strName + "DialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)";

   sl_cpp.Append(BEFORE_DIALOG_PROC);
   sl_cpp.Append(INSIDE_DIALOG_PROC);
   sl_cpp.Append("\tswitch (uMsg)\n\t{");
   sl_cpp.Append(INSIDE_SWITCH_MESSAGE);

//inserire i vari messaggi
   sl_cpp.Append("\t}; // switch (uMsg)");
   sl_cpp.Append(OUT_OF_SWITCH_MESSAGE);
   sl_cpp.Append("\treturn FALSE;");
   sl_cpp.Append("}; // DIALOG_PROC");
   sl_cpp.Append(OUT_OF_DIALOG_PROC);

   sl_cpp.Insert_A_Before_B("\n\n" + str + "\n{", INSIDE_DIALOG_PROC);
   sl_hpp.Insert_A_After_B("\n" + str + ";", INSIDE_HPP);

   HandleMessage(sl_cpp, "WM_CLOSE", "EndDialog(hWnd, IDCANCEL);");

   return true;
}
