//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include "PVisualControl.h"


bool pVisualControl::SetMoreAttr()
{	if ((bTabstop) && (tab_index >= 0)) AddAttr("WS_TABSTOP");
   if (bBorder) AddAttr("WS_BORDER");
   return true;
}


sl_It pVisualControl::WriteDecl(StrList& sl_cpp, StrList& sl_hpp)
{  sl_It ret = sl_cpp.Insert_A_After_B("\tstatic HWND " + strCtlHWND + ";", INSIDE_DIALOG_PROC);
   return WriteDeclMore(sl_cpp, sl_hpp, ret);
}


sl_It pVisualControl::WriteDeclMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  return pos;  }


sl_It pVisualControl::WriteInit(StrList& sl_cpp, StrList& sl_hpp)
{  string str = "\n\t\t\t" + strCtlHWND + " = GetDlgItem(hWnd, " + strId + ");";
   sl_It pos = HandleMessage(sl_cpp, "WM_INITDIALOG", str);
   return WriteInitMore(sl_cpp, sl_hpp, pos);
}


sl_It pVisualControl::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  return pos;  }


sl_It pVisualControl::WriteCppHppMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  return pos; }


bool pVisualControl::WriteCppHpp(StrList& sl_cpp, StrList& sl_hpp)
{
	if (id <= 0) return false;

	strCtlHWND = "hCtl" + strName;

   WriteDecl(sl_cpp, sl_hpp);
   sl_It pos = WriteInit(sl_cpp, sl_hpp);
   WriteCppHppMore(sl_cpp, sl_hpp, pos);

	return true;
}



sl_It pVisualControl::HandleWmPaint(StrList& sl, const string& value)
{
   if (id <= 0) return sl.end();

   sl_It i = find(sl.begin(), sl.end(), INSIDE_WM_PAINT);

   if (i == sl.end())
   {
   	i = sl.Insert_A_After_B("\n\t\tcase WM_PAINT:\n\t\t{", INSIDE_SWITCH_MESSAGE);

      i = sl.Insert(++i, "\t\t\tPAINTSTRUCT ps;");
      i = sl.Insert(++i, "\t\t\tBeginPaint(hWnd, &ps );");
      i = sl.Insert(++i, INSIDE_WM_PAINT);
      i = sl.Insert(++i, "\t\t\tEndPaint(hWnd, &ps);\n\t\t}");
      i = sl.Insert(++i, "\t\tbreak;");
      HandleWmPaint(sl, value);
   }
   else
   	i = sl.Insert_A_After_B("\t\t\t" + value + " // " + strName, INSIDE_WM_PAINT);

   return i;
}



pVisualControl::pVisualControl(const char *_sz_type, const char *_sz_name, const char *_sz_family, const char *_sz_include):pVisualObject(_sz_type, _sz_name, _sz_include)
{	strCtlFamily = _sz_family;

   LookForInt("TabOrder", &tab_index, -1);

   LookForBool("TabStop", &bTabstop, true);
   LookForBool("Border", &bBorder, false);
   LookForBool("Enabled", &bEnabled, true);
}



int pVisualControl::GetTabIndex()
{	return tab_index;	}



bool pVisualControl::WriteRcRh(StrList& sl_rc, StrList& sl_rh)
{  string str_rc = " CONTROL \"" + GetClassString() + "\", " +
         strId + ", \"" + strCtlFamily +"\", WS_CHILD";

   for (sl_It i = sl_attr.begin(); i != sl_attr.end(); i++)
   	str_rc += " | " + (*i);

   string comma = ", ";

   str_rc += comma + top_left.x + comma + top_left.y + comma + width + comma + height + ", 0x00";

   for (sl_It i = sl_attr_ex.begin(); i != sl_attr_ex.end(); i++)
 		str_rc += " | " + (*i);

	sl_rc.push_back(str_rc);

   sl_rh.push_back("#define " + strId + " " + id);

   return true;
}
