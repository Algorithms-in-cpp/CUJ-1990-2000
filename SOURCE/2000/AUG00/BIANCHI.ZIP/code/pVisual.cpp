//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
// -----------------
//  ----------------

#include "pVisual.h"
#include <dir.h>

string pVisualObject::strAttrExFile;
string pVisualObject::strAttrFile;

/**# implementation pVisualObject:: id(C_0954405138) */

bool pVisualObject::ApplyStyles()
{  const int buf_size = 256;
	char szStyle[buf_size];

	if (GetPrivateProfileString(strType.c_str(), "Style", "", szStyle, buf_size, strAttrFile.c_str()))
		AddAttr(szStyle);

   if (GetPrivateProfileString(strType.c_str(), "StyleEx", "", szStyle, buf_size, strAttrExFile.c_str()))
		AddAttrEx(szStyle);

   for (sm_iter i = sm_attr.begin(); i != sm_attr.end(); i++)
   { 	if (GetPrivateProfileString(strType.c_str(), (*i).second->c_str(), "", szStyle, buf_size, strAttrFile.c_str()))
   	   AddAttr(szStyle);

    	if (GetPrivateProfileString(strType.c_str(), (*i).second->c_str(), "", szStyle, buf_size, strAttrExFile.c_str()))
   	   AddAttrEx(szStyle);
   }

   return true;
}

void pVisualObject::LookForAttr(const char *what, string* dest, string def_val)
{	*dest = def_val;
	sm_attr.insert(make_pair(what, dest));
}

void pVisualObject::AddAttrEx(const char *sz_attr_ex)
{	if (strlen(sz_attr_ex)) sl_attr_ex.push_back(sz_attr_ex);		}

void pVisualObject::AddAttr(const char *sz_attr)
{	if (strlen(sz_attr)) sl_attr.push_back(sz_attr);		}

bool pVisualObject::OnParseEnd()
{	for (sl_It i = slFntStyle.begin(); i != slFntStyle.end(); i++)
   {	if ((*i) == "fsBold") bFntBold = true;
   	if ((*i) == "fsItalic") bFntItalic = true;
   }

   ApplyStyles();
   SetAttr();

	return OnVisualParseEnd();
}


bool pVisualObject::ParseMore(FILE *fin, char *sss)
{
	sm_iter si = sm_attr.find(sss);
   if (si != sm_attr.end())
   {  char str[256];
      fscanf(fin, "%*s %s", str);
      *si->second = str;
      return true;
   }

	if (!strcmpi(sss, "Font.Style"))
   { 	ParseCollection(fin, slFntStyle);
      return true;
   }

   return ParseVisual(fin, sss);
}


bool pVisualObject::OnVisualParseEnd()
{	return false;	}


bool pVisualObject::ParseVisual(FILE *fin, char *sss)
{	return false;	}


bool pVisualObject::SetAttr()
{	AddAttr(bVisible ? "WS_VISIBLE" : "NOT WS_VISIBLE");
   return SetMoreAttr();
}


bool pVisualObject::SetMoreAttr()
{  return false;	}


string pVisualObject::GetClassString()
{  string ret_string;
	for (int i = 0; i < strCaption.size(); i++)
   	if (strCaption[i] != '"')
      	ret_string += strCaption[i];
      else
      	ret_string += "\\\"";
	return ret_string;
}


pVisualObject::pVisualObject(const char *_sz_type, const char *_sz_name, const char *_sz_include):pResComponent(_sz_type, _sz_name, _sz_include)
{
	LookForInt("Top", &top_left.y, 0);
   LookForInt("Left", &top_left.x, 0);
   LookForInt("Width", &width, 100);
   LookForInt("Height", &height, 100);

   LookForBool("Visible", &bVisible, true);

   LookForText("Caption", &strCaption);

//////font section
	bFntItalic = false;
	bFntBold = false;

   LookForInt("Font.Height", &nFntHeight, -11);

   LookForText("Font.Name", &strFntName, "MS Sans Serif");
   LookForInfo("Font.Charset", &strFntCharset, "DEFAULT_CHARSET");
   LookForInfo("Font.Color", &strFntColor, "clWindowText");

////////
   if (!strAttrFile.size())
   {
		char szPath[MAXPATH], drive[MAXDRIVE], dir[MAXDIR], file[MAXFILE], ext[MAXEXT];

   	GetModuleFileName(0, szPath, sizeof(szPath));
   	fnsplit(szPath, drive, dir, file, ext);

      strAttrFile = drive + string(dir) + "Attr.xfr";
      strAttrExFile = drive + string(dir) + "AttrEx.xfr";
   }
}


pVisualObject::~pVisualObject()
{}


pPoint pVisualObject::GetTopLeft()
{	return top_left;	}


void pVisualObject::OffsetBy(pPoint& pnt)
{	top_left.x += pnt.x;
	top_left.y += pnt.y;
}


bool pVisualObject::ResizeMore(float fx, float fy)
{  return false;	}


bool pVisualObject::Resize(float fx, float fy)
{	top_left.x *= fx;
   top_left.y *= fy;

	width *= fx;
   height *= fy;

   return ResizeMore(fx, fy);
}