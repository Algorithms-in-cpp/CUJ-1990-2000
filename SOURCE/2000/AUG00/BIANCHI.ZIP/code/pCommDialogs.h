//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include "pVCLComponent.h"

#ifndef PCOMMDIALOGS_H
#define PCOMMDIALOGS_H


#include <commdlg.h>
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
	
class pCommDialogs : public pVCLComponent
{
      bool ParseMore(FILE *fin, char *sss);
	protected:
		bool OnParseEnd();

      virtual bool ParseCommDlg(FILE *fin, char *sss);
      virtual bool OnParseCommDlgEnd();
		virtual bool WriteCommDlgCppHpp(StrList& sl_cpp, StrList& sl_hpp, sl_It pos);

   	StrList slOptions;
      StrList slFlags;

      string strStructName;
      string strFlags;

	public:
		pCommDialogs(char *_sz_name, char *_sz_type, char * _sz_struct, char *_sz_include);
      virtual ~pCommDialogs();
		bool WriteCppHpp(StrList& sl_cpp, StrList& sl_hpp);

      static string strFileOptions;
};

#endif
