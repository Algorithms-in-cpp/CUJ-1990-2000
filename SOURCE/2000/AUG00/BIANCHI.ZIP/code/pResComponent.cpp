//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
// -----------------
#include "pResComponent.h"

/**# implementation pResComponent:: id(C_0954409846) */

int pResComponent::global_id = 100;


sl_It pResComponent::HandleWmCommand(StrList& sl, const string& value)
{
   if (id <= 0) return sl.end();

   sl_It i = find(sl.begin(), sl.end(), INSIDE_WM_COMMAND);

   if (i == sl.end())
   {
   	i = sl.Insert_A_After_B("\n\t\tcase WM_COMMAND:\n\t\t{", INSIDE_SWITCH_MESSAGE);
      i = sl.Insert(++i, "\t\t\tWORD dwCtlId = LOWORD(wParam);");
      i = sl.Insert(++i, "\t\t\tWORD dwHi = HIWORD(wParam);");
      i = sl.Insert(++i, "\t\t\tswitch (dwCtlId)\n\t\t\t{");
   	i = sl.Insert(++i, INSIDE_WM_COMMAND);
      i = sl.Insert(++i, "\t\t\t\}\n\t\t\tbreak;");
   	i = sl.Insert(++i, "\t\t}\n\t\t; // + WM_COMMAND");
      HandleWmCommand(sl, value);
   }
   else
   {
		string str = INSIDE_WM_COMMAND + string("_") + strId;
   	sl_It i = find(sl.begin(), sl.end(), str);

      if (i == sl.end())
      {
         i = sl.Insert_A_After_B("\t\t\t\tcase " + strId + ":", INSIDE_WM_COMMAND);
         i = sl.Insert(++i, str);
         i = sl.Insert(++i, "\t\t\t\tbreak; //" + str);
         i = sl.Insert(++i, "\n");
         HandleWmCommand(sl, value);
      }
      else
	   	i = sl.insert(++i, "\t\t\t\t\t" + value + " // " + strName);
   }
   return i;
}


pResComponent::pResComponent(const char *_sz_type, const char *_sz_name, const char *_sz_include):pVCLComponent(_sz_type, _sz_name, _sz_include)
{  id = global_id++;

   if (strName.size())
	   strId = "IDC_" + strName;
   else
   {	id = -1;
   	strId = "-1";
   }

   for (unsigned int i = 0; i < strId.size(); i++)
   	strId[i] = (char)toupper(strId[i]);
}


pResComponent::~pResComponent()
{}


const char* pResComponent::GetId()
{	return strId.c_str();	}


bool pResComponent::WriteRcRh(StrList& sl_rc, StrList& sl_rh)
{   return false;	}
