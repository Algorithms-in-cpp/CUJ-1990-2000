//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include "CommonControls.h"

//---------------------------------------------------------------------------

StringSet pCommCtrl::ss_dwICC;


pCommCtrl::pCommCtrl(char *_sz_type, char *_sz_name, char *_sz_family, char *_sz_dwICC) : pVisualControl(_sz_type, _sz_name, _sz_family, "<commctrl.h>")
{	if (strlen(_sz_dwICC))
		ss_dwICC.insert(ss_dwICC.begin(), _sz_dwICC);
}




/////////////////pTreeWindow
/////////////////pTreeWindow
pTreeView::pTreeView(char *_sz_name) : pCommCtrl("TreeView", _sz_name, "SysTreeView32", "ICC_TREEVIEW_CLASSES")
{  LookForInt("Indent", &nIndent, 20);

   LookForAttr("BorderStyle", &strBorderStyle, "bsSingle");
}


/////////////////pListWindow
/////////////////pListWindow
pListView::pListView(char *_sz_name) : pCommCtrl("ListView", _sz_name, "SysListView32", "ICC_LISTVIEW_CLASSES")
{  LookForBool("Checkboxes", &bCheckboxes, false);
   LookForBool("GridLines", &bGridLines, false);
   LookForBool("MultiSelect", &bMultiSelect, false);
   LookForBool("RowSelect", &bRowSelect, false);

   LookForAttr("ViewStyle", &strViewStyle, "vsReport");
   LookForAttr("BorderStyle", &strBorderStyle, "bsSingle");
}


bool pListView::SetMoreAttr()
{	if (!bMultiSelect) AddAttr("LVS_SINGLESEL");
	return true;
}


bool pListView::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Columns"))
   {  NextChar(fin, '<');

      fscanf(fin, "%s", sss);

      string str_title;

      while (strcmpi(sss, "end>"))
      {  if (!strcmpi(sss, "Caption"))
         {  NextChar(fin, '\'');
         	str_title = "";
         	char ch = fgetc(fin);
            while (ch != '\'')
            {
            	str_title += ch;
               ch = fgetc(fin);
            }
            slCols.push_back(str_title);
         }
       	fscanf(fin, "%s", sss);
      }
	   return true;
   }
   return false;
}




sl_It pListView::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{	if (bCheckboxes)
   	pos = sl_cpp.Insert(++pos,
	   	"\t\t\tListView_SetExtendedListViewStyleEx(" + strCtlHWND + ", LVS_EX_CHECKBOXES, LVS_EX_CHECKBOXES);");

	if (bGridLines)
   	pos = sl_cpp.Insert(++pos, "\t\t\tListView_SetExtendedListViewStyleEx(" +
      	strCtlHWND + ", LVS_EX_GRIDLINES, LVS_EX_GRIDLINES);");

	if (bRowSelect)
   	pos = sl_cpp.Insert(++pos,	"\t\t\tListView_SetExtendedListViewStyleEx(" +
      	strCtlHWND + ", LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);");

   if (slCols.size())
   {  string strColumn = strCtlHWND + "Column";
   	pos = sl_cpp.Insert(++pos, "\n\t\t\tLVCOLUMN " + strColumn + ";");
   	pos = sl_cpp.Insert(++pos, "\t\t\tZeroMemory(&" + strColumn + ", sizeof(LVCOLUMN));");
   	pos = sl_cpp.Insert(++pos, "\t\t\t" + strColumn + ".mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT;");
      pos = sl_cpp.Insert(++pos, "\t\t\t" + strColumn + ".fmt = LVCFMT_LEFT;");
      pos = sl_cpp.Insert(++pos, "\t\t\t" + strColumn + ".cx = 100;");
      int iCount = 0;

      for (sl_It i = slCols.begin(); i != slCols.end(); i++, iCount++)
		{
	      pos = sl_cpp.Insert(++pos, "\t\t\t" + strColumn + ".pszText = \"" + (*i) + "\";");
         pos = sl_cpp.Insert(++pos, "\t\t\tListView_InsertColumn(" + strCtlHWND +
         	", " + iCount + ", &" + strColumn + ");");
      }
   }

   return pos;
}



/////////////////pHeaderControl
/////////////////pHeaderControl
pHeaderControl::pHeaderControl(char *_sz_name) : pCommCtrl("Header", _sz_name, "SysHeader32", "ICC_LISTVIEW_CLASSES")
{  LookForAttr("Style", &strStyle, "hsButtons");	}


bool pHeaderControl::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Sections"))
   {  NextChar(fin, '<');

      fscanf(fin, "%s", sss);

      string str_title;

      while (strcmpi(sss, "end>"))
      {  if (!strcmpi(sss, "Text"))
         {  NextChar(fin, '\'');
         	str_title = "";
         	char ch = fgetc(fin);
            while (ch != '\'')
            {
            	str_title += ch;
               ch = fgetc(fin);
            }
            slCols.push_back(str_title);
         }
       	fscanf(fin, "%s", sss);
      }

	   return true;
   }
   return false;
}



sl_It pHeaderControl::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  if (slCols.size())
   {  string strItem = strCtlHWND + "Item";
   	pos = sl_cpp.Insert(++pos, "\n\t\t\tHDITEM " + strItem + ";");
   	pos = sl_cpp.Insert(++pos, "\t\t\tZeroMemory(&" + strItem + ", sizeof(HDITEM));");
   	pos = sl_cpp.Insert(++pos, "\t\t\t" + strItem + ".mask = HDI_FORMAT | HDI_TEXT | HDI_WIDTH;");
      pos = sl_cpp.Insert(++pos, "\t\t\t" + strItem + ".fmt = HDF_LEFT;");
      pos = sl_cpp.Insert(++pos, "\t\t\t" + strItem + ".cxy = 80;");
      int iCount = 0;

      for (sl_It i = slCols.begin(); i != slCols.end(); i++, iCount++)
		{  pos = sl_cpp.Insert(++pos, "\t\t\t" + strItem + ".pszText = \"" + (*i) + "\";");
         pos = sl_cpp.Insert(++pos, "\t\t\tHeader_InsertItem(" + strCtlHWND +
         	", " + iCount + ", &" + strItem + ");");
      }
   }

   return pos;
}




/////////////////pTrackBar
/////////////////pTrackBar
pTrackBar::pTrackBar(char *_sz_name) : pCommCtrl("TrackBar", _sz_name, "msctls_trackbar32", "ICC_BAR_CLASSES")
{	LookForInt("Min", &nMin, 0);
   LookForInt("Max", &nMax, 100);
   LookForInt("SelStart", &nSelStart, 0);
   LookForInt("SelEnd", &nSelEnd, 0);
   LookForInt("Position", &nPosition, 0);
   LookForInt("Frequency", &nFrequency, 10);

   LookForAttr("TickMarks", &strTickMarks, "tmTopLeft");
   LookForAttr("TickStyle", &strTickStyle, "tsAuto");
   LookForAttr("Orientation", &strOrientation, "trVertical");
}


sl_It pTrackBar::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{
  	pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND +
   		", TBM_SETRANGE, FALSE, MAKELPARAM(" + nMin + ", " + nMax + "));");

  	pos = sl_cpp.Insert(++pos,	"\t\t\tSendMessage(" + strCtlHWND +
   		", TBM_SETSEL, FALSE, MAKELPARAM(" + nSelStart + ", " + nSelEnd + "));");

  	pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND +
   		", TBM_SETPOS, TRUE, " + nPosition + ");");

   pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND +
   		", TBM_SETTICFREQ, " + nFrequency + ", 0);");

   return pos;
}


/////////////////pProgressBar
/////////////////pProgressBar
pProgressBar::pProgressBar(char *_sz_name) : pCommCtrl("ProgressBar", _sz_name, "msctls_progress32", "ICC_PROGRESS_CLASS")
{
	LookForInt("Min", &nMin, 0);
   LookForInt("Max", &nMax, 100);
   LookForInt("Position", &nPosition, 0);

   LookForBool("Smooth", &bSmooth, false);

   LookForAttr("Orientation", &strOrientation, "pbHorizontal");
}


sl_It pProgressBar::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{ 	pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND +
   	", PBM_SETRANGE32, "+ nMin + ", " + nMax + ");");

  	pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND +
   	", PBM_SETPOS, " + nPosition + ", 0);");

   return pos;
}


bool pProgressBar::SetMoreAttr()
{	if (bSmooth) AddAttr("0x01");     //PBS_SMOOTH explicit value, to avoid the inclusion of <commctrl.h> in .rh
 	return true;
}


/////////////////pStatusBar
/////////////////pStatusBar
pStatusBar::pStatusBar(char *_sz_name) : pCommCtrl("StatusBar", _sz_name, "msctls_statusbar32", "ICC_BAR_CLASSES")
{	LookForText("SimpleText", &strSimpleText);
	LookForBool("SimplePanel", &bSimplePanel, false);
   LookForBool("SizeGrip", &bSizeGrip, true);
}



bool pStatusBar::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Panels"))
   {  NextChar(fin, '<');

      fscanf(fin, "%s", sss);

      string str_text;

      while (strcmpi(sss, "end>"))
      {  if (!strcmpi(sss, "Text"))
         {  NextChar(fin, '\'');
         	str_text = "";
         	char ch = fgetc(fin);
            while (ch != '\'')
            {
            	str_text += ch;
               ch = fgetc(fin);
            }
            slPanels.push_back(str_text);
         }
       	fscanf(fin, "%s", sss);
      }
	   return true;
   }
   return false;
}




sl_It pStatusBar::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  int nParts = slPanels.size();

   pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", SB_SIMPLE, " + bSimplePanel + ", 0);");

   if (slPanels.size())
   {
   	string strParts = "n" + strName + "Parts";
   	pos = sl_cpp.Insert(++pos, "\t\t\tint " + strParts + "[" + nParts + "];");

      int iCount = 0;
      for (sl_It i = slPanels.begin(); i != slPanels.end(); i++, iCount++)
	      pos = sl_cpp.Insert(++pos, "\t\t\t" + strParts + "[" + iCount + "] = " + ((iCount + 1) * 100) + ";");

      pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", SB_SETPARTS, " + nParts + ", (LPARAM)" + strParts + ");");

      iCount = 0;
      for (sl_It i = slPanels.begin(); i != slPanels.end(); i++, iCount++)
	      pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", SB_SETTEXT, " + iCount + ", (LPARAM) (LPCSTR) \"" + (*i) + "\");");
   }
   if (bSimplePanel)
      pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND + ", SB_SETTEXT, 255, (LPARAM) (LPCSTR) \"" + strSimpleText + "\");");

   return pos;
}



/////////////////pAnimate
/////////////////pAnimate
pAnimate::pAnimate(char *_sz_name) : pCommCtrl("Animate", _sz_name, "SysAnimate32", "ICC_ANIMATE_CLASS")
{	LookForInt("StopFrame", &nStopFrame, 0);

   LookForBool("Active", &bActive, false);
   LookForBool("Center", &bCenter, true);

   LookForText("FileName", &strFileName);
}


string pAnimate::GetClassString()
{	return strFileName;	}


bool pAnimate::SetMoreAttr()
{	for (int i = 0; i < strFileName.size(); i++)
   	if (strFileName[i] == '\\')
	   	strFileName[i] = '/';

	if (bActive) AddAttr("ACS_AUTOPLAY");
	if (bCenter) AddAttr("ACS_CENTER");

   return true;
}



/////////////////pToolBar
/////////////////pToolBar
pToolBar::pToolBar(char *_sz_name) : pCommCtrl("ToolBar", _sz_name, "ToolbarWindow32", "ICC_BAR_CLASSES")
{}



/////////////////pUpDownBase
/////////////////pUpDownBase
pUpDownBase::pUpDownBase(char *sz_type, char *_sz_name) : pCommCtrl(sz_type, _sz_name, "msctls_updown32", "ICC_UPDOWN_CLASS")
{  LookForBool("Wrap", &bWrap, false);

	nMin = 0;
   nMax = 100;
   nPosition = 0;
}


sl_It pUpDownBase::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{
  	pos = sl_cpp.Insert(++pos, "\t\t\tSendMessage(" + strCtlHWND +
   	", UDM_SETRANGE32, " + nMin + ", " + nMax + ");");

   return pos;
}





/////////////////pUpDown
/////////////////pUpDown
pUpDown::pUpDown(char *_sz_name) : pUpDownBase("UpDown", _sz_name)
{  LookForInt("Min", &nMin);
   LookForInt("Max", &nMax, 100);
   LookForInt("Position", &nPosition);
}



/////////////////pSpinEdit
/////////////////pSpinEdit
pSpinEdit::pSpinEdit(char *_sz_name) : pUpDownBase("SpinEdit", _sz_name)
{  bBorder = true;

   LookForInt("MinValue", &nMin, 0);
   LookForInt("MaxValue", &nMax, 100);
   LookForInt("Value", &nPosition, 0);

   LookForBool("ReadOnly", &bReadOnly, false);
}


bool pSpinEdit::SetMoreAttr()
{	if (bReadOnly) AddAttr("ES_READONLY");
	return true;
}


bool pSpinEdit::OnVisualParseEnd()
{	global_id++;
   return true;
}



sl_It pSpinEdit::WriteInit(StrList& sl_cpp, StrList& sl_hpp)
{  string str = "\n\t\t\t" + strCtlHWND + " = GetDlgItem(hWnd, " + strId + "_UPDOWN);";
   sl_It pos = HandleMessage(sl_cpp, "WM_INITDIALOG", str);

  	pos = sl_cpp.Insert(++pos, "\t\t\tSetDlgItemInt(hWnd, " +
   	strId + "_EDIT, " + nPosition + ", TRUE);");

	return WriteInitMore(sl_cpp, sl_hpp, pos);
}


bool pSpinEdit::WriteRcRh(StrList& sl_rc, StrList& sl_rh)
{  string str_rc = " CONTROL \"\", " + strId + "_EDIT, \"" + "edit" + "\", WS_CHILD";

	str_rc += " | ES_RIGHT | ES_NUMBER | WS_BORDER | WS_CLIPCHILDREN";
   if (bReadOnly) str_rc += " | ES_READONLY";

   sl_rc.push_back(str_rc + ", " + top_left.x + ", " + top_left.y + ", " + width + ", " + height);
   sl_rh.push_back("#define " + strId + "_EDIT " + id);

/////////////////////////////
   str_rc = " CONTROL \"\", " + strId + "_UPDOWN, \"" + strCtlFamily + "\", WS_CHILD";

   for (sl_It i = sl_attr.begin(); i != sl_attr.end(); i++)
     str_rc += " | " + (*i);

   sl_rc.push_back(str_rc + ", " + top_left.x + ", " + top_left.y + ", " + width + ", " + height);
   sl_rh.push_back("#define " + strId  + "_UPDOWN " + (id + 1));

   return true;
}



//////////////////pTabControl
//////////////////pTabControl
pTabControl::pTabControl(char *_sz_name) : pCommCtrl("TabControl", _sz_name, "SysTabControl32", "ICC_TAB_CLASSES")
{
	LookForInt("TabIndex", &nTabIndex);
	LookForAttr("Style", &strStyle, "tsTabs");
   LookForAttr("TabPosition", &strTabPosition, "tpTop");
   LookForBool("MultiLine", &bMultiLine, false);
}

bool pTabControl::ParseVisual(FILE *fin, char *sss)
{  if (!strcmpi(sss, "Tabs.Strings"))
   { 	ParseItems(fin, slTabs);
      return true;
   }
   return false;
}

bool pTabControl::SetMoreAttr()
{	if (bMultiLine) AddAttr("TCS_MULTILINE");

	return true;
}

sl_It pTabControl::WriteInitMore(StrList& sl_cpp, StrList& sl_hpp, sl_It pos)
{  string strItem = strCtlHWND + "Item";

	if (slTabs.size())
   {
   	pos = sl_cpp.Insert(++pos, "\n\t\t\tTCITEM " + strItem + ";");
   	pos = sl_cpp.Insert(++pos, "\t\t\tZeroMemory(&" + strItem + ", sizeof(TCITEM));");
		pos = sl_cpp.Insert(++pos, "\t\t\t" + strItem + ".mask = TCIF_TEXT | TCIF_IMAGE;");
		pos = sl_cpp.Insert(++pos, "\t\t\t" + strItem + ".iImage = -1;");
      int iCount = 0;
      for (sl_It i = slTabs.begin(); i != slTabs.end(); i++, iCount++)
		{  pos = sl_cpp.Insert(++pos, "\t\t\t" + strItem + ".pszText = \"" + (*i) + "\";");
         pos = sl_cpp.Insert(++pos, "\t\t\tTabCtrl_InsertItem(" + strCtlHWND +
         	", " + iCount + ", &" + strItem + ");");
      }
		pos = sl_cpp.Insert(++pos, "\t\t\tTabCtrl_SetCurSel(" + strCtlHWND + ", " + nTabIndex + ");");
   }

   return pos;
}







pMonthCal::pMonthCal(char * _sz_name) : pCommCtrl("MonthCal", _sz_name, "SysMonthCal32", "ICC_DATE_CLASSES")
{}


pDateTimePick::pDateTimePick(char * _sz_name) : pCommCtrl("DateTimePick", _sz_name, "SysDateTimePick32", "ICC_DATE_CLASSES")
{}


pPager::pPager(char *_sz_name) : pCommCtrl("Pager", _sz_name, "SysPager", "ICC_PAGESCROLLER_CLASS")
{}


pReBarWindow::pReBarWindow(char *_sz_name) : pCommCtrl("Rebar", _sz_name, "ReBarWindow32", "ICC_COOL_CLASSES")
{}


pHotKey::pHotKey(char *_sz_name) : pCommCtrl("HotKey", _sz_name, "msctls_hotkey32", "ICC_HOTKEY_CLASS")
{}



