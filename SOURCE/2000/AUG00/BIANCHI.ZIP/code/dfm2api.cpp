//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("dfm2api.res");
USEFORM("ChoiceForm.cpp", Form2);
USEUNIT("CommonControls.cpp");
USEUNIT("DialogBox.cpp");
USEUNIT("PVisualControl.cpp");
USEUNIT("Controls.cpp");
USEUNIT("EnumRes.cpp");
USEUNIT("pmenu.cpp");
USEUNIT("pVisual.cpp");
USEUNIT("pResComponent.cpp");
USEUNIT("pCommDialogs.cpp");
USEUNIT("StlUtils.cpp");
USEUNIT("CommonDialogs.cpp");
USEUNIT("PVCLCOMPONENT.cpp");
USEUNIT("process.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	try
	{
		Application->Initialize();
		Application->CreateForm(__classid(TForm2), &Form2);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	return 0;
}
//---------------------------------------------------------------------------
