//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
/**# implementation pVCLComponent:: id(C_0954414041) */


//---------------------------------------------------------------------------

#include <dir.h>
#include "PVCLCOMPONENT.h"

StringSet pVCLComponent::ss_include;


void pVCLComponent::LookForBool(const char *prop, bool *dest, bool def_val)
{  *dest = def_val;
   bm.insert(make_pair(prop, dest));
}


void pVCLComponent::LookForInt(const char *prop, int *dest, int def_val)
{  *dest = def_val;
   im.insert(make_pair(prop, dest));
}


void pVCLComponent::LookForText(const char *prop, string* dest, string def_val)
{	*dest = def_val;
	sm_text.insert(make_pair(prop, dest));
}

void pVCLComponent::LookForInfo(const char *prop, string* dest, string def_val)
{	*dest = def_val;
	sm_info.insert(make_pair(prop, dest));
}


unsigned char pVCLComponent::TwoChToByte(FILE *fin, char& ch)
{  char sz_val[3] = {0, 0, 0};
	unsigned char value;
	sz_val[0] = ch;
   sz_val[1] = fgetc(fin);
   sscanf(sz_val, "%X", &value);
   ch = fgetc(fin);
   return value;
}


string pVCLComponent::GetName()
{	return strName;	}


pVCLComponent::~pVCLComponent()
{}


int pVCLComponent::ParseItems(FILE *fin, StrList& items)
{  const int str_size = 256;
	char ch, str[str_size];
   int count = items.size();
   ch = fgetc(fin);	// un apostrofo
   while (ch != ')')
   {
   	NextChar(fin, '\'');
      int pos = 0;
      str[pos++] = ch = fgetc(fin);
      while ((ch != '\'') && (pos < str_size))
         str[pos++] = ch = fgetc(fin);

     	str[pos - 1] = '\0';
      if (pos >= str_size)
         NextChar(fin, '\'');//on the same line

      items.push_back(str);
      ch = fgetc(fin);
   }
   return items.size() - count;
}


int pVCLComponent::ParseCollection(FILE *fin, StrList& sl)
{	string str_coll;

	int count = sl.size();

  	NextChar(fin, '[');

   char ch = fgetc(fin);
	while (ch != ']')
   { 	str_coll = "";
      while (!((ch == ',') || (ch == ']')))
      {  str_coll += ch;
         ch = fgetc(fin);
      }

      sl.push_back(str_coll);
      if (ch == ',')
      {  ch = fgetc(fin);
      	while (ch == ' ')
         	ch = fgetc(fin);
      }
   }
   return sl.size() - count;
}

pVCLComponent::pVCLComponent(const char *_sz_type, const char *_sz_name, const char *_sz_include)
{	strType = _sz_type;
	strName = _sz_name;

   if (strlen(_sz_include))
   	ss_include.insert(ss_include.begin(), _sz_include);

   level = 0;
}

int pVCLComponent::GetLevel()
{	return level;	}


bool pVCLComponent::Parse(FILE *fin, char *sss, int _level)
{  bool b_obj = !strcmpi(sss, "object");
	bool b_end = !strcmpi(sss, "end");

   level = _level;

	while (!b_obj && !b_end)                     //  this
   {
   	im_iter ii = im.find(sss);
      if (ii != im.end())
  	   {  fscanf(fin, "%*s %d %s", ii->second, sss);
        	continue;
      }

      bm_iter bi = bm.find(sss);
      if (bi != bm.end())
  	   {	char str[16];
        	fscanf(fin, "%*s %s %s", str, sss);
        	*bi->second = strcmpi(str, "False");
        	continue;
      }

      sm_iter si = sm_text.find(sss);
      if (si != sm_text.end())
      {	fscanf(fin, "%*s");
      	char ch = '\0';
         while (ch != '\'')
         	ch = fgetc(fin);

         string text("");
         text += fgetc(fin);

         bool b_quit = false;
         while (!b_quit)
         { 	ch = fgetc(fin);
            if (ch == '\'')
            { 	ch = fgetc(fin);
            	if (ch == '\n')
               	b_quit = true;
               else
               	if (ch == '#')    // it's an apostrophe
                  {
                  	ch = fgetc(fin);	// char 3
                  	ch = fgetc(fin);	// char 9
                  	ch = fgetc(fin);	// char '
							text += '\'';
                  }
                  else
		            	NextChar(fin, '\'');
            }
            else
	            text += ch;
         }

         *si->second = text;
         fscanf(fin, "%s", sss);
         continue;
      }

      si = sm_info.find(sss);
      if (si != sm_info.end())
      {  char str[256];
      	fscanf(fin, "%*s %s %s", str, sss);
         *si->second = str;
         continue;
      }

      if (ParseMore(fin, sss))
      {  if (!feof(fin))
		      fscanf(fin, "%s", sss);
        	continue;
      }

		b_end = !strcmpi(sss, "end");
      b_obj = !strcmpi(sss, "object");

      bool b_exit = (b_end || b_obj);
      char ch = fgetc(fin);

      while (!b_exit && !feof(fin))
      {  switch (ch)
   	   {	case '\n':
            	b_exit = true;
            break;

            case '(':
            	NextChar(fin, ')');
               b_exit = true;
            break;

            case '<':
            	NextChar(fin, '>');
               b_exit = true;
            break;

            case '{':
            	NextChar(fin, '}');
               b_exit = true;
            break;

            default:
            	ch = fgetc(fin);
            break;
	      }
      }

      if (!b_end && ! b_obj)
      {  fscanf(fin, "%s", sss);
			b_end = !strcmpi(sss, "end");
   	   b_obj = !strcmpi(sss, "object");
      }
   }

   OnParseEnd();

   return true;
}


bool pVCLComponent::OnParseEnd()
{  return false;  }

bool pVCLComponent::ParseMore(FILE *fin, char *sss)
{	return false;	}


void pVCLComponent::NextChar(FILE *fin, char ch)
{	while ((fgetc(fin) != ch) && !feof(fin));	}


bool pVCLComponent::WriteCppHpp(StrList& sl_cpp, StrList& sl_hpp)
{	return false;	}


sl_It pVCLComponent::HandleMessage(StrList& sl, const string& msg, const string& code)
{
	string str = "//INSIDE_" + msg;
   sl_It i = find(sl.begin(), sl.end(), str);

   if (i == sl.end())
   {
   	i = sl.Insert_A_After_B("\n\t\tcase " + msg + ":\n\t\t{", INSIDE_SWITCH_MESSAGE);
   	i = sl.Insert(++i, str);
   	i = sl.Insert(++i, "\t\t}\n\t\tbreak; //" + msg);
      return HandleMessage(sl, msg, code);
   }
   else
   	i = sl.insert(++i, "\t\t\t" + code + " // " + strName);
   return i;
}



