//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#ifndef ChoiceFormH
#define ChoiceFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm2 : public TForm
{
__published:	// IDE-managed Components
   TButton *Process;
   TButton *Exit;
   TOpenDialog *OpenDfmDialog;
   TUpDown *udDialogID;
	TEdit *Edit1;
   TLabel *Label1;
   TLabel *Label2;
   TLabel *Label3;
   TUpDown *udRatioX;
   TEdit *Edit2;
   TUpDown *udRatioY;
   TEdit *Edit3;
   TUpDown *udCtlIdBase;
   TEdit *Edit4;
   TLabel *Label4;
   TButton *Extract;
   TOpenDialog *OpenExeDialog;
	TSaveDialog *SaveDialog1;
	void __fastcall ExitClick(TObject *Sender);
	void __fastcall ProcessClick(TObject *Sender);
   void __fastcall ExtractClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm2(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm2 *Form2;
//---------------------------------------------------------------------------
#endif
