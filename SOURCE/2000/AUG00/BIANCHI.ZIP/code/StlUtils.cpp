//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include "StlUtils.h"


StrList::StrList()
{}

StrList::~StrList()
{	clear();	}



sl_It StrList::Insert_A_Before_B(const string& A, const string& B)
{	sl_It i = find(begin(), end(), B);

	if (i != end())
      return insert(i, A);
   else
   	push_back(A);
   return end();
}



sl_It StrList::Insert_A_After_B(const string& A, const string& B)
{	sl_It i = find(begin(), end(), B);

	if (i != end())
      return insert(++i, A);
   else
   	push_back(A);
   return end();
}



void StrList::Append(const char* sz)
{	push_back(sz);	}


void StrList::Append(const string& str)
{	push_back(str);}


sl_It StrList::Insert(sl_It pos, const string& str)
{	return insert(pos, str);	}


sl_It StrList::Insert(sl_It pos, const char *sz)
{	return insert(pos, sz);	}


bool StrList::WriteFile(const char* sz_file_name)
{
	FILE *fout = fopen(sz_file_name, "wt");
   if (!fout) return false;
   for (sl_It i = begin(); i != end(); i++)
     	fprintf(fout, "%s\n", (*i).c_str());
   fclose(fout);
   return true;
}
