//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#ifndef _my_stl_defs_
#define _my_stl_defs_

#include <list>
#include <set>
#include <map>


using namespace std;


typedef map<string, string*> StringMap;
typedef StringMap::iterator sm_iter;

typedef map<string, int*> IntMap;
typedef IntMap::iterator im_iter;

typedef map<string, bool*> BoolMap;
typedef BoolMap::iterator bm_iter;



typedef set<const char*> StringSet;
typedef StringSet::iterator ss_iter;


inline string operator + (const string& lhs, const int value)
{	char sss[32];
	sprintf(sss, "%d", value);
   return string(lhs).append(sss);
}


typedef list<string>::iterator sl_It;

class StrList : public list <string>
{
	public:
   	StrList();
      ~StrList();
      sl_It Insert_A_Before_B(const string& A, const string& B);
      sl_It Insert_A_After_B(const string& A, const string& B);
      void Append(const char* sz);
      void Append(const string& str);
		sl_It Insert(sl_It pos, const string& str);
		sl_It Insert(sl_It pos, const char *sz);
      bool WriteFile(const char* sz_file_name);
};


#endif
