//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#ifndef PVISUAL_H
#define PVISUAL_H
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
#include "pResComponent.h"

struct pPoint
{	int x;
	int y;
};


class pVisualObject : public pResComponent
{
	public:
      pVisualObject(const char *_sz_type, const char *_sz_name, const char *_sz_include);
      virtual ~pVisualObject();
      bool Resize(float fx, float fy);
      void OffsetBy(pPoint& pnt);
      pPoint GetTopLeft();

      virtual bool ResizeMore(float fx, float fy);
      virtual string GetClassString();
		inline void AddAttr(const char *sz_attr);
		inline void AddAttrEx(const char *sz_attr);
		void LookForAttr(const char *what, string* dest, string def_val = "");

	protected :
      bool ApplyStyles();
      virtual bool OnVisualParseEnd();
      virtual bool ParseVisual(FILE *fin, char *sss);
      virtual bool SetAttr();
      virtual bool SetMoreAttr();

      pPoint top_left;

      int width;
      int height;
      int nFntHeight;

      string strCaption;
      string strFntCharset;
      string strFntColor;
      string strFntName;

      bool bFntItalic;
      bool bFntBold;
      bool bVisible;

      StrList slFntStyle;
		StringMap sm_attr;
      StrList sl_attr;
      StrList sl_attr_ex;
      static string strAttrFile;
      static string strAttrExFile;
   private :
      bool OnParseEnd();
      bool ParseMore(FILE *fin, char *sss);
};

#endif