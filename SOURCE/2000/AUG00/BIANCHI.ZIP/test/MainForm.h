//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
//---------------------------------------------------------------------------
#ifndef MainFormH
#define MainFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <ToolWin.hpp>
#include <Graphics.hpp>
#include <ImgList.hpp>
#include <Menus.hpp>
#include "CGAUGES.h"
#include "CSPIN.h"
//---------------------------------------------------------------------------
class TTranslateFormName : public TForm
{
__published:	// IDE-managed Components
	TBitBtn *BitBtn1;
	TBitBtn *BitBtn2;
	TLabel *Label1;
	TCheckBox *CheckBox1;
	TRadioButton *RadioButton1;
	TListBox *ListBox1;
	TComboBox *cb1;
	TGroupBox *GroupBox1;
	TTreeView *TreeView1;
	TListView *ListView1;
   TRichEdit *RichEdit1;
   TProgressBar *ProgressBar1;
   TStatusBar *StatusBar1;
   TScrollBar *ScrollBar1;
   TScrollBar *ScrollBar2;
   TImage *Image1;
	TEdit *Edit2;
	TEdit *Edit3;
	THeaderControl *HeaderControl1;
	TTabControl *TabControl1;
	TTrackBar *TrackBar1;
	TMonthCalendar *MonthCalendar1;
	TDateTimePicker *DateTimePicker1;
	TRadioGroup *RadioGroup1;
	TPanel *Panel1;
	TCheckBox *CheckBox2;
	TCheckBox *CheckBox3;
	TRadioButton *RadioButton2;
	TRadioButton *RadioButton3;
	TCheckBox *CheckBox4;
	TMainMenu *MainMenu1;
	TMenuItem *Ciao1;
	TMenuItem *ciao21;
	TMenuItem *subitem11;
	TMenuItem *Subitem21;
	TImage *Image2;
	TAnimate *Animate1;
	TButton *Button1;
	TButton *Button2;
	TPanel *Panel2;
	TButton *Button3;
	TSpeedButton *SpeedButton1;
	TBevel *Bevel1;
	TTabControl *TabControl2;
	TBevel *Bevel2;
	TMemo *Memo3;
	TMenuItem *pippo1;
	TMenuItem *ciao211;
	TMenuItem *Ciao221;
	TMenuItem *Ciao131;
	TMenuItem *Ciao141;
	TMenuItem *N11;
	TMenuItem *ciao31;
	TMenuItem *Ciao161;
	TMenuItem *Ciao171;
	TMenuItem *ciao311;
	TMenuItem *ciao321;
	TMenuItem *ciao331;
	TMenuItem *ciao341;
	TMenuItem *ciao351;
	TMenuItem *ciao3511;
	TMenuItem *ciao35111;
	TMenuItem *ciao351111;
	TProgressBar *ProgressBar2;
	TMenuItem *Menu221;
	TMenuItem *Menu231;
	TCSpinEdit *CSpinEdit1;
	TTabControl *TabControl3;
	void __fastcall BitBtn2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TTranslateFormName(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTranslateFormName *TranslateFormName;
//---------------------------------------------------------------------------
#endif
  