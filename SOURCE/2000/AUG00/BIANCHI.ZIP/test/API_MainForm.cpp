#include <windows.h>

#include <commctrl.h>

#include "API_MainForm.hpp"

//{{Implementation}}

// ---------------------------------------
// TTranslateFormName
// ~~~~~~~~~~~
//


//BEFORE_DIALOG_PROC


BOOL CALLBACK TTranslateFormNameDialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
//INSIDE_DIALOG_PROC
	static HWND hCtlTabControl3;
	static HWND hCtlCSpinEdit1;
	static HWND hCtlProgressBar2;
	static HWND hCtlMemo3;
	static HWND hCtlTabControl2;
	static HWND hCtlAnimate1;
	static HWND hCtlCheckBox4;
	static HWND hCtlRadioButton3;
	static HWND hCtlRadioButton2;
	static HWND hCtlCheckBox3;
	static HWND hCtlCheckBox2;
	static HWND hCtlButton3;
	static HWND hCtlPanel2;
	static HWND hCtlButton2;
	static HWND hCtlButton1;
	static HWND hCtlPanel1;
	static HWND hCtlRadioGroup1;
	static HWND hCtlDateTimePicker1;
	static HWND hCtlMonthCalendar1;
	static HWND hCtlTrackBar1;
	static HWND hCtlTabControl1;
	static HWND hCtlHeaderControl1;
	static HWND hCtlEdit3;
	static HWND hCtlEdit2;
	static HWND hCtlScrollBar2;
	static HWND hCtlScrollBar1;
	static HWND hCtlStatusBar1;
	static HWND hCtlProgressBar1;
	static HWND hCtlRichEdit1;
	static HWND hCtlListView1;
	static HWND hCtlTreeView1;
	static HWND hCtlcb1;
	static HWND hCtlListBox1;
	static HWND hCtlRadioButton1;
	static HWND hCtlCheckBox1;
	static HWND hCtlBitBtn2;
	static HWND hCtlBitBtn1;
	static HWND hCtlGroupBox1;
	static HWND hCtlBevel2;
	static HWND hCtlBevel1;
	static HBITMAP hBmpSpeedButton1;
	static HWND hCtlSpeedButton1;
	static HWND hCtlImage2;
	static HWND hCtlImage1;
	static HWND hCtlLabel1;
	switch (uMsg)
	{
//INSIDE_SWITCH_MESSAGE

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			BeginPaint(hWnd, &ps );
//INSIDE_WM_PAINT
			RECT rectPanel2;
			rectPanel2.left = 494;
			rectPanel2.top = 47;
			rectPanel2.right = 531;
			rectPanel2.bottom = 79;
			MapDialogRect(hWnd, &rectPanel2);
			DrawEdge(ps.hdc, &rectPanel2, 0x00 | BDR_SUNKENINNER, BF_RECT	);
 // Panel2
			RECT rectPanel1;
			rectPanel1.left = 489;
			rectPanel1.top = 0;
			rectPanel1.right = 537;
			rectPanel1.bottom = 85;
			MapDialogRect(hWnd, &rectPanel1);
			DrawEdge(ps.hdc, &rectPanel1, 0x00 | BDR_RAISEDINNER, BF_RECT	);
 // Panel1
			EndPaint(hWnd, &ps);
		}
		break;

		case WM_COMMAND:
		{
			WORD dwCtlId = LOWORD(wParam);
			WORD dwHi = HIWORD(wParam);
			switch (dwCtlId)
			{
//INSIDE_WM_COMMAND
				case IDC_CIAO351111:
//INSIDE_WM_COMMAND_IDC_CIAO351111
					//write menu response code here // ciao351111
				break; ////INSIDE_WM_COMMAND_IDC_CIAO351111


				case IDC_CIAO341:
//INSIDE_WM_COMMAND_IDC_CIAO341
					//write menu response code here // ciao341
				break; ////INSIDE_WM_COMMAND_IDC_CIAO341


				case IDC_CIAO331:
//INSIDE_WM_COMMAND_IDC_CIAO331
					//write menu response code here // ciao331
				break; ////INSIDE_WM_COMMAND_IDC_CIAO331


				case IDC_CIAO321:
//INSIDE_WM_COMMAND_IDC_CIAO321
					//write menu response code here // ciao321
				break; ////INSIDE_WM_COMMAND_IDC_CIAO321


				case IDC_CIAO311:
//INSIDE_WM_COMMAND_IDC_CIAO311
					//write menu response code here // ciao311
				break; ////INSIDE_WM_COMMAND_IDC_CIAO311


				case IDC_MENU231:
//INSIDE_WM_COMMAND_IDC_MENU231
					//write menu response code here // Menu231
				break; ////INSIDE_WM_COMMAND_IDC_MENU231


				case IDC_MENU221:
//INSIDE_WM_COMMAND_IDC_MENU221
					//write menu response code here // Menu221
				break; ////INSIDE_WM_COMMAND_IDC_MENU221


				case IDC_CIAO211:
//INSIDE_WM_COMMAND_IDC_CIAO211
					//write menu response code here // ciao211
				break; ////INSIDE_WM_COMMAND_IDC_CIAO211


				case IDC_CIAO171:
//INSIDE_WM_COMMAND_IDC_CIAO171
					//write menu response code here // Ciao171
				break; ////INSIDE_WM_COMMAND_IDC_CIAO171


				case IDC_N11:
//INSIDE_WM_COMMAND_IDC_N11
					//write menu response code here // N11
				break; ////INSIDE_WM_COMMAND_IDC_N11


				case IDC_CIAO141:
//INSIDE_WM_COMMAND_IDC_CIAO141
					//write menu response code here // Ciao141
				break; ////INSIDE_WM_COMMAND_IDC_CIAO141


				case IDC_CIAO131:
//INSIDE_WM_COMMAND_IDC_CIAO131
					//write menu response code here // Ciao131
				break; ////INSIDE_WM_COMMAND_IDC_CIAO131


				case IDC_CIAO221:
//INSIDE_WM_COMMAND_IDC_CIAO221
					//write menu response code here // Ciao221
				break; ////INSIDE_WM_COMMAND_IDC_CIAO221


				case IDC_PIPPO1:
//INSIDE_WM_COMMAND_IDC_PIPPO1
					//write menu response code here // pippo1
				break; ////INSIDE_WM_COMMAND_IDC_PIPPO1


				case IDC_SUBITEM11:
//INSIDE_WM_COMMAND_IDC_SUBITEM11
					//write menu response code here // subitem11
				break; ////INSIDE_WM_COMMAND_IDC_SUBITEM11


				case IDC_BITBTN2:
//INSIDE_WM_COMMAND_IDC_BITBTN2
					EndDialog(hWnd, IDCANCEL); // BitBtn2
				break; ////INSIDE_WM_COMMAND_IDC_BITBTN2


				case IDC_BITBTN1:
//INSIDE_WM_COMMAND_IDC_BITBTN1
					EndDialog(hWnd, IDOK); // BitBtn1
				break; ////INSIDE_WM_COMMAND_IDC_BITBTN1


				case IDC_SPEEDBUTTON1:
//INSIDE_WM_COMMAND_IDC_SPEEDBUTTON1
					//write code here // SpeedButton1
				break; ////INSIDE_WM_COMMAND_IDC_SPEEDBUTTON1


			}
			break;
		}
		; // + WM_COMMAND

		case WM_INITDIALOG:
		{
//INSIDE_WM_INITDIALOG
			
			hCtlTabControl3 = GetDlgItem(hWnd, IDC_TABCONTROL3); // TabControl3

			TCITEM hCtlTabControl3Item;
			ZeroMemory(&hCtlTabControl3Item, sizeof(TCITEM));
			hCtlTabControl3Item.mask = TCIF_TEXT | TCIF_IMAGE;
			hCtlTabControl3Item.iImage = -1;
			hCtlTabControl3Item.pszText = "One";
			TabCtrl_InsertItem(hCtlTabControl3, 0, &hCtlTabControl3Item);
			hCtlTabControl3Item.pszText = "Two";
			TabCtrl_InsertItem(hCtlTabControl3, 1, &hCtlTabControl3Item);
			hCtlTabControl3Item.pszText = "Three";
			TabCtrl_InsertItem(hCtlTabControl3, 2, &hCtlTabControl3Item);
			hCtlTabControl3Item.pszText = "Four";
			TabCtrl_InsertItem(hCtlTabControl3, 3, &hCtlTabControl3Item);
			TabCtrl_SetCurSel(hCtlTabControl3, 2);
			
			hCtlCSpinEdit1 = GetDlgItem(hWnd, IDC_CSPINEDIT1_UPDOWN); // CSpinEdit1
			SetDlgItemInt(hWnd, IDC_CSPINEDIT1_EDIT, 23, TRUE);
			SendMessage(hCtlCSpinEdit1, UDM_SETRANGE32, 20, 80);
			
			hCtlProgressBar2 = GetDlgItem(hWnd, IDC_PROGRESSBAR2); // ProgressBar2
			SendMessage(hCtlProgressBar2, PBM_SETRANGE32, -100, 100);
			SendMessage(hCtlProgressBar2, PBM_SETPOS, 0, 0);
			
			hCtlMemo3 = GetDlgItem(hWnd, IDC_MEMO3); // Memo3
			int nMemo3Len;
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "This is a VCL "));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nmemo "));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nfield"));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\n"));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nThis is a VCL "));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nmemo "));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nfield"));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\n"));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nThis is a VCL "));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nmemo "));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nfield"));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\n"));
			nMemo3Len = GetWindowTextLength(hCtlMemo3);
			SendMessage(hCtlMemo3, EM_SETSEL, (WPARAM)nMemo3Len, (LPARAM)nMemo3Len);
			SendMessage(hCtlMemo3, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\n "));
			
			hCtlTabControl2 = GetDlgItem(hWnd, IDC_TABCONTROL2); // TabControl2

			TCITEM hCtlTabControl2Item;
			ZeroMemory(&hCtlTabControl2Item, sizeof(TCITEM));
			hCtlTabControl2Item.mask = TCIF_TEXT | TCIF_IMAGE;
			hCtlTabControl2Item.iImage = -1;
			hCtlTabControl2Item.pszText = "one";
			TabCtrl_InsertItem(hCtlTabControl2, 0, &hCtlTabControl2Item);
			hCtlTabControl2Item.pszText = "two";
			TabCtrl_InsertItem(hCtlTabControl2, 1, &hCtlTabControl2Item);
			hCtlTabControl2Item.pszText = "three";
			TabCtrl_InsertItem(hCtlTabControl2, 2, &hCtlTabControl2Item);
			hCtlTabControl2Item.pszText = "four";
			TabCtrl_InsertItem(hCtlTabControl2, 3, &hCtlTabControl2Item);
			hCtlTabControl2Item.pszText = "five";
			TabCtrl_InsertItem(hCtlTabControl2, 4, &hCtlTabControl2Item);
			TabCtrl_SetCurSel(hCtlTabControl2, 3);
			
			hCtlAnimate1 = GetDlgItem(hWnd, IDC_ANIMATE1); // Animate1
			
			hCtlCheckBox4 = GetDlgItem(hWnd, IDC_CHECKBOX4); // CheckBox4
			
			hCtlRadioButton3 = GetDlgItem(hWnd, IDC_RADIOBUTTON3); // RadioButton3
			CheckRadioButton(hWnd, IDC_RADIOBUTTON3, IDC_RADIOBUTTON3, IDC_RADIOBUTTON3);
			
			hCtlRadioButton2 = GetDlgItem(hWnd, IDC_RADIOBUTTON2); // RadioButton2
			
			hCtlCheckBox3 = GetDlgItem(hWnd, IDC_CHECKBOX3); // CheckBox3
			CheckDlgButton(hWnd, IDC_CHECKBOX3, BST_CHECKED);
			
			hCtlCheckBox2 = GetDlgItem(hWnd, IDC_CHECKBOX2); // CheckBox2
			
			hCtlButton3 = GetDlgItem(hWnd, IDC_BUTTON3); // Button3
			
			hCtlPanel2 = GetDlgItem(hWnd, IDC_PANEL2); // Panel2
			
			hCtlButton2 = GetDlgItem(hWnd, IDC_BUTTON2); // Button2
			
			hCtlButton1 = GetDlgItem(hWnd, IDC_BUTTON1); // Button1
			
			hCtlPanel1 = GetDlgItem(hWnd, IDC_PANEL1); // Panel1
			
			hCtlRadioGroup1 = GetDlgItem(hWnd, IDC_RADIOGROUP1); // RadioGroup1
			CheckRadioButton(hWnd, IDC_RADIOGROUP1_ITEM_1, IDC_RADIOGROUP1_ITEM_4, IDC_RADIOGROUP1_ITEM_4);
			
			hCtlDateTimePicker1 = GetDlgItem(hWnd, IDC_DATETIMEPICKER1); // DateTimePicker1
			
			hCtlMonthCalendar1 = GetDlgItem(hWnd, IDC_MONTHCALENDAR1); // MonthCalendar1
			
			hCtlTrackBar1 = GetDlgItem(hWnd, IDC_TRACKBAR1); // TrackBar1
			SendMessage(hCtlTrackBar1, TBM_SETRANGE, FALSE, MAKELPARAM(1, 99));
			SendMessage(hCtlTrackBar1, TBM_SETSEL, FALSE, MAKELPARAM(20, 40));
			SendMessage(hCtlTrackBar1, TBM_SETPOS, TRUE, 55);
			SendMessage(hCtlTrackBar1, TBM_SETTICFREQ, 10, 0);
			
			hCtlTabControl1 = GetDlgItem(hWnd, IDC_TABCONTROL1); // TabControl1

			TCITEM hCtlTabControl1Item;
			ZeroMemory(&hCtlTabControl1Item, sizeof(TCITEM));
			hCtlTabControl1Item.mask = TCIF_TEXT | TCIF_IMAGE;
			hCtlTabControl1Item.iImage = -1;
			hCtlTabControl1Item.pszText = "First Tab";
			TabCtrl_InsertItem(hCtlTabControl1, 0, &hCtlTabControl1Item);
			hCtlTabControl1Item.pszText = "Second Tab ";
			TabCtrl_InsertItem(hCtlTabControl1, 1, &hCtlTabControl1Item);
			hCtlTabControl1Item.pszText = "Third Tab";
			TabCtrl_InsertItem(hCtlTabControl1, 2, &hCtlTabControl1Item);
			TabCtrl_SetCurSel(hCtlTabControl1, 1);
			
			hCtlHeaderControl1 = GetDlgItem(hWnd, IDC_HEADERCONTROL1); // HeaderControl1

			HDITEM hCtlHeaderControl1Item;
			ZeroMemory(&hCtlHeaderControl1Item, sizeof(HDITEM));
			hCtlHeaderControl1Item.mask = HDI_FORMAT | HDI_TEXT | HDI_WIDTH;
			hCtlHeaderControl1Item.fmt = HDF_LEFT;
			hCtlHeaderControl1Item.cxy = 80;
			hCtlHeaderControl1Item.pszText = "Section 1";
			Header_InsertItem(hCtlHeaderControl1, 0, &hCtlHeaderControl1Item);
			hCtlHeaderControl1Item.pszText = "Section 2";
			Header_InsertItem(hCtlHeaderControl1, 1, &hCtlHeaderControl1Item);
			
			hCtlEdit3 = GetDlgItem(hWnd, IDC_EDIT3); // Edit3
			SendMessage(hCtlEdit3, WM_SETTEXT, 0, (LPARAM) (LPCTSTR)"Edit3");
			
			hCtlEdit2 = GetDlgItem(hWnd, IDC_EDIT2); // Edit2
			SendMessage(hCtlEdit2, WM_SETTEXT, 0, (LPARAM) (LPCTSTR)"Edit2");
			
			hCtlScrollBar2 = GetDlgItem(hWnd, IDC_SCROLLBAR2); // ScrollBar2
			
			hCtlScrollBar1 = GetDlgItem(hWnd, IDC_SCROLLBAR1); // ScrollBar1
			
			hCtlStatusBar1 = GetDlgItem(hWnd, IDC_STATUSBAR1); // StatusBar1
			SendMessage(hCtlStatusBar1, SB_SIMPLE, 1, 0);
			int nStatusBar1Parts[2];
			nStatusBar1Parts[0] = 100;
			nStatusBar1Parts[1] = 200;
			SendMessage(hCtlStatusBar1, SB_SETPARTS, 2, (LPARAM)nStatusBar1Parts);
			SendMessage(hCtlStatusBar1, SB_SETTEXT, 0, (LPARAM) (LPCSTR) "xxx");
			SendMessage(hCtlStatusBar1, SB_SETTEXT, 1, (LPARAM) (LPCSTR) "yyy");
			SendMessage(hCtlStatusBar1, SB_SETTEXT, 255, (LPARAM) (LPCSTR) "pippo");
			
			hCtlProgressBar1 = GetDlgItem(hWnd, IDC_PROGRESSBAR1); // ProgressBar1
			SendMessage(hCtlProgressBar1, PBM_SETRANGE32, 0, 100);
			SendMessage(hCtlProgressBar1, PBM_SETPOS, 30, 0);
			
			hCtlRichEdit1 = GetDlgItem(hWnd, IDC_RICHEDIT1); // RichEdit1
			int nRichEdit1Len;
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM) 0, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) ""));
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "RichEdit1"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine1"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine2"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine3"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine4"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine5"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine6"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine7"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine8"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine9"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine10"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\n...."));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine100"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\n...."));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\nLine1000"));
			nRichEdit1Len = GetWindowTextLength(hCtlRichEdit1);
			SendMessage(hCtlRichEdit1, EM_SETSEL, (WPARAM)nRichEdit1Len, (LPARAM)nRichEdit1Len);
			SendMessage(hCtlRichEdit1, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) "\r\n "));
			
			hCtlListView1 = GetDlgItem(hWnd, IDC_LISTVIEW1); // ListView1
			ListView_SetExtendedListViewStyleEx(hCtlListView1, LVS_EX_GRIDLINES, LVS_EX_GRIDLINES);
			ListView_SetExtendedListViewStyleEx(hCtlListView1, LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);

			LVCOLUMN hCtlListView1Column;
			ZeroMemory(&hCtlListView1Column, sizeof(LVCOLUMN));
			hCtlListView1Column.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT;
			hCtlListView1Column.fmt = LVCFMT_LEFT;
			hCtlListView1Column.cx = 100;
			hCtlListView1Column.pszText = "Column 1";
			ListView_InsertColumn(hCtlListView1, 0, &hCtlListView1Column);
			hCtlListView1Column.pszText = "Column 2";
			ListView_InsertColumn(hCtlListView1, 1, &hCtlListView1Column);
			
			hCtlTreeView1 = GetDlgItem(hWnd, IDC_TREEVIEW1); // TreeView1
			
			hCtlcb1 = GetDlgItem(hWnd, IDC_CB1); // cb1
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 0");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 1");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 2");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 3");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 4");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 5");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 6");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 7");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 8");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 9");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 10");
			SendMessage(hCtlcb1, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ComboBox Item 11");
			
			hCtlListBox1 = GetDlgItem(hWnd, IDC_LISTBOX1); // ListBox1
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 0");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 1");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 2");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 3");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 4");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 5");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 6");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 7");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 8");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 9");
			SendMessage(hCtlListBox1, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR)"ListBox Item 10");
			
			hCtlRadioButton1 = GetDlgItem(hWnd, IDC_RADIOBUTTON1); // RadioButton1
			
			hCtlCheckBox1 = GetDlgItem(hWnd, IDC_CHECKBOX1); // CheckBox1
			
			hCtlBitBtn2 = GetDlgItem(hWnd, IDC_BITBTN2); // BitBtn2
			
			hCtlBitBtn1 = GetDlgItem(hWnd, IDC_BITBTN1); // BitBtn1
			
			hCtlGroupBox1 = GetDlgItem(hWnd, IDC_GROUPBOX1); // GroupBox1
			
			hCtlBevel2 = GetDlgItem(hWnd, IDC_BEVEL2); // Bevel2
			
			hCtlBevel1 = GetDlgItem(hWnd, IDC_BEVEL1); // Bevel1
			
			hCtlSpeedButton1 = GetDlgItem(hWnd, IDC_SPEEDBUTTON1); // SpeedButton1
			hBmpSpeedButton1 = LoadBitmap(GetModuleHandle(0), MAKEINTRESOURCE(IDC_SPEEDBUTTON1));
			SendMessage(hCtlSpeedButton1, BM_SETIMAGE, IMAGE_BITMAP, (LPARAM) hBmpSpeedButton1);
			
			hCtlImage2 = GetDlgItem(hWnd, IDC_IMAGE2); // Image2
			
			hCtlImage1 = GetDlgItem(hWnd, IDC_IMAGE1); // Image1
			
			hCtlLabel1 = GetDlgItem(hWnd, IDC_LABEL1); // Label1
		}
		break; //WM_INITDIALOG

		case WM_CLOSE:
		{
//INSIDE_WM_CLOSE
			EndDialog(hWnd, IDCANCEL); // TTranslateFormName
		}
		break; //WM_CLOSE
	}; // switch (uMsg)
//OUT_OF_SWITCH_MESSAGE
	return FALSE;
}; // DIALOG_PROC
//OUT_OF_DIALOG_PROC
