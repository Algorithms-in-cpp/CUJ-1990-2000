//Copyright (c) 2000, Luigi Bianchi
//E-Mail: Luigi.Bianchi@uniroma2.it.
//Permission is granted to use this code without restriction as long as 
//this copyright notice appears in all source files."
#include <windows.h>
#pragma hdrstop
#include <condefs.h>


#include <commctrl.h>
#include "mainform.rh"

#include "api_mainform.hpp"


//---------------------------------------------------------------------------
USERC("mainform.rc");
USEUNIT("API_MainForm.cpp");
//---------------------------------------------------------------------------
class pInitControls
{  HINSTANCE m_hLibRichEdit;
	public:
		pInitControls()
      {	m_hLibRichEdit = LoadLibrary("RichEd32.dll");
         INITCOMMONCONTROLSEX icce;
         icce.dwSize = sizeof(icce);
         icce.dwICC = ICC_WIN95_CLASSES | ICC_DATE_CLASSES | ICC_USEREX_CLASSES | ICC_TAB_CLASSES | ICC_COOL_CLASSES | ICC_LISTVIEW_CLASSES;

         InitCommonControlsEx(&icce);
      }
      ~pInitControls()
      {	FreeLibrary(m_hLibRichEdit);	      }
};



pInitControls re;


//---------------------------------------------------------------------------
#pragma argsused
WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int)
{
   DialogBox(hInst, MAKEINTRESOURCE(IDC_TTRANSLATEFORMNAME), NULL, (DLGPROC)TTranslateFormNameDialogProc);
   return 0;
}
