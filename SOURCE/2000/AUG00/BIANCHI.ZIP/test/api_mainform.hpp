#if !defined(api_TTranslateFormName_hpp)
#define api_api_TTranslateFormName_hpp

#include "MainForm.rh"
//INSIDE_HPP

BOOL CALLBACK TTranslateFormNameDialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
#endif  // MainForm_h sentry
