
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   10-Aug-1999

*/

#ifndef GBISTREAM_H
#define GBISTREAM_H

#include <stdlib.h>
#include <strings.h>
#include <typeinfo>

#include <string>
#include <deque>
#include <stack>
#include <slist>
#include <list>
#include <map>
#include <queue>
#include <vector>
#include <set>
#include <hash_set>
#include <hash_map>

class Gbistream {
public:
    virtual Gbistream& get(bool&)=0;
    virtual Gbistream& get(char&)=0;
    virtual Gbistream& get(unsigned&)=0;
    virtual Gbistream& get(short&)=0;
    virtual Gbistream& get(int&)=0;
    virtual Gbistream& get(long&)=0;
    virtual Gbistream& get(double&)=0;
    virtual Gbistream& get(long long&)=0;
    virtual Gbistream& getString(string&)=0;

    virtual Gbistream& get(const char*&)=0;
    virtual Gbistream& get(char*&)=0;
    virtual Gbistream& get(const bool*&)=0;
    virtual Gbistream& get(bool*&)=0;
    virtual Gbistream& get(const unsigned*&)=0;
    virtual Gbistream& get(unsigned*&)=0;
    virtual Gbistream& get(const short*&)=0;
    virtual Gbistream& get(short*&)=0;
    virtual Gbistream& get(const int*&)=0;
    virtual Gbistream& get(int*&)=0;
    virtual Gbistream& get(const long*&)=0;
    virtual Gbistream& get(const double*&)=0;
    virtual Gbistream& get(double*&)=0;
    virtual Gbistream& get(const long long*&)=0;
    virtual Gbistream& get(long long*&)=0;

    virtual Gbistream& operator>>(bool&)=0;
    virtual Gbistream& operator>>(char&)=0;
    virtual Gbistream& operator>>(unsigned&)=0;
    virtual Gbistream& operator>>(short&)=0;
    virtual Gbistream& operator>>(int&)=0;
    virtual Gbistream& operator>>(long&)=0;
    virtual Gbistream& operator>>(double&)=0;
    virtual Gbistream& operator>>(long long&)=0;
    virtual Gbistream& operator>>(string&)=0;

    virtual Gbistream& operator>>(const char*&)=0;
    virtual Gbistream& operator>>(char*&)=0;
    virtual Gbistream& operator>>(const bool*&)=0;
    virtual Gbistream& operator>>(bool*&)=0;
    virtual Gbistream& operator>>(const unsigned*&)=0;
    virtual Gbistream& operator>>(unsigned*&)=0;
    virtual Gbistream& operator>>(const short*&)=0;
    virtual Gbistream& operator>>(short*&)=0;
    virtual Gbistream& operator>>(const int*&)=0;
    virtual Gbistream& operator>>(int*&)=0;
    virtual Gbistream& operator>>(const long*&)=0;
    virtual Gbistream& operator>>(long*&)=0;
    virtual Gbistream& operator>>(const double*&)=0;
    virtual Gbistream& operator>>(double*&)=0;
    virtual Gbistream& operator>>(const long long*&)=0;
    virtual Gbistream& operator>>(long long*&)=0;
    
};


template < class T, class A >
Gbistream& operator>>(Gbistream& bistr, deque<T, A>& dque)
{
    dque.clear();

    size_t size;
    bistr >> size; 
    if(size > 0) {
        T t;
        for(int i = 0; i < size; i++) {
            bistr >> t;
    	    dque.push_back(t);
        }
    }
    return bistr;
}

template <class T, class S> 
Gbistream& operator>>(Gbistream& bistr, stack<T, S>& stk)
{
    while(!stk.empty()) stk.pop();
    
    size_t sz;
    bistr >> sz;
    const size_t size = sz;
    if(size > 0) {
        int i;
        T bf[size];
        for(i=size; i > 0;)  
    	    bistr >> bf[--i];
        for(i=0; i < size;)
    	    stk.push(bf[i++]);
    }
    return bistr;
}

template<class T, class A>
Gbistream& operator>>(Gbistream& bistr, slist<T, A>& lst)
{
    if(!lst.empty()) 
    	lst.clear();
    size_t size;
    bistr >> size;
    if(size > 0) {
        T t;
        bistr >> t;
        lst.push_front(t);
        slist<T>::iterator back= lst.begin();
        for(int i=1; i < size; i++) {
    		bistr >> t;
    	    back = lst.insert_after(back, t);
        }
    }
    return bistr;
}

template <class T, class A>
Gbistream& operator>>(Gbistream& bistr, list<T, A>& lst)
{
    if(!lst.empty())
        lst.clear();
    size_t size;
    bistr >> size;
    if(size > 0) {
        T t;
    	for(int i=0; i < size; i++) {
    		bistr >> t;
    		lst.push_back(t);
    	}
    }
    return bistr;
}

template <class K, class V, class C, class A > 
Gbistream& operator>>(Gbistream& bistr, map<K, V, C, A>& mp)
{
    if(!mp.empty()) mp.clear();

    size_t size;
    bistr >> size;
    if(size > 0) {
    	K k;
    	V v;
    	for(int i=0; i < size; i++) {
    	    bistr >> k;
    	    bistr >> v;
    	    pair<K, V> p(k, v);
    	    mp.insert(p);
        }
    }
    return bistr;
}

template <class T, class S> 
Gbistream& operator>>(Gbistream& bistr, queue<T, S>& Q)
{
    while(!Q.empty()) Q.pop();

    size_t size;
    bistr >> size;
    if(size > 0) 
        for(int i=0; i < size; i++) {
    		T t;
    		bistr >> t;
            Q.push(t);
    	}
    return bistr;
}

template <class T, class S, class C> 
Gbistream& operator>>(Gbistream& bistr, priority_queue<T, S, C>& Q) 
{
    while(!Q.empty()) Q.pop();

    size_t size;
    bistr >> size;
    if(size > 0)
        for(int i=0; i < size; i++) {
            T t;
            bistr >> t;
            Q.push(t);
        }
    return bistr;
}

template <class T, class A>
Gbistream& operator>>(Gbistream& bistr, vector<T, A>& V)
{
    while(!V.empty()) V.clear();

    size_t size;
    bistr >> size;
    if(size > 0) 
    	for(int i=0; i < size; i++) {
    		T t;
            bistr >> t;
            V.push_back(t);
        }
    return bistr;
}

template <class K, class C, class A> 
Gbistream& operator>>(Gbistream& bistr, set<K, C, A>& S)
{
    while(!S.empty()) S.clear();

    size_t size;
    bistr >> size;
    if(size > 0)
        for(int i=0; i < size; i++) {
            K k;
            bistr >> k;
            S.insert(k);
        }
    return bistr;
}

template <class K, class C, class A>
Gbistream& operator>>(Gbistream& bistr, multiset<K, C, A>& S)
{
    while(!S.empty()) S.clear();

    size_t size;
    bistr >> size;
    if(size > 0)
        for(int i=0; i < size; i++) {
            K k;
            bistr >> k;
            S.insert(k);
        }
    return bistr;
}

template <class K, class H, class E, class A > 
Gbistream& operator>>(Gbistream& bistr, hash_multiset<K, H, E, A>& S)
{
    while(!S.empty()) S.clear();

    size_t size;
    bistr >> size;
    if(size > 0)
        for(int i=0; i < size; i++) {
            K k;
            bistr >> k;
            S.insert(k);
        }
    return bistr;
}

template <class K, class V, class C, class A >
Gbistream& operator>>(Gbistream& bistr, multimap<K, V, C, A>& mp)
{
    if(!mp.empty()) mp.clear();

    size_t size;
    bistr >> size;
    if(size > 0) {
        K k;
        V v;
        for(int i=0; i < size; i++) {
            bistr >> k;
            bistr >> v;
            pair<K, V> p(k, v);
            mp.insert(p);
        }
    }
    return bistr;
}

template <class K, class V, class H, class E, class A>
Gbistream& operator>>(Gbistream& bistr, hash_multimap<K, V, H, E, A>& mp)
{
    if(!mp.empty()) mp.clear();

    size_t size;
    bistr >> size;
    if(size > 0) {
        K k;
        V v;
        for(int i=0; i < size; i++) {
            bistr >> k;
            bistr >> v;
            pair<K, V> p(k, v);
            mp.insert(p);
        }
    }
    return bistr;
}

template <class K, class V, class H, class E, class A>
Gbistream& operator>>(Gbistream& bistr, hash_map<K, V, H, E, A>& mp)
{
    if(!mp.empty()) mp.clear();

    size_t size;
    bistr >> size;
    if(size > 0) {
        K k;
        V v;
        for(int i=0; i < size; i++) {
            bistr >> k;
            bistr >> v;
            pair<K, V> p(k, v);
            mp.insert(p);
        }
    }
    return bistr;
}

template <class T1, class T2>
Gbistream& operator>>(Gbistream& bistr, pair<T1, T2>& P)
{
    bistr >> P.first;
    bistr >> P.second;
        
    return bistr;
}

#endif
