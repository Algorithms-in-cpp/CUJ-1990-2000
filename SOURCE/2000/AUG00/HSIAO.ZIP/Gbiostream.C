
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   10-Aug-1999

*/

#include "Gbiostream.h"
#include <typeinfo>

Gbistream& operator>>(Gbistream& bistr, bit_vector& bv)
{
    while(!bv.empty()) bv.clear();

    size_t size;
    bistr >> size;
    if(size > 0)
        for(int i=0; i < size; i++) {
            bool b;
            bistr >> b;
            bv.push_back(b);
        }
    return bistr;
}

Gbostream& operator<<(Gbostream& bostr, const bit_vector& bv)
{
    size_t size = bv.size();
    bostr << size;
    if(size > 0) 
       for(bit_vector::const_iterator i = bv.begin(); i < bv.end(); ++i)
           bostr << *i;
    return bostr;
}

Gbiostream::Gbiostream():_err(2)
{
    _err[0] = _err[1] = false;
    _idx = 0;
}

Gbiostream::~Gbiostream()
{
    clear();
}

void Gbiostream::clear()
{
    _err[0] = _err[1] = false;
    _idx = 0;
    _data.resize(0);
}

bool Gbiostream::isFail()
{
    return (_err[0])? false : true;
}

bool Gbiostream::isGood() 
{
    return (_err[1])? true : false;
}

void Gbiostream::operator=(const Gbiostream& biostr)
{
    _err = biostr._err;
    _idx = biostr._idx;
    _data = biostr._data;
}

Gbiostream::operator const string& ()
{
    return _data;
}

Gbiostream::operator string& ()
{
    return _data;
}

Gbistream& Gbiostream::get(bool& b)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(bool).name(), bf)) 
    {
    	_err[0] = true;
    	_err[1] = true;
    }

    sz = sizeof(bool);
    _data.copy((char*)(&b), sz, _idx);
    _idx += sz;
    return *this;
}

Gbistream& Gbiostream::get(char& c)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(char).name(), bf))  
    {
        _err[0] = true;
        _err[1] = true;
    }

    sz = sizeof(char);
    _data.copy((char*)(&c), sz, _idx);
    _idx += sz;
    return *this;
}

Gbistream& Gbiostream::get(unsigned& u)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(unsigned).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    sz = sizeof(unsigned);
    _data.copy((char*)(&u), sz, _idx);
    _idx += sz;
    return *this;
}

Gbistream& Gbiostream::get(short& s)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(short).name(), bf))  
    {
        _err[0] = true;
        _err[1] = true;
    }

    sz = sizeof(short);
    _data.copy((char*)(&s), sz, _idx);
    _idx += sz;
    return *this;
}

Gbistream& Gbiostream::get(int& i)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(int).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    sz = sizeof(int);
    _data.copy((char*)(&i), sz, _idx);
    _idx += sz;
    return *this;
}

Gbistream& Gbiostream::get(long& l)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(long).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    sz = sizeof(long);
    _data.copy((char*)(&l), sz, _idx);
    _idx += sz;
    return *this;
}

Gbistream& Gbiostream::get(double& d)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(double).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    sz = sizeof(double);
    _data.copy((char*)(&d), sz, _idx);
    _idx += sz;
    return *this;
}

Gbistream& Gbiostream::get(long long& ll)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(long long).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    sz = sizeof(long long);
    _data.copy((char*)(&ll), sz, _idx);
    _idx += sz;
    return *this;
}

Gbistream& Gbiostream::getString(string& str)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(string).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        str.assign(_data, _idx, size);
        _idx += size;
    }
    str.resize(size);

   return *this;
}

Gbistream& Gbiostream::get(char*& pch)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(char*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
    	pch = new char[size];
    	_data.copy(pch, size, _idx);
    	_idx += size;
    }	
    return *this;
}

Gbistream& Gbiostream::get(bool*& pb)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(bool*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pb = new bool[size/sizeof(bool)];
        _data.copy((char*)pb, size, _idx);
        _idx += size;
    }  
    return *this;
}

Gbistream& Gbiostream::get(unsigned*& pu)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(unsigned*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pu = new unsigned[size/sizeof(unsigned)];
        _data.copy((char*)pu, size, _idx);
        _idx += size;
    } 
    return *this;
}

Gbistream& Gbiostream::get(short*& ps)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(short*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        ps = new short[size/sizeof(short)];
        _data.copy((char*)ps, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(int*& pi)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(int*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pi = new int[size/sizeof(int)];
        _data.copy((char*)pi, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(long*& pl)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(long*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pl = new long[size/sizeof(long)];
        _data.copy((char*)pl, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(double*& pd)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(double*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pd = new double[size/sizeof(double)];
        _data.copy((char*)pd, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(long long*& pll)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(long long*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pll = new long long[size/sizeof(long long)];
        _data.copy((char*)pll, size, _idx);
        _idx += size;
    }
    return *this;
}


Gbistream& Gbiostream::get(const char*& pcch)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(const char*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pcch = new char[size];
    	char* pch = const_cast<char*>(pcch);
        _data.copy(pch, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(const bool*& pb)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(const bool*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pb = new bool[size/sizeof(bool)];
        bool* vec = const_cast<bool*>(pb);
        _data.copy((char*)vec, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(const unsigned*& pu)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(const unsigned*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pu = new unsigned[size/sizeof(unsigned)];
        unsigned* vec = const_cast<unsigned*>(pu);
        _data.copy((char*)vec, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(const short*& ps)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(const short*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        ps = new short[size/sizeof(short)];
        short* vec = const_cast<short*>(ps);
        _data.copy((char*)vec, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(const int*& pi)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(const int*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pi = new int[size/sizeof(int)];
        int* vec = const_cast<int*>(pi);
        _data.copy((char*)vec, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(const long*& pl)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(const long*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pl = new long[size/sizeof(long)];
        long* vec = const_cast<long*>(pl);
        _data.copy((char*)vec, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(const double*& pd)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(const double*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pd = new double[size/sizeof(double)];
        double* vec = const_cast<double*>(pd);
        _data.copy((char*)vec, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::get(const long long*& pll)
{
    size_t bfsz, sz = sizeof(size_t);
    _data.copy((char*)(&bfsz), sz, _idx);
    _idx += sz;
    const size_t type_size = bfsz;;
    char bf[type_size];
    _data.copy((char*)(&bf), bfsz, _idx);
    _idx += bfsz;
    if(strcmp(typeid(long long*).name(), bf))
    {
        _err[0] = true;
        _err[1] = true;
    }

    int size;
    sz = sizeof(size_t);
    _data.copy((char*)(&size), sz, _idx);
    _idx += sz;
    if(size > 0) {
        pll = new long long[size/sizeof(long long)];
        long long* vec = const_cast<long long*>(pll);
        _data.copy((char*)vec, size, _idx);
        _idx += size;
    }
    return *this;
}

Gbistream& Gbiostream::operator>>(bool& b)
{
    get(b);
    return *this;
}

Gbistream& Gbiostream::operator>>(char& c)
{
    get(c);
    return *this;
}

Gbistream& Gbiostream::operator>>(unsigned& u)
{
    get(u);
    return *this;
}

Gbistream& Gbiostream::operator>>(short& s)
{
    get(s);
    return *this;
}

Gbistream& Gbiostream::operator>>(int& i)
{
    get(i);
    return *this;
}

Gbistream& Gbiostream::operator>>(long& l)
{
    get(l);
    return *this;
}

Gbistream& Gbiostream::operator>>(double& d)
{
    get(d);
    return *this;
}

Gbistream& Gbiostream::operator>>(long long& ll)
{
    get(ll);
    return *this;
}

Gbistream& Gbiostream::operator>>(string& src)
{
    getString(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(char*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(bool*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(unsigned*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(short*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(int*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(long*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(double*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(long long*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(const char*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(const bool*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(const unsigned*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(const short*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(const int*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(const long*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(const double*& src)
{
    get(src);
    return *this;
}

Gbistream& Gbiostream::operator>>(const long long*& src)
{
    get(src);
    return *this;
}

Gbostream& Gbiostream::put(const bool b)
{
    size_t type_size = strlen(typeid(bool).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(bool).name(), type_size);
    size_t sz = sizeof(bool);
    _data.append((char*)(&b), sz);
    return *this;
}

Gbostream& Gbiostream::put(const char c)
{
    size_t type_size = strlen(typeid(char).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(char).name(), type_size);
    size_t sz = sizeof(char);
    _data.append((char*)(&c), sz);
    return *this;
}

Gbostream& Gbiostream::put(const unsigned u)
{
    size_t type_size = strlen(typeid(unsigned).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(unsigned).name(), type_size);
    size_t sz = sizeof(unsigned);
    _data.append((char*)(&u), sz);
    return *this;
}

Gbostream& Gbiostream::put(const short s)
{
    size_t type_size = strlen(typeid(short).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(short).name(), type_size);
    size_t sz = sizeof(short);
    _data.append((char*)(&s), sz);
    return *this;
}

Gbostream& Gbiostream::put(const int i)
{
    size_t type_size = strlen(typeid(int).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(int).name(), type_size);
    size_t sz = sizeof(int);
    _data.append((char*)(&i), sz);
    return *this;
}

Gbostream& Gbiostream::put(const long l)
{
    size_t type_size = strlen(typeid(long).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(long).name(), type_size);
    size_t sz = sizeof(long);
    _data.append((char*)(&l), sz);
    return *this;
}

Gbostream& Gbiostream::put(const double d)
{
    size_t type_size = strlen(typeid(double).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(double).name(), type_size);
    size_t sz = sizeof(double);
    _data.append((char*)(&d), sz);
    return *this;
}

Gbostream& Gbiostream::put(const long long ll)
{
    size_t type_size = strlen(typeid(long long).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(ll).name(), type_size);
    size_t sz = sizeof(long long);
    _data.append((char*)(&ll), sz);
    return *this;
}

Gbostream& Gbiostream::putString(const string& str)
{
    size_t type_size = strlen(typeid(string).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(string).name(), type_size);

    int size = str.size();
    size_t sz = sizeof(size_t);
    _data.append((char*)(&size), sz);

    if(size > 0) {
        _data.append(str.data(), size);
    }
    return *this;
}

Gbostream& Gbiostream::put(const char* pch)
{
    size_t type_size = strlen(typeid(const char*).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(const char*).name(), type_size);

    char ch='\0';
    size_t size;
    size_t sz = sizeof(size_t);
    if(pch == NULL) {
    	size = 0;
    	_data.append((char*)(&size), sz);
    }
     else if(*pch == '\0') {
    	size = 1;
    	_data.append((char*)(&size), sz);
    	_data.append(&ch, sizeof(char));
    }
    else {
        size = strlen(pch)+1;
    	_data.append((char*)(&size), sz);
        _data.append(pch, size);
    }
    return *this;
}

Gbostream& Gbiostream::put(const bool* pb, size_t n)
{
    size_t type_size = strlen(typeid(const bool*).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(const bool*).name(), type_size);

    size_t size;
    size_t sz = sizeof(size_t);
    if(pb == NULL || n == 0) {
        size = 0;
        _data.append((char*)(&size), sz);
    }
    else {
        size = sizeof(bool)*n;
        _data.append((char*)(&size), sz);
        _data.append((char*)pb, size);
    }
    return *this;
}

Gbostream& Gbiostream::put(const unsigned* pu, size_t n)
{
    size_t type_size = strlen(typeid(const unsigned*).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(const unsigned*).name(), type_size);

    size_t size;
    size_t sz = sizeof(size_t);
    if(pu == NULL || n == 0) {
        size = 0;
        _data.append((char*)(&size), sz);
    }
    else {
        size = sizeof(unsigned)*n;
        _data.append((char*)(&size), sz);
        _data.append((char*)pu, size);
    }
    return *this;
}

Gbostream& Gbiostream::put(const short* ps, size_t n)
{
    size_t type_size = strlen(typeid(const short*).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(const short*).name(), type_size);

    size_t size;
    size_t sz = sizeof(size_t);
    if(ps == NULL || n == 0) {
        size = 0;
        _data.append((char*)(&size), sz);
    }
    else {
        size = sizeof(short)*n;
        _data.append((char*)(&size), sz);
        _data.append((char*)ps, size);
    }
    return *this;
}

Gbostream& Gbiostream::put(const int* pi, size_t n)
{
    size_t type_size = strlen(typeid(const int*).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(const int*).name(), type_size);

    size_t size;
    size_t sz = sizeof(size_t);
    if(pi == NULL || n == 0) {
        size = 0;
        _data.append((char*)(&size), sz);
    }
    else {
        size = sizeof(int)*n;
        _data.append((char*)(&size), sz);
        _data.append((char*)pi, size);
    }
    return *this;
}

Gbostream& Gbiostream::put(const long* pl, size_t n)
{
    size_t type_size = strlen(typeid(const long*).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(const long*).name(), type_size);

    size_t size;
    size_t sz = sizeof(size_t);
    if(pl == NULL || n == 0) {
        size = 0;
        _data.append((char*)(&size), sz);
    }
    else {
        size = sizeof(long)*n;
        _data.append((char*)(&size), sz);
        _data.append((char*)pl, size);
    }
    return *this;
}

Gbostream& Gbiostream::put(const double* pd, size_t n)
{
    size_t type_size = strlen(typeid(const double*).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(const double*).name(), type_size);

    size_t size;
    size_t sz = sizeof(size_t);
    if(pd == NULL || n == 0) {
        size = 0;
        _data.append((char*)(&size), sz);
    }
    else {
        size = sizeof(double)*n;
        _data.append((char*)(&size), sz);
        _data.append((char*)pd, size);
    }
    return *this;
}

Gbostream& Gbiostream::put(const long long* pll, size_t n)
{
    size_t type_size = strlen(typeid(const long long*).name())+1;
    _data.append((char*)(&type_size), sizeof(size_t));
    _data.append(typeid(const long long*).name(), type_size);

    size_t size;
    size_t sz = sizeof(size_t);
    if(pll == NULL || n == 0) {
        size = 0;
        _data.append((char*)(&size), sz);
    }
    else {
        size = sizeof(long long)*n;
        _data.append((char*)(&size), sz);
        _data.append((char*)pll, size);
    }
    return *this;
}

Gbostream& Gbiostream::operator<<(const bool b)
{
    put(b);
    return *this;
}

Gbostream& Gbiostream::operator<<(const char c)
{
    put(c);
    return *this;
}

Gbostream& Gbiostream::operator<<(const unsigned u)
{
    put(u);
    return *this;
}

Gbostream& Gbiostream::operator<<(const short s)
{
    put(s);
    return *this;
}

Gbostream& Gbiostream::operator<<(const int i)
{
    put(i);
    return *this;
}

Gbostream& Gbiostream::operator<<(const long l)
{
    put(l);
    return *this;
}

Gbostream& Gbiostream::operator<<(const double d)
{
    put(d);
    return *this;
}

Gbostream& Gbiostream::operator<<(const long long ll)
{
    put(ll);
    return *this;
}

Gbostream& Gbiostream::operator<<(const string& src)
{
    putString(src);
    return *this;
}

Gbostream& Gbiostream::operator<<(const char* src)
{
    put(src);
    return *this;
}

Gbostream& Gbiostream::addStr(const char* bf, size_t size)
{
    _data.append(bf, size);
    return *this;
}

Gbistream& Gbiostream::copyStr(char* pc, size_t size)
{
    _data.copy(pc, size, _idx);
    _idx += size;
    return *this;
}

void Gbiostream::set_error()
{
    _err[0] = true;
    _err[1] = true;
}
