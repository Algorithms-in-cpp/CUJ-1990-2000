
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

*/

#include "example.h"

ABC::operator const string& ()
{
    *this << _size;
    *this << _name;
    *this << _price;
    *this << _desp;

    return getData();
}

void ABC::operator=(const string& str)
{
    putData(str);

    *this >> _size;
    *this >> _name;
    *this >> _price;
    *this >> _desp;
}

void ABC::set_price(double d) { _price = d; }
void ABC::set_size(int i) { _size = i; }
void ABC::set_desp(string s) { _desp = s; }
void ABC::set_name(string n) { _name = n; }

