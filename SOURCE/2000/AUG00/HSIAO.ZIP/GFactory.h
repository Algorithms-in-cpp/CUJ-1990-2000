
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   15-July-1999

*/

#ifndef	GFACTORY_H
#define GFACTORY_H

#include <map>

template <class T> class GFactory
{
public:
    typedef T* (*PFUNC)(void);
    typedef map<string, PFUNC, less<string> > FMAP;

    virtual void add_function(const string&, PFUNC);
    virtual T* create(const string&);
    virtual bool findClassTypeId(const string&);

private:
    FMAP	_fmap;
};

template<class T> 
void GFactory<T>::add_function(const string& clsid, PFUNC pfc)
{
    if(_fmap.find(clsid) == _fmap.end())   
        _fmap[clsid] = pfc;
}

template<class T> 
bool GFactory<T>::findClassTypeId(const string& clsid)
{
    if(_fmap.find(clsid) != _fmap.end())  return  true;
    else return false;
}

template<class T> 
T* GFactory<T>::create(const string& clsid)
{
    FMAP::iterator itr;

    if((itr = _fmap.find(clsid)) != _fmap.end())  
        return (((*itr).second)());
    else  
        return (T*)0;
}

#endif
