
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   20-Aug-1999

*/

#ifndef GBIOSTREAM_H
#define GBIOSTREAM_H

#include <bvector.h>
#include <string>

#include "Gbistream.h"
#include "Gbostream.h"

class Gbiostream : public Gbistream, public Gbostream {
    friend Gbistream& operator>>(Gbistream&, bit_vector&);
    friend Gbostream& operator<<(Gbostream&, const bit_vector&);

public:
    Gbiostream();
    virtual ~Gbiostream();

    virtual Gbistream& get(bool&);
    virtual Gbistream& get(char&);
    virtual Gbistream& get(unsigned&);
    virtual Gbistream& get(short&);
    virtual Gbistream& get(int&);
    virtual Gbistream& get(long&);
    virtual Gbistream& get(double&);
    virtual Gbistream& get(long long&);
    virtual Gbistream& getString(string&);

    virtual Gbistream& get(const char*&);
    virtual Gbistream& get(char*&);
    virtual Gbistream& get(const bool*&);
    virtual Gbistream& get(bool*&);
    virtual Gbistream& get(const unsigned*&);
    virtual Gbistream& get(unsigned*&);
    virtual Gbistream& get(const short*&);
    virtual Gbistream& get(short*&);
    virtual Gbistream& get(const int*&);
    virtual Gbistream& get(int*&);
    virtual Gbistream& get(const long*&);
    virtual Gbistream& get(long*&);
    virtual Gbistream& get(const double*&);
    virtual Gbistream& get(double*&);
    virtual Gbistream& get(const long long*&);
    virtual Gbistream& get(long long*&);

    virtual Gbistream& operator>>(bool&);
    virtual Gbistream& operator>>(char&);
    virtual Gbistream& operator>>(unsigned&);
    virtual Gbistream& operator>>(short&);
    virtual Gbistream& operator>>(int&);
    virtual Gbistream& operator>>(long&);
    virtual Gbistream& operator>>(double&);
    virtual Gbistream& operator>>(long long&);
    virtual Gbistream& operator>>(string&);

    virtual Gbistream& operator>>(const char*&);
    virtual Gbistream& operator>>(char*&);
    virtual Gbistream& operator>>(const bool*&);
    virtual Gbistream& operator>>(bool*&);
    virtual Gbistream& operator>>(const unsigned*&);
    virtual Gbistream& operator>>(unsigned*&);
    virtual Gbistream& operator>>(const short*&);
    virtual Gbistream& operator>>(short*&);
    virtual Gbistream& operator>>(const int*&);
    virtual Gbistream& operator>>(int*&);
    virtual Gbistream& operator>>(const long*&);
    virtual Gbistream& operator>>(long*&);
    virtual Gbistream& operator>>(const double*&);
    virtual Gbistream& operator>>(double*&);
    virtual Gbistream& operator>>(const long long*&);
    virtual Gbistream& operator>>(long long*&);

    virtual Gbostream& put(const bool);
    virtual Gbostream& put(const char);
    virtual Gbostream& put(const unsigned);
    virtual Gbostream& put(const short);
    virtual Gbostream& put(const int);
    virtual Gbostream& put(const long);
    virtual Gbostream& put(const double);
    virtual Gbostream& put(const long long);
    virtual Gbostream& putString(const string&);

    virtual Gbostream& put(const char*);
    virtual Gbostream& put(const bool*, size_t);
    virtual Gbostream& put(const unsigned*, size_t);
    virtual Gbostream& put(const short*, size_t);
    virtual Gbostream& put(const int*, size_t);
    virtual Gbostream& put(const long*, size_t);
    virtual Gbostream& put(const double*, size_t);
    virtual Gbostream& put(const long long*, size_t);

    virtual Gbostream& operator<<(const bool);
    virtual Gbostream& operator<<(const char);
    virtual Gbostream& operator<<(const unsigned);
    virtual Gbostream& operator<<(const short);
    virtual Gbostream& operator<<(const int);
    virtual Gbostream& operator<<(const long);
    virtual Gbostream& operator<<(const double);
    virtual Gbostream& operator<<(const long long);
    virtual Gbostream& operator<<(const string&);

    virtual Gbostream& operator<<(const char*);

    virtual Gbistream& copyStr(char*, size_t);
    virtual Gbostream& addStr(const char*, size_t);
    virtual void set_error();

    virtual void clear();
    virtual bool isFail();
    virtual bool isGood();

    virtual void operator=(const Gbiostream&);

    operator string&();
    operator const string&();

    const string& getData() { return _data; }
    void putData(const string& str) { _data = str; _idx = 0; }

private:
    bit_vector _err;
    int _idx;
    string _data;
};

template < class T>
Gbistream& operator>>(Gbistream& bistr, T& t)
{   
    Gbiostream* p = (Gbiostream*)(&bistr);
    string bf = p->operator const string&();
    bf.erase(0, p->getidx()+(sizeof(size_t)+strlen(typeid(string).name())+1+4));
    t.operator=(bf);
    return bistr;
}

#endif
