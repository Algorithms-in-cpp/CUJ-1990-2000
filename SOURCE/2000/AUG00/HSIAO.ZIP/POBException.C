
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   24-Aug-1999

*/

#include "POBException.h"

#include <stddef.h>

extern int errno;

#include <string.h>

ostream&
operator<<(ostream& os, const POBException& excp)
{
    if(excp._message.c_str() == NULL || *(excp._message.c_str()) == '\0')
        return os << perst_err_msg[excp._id];
    else
        return os << excp._message.c_str() << ":" << perst_err_msg[excp._id];
}

ostream&
operator<<(ostream& os, const BTreeException& excp)
{
    if(excp._message.c_str() == NULL || *(excp._message.c_str()) == '\0')
        return os << perst_err_msg[excp._id];
    else
        return os << excp._message.c_str() << ":" << perst_err_msg[excp._id];
}

ostream&
operator<<(ostream& os, const objAvlException& excp)
{
    if(excp._message.c_str() == NULL || *(excp._message.c_str()) == '\0')
        return os << perst_err_msg[excp._id];
    else
        return os << excp._message.c_str() << ":" << perst_err_msg[excp._id];
}

void Exception::make_msg(const string& m)
{
    if( m.c_str() != NULL || *(m.c_str()) != '\0')
    {
        _message  = "[";
    	_message += m + "]";
        char* p = strerror(errno);
        if(p != NULL) {
    		_message += ":";
    		_message += p;
    	}
    }
}

POBException::POBException(int err, string m)
{
    _id = err;
    make_msg(m);
}

BTreeException::BTreeException(int err, string m)
{
    _id = err;
    make_msg(m);
}

objAvlException::objAvlException(int err, string m)
{
    _id = err;
    make_msg(m);
}
