/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

*/

#include <stdlib.h>

#include "POBroker.h"
#include "example.h"


int main()
{
    POBroker<POBObj> pob("TEST.DAT");

    pob.register_create_function(typeid(ABC).name(), ABC::create);

    ABC abc;

    abc.set_size(11);
    abc.set_price(19.99);
    abc.set_name("Hammer");
    abc.set_desp("Made in USA");
    unsigned long oi = pob.writeObj(abc);
    cout << "oi=" << oi << endl;

    if(pob.findObj(oi)) {
        ABC* pabc = (ABC*)pob.readObj(oi);
        pabc->set_price(35.75);
        pabc->set_name("Light Hammer");
        pob.modifyObj(pabc);
        pob.POB_DEL_REF(pabc);
    }
    else cout << "Not found" << endl;
 
    if(pob.findObj(oi)) {
        ABC* pabc = (ABC*)pob.readObj(oi);
        cout << pabc->size() << endl;
        cout << pabc->price() << endl;
        cout << pabc->name() << endl;
        cout << pabc->desp() << endl;
        pob.POB_DEL_REF(pabc);
    }
    else cout << "Not found" << endl;

    return 0;
}
