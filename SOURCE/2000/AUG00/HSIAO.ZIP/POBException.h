
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   24-Aug-1999

*/

#ifndef POBEXCEPTION_H
#define POBEXCEPTION_H

#include <iostream.h>

#include <string>

static char* perst_err_msg[] = {
    "FILE_OPEN_ERROR",
    "FILE_SIZE_WRITE_ERROR",
    "FILE_DATA_WRITE_ERROR",
    "FILE_SIZE_READ_ERROR",
    "FILE_DATA_READ_ERROR",
    "FILE_READ_SEEK_ERROR",
    "FILE_WRITE_SEEK_ERROR",
    "FILE_OI_WRITE_ERROR",
    "FILE_OBJ_WRITE_ERROR",
    "FILE_TYPE_WRITE_ERROR",
    "FILE_DEL_WRITE_ERROR",
    "FILE_OFFSET_NOT_MATCH",
    "NO_CLASS_TYPE_ID_ERROR",
    "NO_CLASS_CREATION_FUNC_ERROR",
    "NO_OBJ_FOR_CHANGE",
    "INVALID_ARGUMENTS",
    "INSERT_OBJ_ERROR",
    "OBJ_POSITION_NOT_MATCH",
    "NODE_KEY_NOT_MATCH",
    "INVALID_KEY_COUNT",
    "NODE_NOT_FOUND",
    "OBJ_ID_NOT_MATCH"
};

class Exception {
public:
    enum {
        FILE_OPEN_ERROR,
        FILE_SIZE_WRITE_ERROR,
        FILE_DATA_WRITE_ERROR,
        FILE_SIZE_READ_ERROR,
        FILE_DATA_READ_ERROR,
        FILE_READ_SEEK_ERROR,
        FILE_WRITE_SEEK_ERROR,
    	FILE_OI_WRITE_ERROR,
    	FILE_OBJ_WRITE_ERROR,
        FILE_TYPE_WRITE_ERROR,
        FILE_DEL_WRITE_ERROR,
    	FILE_OFFSET_NOT_MATCH,
        NO_CLASS_TYPE_ID_ERROR,
        NO_CLASS_CREATION_FUNC_ERROR,
    	NO_OBJ_FOR_CHANGE,
        INVALID_ARGUMENTS,
        INSERT_OBJ_ERROR,
    	OBJ_POSITION_NOT_MATCH,
        NODE_KEY_NOT_MATCH,
        INVALID_KEY_COUNT,
    	NODE_NOT_FOUND,
    	OBJ_ID_NOT_MATCH
    };
    virtual ~Exception(){};
    virtual void make_msg(const string&);

    int _id;
    string _message;
};

class POBException : public Exception
{
    friend ostream& operator<<(ostream&, const POBException&);
public:
    POBException(){};
    POBException(int err, string m=""); 
};

class BTreeException : public POBException
{
    friend ostream& operator<<(ostream&, const BTreeException&);
public:
    BTreeException(int err, string m="");
};

class objAvlException : public POBException
{
    friend ostream& operator<<(ostream&, const objAvlException&);
public:
    objAvlException(int err, string m="");
};

#endif
