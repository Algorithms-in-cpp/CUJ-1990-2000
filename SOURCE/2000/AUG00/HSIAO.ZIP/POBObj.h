
/*
    Copyright (c) 1999, Gary yiHsiang Hsiao. All Rights Reserved.

    bugs report to:ghsiao@rbcds.com or ghsiao@netzero.com

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   05-Sep-1999

*/

#ifndef POBOBJ_H
#define POBOBJ_H

#include "Gbiostream.h"

class POBObj : public Gbiostream {
public:

    virtual ~POBObj(){};

    virtual operator const string& () = 0;
    virtual void operator=(const string&) = 0;

};

#endif 
