
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bug report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   10-May-1999

*/

#ifndef POBROKER_H
#define POBROKER_H

#include <sys/stat.h>

#include <map>
#include <vector>

#include "POBbase.h"
#include "Gbiostream.h"

template<class T>
class POBroker : public POBbase<class T>
{
public:

    POBroker();
    POBroker(const char*);

    POBbase<T>::OBJ_ID  writeObj(const T&) throw (POBException*);
    T*                                  readObj(POBbase<T>::OBJ_ID) throw (POBException*);
    POBbase<T>::OBJ_ID  readObj(T*&) throw (POBException*);
    bool                                findObj(POBbase<T>::OBJ_ID);
    POBbase<T>::OBJ_ID  modifyObj(T*) throw (POBException*);
    bool                deleteObj(POBbase<T>::OBJ_ID, T*&) throw (POBException*);
    
};

template<class T> 
POBroker<T>::POBroker()
{
}

template<class T> 
POBroker<T>::POBroker(const char* fn)
    : POBbase(fn)
{
}

template<class T> 
bool POBroker<T>::findObj(POBbase<T>::OBJ_ID oi)
{
    streampos loc;
    return POBbase<T>::findObj(loc, oi);
}

template<class T> 
POBbase<T>::OBJ_ID POBroker<T>::writeObj(const T& t)
    throw (POBException*)
{
    POBbase<T>::OBJ_ID oi = insertObj(t);
    
    return oi;
}

template<class T> 
T* POBroker<T>::readObj(POBbase<T>::OBJ_ID oi)
    throw (POBException*)
{
    T* t;

    //*-----------------------------------
    //* random read
    //*-----------------------------------
    streampos loc;
    if(POBbase<T>::findObj(loc, oi)) {
        int sz;
        POBbase<T>::read(POBbase<T>::RANDOM, sz, loc, t);
        POBbase<T>::add2map((long)t, oi, loc, sz);
        return t;
    }
    return NULL;
}

template<class T>
POBbase<T>::OBJ_ID POBroker<T>::readObj(T*& t)
    throw (POBException*)
{
    int sz;
    //*-----------------------------------
    //* sequential read
    //*-----------------------------------
    streampos loc;
    POBbase<T>::OBJ_ID oi = POBbase<T>::read(POBbase<T>::SEQUENCE, sz, loc, t);
    if(oi)
    {
        POBbase<T>::add2map((long)t, oi, loc, sz);
    }
    return oi;
}

template<class T> 
POBbase<T>::OBJ_ID  POBroker<T>::modifyObj(T* t) 
    throw (POBException*)
{
    return POBbase<T>::changeObj(t);
}

template<class T> 
bool  POBroker<T>::deleteObj(POBbase<T>::OBJ_ID oi, T*& t)
    throw (POBException*)
{
    return POBbase<T>::removeObj(oi, t);
}

#endif 
