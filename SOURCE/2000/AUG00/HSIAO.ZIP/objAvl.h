
/*
    Copyright (c) 1999, Gary YiHsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   05-Sep-1999

*/

#ifndef OBJAVL_H
#define OBJAVL_H

#include "POBObj.h"

#include <deque>

class objAvl : public POBObj {
    friend ostream& operator<<(ostream&, objAvl&);

public:
    typedef pair<size_t, streampos> SIZE_POS;

    objAvl();
    ~objAvl();
    objAvl& operator=(const objAvl&);

    static POBObj* create() { return (POBObj*)(new objAvl); }
    operator const string& ();
    void operator=(const string&);

    bool   isEmpty();
    bool   getAvl(size_t, streampos&);
    void   addAvl(size_t, streampos);
    void   removepad();
    bool   isEmptySlot(streampos, size_t&);
    size_t spaceRecollection();
    size_t deqsize();
    
private:
    void getpos(int, int size, streampos&);
    bool deque_best_bsearch(size_t, size_t&);
    void swap(int, int);
    void sort_by_pos(int, int);
    void sort_by_size(int, int);

private:
    const size_t _max;
    size_t _acc_size;
    int       _pad_size;
    deque<SIZE_POS> _avl;
};

#endif 
