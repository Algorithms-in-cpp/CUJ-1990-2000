
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

*/

#include "POBroker.h"

class ABC : public POBObj
{
public:
    static POBObj* create() { return (POBObj*) new ABC; }
    ABC(){};

    operator const string& ();
    void operator=(const string&);

    void set_price(double);
    void set_size(int);
    void set_desp(string);
    void set_name(string);

    double price() { return _price; }
    int    size() { return _size; }
    const char* desp() { return _desp.c_str(); }
    const char* name() { return _name.c_str(); }

private:
    int _size;
    string _name;
    double _price;
    string _desp;
};

