
/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

    Release: 1.0   02-Aug-1999

*/

#ifndef GBOSTREAM_H
#define GBOSTREAM_H

#include <stdlib.h>
#include <typeinfo>

#include <string>
#include <deque>
#include <stack>
#include <slist>
#include <list>
#include <map>
#include <queue>
#include <vector>
#include <set>
#include <hash_set>
#include <hash_map>

class Gbostream {
public:
    virtual Gbostream& put(const bool)=0;
    virtual Gbostream& put(const char)=0;
    virtual Gbostream& put(const unsigned)=0;
    virtual Gbostream& put(const short)=0;
    virtual Gbostream& put(const int)=0;
    virtual Gbostream& put(const long)=0;
    virtual Gbostream& put(const double)=0;
    virtual Gbostream& put(const long long)=0;
    virtual Gbostream& putString(const string&)=0;

    virtual Gbostream& put(const char*)=0;
    virtual Gbostream& put(const bool*, size_t)=0;
    virtual Gbostream& put(const unsigned*, size_t)=0;
    virtual Gbostream& put(const short*, size_t)=0;
    virtual Gbostream& put(const int*, size_t)=0;
    virtual Gbostream& put(const long*, size_t)=0;
    virtual Gbostream& put(const double*, size_t)=0;
    virtual Gbostream& put(const long long*, size_t)=0;

    virtual Gbostream& operator<<(const bool)=0;
    virtual Gbostream& operator<<(const char)=0;
    virtual Gbostream& operator<<(const unsigned)=0;
    virtual Gbostream& operator<<(const short)=0;
    virtual Gbostream& operator<<(const int)=0;
    virtual Gbostream& operator<<(const long)=0;
    virtual Gbostream& operator<<(const double)=0;
    virtual Gbostream& operator<<(const long long)=0;
    virtual Gbostream& operator<<(const string&)=0;
    virtual Gbostream& operator<<(const char*)=0;

};

template < class T, class A >
Gbostream& operator<<(Gbostream& bostr, const deque<T, A>& dque)
{
    size_t size = dque.size();
    bostr << size;
    if(size > 0) {
        for(int i = 0; i < size; i++) {
            bostr << dque[i];
    	}
    }
    return bostr;
}

template <class T, class S>
Gbostream& operator<<(Gbostream& bostr, const stack<T, S>& stk)
{
    size_t size = stk.size();
    bostr << size;
    if(size > 0) {
    	stack<T, S> tmp(stk);
        for(int i=0; i < size; i++) {
    	    bostr << tmp.top();
    		tmp.pop();
    	}
    }
    return bostr;
}

template <class T, class A> 
Gbostream& operator<<(Gbostream& bostr, const slist<T, A>& list)
{
    size_t size = list.size();
    bostr << size;
    if(size > 0) {
    	slist<T, A>::const_iterator itr = list.begin();
        while(itr != list.end()) 
    		bostr << *itr++;
    }	
    return bostr;
}

template <class T, class A> 
Gbostream& operator<<(Gbostream& bostr, const list<T, A>& lst)
{
    size_t size = lst.size();
    bostr << size;
    if(size > 0) {
        list<T, A>::const_iterator itr = lst.begin();
        while(itr != lst.end())
    		bostr << *itr++;
    }
    return bostr;
}

template <class K, class V, class C, class A> 
Gbostream& operator<<(Gbostream& bostr, const map<K, V, C, A>& mp)
{
    size_t size = mp.size();
    bostr << size;
    if(size > 0) {
        map<K, V, C, A>::const_iterator itr = mp.begin();
    	while(itr != mp.end()) {
            bostr << (*itr).first;
    		bostr << (*itr).second;
    		++itr;
        }
    }
    return bostr;
}

template <class T, class S>
Gbostream& operator<<(Gbostream& bostr, const queue<T, S>& Q)
{
    size_t size = Q.size();
    bostr << size;
    if(size > 0)  {
    	queue<T, S> tmpQ(Q);
    	for(int i=0; i < size; i++) {
    	    T t;
    	    t = tmpQ.front();
    		bostr << t;
    		tmpQ.pop();
        }
    }
    return bostr;
}

template <class T, class S, class C> 
Gbostream& operator<<(Gbostream& bostr, const priority_queue<T, S, C>& Q)
{
    size_t size = Q.size();
    bostr << size;
    if(size > 0) {
        priority_queue<T, S, C> tmpQ(Q); 
    	for(int i=0; i < size; i++) {
            T t;
            t = tmpQ.top();
            bostr << t;
            tmpQ.pop();
        }
    }
    return bostr;
}

template <class T, class A>
Gbostream& operator<<(Gbostream& bostr, const vector<T, A>& V)
{
    size_t size = V.size();
    bostr << size;
    if(size > 0) {
    	vector<T, A>::const_iterator itr = V.begin();
        while(itr != V.end())
    	    bostr << *itr++;
    }
    return bostr;
}

template <class K, class C, class A> 
Gbostream& operator<<(Gbostream& bostr, const set<K, C, A>& S)
{
    size_t size = S.size();
    bostr << size;
    if(size > 0) {
        set<K, C, A>::const_iterator itr = S.begin();
    	while(itr != S.end())
    		bostr << *itr++;
    }
    return bostr;
}

template <class K, class C, class A>
Gbostream& operator<<(Gbostream& bostr, const multiset<K, C, A>& S)
{
    size_t size = S.size();
    bostr << size;
    if(size > 0) {
        multiset<K, C, A>::const_iterator itr = S.begin();
        while(itr != S.end())
            bostr << *itr++;
    }
    return bostr;
}

template <class K, class H, class E, class A> 
Gbostream& operator<<(Gbostream& bostr, const hash_multiset<K, H, E, A>& S)
{
    size_t size = S.size();
    bostr << size;
    if(size > 0) {
        hash_multiset<K, H, E, A>::const_iterator itr = S.begin();
        while(itr != S.end())
            bostr << *itr++;
    }
    return bostr;
}

template <class K, class V, class C, class A>
Gbostream& operator<<(Gbostream& bostr, const multimap<K, V, C, A>& mp)
{
    size_t size = mp.size();
    bostr << size;
    if(size > 0) {
        multimap<K, V, C, A>::const_iterator itr = mp.begin();
        while(itr != mp.end()) {
            bostr << (*itr).first;
            bostr << (*itr).second;
            ++itr;
        }
    }
    return bostr;
}

template <class K, class V, class H, class E, class A>
Gbostream& operator<<(Gbostream& bostr, const hash_multimap<K, V, H, E, A>& mp)
{
    size_t size = mp.size();
    bostr << size;
    if(size > 0) {
        hash_multimap<K, V, H, E, A>::const_iterator itr = mp.begin();
        while(itr != mp.end()) {
            bostr << (*itr).first;
            bostr << (*itr).second;
            ++itr;
        }
    }
    return bostr;
}

template <class K, class V, class H, class E, class A>
Gbostream& operator<<(Gbostream& bostr, const hash_map<K, V, H, E, A>& mp)
{
    size_t size = mp.size();
    bostr << size;
    if(size > 0) {
        hash_map<K, V, H, E, A>::const_iterator itr = mp.begin();
        while(itr != mp.end()) {
            bostr << (*itr).first;
            bostr << (*itr).second;
            ++itr;
        }
    }
    return bostr;
}

template <class T1, class T2>
Gbostream& operator<<(Gbostream& bostr, const pair<T1, T2>& P)
{
    bostr << P.first;
    bostr << P.second;

    return bostr;
}

#endif
