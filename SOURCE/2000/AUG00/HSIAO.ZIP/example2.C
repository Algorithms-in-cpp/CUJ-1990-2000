/*
    Copyright (c) 1999, Gary Yihsiang Hsiao. All Rights Reserved.

    bugs report to: ghsiao@rbcds.com or ghsiao@netzero.net

    Permission to use, copy, modify, and distribute this software
    for NON-COMMERCIAL purposes and without fee
    is hereby granted provided that this copyright notice
    appears in all copies. This software is distributed on an 'as is'
    basis without warranty.

*/

#include <stdlib.h>

#include "POBroker.h"
#include "example.h"


int main(int argc, char* argv[])
{
    if(argc <= 1) return 0;

    POBroker<POBObj> pob("TEST.DAT");

    pob.register_create_function(typeid(ABC).name(), ABC::create);

    unsigned long oi = atol(argv[1]);

    if(pob.findObj(oi)) {
        POBObj* pobj;
        ABC* pabc;
        try {
           if(pob.deleteObj(oi, pobj)) {
               pabc = (ABC*)pobj;
               cout << "delete object:" << endl;
               cout << pabc->size() << endl;
               cout << pabc->price() << endl;
               cout << pabc->desp() << endl;
               cout << pabc->name() << endl;
               pob.POB_DEL_REF(pobj);
    	   }
    	} catch(POBException* e) {
           cout << *e << endl;
        }
    }
    else cout << "Not found" << endl;
 
    return 0;
}
