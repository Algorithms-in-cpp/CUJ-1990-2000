class CWindow
{
public:
    CWindow();
    HWND Create(int x, int y, int nWidth, int nHeight,
            HWND hParent, HMENU hMenu, HINSTANCE hInstance);

    HWND _hwnd;

protected:
    static LRESULT CALLBACK BaseWndProc(HWND hwnd, UINT msg,
        WPARAM wParam, LPARAM lParam);
    
    virtual LRESULT WindowProc(HWND hwnd, UINT msg,
        WPARAM wParam, LPARAM lParam, PBOOL pbProcessed);

    WNDCLASSEX _WndClass;
    DWORD _dwExtendedStyle;
    DWORD _dwStyle;
    LPSTR _pszClassName;
    LPSTR _pszTitle;
};  

class CMainWindow : public CWindow
{
public: 
    CMainWindow();
};

class CChildWindow : public CMainWindow
{
public:
    CChildWindow();

protected:
    virtual LRESULT WindowProc(HWND hwnd, UINT msg,
        WPARAM wParam, LPARAM lParam, PBOOL pbProcessed);

    virtual void OnDestroy(HWND hwnd);
    virtual void OnPaint(HWND hwnd);
};

