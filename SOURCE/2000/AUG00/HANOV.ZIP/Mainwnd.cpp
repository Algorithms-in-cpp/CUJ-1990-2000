#include <windows.h>
#include <windowsx.h>
#include "WndObj.h"

CMainWindow::CMainWindow()
{
    //Override class name and style attributes.
    _pszClassName = "CMainWindow";
    _pszTitle = "My Window";
    _dwStyle = WS_OVERLAPPEDWINDOW | WS_VISIBLE;
    _WndClass.style |= CS_HREDRAW | CS_VREDRAW;
}

CChildWindow::CChildWindow()
{
    //Override class name and style attributes.
    _pszClassName = "CChildWindow";
    _dwStyle |= WS_CHILD;
}

LRESULT CChildWindow::WindowProc(HWND hwnd, UINT msg,
      WPARAM wParam, LPARAM lParam, PBOOL pbProcessed)
{
    //call base class first.
    LRESULT lResult = CMainWindow::WindowProc(hwnd, msg, wParam,
        lParam, pbProcessed);
    BOOL bWasProcessed = *pbProcessed;
    *pbProcessed = TRUE;

    switch(msg)
    {
        HANDLE_MSG(hwnd, WM_DESTROY, OnDestroy);
        HANDLE_MSG(hwnd, WM_PAINT, OnPaint);

    default:
        //We did not process the message.
        //Indicate whether the base class's handler did.
        *pbProcessed = bWasProcessed;
        return lResult;
    }
}

void CChildWindow::OnDestroy(HWND hwnd)
{
    PostQuitMessage(0);
}

void CChildWindow::OnPaint(HWND hwnd)
{
    RECT rect;
    HDC hDC = GetDC(hwnd);
    PAINTSTRUCT PaintStruct;
    BeginPaint(hwnd, &PaintStruct);
    GetClientRect(hwnd, &rect);
    DrawText(hDC, "Hello, Object-Oriented World!", 29, &rect,
             DT_VCENTER | DT_CENTER | DT_SINGLELINE);
    EndPaint(hwnd, &PaintStruct);
    ReleaseDC(hwnd, hDC);
}
