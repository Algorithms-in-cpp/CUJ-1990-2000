#include <windows.h>
#include "WndObj.h"

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInst,
                   LPSTR lpszCmdLine, int nCmdShow)
{
    CMainWindow MainWindow;
    CChildWindow ChildWindow;

    //Create the window objects.
    if(NULL == MainWindow.Create(CW_USEDEFAULT, CW_USEDEFAULT,
        CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance))
        return FALSE;
    
    if(NULL == ChildWindow.Create(CW_USEDEFAULT, CW_USEDEFAULT,
        350, 100, MainWindow._hwnd, NULL, hInstance))
        return FALSE;

    MSG Msg; 
    while(GetMessage(&Msg, NULL, 0, 0))
      DispatchMessage(&Msg);

    return Msg.wParam;
}
