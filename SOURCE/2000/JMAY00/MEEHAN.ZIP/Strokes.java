import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.BasicStroke;
import java.awt.geom.Line2D;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Strokes extends JPanel {

    RenderingHints hint= new RenderingHints(RenderingHints.KEY_ANTIALIASING,
					    RenderingHints.VALUE_ANTIALIAS_ON);

    Stroke wideStroke =  new BasicStroke(10.f);
    Stroke wideRoundCapStroke = 
	new BasicStroke(10.f, // width
			BasicStroke.CAP_ROUND, // cap style
			BasicStroke.JOIN_MITER); // join style
    Stroke dashStroke = 
	new BasicStroke(3.f, // width
			BasicStroke.CAP_SQUARE, // cap style
			BasicStroke.JOIN_MITER, // join style
			1.0f, // percentage of mitre drawn
			// dashes are defined by an array of floats indicating
			// a sequence of pen-down pen-up operations. Here the
			// pen is down for 8 pixels then up for 8 pixels,
			// creating an even dash pattern
			new float[]{ 8f,8f }, 
			1.f);
    Stroke dashDotStroke = 
	new BasicStroke(3.f, // width
			BasicStroke.CAP_BUTT, // cap style
			BasicStroke.JOIN_MITER, // join style
			1.0f, // percentage of mitre drawn
			// dashes are defined by an array of floats indicating
			// a sequence of pen-down pen-up operations. Here the
			// pen is down for 5 pixels, up for 2 pixels, down for
			// 2 pixels then up for 2 pixels, creating a dash-dot
			// pattern
			new float[]{ 5f,2f,2f,2f },
			1.f);


    public Strokes() {
	super();
	setBackground(Color.black);
    }

    /**
     * Demonstrate strokes by drawing a number of lines, each with a 
     * different stroke.
     */
    protected void paintComponent(Graphics g) {
	super.paintComponent(g); 
	Graphics2D g2 = (Graphics2D) g; 
	g2.addRenderingHints(hint);
	g2.setColor(Color.white); // line color
	g2.setStroke(wideStroke);
	g2.draw(new Line2D.Double(40f,20f,100f,20f));
	g2.setStroke(wideRoundCapStroke);
	g2.draw(new Line2D.Double(40f,40f,100f,40f));
	g2.setStroke(dashStroke);
	g2.draw(new Line2D.Double(40f,60f,100f,60f));
	g2.setStroke(dashDotStroke);
	g2.draw(new Line2D.Double(40f,80f,100f,80f));
    }

    public static void main(String args[]) {
	JFrame frame = new JFrame("Strokes");
	frame.getContentPane().add(new Strokes());
	frame.pack();
	frame.setSize(new Dimension(150,120));
	frame.show();
    }
}
