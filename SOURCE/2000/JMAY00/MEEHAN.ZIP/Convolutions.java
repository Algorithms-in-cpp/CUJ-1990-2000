import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.geom.Arc2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.PixelGrabber;
import java.awt.image.Kernel;
import java.awt.image.ConvolveOp;
import javax.swing.JFrame;
import javax.swing.JPanel;


/**
 * Use convolutions to illustrate sharpening and blurring of images.
 */
public class Convolutions extends JPanel {

    RenderingHints hint= new RenderingHints(RenderingHints.KEY_ANTIALIASING,
					    RenderingHints.VALUE_ANTIALIAS_ON);

    /*
     * Used to store an in-memory copy of the image
     */
    BufferedImage origImage, sharpImage, blurImage;

    /*
     * The texture paint
     */
    Paint woodPaint;


    BufferedImage getOriginalImage() {
	/*
	 * Get the original image file
	 */
	Image woodImage = Toolkit.getDefaultToolkit().createImage("wood.jpg");
	/*
	 * Use pixel grabber to get  the image pixels
	 */
	int w,h;
	PixelGrabber grabber = new PixelGrabber(woodImage,0,0,-1,-1,true);
	try {
	    grabber.grabPixels();
        } catch (InterruptedException e) {
            System.err.println("interrupted waiting for pixels!");
            return null;
        }
        if ((grabber.getStatus() & ImageObserver.ABORT) != 0) {
            System.err.println("Aborted!");
            return null;
        }
	w = grabber.getWidth();
	h = grabber.getHeight();
	BufferedImage bi = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
	bi.setRGB(0,0,grabber.getWidth(),grabber.getHeight(),
		  (int[])grabber.getPixels(),0,grabber.getWidth());

	return bi;
    }
				
    BufferedImage sharpen(BufferedImage src) {

	/*
	 * Define a kernel  that accentuates the current pixel
	 * and reduces the effect of surrounding pixels
	 */
	float elements[] = { -.5f,-.5f,-.5f,
			     -.5f,5.f,-.5f,
			     -.5f,-.5f,-.5f
	};

	/*
	 * Build the kernel from its definition
	 */
	Kernel kernel = new Kernel(3,3,elements);
	/*
	 * Build a convolution operator based on the kernel
	 */
	ConvolveOp op = new ConvolveOp(kernel,ConvolveOp.EDGE_NO_OP,null);
	/*
	 * Filter the source image using the operator
	 */
	return op.filter(src,null);
    }

    BufferedImage blur(BufferedImage src) {

	/*
	 * Define a kernel that replaces a pixel by the average of it and its
	 * surrounding 15 pixels.
	 */
	float avg = 1f/16f;
  	float elements[] = { avg,avg,avg,avg,
			     avg,avg,avg,avg,
			     avg,avg,avg,avg,
			     avg,avg,avg,avg,
  	};


	/*
	 * Build the kernel from its definition
	 */
	Kernel kernel = new Kernel(4,4,elements);
	/*
	 * Build a convolution operator based on the kernel
	 */
	ConvolveOp op = new ConvolveOp(kernel,ConvolveOp.EDGE_NO_OP,null);
	/*
	 * Filter the source image using the operator
	 */
	return op.filter(src,null);
    }

    public Convolutions() {
	super();
	origImage = getOriginalImage(); 
	sharpImage = sharpen(origImage);
	blurImage = blur(origImage);
    }

    /**
     * Display the original, sharpened and blurred images.
     */
    protected void paintComponent(Graphics g) {
	super.paintComponent(g); 
	Graphics2D g2 = (Graphics2D) g; 
	g2.addRenderingHints(hint);
	
	g2.drawImage(sharpImage,null,10,10);
	g2.drawImage(origImage,null,110,10);
	g2.drawImage(blurImage,null,210,10);

    }

    public static void main(String args[]) {
	JFrame frame = new JFrame("Convolutions");
	frame.getContentPane().add(new Convolutions());
	frame.pack();
	frame.setSize(new Dimension(320,150));
	frame.show();
    }
}
