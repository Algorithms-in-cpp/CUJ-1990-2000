import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Gradients extends JPanel {

    RenderingHints hint= new RenderingHints(RenderingHints.KEY_ANTIALIASING,
					    RenderingHints.VALUE_ANTIALIAS_ON);

    /*
     * Build a linear paint along the x axis
     */
    Paint linearGradient = new GradientPaint(10,0,Color.green,90,0,Color.red);
    /*
     * Build a cyclic paint along a 45 degree axis
     */
    Paint cyclicGradient = new GradientPaint(100,10,Color.green,
					     120,30,Color.red,
					     true);

    public Gradients() {
	super();
	setBackground(Color.black);
    }

    /**
     * Demonstrate Gradients 
     */
    protected void paintComponent(Graphics g) {
	super.paintComponent(g); 
	Graphics2D g2 = (Graphics2D) g; 
	g2.setPaint(linearGradient);
	g2.fill(new Rectangle2D.Double(10.,10.,80.,80.));
	g2.setPaint(cyclicGradient);
	g2.fill(new Rectangle2D.Double(100.,10.,80.,80.));
    }

    public static void main(String args[]) {
	JFrame frame = new JFrame("Gradients");
	frame.getContentPane().add(new Gradients());
	frame.pack();
	frame.setSize(new Dimension(200,120));
	frame.show();
    }
}
