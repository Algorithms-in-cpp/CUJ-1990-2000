import java.awt.BasicStroke;
import java.awt.RenderingHints;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.geom.Arc2D;
import javax.swing.JFrame;
import javax.swing.JPanel;


/**
 * Demonstrate anti aliasing
 */
public class Antialias extends JPanel {

    public Antialias() {
	super();
    }

    /**
     * Compare aliased and antialiased lines
     *
     */
    protected void paintComponent(Graphics g) {
	super.paintComponent(g); 
	Graphics2D g2 = (Graphics2D) g;

	g2.setStroke(new BasicStroke(2)); // 2 pixel wide lines
	g2.setPaint(Color.blue); // set context to draw with blue paint
	
	// draw a circle with anti-aliasing inactive
	g2.draw(new Arc2D.Double(10,10,50,50,0,360,Arc2D.CHORD));
	
	// activate anti-aliasing
	RenderingHints hint = 
	    new RenderingHints(RenderingHints.KEY_ANTIALIASING,
			       RenderingHints.VALUE_ANTIALIAS_ON);
	g2.addRenderingHints(hint);
	// draw a circle with anti-aliasing active
	g2.draw(new Arc2D.Double(70,10,50,50,0,360,Arc2D.CHORD));

    }

    public static void main(String args[]) {
	JFrame frame = new JFrame("Antialiasing");
	frame.getContentPane().add(new Antialias());
	frame.pack();
	frame.setSize(new Dimension(140,90));
	frame.show();
    }
}
