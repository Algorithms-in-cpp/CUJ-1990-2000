import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.RenderingHints;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Shamrock extends JPanel {

    GeneralPath path = new GeneralPath();
    RenderingHints renderHints = new RenderingHints(RenderingHints.KEY_ANTIALIASING,
						    RenderingHints.VALUE_ANTIALIAS_ON);
    public Shamrock() {
	super();
	setBackground(Color.black);

	/*
	 * Construct a shamrock
	 */
	path.moveTo(60f,80f); // start point
	path.quadTo(70f,70f,73f,60f); // left side of stem
	path.curveTo(30f,100f,30f,10f,70f,50f); // left leaf
	path.curveTo(30f,10f,120f,10f,80f,50f); // top leaf
	path.curveTo(120f,10f,120f,100f,77f,60f); // right leaf
	path.quadTo(75f,70f,63f,83f); // right side of stem
	path.closePath(); // base of stem
    }

    /**
     * Demonstrate the general path
     *
     */
    protected void paintComponent(Graphics g) {
	super.paintComponent(g); // do this to ensure background is cleared
	Graphics2D g2 = (Graphics2D) g; // get Java2D graphics context
	g2.addRenderingHints(renderHints);
	g2.setPaint(Color.green); // fill with green
	g2.fill(path); // fill shape
    }

    public static void main(String args[]) {
	JFrame frame = new JFrame("Shamrock");
	frame.getContentPane().add(new Shamrock());
	frame.pack();
	frame.setSize(new Dimension(150,150));
	frame.show();
    }
}
