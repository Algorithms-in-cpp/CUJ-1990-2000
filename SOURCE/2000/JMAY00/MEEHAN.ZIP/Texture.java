import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.TexturePaint;
import java.awt.Toolkit;
import java.awt.geom.Arc2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.PixelGrabber;
import javax.swing.JFrame;
import javax.swing.JPanel;


/**
 * Create a texture paint from an existing image file and
 * use it to fill a shape
 */
public class Texture extends JPanel {

    RenderingHints hint= new RenderingHints(RenderingHints.KEY_ANTIALIASING,
					    RenderingHints.VALUE_ANTIALIAS_ON);

    /*
     * Used to store an in-memory copy of the image
     */
    BufferedImage woodTexture; 
    /*
     * Get the texture image file
     */
    Image woodImage = Toolkit.getDefaultToolkit().createImage("wood.jpg");
    /*
     * The texture paint
     */
    Paint woodPaint;

    /**
     * Copy the image to the buffered image, then create the texture paint
     */
    void buildTexture() {
	int w,h;
	/*
	 * Grab pixels from the woodImage
	 */
	PixelGrabber grabber = new PixelGrabber(woodImage,0,0,-1,-1,true);
	try {
	    grabber.grabPixels();
        } catch (InterruptedException e) {
            System.err.println("interrupted waiting for pixels!");
            return;
        }
        if ((grabber.getStatus() & ImageObserver.ABORT) != 0) {
            System.err.println("Aborted!");
            return;
        }
	/*
	 * Now that the pixels are stored in memory write them to the
	 * buffered image object
	 */
	w = grabber.getWidth();
	h = grabber.getHeight();
	woodTexture = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
	woodTexture.setRGB(0,0,grabber.getWidth(),grabber.getHeight(),
			   (int[])grabber.getPixels(),0,grabber.getWidth());

	/*
	 * The anchor is a rectangle defining the tile used to replicate
	 * the texture in user space
	 */
	Rectangle2D anchor = new Rectangle2D.Double(20.,
						    20.,
						    grabber.getWidth()/2,
						    grabber.getHeight()/2);
	/*
	 * Create the texture paint from the buffered image
	 */
	woodPaint = new TexturePaint(woodTexture,anchor);
    }

    public Texture() {
	super();
	buildTexture();
    }

    /**
     * Demonstrate texture paint
     */
    protected void paintComponent(Graphics g) {
	super.paintComponent(g); 
	Graphics2D g2 = (Graphics2D) g; 
	g2.addRenderingHints(hint);
	
	/*
	 * Use the texture paint to fill a circle
	 */
	g2.setPaint(woodPaint);
	g2.fill(new Arc2D.Double(20,20,100,100,0,360,Arc2D.PIE));
    }

    public static void main(String args[]) {
	JFrame frame = new JFrame("Texture");
	frame.getContentPane().add(new Texture());
	frame.pack();
	frame.setSize(new Dimension(140,160));
	frame.show();
    }
}
