import java.io.*;

public class SimpleTest2
{
    public static void main(String[] args)
    {
        SimpleBean bean = new SimpleBean();
        bean.setCount(33);
        try
        {
            FileOutputStream f = new FileOutputStream("SimpleBean.ser");
            ObjectOutputStream s = new ObjectOutputStream(f);
            s.writeObject(bean);
            s.flush();
        }
        catch (Exception e)
        {
            System.out.println(e);
        }        
    }
}

