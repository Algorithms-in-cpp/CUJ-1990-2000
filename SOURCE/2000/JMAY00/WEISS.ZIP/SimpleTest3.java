import java.beans.*;

public class SimpleTest3
{
    public static void main(String[] args)
    {
        try
        {
            SimpleBean bean = (SimpleBean) Beans.instantiate(null,"SimpleBean");
            int cnt = bean.getCount();
            System.out.println("Bean count = " + cnt);
        }
        catch (Exception e)
        {
            System.out.println(e.toString());
        }
    }
}
