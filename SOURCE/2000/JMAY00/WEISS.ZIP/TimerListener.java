package timerbean;

import java.util.*;

/**
 *
 * All users of the TimerBean must implement this interface
 *
 */
public interface TimerListener extends EventListener {
    /**
     *
     * Called whenever the timer is fired
     *
     */
    public void timerFired(TimerEvent evt);
}
