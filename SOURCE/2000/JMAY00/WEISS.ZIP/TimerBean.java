package timerbean;

import java.util.*;

public class TimerBean implements Runnable {
    private Thread runner;                  // the timer thread
    private static int theNumber;           // the timer number
    private volatile int theInterval;       // the event interval
    private int theCount;                   // the event counter
    private Vector listeners;               // all registered listeners
    private volatile boolean suspended;     
    private boolean firstTime;
    private boolean running = true;

    public TimerBean() {                    // default constructor
        this(++theNumber,1000);             // pass default values to 2 arg ctor
    }
    public TimerBean(int number, int interval) {
        theNumber = number;                 // save the timer number
        theInterval = interval;             // save the event interval
        theCount = 0;                       // save the event counter
        listeners = new Vector();
        suspended = true;
        firstTime = true;
        runner = new Thread(this);          // create the thread object
        runner.setDaemon(true);             // will kill thread if no user threads
    }

    public synchronized void addTimerListener(TimerListener l) {
        if (!listeners.contains(l)) {       // if the listener is not in list
            listeners.addElement(l);        // add it now
        }
    }

    public synchronized void removeTimerListener(TimerListener l) {
        if (listeners.contains(l)) {        // if the listener is in the list
            listeners.removeElement(l);     // remove it now
        }
    }
    /**
     *
     * Defines the read portion of the Interval property
     *
     */
    public synchronized int getInterval() {
        return theInterval;
    }
    /**
     *
     * Defines the write portion of the Interval property
     *
     */
    public synchronized void setInterval(int interval) {
        theInterval = interval;
    }
    /**
     *
     * Defines an alternate way to do the read portion
     * of a boolean property
     *
     */
    public synchronized boolean isSuspended() {
        return suspended;
    }
    /**
     *
     * Defines the write portion of the Suspended property 
     */
    public synchronized void setSuspended(boolean flag) {
        suspended = flag;
        if (!suspended) {
            notifyAll();
        }
    }
    /**
     *
     * A utility method to suspend the thread when requested
     *
     */
    private synchronized void checkIfSuspended() {
        if (suspended) {
            try {
                wait();                     // suspends the thread
            } catch (InterruptedException e) {
                System.out.println(e.toString());
            }
        }
    }
    public synchronized void init() {      // used to start up a timer
        if (firstTime) {
            runner.start();
            firstTime = false;
        }
        setSuspended(false);
    }
    /**
     *
     * Causes the thread to fall out of the bottom
     * of the run method, thereby terminating the thread
     *
     */
    public synchronized void destroy() {     // kills the timer
        running = false;
    }
    
    /**
     *
     * The heart of the thread
     *
     */
    public void run() {
        while (running) {
            checkIfSuspended();
            try {
                Thread.sleep(theInterval);  
                theCount++;
                notifyFired();
            } catch(InterruptedException e) {
                System.out.println(e);
            }
        }
    }

    /**
     *
     * Notify all listeners that an event occurred
     *
     */
    protected void notifyFired() {
        TimerEvent evt = new TimerEvent(this, theNumber, theCount);
        Vector v;
        synchronized(this) {
            v = (Vector) listeners.clone();
        }
        int cnt = v.size();
        for (int k=0;k<cnt;k++) {
            TimerListener client = (TimerListener) v.elementAt(k);
            client.timerFired(evt);
        }
    }
}
