public class SimpleBean implements java.io.Serializable
{
    private int counter;
    
    public int getCount()
    {
        return counter;
    }
    public void setCount(int count)
    {
        counter = count;
    }
}
