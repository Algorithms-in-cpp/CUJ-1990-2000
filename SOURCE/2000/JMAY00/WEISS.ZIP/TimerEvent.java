package timerbean;

import java.util.*;                         // for EventObject

public class TimerEvent extends EventObject {
    
    private int theTimer;                   // the unique identifier for a timer
    private int theCount;                   // the event number for a timer
    
    public TimerEvent(Object source, int timerNumber, int timerCount) {
        super(source);                      // pass source object to superclass
        theTimer = timerNumber;             // save the timer number
        theCount = timerCount;              // save the timer count
    }
    public int getTimerNumber() {           // get the timer number
        return theTimer;
    }
    public int getTimerCount()  {           // get the timer count
        return theCount;
    }
}
