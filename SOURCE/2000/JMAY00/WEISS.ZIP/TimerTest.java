import timerbean.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.beans.*;

public class TimerTest extends JFrame {
    private Container contentPane;
    private JLabel lblMessage;
    private JButton btnStart;
    private JButton btnStop;
    private TimerBean tb;
    
    public TimerTest() {
        contentPane = getContentPane();
        setTitle("Timer JavaBean Tester");
        setSize(300,200);
        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent evt) {
                System.exit(0);
            }
        });
        lblMessage = new JLabel("No timer is active", JLabel.CENTER);
        contentPane.setLayout(new BorderLayout());
        contentPane.add(lblMessage,BorderLayout.CENTER);
        JPanel s = new JPanel();
        s.setLayout(new FlowLayout());
        btnStart = new JButton("Start");
        btnStop = new JButton("Stop");
        btnStart.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent evt) {
                tb.setSuspended(false);
                btnStart.setEnabled(false);
                btnStop.setEnabled(true);
            }
        });
        btnStop.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent evt) {
                tb.setSuspended(true);
                btnStop.setEnabled(false);
                btnStart.setEnabled(true);
            }
        });
        s.add(btnStart);
        s.add(btnStop);
        contentPane.add(s,BorderLayout.SOUTH);
        btnStart.setEnabled(false);
        try {
            tb = (TimerBean) Beans.instantiate(null,"timerbean.MyTimerBean");
        } catch (Exception e) {
            System.out.println(e.toString());
            tb = new TimerBean();
        }
        tb.setInterval(500);
        tb.addTimerListener(new TimerListener()
        {
            public void timerFired(TimerEvent evt) {
                int count = evt.getTimerCount();
                int timer = evt.getTimerNumber();
                String str = "Timer " + timer + " count is " + count;
                lblMessage.setText(str);
            }
        });
        setVisible(true);
        tb.init();
    }
    public static void main(String[] args) {
        new TimerTest();
    }
}
