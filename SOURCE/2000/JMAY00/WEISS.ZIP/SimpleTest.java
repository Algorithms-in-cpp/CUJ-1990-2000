public class SimpleTest
{
    public static void main(String[] args)
    {
        SimpleBean bean = new SimpleBean();
        bean.setCount(33);
        int cnt = bean.getCount();
        System.out.println("Bean count = " + cnt);
    }
}
