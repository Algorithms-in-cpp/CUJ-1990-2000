bool get_token(std::string &s)
    {
    s.erase();
    int c;
    while ((c = fgetc(stdin)) != EOF)
        if (isalpha(c) || c == '_' || c == '\n')
            break;
    if (c == EOF)
        return false;
    s += c;
    if (c != '\n')
        {
        while (isalnum(c = fgetc(stdin)) || c == '_')
            s += c;
        ungetc(c, stdin);
        }
    return true;
    }


