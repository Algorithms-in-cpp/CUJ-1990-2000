class StackTest3
{
    public static void main(String[] args)
    {
        FixedStack s = new FixedStack(3);
        doTest(s);
    }

    public static void doTest(Stack s)
    {
        System.out.println("Implementation: " +
                           s.getClass().getName());
        try
        {
            System.out.println("Initial size = " + s.size());
            s.push("one");
            s.push(new Integer(2));
            s.push(new Float(3.0));

            s.push("one too many");
        }
        catch(StackException x)
        {
            System.out.println(x);
        }

        try
        {
            System.out.println("Top: " + s.top());
            System.out.println("Popping...");

            while (s.size() > 0)
                System.out.println(s.pop());
        }
        catch(StackException x)
        {
            throw new InternalError(x.toString());
        }
    }
}

/* Output:
Implementation: FixedStack
Initial size = 0
StackException: overflow
Top: 3.0
Popping...
3.0
2
one
*/
