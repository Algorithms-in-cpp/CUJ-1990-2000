import java.util.*;

class DynamicStack
{
    private Vector data;

    public DynamicStack()
    {
        data = new Vector();
    }

    public void push(Object o)
    {
        data.addElement(o);
    }

    public Object pop()
    throws StackException
    {
        if (data.size() == 0)
            throw new StackException("underflow");
        int where = data.size() - 1;
        Object o = data.elementAt(where);
        data.removeElementAt(where);
        return o;
    }

    public Object top()
    throws StackException
    {
        if (data.size() == 0)
            throw new StackException("underflow");
        return data.elementAt(data.size()-1);
    }

    public int size()
    {
        return data.size();
    }
}
