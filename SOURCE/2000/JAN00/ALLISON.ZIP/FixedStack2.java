class FixedStack implements Stack
{
    private int capacity;
    private int size;
    private Object[] data;

    private class StackIter implements Iterator
    {
        private int pos = 0;
        public boolean hasNext()
        {
            return pos < size;
        }
        public Object next()
        {
            return hasNext() ? data[pos++] : null;
        }
    }

    public Iterator iterator()
    {
        return new StackIter();
    }

// Other methods unchanged ...
}
  
