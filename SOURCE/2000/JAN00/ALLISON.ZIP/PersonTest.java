class PersonTest
{
    public static void main(String[] args)
    {
        Person p1 = new Person("James", 1976, 8, 13);
        Person p2 = (Person) p1.clone();
        System.out.println(p1 == p2);
        System.out.println(p1.equals(p2));
    }
}

/* Output:
false
true
*/
