interface Stack
{
    void push(Object o)
        throws StackException;

    Object pop()
        throws StackException;

    Object top()
        throws StackException;

    int size();

    // This class is static:
    class StackException extends Exception
    {
        StackException(String msg)
        {
            super(msg);
        }
    }
}
