class StackIter implements Iterator
{
    FixedStack s;
    private int pos = 0;
    
    StackIter(FixedStack s)
    {
        this.s = s;
    }
    public boolean hasNext()
    {
        return pos < s.size();
    }
    public Object next()
    {
        return hasNext() ? s.data[pos++] : null;
    }
}

class FixedStack implements Stack
{
    private int capacity;
    private int size;
    Object[] data;

    public Iterator iterator()
    {
        return new StackIter(this);
    }
    // Other methods unchanged ...
}
