class StackException extends Exception
{
    StackException()
    {}
    StackException(String msg)
    {
        super(msg);
    }
}
