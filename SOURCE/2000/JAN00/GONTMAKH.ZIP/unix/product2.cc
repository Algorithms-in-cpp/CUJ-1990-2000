#include "factory.h"
#include "product.h"
#include "product2.h"

regime::creator<int,MyBase,MyProduct2>
s_product2_int_creator(2);
