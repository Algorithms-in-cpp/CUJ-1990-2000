#include <map>
#include <set>
#include <string>

#include <cstdio>

namespace regime {

  //==================================================
  // CLASS: creator_base
  //==================================================
  template <class KEY, class BASE>
    class creator_base {
      //==================================================
      // GROUP: constructors/destructors
      //==================================================
    public:
      creator_base(const KEY& key);
      virtual ~creator_base() {}

      const KEY& get_key() const { return m_key; }
      //==================================================
      // GROUP: library handling
      //==================================================
    public:
      const std::string& get_library() const { return m_library; }
      bool is_loaded() const { return m_is_loaded; }
      void load() { m_is_loaded = true; }
      void unload() { m_is_loaded = false; }

      //==================================================
      // GROUP: product creation
      //==================================================
    public:
      virtual BASE* create() const = 0;
#ifdef REGIME_FACTORY_PARAMS
      virtual BASE* create(const typename BASE::FactoryParams& params) const = 0;
#endif
      virtual void clean() = 0;

      //==================================================
      // GROUP: internal data
      //==================================================
    private:
      const std::string m_library;
      const KEY m_key;
      bool m_is_loaded;
    };

  //==================================================
  // CLASS: creator
  //==================================================
  template <class KEY, class BASE, class PRODUCT>
    class creator : public creator_base<KEY,BASE> {
      //==================================================
      // GROUP: construction/destruction
      //==================================================
    public:
      creator(const KEY& key);
      ~creator();

      //==================================================
      // GROUP: product creation
      //==================================================
    public:
      virtual BASE* create() const {
	return new PRODUCT;
      }
#ifdef REGIME_FACTORY_PARAMS
      virtual BASE* create(const typename BASE::FactoryParams& params) const {
	return new PRODUCT(params);
      }
#endif
      virtual void clean() {
	// Nothing to do here
      }
    };

  //==================================================
  // CLASS: singleton_creator
  //==================================================
  template <class KEY, class BASE, class PRODUCT>
    class singleton_creator : public creator_base<KEY,BASE> {
      //==================================================
      // GROUP: construction/destruction
      //==================================================
    public:
      singleton_creator(const KEY& key);
      ~singleton_creator();

      //==================================================
      // GROUP: product creation
      //==================================================
    public:
      virtual BASE* create() const {
	if (m_product == 0)
	  m_product = new PRODUCT;
	return m_product;
      }
#ifdef REGIME_FACTORY_PARAMS
      virtual BASE* create(const typename BASE::FactoryParams& params) const {
	if (m_product == 0)
	  m_product = new PRODUCT(params);
	return m_product;
      }
#endif
      virtual void clean() {
	m_product = 0;
      }
    private:
      mutable PRODUCT* m_product;
    };

  //==================================================
  // CLASS: load_strategy
  //==================================================
  template <class KEY>
    class load_strategy {
    public:
      virtual ~load_strategy() {}

      virtual std::string find(const KEY& key) = 0;
    };
  
  //==================================================
  // CLASS: library_loader
  //==================================================
  class library_loader {
  public:
    static void* load(const std::string& library);
    static void unload(void* library_handle);
  };

  //==================================================
  // CLASS: factory
  //==================================================
  template <class KEY, class BASE>
    class factory {
    public:
      factory() {
	m_libraries[""] = std::set<KEY>();
      }
      ~factory() {
	for (library_infos::iterator i = m_library_infos.begin();
	     i != m_library_infos.end(); ++i) {
	  assert((*i).second.is_auto == true);
	}
      }
    public:
      static BASE* create(const KEY& key) {
	return get_instance().internal_create(key);
      }
#ifdef REGIME_FACTORY_PARAMS
      static BASE* create(const KEY& key,
			  const typename BASE::FactoryParams& params) {
	return get_instance().internal_create(key, params);
      }
#endif

      static void clean() {
	get_instance().internal_clean();
      }
      static void clean(const KEY& key) {
	get_instance().internal_clean(key);
      }

      static const std::string& get_current_library() {
	return get_instance().internal_get_current_library();
      }
      static void load_library(const std::string& library) {
	get_instance().internal_load_library(library, false);
      }
      static void load_key(const std::string& key) {
	get_instance().internal_load_key(key);
      }
      static void unload_library(const std::string& library) {
	get_instance().internal_unload_library(library);
      }
      static void unload_key(const std::string& key) {
	get_instance().internal_unload_key(key);
      }

      static load_strategy<KEY>* set_load_strategy(load_strategy<KEY>* strategy) {
	return get_instance().internal_set_load_strategy(strategy);
      }

      static const std::map<std::string, std::set<KEY> >&
      query_libraries() {
	return get_instance().internal_query_libraries();
      }
      static const std::set<KEY>& query_library(const std::string& library) {
	return get_instance().internal_query_library(library);
      }
      static const std::set<KEY>&
      query_keys() {
	return get_instance().internal_query_keys();
      }

      static void register_creator(const KEY& key,
				   creator_base<KEY,BASE>* creator) {
	get_instance().internal_register_creator(key, creator);
      }
      static void unregister_creator(const KEY& key,
				     creator_base<KEY,BASE>* creator) {
	get_instance().internal_unregister_creator(key, creator);
      }
      //==================================================
      // Implementation of internal methods
      //==================================================
    private:
      //--------------------------------------------------
      // METHOD: internal_create
      // DESCRIPTION:
      //--------------------------------------------------
      BASE* internal_create(const KEY& key) {
	creators::const_iterator i = m_creators.find(key);
	if (i == m_creators.end()) {
	  if (m_load_strategy == 0)
	    return 0;
	  std::string library = m_load_strategy->find(key);
	  if (library == "")
	    return 0;
	  internal_load_library(library, true);
	  i = m_creators.find(key);
	  assert(i != m_creators.end());
	}
	return (*i).second->create();
      }
      //--------------------------------------------------
      // METHOD: internal_create
      // DESCRIPTION:
      //--------------------------------------------------
#ifdef REGIME_FACTORY_PARAMS
      BASE* internal_create(const KEY& key,
			    const typename BASE::FactoryParams& params) {
	creators::const_iterator i = m_creators.find(key);
	if (i == m_creators.end()) {
	  if (m_load_strategy == 0)
	    return 0;
	  std::string library = m_load_strategy->find(key);
	  if (library == "")
	    return 0;
	  internal_load_library(library, true);
	  i = m_creators.find(key);
	  assert(i != m_creators.end());
	}
	return (*i).second->create(params);
      }
#endif
      //--------------------------------------------------
      // METHOD: internal_clean
      // DESCRIPTION:
      //--------------------------------------------------
      void internal_clean() {
	for (creators::iterator i = m_creators.begin();
	     i != m_creators.end(); ++i) {
	  (*i).second->clean();
	}
      }
      //--------------------------------------------------
      // METHOD: internal_clean(key)
      // DESCRIPTION:
      //--------------------------------------------------
      void internal_clean(const KEY& key) {
	creators::iterator i = m_creators.find(key);
	assert(i != m_creators.end());
	(*i).second->clean();
      }
      //--------------------------------------------------
      // METHOD: internal_load_key
      // DESCRIPTION:
      //--------------------------------------------------
      void internal_load_key(const KEY& key) {
	creators::iterator i = m_creators.find(key);
	if (i == m_creators.end()) {
	  if (m_load_strategy == 0)
	    return;
	  std::string library = m_load_strategy->find(key);
	  if (library == "")
	    return;
	  internal_load_library(library, true);
	  i = m_creators.find(key);
	  assert(i != m_creators.end());
	}
	(*i).second->load();
      }
      //--------------------------------------------------
      // METHOD: internal_get_current_library
      //--------------------------------------------------
      const std::string& internal_get_current_library() const {
	return m_current_library;
      }
      //--------------------------------------------------
      // METHOD: internal_load_library
      // DESCRIPTION:
      //--------------------------------------------------
      void internal_load_library(const std::string& library, bool is_auto) {
	std::string save_library = m_current_library;
	m_current_library = library;

	assert(m_libraries.find(library) == m_libraries.end());
	m_libraries[library] = std::set<KEY>();

	void* library_handle = library_loader::load(library);
	assert(m_library_infos.find(library) == m_library_infos.end());
	m_library_infos[library] = library_info(library_handle, is_auto);

	m_current_library = save_library;
      }
      //--------------------------------------------------
      // METHOD: internal_unload_library
      // DESCRIPTION:
      //--------------------------------------------------
      void internal_unload_library(const std::string& library) {
	std::string save_library = m_current_library;
	m_current_library = library;

	library_infos::iterator i = m_library_infos.find(library);
	assert(i != m_library_infos.end());
	void* library_handle = (*i).second.handle;
	library_loader::unload(library_handle);
	m_library_infos.erase(library);

	assert(m_libraries.find(library) != m_libraries.end());
	assert((*m_libraries.find(library)).second.size() == 0);
	m_libraries.erase(library);

	m_current_library = save_library;
      }
      //--------------------------------------------------
      // METHOD: internal_unload_key
      // DESCRIPTION:
      //--------------------------------------------------
      void internal_unload_key(const KEY& key) {
	creators::iterator i = m_creators.find(key);
	assert(i != m_creators.end());
	(*i).second->unload();
	const std::string& library = (*i)->library();
	bool all_unloaded = true;
	for (i = m_creators.begin(); i != m_creators.end(); ++i) {
	  if ((*i).second->loaded())
	    all_unloaded = false;
	}
	if (all_unloaded)
	  internal_unload_library(library);
      }
      //--------------------------------------------------
      // METHOD: internal_set_load_strategy
      //--------------------------------------------------
      load_strategy<KEY>* internal_set_load_strategy(load_strategy<KEY>* strategy) {
	load_strategy<KEY>* save_strategy = m_load_strategy;
	m_load_strategy = strategy;
	return save_strategy;
      }
      //--------------------------------------------------
      // METHOD: internal_query_libraries
      //--------------------------------------------------
      const std::map<std::string, std::set<KEY> >&
      internal_query_libraries() const {
	return m_libraries;
      }
      //--------------------------------------------------
      // METHOD: internal_query_library
      //--------------------------------------------------
      const std::set<KEY>&
      internal_query_library(const std::string& library) const {
	libraries::const_iterator i = m_libraries.find(library);
	assert(i != m_libraries.end());
	return (*i).second;
      }
      //--------------------------------------------------
      // METHOD: internal_query_keys
      //--------------------------------------------------
      const std::set<KEY>& internal_query_keys() const {
	return m_keys;
      }
      //--------------------------------------------------
      // METHOD: internal_register_creator
      //--------------------------------------------------
      void internal_register_creator(const KEY& key,
				     creator_base<KEY,BASE>* creator) {
	// register the creator
	assert(m_creators.find(key) == m_creators.end());
	m_creators[key] = creator;

	// register the key to keys
	assert(m_keys.find(key) == m_keys.end());
	m_keys.insert(key);

	// register the key to the library
	assert(m_libraries.find(get_current_library()) != m_libraries.end());
	std::set<KEY>& library_keys = m_libraries[get_current_library()];
	assert(library_keys.find(key) == library_keys.end());
	library_keys.insert(key);
      }
      //--------------------------------------------------
      // METHOD: internal_unregister_creator
      //--------------------------------------------------
      void internal_unregister_creator(const KEY& key,
				       creator_base<KEY,BASE>* creator) {
	// While a library is loaded explicitly, it is unloaded
	// implicitly, and usually before the factory.
	// Thus, when a creator gets unloaded, we may not know
	// to which library it belongs.
	// So, in this case we make no checks.
	const std::string& library = creator->get_library();
	assert(get_current_library() == "" ||
	       get_current_library() == library);

	// unregister the key from the library
	assert(m_libraries.find(library) != m_libraries.end());
	std::set<KEY>& library_keys = m_libraries[library];
	assert(library_keys.find(key) != library_keys.end());
	library_keys.erase(key);

	// unregister the key from keys
	assert(m_keys.find(key) != m_keys.end());
	m_keys.erase(key);

	// unregister the creator
	assert(m_creators.find(key) != m_creators.end());
	assert((*m_creators.find(key)).second == creator);
	m_creators.erase(key);
      }
      //==================================================
      // Internal data
      //==================================================
    private:
      typedef std::map<KEY, creator_base<KEY,BASE>*> creators;
      creators m_creators;

      typedef std::set<KEY> keys;
      keys m_keys;

      typedef std::map<std::string, std::set<KEY> > libraries;
      libraries m_libraries;

      struct library_info {
	library_info()
	  : handle(0), is_auto(false)
	  {}
	library_info(void* _handle, bool _is_auto)
	  : handle(_handle), is_auto(_is_auto)
	  {}
	void* handle;
	bool is_auto;
      };
      typedef std::map<std::string, library_info > library_infos;
      library_infos m_library_infos;

      load_strategy<KEY>* m_load_strategy;

      std::string m_current_library;

      //==================================================
      // Instance handling
      //==================================================
    private:
      static factory<KEY,BASE>& get_instance() {
	if (m_instance == 0)
	  m_instance = new factory<KEY,BASE>();
	return *m_instance;
      }
      static factory<KEY,BASE>* m_instance;
    };

  //==================================================
  // IMPLEMENTATION OF: creator_base
  //==================================================
  template <class KEY, class BASE>
    creator_base<KEY,BASE>::creator_base(const KEY& key)
    : m_library(factory<KEY,BASE>::get_current_library())
    , m_is_loaded(true)
    , m_key(key)
    {
    }

  //==================================================
  // IMPLEMENTATION OF: creator
  //==================================================
  template <class KEY, class BASE, class PRODUCT>
    creator<KEY,BASE,PRODUCT>::creator(const KEY& key)
    : creator_base(key)
    {
      factory<KEY,BASE>::register_creator(get_key(), this);
    }

  template <class KEY, class BASE, class PRODUCT>
    creator<KEY,BASE,PRODUCT>::~creator()
    {
      factory<KEY,BASE>::unregister_creator(get_key(), this);
    }

  //==================================================
  // IMPLEMENTATION OF: singleton_creator
  //==================================================
  template <class KEY, class BASE, class PRODUCT>
    singleton_creator<KEY,BASE,PRODUCT>::singleton_creator(const KEY& key)
    : creator_base(key)
    , m_product(0)
    {
      factory<KEY,BASE>::register_creator(get_key(), this);
    }

  template <class KEY, class BASE, class PRODUCT>
    singleton_creator<KEY,BASE,PRODUCT>::~singleton_creator()
    {
      // If I am destroyed, it means my library is unloaded.
      // In this case, I want to make sure my product does not exist
      if (library() != "")
	assert(m_product == 0);
      factory<KEY,BASE>::unregister_creator(get_key(), this);
    }
  //==================================================
  // IMPLEMENTATION OF: factory
  //==================================================
  template <class KEY, class BASE>
    factory<KEY,BASE>* factory<KEY, BASE>::m_instance = 0;
}






