#include "factory.h"
#include "product.h"
#include "product1.h"

regime::creator<int,MyBase,MyProduct1>
s_product1_int_creator(1);
