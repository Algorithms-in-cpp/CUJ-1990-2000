// -*- mode: c++; -*-

#include <dlfcn.h>
#include "factory.h"

namespace regime {
  void* library_loader::load(const std::string& library) {
    return dlopen(library.c_str(), RTLD_LAZY);
  }
  void library_loader::unload(void* handle) {
    dlclose(handle);
  }
}
