class MyBase {
public:
  virtual ~MyBase(){}
  virtual void print(std::ostream& os) const = 0;
};

std::ostream& operator <<(std::ostream& os, const MyBase& base)
{
  base.print(os);
  return os;
}

