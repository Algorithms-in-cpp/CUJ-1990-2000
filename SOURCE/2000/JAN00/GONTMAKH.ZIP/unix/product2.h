class MyProduct2 : public MyBase {
public:
  virtual void print(std::ostream& os) const {
    os << "I am Product2" << std::endl;
  }
};
