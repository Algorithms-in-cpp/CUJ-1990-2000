
void run_kernel();

int main()
{
  run_kernel();
  return 0;
}
