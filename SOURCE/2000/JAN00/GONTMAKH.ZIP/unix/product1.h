class MyProduct1 : public MyBase {
public:
  virtual void print(std::ostream& os) const {
    os << "I am Product1" << std::endl;
  }
};
