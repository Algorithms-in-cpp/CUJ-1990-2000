#include <iostream>
#include <cstdio>
#include "factory.h"
#include "product.h"

class MyLoadStrategy : public regime::load_strategy<int> {
public:
  virtual string find(const int& key) {
    // I would use stringstream here, but it is not yet
    // available in my implementation of C++ (egcs-1.1.2)
    char buf[256];
    if (key < 0)
      return "";
    sprintf(buf, "product%d.so", key);
    std::string result(buf);
    std::cout << "Should load library: " << buf << std::endl;
    return result;
  }
};

typedef regime::factory<int,MyBase> IntFactory;

void dump_libraries()
{
  cout << "IntFactory keys:";
  const set<int>& ikeys = IntFactory::query_keys();
  for (set<int>::const_iterator i = ikeys.begin();
       i != ikeys.end(); ++i) {
    cout << " " << *i;
  }
  cout << endl;

  cout << "IntFactory libraries:" << endl;
  const map<string,set<int> >& ilibs = IntFactory::query_libraries();
  for(map<string,set<int> >::const_iterator i = ilibs.begin();
      i != ilibs.end(); ++i) {
    cout << "  '" << (*i).first << "':";
    for (set<int>::const_iterator si = (*i).second.begin();
	 si != (*i).second.end(); ++si) {
      cout << " " << *si;
    }
    cout << endl;
  }
}

void run_kernel()
{
  using std::cout;
  using std::endl;
  using std::set;
  using std::map;
  using std::string;

  IntFactory::load_library("product1.so");
  IntFactory::set_load_strategy(new MyLoadStrategy());

  cout << "----------------------- before creating ----------------" << endl;
  dump_libraries();
  cout << "--------------------------------------------------------" << endl;

  MyBase* b1 = IntFactory::create(1);
  if (b1 == 0)
    cout << "product with key '1' cannot be created" << endl;
  else
    cout << "product with key '1' says:" << *b1 << endl;

  MyBase* b2 = IntFactory::create(2);
  if (b2 == 0)
    cout << "product with key '2' cannot be created" << endl;
  else
    cout << "product with key '2' says:" << *b1 << endl;

  cout << "------------------------ after creating ----------------" << endl;
  dump_libraries();
  cout << "--------------------------------------------------------" << endl;

  IntFactory::unload_library("product1.so");

  cout << "------------------------ after unloading ---------------" << endl;
  dump_libraries();
  cout << "--------------------------------------------------------" << endl;
}








