#include <iostream.h>
#include "factory.h"

class MyBase {
public:
  virtual ~MyBase(){}
  virtual void print(std::ostream& os) const = 0;
};

std::ostream& operator <<(std::ostream& os, const MyBase& base)
{
  base.print(os);
  return os;
}

class MyProduct1 : public MyBase {
public:
  virtual void print(std::ostream& os) const {
    os << "I am Product1" << std::endl;
  }
};
static regime::creator<int,MyBase,MyProduct1>
s_product1_int_creator(1);
static regime::creator<std::string,MyBase,MyProduct1>
s_product1_string_creator("product1");

class MyProduct2 : public MyBase {
public:
  virtual void print(std::ostream& os) const {
    os << "I am Product2" << std::endl;
  }
};

static regime::creator<int,MyBase,MyProduct2>
s_product2_int_creator(2);
static regime::creator<std::string,MyBase,MyProduct2>
s_product2_string_creator("product2");

int main()
{
  using std::cout;
  using std::endl;
  using std::set;
  using std::map;
  using std::string;
  typedef regime::factory<int,MyBase> IntFactory;
  typedef regime::factory<std::string,MyBase> StringFactory;

  cout << "Hello world" << endl;
  MyBase* b1 = IntFactory::create(1);
  if (b1 == 0)
    cout << "product with key '1' cannot be created" << endl;
  else
    cout << *b1 << endl;

  cout << "IntFactory keys:";
  const set<int>& ikeys = IntFactory::query_keys();
  for (set<int>::const_iterator i = ikeys.begin();
       i != ikeys.end(); ++i) {
    cout << " " << *i;
  }
  cout << endl;

  cout << "StringFactory keys:";
  const set<string>& skeys = StringFactory::query_keys();
  for (set<string>::const_iterator i = skeys.begin();
       i != skeys.end(); ++i) {
    cout << " " << *i;
  }
  cout << endl;

  cout << "StringFactory libraries:" << endl;
  const map<string,set<string> > slibs = StringFactory::query_libraries();
  for(map<string,set<string> >::const_iterator i = slibs.begin();
      i != slibs.end(); ++i) {
    cout << "  '" << (*i).first << "':";
    for (set<string>::const_iterator si = (*i).second.begin();
	 si != (*i).second.end(); ++si) {
      cout << " " << *si;
    }
    cout << endl;
  }
  return 0;
}

