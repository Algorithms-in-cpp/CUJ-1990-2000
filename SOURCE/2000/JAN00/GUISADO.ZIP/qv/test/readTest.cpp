//#include <condefs.h>
#define USEUNIT(ModName) \
   extern DummyThatIsNeverReferenced
   
#include <QvDB.h>
#include <QvInput.h>
#include <QvNode.h>

USEUNIT("..\src\QvLib.cpp");
//---------------------------------------------------------------------------
main(int argc, char **argv)
{
    QvDB::init();

    QvInput	in;
    QvNode	*root;

    if (QvDB::read(&in, root) && root != NULL) {
	root->ref();
	printf("Read was ok\n");
    }
    else {
	root = NULL;
	printf("Read was bad\n");
    }

    if (root != NULL)
	root->unref();

    return 0;
}
