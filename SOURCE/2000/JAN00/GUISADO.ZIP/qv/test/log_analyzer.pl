while (<>) {
   chop;
   my ($op, $id, $at, $ms, $addr, $size, $class)
      = split /,/;
   if ($op eq "+") {
      $objs{$id} = { from => $at, ms => $ms, addr => $addr,
         size => $size, class => $class };
      if (!$group{$class}) {
         $group{$class} = [$id];
      } else {
         push @{$group{$class}}, $id;
      }
   } else {
      $objs{$id}->{to}   = $at;
      $objs{$id}->{toms} = $ms;
	  my $from = $objs{$id}->{from}*1000+$objs{$id}->{ms};
      my $to   = $objs{$id}->{to}*1000+$objs{$id}->{toms};
	  $objs{$id}->{live} = $to-$from;
   }
}


print "Types (by name)\n";
print "Class\tCount\tAvg. Live (ms.)\n";
for (sort keys %group) {
   my $n = scalar @{$group{$_}};
   my $c = $_;
   my $count;
   my $av_live;
   for (@{$group{$_}}) {
      $av_live += $objs{$_}->{live};  
   }
   $av_live /= $n;
   print "$_\t$n\t$av_live\n";
}

print "Types (by count)\n";
sub by_count {
  scalar @{$group{$b}} <=> scalar @{$group{$a}};
}

for (sort by_count keys %group) {
   my $n = scalar @{$group{$_}};
   print "$_ => $n\n";
}

print "Full info\n";
for (sort keys %objs) {
   my $class = $objs{$_}->{class};
   my $live  = $objs{$_}->{live};
   print "$class($_) Live($live)\n"
}


