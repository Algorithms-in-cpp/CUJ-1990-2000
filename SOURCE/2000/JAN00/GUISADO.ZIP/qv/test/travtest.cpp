#include <QvDB.h>
#include <QvInput.h>
#include <QvNode.h>
#include <QvState.h>

#define USEUNIT(x) extern dummito

USEUNIT("..\src\QvLib.cpp");
USEUNIT("..\src\log_object.cpp");
//---------------------------------------------------------------------------
main(int argc, char **argv)
{
    QvDB::init();

    QvInput	in;
    QvNode	*root;

    if (QvDB::read(&in, root) && root != NULL) {
	root->ref();
	printf("Read was ok\n");
    }
    else {
	printf("Read was bad\n");
	return 1;
    }

    QvState state;
    root->traverse(&state);

    root->unref();

    return 0;
}
