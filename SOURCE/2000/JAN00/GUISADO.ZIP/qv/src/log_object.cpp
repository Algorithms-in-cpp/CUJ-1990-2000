#include <log_object.h>
#include <sys\timeb.h>
#include <stdlib.h>

#define LOGFILE "c:\\temp\\log_obj.txt"

unsigned log_object::next_id = 0;
FILE* log_object::fp = NULL;

void log_object::log_create(unsigned id, void* self, size_t size, const char* name)
{
   if (fp == NULL) {
      fp = fopen(LOGFILE, "wt");
      if (fp == NULL) {
         fprintf(stderr, "Could not open log file <%s>.\n", LOGFILE);
         exit(-1);
      }
   }
   struct timeb tb; ftime(&tb);

   fprintf(fp, "+, %u, %ld, %hd, 0x%lx, %d, %s\n",
      id, tb.time, tb.millitm, self, size, name);
   fflush(fp);
}

void log_object::log_delete(unsigned id)
{
   struct timeb tb; ftime(&tb);
   fprintf(fp, "-, %u, %ld, %hd\n", id, tb.time, tb.millitm);
   fflush(fp);
}
