#ifndef LOG_OBJECT_H
#define LOG_OBJECT_H

#include <stdio.h>

class log_object {
public:
   log_object(size_t size, const char* n)
   : obj_id(next_id++)
   {
      log_create(obj_id, this, size, n);
   }
   ~log_object()
   {
      log_delete(obj_id);
   }
   unsigned obj_id;

   static unsigned next_id;
   static FILE* fp;

   static void log_create(unsigned id, void* self, size_t size, const char* name);
   static void log_delete(unsigned id);
};

#define OBJECT_LOGGER(class_name)\
   class _##class_name##_logger : public log_object {\
   public:\
      _##class_name##_logger() : log_object(sizeof(class_name), #class_name) {}\
   } __##class_name##_log_object;

#endif /* LOG_OBJECT_H */

