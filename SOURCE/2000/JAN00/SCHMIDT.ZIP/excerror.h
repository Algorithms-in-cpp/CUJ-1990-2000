#include <stdio.h>

class error
    {
public:
    error()
        {
        printf("error()\n");
        };
    ~error()
        {
        printf("~error()\n");
        };
    };

static void test_1()
    {
    throw error();
    };

static void test_2() throw()
    {
    throw error(); // violates specification
    };

int main()
    {
    printf("\nTest 1: specification empty\n");
    try
        {
        test_1();
        }
    catch (...)
        {
        printf("caught\n");
        };
    printf("\nTest 2: specification 'throw()'\n");
    try
        {
        test_2();
        }
    catch (...)
        {
        printf("caught\n"); // should never appear
        };
    return 0;
    }
