//
// other.h
//
class other_class
    {
public:
    other_class();
    };

//
// other.cpp
//
#include "other.h"

other_class::other_class()
    {
    }

other_class other_object;

//
// main.cpp
//
#include "other.h"

int main()
    {
    return 0;
    }
