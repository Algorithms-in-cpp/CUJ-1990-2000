// sequence.h

#ifndef SEQUENCE_H_INCLUDED
#define SEQUENCE_H_INCLUDED

#include "deep.h"

class line_number_sequence
    {
public:
    line_number_sequence(unsigned n);
    void add(unsigned n);
    void put() const;
private:
    struct list_node;
    deep_pointer<list_node> first, last;
    };

#endif
