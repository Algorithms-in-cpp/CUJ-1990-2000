cross_reference_table::tree_node *
cross_reference_table::add_tree
(tree_node *t, string const &w, unsigned n)
    {
    int cmp;
    if (t == NULL)
        t = new tree_node (w, n);
    else if ((cmp = w.compare(t->word)) < 0)
        t->left = add_tree(t->left, w, n);
    else if (cmp > 0)
        t->right = add_tree(t->right, w, n);
    else
        t->lines.add(n);
    return t;
    }
