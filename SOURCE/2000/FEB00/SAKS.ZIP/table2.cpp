// table.cpp

#include <stdio.h>
#include <string>
#include <string.h>

#include "deep.h"
#include "table2.h"
#include "sequence.h"

using std::string;

struct cross_reference_table::tree_node
    {
    tree_node(string const &w, unsigned n);
    string word;
    line_number_sequence lines;
    deep_pointer<tree_node> left, right;
    };

inline
cross_reference_table::
tree_node::tree_node(string const &w, unsigned n)
    : word(w), lines(n), left(NULL), right(NULL)
    {
    }

cross_reference_table::tree_node *
cross_reference_table::add_tree
(tree_node *t, string const &w, unsigned n)
    {
    if (t == NULL)
        t = new tree_node (w, n);
    else if (w < t->word)
        t->left = add_tree(t->left, w, n);
    else if (w > t->word)
        t->right = add_tree(t->right, w, n);
    else
        t->lines.add(n);
    return t;
    }

void
cross_reference_table::put_tree(tree_node const *t)
    {
    if (t != NULL)
        {
        put_tree(t->left);
        printf("%12s:", t->word.c_str());
        t->lines.put();
        printf("\n");
        put_tree(t->right);
        }
    }
