int main()
    {
    cross_reference_table table;
    std::string token;
    token.reserve(128);
    unsigned ln = 1;
    while (get_token(token))
        if (isalpha(token[0]) || token[0] == '_')
            table.add(token, ln);
        else // if (token[0] == '\n')
            ++ln;
    table.put();
    return 0;
    }
