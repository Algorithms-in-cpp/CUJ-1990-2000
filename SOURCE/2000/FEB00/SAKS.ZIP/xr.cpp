// xr.cpp

#include <ctype.h>
#include <stdio.h>
#include <string>

#include "table.h"

bool get_token(std::string &s);

int main()
    {
    cross_reference_table table;
    std::string token;
    unsigned ln = 1;
    while (get_token(token))
        if (isalpha(token[0]) || token[0] == '_')
            table.add(token.c_str(), ln);
        else // if (token[0] == '\n')
            ++ln;
    table.put();
    return 0;
    }

bool get_token(std::string &s)
    {
    int c;
    while ((c = fgetc(stdin)) != EOF)
        if (isalpha(c) || c == '_' || c == '\n')
            break;
    if (c == EOF)
        {
        s.erase();
        return false;
        }
    s = c;
    if (c != '\n')
        {
        while (isalnum(c = fgetc(stdin)) || c == '_')
            s += c;
        ungetc(c, stdin);
        }
    return true;
    }
