// sequence.cpp

#include <stdio.h>

#include "deep.h"
#include "sequence.h"

struct line_number_sequence::list_node
    {
    unsigned number;
    deep_pointer<list_node> next;
    };

line_number_sequence::
line_number_sequence(unsigned n)
    {
    first = new list_node;
    first->number = n;
    first->next = NULL;
    last = first;
    }

void line_number_sequence::add(unsigned n)
    {
    if (n != last->number)
        {
        last->next = new list_node;
        last = last->next;
        last->number = n;
        last->next = NULL;
        }
    }

void line_number_sequence::put() const
    {
    list_node const *p;
    for (p = first; p != NULL; p = p->next)
        printf(" %4d", p->number);
    }

