#ifndef INTERPOLATE_H
#define INTERPOLATE_H

double lagrange(const double *x, const double *fx, int n,
   double X);

double newton(const double *x, const double *fx, int n,
   double X, double tolerance, int *degree);

double pwlinear(const double *x, const double *fx, int n,
   double X);

double pwhermite(const double *x, const double *fx, const
   double *fpx, int n, double X);

#endif
