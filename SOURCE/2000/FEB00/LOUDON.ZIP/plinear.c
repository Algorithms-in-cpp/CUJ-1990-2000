/***************************************************************
*                                                              *
*  ------------- Piecewise-Linear Interpolation -------------  *
*                                                              *
*  On Call:                                                    *
*  x           Array of strictly increasing points             *
*  fx          Array of known values of f(x) at each x         *
*  n           Count of values in x and fx                     *
*  X           Value of x at which to compute f(x)             *
*                                                              *
*  On Return:                                                  *
*  pwlinear    Value of f(x) at X                              *
*                                                              *
***************************************************************/

#include "interpolate.h"

double pwlinear(const double *x, const double *fx, int n,
   double X) {

int                k;

/*
** Locate the interval on which X lies. If this interval is not
** found by k = n - 3, [x[n - 2], x[n - 1]] is used.
*/

for (k = 0; k < n - 2; k++) {

   if (X < x[k + 1])
      break;

}

/*
** Compute p1(x), the linear interpolating polynomial, to obtain
** a value for f(x) at X.     
*/

return fx[k] + (((fx[k + 1] - fx[k]) / (x[k + 1] - x[k])) * (X -
   x[k]));

}
