/***************************************************************
*                                                              *
*  -------- Interpolation Using Lagrange Polynomials --------  *
*                                                              *
*  On Call:                                                    *
*  x           Array of interpolation points                   *
*  fx          Array of known values of f(x) at each x         *
*  n           Count of values in x and fx                     *
*  X           Value of x at which to compute f(x)             *
*                                                              *
*  On Return:                                                  *
*  lagrange    Value of f(x) at X                              *
*                                                              *
***************************************************************/

#include "interpolate.h"

double lagrange(const double *x, const double *fx, int n,
   double X) {

double             l, p = 0.0;
int                i, k;

for (k = 0; k < n; k++) {

   l = 1.0;

   /*
   ** Obtain lk(x) for the next term to add to the interpolating
   ** polynomial.
   */

   for (i = 0; i < n; i++) {

      if (i != k)
         l = l * ((X - x[i]) / (x[k] - x[i]));

   }

   /*
   ** Add the next term computed from lk(x) to the interpolating
   ** polynomial.
   */

   p = p + (fx[k] * l);

}

return p;

}
