/***************************************************************
*                                                              *
*  --------- Interpolation Using Newton Polynomials ---------  *
*                                                              *
*  On Call:                                                    *
*  x           Array of interpolation points                   *
*  fx          Array of known values of f(x) at each x         *
*  n           Count of values in x and fx                     *
*  X           Value of x at which to compute f(x)             *
*  tolerance   Delta for successive pk(x) at which to stop     *
*                                                              *
*  On Return:                                                  *
*  degree      Degree of the interpolating polynomial          *
*  newton      Value of f(x) at X, or DBL_MAX on errors        *
*                                                              *
***************************************************************/

#include <float.h>
#include <math.h>
#include <stdlib.h>
#include "interpolate.h"

double newton(const double *x, const double *fx, int n,
   double X, double tolerance, int *degree) {

double             *table, delta, m = 1.0, p;
int                i, k;

/*
** Allocate enough storage for the longest diagonal required in
** the divided-diffrence table.
*/

if ((table = (double *)malloc(sizeof(double) * n)) == NULL)
   return DBL_MAX;

/*
** Set the initial interpolating polynomial and first element of 
** the divided-difference table to f(x0).
*/

p = table[0] = fx[0];
*degree = 0;

for (k = 0; k < n - 1; k++) {

   (*degree)++;
   table[k + 1] = fx[k + 1];

   /*
   ** Compute the next diagonal placed in the divided-difference
   ** table to obtain the next coefficient.
   */

   for (i = k; i >= 0; i--)
      table[i] = (table[i + 1] - table[i]) / (x[k + 1] - x[i]);

   /*
   ** Compute the next pk(x), one degree larger than the last,
   ** and determine whether the specified tolerance will be met.
   */

   m = m * (X - x[k]);
   p = p + (delta = table[0] * m);

   if (fabs(delta) < tolerance) {

      free(table);
      return p;

   }

}

/*
** The specified tolerance was never met for differences between
** successive interpolating polynomials.
*/

free(table);
return DBL_MAX;

}
