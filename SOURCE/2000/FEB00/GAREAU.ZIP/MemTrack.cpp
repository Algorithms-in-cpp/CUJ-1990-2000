// MemTrack.cpp
// Copyright (C) 2000, Jean Louis Gareau
// All rights reserved.
//
// This is an MFC extension DLL that implements memory tracking function.
// The main purpose of using a DLL is to provide an automatic dump of the 
// detected leaks (if any) upon process termination.
//
// To add memory tracking to an MFC project:
//    1) Add "#include <MemTrack.h>" as the last include file in Stdafx.h.
//       You can surround it by #ifdef _DEBUG and #endif if you want memory 
//       tracking to take effect only in debug mode.
//    2) Replace any occurrence of ::new and ::delete by new and delete respectively.
//    3) Add the directory where MemTrack.h resides in the project settings: from the 
//       Projects menu, select Settings and then C/C++; select Preprocessor from the 
//       Category combo box, and add the path under "Additional include directories".
//    4) Add the directory where MemTrackd.lib resides in the project settings: still 
//       within the Projects Settings dialog box, select the Link tab, and Input from 
//       the Category combo box; then add the path under "Additional library path".
//    5) Rebuild the project and run it.
//    6) The reward: any memory leak will be dumped in the Output window. Double-clicking 
//       on each line describing a leak will open the file and position the cursor on the 
//       related line.
//
// Enjoy!
// 
// Email your comments and suggestions to jeangareau@yahoo.com

#include "stdafx.h"
#include <afxdllx.h>
#include <stdlib.h>

// Make sure that some new settings do not take effect in this file.
#define __MEMTRACK__

#include "MemTrack.h"

/////////////////////////////////////////////////////////////////////////////
// DLL management function.

static AFX_EXTENSION_MODULE MemTrackDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HANDLE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("MemTrackD.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		if (!AfxInitExtensionModule(MemTrackDLL, (HINSTANCE)hInstance))
			return 0;

		// Insert this DLL into the resource chain
		// NOTE: If this Extension DLL is being implicitly linked to by
		//  an MFC Regular DLL (such as an ActiveX Control)
		//  instead of an MFC application, then you will want to
		//  remove this line from DllMain and put it in a separate
		//  function exported from this Extension DLL.  The Regular DLL
		//  that uses this Extension DLL should then explicitly call that
		//  function to initialize this Extension DLL.  Otherwise,
		//  the CDynLinkLibrary object will not be attached to the
		//  Regular DLL's resource chain, and serious problems will
		//  result.

		new CDynLinkLibrary(MemTrackDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
      // Automatically dump any memory leaks and cleanup.
      afxMemTrack.DumpMemoryLeaks();
      afxMemTrack.Cleanup();

		// Terminate the library before destructors are called
		AfxTermExtensionModule(MemTrackDLL);

		TRACE0("MemTrackD.DLL Terminating!\n");
   }

	return 1;
}

/////////////////////////////////////////////////////////////////////////////
// Memory check implementation

// The one and only one instance of CMemTrack.

CMemTrack   afxMemTrack;

CMemTrack::CMemTrack()
{
#ifdef _DEBUG
   m_bSilent = FALSE;
#else
   m_bSilent = TRUE;
#endif
}

// Allocating a block of memory is done via malloc(), but the information
// about the statement requiring that memory is kept in the map.

void* CMemTrack::Allocate(size_t nSize, char* lpszFileName, int nLine)
{
   LPVOID pAddr = malloc(nSize);

   if (!m_bSilent)
   {
      TRACE(_T("%S(%d) : allocating %d bytes at 0x%08x\n"), lpszFileName, nLine, nSize, pAddr);
   }

   if (pAddr)
   {
      LPMEMALLOC  pMemAlloc = (LPMEMALLOC) malloc(sizeof(SMEMALLOC));
      ASSERT(pMemAlloc != NULL);

      pMemAlloc->pszFilename = lpszFileName;
      pMemAlloc->nLine = nLine;
      pMemAlloc->nSize = nSize;

      // Store it in the map
      m_AddrMap.SetAt(pAddr, pMemAlloc);
   }

   return pAddr;
}

// Deallocating memory is done via free(), and the corresponding entry in the
// map is removed.

void CMemTrack::Deallocate(void* pAddr)
{
   if (!m_bSilent)
   {
      TRACE(_T("MemTrack: Deallocating block 0x%08x\n"), pAddr);
   }

   if (pAddr)
   {
      LPMEMALLOC  pMemAlloc;
      
      if (m_AddrMap.Lookup(pAddr, pMemAlloc))
      {
         ASSERT(pMemAlloc != NULL);

         m_AddrMap.RemoveKey(pAddr);
         free(pMemAlloc);
      }
      else
      {
         TRACE(_T("MemTrack: Can't deallocate block 0x%08x (block not found)\n"), pAddr);
      }
   }

   free(pAddr);
}

// Dumping memory leaks simply consists of dumping all entries in the map.
// Note that in release mode, only a message box is being shown, since TRACE
// statements are not visible from the Output window.

void CMemTrack::DumpMemoryLeaks()
{
   if (m_AddrMap.IsEmpty())
      return;

   int   nCount = m_AddrMap.GetCount();

#ifdef _DEBUG
   TRACE(_T("\n%d memory leak(s) found:\n"), nCount);

   POSITION pos = m_AddrMap.GetStartPosition();

   while (pos != NULL)
   {
      LPMEMALLOC  pMemAlloc;
      LPVOID      pAddr;

      m_AddrMap.GetNextAssoc(pos, pAddr, pMemAlloc);
      TRACE(_T("%S(%d) : block at 0x%x, %d byte(s) long\n"), pMemAlloc->pszFilename, pMemAlloc->nLine, pAddr, pMemAlloc->nSize);
   }

   TRACE(_T("\n"));

   CString  sText;
   sText.Format(_T("%d memory leaks detected!\nSee Output window for details"), nCount);;
#else
   CString  sText;
   sText.Format(_T("%d memory leaks detected!\nRun the application in debug mode and see the Output window for details."), nCount);
#endif

#if (_WIN32_WCE >= 201)
   AfxMessageBox(sText, MB_ICONHAND);
#else
   // Windows CE 2.00 doesn't digest AfxMessageBox() at this point.
   ::MessageBox(NULL, sText, _T("Memory Leaks!"), MB_ICONHAND);
#endif
}

// Cleaning CMemTrack consists of deleting all entries in the map.

void CMemTrack::Cleanup()
{
   POSITION pos = m_AddrMap.GetStartPosition();

   while (pos != NULL)
   {
      LPMEMALLOC  pMemAlloc;
      LPVOID      pAddr;

      m_AddrMap.GetNextAssoc(pos, pAddr, pMemAlloc);

      delete pMemAlloc;
   }

   m_AddrMap.RemoveAll();
}

// This static Dump method dumps afxMemTrack.

void CMemTrack::Dump()
{
   afxMemTrack.DumpMemoryLeaks();
}
