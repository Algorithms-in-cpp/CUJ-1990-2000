Listing 2: test.cpp

#include <assert.h>

#include <functional>
#include <vector>

#include "BackTrack.h"


enum State
   {ME, NH, VT, MA, CT, RI, NY, PA, NJ, DE,
    MD, DC, VA, NC, WV, SC, GA, FL, AL, TN,
    KY, OH, IN, MI, MS, LA, AR, MO, IL, WI,
    IA, MN, ND, SD, NE, KS, OK, TX, NM, CO,
    WY, MT, ID, UT, AZ, NV, CA, OR, WA};


const int NumberStates = 49;
const int MaxNeighbors = 8;


enum Color {Blue, Yellow, Green, Red};

inline Color& operator++ (Color& c)
{
   c = Color (c + 1);
   return c;
}

inline State& operator++ (State& c)
{
   c = State (c + 1);
   return c;
}

typedef std::vector<Color> Map;
typedef Map::iterator MapIter;


// store neighbor's of each state.
// Neighbor [i][0] == # of neighbors  of state i
// Neighbor [i][j] == jth neighbor of state i
State Neighbor [NumberStates][MaxNeighbors+1]; 

inline Connect (State s1, State s2)
{
   int count = ++Neighbor [s1][0];
   Neighbor [s1][count] = s2;

   count = ++Neighbor [s2][0];
   Neighbor [s2][count] = s1;

   assert (Neighbor [s1][0] <= MaxNeighbors);
   assert (Neighbor [s2][0] <= MaxNeighbors);
}


void BuildMap ()
{
   for (int i = 0; i < NumberStates; i++)
         Neighbor [i][0] = State(0);


   Connect (ME,NH);
   Connect (NH,VT); Connect (NH,MA);
   Connect (VT,MA); Connect (VT,NY);
   Connect (MA,NY); Connect (MA,CT); Connect (MA,RI);
   Connect (CT,RI); Connect (CT,NY);
   Connect (NY,NJ); Connect (NY,PA); Connect (NY,OH);
   Connect (PA,NJ); Connect (PA,DE); Connect (PA,MD); Connect (PA,WV);
   Connect (PA,OH);
   Connect (NJ,DE);
   Connect (DE,MD);
   Connect (MD,DC); Connect (MD,WV); Connect (MD,VA); Connect (DC,VA);
   Connect (VA,WV); Connect (VA,NC); Connect (VA,KY);   Connect (VA,TN);
   Connect (NC,TN); Connect (NC,SC); Connect (NC,GA);
   Connect (WV,OH); Connect (WV,KY);
   Connect (SC,GA);
   Connect (GA,AL); Connect (GA,FL);
   Connect (FL,AL);
   Connect (AL,TN); Connect (AL,MS);
   Connect (TN,KY); Connect (TN,MS); Connect (TN,AR); Connect (TN,MO);
   Connect (KY,IN); Connect (KY,OH); Connect (KY,MO); Connect (KY,IL);
   Connect (OH,IN); Connect (OH,MI);
   Connect (IN,MI); Connect (IN,IL);
   Connect (MI,WI);
   Connect (MS,LA); Connect (MS,AR);
   Connect (LA,TX);
   Connect (AR,MO); Connect (AR,TX); Connect (AR,OK);
   Connect (MO,IA); Connect (MO,IL); Connect (MO,OK); Connect (MO,KS); Connect (MO,NE);
   Connect (IL,WI); Connect (IL,IA);
   Connect (WI,MN); Connect (WI,IA);
   Connect (IA,MN); Connect (IA,SD); Connect (IA,NE);
   Connect (MN,ND); Connect (MN,SD);
   Connect (ND,MT); Connect (ND,SD);
   Connect (SD,NE); Connect (SD,MT); Connect (SD,WY);
   Connect (NE,WY); Connect (NE,CO); Connect (NE,KS);
   Connect (KS,CO); Connect (KS,OK);
   Connect (OK,CO); Connect (OK,NM); Connect (OK,TX);
   Connect (TX,NM);
   Connect (NM,CO); Connect (NM,AZ); Connect (NM,UT);
   Connect (CO,AZ); Connect (CO,UT); Connect (CO,WY);
   Connect (WY,MT); Connect (WY,ID); Connect (WY,UT);
   Connect (MT,ID);
   Connect (ID,WA); Connect (ID,OR); Connect (ID,NV); Connect (ID,UT);
   Connect (UT,NV); Connect (UT,AZ);
   Connect (AZ,NV); Connect (AZ,CA);
   Connect (NV,OR); Connect (NV,CA);
   Connect (CA,OR);
   Connect (OR,WA);
}


struct ColorIsValid : public std::binary_function<MapIter, MapIter, bool> 
{
   bool operator() (const MapIter& begin, const MapIter& end) 
   {
      State LastState = State (end-begin-1);
      Color LastColor = *(end-1);
      bool Valid = true;
      for (int i = 1; i <= Neighbor [LastState][0]; i++) {
         State NeighborState = Neighbor [LastState][i];
         if (NeighborState < LastState &&
             *(begin+NeighborState) == LastColor)
             return false;
      }
      return true;
   }
};



int main (int argc, char* argv [])
{
   Map tree (NumberStates);

   BackTrack <Color, MapIter, ColorIsValid> ColorMap (Blue, Red);
   BuildMap ();

   bool FirstTime = true;
   // find first 100 valid colorings of the U.S.
   for (int i = 0; i < 100; i++)
      bool Valid = ColorMap (tree.begin(), tree.end(), FirstTime);

   return 0;
}

