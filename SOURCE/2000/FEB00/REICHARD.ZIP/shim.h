class ABase
{
protected:
    virtual size_t GetSize()=0;
    ...
    void UseGetSize()
    {
    ...
    size_t size = GetSize();
    ...
    }
};

template <class Derived, class Base>
class SGetSize : public Base
{
protected:
    virtual size_t GetSize() { return sizeof(Derived);}
};

class CDerivedOne : public SGetSize<CDerivedOne, ABase> {};
class CDerivedTwo: public SGetSize<CDerivedTwo, ABase> {};
