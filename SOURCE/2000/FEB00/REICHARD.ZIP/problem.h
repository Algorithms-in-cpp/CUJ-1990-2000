class ABase
{
protected:
    virtual size_t GetSize()=0;
    ...
    void UseGetSize()
    {
    ...
    size_t size = GetSize();
    ...
    }
};
 
class CDerivedOne : public ABase 
{
protected:
    virtual size_t GetSize() 
    { return sizeof(CDerivedOne);}
};

class CDerivedTwo: public ABase 
{
protected:
    virtual size_t GetSize() 
    { return sizeof(CDerivedTwo);}
};
