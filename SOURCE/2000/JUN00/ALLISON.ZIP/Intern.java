class Intern
{ 
    public static void main(String[] args) {
        String s1 = "hello";
        String s2 = "hello";
        if (s1 == s2) {
            // The same object:
            System.out.println("s1 == s2");
        }
        String s3 = new String("hello");
        if (s3 != s1) {
            // Different objects:
            System.out.println("s3 != s1");
        }
        String suffix = "lo";
        String s4 = "hel" + suffix;
        String s5 = s4.intern();
        if (s4 != s1) {
            // Same:
            System.out.println("s4 != s1");
        }
        if (s5 == s1) {
            // Different:
            System.out.println("s5 from pool");
        }
    }
}

/* Output:
s1 == s2
s3 != s1
s4 != s1
s5 from pool
*/
