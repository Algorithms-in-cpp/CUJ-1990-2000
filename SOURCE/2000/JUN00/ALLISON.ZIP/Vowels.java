import java.io.*;
import java.util.*;

class Vowels
{
    public static void main(String[] args)
        throws IOException
    {
        BufferedReader in =
            new BufferedReader(
               new FileReader(args[0]));
        String delims =
            "aAeEiIoOuU";
        int totA = 0, totE = 0, totI = 0,
            totO = 0, totU = 0;

        // Read lines:
        String line;
        while ((line = in.readLine()) != null)
        {
            // Tokenize line:
            StringTokenizer strtok =
                new StringTokenizer(line, delims, true);
            while (strtok.hasMoreTokens())
            {
                char vowel = strtok.nextToken().charAt(0);
                switch(Character.toLowerCase(vowel))
                {
                case 'a':
                    ++totA;
                    break;
                case 'e':
                    ++totE;
                    break;
                case 'i':
                    ++totI;
                    break;
                case 'o':
                    ++totO;
                    break;
                case 'u':
                    ++totU;
                    break;
                }
            }
        }

        System.out.println("Number of 'A's: " + totA);
        System.out.println("Number of 'E's: " + totE);
        System.out.println("Number of 'I's: " + totI);
        System.out.println("Number of 'O's: " + totO);
        System.out.println("Number of 'U's: " + totU);
    }
}

/* Output from "Vowels tokens.dat":
Number of 'A's: 12
Number of 'E's: 19
Number of 'I's: 15
Number of 'O's: 15
Number of 'U's: 5
*/


