import java.io.*;

class Replace
{
    public static void main(String[] args)
        throws IOException
    {
        BufferedReader in =
            new BufferedReader(new InputStreamReader(System.in));
        String line;
        int fromLen = args[0].length();
        int toLen = args[1].length();
        
        while ((line = in.readLine()) != null)
        {
            String newLine = line;
            int pos1 = 0, pos2;
            while ((pos2 = newLine.indexOf(args[0], pos1)) >= 0)
            {
                newLine = 
                    newLine.substring(0, pos2) +
                    args[1] + newLine.substring(pos2 + fromLen);
                pos1 = pos2 + toLen;
            }
            System.out.println(newLine);
        }
    }
}

/* Output:
import java.io.*;

class Replace
{
    public static void ma$$$(Str$$$g[] args)
        throws IOException
    {
        BufferedReader $$$ =
            new BufferedReader(new InputStreamReader(System.$$$));
        Str$$$g l$$$e;
        $$$t fromLen = args[0].length();
        $$$t toLen = args[1].length();
        
        while ((l$$$e = $$$.readL$$$e()) != null)
        {
            Str$$$g newL$$$e = l$$$e;
            $$$t pos1 = 0, pos2;
            while ((pos2 = newL$$$e.$$$dexOf(args[0], pos1)) >= 0)
            {
                newL$$$e = 
                    newL$$$e.substr$$$g(0, pos2) +
                    args[1] + 
                    newL$$$e.substr$$$g(pos2 + fromLen);
                pos1 = pos2 + toLen;
            }
            System.out.pr$$$tln(newL$$$e);
        }
    }
}
*/
