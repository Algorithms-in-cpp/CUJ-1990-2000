import java.io.*;

class Search2
{
    public static void main(String[] args)
        throws IOException
    {
        BufferedReader in =
            new BufferedReader(
                new InputStreamReader(System.in));
        String key = args[0].toLowerCase();
        
        // Process each line:
        String line;
        while ((line = in.readLine()) != null)
        {
            String lineLower = line.toLowerCase();
            if (lineLower.indexOf(key) >= 0)
                System.out.println(line);
        }
    }
}
