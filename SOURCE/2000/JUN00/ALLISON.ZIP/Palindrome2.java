class Palindrome2
{
    static void normalize(StringBuffer s)
    {
        int i = 0;
        while (i < s.length())
        {
            char c = s.charAt(i);
            if (!Character.isLetter(c))
                s.deleteCharAt(i);
            else
                s.setCharAt(i++, Character.toLowerCase(c));
        }
    }

    static boolean isSymmetric(StringBuffer s)
    {
        int len = s.length();
        for (int i = 0; i < len; ++i)
            if (s.charAt(i) != s.charAt(len-i-1))
                return false;
        return true;
    }

    public static void main(String[] args)
    {
        String[] strings = {
            "Madam",
            "Lid off a daffodil",
            "Norma is as selfless as I am, Ron",
            "Not a palindrome"};

        for (int i = 0; i < strings.length; ++i)
        {
            StringBuffer s = new StringBuffer(strings[i]);
            System.out.print("\"" + s + "\" is ");
            normalize(s);
            if (!isSymmetric(s))
                System.out.print("not ");
            System.out.println("a palindrome");
        }
    }
}

/* Output:
"Madam" is a palindrome
"Lid off a daffodil" is a palindrome
"Norma is as selfless as I am, Ron" is a palindrome
"Not a palindrome" is not a palindrome
*/
