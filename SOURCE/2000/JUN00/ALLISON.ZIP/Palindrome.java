class Palindrome
{
    static boolean isSymmetric(String s)
    {
        int len = s.length();
        for (int i = 0; i < len; ++i)
            if (s.charAt(i) != s.charAt(len-i-1))
                return false;
        return true;
    }

    public static void main(String[] args)
    {
        String[] strings = {
            "madam",
            "notapalindrome"};
        for (int i = 0; i < strings.length; ++i)
        {
            System.out.print("\"" + strings[i] + "\" is ");
            if (!isSymmetric(strings[i]))
                System.out.print("not ");
            System.out.println("a palindrome");
        }
    }
}

/* Output:
"madam" is a palindrome
"notapalindrome" is not a palindrome
*/
