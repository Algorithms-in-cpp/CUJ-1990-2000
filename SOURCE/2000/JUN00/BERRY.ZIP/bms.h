#ifndef __BMS_H__
#define __BMS_H__

int bms(char *pattern, char *text, int length);
int bmsfile(FILE *in, FILE *out, char *pattern);
int grepfile(FILE *in, FILE *out, char *pattern);
int testbms();

#endif //__BMS_H__