//
//	Copyright 1999-2000. David E. Berry. All rights reserved
//
//
#if !defined(UNIX)
	#include <windows.h>
    #include <io.h>
    #include <fcntl.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include "bms.h"
#include "regex.h"

int main(int argc, char *argv[]);

int main(int argc, char *argv[])
{

#if defined(TEST)
	(void) argc;
	(void) argv;
	return testbms();
#else

	if (argc < 2)
	{
		fprintf(stderr,"Usage: BMS pattern [file] \n");
		exit (1);
	}

	if ( argc > 2 )
	{
		if(freopen( argv[ 2 ], "rt", stdin )==NULL)
		{
			fprintf(stderr, "Could not Open %s\n", argv[2]);
			exit (1);
		}
	}

#if !defined( UNIX )
    setmode( fileno( stdin ), O_BINARY );
    setmode( fileno( stdout ), O_BINARY );
#endif

#if defined(GREP)
	return  grepfile(stdin, stdout, argv[1]);
#else
	return  bmsfile(stdin, stdout, argv[1]);
#endif
#endif //TEST
}


int bmsfile(FILE *in, FILE *out, char *pattern)
{
char buff[2048];
int bytesread=0;
int totalbytesread=0;
CRegEx CRE(pattern);
char *ptr;
int rc = 0;
int matchLen;
char *matchStr;

	while (!feof(in))
	{
		bytesread = fread(buff, sizeof(char), sizeof(buff), in);
		ptr = buff;

		while ((ptr = CRE.Match( (LPTSTR)ptr, bytesread-(ptr-buff), matchLen)) != NULL)
		{
			matchStr = new char[matchLen+1];
			strncpy(matchStr, ptr, matchLen);
			matchStr[matchLen]='\0';
			fprintf(out,"Match found at position %d - <%s>\n", totalbytesread + (ptr-buff), matchStr);
			delete [] matchStr;
			ptr+=matchLen;
			rc=1;
		}

		totalbytesread += bytesread;
	}
	return rc;
}

int grepfile(FILE *in, FILE *out, char *pattern)
{
char buff[2049];
CRegEx CRE(pattern);
char *ptr;
int rc = 0;
int matchLen;
int ch;
bool overrun;

	while (!feof(in))
	{
		ptr = buff;
		overrun =false;

		while ((ch = getc(in)) != EOF && ch == '\n' || ch == '\r');

		if (ch != EOF ) *ptr++=(char) ch;

		while((ch = getc(in)) != EOF && ch != '\n' && ch != '\r')
		{
			if (!overrun)
			{
				if (ptr-buff>=2048)
				{
					overrun = true;
					// I have included my most hated grep message
					fprintf(stderr,"Line Exceeded 2048 characters\n");
				}
				else
					*ptr++=(char)ch;
			}
		}
		*ptr = '\0';

		if (CRE.Match((LPTSTR)buff, strlen(buff), matchLen) != NULL)
			fprintf(out,"%s\r\n",buff);

	}
	return rc;
}


#if defined(TEST)
struct TEST_ENTRY
{
	TCHAR *regex;
	TCHAR *text;
	bool result;	// expected result
};

TEST_ENTRY TestArray[] = {	{"t?st","this is a test",true},
{"t?st$","this is a test",true},
{"^t?st","this is a test",false},
{"^t*s","this is a test",true},
{"^the","this is a test",false},
{"t*t","this is a test",true},
{"^t*t","this is a test",true},
{"t*t$","this is a test",true},
{"^*$","this is a test",true},
{"off?set","offoffsetset", true},
{"this*not*test","this is not a test",true},
{NULL, NULL, false} };

int testbms()
{
	int i;
	CRegEx RegEx;
	TCHAR *textfound;
	TCHAR *displaystr=NULL;
	int len;

	for (i=0; TestArray[i].regex!=NULL; i++)
	{
		RegEx.SetRegEx(TestArray[i].regex);
		len =0;
		textfound = RegEx.Match(TestArray[i].text, _tcslen(TestArray[i].text),len);
		
		if ((textfound!=NULL)^TestArray[i].result)
			printf("\nTest Failed:");
		else
			printf("\nTest Passed:");
		
		if (textfound!=NULL)
		{
			displaystr = new char[len+1];
			displaystr = strncpy(displaystr, textfound, len);
			displaystr[len]='\0';
			printf("regex:<%s> text:<%s> match:<%s>", TestArray[i].regex,TestArray[i].text,displaystr);
			delete [] displaystr;
		}
		else
			printf("regex:<%s> text:<%s> match:<>", TestArray[i].regex,TestArray[i].text);

		printf("\n");
	}

	return 0;
}
#endif //TEST