///////////////////////////////////////////////////////////////
//
//	NAME:	CRegEx
//
//	AUTHOR:	David E. Berry
//
//	DATE:	07/15/99
//
//	DESCRIPTION:
//
//	CRegEx is a class that incorporates the Boyer-Moore 
//	string searching algorithm with regular expressions.
//	The following special characters are or will be supported:
//
//	?  - match any or no single character.	(SUPPORTED)
//	*  - match any or no string of chars.	(SUPPORTED)
//	[] - match any single character include	(SUPPORTED)
//		 between the brackets.
//	^  - match must be at the beginning of	(SUPPORTED)
//		 the buffer
//	$  - match must be at the end of the	(SUPPORTED)
//		 buffer.
//
//  COPYRIGHT:
//  Copyright (c) 1999-2000, David E. Berry. All rights reserved.
//
//	MODIFICATIONS:
//
//	07/15/99 David E. Berry
//		Implemented the Boyer-Moore String searching  algorithm.
//
//	07/20/99 David E. Berry
//		Implemented single character wildcards
//
//	08/10/99
//		Implement multicharacter wildcards
//
//	08/23/99
//		Implemented character substitution.
//
///////////////////////////////////////////////////////////////

#if !defined(UNIX)
	#include <windows.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "regex.h"

//
//	CRegEx::Initialize
//
//	void CRegEx::Initialize()
//
//	Description
//		Initialize the member variables in the class CRegEx
//
//	Parameters
//		None.
//
//	Return Values
//		None.
//		
void CRegEx::Initialize()
{
	textRegEx = (char *)NULL;			// This will be specified by caller
	compiledRegEx = (REGEX_CH *)NULL;	// Will allocate during Compile
	lead=0;							// lead wildcards
	beginMatch=false;				// ^ beginning of buffer match
	endMatch=false;					// $ end of buffer match
	nextRegEx = (CRegEx *)NULL;		// The next string to look for
	creLength = 0;					// The length of the compiled regex
}

//
//	CRegEx::CRegEx
//
//	CRegEx::CRegEx()
//
//	Description
//		The default constructor for CRegEx. This is the constructor that
//		will be used from most calling programs.  
//
//	Parameters
//		None.
//
//	Return Values
//		None.
//		
CRegEx::CRegEx()
{
	Initialize();	// Initialize the class
}

//
//	CRegEx::CRegEx
//
//	CRegEx::CRegEx(LPTSTR new_regex, bool begin/*=false*/, bool end/*=false*/)
//
//	Description
//		This constructor was developed because I needed a simple way to match 
//		wildcards. Wildcards at the beginning and end of a regular expression
//		were the easiest to code for so I completed them first. I then realized 
//		that I could break the regex up around wildcards and use CRegEx recursively.
//		Since I strip out wildcards from the first regex I didn't want to have to put them
//		back in for the recursive call and all I needed was the bools that were already set.
//		So we pass them in here.
//
//		It can also be used by a programmer that knows the regex when he instantiates
//		this class, e.g. CRegEx cre("^*$");
//
//	Parameters
//		new_regex
//			The string that we are searching for.
//
//		begin
//			A bool that says that we must match from the start of the buffer.
//
//		end 
//			A bool that says the match must be to the end of the string
//
//	Return Values
//		None.
//		
CRegEx::CRegEx(LPCTSTR new_regex, bool begin/*=false*/, bool end/*=false*/)
{
	Initialize();		// Initialize the class
	SetRegEx(new_regex, begin, end);// Compile and Set the RegEx
}

//
//	CRegEx::~CRegEx
//
//	CRegEx::~CRegEx()
//
//	Description
//		Performs the cleanup of all the memory allocated.
//
//	Parameters
//		None.
//
//	Return Values
//		None.
//		
CRegEx::~CRegEx()
{
	DeleteTextRegEx();		// Delete the storage for the TextRegEx
	DeleteCompiledRegEx();	// Delete the storage for the Compiled Reg Ex
}

//
//	CRegEx::DeleteTextRegEx
//
//	void CRegEx::DeleteTextRegEx()
//
//	Description
//		Cleans up the memory allocated for the Text regular expression
//
//	Parameters
//		None.
//
//	Return Values
//		None.
//		
void CRegEx::DeleteTextRegEx()
{
	if (textRegEx != NULL)		// Delete it if it is not NULL
	{
		delete [] textRegEx;	// Perform the delete
		textRegEx = NULL;		// Get rid of invalid ptr information
	}
}

//
//	CRegEx::DeleteCompiledRegEx
//
//	void CRegEx::DeleteCompiledRegEx()
//
//	Description
//		Cleans up the memory allocated for the Compiled regular expression
//
//	Parameters
//		None.
//
//	Return Values
//		None.
//		
void CRegEx::DeleteCompiledRegEx()
{
REGEX_CH *pCRE = compiledRegEx;	// Temp ptr to the cre

	if (compiledRegEx != NULL)	// Delete it if it is not NULL
	{
		// Loop Through the structure and delete all
		// the multicharacter arrays
		while ((*pCRE).ch != RE_EOS)
		{
			if ((*pCRE).ch == RE_MULTI)
				delete [] (*pCRE).multiChar;
			pCRE++;
		}
		// Now delete the structure itself
		delete [] compiledRegEx;

		// Reset member variables in case this CRegEx is re-used
		compiledRegEx = NULL;	// Get rid of invalid ptr information
		creLength=0;
		lead=0;
	}

	if (nextRegEx != NULL)
	{
		delete nextRegEx;
		nextRegEx = NULL;
	} 
}

//
//	CRegEx::Compile
//
//	bool CRegEx::Compile(bool ParseBeginEnd /* = true */)
//
//	Description
//		Compiles a test regex into a structure that can be used to easily find 
//		Matches.
//
//	Parameters
//		bool ParseBeginEnd
//			true - Tells the compiler to look for the '^' and '$' characters.
//			false - Tells the compiler to ignore the '^' and '$' characters.
//
//	Return Values
//		true - Indicates the compile was successful.
//		false - Indicates the compile was failed.
//		
bool CRegEx::Compile(bool ParseBeginEnd /* = true */)
{
	LPTSTR trePtr = (LPTSTR)textRegEx;	// Ptr to the Text Regex
	size_t treLen = _tcslen(textRegEx);	// Len of the Text Regex
	REGEX_CH *crePtr;					// Ptr to the compiled Regex
	int i;

	// Allocate a new Array of Regex characters and 
	// assign it to the member variable and the temp variable
	crePtr = compiledRegEx = new REGEX_CH[treLen*2];

	if (crePtr == NULL)
		return false;		// No memory, No Compile

	if (ParseBeginEnd)
	{
		if (trePtr[treLen-1]==_T('$')) //end match
		{
			endMatch=true;				// Match to the end of the buffer
			trePtr[treLen-1]=_T('\0');  // remove the character from the end of the string
		}

		if (*trePtr == _T('^'))	//begin match
		{
			beginMatch = true;	// Match from the beginning of the buffer
			trePtr++;			// Go To next char
		}
	}

	// Get rid of lead wild cards, we know that they match
	while (*trePtr == _T('?') || *trePtr == _T('*'))
	{
		if (lead != -1)
		{
			if (*trePtr == _T('*'))
			{
				// Once we get * we automatically match from the beginning
				// to wherever the actual chars in the regex occur in the buffer
				// so take off the begin match so we will search the entire buffer
				beginMatch = false;
				lead = -1;		
			}
			else
			{
				beginMatch = true;
				lead++;
			}
		}
		trePtr++;
	}

	while (*trePtr != _T('\0'))
	{
		if (*trePtr == '\\' )	// Literal char so take next char
			(*crePtr).ch = (wchar_t)*++trePtr;
		else if (*trePtr == _T('*'))	// Wildcard zero or more chars
		{
			nextRegEx = new CRegEx((LPTSTR)trePtr, false, endMatch);
			endMatch=false;	// delegate the end Match
			break;
		}
		else if (*trePtr == _T('?'))	// wildcard zero or one chars
		{
			nextRegEx = new CRegEx((LPTSTR)trePtr,true,endMatch);
			endMatch = false; // delegate the end Match
			break;
		}
		else if (*trePtr == _T('['))
		{
			// The character in the buffer must match one of the characters
			// in the set of chars between the brackets.
			trePtr++;
			(*crePtr).ch = RE_MULTI;
			int nrChars = 0;
			for (i=0; trePtr[i]!=_T('\0'); i++)
			{
				nrChars++;
				// allow escaping of ']' and '\'
				if ( (trePtr[i] == _T('\\')) && (trePtr[i+1] != _T('\0')) )
					i++;
				else if (trePtr[i] == _T(']'))
					break;
			}

			if (trePtr[i] == _T('\0'))
			{
				(*crePtr).ch = RE_EOS;	// So the cleanup works later
				return false;
			}

			(*crePtr).multiChar = new wchar_t[nrChars+1];
			i=0;
			while (*trePtr!=_T(']'))
			{
				if (*trePtr==_T('\\')) // allow escaping of ']' and '\'
					trePtr++;
				(*crePtr).multiChar[i++] = (wchar_t) (*trePtr++);
			}
			(*crePtr).multiChar[i] = RE_EOS;
		}
		else
			(*crePtr).ch = *trePtr;

		creLength++;
		crePtr++;
		trePtr++;
	}

	(*crePtr).ch = RE_EOS;

	return true;
}

//
//	CRegEx::SetRegex
//
//	bool CRegEx::SetRegex(LPCTSTR regex,bool begin /*=false*/, bool end /*=false*/)
//
//	Description
//		Stores the regex to be matched and calls the compiler.
//
//	Parameters
//		regex
//			The regular expression that we will try to match.
//		begin
//			true - Force a match at the beginning of the buffer.
//		end
//			true - Force a match at the end of the buffer.
//		if begin and end are both false, Compile will look for the special characters.
//
//	Return Values
//		true - Indicates that the regex was accepted.
//		false - Indicates the regex was rejected.
//		
bool CRegEx::SetRegEx(LPCTSTR regex,bool begin /*=false*/, bool end /*=false*/)
{
	bool rc = false;

	DeleteTextRegEx();		// Get rid of any prior regex.
	DeleteCompiledRegEx();	// Delete the old compiled data;

	beginMatch=begin;
	endMatch=end;

	if (regex != NULL)		// No regex, then fail.
	{
		// Let's keep our own copy of it
		// and compile it.
		textRegEx = new TCHAR[_tcslen(regex)+1];
		if (textRegEx != NULL)
		{
			_tcscpy(textRegEx, regex);
			rc = Compile(!(beginMatch|endMatch));
			// If it compiles OK then set up the Boyer-Moore 
			// Skip Table
			if (rc==true)
				InitSkipTable();
		}
	}

	return rc;
}

//
//	CRegEx::InitSkipTable
//
//	void CRegEx::InitSkipTable()
//
//	Description
//		Initializes the skip table required for the Boyer-Moore 
//		string searching algorithm.
//
//	Parameters
//		None.
//
//	Return Values
//		None.
//		
void CRegEx::InitSkipTable()
{
	int j;
	int skiplen;
	wchar_t *pMulti;

	// The default skip length is the size of the pattern that we
	// are trying to match character.
	skiplen = creLength;

	for (j=0; j<TMAXCHAR; j++)
		skip[j]=skiplen;

	// We then look through the pattern, from right to left and
	// calculate the skip length as the distance of that character 
	// from the end of the string.
	for (j=0; j<creLength; j++)
	{
		if (compiledRegEx[j].ch == RE_MULTI)
		{
		// A RE_MULTI can match any char in the array. So we must reset 
		// the skip for each character in the array.
			pMulti = compiledRegEx[j].multiChar;
			while (*pMulti != RE_EOS)
				skip[*pMulti++] = skiplen-j-1;
		}
		else
			skip[compiledRegEx[j].ch] = skiplen-j-1;
	}
}

//
//	CRegEx::MatchChar
//
//	bool CRegEx::MatchChar(TCHAR ch, int creIndex)
//
//	Description
//		Compares the character in the buffer to the character in the 
//		compiled regular expression.
//
//	Parameters
//		ch - The character to match
//		creIndex - The index to the REGEX_CH that we are comparing.
//
//	Return Values
//		true - Character Matches
//		false - Character did not match
//		
bool CRegEx::MatchChar(TCHAR ch, int creIndex)
{
	wchar_t *pMulti;

	// If it is an array, compare to all chars in the array
	if (compiledRegEx[creIndex].ch == RE_MULTI)
	{
		pMulti = compiledRegEx[creIndex].multiChar;

		while (*pMulti != ch && *pMulti != RE_EOS)
			pMulti++;

		return (ch == *pMulti);
	}

	// else just compare it to the character
	return (ch == compiledRegEx[creIndex].ch);
}


//
//	CRegEx::Match
//
//	LPCTSTR CRegEx::Match(LPCTSTR text, int textLen, int &matchLen)
//
//	Description
//		Tries to find an ocurrence of the regex in the text.
//		Doesn't allow to change content of the returned pointer (it's LPCTSTR)
//
//	Parameters
//		text - The text in which to find a match.
//		textLen - The size of the text passed in.
//		matchLen - The length of the match
//			Length of match is returned so that if you need to highlight 
//			a match in a gui, you know how many chars to highlight
//
//	Return Values
//		NULL - No Match.
//		!NULL - A pointer to the first character in the matching string
//		
LPCTSTR CRegEx::Match(LPCTSTR text, int textLen, int &matchLen)
{
	int i,j;
	LPCTSTR MatchStart=NULL;
	int nextMatchLen=0;
	
	matchLen=0;		// We haven't matched anything yet.

	// If there is no text then there is no match
	if (text==NULL || textLen==0)
		return NULL;

	if (compiledRegEx==NULL || creLength == 0)
	{
		// Since we strip wild cards, we need to see if the 
		// compiled regex was empty because it was all wildcards
		// or if it was really empty

		if (lead==0)		// It was empty to begin with
			return (NULL);
		else if (lead == -1)	// We had a '*', so match everything
			matchLen=_tcslen((LPTSTR)text);
		else
			matchLen=lead;		// We had '?'s so match them

		return text;
	}

	// This is the actually code for the Boyer-Moore string search
	// This for loop and the InitSkipTable are the only two pieces of 
	// code you need for Boyer-Moore. This routine performs a right to left string comparison of the
	// pattern and the text. 
	// 
	// Normally we start comparing at the start of text +
	// the size of crelength -1. This has us compare the last character 
	// of the pattern with the correct character in the text. If 
	// we were given the '$' end of text match then we start comparing 
	// with the last char of the pattern, and the last char of text.
	j=creLength-1;
	i=endMatch?textLen-1:creLength-1; 
	do
	{
		for (;j>=0; i--,j--)
		{
			while (!MatchChar(text[i],j))
			{
				//It did not match so let's increment our text index
				// by the skip distance
				i+=(creLength-j > skip[text[i]]) ? creLength-j:skip[text[i]] ;

				// Set j to last char in pattern
				j = creLength-1;

				// If we index past the end of the text then no match
				// If the match must be at the beginning of the buffer
				// and i is greater than the start of text plus the pattern
				// length, then there is no match
				if (i >= textLen || (beginMatch==true && i-j>lead)) 
					return NULL;
			}
		}

		i++;	// point i to the first char in the matching text

		if (beginMatch==true && i>lead) 
			return NULL;

		// Do we have any more partial patterns to look for
		if (nextRegEx != NULL)
		{
			if (nextRegEx->Match(text+i+creLength,textLen-i-creLength, nextMatchLen) == NULL)
			{
				i+=creLength;
				j = creLength-1;
				if (i >= textLen || (beginMatch==true && i-j>lead)) 
					return NULL;
			}
			else
			{
				matchLen+=nextMatchLen;
				break;
			}
		}
		else
			break;
	} while (i < textLen-creLength);

	if (lead==-1)
	{
		MatchStart = text;
		matchLen += i+creLength;
	}
	else
	{
		if (lead>i) lead = i;
		MatchStart = (LPCTSTR) (text+i-lead);
		matchLen += creLength+lead;
	}
	return (LPCTSTR)MatchStart;
}

//
//	CRegEx::Match
//
//	LPTSTR CRegEx::Match(LPTSTR text, int textLen, int &matchLen)
//
//	Description
//		Tries to find an ocurrence of the regex in the text.
//		Allows to change content of the returned pointer (if not NULL)
//
//	Parameters
//		text - The text in which to find a match.
//		textLen - The size of the text passed in.
//		matchLen - The length of the match
//			Length of match is returned so that if you need to highlight 
//			a match in a gui, you know how many chars to highlight
//
//	Return Values
//		NULL - No Match.
//		!NULL - A pointer to the first character in the matching string
//		
LPTSTR CRegEx::Match(LPTSTR text, int textLen, int &matchLen)
{
	LPCTSTR rv = Match((LPCTSTR)text, textLen, matchLen); // call LPCTSTR overloaded function
	if (rv==NULL) return NULL;
	return text+(rv-(LPCTSTR)text);
}
