#ifndef __REGEX_H__
#define __REGEX_H__
/*---------------------------------------------------------------------------
 *
 *  FILE NAME:      regex.h.
 *
 *  FILE DESCR:     Header File for the CRegEx class.
 *
 *  PROJECT NAME:   C++ Class that performs Regular Expression Matching
 *
 *  PROJECT DESCR:  Expand the Boyer-Moore String Searching Methodology to 
 *                                      include regular expression matching
 *
 *  SOURCE LANG:    C++.
 *
 *  SOURCE VARIANT: Microsoft Visual C++ 6.0
 *
 *  AUTHOR:         David E. Berry.
 *
 *  DATE WRITTEN    07/15/99.
 *
 *  COPYRIGHT:      Copyright (c) 1999-2000, David E. Berry. All rights reserved.
 *
 *  GENERAL DESCR:
 *       
 --------------------------------------------------------------------------*/

#if defined(UNIX)
        typedef int bool;
        typedef char TCHAR;
        typedef char * LPTSTR;
		typedef const char * LPCTSTR;
        #define _tcslen strlen
        #define _tcscpy strcpy
        #define _T(x)   x
        #define false FALSE
        #define true TRUE
#else
        #include <tchar.h>
#endif

#define RE_EOS          ((wchar_t)-1)   // End of String Marker
#define RE_MULTI        ((wchar_t)-2)   // This is an array of chars for this spot


        // The skip table needs to have entries for all characters in the given character set
        // I have included the ascii set but have not set it up for Multi-byte or Unicode
        // The size will be dependent on the locale

#if defined(_UNICODE)
// Need to find the Maximum # of chars used for UNICODE
        #pragma message  (_T("TMAXCHAR may need to be larger than 256 for _UNICODE"))
        #define TMAXCHAR 256
#elif defined (_MBCS)
        #pragma message  (_T("TMAXCHAR may need to be larger than 256 for _MBCS"))
        #define TMAXCHAR 256
#else
        #define TMAXCHAR 256
#endif

/*
 * struct REGEX_CH
 *
 * This structure defines a character in a regular expression
 * it can be a single character in which case ch is the character 
 * and multiChar is NULL, or it can represent a group of characters
 * that are valid in that location. For a group of character, ch = RE_MULTI
 * and multiChar is a null terminated array of characters.
 */

struct REGEX_CH 
{
        wchar_t ch;
        wchar_t *multiChar;
};

class CRegEx
{
private: //Attributes
        LPTSTR          textRegEx;              // text regular expression
        REGEX_CH        *compiledRegEx; // compiled regex
        int                     creLength;              // length of the compiled regex
        int                     skip[TMAXCHAR]; // This is the BMS skip table
        int                     lead;                   // lead wildcards
        bool            beginMatch;             // ^ beginning of buffer match
        bool            endMatch;               // $ end of buffer match
        CRegEx          *nextRegEx;             // The next string to look for

private: // Methods
        void Initialize();                      // Initializes all the variables/structures
        bool Compile(bool ParseBeginEnd = true);                                // Compiles the text RegEx
        void DeleteTextRegEx();         // Frees memory for the textRegEx
        void DeleteCompiledRegEx();     // Frees memory for the compiledRegEx
        void InitSkipTable();           // Initializes the SkipTable
        bool MatchChar(TCHAR ch, int creIndex); // Matches a character against the Compiled Regex

public: // Methods
        CRegEx();       
        CRegEx(LPCTSTR regex, bool begin=false, bool end=false); 
        ~CRegEx();
        
        bool SetRegEx(LPCTSTR regex, bool begin=false, bool end=false);
        LPTSTR Match(LPTSTR text, int length, int &matchLen);
		LPCTSTR Match(LPCTSTR text, int length, int &matchLen);
};

#endif //__REGEX_H__
