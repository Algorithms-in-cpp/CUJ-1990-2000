#ifndef _STL_SUPPL_INCLUDED
#define _STL_SUPPL_INCLUDED

// COPYRIGHT (C) 2000 Thomas Becker
//
// PERMISSION NOTICE:
//
// PERMISSION TO USE, COPY, MODIFY, AND DISTRIBUTE THIS SOFTWARE FOR ANY
// PURPOSE AND WITHOUT FEE IS HEREBY GRANTED, PROVIDED THAT ALL COPIES
// ARE ACCOMPANIED BY THE COMPLETE MACHINE-READABLE SOURCE CODE, ALL
// MODIFIED FILES CARRY PROMINENT NOTICES AS TO WHEN AND BY WHOM THEY
// WERE MODIFIED, THE ABOVE COPYRIGHT NOTICE, THIS PERMISSION NOTICE AND
// THE NO-WARRANTY NOTICE BELOW APPEAR IN ALL SOURCE FILES AND IN ALL
// SUPPORTING DOCUMENTATION.
//
// NO-WARRANTY NOTICE:
//
// THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY.
// ALL IMPLIED WARRANTIES OF FITNESS FOR ANY PARTICULAR PURPOSE AND OF
// MERCHANTABILITY ARE HEREBY DISCLAIMED.

//
// File: StlSuppl.h
// 
// Created: Feb 2000
//
// Author: Thomas Becker
//
// Description:
// ============
//
// Some additions to the C++ Standard Template Library:
//
// 1) Const member function adapters. These are now part of the 
//    standard, but they not provided in all implementations yet.
//    To disable these, uncomment the next line.
//    #define _EXCLUDE_CONST_MEM_FUN_ADAPTERS
//
// 2) Member function adapters that work for member functions returning
//    void.
//
// 3) Logical conjunction and disjunction adapters for predicates.
//
// 4) Composition of functionals. These are not part of the C++ 
//    standard, but some implementations provide the ones for
//    functionals returning non-void. To disable these, uncomment the
//    next line.
//    #define _EXCLUDE_NON_VOID_COMPOSITION_ADAPTERS
//
// 5) Binary search algorithm for ordered sequences.
//

#include<functional>
#include<algorithm>

namespace std_suppl
{

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for const member functions 
// taking no argument. The call is made through a pointer.
//
#ifndef _EXCLUDE_CONST_MEM_FUN_ADAPTERS
//
template<class R, class T>
class const_mem_fun_t : public std::unary_function<const T*, R> 
{
public:
  explicit const_mem_fun_t(R (T::*pMemFun)() const)
    : m_pMemFun(pMemFun) {}
  R operator()(const T* p) const
  { return (p->*m_pMemFun)(); }
private:
  R (T::*m_pMemFun)() const;
};
//
template<class R, class T> inline
const_mem_fun_t<R, T> mem_fun(R (T::*pMemFun)() const)
{ return const_mem_fun_t<R, T>(pMemFun); }
//
#endif

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for const member functions 
// taking one argument. The call is made through a pointer.
//
#ifndef _EXCLUDE_CONST_MEM_FUN_ADAPTERS
//
template<class R, class T, class A>
class const_mem_fun1_t : public std::binary_function<const T*, A, R> {
public:
  explicit const_mem_fun1_t(R (T::*pMemFun)(A) const)
    : m_pMemFun(pMemFun) {}
  R operator()(const T* p, A arg) const
  { return (p->*m_pMemFun)(arg); }
private:
  R (T::*m_pMemFun)(A) const;
};
//
template<class R, class T, class A> inline
const_mem_fun1_t<R, T, A> mem_fun1(R (T::*pMemFun)(A) const)
{ return const_mem_fun1_t<R, T, A>(pMemFun); }
//
#endif

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for const member functions 
// taking no argument. The call is made through a reference.
//
#ifndef _EXCLUDE_CONST_MEM_FUN_ADAPTERS
//
template<class R, class T>
class const_mem_fun_ref_t : public std::unary_function<const T&, R> {
public:
  explicit const_mem_fun_ref_t(R (T::*pMemFun)() const)
    : m_pMemFun(pMemFun) {}
  R operator()(const T& ref) const
  {return (ref.*m_pMemFun)(); }
private:
  R (T::*m_pMemFun)() const;
};
//
template<class R, class T> inline
const_mem_fun_ref_t<R, T> mem_fun_ref(R (T::*pMemFun)() const)
{return const_mem_fun_ref_t<R, T>(pMemFun); }
//
#endif

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for const member functions 
// taking one argument. The call is made through a reference.
//
#ifndef _EXCLUDE_CONST_MEM_FUN_ADAPTERS
//
template<class R, class T, class A>
class const_mem_fun1_ref_t : public std::binary_function<const T&, A, R> {
public:
  explicit const_mem_fun1_ref_t(R (T::*pMemFun)(A) const)
    : m_pMemFun(pMemFun) {}
  R operator()(const T& ref, A arg) const
  {return (ref.*m_pMemFun)(arg); }
private:
  R (T::*m_pMemFun)(A) const;
};
//
template<class R, class T, class A> inline
const_mem_fun1_ref_t<R, T, A> mem_fun1_ref(R (T::*pMemFun)(A) const)
{ return const_mem_fun1_ref_t<R, T, A>(pMemFun); }
//
#endif

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for member functions taking no 
// argument and returning void. The call is made through a pointer.
//
template<class T>
class void_mem_fun_t : public std::unary_function<T*, void> {
public:
  explicit void_mem_fun_t(void (T::*pMemFun)())
    : m_pMemFun(pMemFun) {}
  void operator()(T* p) const
  { (p->*m_pMemFun)(); }
private:
  void (T::*m_pMemFun)();
};
//
template<class T> inline
void_mem_fun_t<T> void_mem_fun(void (T::*pMemFun)())
{ return void_mem_fun_t<T>(pMemFun); }

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for member functions taking one 
// argument and returning void. The call is made through a pointer.
//
template<class T, class A>
class void_mem_fun1_t : public std::binary_function<T*, A, void> {
public:
  explicit void_mem_fun1_t(void (T::*pMemFun)(A))
    : m_pMemFun(pMemFun) {}
  void operator()(T* p, A arg) const
  { (p->*m_pMemFun)(arg); }
private:
  void (T::*m_pMemFun)(A);
};
//
template<class T, class A> inline
void_mem_fun1_t<T, A> void_mem_fun1(void (T::*pMemFun)(A))
{ return void_mem_fun1_t<T, A>(pMemFun); }

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for member functions taking no 
// argument and returning void. The call is made through a reference.
//
template<class class T>
class void_mem_fun_ref_t : public std::unary_function<T&, void> {
public:
  explicit void_mem_fun_ref_t(void (T::*pMemFun)())
    : m_pMemFun(pMemFun) {}
  void operator()(T& ref) const
  { (ref.*m_pMemFun)(); }
private:
  void (T::*m_pMemFun)();
};
//
template<class T> inline
void_mem_fun_ref_t<T> void_mem_fun_ref(void (T::*pMemFun)())
{ return void_mem_fun_ref_t<T>(pMemFun); }

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for member functions taking one 
// argument and returning void. The call is made through a reference.
//
template<class T, class A>
class void_mem_fun1_ref_t : public std::binary_function<T&, A, void> {
public:
  explicit void_mem_fun1_ref_t(void (T::*pMemFun)(A))
    : m_pMemFun(pMemFun) {}
  void operator()(T& ref, A arg) const
  { (ref.*m_pMemFun)(arg); }
private:
  void (T::*m_pMemFun)(A);
};
//
template<class T, class A> inline
void_mem_fun1_ref_t<T, A> void_mem_fun1_ref(void (T::*pMemFun)(A))
{ return void_mem_fun1_ref_t<T, A>(pMemFun); }

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for const member functions 
// taking no argument and returning void. The call is made through a 
// pointer.
//
template<class T>
class void_const_mem_fun_t : public std::unary_function<const T*, void> {
public:
  explicit void_const_mem_fun_t(void (T::*pMemFun)() const)
    : m_pMemFun(pMemFun) {}
  void operator()(const T* p) const
  { (p->*m_pMemFun)(); }
private:
  void (T::*m_pMemFun)() const;
};
//
template<class T> inline
void_const_mem_fun_t<T> void_mem_fun(void (T::*pMemFun)() const)
{ return void_const_mem_fun_t<T>(pMemFun); }

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for const member functions 
// taking one argument and returning void. The call is made through a 
// pointer.
//
template<class T, class A>
class void_const_mem_fun1_t : public std::binary_function<const T*, A, void> {
public:
  explicit void_const_mem_fun1_t(void (T::*pMemFun)(A) const)
    : m_pMemFun(pMemFun) {}
  void operator()(const T* p, A arg) const
  { (p->*m_pMemFun)(arg); }
private:
  void (T::*m_pMemFun)(A) const;
};
//
template<class T, class A> inline
void_const_mem_fun1_t<T, A> void_mem_fun1(void (T::*pMemFun)(A) const)
{ return void_const_mem_fun1_t<T, A>(pMemFun); }

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for const member functions 
// taking no argument and returning void. The call is made through a 
// reference.
//
template<class class T>
class void_const_mem_fun_ref_t : public std::unary_function<const T&, void> {
public:
  explicit void_const_mem_fun_ref_t(void (T::*pMemFun)() const)
    : m_pMemFun(pMemFun) {}
  void operator()(const T& ref) const
  { (ref.*m_pMemFun)(); }
private:
  void (T::*m_pMemFun)() const;
};
//
template<class T> inline
void_const_mem_fun_ref_t<T> void_mem_fun_ref(void (T::*pMemFun)() const)
{ return void_const_mem_fun_ref_t<T>(pMemFun); }

///////////////////////////////////////////////////////////////////////
//
// Member function adapter that works for const member functions 
// taking no argument and returning void. The call is made through a 
// reference.
//
template<class T, class A>
class void_const_mem_fun1_ref_t : public std::binary_function<const T&, A, void> {
public:
  explicit void_const_mem_fun1_ref_t(void (T::*pMemFun)(A) const)
    : m_pMemFun(pMemFun) {}
  void operator()(const T& ref, A arg) const
  { (ref.*m_pMemFun)(arg); }
private:
  void (T::*m_pMemFun)(A) const;
};
//
template<class T, class A> inline
void_const_mem_fun1_ref_t<T, A> void_mem_fun1_ref(void (T::*pMemFun)(A) const)
{ return void_const_mem_fun1_ref_t<T, A>(pMemFun); }

///////////////////////////////////////////////////////////////////////
//
// Adapter that forms the logical conjunction of two predicates taking
// one argument.
//
template<class Ufn1, class Ufn2>
class unary_and : public std::unary_function<Ufn1::argument_type, bool> {
public:
  explicit unary_and(Ufn1 Fn1, Ufn2 Fn2)
    : m_Fn1(Fn1), m_Fn2(Fn2) {}
  bool operator()(Ufn1::argument_type arg) const
  { return m_Fn1(arg) && m_Fn2(arg); }
private:
  Ufn1 m_Fn1;
  Ufn2 m_Fn2;
};
//
template<class Ufn1, class Ufn2>
unary_and<Ufn1, Ufn2> and1(Ufn1 Fn1, Ufn2 Fn2)
{ return unary_and<Ufn1, Ufn2>(Fn1, Fn2); }

///////////////////////////////////////////////////////////////////////
//
// Adapter that forms the logical disjunction of two predicates taking
// one argument.
//
template<class Ufn1, class Ufn2>
class unary_or : public std::unary_function<Ufn1::argument_type, bool> {
public:
  explicit unary_or(Ufn1 Fn1, Ufn2 Fn2)
    : m_Fn1(Fn1), m_Fn2(Fn2) {}
  bool operator()(Ufn1::argument_type arg) const
  { return m_Fn1(arg) || m_Fn2(arg); }
private:
  Ufn1 m_Fn1;
  Ufn2 m_Fn2;
};
//
template<class Ufn1, class Ufn2>
unary_or<Ufn1, Ufn2> or1(Ufn1 Fn1, Ufn2 Fn2)
{ return unary_or<Ufn1, Ufn2>(Fn1, Fn2); }

///////////////////////////////////////////////////////////////////////
//
// Adapter that forms the logical conjunction of two predicates taking
// two arguments.
//
template<class Bfn1, class Bfn2>
class binary_and : public std::binary_function<Bfn1::first_argument_type, Bfn1::second_argument_type, bool> {
public:
  explicit binary_and(Bfn1 Fn1, Bfn2 Fn2)
    : m_Fn1(Fn1), m_Fn2(Fn2) {}
  bool operator()(Bfn1::first_argument_type arg1, Bfn1::second_argument_type arg2) const
  { return m_Fn1(arg1, arg2) && m_Fn2(arg1, arg2); }
private:
  Bfn1 m_Fn1;
  Bfn2 m_Fn2;
};
//
template<class Bfn1, class Bfn2>
binary_and<Bfn1, Bfn2> and2(Bfn1 Fn1, Bfn2 Fn2)
{ return binary_and<Bfn1, Bfn2>(Fn1, Fn2); }

///////////////////////////////////////////////////////////////////////
//
// Adapter that forms the logical disjunction of two predicates taking
// two arguments.
//
template<class Bfn1, class Bfn2>
class binary_or : public std::binary_function<Bfn1::first_argument_type, Bfn1::second_argument_type, bool> {
public:
  explicit binary_or(Bfn1 Fn1, Bfn2 Fn2)
    : m_Fn1(Fn1), m_Fn2(Fn2) {}
  bool operator()(Bfn1::first_argument_type arg1, Bfn1::second_argument_type arg2) const
  { return m_Fn1(arg1, arg2) || m_Fn2(arg1, arg2); }
private:
  Bfn1 m_Fn1;
  Bfn2 m_Fn2;
};
//
template<class Bfn1, class Bfn2>
binary_or<Bfn1, Bfn2> or2(Bfn1 Fn1, Bfn2 Fn2)
{ return binary_or<Bfn1, Bfn2>(Fn1, Fn2); }

///////////////////////////////////////////////////////////////////////
//
// Adapter that forms the composition of two unary functionals.
//
#ifndef _EXCLUDE_NON_VOID_COMPOSITION_ADAPTERS
//
template<class Ufn1, class Ufn2>
class unary_compose : public std::unary_function<Ufn2::argument_type, Ufn1::result_type> {
public:
  explicit unary_compose(Ufn1 Fn1, Ufn2 Fn2)
    : m_Fn1(Fn1), m_Fn2(Fn2) {}
  Ufn1::result_type operator()(Ufn2::argument_type arg)
  { return m_Fn1(m_Fn2(arg)); }
private:
  Ufn1 m_Fn1;
  Ufn2 m_Fn2;
};
//
template<class Ufn1, class Ufn2>
unary_compose<Ufn1, Ufn2> compose1(Ufn1 Fn1, Ufn2 Fn2)
{ return unary_compose<Ufn1, Ufn2>(Fn1, Fn2); }
//
#endif

///////////////////////////////////////////////////////////////////////
//
// Adapter that forms the composition of a unary and a binary
// functional.
//
#ifndef _EXCLUDE_NON_VOID_COMPOSITION_ADAPTERS
//
template<class Ufn, class Bfn>
class binary_compose : public std::binary_function<Bfn::first_argument_type, Bfn::second_argument_type, Ufn::result_type> {
public:
  explicit binary_compose(Ufn Fn1, Bfn Fn2)
    : m_Fn1(Fn1), m_Fn2(Fn2) {}
  Ufn::result_type operator()(Bfn::first_argument_type arg1, Bfn::second_argument_type arg2)
  { return m_Fn1(m_Fn2(arg1, arg2)); }
private:
  Ufn m_Fn1;
  Bfn m_Fn2;
};
//
template<class Ufn, class Bfn>
binary_compose<Ufn, Bfn> compose2(Ufn Fn1, Bfn Fn2)
{ return binary_compose<Ufn, Bfn>(Fn1, Fn2); }
//
#endif

///////////////////////////////////////////////////////////////////////
//
// Adapter that forms the composition of two unary functionals 
// returning void.
//
template<class Ufn1, class Ufn2>
class void_unary_compose : public std::unary_function<Ufn2::argument_type, void> {
public:
  explicit void_unary_compose(Ufn1 Fn1, Ufn2 Fn2)
    : m_Fn1(Fn1), m_Fn2(Fn2) {}
  void operator()(Ufn2::argument_type arg)
  { m_Fn1(m_Fn2(arg)); }
private:
  Ufn1 m_Fn1;
  Ufn2 m_Fn2;
};
//
template<class Ufn1, class Ufn2>
void_unary_compose<Ufn1, Ufn2> void_compose1(Ufn1 Fn1, Ufn2 Fn2)
{ return void_unary_compose<Ufn1, Ufn2>(Fn1, Fn2); }

///////////////////////////////////////////////////////////////////////
//
// Adapter that forms the composition of a unary with a binary 
// functional returning void.
//
template<class Ufn, class Bfn>
class void_binary_compose : public std::binary_function<Bfn::first_argument_type, Bfn::second_argument_type, void> {
public:
  explicit void_binary_compose(Ufn Fn1, Bfn Fn2)
    : m_Fn1(Fn1), m_Fn2(Fn2) {}
  void operator()(Bfn::first_argument_type arg1, Bfn::second_argument_type arg2)
  { m_Fn1(m_Fn2(arg1, arg2)); }
private:
  Ufn m_Fn1;
  Bfn m_Fn2;
};
//
template<class Ufn, class Bfn>
void_binary_compose<Ufn, Bfn> void_compose2(Ufn Fn1, Bfn Fn2)
{ return void_binary_compose<Ufn, Bfn>(Fn1, Fn2); }

///////////////////////////////////////////////////////////////////////
//
// Binary find algorithm using operator <.
//
template<class RanIt, class T> inline
RanIt lower_bound_find(RanIt first, RanIt last, const T& val)
{
  RanIt lb = std::lower_bound(first, last, val);
  if( lb == last)
    return last;
  else if( *lb != val )
    return last;
  else
    return lb;
}

///////////////////////////////////////////////////////////////////////
//
// Binary find algorithm using operator a predicate.
//
template<class RanIt, class T, class Pred> inline
RanIt lower_bound_find(RanIt first, RanIt last, const T& val, Pred pred)
{
  RanIt lb = std::lower_bound(first, last, val, pred);
  if( lb == last)
    return last;
  else if( *lb != val )
    return last;
  else
    return lb;
}

} // end namespace std_suppl

#endif // end multiple inclusion protection
