//-----------------------------------------------------------------------------
// son.h - Supporting function for the Self-Organizing Neural Network (SON)
//-----------------------------------------------------------------------------
void Save_Weights( char filename[], 
				   double W[MAX_ROWS][MAX_COLS][MAX_INPUT_NODES], 
				   int rows, int cols, int num_input_nodes, long iteration,
				   double learning_rate, int neighborhood)
	{
	FILE *outfile;
	int i,j,k;

	outfile=fopen("output.dat","a");   // Open file to append weight values
	fprintf(outfile,"%ld\n",iteration);
	fprintf(outfile,"%lf\n",learning_rate);
	fprintf(outfile,"%d\n",neighborhood);
	fprintf(outfile,"%d\n",rows);	   // Store number of rows in Kohonen layer	
	fprintf(outfile,"%d\n",cols);	   // Store number of columns in Kohonen layer
	fprintf(outfile,"%d\n",num_input_nodes);  // Store number of input layer nodes
	
	for (i=0; i<rows; i++)			  // Store each weight vector	
		for (j=0; j<cols; j++)
			{	
			for (k=0; k<num_input_nodes; k++)
				fprintf(outfile,"%lf ",W[i][j][k]);
			fprintf(outfile,"\n");
			}
	fclose(outfile);
	}
//-----------------------------------------------------------------------------
void Initialize_Weights( double W[MAX_ROWS][MAX_COLS][MAX_INPUT_NODES], 
						 int rows, int cols, int num_input_nodes )
	{
	int i,j,k;
	for (i=0; i<rows; i++)	    // Initialize each weight vector component
		for (j=0; j<cols; j++)  // to a value between 0.0 and 1.0
			for (k=0; k<num_input_nodes; k++)
				W[i][j][k]=((double)rand()/(double)RAND_MAX);
	}
//-----------------------------------------------------------------------------
double Kohonen_Node_Value( double pattern[], double W[], int num_input_nodes)
	{
	int k;
	double sum=0;		
	for (k=0; k<num_input_nodes; k++)		  // Compute Euclidean distance
				sum+=pow(pattern[k]-W[k],2);  // between input pattern vector
	return sqrt(sum);						  // and weight vector	
	}
//-----------------------------------------------------------------------------
void Get_Winning_Node( double pattern[], double W[MAX_ROWS][MAX_COLS][MAX_INPUT_NODES],
					  int num_input_nodes, int rows, int cols, 
					  int *winning_row, int *winning_col )
	{
	double  value;
	double min_value=9999999;
	double sum=0;
	int i,j,k;

	for (i=0; i<rows; i++)        // Find the Kohonen Node with the shortest distance
	   for (j=0; j<cols; j++)
	   	   {
		   value=0;
		   for (k=0; k<num_input_nodes; k++)         // Find the distance between the 
				value+=pow(pattern[k]-W[i][j][k],2); // Input vector and the current
			value=sqrt(value);				         // Kohonen node (i,j)

			if (value<min_value)			   // If the Kohonen node value is 
				{							   // less than the smallest seen,
				min_value=value;			   // store it position (i,j)
				*winning_row=i;
				*winning_col=j;
				}
		   }
	}	
//-----------------------------------------------------------------------------
void Update_Weight_Vectors( double pattern[],
						   double W[MAX_ROWS][MAX_COLS][MAX_INPUT_NODES], 
						   int num_input_nodes, int rows, int cols, 
						   int winning_row, int winning_col,
						   double learning_rate, int neighborhood )
	{
	int i,j,k;
	int row_start, row_stop, col_start, col_stop;

	row_start=winning_row-neighborhood;	  // Find range of neighborhood
	row_stop=winning_row+neighborhood;
	col_start=winning_col-neighborhood;
	col_stop=winning_col+neighborhood;

	if (row_start<0) row_start=0;
	if (row_stop>=rows) row_stop=rows-1;  // Correct range if out of bounds
	if (col_start<0) col_start=0;
	if (col_stop>=cols) col_stop=cols-1;


	
	for (i=row_start; i<=row_stop; i++)	  // Update all weights in neighborhood
		for (j=col_start; j<=col_stop; j++)
			for (k=0; k<num_input_nodes; k++)
				W[i][j][k]+=learning_rate*(pattern[k]-W[i][j][k]);
	}

