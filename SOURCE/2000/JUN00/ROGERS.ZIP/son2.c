//-----------------------------------------------------------------------------
// son2.cpp - Self-Organizing Neural Network (SON) - Example 2
//-----------------------------------------------------------------------------
#include<stdio.h>
#include<math.h>
#include<stdlib.h>



#define MAX_NUM_PATTERNS 1000
#define MAX_INPUT_NODES 2
#define MAX_ROWS 100
#define MAX_COLS 1


#include "son.h"


void main( void )
	{
	double pattern[MAX_NUM_PATTERNS][MAX_INPUT_NODES]; // Training set patterns
	int num_patterns;								   // Number of training patterns

	double W[MAX_ROWS][MAX_COLS][MAX_INPUT_NODES];  // Weight vectors
	
	int num_input_nodes=2;				// Number of node in the Input Layer
	int rows=100;						// Number of rows in Kohonen Layer
	int cols=1;					     	// Number of columns in Kohonen Layer
	double initial_learning_rate=0.50;	// Learning rate when training begins
	double final_learning_rate=0.01;	// Learning rate at last iteration											
	double learning_rate;				// Current Learning rate

	int initial_neighborhood=40;		// Neighborhood size when training begins
	int neighborhood_decrement=125;  	// Iterations between Neighborhood size reduction
	int neighborhood;					// Current Neighborhood size
	long iteration=0;					// Current Iteration
	long num_iterations=5000;			// Number of training iterations to perform
	int winning_row, winning_col;		// Current position of winning Kohonen node

	int id,i,j;							// working variables
	FILE *infile;						// file pointer to read training set patterns
	
	infile=fopen("data1.dat","r");	// Open training set patterns
	if (!infile)
		{
		printf("Unable to open data file\n");
		exit(0);
		}

	fscanf(infile,"%d\n",&num_patterns);		// read number of patterns in file
	fscanf(infile,"%d\n",&num_input_nodes);	    // read number of components in patterns
	for (i=0; i<num_patterns; i++)				// Read each training set pattern
		{
		for (j=0; j<num_input_nodes; j++)
			fscanf(infile,"%lf ",&pattern[i][j]);
		fscanf(infile,"\n");
		}	
	
	printf("Number of Patterns: %d\n", num_patterns);

	Initialize_Weights(W,rows,cols,num_input_nodes);	// Initialize Weight vectors
	
	neighborhood=initial_neighborhood;					// Initialize neighborhood size

	while (iteration<num_iterations)					// Training Loop
		{
		learning_rate=initial_learning_rate-			// Calculate learning rate
					 (((double)iteration/(double)num_iterations)*
					 (initial_learning_rate-final_learning_rate));

														// Decrement neighorbood size
														// if necessary
		if ((iteration+1)%neighborhood_decrement==0 && neighborhood>0)	
					neighborhood--;

		if (iteration%100==0)
			{
			printf("%ld.  Learning Rate: %lf  Neighborhood: %d\n",   // Print status
				   iteration,learning_rate,neighborhood);
			Save_Weights("outfile.dta",W,rows,cols,num_input_nodes,
						 iteration,learning_rate,neighborhood); // Store feature map
			}

		for (id=0; id<num_patterns; id++)	// Present each training pattern to network
			{
		 // Find Winning Kohonen layer node for input pattern
			Get_Winning_Node( pattern[id], W, num_input_nodes, rows, cols, 
							  &winning_row, &winning_col );

		 // Update all Kohonen node weight vectors in winner's neighborhood
			Update_Weight_Vectors( pattern[id], W, num_input_nodes, rows, cols, 
						           winning_row, winning_col,
								   learning_rate, neighborhood);
			
			}	
		iteration++;   // Increment current iteration
		}

	Save_Weights("outfile.dta",W,rows,cols,num_input_nodes,
				 iteration,learning_rate,neighborhood); // Store feature map

	}