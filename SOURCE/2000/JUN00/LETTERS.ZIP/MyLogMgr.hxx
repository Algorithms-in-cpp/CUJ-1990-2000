#ifndef _MYLOGMGR_H
#define _MYLOGMGR_H

/* include directives */
#include <sys/types.h>
#include <iostream.h>
#include <String.hxx>
#include <LogMgr.hxx>

/* constant declarations and enumerations */
#define LOG_ROLL_SIZE      4000000
#define MAX_DEBUG_LINE_LEN   65536

// trace log debug level of detail
/* Level of Detail Description
   SPARSE:
     Include a meager amount of detail; major tracing points 
   DETAILED:
     Include more detail ; intermediate level tracing points; encompasses SPARSE
   OVERWELMING:
     Include all the details; minor tracing points; encompasses SPARSE and DETAILED

   To explore how to use the Level of Detail, look at a typical method call.
   If one is only interested in a SPARSE Level of Detail, logging the method
   name and the fact that it was entered is probably sufficient. If one is 
   interested in a DETAILED Level of Detail, logging the method name, the 
   fact that it was entered and when it is exited may be adequate. If one is
   interested in a OVERWELMING Level of Detail, logging the method name, all
   the parameters passed in, the fact that it was entered, when it is exited
   and all the return values is probably what is required. */

#define DEBUG_SPARSE       0x10000000
#define DEBUG_DETAILED     0x30000000
#define DEBUG_OVERWHELMING 0x70000000

// trace log debug behavior type
/* Behavior Type Description
   ALGORITHM:
     Algorithmic detail
   CACHE:
     Cache detail
   COMMUNICATIONS:
     Interprocess communications (RPC, Corba, socket, shared memory, etc)
   DATABASE:
     Anything to do with the database (writing to, selecting from, etc)
   ERROR:
     Used by the Error Log Service when duplicating errors in trace
   FILE I/O:
     Input/Output to a file
   PROCEDURE:
     Flow of control, entry and exit of method calls
   LIFECYCLE:
     Construction of objects, destruction of objects
   STATE:
     Changes in the state of an object
   ALL:
     (Combination) All defined behavior types */

#define DEBUG_ALGORITHM      0x00000001
#define DEBUG_CACHE          0x00000002
#define DEBUG_COMMUNICATIONS 0x00000004
#define DEBUG_DATABASE       0x00000008
#define DEBUG_ERROR          0x00000010
#define DEBUG_FILE           0x00000020
#define DEBUG_PROCEDURE      0x00000040
#define DEBUG_LIFECYCLE      0x00000080
#define DEBUG_STATE          0x00000100
#define DEBUG_ALL            0x00FFFFFF

/* type definitions */
class MyLogBuf : public streambuf {
public:
    MyLogBuf(G_String region, G_String processName);
    virtual ~MyLogBuf();
    
    // streambuf stuff
    virtual int sync();
    virtual int overflow(int nCh = EOF);
    virtual int underflow();

protected:
    MyLogBuf(); // default constructor not accessible outside class
	MyLogBuf(const MyLogBuf& right);
	const MyLogBuf& operator=(const MyLogBuf& right);
	int operator==(const MyLogBuf& right) const;
	int operator!=(const MyLogBuf& right) const;

private:
    FILE* OpenLog();
    void CloseLog();
    void ArchiveLog();

    G_String _pidString;
	FILE *_fileHandle; /* file handle of debug file */
    char _debugLine[MAX_DEBUG_LINE_LEN + 1];
    char _debugLineIndex;
    unsigned long _logSize;
    G_String _logName;
    int _logTmYday;
    G_String _region;
    G_String _processName;
    int _expectingEndOfMsg;
};

class MyLogMgr : public G_LogMgr {
public:

/* the appropriate values for debug level of detail and behavior type 
   bitmasks are bitwise-OR'd together to generate the debug level passed
   to the MyLogMgr constructor. */
	MyLogMgr(
        G_String region, 
        G_String processName, 
        int debugLevel = (DEBUG_SPARSE | DEBUG_ALL));

	virtual ~MyLogMgr();

	// Set methods
    void SetDebugLevel(int debugLevel) {_debugLevel = debugLevel;}

	// Get methods
    int GetDebugLevel() const {return _debugLevel;}
    virtual ostream& GetTraceLog() throw(G_NotImplementedException);
    virtual ostream& GetErrorLog() throw(G_NotImplementedException);

protected:
	MyLogMgr(); // default constructor not accessible outside class
	MyLogMgr(const MyLogMgr& right);
	const MyLogMgr& operator=(const MyLogMgr& right);
	int operator==(const MyLogMgr& right) const;
	int operator!=(const MyLogMgr& right) const;

private:
    int _debugLevel;
    MyLogBuf *_logBufPtr;
    streambuf *_prevClogBufPtr;
    streambuf *_prevCerrBufPtr;
    G_String _region;
    G_String _processName;
};

/* global function prototypes */

/* global variable extern's */

/* macro definitions */
#define TRACELOG(debugLevel, outMsg) {\
    MyLogMgr *theLogMgr = (MyLogMgr*) G_LogMgr::GetInstance();\
    if ((theLogMgr->GetDebugLevel() & debugLevel) == debugLevel) {\
    theLogMgr->GetTraceLog() << outMsg << endl << endl;}}
#define ERRORLOG(outMsg) {\
    char szMsg[512];\
    sprintf(szMsg, "An error occurred at line %d in file(%s):\n",\
    __LINE__, __FILE__);\
    G_LogMgr::GetInstance()->GetErrorLog() << szMsg << outMsg << endl << endl;}
#define TRACEFUNCTIONENTRY(functionName) {\
    char szMsg[512];\
    sprintf(szMsg, "Enter routine " #functionName );\
    TRACELOG((DEBUG_SPARSE | DEBUG_PROCEDURE), szMsg);}
#define TRACEFUNCTIONEXIT(functionName) {\
    char szMsg[512];\
    sprintf(szMsg, "Leaving routine " #functionName ", line %d, file(%s)",\
    __LINE__, __FILE__);\
    TRACELOG((DEBUG_DETAILED | DEBUG_PROCEDURE), szMsg);}
#define TRACEFUNCTIONEXIT_RC(functionName, returnCode) {\
    char szMsg[512];\
    sprintf(szMsg, "Leaving routine " #functionName ", line %d, file(%s), rc(%d)",\
    __LINE__, __FILE__, returnCode);\
    TRACELOG((DEBUG_DETAILED | DEBUG_PROCEDURE), szMsg);}

#endif /* #ifndef _MYLOGMGR_H */

