#ifndef _G_LOGMGR_H
#define _G_LOGMGR_H

/* include directives */
#include <sys/types.h>
#include <iostream.h>
#include <Exception.hxx>

/* constant declarations and enumerations */

/* type definitions */
class G_LogMgr {
public:
	virtual ~G_LogMgr() {}

	// Set methods

	// Get methods
    virtual ostream& GetTraceLog() 
        throw(G_NotImplementedException) = 0;
    virtual ostream& GetErrorLog() 
        throw(G_NotImplementedException) = 0;

    // Singleton method
    static G_LogMgr* GetInstance() {return _instancePtr;}

protected:
	G_LogMgr();	// default constructor not accessible outside class
	G_LogMgr(const G_LogMgr& right);
	const G_LogMgr& operator=(const G_LogMgr& right);
	int operator==(const G_LogMgr& right) const;
	int operator!=(const G_LogMgr& right) const;

private:
    static G_LogMgr *_instancePtr;
};

/* global function prototypes */

/* global variable extern's */

/* macro definitions */

#endif /* #ifndef _G_LOGMGR_H */

