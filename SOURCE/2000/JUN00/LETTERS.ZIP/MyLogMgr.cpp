//----------------------------------------------------------------------------
// METHOD: MyLogBuf::MyLogBuf
//
// PURPOSE: constructor
//
// PARAMETERS:
//
// RETURNS:
//      Nothing
//
// NOTES:
//

//----------------------------------------------------------------------------
MyLogBuf::MyLogBuf(G_String region, G_String processName)
    : _expectingEndOfMsg(FALSE), _fileHandle(0), _logSize(0),
_debugLineIndex(0),
    streambuf(NULL, 0) // unbuffered
{
    pid_t myPID = getpid();
    _pidString.printf("%d", myPID);
    _region = region;
    _processName = processName;

    _fileHandle = OpenLog();
}

//----------------------------------------------------------------------------
// METHOD: MyLogBuf::~MyLogBuf
//
// PURPOSE: destructor
//
// PARAMETERS:
//
// RETURNS:
//      Nothing
//
// NOTES:
//

//----------------------------------------------------------------------------
MyLogBuf::~MyLogBuf()
{
    // roll the log when the process exits
    CloseLog();
    ArchiveLog();
}

// streambuf stuff

//----------------------------------------------------------------------------
// METHOD: MyLogBuf::sync
//
// PURPOSE: Flushes the put area. Empties the get area.
//   FOR UNBUFFERED OPERATION, THIS FUNCTION IS CALLED AFTER OUTPUT
//   IS FLUSHED AND BEFORE INPUT IS ATTEMPTED AND IS JUST A NOP.
//
// PARAMETERS:
//
// RETURNS:
//   0, successful
//   EOF, error occurred
//
// NOTES:
//

//----------------------------------------------------------------------------
int MyLogBuf::sync()
{
    return(0);  // successful
}

//----------------------------------------------------------------------------
// METHOD: MyLogBuf::overflow
//
// PURPOSE: Consumes the characters in the put area between the pbase and
//   pptr pointers and then reinitializes the put area. The overflow
function
//   must also consume nCh (if nCh is not EOF). FOR UNBUFFERED OPERATION,
//   THIS FUNCTION IS CALLED TO WRITE A CHARACTER TO THE LOG.
//
// PARAMETERS:
//
// RETURNS:
//   0, successful
//   EOF, error occurred.
//
// NOTES:
//   two newline characters in succession indicates the end of a log message
//

//----------------------------------------------------------------------------
int MyLogBuf::overflow(int nCh)
{
    int status = TRUE;
    char nChString[2];
    int ret;

    // consume leading newline characters
    if ((nCh == '\n') && !_debugLineIndex)
    {
        nCh = EOF;
    }

    if (nCh != EOF)
    {
        // buffer the character to write
        _debugLine[_debugLineIndex] = nCh;
        _debugLineIndex++;

        if (_debugLineIndex >= MAX_DEBUG_LINE_LEN)
        {
            // chop the debug message up so we don't exceed our buffer
length
            nCh = '\n';
            _expectingEndOfMsg = TRUE;
        }

        if (nCh == '\n')
        {
            // if this is the end of a debug line/message
            if (_expectingEndOfMsg)
            {
                _expectingEndOfMsg = FALSE;
                _debugLine[_debugLineIndex] = '\0'; // null terminate debug
message

                time_t currentTime = time(NULL);
                struct tm *t_m;
                t_m = localtime(&currentTime);     /* breaks the date into
integers */
                G_String msgPrefixLine;

                msgPrefixLine.printf(
                    "%02.02d:%02.02d:%02.02d %s %s %s\n",
                    t_m->tm_hour,
                    t_m->tm_min,
                    t_m->tm_sec,
                    (char*) _processName,
                    (char*) _pidString,
                    (char*) _region);

                // roll the log when a date change occurs
                if (_logTmYday != t_m->tm_yday)
                {
                    CloseLog();
                    ArchiveLog();
                    _fileHandle = OpenLog();
                }

                // write the debug timestamp to the log file
                if (_fileHandle)
                {
                    ret = fputs(msgPrefixLine, _fileHandle);
                    if (ret == EOF)
                    {
                        // error occurred while logging to file, try to
recover
                        CloseLog();
                        ArchiveLog();
                        _fileHandle = OpenLog();
                        if (_fileHandle)
                        {
                            // second attempt to write to log file
                            ret = fputs(msgPrefixLine, _fileHandle);
                            if (ret == EOF)
                            {
                                // fputs() failed again, stop logging to
file
                                CloseLog();
                                ArchiveLog();
                            }
                        }
                    }
                }

                if (!_fileHandle)
                {
                    cout << msgPrefixLine;
                }

                // write the debug message to the log file
                if (_fileHandle)
                {
                    ret = fputs(_debugLine, _fileHandle);
                    if (ret == EOF)
                    {
                        // error occurred while logging to file, try to
recover
                        CloseLog();
                        ArchiveLog();
                        _fileHandle = OpenLog();
                        if (_fileHandle)
                        {
                            // second attempt to write to log file
                            ret = fputs(_debugLine, _fileHandle);
                            if (ret == EOF)
                            {
                                // fputs() failed again, stop logging to
file
                                CloseLog();
                                ArchiveLog();
                            }
                        }
                    }
                }

                if (!_fileHandle)
                {
                    cout << _debugLine;
                }

                _logSize += msgPrefixLine.Length();
                _logSize += _debugLineIndex;
                _debugLineIndex = 0;

                // roll the log when the size of the log file reaches 4
megabytes
                if (_logSize >= LOG_ROLL_SIZE)
                {
                    CloseLog();
                    ArchiveLog();
                    _fileHandle = OpenLog();
                }
            }
            else
            {
                _expectingEndOfMsg = TRUE;
            }
        }
        else
        {
            _expectingEndOfMsg = FALSE;
        }
    }

    if (!status)
    {
        return(EOF);    // unsuccessful
    }

    return(0);  // successful
}

//----------------------------------------------------------------------------
// METHOD: MyLogBuf::underflow
//
// PURPOSE: Supplies the get area with characters from the input source.
//   If the get area contains characters, then underflow returns the
//   first character. If the get area is empty, then it fills the get
//   area and returns the next character (which it leaves in the get
//   area). FOR UNBUFFERED OPERATION, THIS FUNCTION IS CALLED TO
//   RECEIVE A CHARACTER.
//
// PARAMETERS:
//
// RETURNS:
//   EOF, no more characters were available
//   !EOF, first character available from get area
//
// NOTES:
//

//----------------------------------------------------------------------------
int MyLogBuf::underflow()
{
    return(EOF);
}

//----------------------------------------------------------------------------
// METHOD: MyLogBuf::ArchiveLog
//
// PURPOSE: rolls and compresses the log file
//
// PARAMETERS:
//
// RETURNS:
//      Nothing
//
// NOTES:
//

//----------------------------------------------------------------------------
void MyLogBuf::ArchiveLog()
{
    G_String dateTimeString;
    struct tm *t_m;
    G_String rolledLogName;
    G_String commandString;
    time_t currentTime;

    _logSize = 0;
    currentTime = time(NULL);
    t_m = localtime(&currentTime);     /* breaks the date into integers */
    dateTimeString.printf(
        "%04.04d-%02.02d-%02.02d_%02.02d:%02.02d:%02.02d",
        t_m->tm_year + 1900,
        t_m->tm_mon + 1,
        t_m->tm_mday,
        t_m->tm_hour,
        t_m->tm_min,
        t_m->tm_sec);

    rolledLogName.printf("etilog.%s.%s", (char*) _pidString, (char*)
dateTimeString);
    if (rename(_logName, rolledLogName) > -1)
    {
        commandString.printf("compress %s &\n", (char*) rolledLogName);
        system(commandString);
    }
}


//----------------------------------------------------------------------------
// METHOD: MyLogBuf::OpenLog
//
// PURPOSE: opens the log file
//
// PARAMETERS:
//
// RETURNS:
//      Nothing
//
// NOTES:
//

//----------------------------------------------------------------------------
FILE* MyLogBuf::OpenLog()
{
    G_String dateString;
    struct tm *t_m;
    time_t currentTime;
    FILE* fileHandle = NULL;

    currentTime = time(NULL);
    t_m = localtime(&currentTime);     /* breaks the date into integers */

    _logTmYday = t_m->tm_yday;
    dateString.printf(
        "%04.04d-%02.02d-%02.02d",
        t_m->tm_year + 1900,
        t_m->tm_mon + 1,
        t_m->tm_mday);

    _logName.Empty();
    _logName.printf("etilog.%s.%s", (char*) _pidString, (char*) dateString);
    _expectingEndOfMsg = FALSE;
    _debugLineIndex = 0;

    fileHandle = fopen(_logName, "w");
    return fileHandle;
}

//----------------------------------------------------------------------------
// METHOD: MyLogBuf::CloseLog
//
// PURPOSE: close the log file
//
// PARAMETERS:
//
// RETURNS:
//      Nothing
//
// NOTES:
//

//----------------------------------------------------------------------------
void MyLogBuf::CloseLog()
{
    if (_fileHandle)
    {
        fclose(_fileHandle);
        _fileHandle = NULL;
    }
}

Finally, here is the constructor of MyLogMgr which redirects cerr and clog
to the log file
by assigning an instance of MyLogBuf, and the destructor which undoes this
redirection:

//----------------------------------------------------------------------------
// METHOD: MyLogMgr::MyLogMgr
//
// PURPOSE: constructor
//
// PARAMETERS:
//
// RETURNS:
//      Nothing
//
// NOTES:
//

//----------------------------------------------------------------------------
MyLogMgr::MyLogMgr(G_String region, G_String processName, int debugLevel)
    : _logBufPtr(NULL), _prevClogBufPtr(NULL), _prevCerrBufPtr(NULL)
{
    _region = region;
    _processName = processName;
    _debugLevel = debugLevel;

    // setup our streambuf for doing trace and error output
    _logBufPtr = new MyLogBuf(region, processName);
    _prevClogBufPtr = clog.rdbuf();
    clog = _logBufPtr;
    _prevCerrBufPtr = cerr.rdbuf();
    cerr = _logBufPtr;
}

//----------------------------------------------------------------------------
// METHOD: MyLogMgr::~MyLogMgr
//
// PURPOSE: destructor
//
// PARAMETERS:
//
// RETURNS:
//      Nothing
//
// NOTES:
//

//----------------------------------------------------------------------------
MyLogMgr::~MyLogMgr()
{
    clog.flush();
    cerr.flush();

    // restore the previous streambuf's for clog and cerr
    clog = _prevClogBufPtr;
    cerr = _prevCerrBufPtr;

    // delete our streambuf
    delete _logBufPtr;
}
