//////////////////////////////////////////////////////////////////////
//
//  Vector.cpp
//
//  An nx1 vector of numbers.
//
//  Michael L Perry
//  8/29/99
//

#include "stdhdr.h"
#include "Vector.h"

#include <memory.h>

//////////////////////////////////////////////////////////////////////
// CVectorData
inline CVector::CVectorData::CVectorData()
{
    // Make an empty vector.
    m_nSize = 0;
    m_pElements = NULL;
    m_nRefCount = 0;
}

inline CVector::CVectorData::CVectorData(const CVectorData &that)
{
    // Copy the elements from the other vector.
    m_nSize = that.m_nSize;
    m_pElements = new double[m_nSize];
    memcpy( m_pElements, that.m_pElements, m_nSize*sizeof(double) );
    m_nRefCount = 0;
}

inline CVector::CVectorData::CVectorData(int nSize)
{
    // Allocate a vector and initialize the elements to zero.
    m_nSize = nSize;
    m_pElements = new double[m_nSize];
    memset( m_pElements, 0, m_nSize*sizeof(double) );
    m_nRefCount = 0;
}

inline CVector::CVectorData::~CVectorData()
{
    if ( m_pElements != NULL )
        delete[] m_pElements;
}

inline void CVector::CVectorData::AddRef()
{
    m_nRefCount++;
}

inline void CVector::CVectorData::Release()
{
    // When the reference count reaches zero, delete the object.
    if ( --m_nRefCount == 0 )
    {
        delete this;
    }
}

inline bool CVector::CVectorData::IsShared() const
{
    return m_nRefCount > 1;
}

inline int CVector::CVectorData::Size() const
{
    return m_nSize;
}

inline bool CVector::CVectorData::Equals(const CVector::CVectorData *pThat)
{
    // Must be the same size.
    if ( m_nSize != pThat->m_nSize )
        return false;

    return memcmp(
        m_pElements,
        pThat->m_pElements,
        m_nSize*sizeof(double) ) == 0;
}

inline double CVector::CVectorData::Element(int nRow) const
{
    // Verify that we are still in range.
    ASSUMING ( nRow >= 0 && nRow < m_nSize )
    {
        return m_pElements[nRow];
    }
    return 0.0;
}

inline double &CVector::CVectorData::Element(int nRow)
{
    static double dDummy = 0.0;

    // Verify that we are still in range.
    ASSUMING ( nRow >= 0 && nRow < m_nSize )
    {
        return m_pElements[nRow];
    }
    // Satisfy the compiler.
    return dDummy;
}


//////////////////////////////////////////////////////////////////////
// CVector
CVector::CVector()
{
    // Create an empty vector.
    m_pVectorData = NULL;
}

CVector::CVector(const CVector &that)
{
    // Refer to the same data - lazy copy.
    m_pVectorData = that.m_pVectorData;
    m_pVectorData->AddRef();
}

CVector::CVector(int nSize)
{
    // Create vector data if the size is valid.
    if ( nSize > 0 )
    {
        m_pVectorData = new CVectorData(nSize);
        m_pVectorData->AddRef();
    }
    else
    {
        m_pVectorData = NULL;
    }
}

CVector::~CVector()
{
    // Release my reference on the data.
    if ( m_pVectorData != NULL )
        m_pVectorData->Release();
}

bool CVector::operator ==(const CVector &that) const
{
    // First determine if they share data.
    if ( m_pVectorData == that.m_pVectorData )
        return true;

    // If not, make sure they both have data.
    if ( m_pVectorData == NULL ||
         that.m_pVectorData == NULL )
        return false;

    return m_pVectorData->Equals(that.m_pVectorData);
}

bool CVector::operator !=(const CVector &that) const
{
    return !operator ==(that);
}

const CVector &CVector::operator =(const CVector &that)
{
    // Release the old vector data.
    if ( m_pVectorData != NULL )
        m_pVectorData->Release();

    // Share the data.
    m_pVectorData = that.m_pVectorData;
    if ( m_pVectorData != NULL )
        m_pVectorData->AddRef();

    return that;
}

int CVector::Size() const
{
    if ( m_pVectorData == NULL )
        return 0;

    return m_pVectorData->Size();
}

double CVector::operator()(int nRow) const
{
    // Verify that we have data.
    ASSUMING ( m_pVectorData != NULL )
    {
        return m_pVectorData->Element(nRow);
    }
    return 0.0;
}

double &CVector::operator()(int nRow)
{
    static double dDummy = 0.0;
    // Verify that we have data.
    ASSUMING ( m_pVectorData != NULL )
    {
        // Make a copy if the data is shared.
        if ( m_pVectorData->IsShared() )
        {
            CVectorData *pCopy = new CVectorData(*m_pVectorData);

            // Release the old vector data.
            m_pVectorData->Release();

            // Use the copy.
            m_pVectorData = pCopy;
            m_pVectorData->AddRef();
        }
        return m_pVectorData->Element(nRow);
    }
    // Appease the compiler.
    return dDummy;
}

CVector CVector::operator -() const
{
    // Make the result vector.
    int nSize = Size();
    CVector result( nSize );
    int nElement;
    for ( nElement = 0; nElement < nSize; nElement++ )
    {
        // Each element is the opposite of the one in this vector.
        result(nElement) = -(*this)(nElement);
    }
    return result;
}

CVector CVector::operator +(const CVector &that) const
{
    // Make the result vector.
    int nSize = Size();
    ASSUMING ( that.Size() == nSize )
    {
        CVector result( nSize );
        int nElement;
        for ( nElement = 0; nElement < nSize; nElement++ )
        {
            result(nElement) = (*this)(nElement) + that(nElement);
        }
        return result;
    }

    return CVector();
}

CVector CVector::operator -(const CVector &that) const
{
    // Make the result vector.
    int nSize = Size();
    ASSUMING ( that.Size() == nSize )
    {
        CVector result( nSize );
        int nElement;
        for ( nElement = 0; nElement < nSize; nElement++ )
        {
            result(nElement) = (*this)(nElement) - that(nElement);
        }
        return result;
    }

    return CVector();
}

double CVector::InnerProduct(const CVector &that) const
{
    // Calculate the sum of the products.
    int nSize = Size();
    ASSUMING ( that.Size() == nSize )
    {
        double dSum = 0.0;
        int nElement;
        for ( nElement = 0; nElement < nSize; nElement++ )
        {
            dSum += (*this)(nElement) * that(nElement);
        }
        return dSum;
    }

    return 0.0;
}

void CVector::Dump() const
{
    int nSize = m_pVectorData->Size();

    int nElement;
    Trace( "[ " );
    for ( nElement = 0; nElement < nSize; nElement++ )
    {
        Trace( m_pVectorData->Element(nElement) );
        Trace( " " );
    }
    Trace( "]\n" );
}

CVector operator *(double dScalar, const CVector &vVector)
{
    int nSize = vVector.Size();
    CVector vResult(nSize);

    int nElement;
    for ( nElement = 0; nElement < nSize; nElement++ )
    {
        vResult(nElement) = dScalar * vVector(nElement);
    }

    return vResult;
}
