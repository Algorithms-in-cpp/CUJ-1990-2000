//////////////////////////////////////////////////////////////////////
//
//  ProbLattice.cpp
//
//  A triangular spring lattice.
//
//  Michael L Perry
//  9/21/99
//

#include "stdhdr.h"

#include "ProbLattice.h"
#include "EqSystem.h"

const double dSqrt5  = 2.23606797750;
const double dSqrt13 = 3.60555127546;

// Connect the cords and springs to the points and forces.
CProbLattice::CProbLattice() :

    // Set parameters and tie together points and forces.
    m_Spring1( 2.5, 0.5, m_Point1, m_Point2, m_Force1 ),
    m_Spring2( 1.5, 0.5, m_Point2, m_Point3, m_Force2 ),
    m_Spring3( 2.0, 1.0, m_Point3, m_Point1, m_Force3 ),
    m_Cord1( -4.0, -2.0, dSqrt5,  m_Point1, m_Force1, m_Force3 ),
    m_Cord2(  4.0,  5.0, dSqrt13, m_Point2, m_Force2, m_Force1 ),
    m_Cord3(  4.0, -4.0, dSqrt13, m_Point3, m_Force3, m_Force2 ),

    // Set initial guesses.
    /*
    // This initial guess is the correct answer.
    m_Point1( -2.0, -1.0),
    m_Point2(  2.0,  2.0),
    m_Point3(  2.0, -1.0),
    m_Force1(  4.0,  3.0),
    m_Force2(  0.0, -3.0),
    m_Force3( -2.0,  0.0)
    */

    /*
    // This one is a little off.
    m_Point1(-2.37, -0.63),
    m_Point2( 2.48,  1.57),
    m_Point3( 2.13, -0.56),
    m_Force1( 3.96,  3.15),
    m_Force2(-0.10, -3.41),
    m_Force3(-1.81,  0.41)
    */

    /*
    // This one is a little more off.
    m_Point1(-3.26, -2.19),
    m_Point2( 1.04,  0.50),
    m_Point3( 1.08,  0.47),
    m_Force1( 2.52,  3.48),
    m_Force2(-0.37, -2.42),
    m_Force3(-3.41,  0.08)
    */

    // This one is not even close.
    m_Point1( 86.78, -72.46),
    m_Point2(-38.01,  59.53),
    m_Point3( 98.77,  11.73),
    m_Force1( 46.52,  21.10),
    m_Force2( 34.72,  46.84),
    m_Force3(-15.25, -40.19)
{
}

// Add all components to the system of equations.
void CProbLattice::AddToSystem(CEqSystem &sys)
{
    m_Spring1.AddToSystem(sys);
    m_Spring2.AddToSystem(sys);
    m_Spring3.AddToSystem(sys);
    m_Cord1.AddToSystem(sys);
    m_Cord2.AddToSystem(sys);
    m_Cord3.AddToSystem(sys);

    m_Point1.AddToSystem(sys);
    m_Point2.AddToSystem(sys);
    m_Point3.AddToSystem(sys);
    m_Force1.AddToSystem(sys);
    m_Force2.AddToSystem(sys);
    m_Force3.AddToSystem(sys);
}

void CProbLattice::Dump()
{
    Trace( "Point 1 = " );
    m_Point1.Dump();
    Trace( "Point 2 = " );
    m_Point2.Dump();
    Trace( "Point 3 = " );
    m_Point3.Dump();
    Trace( "Force 1 = " );
    m_Force1.Dump();
    Trace( "Force 2 = " );
    m_Force2.Dump();
    Trace( "Force 3 = " );
    m_Force3.Dump();
}
