//////////////////////////////////////////////////////////////////////
//
//  ProbSpring.cpp
//
//  A spring in a lattice.
//
//  Michael L Perry
//  9/6/99
//

#include "stdhdr.h"
#include "ProbSpring.h"

#include <math.h>

CProbSpring::CProbSpring(
        double dRestingLength,
        double dSpringConstant,
        const CProbVector &vPoint1,
        const CProbVector &vPoint2,
        const CProbVector &vForce) :
    m_dRestingLength(dRestingLength),
    m_dSpringConstant(dSpringConstant),
    m_vPoint1(vPoint1),
    m_vPoint2(vPoint2),
    m_vForce(vForce)
{
}

void CProbSpring::AddToSystem(CEqSystem & sys)
{
    sys.AddEquation( (IEqEquationX *)this );
    sys.AddEquation( (IEqEquationY *)this );
}

double CProbSpring::CalculateValueX()
{
    // Calculate the magnitude of the force.
    double dForce = sqrt( square(m_vForce.GetX()) + square(m_vForce.GetY()) );
    // Calculate x of the right hand side ( [F](p-a) ).
    double dRHS = m_vPoint2.GetX() - m_vPoint1.GetX();
    // Calculate x of the left hand side ( F (R+[F]k) ).
    double dLHS = m_vForce.GetX() * (m_dRestingLength/dForce + m_dSpringConstant);

    return dRHS - dLHS;
}

bool CProbSpring::DependsUponX(IEqUnknown *pUnknown)
{
    return
        m_vPoint1.Represents(pUnknown) ||
        m_vPoint2.Represents(pUnknown) ||
        m_vForce.Represents(pUnknown);
}

double CProbSpring::CalculateValueY()
{
    // Calculate the magnitude of the force.
    double dForce = sqrt( square(m_vForce.GetX()) + square(m_vForce.GetY()) );
    // Calculate y of the right hand side ( [F](p-a) ).
    double dRHS = m_vPoint2.GetY() - m_vPoint1.GetY();
    // Calculate y of the left hand side ( F (R+[F]k) ).
    double dLHS = m_vForce.GetY() * (m_dRestingLength/dForce + m_dSpringConstant);

    return dRHS - dLHS;
}

bool CProbSpring::DependsUponY(IEqUnknown *pUnknown)
{
    return
        m_vPoint1.Represents(pUnknown) ||
        m_vPoint2.Represents(pUnknown) ||
        m_vForce.Represents(pUnknown);
}
