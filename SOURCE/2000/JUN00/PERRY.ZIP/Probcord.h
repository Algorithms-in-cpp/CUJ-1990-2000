//////////////////////////////////////////////////////////////////////
//
//  ProbCord.h
//
//  A cord in a lattice.
//
//  Michael L Perry
//  9/6/99
//

#if !defined(AFX_PROBCORD_H__1EA06B24_644F_11D3_9D65_444553540000__INCLUDED_)
#define AFX_PROBCORD_H__1EA06B24_644F_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "EquationInterpreter.h"
#include "ProbVector.h"

// Cord object.
// Attaches a fixed anchor point with an unknown point.  The length is fixed,
// and the force is the sum of two unknowns.
class CProbCord :
    private IEqEquationX,
    private IEqEquationY
{
public:
    CProbCord(
        double dAX,
        double dAY,
        double dLength,
        const CProbVector &vPoint,
        const CProbVector &vForce1,
        const CProbVector &vForce2);

    void AddToSystem(CEqSystem &sys);

private:
    // IEqEquationX interface.
    double CalculateValueX();
    bool DependsUponX(IEqUnknown *pUnknown);
    // IEqEquationY interface.
    double CalculateValueY();
    bool DependsUponY(IEqUnknown *pUnknown);

private:
    double              m_dAX;
    double              m_dAY;
    double              m_dLength;
    const CProbVector   &m_vPoint;
    const CProbVector   &m_vForce1;
    const CProbVector   &m_vForce2;
};

#endif // !defined(AFX_PROBCORD_H__1EA06B24_644F_11D3_9D65_444553540000__INCLUDED_)
