//////////////////////////////////////////////////////////////////////
//
//  ProbSpring.h
//
//  A spring in a lattice.
//
//  Michael L Perry
//  9/6/99
//

#if !defined(AFX_PROBSPRING_H__5267F7E3_646B_11D3_9D65_444553540000__INCLUDED_)
#define AFX_PROBSPRING_H__5267F7E3_646B_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "EquationInterpreter.h"
#include "ProbVector.h"

// Spring object.
// Connects two unknown points.  The resting length and spring constant
// are fixed, while the force is unknown.
class CProbSpring :
    private IEqEquationX,
    private IEqEquationY
{
public:
    CProbSpring(
        double dRestingLength,
        double dSpringConstant,
        const CProbVector &vPoint1,
        const CProbVector &vPoint2,
        const CProbVector &vForce);

    void AddToSystem(CEqSystem &sys);

private:
    // IEqEquationX interface.
    double CalculateValueX();
    bool DependsUponX(IEqUnknown *pUnknown);
    // IEqEquationX interface.
    double CalculateValueY();
    bool DependsUponY(IEqUnknown *pUnknown);

private:
    double              m_dRestingLength;
    double              m_dSpringConstant;
    const CProbVector   &m_vPoint1;
    const CProbVector   &m_vPoint2;
    const CProbVector   &m_vForce;
};

#endif // !defined(AFX_PROBSPRING_H__5267F7E3_646B_11D3_9D65_444553540000__INCLUDED_)
