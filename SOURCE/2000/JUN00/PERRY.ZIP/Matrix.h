//////////////////////////////////////////////////////////////////////
//
//  Matrix.h
//
//  A square matrix of numbers.
//
//  Michael L Perry
//  8/22/99
//

#if !defined(AFX_MATRIX_H__9AFB8545_5871_11D3_9D65_444553540000__INCLUDED_)
#define AFX_MATRIX_H__9AFB8545_5871_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Vector.h"

// Matrix class.
// Represents a square matrix of doubles.
class CMatrix
{
public:
    // Create an identity matrix.
    static CMatrix Identity(int nSize);

    // Default, copy, and sizing constructors.
    CMatrix();
    CMatrix(const CMatrix &that);
    CMatrix(int nSize);
    ~CMatrix();

    // Comparison and assignment operators.
    bool operator ==(const CMatrix &that) const;
    bool operator !=(const CMatrix &that) const;
    const CMatrix &operator =(const CMatrix &that);

    // Get the size of the matrix.
    int Size() const;

    // Get and set elements.
    double operator()(int nRow, int nCol) const;
    double &operator()(int nRow, int nCol);

    // Matrix multiplication.
    CMatrix operator *(const CMatrix &that) const;
    CVector operator *(const CVector &that) const;

    CMatrix Transpose() const;

    void Dump() const;

private:
    // Put the data into a shared structure for lazy copy.
    class CMatrixData
    {
    public:
        // Default, copy, and sizing constructors.
        CMatrixData();
        CMatrixData(const CMatrixData &that);
        CMatrixData(int nSize);
        ~CMatrixData();

        // Reference counting.
        void AddRef();
        void Release();
        bool IsShared() const;

        // Get the size of the matrix.
        int Size() const;

        // Comparison.
        bool Equals(const CMatrixData *pThat);

        // Get and set elements.
        double Element(int nRow, int nCol) const;
        double &Element(int nRow, int nCol);
    private:
        int     m_nSize;
        double *m_pElements;

        int     m_nRefCount;
    } *m_pMatrixData;
};

#endif // !defined(AFX_MATRIX_H__9AFB8545_5871_11D3_9D65_444553540000__INCLUDED_)
