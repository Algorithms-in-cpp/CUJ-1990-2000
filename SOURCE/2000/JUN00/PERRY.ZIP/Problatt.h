//////////////////////////////////////////////////////////////////////
//
//  ProbLattice.h
//
//  A triangular spring lattice.
//
//  Michael L Perry
//  9/21/99
//

#if !defined(AFX_PROBLATTICE_H__277E2F44_708B_11D3_948A_00105A05D6B6__INCLUDED_)
#define AFX_PROBLATTICE_H__277E2F44_708B_11D3_948A_00105A05D6B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProbSpring.h"
#include "ProbCord.h"
#include "ProbVector.h"

class CEqSystem;
// Lattice object.
// Connects three cords and three springs by attaching
// common points and forces.
class CProbLattice  
{
public:
    CProbLattice();

    void AddToSystem(CEqSystem &sys);
    void Dump();

public:
    CProbSpring     m_Spring1;
    CProbSpring     m_Spring2;
    CProbSpring     m_Spring3;
    CProbCord       m_Cord1;
    CProbCord       m_Cord2;
    CProbCord       m_Cord3;

    CProbVector     m_Point1;
    CProbVector     m_Point2;
    CProbVector     m_Point3;
    CProbVector     m_Force1;
    CProbVector     m_Force2;
    CProbVector     m_Force3;
};

#endif // !defined(AFX_PROBLATTICE_H__277E2F44_708B_11D3_948A_00105A05D6B6__INCLUDED_)
