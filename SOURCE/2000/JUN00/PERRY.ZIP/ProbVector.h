//////////////////////////////////////////////////////////////////////
//
//  ProbVector.h
//
//  A two-dimensional vector that represents a point or force.
//
//  Michael L Perry
//  9/6/99
//

#if !defined(AFX_PROBVECTOR_H__1EA06B23_644F_11D3_9D65_444553540000__INCLUDED_)
#define AFX_PROBVECTOR_H__1EA06B23_644F_11D3_9D65_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "EqSystem.h"

// Interface interpreters.
class IEqUnknownX : public IEqUnknown
{
public:
    double GetValue()
        { return GetValueX(); }
    void SetValue(double dValue)
        { SetValueX(dValue); }

    virtual double GetValueX() = 0;
    virtual void SetValueX(double dValue) = 0;
};

class IEqUnknownY : public IEqUnknown
{
public:
    double GetValue()
        { return GetValueY(); }
    void SetValue(double dValue)
        { SetValueY(dValue); }

    virtual double GetValueY() = 0;
    virtual void SetValueY(double dValue) = 0;
};

// Point/vector object.
// An unknown two-dimensional force or position.
class CProbVector :
    private IEqUnknownX,
    private IEqUnknownY
{
public:
    CProbVector();
    CProbVector( double dX, double dY );

    double GetX() const
        { return m_dX; }
    double GetY() const
        { return m_dY; }

    void AddToSystem(CEqSystem &sys);
    bool Represents(const IEqUnknown *pUnknown) const;
    void Dump();

private:
    // IEqUnknownX interface.
    double GetValueX();
    void SetValueX(double dValue);
    // IEqUnknownY interface.
    double GetValueY();
    void SetValueY(double dValue);

private:
    double  m_dX;
    double  m_dY;
};

#endif // !defined(AFX_PROBVECTOR_H__1EA06B23_644F_11D3_9D65_444553540000__INCLUDED_)
