//////////////////////////////////////////////////////////////////////
//
//  EquationInterpreter.h
//
//  IEqEquation interpreter classes.
//
//  Michael L Perry
//  9/6/99
//

#ifndef _EQUATIONINTERPRETER_H
#define _EQUATIONINTERPRETER_H

#include "EqSystem.h"

class IEqEquationX : public IEqEquation
{
public:
    double CalculateValue()
        { return CalculateValueX(); }
    bool DependsUpon(IEqUnknown *pUnknown)
        { return DependsUponX(pUnknown); }

    virtual double CalculateValueX() = 0;
    virtual bool DependsUponX(IEqUnknown *pUnknown) = 0;
};

class IEqEquationY : public IEqEquation
{
public:
    double CalculateValue()
        { return CalculateValueY(); }
    bool DependsUpon(IEqUnknown *pUnknown)
        { return DependsUponY(pUnknown); }

    virtual double CalculateValueY() = 0;
    virtual bool DependsUponY(IEqUnknown *pUnknown) = 0;
};

#endif
