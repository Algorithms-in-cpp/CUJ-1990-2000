//////////////////////////////////////////////////////////////////////
//
//  Main.cpp
//
//  Main program file.
//
//  Michael L Perry
//  8/22/99
//

#include "stdhdr.h"

#include "ProbLattice.h"
#include "EqSystem.h"

#include <fstream>

std::fstream trace("output.txt", std::ios_base::out);

void Trace(char *strOut)
{
    trace << strOut;
}

void Trace(double dValue)
{
    char strValue[20];

    sprintf(strValue, "%f", dValue);
    Trace(strValue);
}

void main()
{
    CProbLattice prob;          // Create the problem object.
    CEqSystem sys;              // Create the solver.

    prob.AddToSystem(sys);      // Attach the problem to the solver.
    sys.Solve();                // Solve the system.
    prob.Dump();                // Display the results.
}
