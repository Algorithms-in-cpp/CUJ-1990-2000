//////////////////////////////////////////////////////////////////////
//
//  ProbCord.cpp
//
//  A cord in a lattice.
//
//  Michael L Perry
//  9/6/99
//

#include "stdhdr.h"
#include "ProbCord.h"

#include <math.h>

CProbCord::CProbCord(
        double dAX,
        double dAY,
        double dLength,
        const CProbVector &vPoint,
        const CProbVector &vForce1,
        const CProbVector &vForce2) :
    m_dAX(dAX),
    m_dAY(dAY),
    m_dLength(dLength),
    m_vPoint(vPoint),
    m_vForce1(vForce1),
    m_vForce2(vForce2)
{
}

void CProbCord::AddToSystem(CEqSystem & sys)
{
    sys.AddEquation( (IEqEquationX *)this );
    sys.AddEquation( (IEqEquationY *)this );
}

double CProbCord::CalculateValueX()
{
    // Get the total force on the cord.
    double dForceX = m_vForce1.GetX() - m_vForce2.GetX();
    double dForceY = m_vForce1.GetY() - m_vForce2.GetY();
    // Calculate x of the right hand side ( [F](p-a) ).
    double dRHS = ( m_vPoint.GetX() - m_dAX );
    // Calculate x of the left hand side ( F L ).
    double dLHS = dForceX * m_dLength /
        sqrt( square(dForceX) + square(dForceY) );

    return dRHS - dLHS;
}

bool CProbCord::DependsUponX(IEqUnknown *pUnknown)
{
    return
        m_vPoint.Represents(pUnknown) ||
        m_vForce1.Represents(pUnknown) ||
        m_vForce2.Represents(pUnknown);
}

double CProbCord::CalculateValueY()
{
    // Get the total force on the cord.
    double dForceX = m_vForce1.GetX() - m_vForce2.GetX();
    double dForceY = m_vForce1.GetY() - m_vForce2.GetY();
    // Calculate y of the right hand side ( [F](p-a) ).
    double dRHS = ( m_vPoint.GetY() - m_dAY );
    // Calculate y of the left hand side ( F L ).
    double dLHS = dForceY * m_dLength /
        sqrt( square(dForceX) + square(dForceY) );

    return dRHS - dLHS;
}

bool CProbCord::DependsUponY(IEqUnknown *pUnknown)
{
    return
        m_vPoint.Represents(pUnknown) ||
        m_vForce1.Represents(pUnknown) ||
        m_vForce2.Represents(pUnknown);
}
