//////////////////////////////////////////////////////////////////////
//
//  ProbVector.cpp
//
//  A two-dimensional vector that represents a point or force.
//
//  Michael L Perry
//  9/6/99
//

#include "stdhdr.h"
#include "ProbVector.h"

CProbVector::CProbVector() :
    m_dX(0.0),
    m_dY(0.0)
{
}

CProbVector::CProbVector( double dX, double dY ) :
    m_dX(dX),
    m_dY(dY)
{
}

void CProbVector::AddToSystem(CEqSystem &sys)
{
    sys.AddUnknown( (IEqUnknownX *)this );
    sys.AddUnknown( (IEqUnknownY *)this );
}

bool CProbVector::Represents(const IEqUnknown * pUnknown) const
{
    return
        pUnknown == (const IEqUnknownX *)this ||
        pUnknown == (const IEqUnknownY *)this;
}

void CProbVector::Dump()
{
    Trace( "(" );
    Trace( m_dX );
    Trace( ", " );
    Trace( m_dY );
    Trace( ")\n" );
}

double CProbVector::GetValueX()
{
    return m_dX;
}

void CProbVector::SetValueX(double dValue)
{
    m_dX = dValue;
}

double CProbVector::GetValueY()
{
    return m_dY;
}

void CProbVector::SetValueY(double dValue)
{
    m_dY = dValue;
}
