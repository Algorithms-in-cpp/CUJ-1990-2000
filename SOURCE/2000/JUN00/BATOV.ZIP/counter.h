// Copyright (c) 1996-2000 by Vladimir Batov. Permission to  use,
// copy, modify,  distribute  and  sell  this  software  and  its
// documentation for any purpose is hereby granted  without  fee,
// provided that the above copyright notice appear in all  copies
// and that both that copyright notice and this permission notice
// appear in supporting documentation. I make no  representations
// about the suitability of this software for any purpose. It  is
// provided "as is" without express or implied warranty.

#ifndef BATOV_HANDLE_COUNTER_H
#define BATOV_HANDLE_COUNTER_H

// Error-bit is highest bit:

// ref-counter   = counter &  INT_MAX
// error         = counter & ~INT_MAX
// ++ref-counter = ++counter
// --ref-counter = --counter
// if (!(--counter & INT_MAX)) delete this;

// Error-bit is lowest bit:

// ref-counter   = counter >> 1;
// error         = counter & 1;
// ++ref-counter = (counter + 2)
// --ref-counter = (counter - 2)
// if (!((counter -= 2) >> 1)) delete this;

class Counter
{
   // The class reserves the lowest bit for error processing.
   // Being inlined it does not introduce any measurable overhead.
   // More bits can be reserved in similar fashion for other purposes.

   public:

   Counter () : _counter(0) {}
   Counter (int counter) : _counter(counter << 1) {}
   Counter (const Counter& c) : _counter(c._counter) {}

   Counter& operator++() { return (_counter += 2, *this); }
   Counter& operator--() { return (_counter -= 2, *this); }
   Counter&     error () { return (_counter | 1,  *this); }

   operator  int () const { return _counter >> 1; }
   bool is_error () const { return _counter  & 1; }
   
   private:

   // ((unsigned int) 0xFFFFFFFF) >> 1 == 0x7FFFFFFF
   // ((int)          0xFFFFFFFF) >> 1 == 0xFFFFFFFF

   unsigned int _counter;
};

#endif

#ifdef how_to_incorporate_traditional_error_processing

Usage:

Handle<Data> not_found = Handle<Data>::error();
Handle<Data>       eof = Handle<Data>::error();


Handle<Data>
find()
{
   if (ok) return Handle<Data>(args);
   else if (not-found) return not_found;
   else return eof;
}

foo()
{
   Handle<Data> h = find();
   
   if (h.is_error())
   {
      if (h == not_found) ...
      if (h == eof)       ...
   }
}


Implementation:

1. Use Counter class instead of 'typedef int Counter'.
2. Add supporting functionality:

class Counted
{
   ...
   
   static
   Counted*
   error()
   {
      Counter* counter = new Counter;
      counter->error();
      return (Counted*) counter;
   }

   bool
   is_error() const
   {
      return _counter.is_error();
   }
};

class Handle
{
   ...
   
   static
   Handle<Data>
   error()
   {
      return Counted::error();
   }

   bool
   is_error() const
   {
      return _counted->is_error();
   }
};

#endif
