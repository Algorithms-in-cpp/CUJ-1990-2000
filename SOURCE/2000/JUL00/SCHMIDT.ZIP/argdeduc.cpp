#include <iostream>

using std::cout;
using std::endl;

template<typename T>
void ft(T const &)
    {
    cout << "ft(T const &)" << endl;
    }

template<typename T>
void ft(T const *)
    {
    cout << "ft(T const *)" << endl;
    }

static void f(char const &)
    {
    cout << "f(char const &)" << endl;
    }

static void f(char const *)
    {
    cout << "f(char const *)" << endl;
    }

int main()
    {
    char c;
    char *p;
    ft(c);
    ft(p);
    f(c);
    f(p);
    return 0;
    }

