//////////////////////////////////////////////////////////////////////////////
// Project Name: Iterative Tree Traversal
//       Author: Valery N. CREUX
//    File Name: <node.h>
//
//  Description: <node.h> define the node structure.
//
//////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////
// General Definition
#define FALSE 0
#define TRUE  (!FALSE)


//////////////////////////////////////////////////////////////////////////////
// Node Structure
struct t_node
{
char data;                // Example Data
struct t_node *first_sub; // First SubNode
struct t_node *sibling;   // Sibling
struct t_node *parent;    // Parent
};


//////////////////////////////////////////////////////////////////////////////
// macro to hide/access the internal of the node
#define NO_NODE         NULL
#define node_exist(n)   ((n) != NULL)
#define has_sub(n)      ((n)->first_sub != NULL)
#define has_sibling(n)  ((n)->sibling != NULL)
#define get_sub(n)      ((n)->first_sub)
#define get_sibling(n)  ((n)->sibling)
#define get_parent(n)   ((n)->parent)
#define get_data(n)     ((n)->data)


/////////////////////////// This the END of the File /////////////////////////
//////////////////////////////////////////////////////////////////////////////

