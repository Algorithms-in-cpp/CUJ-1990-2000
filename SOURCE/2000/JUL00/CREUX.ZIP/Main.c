//////////////////////////////////////////////////////////////////////////////
// Project Name: Iterative Tree Traversal
//       Author: Valery N. CREUX
//    File Name: <main.c>
//
//  Description: <main.c> provide example to test the traversal functions
//
//////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////
// Standard include
#include <stdio.h>


//////////////////////////////////////////////////////////////////////////////
// Defintion for Tree
#include <node.h>


//////////////////////////////////////////////////////////////////////////////
// Defintion for Tree Traversal
#include <tt_depth.h>


//////////////////////////////////////////////////////////////////////////////
// The Example Process Function
void pre_post_process (struct t_node *node, int first_flag)
{
 if (first_flag == TRUE)
         printf (" ->%c", get_data(node));
 else
         printf (" <-%c", get_data(node));
}

void pre_process (struct t_node *node, int first_flag)
{
 if (first_flag == TRUE)
        printf (" %c", get_data(node));
}

void post_process (struct t_node *node, int first_flag)
{
 if (first_flag == FALSE)
        printf (" %c", get_data(node));
}


//////////////////////////////////////////////////////////////////////////////
// The Example Tree
#define node(x) &tree[x-'A']

struct t_node tree[] = {
/*   Node SubNode    Sibling    Parent */
        { 'A', node('B'), NULL,      NULL    },
        { 'B', node('D'), node('C'), node('A') },
        { 'C', NULL,      NULL,      node('A') },
        { 'D', node('F'), node('E'), node('B') },
        { 'E', node('I'), NULL,      node('B') },
        { 'F', NULL,      node('G'), node('D') },
        { 'G', NULL,      node('H'), node('D') },
        { 'H', NULL,      NULL,      node('D') },
        { 'I', node('J'), NULL,      node('E') },
        { 'J', NULL,      NULL,      node('I') }
};


//////////////////////////////////////////////////////////////////////////////
// Example and tests
int main(void)
{
printf (" ***** Tree Depth Traversal 1/2 *****");
//----- test with a root having sub-nodes and no parent or sibling
printf ("\nTree(A) pre/post:\n");
tree_depth_traversal1(node('A'), pre_post_process);
printf ("\nTree(A) pre:\n");
tree_depth_traversal1(node('A'), pre_process);
printf ("\nTree(A) post:\n");
tree_depth_traversal1(node('A'), post_process);
//----- test with a tree having sub-nodes and a parent and no sibling
printf ("\nTree(B) pre/post:\n");
tree_depth_traversal1(node('B'), pre_post_process);
printf ("\nTree(B) pre:\n");
tree_depth_traversal1(node('B'), pre_process);
printf ("\nTree(B) post:\n");
tree_depth_traversal1(node('B'), post_process);
//----- test with a tree having no sub-node, having a parent and a sibling
printf("\nTree(F) pre/post:\n");
tree_depth_traversal1(node('F'), pre_post_process);
printf("\nTree(F) pre:\n");
tree_depth_traversal1(node('F'), pre_process);
printf("\nTree(F) post:\n");
tree_depth_traversal1(node('F'), post_process);
//----- test with a tree having 1 sub-node, having a parent and no sibling
printf("\nTree(E) pre/post:\n");
tree_depth_traversal1(node('E'), pre_post_process);
printf("\nTree(E) pre:\n");
tree_depth_traversal1(node('E'), pre_process);
printf("\nTree(E) post:\n");
tree_depth_traversal1(node('E'), post_process);
printf("\n");

printf (" ***** Tree Depth Traversal 2/2 *****");
//----- test with a root having sub-nodes and no parent or sibling
printf ("\nTree(A) pre/post:\n");
tree_depth_traversal2(node('A'), pre_post_process);
printf ("\nTree(A) pre:\n");
tree_depth_traversal2(node('A'), pre_process);
printf ("\nTree(A) post:\n");
tree_depth_traversal2(node('A'), post_process);
//----- test with a tree having sub-nodes and a parent and no sibling
printf ("\nTree(B) pre/post:\n");
tree_depth_traversal2(node('B'), pre_post_process);
printf ("\nTree(B) pre:\n");
tree_depth_traversal2(node('B'), pre_process);
printf ("\nTree(B) post:\n");
tree_depth_traversal2(node('B'), post_process);
//----- test with a tree having no sub-node, having a parent and a sibling
printf("\nTree(F) pre/post:\n");
tree_depth_traversal2(node('F'), pre_post_process);
printf("\nTree(F) pre:\n");
tree_depth_traversal2(node('F'), pre_process);
printf("\nTree(F) post:\n");
tree_depth_traversal2(node('F'), post_process);
//----- test with a tree having 1 sub-node, having a parent and no sibling
printf("\nTree(E) pre/post:\n");
tree_depth_traversal2(node('E'), pre_post_process);
printf("\nTree(E) pre:\n");
tree_depth_traversal2(node('E'), pre_process);
printf("\nTree(E) post:\n");
tree_depth_traversal2(node('E'), post_process);
printf("\n");

}


/////////////////////////// This the END of the File /////////////////////////
//////////////////////////////////////////////////////////////////////////////

