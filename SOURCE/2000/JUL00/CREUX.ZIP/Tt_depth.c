//////////////////////////////////////////////////////////////////////////////
// Project Name: Iterative Tree Traversal
//       Author: Valery N. CREUX
//    File Name: <tt_depth.c>
//
//  Description: <tt_depth.c> includes the function to depth-first traverse
//               a tree in a full iterative way.
//
//////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////
// Standard include
#include <stdio.h>


//////////////////////////////////////////////////////////////////////////////
// Structure of a Node ie Tree
#include <node.h>


//////////////////////////////////////////////////////////////////////////////
// Defintion for Tree Traversal
#include <tt_depth.h>


//////////////////////////////////////////////////////////////////////////////
//
// FUNCTION NAME:      tree_depth_traversal1
// DESCRIPTION:        depth-first traverse of the tree, calling a supplied
//                     function on each node. The function is called two times
//                     on each node : before the process of its children and after
//                     after the process of its children
//
// PARAMETERS:         root: root of the tree
//                     process: function to be called on each node with a pointer
//                     to the node and a boolean value (TRUE = first process,
//                     FALSE = last process)
//
// RETURN VALUE:       -none-
//
//////////////////////////////////////////////////////////////////////////////

void tree_depth_traversal1 (struct t_node *root,
        void (*process)(struct t_node *node, int first_flag))
{
int dir_flag = TRUE;
 // TRUE  1st exploration of the node, continue with 1st subnode
 // FALSE node completely explored, should contine with sibling
struct t_node *current = root;
 // the current node during exploration

//----- no tree or no user function , nothing to do
if ((root == NULL) || (process == NULL)) return;

//----- the root pre order
(* process) (root, TRUE);

if (has_sub(root))
{
  //----- the exploration loop
  current = get_sub(root);
  while (node_exist(current) && ((current != root) || (dir_flag == TRUE)))
  {
    //--- process the node, dir_Flag : TRUE = prefix, FALSE postfix
    (* process) (current, dir_flag);

    //--- 1st exploration of the node, continue with 1st subnode
    // or stay for 2nd part of the process
    if (dir_flag == TRUE)
    {
      if (has_sub(current))
        current = get_sub(current);
      else
        // 1st exploration of current node is finished
        // go to 2nd exploration of the current node
        dir_flag = FALSE;
    }

    //--- second exploration of the node, should continue with sibling
    // or the parent if no sibling
    else
    {
      if (has_sibling(current))
      {
        current = get_sibling(current);
        // goto 1st exploration of the sibling (now current)
        dir_flag = TRUE;
      }
      else
        current = get_parent(current);
    }


  }
  // ASSERT ((current == root) && (dir_flag == FALSE));
}

//----- the root post order
(* process) (root, FALSE);

}


//////////////////////////////////////////////////////////////////////////////
//
// FUNCTION NAME:      tree_depth_traversal2
// DESCRIPTION:        depth-first traverse of the tree, calling a supplied
//                     function on each node. The function is called two times
//                     on each node : before the process of its children and after
//                     after the process of its children
//
// PARAMETERS:         root: root of the tree
//                     process: function to be called on each node with a pointer
//                     to the node and a boolean value (TRUE = first process,
//                     FALSE = last process)
//
// RETURN VALUE:       -none-
//
//////////////////////////////////////////////////////////////////////////////

void tree_depth_traversal2 (struct t_node *root,
                           void (*process)(struct t_node *node, int first_flag))
{
char dir_flag = TRUE;
 // TRUE  1st exploration of the node, continue with 1st subnode
 // FALSE node completely explored, should contine with sibling
struct t_node *current = root;
 // the current node during exploration
int next_dir_flag = TRUE;
struct t_node *next_current = root;
 // the value for the next step of the loop


//----- no tree or no user function , nothing to do
if ((root == NULL) || (process == NULL)) return;

//----- the root pre order
(* process) (root, TRUE);

//----- the exploration loop
current = get_sub(root);
while (node_exist(current) && ((current != root) || (dir_flag == TRUE)))
{
  //--- (1) Find the next node

  //--- 1st exploration of the node, continue with 1st subnode
  // or stay for 2nd part of the process
  if (dir_flag == TRUE)
  {
    if (has_sub(current))
      next_current = get_sub(current);
    else
      // 1st exploration of current node is finished
      // go to 2nd exploration of the current node
      next_dir_flag = FALSE;
  }

  //--- second exploration of the node, should continue with sibling
  // or the parent if no sibling
  else
  {
    if (has_sibling(current))
    {
      next_current = get_sibling(current);
      // first exploration of the sibling
      next_dir_flag = TRUE;
      }
    else
      next_current = get_parent(current);
  }


  //----- (2) process the current node
  // process the node, dir_Flag : TRUE = prefix, FALSE postfix
  (* process) (current, dir_flag);

  //--- next step of the loop
  current= next_current;
  dir_flag = next_dir_flag;

  }

//----- the root post order
(* process) (root, FALSE);

}


/////////////////////////// This the END of the File /////////////////////////
//////////////////////////////////////////////////////////////////////////////

