#include <iostream>
#include "fp.h"

static void show(const char *title)
	{
	fp a1 = fp(2.0);
	fp a2 = fp(1.0) + fp(3.0) * std::numeric_limits<fp>::epsilon();
	std::cout << '\n' << title << '\n';
	std::cout << (a1 + a2) << '\n';	
	std::cout << (-a1 - a2) << '\n';	
	}

int main()
	{
	show("round to nearest");
	fp::set_round(fp::rm_down);
	show("round toward negative infinity");
	fp::set_round(fp::rm_up);
	show("round toward positive infinity");
	fp::set_round(fp::rm_zero);
	show("round toward zero");
	return 0;
	}