// LdapConnection.h : Declaration of the CLdapConnection

#ifndef __LDAPCONNECTION_H_
#define __LDAPCONNECTION_H_

#include "resource.h"       // main symbols
#include "examples.h"       //LDAP header settings


#define NULL_TERMINATED 0 //required by util
#define MAX_STRING 1024  //for the search output
#define MAXCHARXSTRING 1000 //for strtok_r
#define MAXNUMBEROFATTRIBUTES 10

/////////////////////////////////////////////////////////////////////////////
// CLdapConnection
class ATL_NO_VTABLE CLdapConnection : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CLdapConnection, &CLSID_LdapConnection>,
	public IDispatchImpl<ILdapConnection, &IID_ILdapConnection, &LIBID_ISSNKBLib>
{
public:
	
	LDAP *ld;
	LDAPMessage *result;
	char *stLDAPError;

	CLdapConnection()
	{
		//initialize structures
		ld		= NULL;
		result	= NULL;
		//initialize string
		stLDAPError = NULL;
	}



DECLARE_REGISTRY_RESOURCEID(IDR_LDAPCONNECTION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CLdapConnection)
	COM_INTERFACE_ENTRY(ILdapConnection)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ILdapConnection
public:
	

	//methods of the interface
	STDMETHOD(connectAnonymously)(BSTR host, long port, VARIANT_BOOL* error);
	STDMETHOD(connectAsUser)(BSTR host, long port, BSTR dn, BSTR pwd, VARIANT_BOOL* pError);
	STDMETHOD(isConnected)(VARIANT_BOOL* pConnectStatus);
	STDMETHOD(disconnect)(VARIANT_BOOL* pDisConnectStatus);
	STDMETHOD(search)(BSTR base,
                       long scope,
                       BSTR filter,
					   BSTR attributes,
                       VARIANT_BOOL attrNamesOnly,
					   VARIANT_BOOL* pSearchStatus);

	STDMETHOD(hasMoreSearchResultEntries)(VARIANT_BOOL* hasMore);
	STDMETHOD(nextSearchResultEntry)(VARIANT_BOOL dnOnly,BSTR* pSearchResults);
	STDMETHOD(getLastErrorMessage)(BSTR* pLDAPError);
	STDMETHOD(SearchResultCount)(long* num_entries);

	STDMETHOD(createEntry)(BSTR dn, BSTR attrValuePairs, VARIANT_BOOL* created);
	STDMETHOD(modifyEntry)(BSTR dn, BSTR attrModList, VARIANT_BOOL* modified);
	STDMETHOD(deleteEntry)(BSTR dn, VARIANT_BOOL* deleted);


	//local function declaration
	LPWSTR AllocateUnicodeString(LPSTR  pAnsiString);
	int AnsiToUnicodeString(LPSTR pAnsi, LPWSTR pUnicode, DWORD StringLength);
	int vbtoiAttrOnly(VARIANT_BOOL attrNamesOnly, int* attrOnly);
	int strtok_r(char* input, char* output3, char* output, char token);
	int GetNumberOfAttributes(char* stAttributes, char delimiter);
	int GetAttributePointersArray(char* stAttributes, char* attrs[]);
	void FreeAttributePointersArray(char* stAttributes, char* attrs[]);
	LDAPMod** allocateMods(LDAPMod **mods, int numberOfModes);
	LDAPMod** allocateMods_val(LDAPMod **mods, int modeIndex, int numberOfValues);
	void deallocateMods(LDAPMod **mods, int numberOfModes, int* modValueDim);
	void deallocateMods_val(LDAPMod **mods, int numberOfModes, int* modValueDim);
	bool initializeMods(LDAPMod **mods, char* stAttrValues, int* attrValueArrayDim);
	LDAPMod** SetModValues(char* attrValueListEntry, LDAPMod **mods, int modId);
	int GetModOperation(char* operationMode);
	bool initializeModifyMods(LDAPMod **mods, char* stAttrModList, int* attrValueArrayDim);
	char* GetCert7dbPath();
	int DeleteCert7dbPath(char* certpath);
	};

#endif //__LDAPCONNECTION_H_
