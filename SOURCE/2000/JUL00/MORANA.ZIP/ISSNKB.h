/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Dec 28 16:43:38 1999
 */
/* Compiler settings for D:\NKB\COM\ISSNKB\ISSNKB.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ISSNKB_h__
#define __ISSNKB_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ILdapConnection_FWD_DEFINED__
#define __ILdapConnection_FWD_DEFINED__
typedef interface ILdapConnection ILdapConnection;
#endif 	/* __ILdapConnection_FWD_DEFINED__ */


#ifndef __LdapConnection_FWD_DEFINED__
#define __LdapConnection_FWD_DEFINED__

#ifdef __cplusplus
typedef class LdapConnection LdapConnection;
#else
typedef struct LdapConnection LdapConnection;
#endif /* __cplusplus */

#endif 	/* __LdapConnection_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ILdapConnection_INTERFACE_DEFINED__
#define __ILdapConnection_INTERFACE_DEFINED__

/* interface ILdapConnection */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ILdapConnection;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AB2AEC8F-EE82-11D2-9784-00104B6A7BC7")
    ILdapConnection : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE connectAnonymously( 
            /* [in] */ BSTR host,
            /* [in] */ long port,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0015) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE connectAsUser( 
            /* [in] */ BSTR host,
            /* [in] */ long port,
            /* [in] */ BSTR dn,
            /* [in] */ BSTR pwd,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0016) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE isConnected( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0017) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE disconnect( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0018) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE search( 
            /* [in] */ BSTR base,
            /* [in] */ long scope,
            /* [in] */ BSTR filter,
            /* [in] */ BSTR attributes,
            /* [in] */ VARIANT_BOOL attrNamesOnly,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pSearchStatus) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE hasMoreSearchResultEntries( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0019) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE nextSearchResultEntry( 
            /* [in] */ VARIANT_BOOL dnOnly,
            /* [retval][out] */ BSTR __RPC_FAR *__MIDL_0020) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE getLastErrorMessage( 
            /* [retval][out] */ BSTR __RPC_FAR *__MIDL_0021) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE createEntry( 
            /* [in] */ BSTR dn,
            /* [in] */ BSTR attrValuePairs,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0022) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE modifyEntry( 
            /* [in] */ BSTR dn,
            /* [in] */ BSTR attrModList,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0023) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE deleteEntry( 
            /* [in] */ BSTR dn,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0024) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SearchResultCount( 
            /* [retval][out] */ long __RPC_FAR *num_entries) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILdapConnectionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ILdapConnection __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ILdapConnection __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ILdapConnection __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *connectAnonymously )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ BSTR host,
            /* [in] */ long port,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0015);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *connectAsUser )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ BSTR host,
            /* [in] */ long port,
            /* [in] */ BSTR dn,
            /* [in] */ BSTR pwd,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0016);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *isConnected )( 
            ILdapConnection __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0017);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *disconnect )( 
            ILdapConnection __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0018);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *search )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ BSTR base,
            /* [in] */ long scope,
            /* [in] */ BSTR filter,
            /* [in] */ BSTR attributes,
            /* [in] */ VARIANT_BOOL attrNamesOnly,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pSearchStatus);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *hasMoreSearchResultEntries )( 
            ILdapConnection __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0019);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *nextSearchResultEntry )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL dnOnly,
            /* [retval][out] */ BSTR __RPC_FAR *__MIDL_0020);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *getLastErrorMessage )( 
            ILdapConnection __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *__MIDL_0021);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *createEntry )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ BSTR dn,
            /* [in] */ BSTR attrValuePairs,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0022);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *modifyEntry )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ BSTR dn,
            /* [in] */ BSTR attrModList,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0023);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *deleteEntry )( 
            ILdapConnection __RPC_FAR * This,
            /* [in] */ BSTR dn,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0024);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SearchResultCount )( 
            ILdapConnection __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *num_entries);
        
        END_INTERFACE
    } ILdapConnectionVtbl;

    interface ILdapConnection
    {
        CONST_VTBL struct ILdapConnectionVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILdapConnection_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILdapConnection_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILdapConnection_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILdapConnection_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ILdapConnection_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ILdapConnection_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ILdapConnection_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ILdapConnection_connectAnonymously(This,host,port,__MIDL_0015)	\
    (This)->lpVtbl -> connectAnonymously(This,host,port,__MIDL_0015)

#define ILdapConnection_connectAsUser(This,host,port,dn,pwd,__MIDL_0016)	\
    (This)->lpVtbl -> connectAsUser(This,host,port,dn,pwd,__MIDL_0016)

#define ILdapConnection_isConnected(This,__MIDL_0017)	\
    (This)->lpVtbl -> isConnected(This,__MIDL_0017)

#define ILdapConnection_disconnect(This,__MIDL_0018)	\
    (This)->lpVtbl -> disconnect(This,__MIDL_0018)

#define ILdapConnection_search(This,base,scope,filter,attributes,attrNamesOnly,pSearchStatus)	\
    (This)->lpVtbl -> search(This,base,scope,filter,attributes,attrNamesOnly,pSearchStatus)

#define ILdapConnection_hasMoreSearchResultEntries(This,__MIDL_0019)	\
    (This)->lpVtbl -> hasMoreSearchResultEntries(This,__MIDL_0019)

#define ILdapConnection_nextSearchResultEntry(This,dnOnly,__MIDL_0020)	\
    (This)->lpVtbl -> nextSearchResultEntry(This,dnOnly,__MIDL_0020)

#define ILdapConnection_getLastErrorMessage(This,__MIDL_0021)	\
    (This)->lpVtbl -> getLastErrorMessage(This,__MIDL_0021)

#define ILdapConnection_createEntry(This,dn,attrValuePairs,__MIDL_0022)	\
    (This)->lpVtbl -> createEntry(This,dn,attrValuePairs,__MIDL_0022)

#define ILdapConnection_modifyEntry(This,dn,attrModList,__MIDL_0023)	\
    (This)->lpVtbl -> modifyEntry(This,dn,attrModList,__MIDL_0023)

#define ILdapConnection_deleteEntry(This,dn,__MIDL_0024)	\
    (This)->lpVtbl -> deleteEntry(This,dn,__MIDL_0024)

#define ILdapConnection_SearchResultCount(This,num_entries)	\
    (This)->lpVtbl -> SearchResultCount(This,num_entries)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_connectAnonymously_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [in] */ BSTR host,
    /* [in] */ long port,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0015);


void __RPC_STUB ILdapConnection_connectAnonymously_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_connectAsUser_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [in] */ BSTR host,
    /* [in] */ long port,
    /* [in] */ BSTR dn,
    /* [in] */ BSTR pwd,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0016);


void __RPC_STUB ILdapConnection_connectAsUser_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_isConnected_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0017);


void __RPC_STUB ILdapConnection_isConnected_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_disconnect_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0018);


void __RPC_STUB ILdapConnection_disconnect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_search_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [in] */ BSTR base,
    /* [in] */ long scope,
    /* [in] */ BSTR filter,
    /* [in] */ BSTR attributes,
    /* [in] */ VARIANT_BOOL attrNamesOnly,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pSearchStatus);


void __RPC_STUB ILdapConnection_search_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_hasMoreSearchResultEntries_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0019);


void __RPC_STUB ILdapConnection_hasMoreSearchResultEntries_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_nextSearchResultEntry_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL dnOnly,
    /* [retval][out] */ BSTR __RPC_FAR *__MIDL_0020);


void __RPC_STUB ILdapConnection_nextSearchResultEntry_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_getLastErrorMessage_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *__MIDL_0021);


void __RPC_STUB ILdapConnection_getLastErrorMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_createEntry_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [in] */ BSTR dn,
    /* [in] */ BSTR attrValuePairs,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0022);


void __RPC_STUB ILdapConnection_createEntry_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_modifyEntry_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [in] */ BSTR dn,
    /* [in] */ BSTR attrModList,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0023);


void __RPC_STUB ILdapConnection_modifyEntry_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_deleteEntry_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [in] */ BSTR dn,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *__MIDL_0024);


void __RPC_STUB ILdapConnection_deleteEntry_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILdapConnection_SearchResultCount_Proxy( 
    ILdapConnection __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *num_entries);


void __RPC_STUB ILdapConnection_SearchResultCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILdapConnection_INTERFACE_DEFINED__ */



#ifndef __ISSNKBLib_LIBRARY_DEFINED__
#define __ISSNKBLib_LIBRARY_DEFINED__

/* library ISSNKBLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ISSNKBLib;

EXTERN_C const CLSID CLSID_LdapConnection;

#ifdef __cplusplus

class DECLSPEC_UUID("AB2AEC90-EE82-11D2-9784-00104B6A7BC7")
LdapConnection;
#endif
#endif /* __ISSNKBLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
