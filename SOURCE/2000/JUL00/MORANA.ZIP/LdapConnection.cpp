// LdapConnection.cpp : Implementation of CLdapConnection
#include "stdafx.h"
#include "ISSNKB.h"
#include "LdapConnection.h"
#include "examples.h"  //LDAP header settings
#include <comdef.h> //for _bstr_t objects
//for SSL enabling
#include <ldap_ssl.h>


/////////////////////////////////////////////////////////////////////////////
// CLdapConnection


STDMETHODIMP CLdapConnection::connectAnonymously(BSTR host, long port, VARIANT_BOOL* pError){
/*

	Purpose: set anonymous connection to LDAP server

	Parameters:
 
	host

        Space-delimited list of one or more host names (or IP address in dotted notation, such as "141.211.83.36")
        of the LDAP servers that you want the LDAP client to connect to. 

        The names can be in hostname:portnumber format (in which case, portnumber overrides the port number
        specified by the defport argument. 
	
	port

        Default port number of the LDAP server. To specify the standard LDAP port (port 389), 
        as the value for this parameter. 


        Connection handle, which is a pointer to an LDAP structure containing information about the connection to
        the LDAP server. 

	returns:
		HRESULT OK/FALSE as process OK/NO
		Variant boolean as retval false/success, true/error

*/

	//local
	unsigned int len = _bstr_t(host).length()+1;
	char* stHost = new char[len];
	char* certvar = NULL;

	//BOOLEAN for internal processing
	*pError = VARIANT_FALSE;
	HRESULT hr = S_FALSE; //for error handling

	// get a handle to an LDAP connection //
	if(wcstombs( stHost, host, len ) >0 && len >1){
	
		//select simple LDAP
		if(port == LDAP_PORT){
			if ( (ld = ldap_init(stHost, port )) != NULL ) 
				//set flags for occurring error
				hr = S_OK;
		}

		//select LDAP on SSL
		if(port == LDAPS_PORT){
			//ret = ldapssl_client_init("C:/Program Files/Netscape/Users/mmorana/cert7.db", NULL);
		
			//get the cert7db path from the user variable
			certvar = GetCert7dbPath();
			
			if(certvar != NULL){
			//get SSL server authentication & open LDAP connection
				if(ldapssl_client_init( certvar, NULL ) == 0)
					if((ld = ldapssl_init( stHost, port, 1 )) != NULL ) 
						hr = S_OK;
			DeleteCert7dbPath(certvar);
			}
		}
	}

			
		//stLDAPError = ldap_err2string(ret);
			 
	
	delete[] stHost;

	//set for errors flags
	if(hr == S_FALSE)
		*pError = VARIANT_TRUE;


	return hr;	
}

STDMETHODIMP CLdapConnection::connectAsUser(BSTR host, long port, BSTR dn, BSTR pwd, VARIANT_BOOL* pError)
{

/*
	Purpose: connect to LDAP Server and perform LDAP user authentication

	Parameters 

	host

        Space-delimited list of one or more host names (or IP address in dotted notation, such as "141.211.83.36")
        of the LDAP servers that you want the LDAP client to connect to. 

        The names can be in hostname:portnumber format (in which case, portnumber overrides the port number
        specified by the defport argument. 
	
	port

        Default port number of the LDAP server. To specify the standard LDAP port (port 389), 
        as the value for this parameter. 


       Connection handle, which is a pointer to an LDAP structure containing information about the connection to
       the LDAP server. 
	
	dn

       Distinguished name (DN) of the user who wants to authenticate. For anonymous authentication, set this or
       the passwd argument to NULL. 
 
	pwd

       Password of the user who wants to authenticate. For anonymous authentication, set this or the who
       argument to NULL. 

	returns:

		HRESULT as return method handle (connection & authentication) OK=success/FALSE=not successful
		Variant boolean as retval for error false = no error, true=error
*/

	//BOOLEAN for internal processing, imply errors, credit for success
	*pError = VARIANT_FALSE;
	HRESULT hr = S_FALSE; //for error handling
	bool gofor = false;

	//local
	unsigned int hostlen = _bstr_t(host).length()+1;
	unsigned int dnlen = _bstr_t(dn).length()+1;
	unsigned int pwdlen = _bstr_t(pwd).length()+1;

	char* stHost = new char[hostlen];
	char* stDn   = new char[dnlen];
	char* stPwd  = new char[pwdlen];
	char* certvar = NULL;

	// get host string && != NULL entries
	if(wcstombs( stHost, host, hostlen ) >0 && hostlen >1){
		// get a handle to an LDAP connection //
		
		//select simple LDAP
		if(port == LDAP_PORT)
			if ( (ld = ldap_init(stHost, port )) != NULL ) 
			//set flags for occurring error
				gofor = true;

		//select LDAP with SSL
		if(port == LDAPS_PORT){
			
			//get the cert7db path from the user variable
			certvar = GetCert7dbPath();
			
			if(certvar != NULL){
			//get SSL server authentication & open LDAP connection
				if(ldapssl_client_init( certvar, NULL ) == 0)
					if((ld = ldapssl_init( stHost, port, 1 )) != NULL ) 
						gofor = true;	
			DeleteCert7dbPath(certvar);
			}
		}

	}

	if(gofor == true)
		//looking for authentication
		// get dn string & pwd string from input
		if(wcstombs( stDn, dn, dnlen ) >0 && dnlen >1)
			//get pwd string
			if(wcstombs( stPwd, pwd, pwdlen ) >0 && pwdlen >1)
				//connect as user
				if ( ldap_simple_bind_s( ld, stDn, stPwd ) == LDAP_SUCCESS ) 
					hr = S_OK;
					
	delete[] stHost;
	delete[] stDn;
	delete[] stPwd;

	//set for errors flags
	if(hr == S_FALSE)
		*pError = VARIANT_TRUE;

	return hr;	

}

STDMETHODIMP CLdapConnection::isConnected(VARIANT_BOOL* pConnectStatus){
/*
	Purpose: checks for connection to LDAP server

	Parameters : none

	Returns: true if there is an active connection, false otherwise. 
*/

	//BOOLEAN for internal processing
	*pConnectStatus = VARIANT_TRUE;
	HRESULT hr = S_OK; //for error handling
	
	if(ld == NULL){
		*pConnectStatus = VARIANT_FALSE;
		hr= S_FALSE;
	}

  return hr;
}


STDMETHODIMP CLdapConnection::disconnect(VARIANT_BOOL* pDisConnectStatus){
/*
	Purpose: disconnects the client (i.e. unbinds) from the LDAP server
	Parameters: none
	Returns true if is disconnected, false otherwise
*/
	HRESULT hr = S_FALSE; //for error handling
	*pDisConnectStatus = VARIANT_FALSE;
	

	//check for a no null ld
	if(ld != NULL)
		if(ldap_unbind_s( ld ) == LDAP_SUCCESS){
			//once ld structure has been free by unbind
			//ld is set to null
			ld = NULL;
			//set flags
			*pDisConnectStatus = VARIANT_TRUE;
			hr = S_OK;
		}

	//before disconnect be sure you free all messages
	if(result != NULL){
		ldap_msgfree(result);
		result = NULL;
	}
	

	return hr;

}


STDMETHODIMP CLdapConnection::search(BSTR base,
                       long scope,
                       BSTR filter,
					   BSTR attributes,
                       VARIANT_BOOL attrNamesOnly,
					   VARIANT_BOOL* pSearchStatus){
/*
	 Purpose

     Perform a search (syncronous) against the currently-connected LDAP server. Search results should be retrieved using a loop that calls
     hasMoreSearchResultEntries() and nextSearchResultEntry(). 

     Parameters: 
          base - the DN of the base entry for the search 
          scope - the scope of the search (0 = base, 1 = onelevel, 2 = subtree) 
          filter - the filter defining what is to be searched for; this must be a valid LDAP search filter 
          attributes - a comma-delimited list of the names of the attributes to be returned for each entry found by the search
		  attrNamesOnly - true if only attribute names should be returned; false if both attribute names and values should be returned 
     Returns: 
          HRESULT OK if the search succeeded, false otherwise
		  pSearchStatus: true if the search succeeded, false otherwise
*/

	HRESULT hr = S_FALSE; //for error handling
	*pSearchStatus = VARIANT_FALSE;
	int intAttrNamesOnly = 0;
	int searchError = 0;
	//char** attrs = NULL; //all attributes returned
	char* attrs[MAXNUMBEROFATTRIBUTES];
	stLDAPError = NULL;   //initialize for error


	unsigned int baselen		= _bstr_t(base).length()+1;
	unsigned int filterlen		= _bstr_t(filter).length()+1;
	unsigned int attributeslen	= _bstr_t(attributes).length()+1;
	
	char* stBase		= new char[baselen];
	char* stFilter		= new char[filterlen];
	char* stAttributes  = new char[attributeslen];

	//initialize LDAPMessage result for consecutive searches
	if(result != NULL){
		ldap_msgfree( result );
		result = NULL;
	}

	// get input strings and checks for correct entries
	if(wcstombs( stBase, base, baselen ) >0 && baselen >1)
		if(wcstombs( stFilter, filter, filterlen ) >0 && filterlen >1)
			if(wcstombs( stAttributes, attributes, attributeslen ) >=0 && attributeslen >=1)
				if(vbtoiAttrOnly(attrNamesOnly, &intAttrNamesOnly) == 0)
					if(scope ==0 || scope ==1 || scope ==2){
						//if input entries are correct in format and value go for the search
						//gets the attribute array
						if(GetAttributePointersArray(stAttributes, attrs))	
							searchError = ldap_search_ext_s ( ld, stBase, scope, stFilter,attrs, 
									  intAttrNamesOnly, NULL, NULL, NULL, NULL, &result );
						else
							searchError = ldap_search_ext_s ( ld, stBase, scope, stFilter,NULL, 
									  intAttrNamesOnly, NULL, NULL, NULL, NULL, &result );

						//deallocate the memory for the array of attributes
						FreeAttributePointersArray(stAttributes, attrs);

						//get the error from the search if any
						if(searchError != 0)
							stLDAPError = ldap_err2string(searchError);
					
						//overlook error due to time limit or size limit (by now)
						if( searchError == LDAP_SUCCESS || 
							searchError == LDAP_TIMELIMIT_EXCEEDED ||
							searchError == LDAP_SIZELIMIT_EXCEEDED) {
							//set search OK
								*pSearchStatus = VARIANT_TRUE;
								hr = S_OK;
						}
					}
	//deallocate what is left
	delete[] stBase;
	delete[] stFilter;
	delete[] stAttributes;

	return hr;

}


STDMETHODIMP CLdapConnection::getLastErrorMessage(BSTR* pLDAPError){
/*
	Purpose:
	
	Retrieve the error message, if any, for the previously-executed method. If the previously-executed method succeeded, null is returned. 

    Returns: 
    a string describing the error, if any, encountered by the previously-executed method. 
	HRESULT OK if error is returned, false otherwise
*/
	HRESULT hr = S_FALSE; //for error handling

	if(stLDAPError != NULL){
		//return the error string
		LPWSTR wsz = AllocateUnicodeString(stLDAPError);
		*pLDAPError = ::SysAllocString(wsz);
		if(*pLDAPError == NULL)
			hr = E_OUTOFMEMORY;
		else
			hr= S_OK;
	}
	else
	{
		//return no error string
		wchar_t wsz[] =L"No errors";
		*pLDAPError = ::SysAllocString(wsz);
		if(*pLDAPError == NULL)
			hr = E_OUTOFMEMORY;
		else
			hr= S_OK;
	}

	return hr;
}

STDMETHODIMP CLdapConnection::hasMoreSearchResultEntries(VARIANT_BOOL* hasMore){
/*
	Purpose
	
	Determine whether any search result entries remain to be retrieved. 
	This method should be used in conjunction with nextSearchResultEntry. 

    Returns: 
    true if there are more search results to be retrieved, false otherwise. 
*/

	HRESULT hr = S_FALSE; //for error handling
	*hasMore = VARIANT_FALSE;
	int num_entries;

	//get number of entries from the first message
	num_entries = ldap_count_entries( ld, result );
	
	if(num_entries > 0){
		hr = S_OK; //for error handling
		*hasMore = VARIANT_TRUE;
	}

	return hr;
}


STDMETHODIMP CLdapConnection::nextSearchResultEntry(VARIANT_BOOL dnOnly, BSTR* pSearchResults){
/*

  Purpose:

  Retrieve the next search result entry. The method hasMoreSearchResultEntries() should be called before calling this method, to verify that additional
  search results are available. The search() method is used to obtain the search results that are retrieved by this method. 

  Returns: 
  A string describing the next entry found by the most recent search. The string has the following format:

  dn;attr1=value1,value2,value3;attr2=value;...

  In the above string, ";" is shown as the delimiter between attribute=value pairs, and "," is shown as the delimiter between the individual values of a
  multi-valued attribute. Actually, these delimiters will be the characters returned by the getAttrDelimiter() and getAttrValueDelimiter()
  methods, respectively. These delimiters are not guaranteed to be printable characters.

  If an error occurs, null is returned. 
*/
	HRESULT hr = S_FALSE; //for error handling

	//locals
	int msgtype, i;
	char*  stSearchResults = new char[MAX_STRING];
	char* dn;
	char* a;
	char** vals;
	BerElement *ber;

	//initialize stSearchResults
	*stSearchResults = NULL;

	//for the next entry I should have next entry
	if(result != NULL){

		// Determine what type of message was sent from the server. */
		msgtype = ldap_msgtype( result);

		switch( msgtype ) {

			//If the result was an entry found by the search, get and store the
			// attributes and values of the entry. 

		case LDAP_RES_SEARCH_ENTRY:

			// Get and store the DN of the entry. 
			if (( dn = ldap_get_dn( ld, result )) != NULL ) {

				strcpy(stSearchResults, dn);

				ldap_memfree( dn );

			}

			if(dnOnly == VARIANT_TRUE){
				
				//Iterate through each attribute in the entry. 
				for ( a = ldap_first_attribute( ld, result, &ber );
					a != NULL; a = ldap_next_attribute( ld, result, ber ) ) {
			
					//construct ;a=
					strcat(stSearchResults, ";");
					strcat(stSearchResults, a);
				
					// Get attribute values 
					if (( vals = ldap_get_values( ld, result, a )) != NULL ) {

						strcat(stSearchResults, "=");

						for ( i = 0; vals[ i ] != NULL; i++ ) {
							
							strcat(stSearchResults, vals[i]);

							//if next value is not null put a delimiter
							if(vals[i+1] !=NULL)
								strcat(stSearchResults, ",");
						
						}
						ldap_value_free( vals );

					}

					ldap_memfree(a);
				}//_for

				if ( ber != NULL ) {

					ber_free( ber, 0 );

				}
			}//end if dnOnly

			break;

		case LDAP_RES_SEARCH_REFERENCE:

			// The server sent a search reference encountered during the 
			//search operation.
		break;

		default:

		break;
	
		}//switch
	
		//get the next message
		result = ldap_next_message(ld,result );

	}//if_msg
	
	//pass stSearchResults to pSearchResults
	LPWSTR psztest = AllocateUnicodeString(stSearchResults);
	*pSearchResults = ::SysAllocString(psztest);

	delete[] stSearchResults;
	
	
	if(*pSearchResults == NULL)
		hr = E_OUTOFMEMORY;
	else
		hr= S_OK;
			
	return hr;
	
}


STDMETHODIMP CLdapConnection::createEntry(BSTR dn, BSTR attrValuePairs, VARIANT_BOOL* created){
/*

	 Purpose:

     Create a new entry in the currently-connected LDAP directory. 

     Parameters: 
          dn - the distinguished name of the entry to be created 
          attrValuePairs - a string defining attribute values; the format of this string is as follows:

               attr1=value1,value2,value3;attr2=value;...

               In the above string, ";" is shown as the delimiter between attribute=value pairs, and "," is shown as the delimiter between the individual
               values of a multi-valued attribute. Actually, these delimiters should be the characters returned by the getAttrDelimiter() and
               getAttrValueDelimiter() methods, respectively. These delimiters are not guaranteed to be printable characters.

     Returns: 
          true if entry creation succeeded, false otherwise 
*/

	HRESULT hr = S_FALSE; //for error handling
	*created = VARIANT_FALSE;
	LDAPMod       **mods = NULL;
    int     rc;
	int		numberOfModes;
	int		gofor =0;
	int*	arrayValuesDim = NULL;


	unsigned int dnLen	= _bstr_t(dn).length()+1;
	unsigned int attrValuesPairsLen	= _bstr_t(attrValuePairs).length()+1;
	char* stAttrValuesPairs  = new char[attrValuesPairsLen];
	char* stDn = new char[dnLen];

	//convert BSTRs to Strs
	if(wcstombs(stDn , dn, dnLen ) >0 && dnLen >1)
		if(wcstombs(stAttrValuesPairs , attrValuePairs, attrValuesPairsLen ) >=0 && attrValuesPairsLen >=1)
			gofor = 1;
   
	if(gofor =1){	
		//parse the attributes and values string
		char delimiter =';';
		numberOfModes = GetNumberOfAttributes(stAttrValuesPairs ,delimiter);

		//array to hold value array dimension
		arrayValuesDim= new int[numberOfModes];

		//allocate mods
		mods = allocateMods(mods, numberOfModes);

		

		if(mods != NULL){
			
			//initialize mods & allocates mod_values
			initializeMods(mods,stAttrValuesPairs, arrayValuesDim);
	
			//Perform the add operation
			rc = ldap_add_ext_s( ld, stDn, mods, NULL, NULL );

			//deallocate mods
			deallocateMods(mods,numberOfModes,arrayValuesDim);

		}

		//get the error if any
		if(rc != LDAP_SUCCESS){
			stLDAPError = ldap_err2string(rc);
		}else{			
		//set OK
			*created = VARIANT_TRUE;
			hr = S_OK;
		}


	}//end gofor
   


   delete[]stAttrValuesPairs;
   delete[]stDn;
   delete[]arrayValuesDim;

	
   return hr;
}


STDMETHODIMP CLdapConnection::modifyEntry(BSTR dn, BSTR attrModList, VARIANT_BOOL* modified){

/*
	 Purpose:

     Modify an entry in the currently-connected LDAP directory. 

     Parameters: 
          dn - the distinguished name of the entry to be modified 
          attrModList - a string defining attribute modifications to be performed. The format of this string is as follows:

               a:attr1=value1,value2,value3;d:attr2[=value];r:attr3=value;...

               In the above string, a: entries indicate attribute values to be added, d: entries indicate values to be deleted (note the =value part is optional in
               this case), and r: entries indicate attribute values that are to replace any existing values. Multiple attribute values may be included for any of the
               attribute entries (though this is shown above only for the first listed modification).

               Also, in the above string, ";" is shown as the delimiter between modifications, and "," is shown as the delimiter between individual values within a
               modification. Actually, these delimiters should be the characters returned by the getAttrDelimiter() and getAttrValueDelimiter()
               methods, respectively. These delimiters are not guaranteed to be printable characters.

     Returns: 
          true if entry modification succeeded, false otherwise. If failure is returned, then the LDAP directory remains unmodified; no partial modifications can
          occur. 
*/

	HRESULT hr = S_FALSE; //for error handling
	*modified = VARIANT_FALSE;
	LDAPMod       **mods = NULL;
	int            rc;
	int numberOfModes;
	int* arrayValuesDim = NULL;
	int gofor;

	/* Perform the modify operation. */
	unsigned int dnLen	= _bstr_t(dn).length()+1;
	char* stDn = new char[dnLen];
	unsigned int attrModListLen = _bstr_t(attrModList).length()+1;
	char* stAttrModList = new char[attrModListLen];

	//convert BSTRs to Strs
	if(wcstombs(stDn , dn, dnLen ) >0 && dnLen >1)
		if(wcstombs(stAttrModList ,attrModList , attrModListLen ) >=0 && attrModListLen >=1)
			gofor = 1;
   
	if(gofor =1){	

		//parse to get number of modes (i.e. add(0), delete(1), replace(2)) 
		char delimiter =';';
		numberOfModes = GetNumberOfAttributes(stAttrModList ,delimiter);

		//array to hold value array dimension
		arrayValuesDim= new int[numberOfModes];

		//allocate mods
		mods = allocateMods(mods, numberOfModes);

			if(mods != NULL){
			
			//initialize mods & allocates mod_values
			initializeModifyMods(mods,stAttrModList, arrayValuesDim);
	
			//Perform the add operation
			rc = ldap_modify_ext_s( ld, stDn, mods, NULL, NULL );

			//deallocate mods
			deallocateMods(mods,numberOfModes,arrayValuesDim);
		}

		//get the error if any
		if(rc != LDAP_SUCCESS){
			stLDAPError = ldap_err2string(rc);
		}else{			
		//set OK
			*modified = VARIANT_TRUE;
			hr = S_OK;
		}

		if(arrayValuesDim !=NULL)
			delete[]arrayValuesDim;

	}


	delete[]stAttrModList;
	delete[]stDn;

	return hr;
}


STDMETHODIMP CLdapConnection::deleteEntry(BSTR dn, VARIANT_BOOL* deleted){

/*   
	
	 Purpose:
     Delete the indicated entry from the currently-connected LDAP directory. 

     Parameters: 
          dn - the distinguished name of the entry to be deleted 
     Returns: 
          true if the operation succeeded, false otherwise 
*/
		HRESULT hr = S_FALSE; //for error handling
		*deleted = VARIANT_FALSE;
		LDAPMod       **mods = NULL;

		int            rc;
		unsigned int dnLen	= _bstr_t(dn).length()+1;
		char* stDn = new char[dnLen];

		//convert BSTRs to Strs
		if(wcstombs(stDn , dn, dnLen ) >0 && dnLen >1)
			rc = ldap_delete_ext_s( ld, stDn, NULL, NULL );

		//get the error from the delete if any
		if(rc != LDAP_SUCCESS){
			stLDAPError = ldap_err2string(rc);
		}else{			
		//set delete OK
			*deleted = VARIANT_TRUE;
			hr = S_OK;
		}

		delete[] stDn;

		return hr;
}





//local utilities
LPWSTR CLdapConnection::AllocateUnicodeString(LPSTR  pAnsiString)
{
    LPWSTR  pUnicodeString = NULL;

    if (!pAnsiString)
        return NULL;

    pUnicodeString = (LPWSTR)LocalAlloc(
                        LPTR,
                        strlen(pAnsiString)*sizeof(WCHAR) + sizeof(WCHAR)
                        );

    if (pUnicodeString) {

        AnsiToUnicodeString(
            pAnsiString,
            pUnicodeString,
            0
            );
    }

    return pUnicodeString;
}


int CLdapConnection::AnsiToUnicodeString(LPSTR pAnsi, LPWSTR pUnicode, DWORD StringLength)
{
    int iReturn;

    if( StringLength == 0 )
        StringLength = strlen( pAnsi );

    iReturn = MultiByteToWideChar(CP_ACP,
                                  MB_PRECOMPOSED,
                                  pAnsi,
                                  StringLength + 1,
                                  pUnicode,
                                  StringLength + 1 );

    //
    // Ensure NULL termination.
    //
    pUnicode[StringLength] = 0;

    return iReturn;
}
 

int CLdapConnection::vbtoiAttrOnly(VARIANT_BOOL attrNamesOnly, int *attrOnly)
{
	//purpose: convert attrOnly from type VARIANT_BOOL to integer
	//Parameters:
	//Input:
	//attrNamesOnly VARIANT_BOOL for attributes only(TRUE) or names and values (FALSE)
	//Output
	//attrOnly reference to int=0/1 for attributes only yeas/no
	//on input error returns -1

    int error = -1;

	//if only names
	if(attrNamesOnly == VARIANT_TRUE)
		*attrOnly = 1;

	//if both names and attributes
	if(attrNamesOnly == VARIANT_FALSE)
		*attrOnly = 0;

	//check for errors
	if(attrNamesOnly == VARIANT_TRUE || attrNamesOnly == VARIANT_FALSE)
		error = 0;

	return error;
}


int CLdapConnection::strtok_r(char* input, char* output3, char* output, char token){
	//re-entrant user version of strtok
	//to work with multithreading environments (MFC strtok does not!)
	//for char tokens only
	//strings max MAXCHARXSTRING is 80 characters
	//Parameters are:
	//input: input string 
	//output3: is the string up to the first occurrence of the token
	//output:  is what is left to parse of the original string
	//token: is the char we are looking for
	//Returns:
	//1 if token is found, output3 = parsed string, output = string left to parse
	//0 if token is not found, output3 = input and output is null 


	int i, j;
	char output1[MAXCHARXSTRING];
	char output2[MAXCHARXSTRING];
	char input1[MAXCHARXSTRING];
	char* nullString = "";
	int tokenFound = 0;

	if(strcmp(input, nullString) != 0)
	{

		strcpy(input1, input);

		for(i=0; i < MAXCHARXSTRING; i++){
			output1[i] = input1[i];
			if(output1[i] == '\0')
				break;
			if(output1[i] == token){
				tokenFound = 1;
				output1[i] = '\0';
				for(j = 0; j < MAXCHARXSTRING; j++){
					output2[j] = input1[j+i+1];
					if(output2[j] == '\0')
						break;
				}
				break;
			}
		}
	}

	//copy the outputs
	if(tokenFound == 1){
		strcpy(output3, output1);
		strcpy(output, output2);
	} else {
		strcpy(output3, input);
		strcpy(output,  nullString);
	}
	
	return tokenFound;
}


int CLdapConnection::GetNumberOfAttributes(char* stAttributes, char delimiter){
/*
	Purpose:
	parse the input string of attribute names (attr1,attr2, attrN)
	and return the number of attributes N in the string

	Input:
	stAttributes: string of the attributes names separated by char delimiter

	Returns:
	the number of attributes if successful
	or -1 if there is an error in the input such as "attr,"
*/

	bool AttributesParsed = false;

	int     tokenFound = 0;
	int		numberOfAttributes = 0;

	char* token = new char[MAXCHARXSTRING];
	char* token1 = new char[MAXCHARXSTRING];
	char* token2 = new char[MAXCHARXSTRING];

	tokenFound = strtok_r(stAttributes, token, token1, delimiter);

	if(tokenFound == 0)
		//check is no attribute or one attribute
		if(strlen(stAttributes) != 0)
			numberOfAttributes = 1;	
		
	//there are two or more attributes
	if(tokenFound != 0 && strlen(token1) != 0 && strlen(token) !=0)
		numberOfAttributes = 2;	
	//handle case one attr one comma (example "attr1," error in input)
	if(tokenFound != 0 && strlen(token) != 0 && strlen(token1) ==0)
		numberOfAttributes = -1;	

	//check if there are more than 2 attributs
	if(numberOfAttributes != -1)
		while( tokenFound != 0)   {
		
		//output to be next input
		tokenFound = strtok_r(token1, token, token2, delimiter);
		strcpy(token1, token2);

		//update attribute count++;
		if(tokenFound != 0)
			numberOfAttributes++;
		}

	delete[] token;
	delete[] token1;
	delete[] token2;

	return numberOfAttributes;

}



int CLdapConnection::GetAttributePointersArray(char* stAttributes, char* attrs[]){
/*
	Purpose:
	Allocates memory and initialize the array if pointers
	for the array string to be passed to Netscape search API

	Input:
	stAttributes: the string (char*) with the attribute name

	Output
	the array of strings (char**) of attribute names

	Returns:
	0 for NULL array (no memory allocation)
	1 for memory array allocation

*/

	int i = 0;
	int arrayNotNull =0;
	int numberOfAttributes;

	//allocate tokens for the strtok_r
	char* token = new char[MAXCHARXSTRING];
	char* token1 = new char[MAXCHARXSTRING];
	char* token2 = new char[MAXCHARXSTRING];
	char	comma = ',';
	int     tokenFound = 0;
	char word[MAXCHARXSTRING];

	//get the number of attributes
	numberOfAttributes = GetNumberOfAttributes(stAttributes,comma);
	
	if(numberOfAttributes > 0){

		arrayNotNull = 1;
		//get the first parsed value
		tokenFound = strtok_r(stAttributes, token, token1, comma);

		//parse the loop
		for (i=0; i<numberOfAttributes; i++){
			//allocate the array elements
			attrs[i] = (char*) calloc(strlen(word)+1, sizeof(char));
		
			//write on each element
			strncpy(attrs[i], token, MAXCHARXSTRING);
		
			//get next token
			tokenFound = strtok_r(token1, token, token2, comma);
			strncpy(token1, token2, MAXCHARXSTRING);
		}
	
	
		//pass NULL to the remaining part of the array
		for(i=numberOfAttributes; i<MAXNUMBEROFATTRIBUTES; i++){
			attrs[i] = (char*) calloc(strlen(word)+1, sizeof(char));
			attrs[i] = NULL;
		}
	}

	//deallocate tokens
	delete[]token;
	delete[]token1;
	delete[]token2;


	return arrayNotNull;
}

void CLdapConnection::FreeAttributePointersArray(char* stAttributes, char* attrs[]){
/*
	Purpose:
	Frees for the array of char pointers

	Input:
	the array of strings (char**) of attribute names

	Return
	true/false success/not success
*/

	int numberOfAttributes;
	int i;
	char comma =',';

	//get the number of attributes
	numberOfAttributes = GetNumberOfAttributes(stAttributes,comma);
	
	if(numberOfAttributes == 0){
		return;
	}else {
		//parse the loop
		for (i=0; i<numberOfAttributes; i++){
			//deallocate the array elements
			if(attrs[i] != NULL)
				free(attrs[i]);
		}

	}

}


STDMETHODIMP CLdapConnection::SearchResultCount(long* num_entries){
/*
	Purpose:

    Determine the number of entries found by the previous call of search(). 

    Returns: 
          the number of directory entries found by the previous search 

*/

	HRESULT hr = S_FALSE; //for error handling

	//get number of entries from the first message
	if(result != NULL) 
		*num_entries = ldap_count_entries( ld, result );
	else
		*num_entries = 0;
		
	if(num_entries > 0)
		HRESULT hr = S_OK; //for error handling

	return hr;
}


LDAPMod** CLdapConnection::allocateMods(LDAPMod **mods, int numberOfModes){
/*
	Puropose: 
	Allocates memory for LDAPMods structure needed for ldap_add

	Paramers: double pointer to LDAPMods structure, numberOfModes (i.e attributes)
	Returns:  allocated LDAPMods or NULL
*/
	int i;

	mods = ( LDAPMod ** ) malloc(( numberOfModes+1) * sizeof( LDAPMod * ));
	
	if ( mods == NULL ) 
		return mods;

	for ( i = 0; i < numberOfModes; i++ ) {
		if (( mods[ i ] = ( LDAPMod * ) malloc( sizeof( LDAPMod ))) == NULL ) 
		mods = NULL;
	}

	
	//allocate char* for mod_type
	for( i = 0; i < numberOfModes; i++ ) 
		mods[i]->mod_type = (char*) malloc((MAXCHARXSTRING) * sizeof(char));

	return mods;
}


LDAPMod** CLdapConnection::allocateMods_val(LDAPMod **mods, int modeIndex, int numberOfValues){
/*
	Puropose: 
	Allocates memory for LDAPMods.mod_values sub-structure needed for ldap_add

	Paramers: double pointer to LDAPMods structure, numberOfModes (i.e attributes)
	Returns:  allocated LDAPMods or NULL
*/

	int j;

	//allocate char** for mods_val
	if(mods != NULL){
		//for ( i = 0; i < numberOfModes; i++ ) {
			//allocate char**
			mods[modeIndex]->mod_values = ( char ** ) malloc(( numberOfValues+1 ) * sizeof( char * ));
			//allocate char*
				for ( j = 0; j < numberOfValues; j++ )
					mods[modeIndex]->mod_values[j] = ( char * ) malloc((MAXCHARXSTRING) * sizeof( char ));
		//}
	}

	


	return mods;
}



void CLdapConnection::deallocateMods(LDAPMod **mods, int numberOfModes, int* modValueDim){
/*
	Puropose: 
	Deallocates memory of mods

	Paramers:	mods: double pointer to LDAPMods structure
				numberOfMods: numer of mods int the structure
*/

	int i, j;

	//deallocate mod_types
	for( i = 0; i < numberOfModes; i++ ){
			free(mods[i]->mod_type);
	}


	for( i = 0; i < numberOfModes; i++ ){ 	
		//deallocate nested char** for mod_values
		//deallocate char**
		for ( j = 0; j < modValueDim[i]; j++ )
				free((mods[i]->mod_values[j]));
		
		//deallocate char*
		free((mods[i]->mod_values));
	}


	//deallocate LDAPMod**
	for (i = 0; i < numberOfModes; i++ ) {

      free( mods[ i ] );

   }

   free( mods );

}


void CLdapConnection::deallocateMods_val(LDAPMod **mods, int numberOfModes, int* modValueDim){
/*
	Puropose: 
	Deallocates memory of mods[i].mod_values

	Paramers:	mods: double pointer to LDAPMods structure
				numberOfMods: numer of mods int the structure
*/

	int i,j;

	for( i = 0; i < numberOfModes; i++ ){ 	
		//deallocate nested char** for mod_values
		//deallocate char**
		for ( j = 0; j < modValueDim[i]; j++ )
				free((mods[i]->mod_values[j]));
		
		//deallocate char*
			free((mods[i]->mod_values));
	}

	//deallocate the modValueDim
	free(modValueDim);

}


bool CLdapConnection::initializeMods(LDAPMod **mods, char* stAttrValues, int* attrValueArrayDim){
/*
	Puropose: 
	Initialize the LDAPMods structure needed for ldap_add

	Paramers:	double pointer to LDAPMods structure
				stAttrValuesString ="attr1=val1,val2,val3;attr2=val1,val2,val3
*/

	//for the strtok_r
	char* token		= new char[MAXCHARXSTRING];
	char* token1	= new char[MAXCHARXSTRING];
	char* token2	= new char[MAXCHARXSTRING];
	int  tokenFound = 0;

	//for parsing the entries
	char* attrValuePairEntry	= new char[MAXCHARXSTRING];
	char* attrNameEntry			= new char[MAXCHARXSTRING];
	char* attrValueListEntry	= new char[MAXCHARXSTRING];
	int numberOfModes, numberOfValues;
	char attribEntryDelimiter =';';
	char attribNameDelimiter  ='=';
	char attribValueDelimiter =',';
	bool error = false;

	//get number of mods
	numberOfModes = GetNumberOfAttributes(stAttrValues, attribEntryDelimiter);

	//construct the mods array
	for(int i=0; i<=numberOfModes; i++){

		//parse each attribute=value pair entry
		tokenFound = strtok_r(stAttrValues, token, token1, attribEntryDelimiter);

		//if multiple attributes (;) or single attribute=value entry
		if(tokenFound !=0 || strcmp(stAttrValues,"") !=0){

			//store the entries left (for the next loop)
			strcpy(stAttrValues,token1);

			//parse the entry for attribute names and values
			strcpy(attrValuePairEntry,token);
			tokenFound = strtok_r(attrValuePairEntry, token, token1, attribNameDelimiter);
		
			//NB if tokenFound =0 none "=" is found (name only without value) so is an error entry
			if(tokenFound !=0){

				//get the attribute name
				strcpy(attrNameEntry,token);

				//initalize first element
				mods[i]->mod_op = 0;

				//initalize mods to attribute name entry
				strcpy(mods[i]->mod_type,attrNameEntry);

				if(strcmp(token1,"") !=0){

					//get the atttribute value list
					strcpy(attrValueListEntry,token1);

					//parse the entry for attribute values
					tokenFound = strtok_r(attrValueListEntry, token, token1, attribValueDelimiter);

					//if multiple values (,) or single attribute=value entry
					if( tokenFound != 0 || strcmp(attrValueListEntry,"") !=0){
						//get the number of valuse of the entry
						numberOfValues = GetNumberOfAttributes(attrValueListEntry, attribValueDelimiter);
						
						//store the dimemsion of the char* array to be allocated
						attrValueArrayDim[i] = numberOfValues;

						//allocate the memory for the array
						allocateMods_val(mods, i, numberOfValues);

						//initialize the array of char* containing the attribute values
						mods = SetModValues(attrValueListEntry, mods, i);
					}

				}

			}
			else{
				error = true;
			}
				
		}
	}


	//initialize last mods element to null
	mods[numberOfModes] = NULL;

	delete[]token;
	delete[]token1;
	delete[]token2;
	delete[]attrValuePairEntry;
	delete[]attrNameEntry;
	delete[]attrValueListEntry;

	return error;
}

LDAPMod** CLdapConnection::SetModValues(char* attrValueListEntry, LDAPMod **mods, int modId){

	//Purpose:
	//initialize LDAPMod.mod_value element 
	
	int i = 0;
	int numberOfValues;

	//allocate tokens for the strtok_r
	char* token = new char[MAXCHARXSTRING];
	char* token1 = new char[MAXCHARXSTRING];
	char* token2 = new char[MAXCHARXSTRING];
	
	//string to hold attribute value
	char* attrValueEntry = new char[50];

	char	comma = ',';
	int     tokenFound = 0;

	//get the number of attributes
	numberOfValues = GetNumberOfAttributes(attrValueListEntry, comma);


	if(numberOfValues != 0){

		//get the first parsed value
		tokenFound = strtok_r(attrValueListEntry, token, token1, comma);

		//parse the loop
		for (i=0; i< numberOfValues; i++){
			
			//get the attrValueEntry
			strcpy(attrValueEntry,token);

			//copy the entry value to the mod_values array elements
			strcpy(mods[modId]->mod_values[i], attrValueEntry);

			//get next token
			tokenFound = strtok_r(token1, token, token2, comma);
			strcpy(token1, token2);
		}
	
	}

	//last mods value should be initialized to NULL
	mods[modId]->mod_values[numberOfValues] = NULL;

	//deallocate tokens
	delete[]token;
	delete[]token1;
	delete[]token2;

	delete[]attrValueEntry;


	return mods;
}

bool CLdapConnection::initializeModifyMods(LDAPMod **mods, char* stAttrModList, int* attrValueArrayDim){
/*
	Puropose: 
	Initialize the LDAPMods structure needed for ldap_add

	Paramers:	double pointer to LDAPMods structure
				stAttrValuesString ="attr1=val1,val2,val3;attr2=val1,val2,val3
*/

	//for the strtok_r
	char* token		= new char[MAXCHARXSTRING];
	char* token1	= new char[MAXCHARXSTRING];
	char* token2	= new char[MAXCHARXSTRING];
	int  tokenFound = 0;

	//for parsing the entries
	char* attrValuePairEntry	= new char[MAXCHARXSTRING];
	char* attrNameEntry			= new char[MAXCHARXSTRING];
	char* attrValueListEntry	= new char[MAXCHARXSTRING];
	char* operationMode			= new char[MAXCHARXSTRING];
	char* attrValueModeEntry	= new char[MAXCHARXSTRING];

	int numberOfModes, numberOfValues;
	char attribEntryDelimiter =';';
	char attribNameDelimiter  ='=';
	char attribValueDelimiter =',';
	char modeOperationDelimiter = ':';
	bool error = false;

	//get number of mods
	numberOfModes = GetNumberOfAttributes(stAttrModList, attribEntryDelimiter);

	//construct the mods array
	for(int i=0; i<=numberOfModes; i++){

		//parse each attribute=value pair entry
		tokenFound = strtok_r(stAttrModList, token, token1, attribEntryDelimiter);

		//if multiple attributes (;) or single attribute=value entry
		if(tokenFound !=0 || strcmp(stAttrModList,"") !=0){

			//store the entries left (for the next loop)
			strcpy(stAttrModList,token1);

			//parse the entry for attribute names and values
			strcpy(attrValueModeEntry,token);

			//parse for either a,d or r and assign value 
			tokenFound = strtok_r(attrValueModeEntry, token, token1, modeOperationDelimiter);
			
			//assign operation 
			strcpy(operationMode, token);

			//get operation int and assign it to mod_op
			mods[i]->mod_op = GetModOperation(operationMode);

			//assign attrvaluepair
			strcpy(attrValuePairEntry, token1);

		
			//NB if tokenFound =0 none "=" is found (name only without value) so is an error entry
			if(tokenFound !=0){

				tokenFound = strtok_r(attrValuePairEntry, token, token1, attribNameDelimiter);
				
				//get the attribute name
				strcpy(attrNameEntry,token);

				//initalize mods to attribute name entry
				strcpy(mods[i]->mod_type,attrNameEntry);

				if(strcmp(token1,"") !=0){

					//get the atttribute value list
					strcpy(attrValueListEntry,token1);

					//parse the entry for attribute values
					tokenFound = strtok_r(attrValueListEntry, token, token1, attribValueDelimiter);

					//if multiple values (,) or single attribute=value entry
					if( tokenFound != 0 || strcmp(attrValueListEntry,"") !=0){
						//get the number of valuse of the entry
						numberOfValues = GetNumberOfAttributes(attrValueListEntry, attribValueDelimiter);
						
						//store the dimemsion of the char* array to be allocated
						attrValueArrayDim[i] = numberOfValues;

						//allocate the memory for the array
						allocateMods_val(mods, i, numberOfValues);

						//initialize the array of char* containing the attribute values
						mods = SetModValues(attrValueListEntry, mods, i);
					}

				}

			}
			else{
				error = true;
			}
				
		}
	}


	//initialize last mods element to null
	mods[numberOfModes] = NULL;

	delete[]token;
	delete[]token1;
	delete[]token2;
	delete[]attrValuePairEntry;
	delete[]attrNameEntry;
	delete[]attrValueListEntry;
	delete[]attrValueModeEntry;

	delete[]operationMode;

	return error;
}

int CLdapConnection::GetModOperation(char* operationMode){

/*
	Purpose:
	parse string for either a, d or r
	and assign the proper int type of opeartion
*/
	int modtype;

	if(strcmp(operationMode,"a") == 0)
		modtype = LDAP_MOD_ADD;
	if(strcmp(operationMode,"d") == 0)
		modtype = LDAP_MOD_DELETE;
	if(strcmp(operationMode,"r") == 0)
		modtype = LDAP_MOD_REPLACE;	

	return modtype;
}



char* CLdapConnection::GetCert7dbPath(){

/*

  Purpose:

  Retrieves the path for the Netscape Certificate Database file from the user environment path
  set in CERT7DBPATH. Needs to be used with DeleteCert7db

  Returns: 
  the string that holds the path on success, NULL on failure

*/

	char* certvar = NULL;
	char* certpath = NULL;
	char  certfile[] ="\\cert7.db";
	int certvarlen1;
	int certvarlen2;
	int certvarlen;

	certvar = getenv( "CERTPATH" );
	//stLDAPError = getenv( "CERTPATH" );

	if (certvar != NULL){
		
		certvarlen1 = strlen(certvar);
		certvarlen2 = strlen(certfile);
		certvarlen = certvarlen1 + certvarlen2 + 1;
		certpath = new char[certvarlen];
		strcpy(certpath, certvar);
		strcat(certpath, certfile);
	}

	return certpath;
}

int CLdapConnection::DeleteCert7dbPath(char* certpath){
/*

  Purpose:
	deallocates memory allocated for cert7dbpath
  Returns:
	0 on success -1 on failure

*/
	int success = -1;

	if(certpath != NULL){
		delete [] certpath;
		success = 0;
	}

	return success;
}