#include "publisher.h"
#include "exceptions.h"
#include "observer.h"

Publisher* Publisher::smpInstance = 0;

Publisher* Publisher::getInstance()
{
   if(!smpInstance)
      smpInstance = new Publisher;
   return smpInstance;
}

Publisher::Publisher()
{
}

void Publisher::createPublication(const std::string& fPubName, 
                                  Subject* fpPubOwner)
{
   if(!fpPubOwner)
   {
      NullPointerException ex;
      ex.msg = "Null publication owner pointer fpPubOwner";
      ex.src = "Publisher::createPublication";
      throw ex;
   }
   PubMapVal val;
   val.owner     = fpPubOwner;
   val.observers = new ObserverSet;

   bool res = (mPubMap.insert(PubMapPair(fPubName, val))).second;
   if(!res)
   {
      DuplicateItemException ex;
      ex.msg = "The publication named <" ;
      ex.msg += fPubName + "> already exists";
      ex.src = "Publisher::createPublication";
      delete val.observers;
      throw ex;
   }
}

void Publisher::discontinuePublication(const std::string& fPubName, 
                                       Subject* fpPubOwner)
{
   if(!fpPubOwner)
   {
      NullPointerException ex;
      ex.msg = "Null publication owner pointer fpPubOwner";
      ex.src = "Publisher::discontinuePublication";
      throw ex;
   }

   PubMapIter pmi = mPubMap.find(fPubName);
   if(pmi == mPubMap.end())
   {
      NoSuchItemException ex;
      ex.msg = "The publication named <" ;
      ex.msg += fPubName + "> does not exist";
      ex.src = "PKEIPublisher::discontinuePublication";
      throw ex;
   }

   Subject*     apPubOwner = pmi->second.owner;
   ObserverSet* apSet      = pmi->second.observers;

   if(apPubOwner != fpPubOwner)
   {
      NotOwnerException ex;
      ex.msg = "An attempt to discontinue the publication named <" ;
      ex.msg += fPubName + "> was made by someone other than the owner";
      ex.src = "Publisher::discontinuePublication";
      throw ex;
   }

   ObserverSetIterator p = apSet->begin();
   Observer* fpObserver;
   while(p != apSet->end())
   {
      fpObserver = *p;
      ++p;
      fpObserver->unsubscribe(fPubName);
   }

   mPubMap.erase(pmi);
   delete apSet;
}

void Publisher::subscribe(const std::string& fPubName, 
                          Observer* fpObserver)
{
   PubMapIter p = mPubMap.find(fPubName);

   if(p == mPubMap.end())
   {
      NoSuchItemException ex;
      ex.msg = "The publication named <" ;
      ex.msg += fPubName + "> does not exist";
      ex.src = "PKEIPublisher::subscribe";
      throw ex;
   }

   p->second.observers->insert(fpObserver);
}

void Publisher::unsubscribe(const std::string& fPubName, 
                            Observer* fpObserver)
{
   PubMapIter p = mPubMap.find(fPubName);
   if(p == mPubMap.end())
   {
      NoSuchItemException ex;
      ex.msg = "The publication named <" ;
      ex.msg += fPubName + "> does not exist";
      ex.src = "PKEIPublisher::unsubscribe";
      throw ex;
   }
   p->second.observers->erase(fpObserver);
}

void Publisher::publish(const std::string& fPubName, 
                        Subject* fpPubOwner)
{
   if(!fpPubOwner)
   {
      NullPointerException ex;
      ex.msg = "Null publication owner pointer fpPubOwner";
      ex.src = "Publisher::publish";
      throw ex;
   }

   PubMapIter p = mPubMap.find(fPubName);

   if(p == mPubMap.end())
   {
      NoSuchItemException ex;
      ex.msg = "The publication named <" ;
      ex.msg += fPubName + "> does not exist";
      ex.src = "PKEIPublisher::publish";
      throw ex;
   }

   Subject*     apPubOwner = p->second.owner;
   ObserverSet* apSet      = p->second.observers;

   // verify the caller is the publication owner
   if(apPubOwner != fpPubOwner)
   {
      NotOwnerException ex;
      ex.msg = "An attempt to publish the publication named <" ;
      ex.msg += fPubName + "> was made by someone other than the owner";
      ex.src = "Publisher::publish";
      throw ex;
   }

   ObserverSetIterator po;

   for(po = apSet->begin(); po != apSet->end(); ++po)
      (*po)->update(fPubName, fpPubOwner);
}

void Publisher::discontinueAllByOwner(Subject* fpPubOwner)
{
   PubMapIter p = mPubMap.begin();
   PubMapIter curr;
   while(p != mPubMap.end())
   {
      curr = p;
      ++p;
      Subject* apSubject = curr->second.owner;
      if(apSubject == fpPubOwner)
         discontinuePublication(curr->first, apSubject);

   }
}
