#ifndef _Exceptions_h_
#define _Exceptions_h_

#include <string>

class Exception
{
public:
   std::string msg;
   std::string src;

   inline std::string getFullMsg() const {return src + ": " + msg; }
};

class NullPointerException : public Exception
{
};

class NoSuchItemException : public Exception
{
};

class DuplicateItemException : public Exception
{
};

class NotOwnerException : public Exception
{
};

class NonSubscriberException : public Exception
{
};


#endif
