#ifndef _Observer_h_
#define _Observer_h_

#ifdef _MSC_VER
#pragma warning (disable: 4786)
#endif

#include <set>
#include <string>

class Subject;
class Observer
{
public:
   virtual void update(const std::string& fPubName, Subject*) = 0;
   void subscribe(const std::string& fPubName);
   void unsubscribe(const std::string& fPubName);
   virtual ~Observer();

private:
   typedef std::set<std::string> StringSet;
   typedef std::set<std::string>::iterator StringSetIterator;
   
   void unsubscribe(const StringSetIterator&);
   StringSet mSubscribedPubs; 
};

#endif

