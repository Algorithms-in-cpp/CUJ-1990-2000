#include "subject.h"
#include "publisher.h"

Subject::~Subject()
{
   discontinueAll();
}

void Subject::createPublication(const std::string& fPubName)
{
   Publisher* apPublisher = Publisher::getInstance();
   apPublisher->createPublication(fPubName, this);
}

void Subject::discontinuePublication(const std::string& fPubName)
{
   Publisher* apPublisher = Publisher::getInstance();
   apPublisher->discontinuePublication(fPubName, this);
}

void Subject::publish(const std::string& fPubName)
{
   Publisher* apPublisher = Publisher::getInstance();
   apPublisher->publish(fPubName, this);
}

void Subject::discontinueAll()
{
   Publisher* apPublisher = Publisher::getInstance();
   apPublisher->discontinueAllByOwner(this);
}
