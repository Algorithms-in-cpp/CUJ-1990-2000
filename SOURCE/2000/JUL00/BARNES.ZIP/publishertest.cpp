// Sample main program to illustrate usage of the Publisher
// and related classes

#include <iostream>

#include "exceptions.h"
#include "subject.h"
#include "observer.h"

using namespace std;

// Some simple subject and observer classes
class A_Subject : public Subject
{

};

// This subject can also observe 
class A_SubjectWhoObserves : public Subject, public Observer
{
   void update(const string& fPubName, Subject* fpPubOwner)
   {
      cout << "In A_SubjectWhoObserves::update for publication named " << fPubName << endl;
   }

public:
   // publication observers can call this function (or any public function)
   void call_back() { cout << "In A_SubjectWhoObserves::call_back()\n"; }
};

class ConcreteObserver1 : public Observer
{
   void update(const string& fPubName, Subject* fpPubOwner)
   {
      cout << "In ConcreteObserver1::update for publication named " << fPubName << endl;

      // this observer subscribes to multiple publications 
      // and does different things based on which publication is 
      // being notified
      if(fPubName == "PUB3")
      {
         cout << "\tConcreteObserver1 is calling the call back routine of the subject...\n";
         // call the notifiers call back function
         // would prefer C++ dynamic casting here
         ((A_SubjectWhoObserves*) fpPubOwner)->call_back();
      }
   }
};

class ConcreteObserver2 : public Observer
{
   void update(const string& fPubName, Subject* fpPubOwner)
   {
      cout << "In ConcreteObserver2::update for publication named " << fPubName << endl;
   }
};

int main()
{
   // Instantiate a subject -- subject can create publications
   // and publish updates
   A_Subject s;
   cout << "\n\nCreated a subject. " << endl;

   // Create two publications named PUB1 and PUB2
   const string PUB1 = "PUB1", PUB2 = "PUB2", PUB3 = "PUB3";
   cout << "Subject is creating a publication named PUB1..." << endl;
   s.createPublication(PUB1);
   cout << "Done." << endl;

   cout << "Subject is creating a publication named PUB2..." << endl;
   s.createPublication(PUB2);
   cout << "Done." << endl;


   // Instantiate two different observers
   ConcreteObserver1 O1;
   ConcreteObserver2 O2;

   cout << "\nCreated a ConcreteObserver1 and a ConcreteObserver2 object\n";

   // O1 subscribes to PUB1
   cout << "ConcreteObserver1 instance is subscribing to PUB1...\n";
   O1.subscribe(PUB1);

   // O2 subscribes to both PUB1 and PUB2
   cout << "ConcreteObserver2 instance is subscribing to both PUB1 and PUB2...\n";
   O2.subscribe(PUB1);
   O2.subscribe(PUB2);

   // attempting to subscribe to same pub again does nothing
   O2.subscribe(PUB1);

   // Now broadcast a notification
   cout << "\nSubject is now broadcasting a notification to PUB1 subscribers..." << endl;
   s.publish(PUB1);
   cout << "\nSubject is now broadcasting a notification to PUB2 subscribers..." << endl;
   s.publish(PUB2);
   cout << endl << endl;

   cout << "Press enter to continue...";
   char junk;
   cin.get(junk);


   A_SubjectWhoObserves so;
   cout << "\n\nCreated an A_SubjectWhoObserves instance. " << endl;

   cout << "This subject creating a publication named PUB3...\n";
   so.createPublication(PUB3);

   cout << "The subject is subscribing to his own publication PUB3...\n";
   so.subscribe(PUB3);

   cout << "ConcreteObserver1 instance is subscribing to PUB3...\n";
   O1.subscribe(PUB3);


   cout << "\nThe subject is now broadcasting a notification to PUB3 subscribers...\n";
   so.publish(PUB3);
   cout << endl << endl;


   cout << "Now the A_SubjectWhoObserves instance will attempt to broadcast\n"
      << "a notification to PUB1, which he does not own...\n\n";
   
   try
   {
      so.publish(PUB1);
   }
   catch(NotOwnerException &ex)
   {
      cout << "Caught an exception: " << ex.getFullMsg() << endl;
   }
   cout << endl;
   return 0;
}

