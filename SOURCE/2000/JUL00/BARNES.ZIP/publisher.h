#ifndef _Publisher_h_
#define _Publisher_h_

#ifdef _MSC_VER
#pragma warning (disable: 4786)
#endif

#include <string>
#include <map>
#include <set>

class Subject;
class Observer;

class Publisher
{
public:
   static Publisher* getInstance();

   // Functions for the Subject
   void createPublication(const std::string& fPubName, Subject* fpPubOwner);
   void discontinuePublication(const std::string& fPubName, Subject* fpPubOwner);
   void publish(const std::string& fPubName, Subject *fpPubOwner);
   void discontinueAllByOwner(Subject* fpPubOwner);
   
   // Functions for the Observer (subscriber)
   void subscribe  (const std::string& fPubName, Observer* fpSubscriber);
   void unsubscribe(const std::string& fPubName, Observer* fpSubscriber);

private:

   typedef std::set<Observer*>           ObserverSet;
   typedef std::set<Observer*>::iterator ObserverSetIterator;
   struct PubMapVal
   {
      Subject*     owner;
      ObserverSet* observers;
   };
   typedef std::map <std::string, PubMapVal>            PubMap;
   typedef std::pair<std::string, PubMapVal>            PubMapPair;
   typedef std::map <std::string, PubMapVal>::iterator  PubMapIter;

   Publisher();
   Publisher(const Publisher&);
   operator=(const Publisher&);
   
   static Publisher* smpInstance;

   PubMap mPubMap;

};

#endif
