#ifndef _Subject_h_
#define _Subject_h_
#include <string>

#ifdef _MSC_VER
#pragma warning (disable: 4786)
#endif

class Subject
{
 public:
   virtual ~Subject();
   void createPublication(const std::string& fPubName);
   void discontinuePublication(const std::string& fPubName);
   void publish(const std::string& fPubName);
   void discontinueAll();
};
#endif
