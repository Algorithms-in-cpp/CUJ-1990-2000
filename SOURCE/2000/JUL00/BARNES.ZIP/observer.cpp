#include "observer.h"
#include "publisher.h"



void Observer::subscribe(const std::string& fPubName)
{
   Publisher* apPublisher = Publisher::getInstance();
   apPublisher->subscribe(fPubName, this);
   mSubscribedPubs.insert(fPubName);
}

void Observer::unsubscribe(const std::string& fPubName)
{
   Publisher* apPublisher = Publisher::getInstance();
   apPublisher->unsubscribe(fPubName, this);
   mSubscribedPubs.erase(fPubName);
}

void Observer::unsubscribe(const StringSetIterator& fpIter)
{
   Publisher* apPublisher = Publisher::getInstance();
   apPublisher->unsubscribe(*fpIter, this);
   mSubscribedPubs.erase(fpIter);
}


Observer::~Observer()
{
   StringSetIterator p = mSubscribedPubs.begin();
   StringSetIterator prev;
   while(p != mSubscribedPubs.end())
   {
      prev = p;
      ++p;
      unsubscribe(prev);
      // prev now invalid
   }
}
