/* This was compiled in Visual C under Windows NT */
#include <locale.h>
#include <stdio.h>
#include <time.h>

void print_stuff(void)
{
    char text[81];
    time_t timer = time(NULL);

    printf("%.2f\n",1.2);
    strftime(text, sizeof text,
             "%A, %B %d, %Y (%x)\n",
             localtime(&timer));
    puts(text);
}

int main()
{
    /* First in the C locale */
    puts("In the C locale:");
    print_stuff();

    /* Now try German */
    puts("\nIn the German locale:");
    setlocale(LC_ALL,"german");
    print_stuff();
    return 0;
}

/* Output
In the C locale:
1.20
Monday, March 17, 1997 (03/17/97)


In the German locale:
1,20
Montag, M�rz 17, 1997 (17.03.97)
*/
