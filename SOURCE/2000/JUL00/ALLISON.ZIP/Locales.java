import java.util.*;

class Locales
{
    public static void main(String[] args)
    {
        Locale[] locales = Locale.getAvailableLocales();
        System.out.println(locales.length +
            " locales are supported (sample follows):");
        for (int i = 0; i < locales.length; ++i)
            if (i%10 == 1)
                System.out.println("    " +
                    locales[i].getDisplayName() + "," +
                    locales[i].getLanguage() + "," +
                    locales[i].getDisplayLanguage() + "," +
                    locales[i].getCountry() + "," +
                    locales[i].getDisplayCountry());
        
        Locale def = Locale.getDefault();
        System.out.println("\nThe default locale is:\n    " +
            def.getDisplayName() + "," +
            def.getLanguage() + "," +
            def.getDisplayLanguage() + "," +
            def.getCountry() + "," +
            def.getDisplayCountry());
    }
}

/* Output:
145 locales are supported (sample follows):
    English (United States),en,English,US,United States
    Arabic (Libya),ar,Arabic,LY,Libya
    Byelorussian (Belarus),be,Byelorussian,BY,Belarus
    German,de,German,,
    English (Australia),en,English,AU,Australia
    Spanish (Chile),es,Spanish,CL,Chile
    Spanish (Nicaragua),es,Spanish,NI,Nicaragua
    Finnish,fi,Finnish,,
    French (Luxembourg),fr,French,LU,Luxembourg
    Italian (Italy),it,Italian,IT,Italy
    Latvian (Lettish),lv,Latvian (Lettish),,
    Norwegian (Norway),no,Norwegian,NO,Norway
    Russian,ru,Russian,,
    Serbian,sr,Serbian,,
    Chinese,zh,Chinese,,

The default locale is:
    English (United States),en,English,US,United States
*/
