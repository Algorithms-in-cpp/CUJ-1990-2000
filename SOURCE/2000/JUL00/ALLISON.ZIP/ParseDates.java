import java.util.*;
import java.text.*;

class ParseDates
{
    public static void main(String[] args)
        throws ParseException
    {
        SimpleDateFormat inFmt =
            (SimpleDateFormat)DateFormat.getDateInstance();
        System.out.println("Pattern: " + inFmt.toPattern());
        inFmt.applyPattern("M/d/y");
        System.out.println("Pattern: " + inFmt.toPattern());
        Date d1 = inFmt.parse("10/1/51");
        System.out.println(d1);
        
        SimpleDateFormat outFmt =
            (SimpleDateFormat)DateFormat.getDateInstance();
        outFmt.applyPattern("d MMM yyyy G");
        System.out.println(outFmt.format(d1));
    }
}

/* Output:
Pattern: MMM d, yyyy
Pattern: M/d/y
Mon Oct 01 00:00:00 MDT 1951
1 Oct 1951 AD
*/
