import java.text.*;

class ParseNumbers
{
    public static void main(String[] args)
    {
        NumberFormat fmt = NumberFormat.getInstance();
        String buf = "123 4567 89.01 23E4";
        ParsePosition pos = new ParsePosition(0);
        System.out.println(fmt.parse(buf, pos));
        pos.setIndex(pos.getIndex() + 1);
        System.out.println(fmt.parse(buf, pos));
        pos.setIndex(pos.getIndex() + 1);
        System.out.println(fmt.parse(buf, pos));
        pos.setIndex(pos.getIndex() + 1);
        System.out.println(fmt.parse(buf, pos));
    }
}

/* Output:
123
4567
89.01
230000
*/
