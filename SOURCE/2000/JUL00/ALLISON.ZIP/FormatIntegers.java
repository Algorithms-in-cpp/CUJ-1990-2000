import java.text.*;

class FormatIntegers
{
    public static void main(String[] args)
    {
        NumberFormat fmt = NumberFormat.getInstance();
        fmt.setMinimumIntegerDigits(3);
        fmt.setMaximumIntegerDigits(4);
        System.out.println(fmt.format(10));
        System.out.println(fmt.format(100));
        System.out.println(fmt.format(1000));
        System.out.println(fmt.format(10000));
    }
}

/* Output:
010
100
1,000
0,000
*/
