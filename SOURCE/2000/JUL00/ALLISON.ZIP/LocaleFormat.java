import java.util.*;
import java.text.*;

class LocaleFormat
{
    public static void main(String[] args)
    {
        Locale[] locales = {new Locale("en", "US"),
                            new Locale("de", "CH"),
                            new Locale("pt", "BR")};
        
        // Numerics
        double num = 12345.678;
        System.out.println("Numerics:");
        for (int i = 0; i < locales.length; ++i)
        {
            NumberFormat numFmt =
                NumberFormat.getInstance(locales[i]);
            System.out.println(numFmt.format(num) + " [" +
                               locales[i].getDisplayName() + "]");
        }
                
        // Currency:
        System.out.println("\nCurrency:");
        for (int i = 0; i < locales.length; ++i)
        {
            NumberFormat curFmt =
                NumberFormat.getCurrencyInstance(locales[i]);
            System.out.println(curFmt.format(num) + " [" +
                               locales[i].getDisplayName() + "]");
        }

        // Dates:
        System.out.println("\nDates:");
        Date today = new Date();
        for (int i = 0; i < locales.length; ++i)
        {
            DateFormat datFmt =
                DateFormat.getDateInstance(DateFormat.FULL,
                                           locales[i]);
            System.out.println(datFmt.format(today) + " [" +
                               locales[i].getDisplayName() + "]");
        }
    }
}

/* Output:
Numerics:
12,345.678 [English (United States)]
12'345.678 [German (Switzerland)]
12.345,678 [Portuguese (Brazil)]

Currency:
$12,345.68 [English (United States)]
SFr. 12'345.68 [German (Switzerland)]
R$ 12.345,68 [Portuguese (Brazil)]

Dates:
Wednesday, April 19, 2000 [English (United States)]
Mittwoch, 19. April 2000 [German (Switzerland)]
Quarta-feira, 19 de Abril de 2000 [Portuguese (Brazil)]
*/
