import java.text.*;

class FormatPercent
{
    public static void main(String[] args)
    {
        NumberFormat fmt = NumberFormat.getPercentInstance();
        System.out.println(fmt.format(.1));
        System.out.println(fmt.format(.123));
        System.out.println(fmt.format(.126));
        System.out.println(fmt.format(1.23));
    }
}

/* Output:
10%
12%
13%
123%
*/
