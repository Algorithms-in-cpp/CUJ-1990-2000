import java.text.*;

class FormatDecimals
{
    public static void main(String[] args)
    {
        DecimalFormat fmt = new DecimalFormat("$#,###.00");
        fmt.setNegativePrefix("$(");
        fmt.setNegativeSuffix(")");
        System.out.println("Using pattern: " + fmt.toPattern());
        System.out.println(fmt.format(1.23456));
        System.out.println(fmt.format(12.3456));
        System.out.println(fmt.format(123.456));
        System.out.println(fmt.format(1234.56));
        System.out.println(fmt.format(12345.6));
        System.out.println(fmt.format(-12345.6));
        System.out.println();
        
        fmt.applyPattern("0.##E00");
        System.out.println("Using pattern: " + fmt.toPattern());
        System.out.println(fmt.format(1.23456));
        System.out.println(fmt.format(12.3456));
        System.out.println(fmt.format(123.456));
        System.out.println(fmt.format(1234.56));
        System.out.println(fmt.format(12345.6));
        System.out.println(fmt.format(-12345.6));

    }
}

/* Output:
Using pattern: $#,###.00;$(#,###.00)
$1.23
$12.35
$123.46
$1,234.56
$12,345.60
$(12,345.60)

Using pattern: 0.##E00
1.23E00
1.23E01
1.23E02
1.23E03
1.23E04
-1.23E04
*/
