import java.text.*;

class FormatCurrency
{
    public static void main(String[] args)
    {
        NumberFormat fmt = NumberFormat.getCurrencyInstance();
        System.out.println(fmt.format(10));
        System.out.println(fmt.format(10.34));
        System.out.println(fmt.format(10.345));
        System.out.println(fmt.format(10.346));
        System.out.println(fmt.format(-10.346));
    }
}

/* Output:
$10.00
$10.34
$10.34
$10.35
($10.35)
*/
