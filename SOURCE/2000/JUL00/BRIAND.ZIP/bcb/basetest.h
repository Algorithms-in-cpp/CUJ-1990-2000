//---------------------------------------------------------------------------
#ifndef pxmltest2H
#define pxmltest2H

#include <fstream>
#include <vector>


template<typename I1, typename O1>
class BaseTest11
{
public:
   BaseTest11(){}
   bool run(int first, int last, std::fstream &fout);
   virtual void apply(const I1 &, O1 &)=0;
   virtual const char *getName() const=0;
protected:
   void addCase(const I1 &i1, const O1 &o1);
   std::vector<I1> i1s;
   std::vector<O1> o1s;
};

template<typename I1, typename O1>
bool BaseTest11<I1, O1>::run(int first, int last, std::fstream &fout)
{
   O1 tempo1;
   // constrain range, if necessary
   if(first < 0)
      first = 0;
   if(last > i1s.size() - 1)
      last = i1s.size() - 1;
   for(int i = first; i <= last; ++i)
   {
      if(i >= 0 && i < i1s.size())
      {
         apply(i1s[i], tempo1);
         if(tempo1 == o1s[i])
            fout << getName() << "(" << i << ") successful. Output: " << tempo1 << std::endl;
         else
         {
            fout << getName() << "(" << i << ") UNSUCCESSFUL" << std::endl;
            fout << "  expected: " << o1s[i] << ", actual: " << tempo1 << std::endl;
            return false;
         }
      }
      else
         break;
   }
   return true;
}

template<typename I1, typename O1>
void BaseTest11<I1, O1>::addCase(const I1 &i1, const O1 &o1)
{
   i1s.push_back(i1);
   o1s.push_back(o1);
}

//

template<typename I1, typename O1, typename O2>
class BaseTest12
{
public:
   BaseTest12(){}
   bool run(int first, int last, std::fstream &fout);
   virtual void apply(const I1 &, O1 &, O2&)=0;
   virtual const char *getName() const=0;
protected:
   void addCase(const I1 &i1, const O1 &o1, const O2 &o2);
   std::vector<I1> i1s;
   std::vector<O1> o1s;
   std::vector<O2> o2s;
};

template<typename I1, typename O1, typename O2>
bool BaseTest12<I1, O1, O2>::run(int first, int last, std::fstream &fout)
{
   O1 tempo1;
   O2 tempo2;

   // constrain range, if necessary
   if(first < 0)
      first = 0;
   if(last > i1s.size() - 1)
      last = i1s.size() - 1;

   for(int i = first; i <= last; ++i)
   {
      if(i >= 0 && i < i1s.size())
      {
         apply(i1s[i], tempo1, tempo2);
         if((tempo1 == o1s[i]) && (tempo2 == o2s[i]))
            fout << getName() << "(" << i << ") successful. Output: " << tempo1 << ", " << tempo2 << std::endl;
         else
         {
            fout << getName() << "(" << i << ") UNSUCCESSFUL" << std::endl;
            fout << "  expected: " << o1s[i] << ", actual: " << tempo1 << std::endl;
            fout << "  expected: " << o2s[i] << ", actual: " << tempo2 << std::endl;
            return false;
         }
      }
      else
         break;
   }
   return true;
}

template<typename I1, typename O1, typename O2>
void BaseTest12<I1, O1, O2>::addCase(const I1 &i1, const O1 &o1, const O2 &o2)
{
   i1s.push_back(i1);
   o1s.push_back(o1);
   o2s.push_back(o2);
}

//

template<typename I1, typename O1, typename O2, typename O3>
class BaseTest13
{
public:
   BaseTest13(){}
   bool run(int first, int last, std::fstream &fout);
   virtual void apply(const I1 &, O1 &, O2 &, O3 &)=0;
   virtual const char *getName() const=0;
protected:
   void addCase(const I1 &i1, const O1 &o1, const O2 &o2, const O3 &o3);
   std::vector<I1> i1s;
   std::vector<O1> o1s;
   std::vector<O2> o2s;
   std::vector<O3> o3s;
};

template<typename I1, typename O1, typename O2, typename O3>
bool BaseTest13<I1, O1, O2, O3>::run(int first, int last, std::fstream &fout)
{
   O1 tempo1;
   O2 tempo2;
   O3 tempo3;

   // constrain range, if necessary
   if(first < 0)
      first = 0;
   if(last > i1s.size() - 1)
      last = i1s.size() - 1;

   for(int i = first; i <= last; ++i)
   {
      if(i >= 0 && i < i1s.size())
      {
         apply(i1s[i], tempo1, tempo2, tempo3);
         if((tempo1 == o1s[i]) && (tempo2 == o2s[i]) && (tempo3 == o3s[i]))
            fout << getName() << "(" << i << ") successful. Output: "
                 << tempo1 << ", "
                 << tempo2 << ", "
                 << tempo3 << std::endl;
         else
         {
            fout << getName() << "(" << i << ") UNSUCCESSFUL" << std::endl;
            fout << "  expected: " << o1s[i] << ", actual: " << tempo1 << std::endl;
            fout << "  expected: " << o2s[i] << ", actual: " << tempo2 << std::endl;
            fout << "  expected: " << o3s[i] << ", actual: " << tempo3 << std::endl;
            return false;
         }
      }
      else
         break;
   }
   return true;
}

template<typename I1, typename O1, typename O2, typename O3>
void BaseTest13<I1, O1, O2, O3>::addCase(const I1 &i1, const O1 &o1, const O2 &o2, const O3 &o3)
{
   i1s.push_back(i1);
   o1s.push_back(o1);
   o2s.push_back(o2);
   o3s.push_back(o3);
}

//

template<typename I1, typename I2, typename O1>
class BaseTest21
{
public:
   BaseTest21(){}
   bool run(int first, int last, std::fstream &fout);
   virtual void apply(const I1 &, const I2 &, O1 &)=0;
   virtual const char *getName() const=0;
protected:
   void addCase(const I1 &i1, const I2 &i2, const O1 &o1);
   std::vector<I1> i1s;
   std::vector<I2> i2s;
   std::vector<O1> o1s;
};

template<typename I1, typename I2, typename O1>
bool BaseTest21<I1, I2, O1>::run(int first, int last, std::fstream &fout)
{
   O1 tempo1;

   // constrain range, if necessary
   if(first < 0)
      first = 0;
   if(last > i1s.size() - 1)
      last = i1s.size() - 1;

   for(int i = first; i <= last; ++i)
   {
      if(i >= 0 && i < i1s.size())
      {
         apply(i1s[i], i2s[i], tempo1);
         if(tempo1 == o1s[i])
            fout << getName() << "(" << i << ") successful. Output: " << tempo1 << std::endl;
         else
         {
            fout << getName() << "(" << i << ") UNSUCCESSFUL" << std::endl;
            fout << "  expected: " << o1s[i] << ", actual: " << tempo1 << std::endl;
            return false;
         }
      }
      else
         break;
   }
   return true;
}

template<typename I1, typename I2, typename O1>
void BaseTest21<I1, I2, O1>::addCase(const I1 &i1, const I2 &i2, const O1 &o1)
{
   i1s.push_back(i1);
   i2s.push_back(i2);
   o1s.push_back(o1);
}

//
template<typename I1, typename I2, typename O1, typename O2>
class BaseTest22
{
public:
   BaseTest22(){}
   bool run(int first, int last, std::fstream &fout);
   virtual void apply(const I1 &, const I2 &, O1 &, O2&)=0;//{}
   virtual const char *getName() const=0;// {return "BaseTest32";}
protected:
   void addCase(const I1 &i1, const I2 &i2, const O1 &o1, const O2 &o2);
   std::vector<I1> i1s;
   std::vector<I2> i2s;
   std::vector<O1> o1s;
   std::vector<O2> o2s;
};

template<typename I1, typename I2, typename O1, typename O2>
bool BaseTest22<I1, I2, O1, O2>::run(int first, int last, std::fstream &fout)
{
   O1 tempo1;
   O2 tempo2;

   // constrain range, if necessary
   if(first < 0)
      first = 0;
   if(last > i1s.size() - 1)
      last = i1s.size() - 1;

   for(int i = first; i <= last; ++i)
   {
      if(i >= 0 && i < i1s.size())
      {
         apply(i1s[i], i2s[i], tempo1, tempo2);
         if((tempo1 == o1s[i]) && (tempo2 == o2s[i]))
            fout << getName() << "(" << i << ") successful. Output: " << tempo1 << ", " << tempo2 << std::endl;
         else
         {
            fout << getName() << "(" << i << ") UNSUCCESSFUL" << std::endl;
            fout << "  expected: " << o1s[i] << ", actual: " << tempo1 << std::endl;
            fout << "  expected: " << o2s[i] << ", actual: " << tempo2 << std::endl;
            return false;
         }
      }
      else
         break;
   }
   return true;
}

template<typename I1, typename I2, typename O1, typename O2>
void BaseTest22<I1, I2, O1, O2>::addCase(const I1 &i1, const I2 &i2, const O1 &o1, const O2 &o2)
{
   i1s.push_back(i1);
   i2s.push_back(i2);
   o1s.push_back(o1);
   o2s.push_back(o2);
}

//

template<typename I1, typename I2, typename O1, typename O2, typename O3>
class BaseTest23
{
public:
   BaseTest23(){}
   bool run(int first, int last, std::fstream &fout);
   virtual void apply(const I1 &, const I2 &, O1 &, O2 &, O3 &)=0;//{}
   virtual const char *getName() const=0;// {return "BaseTest32";}
protected:
   void addCase(const I1 &i1, const I2 &i2, const O1 &o1, const O2 &o2, const O3 &o3);
   std::vector<I1> i1s;
   std::vector<I2> i2s;
   std::vector<O1> o1s;
   std::vector<O2> o2s;
   std::vector<O3> o3s;
};

template<typename I1, typename I2, typename O1, typename O2, typename O3>
bool BaseTest23<I1, I2, O1, O2, O3>::run(int first, int last, std::fstream &fout)
{
   O1 tempo1;
   O2 tempo2;
   O3 tempo3;

   // constrain range, if necessary
   if(first < 0)
      first = 0;
   if(last > i1s.size() - 1)
      last = i1s.size() - 1;

   for(int i = first; i <= last; ++i)
   {
      if(i >= 0 && i < i1s.size())
      {
         apply(i1s[i], i2s[i], tempo1, tempo2, tempo3);
         if((tempo1 == o1s[i]) && (tempo2 == o2s[i]) && (tempo3 == o3s[i]))
            fout << getName() << "(" << i << ") successful. Output: "
                 << tempo1 << ", "
                 << tempo2 << ", "
                 << tempo3 << std::endl;
         else
         {
            fout << getName() << "(" << i << ") UNSUCCESSFUL" << std::endl;
            fout << "  expected: " << o1s[i] << ", actual: " << tempo1 << std::endl;
            fout << "  expected: " << o2s[i] << ", actual: " << tempo2 << std::endl;
            fout << "  expected: " << o3s[i] << ", actual: " << tempo3 << std::endl;
            return false;
         }
      }
      else
         break;
   }
   return true;
}

template<typename I1, typename I2, typename O1, typename O2, typename O3>
void BaseTest23<I1, I2, O1, O2, O3>::addCase(const I1 &i1, const I2 &i2,
   const O1 &o1, const O2 &o2, const O3 &o3)
{
   i1s.push_back(i1);
   i2s.push_back(i2);
   o1s.push_back(o1);
   o2s.push_back(o2);
   o3s.push_back(o3);
}


//

template<typename I1, typename I2, typename I3,
   typename O1>
class BaseTest31
{
public:
   BaseTest31(){}
   bool run(int first, int last, std::fstream &fout);
   virtual void apply(const I1 &, const I2 &, const I3 &, O1 &)=0;
   virtual const char *getName() const=0;
protected:
   void addCase(const I1 &i1, const I2 &i2, const I3 &i3, const O1 &o1);
   std::vector<I1> i1s;
   std::vector<I2> i2s;
   std::vector<I3> i3s;
   std::vector<O1> o1s;
};

template<typename I1, typename I2, typename I3,
   typename O1>
bool BaseTest31<I1, I2, I3, O1>::run(int first, int last, std::fstream &fout)
{
   O1 tempo1;

   // constrain range, if necessary
   if(first < 0)
      first = 0;
   if(last > i1s.size() - 1)
      last = i1s.size() - 1;

   for(int i = first; i <= last; ++i)
   {
      if(i >= 0 && i < i1s.size())
      {
         apply(i1s[i], i2s[i], i3s[i], tempo1);
         if(tempo1 == o1s[i])
            fout << getName() << "(" << i << ") successful. Output: " << tempo1 << std::endl;
         else
         {
            fout << getName() << "(" << i << ") UNSUCCESSFUL" << std::endl;
            fout << "  expected: " << o1s[i] << ", actual: " << tempo1 << std::endl;
            return false;
         }
      }
      else
         break;
   }
   return true;
}

template<typename I1, typename I2, typename I3, typename O1>
void BaseTest31<I1, I2, I3, O1>::addCase(const I1 &i1, const I2 &i2, const I3 &i3,
   const O1 &o1)
{
   i1s.push_back(i1);
   i2s.push_back(i2);
   i3s.push_back(i3);
   o1s.push_back(o1);
}


//

template<typename I1, typename I2, typename I3,
   typename O1, typename O2>
class BaseTest32
{
public:
   BaseTest32(){}
   bool run(int first, int last, std::fstream &fout);
   virtual void apply(const I1 &, const I2 &, const I3 &, O1 &, O2&)=0;//{}
   virtual const char *getName() const=0;// {return "BaseTest32";}
protected:
   void addCase(const I1 &i1, const I2 &i2, const I3 &i3, const O1 &o1, const O2 &o2);
   std::vector<I1> i1s;
   std::vector<I2> i2s;
   std::vector<I3> i3s;
   std::vector<O1> o1s;
   std::vector<O2> o2s;
};

template<typename I1, typename I2, typename I3,
   typename O1, typename O2>
bool BaseTest32<I1, I2, I3, O1, O2>::run(int first, int last, std::fstream &fout)
{
   O1 tempo1;
   O2 tempo2;

   // constrain range, if necessary
   if(first < 0)
      first = 0;
   if(last > i1s.size() - 1)
      last = i1s.size() - 1;

   for(int i = first; i <= last; ++i)
   {
      if(i >= 0 && i < i1s.size())
      {
         apply(i1s[i], i2s[i], i3s[i], tempo1, tempo2);
         if((tempo1 == o1s[i]) && (tempo2 == o2s[i]))
            fout << getName() << "(" << i << ") successful. Output: " << tempo1 << ", " << tempo2 << std::endl;
         else
         {
            fout << getName() << "(" << i << ") UNSUCCESSFUL" << std::endl;
            fout << "  expected: " << o1s[i] << ", actual: " << tempo1 << std::endl;
            fout << "  expected: " << o2s[i] << ", actual: " << tempo2 << std::endl;
            return false;
         }
      }
      else
         break;
   }
   return true;
}

template<typename I1, typename I2, typename I3, typename O1, typename O2>
void BaseTest32<I1, I2, I3, O1, O2>::addCase(const I1 &i1, const I2 &i2, const I3 &i3,
   const O1 &o1, const O2 &o2)
{
   i1s.push_back(i1);
   i2s.push_back(i2);
   i3s.push_back(i3);
   o1s.push_back(o1);
   o2s.push_back(o2);
}

//

template<typename I1, typename I2, typename I3,
   typename O1, typename O2, typename O3>
class BaseTest33
{
public:
   BaseTest33(){}
   bool run(int first, int last, std::fstream &fout);
   virtual void apply(const I1 &, const I2 &, const I3 &, O1 &, O2&, O3 &)=0;
   virtual const char *getName() const=0;// {return "BaseTest32";}
protected:
   void addCase(const I1 &i1, const I2 &i2, const I3 &i3, const O1 &o1, const O2 &o2, const O3 &o3);
   std::vector<I1> i1s;
   std::vector<I2> i2s;
   std::vector<I3> i3s;
   std::vector<O1> o1s;
   std::vector<O2> o2s;
   std::vector<O3> o3s;
};

template<typename I1, typename I2, typename I3,
   typename O1, typename O2, typename O3>
bool BaseTest33<I1, I2, I3, O1, O2, O3>::run(int first, int last, std::fstream &fout)
{
   O1 tempo1;
   O2 tempo2;
   O3 tempo3;

   // constrain range, if necessary
   if(first < 0)
      first = 0;
   if(last > i1s.size() - 1)
      last = i1s.size() - 1;

   for(int i = first; i <= last; ++i)
   {
      if(i >= 0 && i < i1s.size())
      {
         apply(i1s[i], i2s[i], i3s[i], tempo1, tempo2, tempo3);
         if((tempo1 == o1s[i]) && (tempo2 == o2s[i]) && (tempo3 == o3s[i]))
            fout << getName() << "(" << i << ") successful. Output: "
                 << tempo1 << ", "
                 << tempo2 << ", "
                 << std::endl;
         else
         {
            fout << getName() << "(" << i << ") UNSUCCESSFUL" << std::endl;
            fout << "  expected: " << o1s[i] << ", actual: " << tempo1 << std::endl;
            fout << "  expected: " << o2s[i] << ", actual: " << tempo2 << std::endl;
            fout << "  expected: " << o3s[i] << ", actual: " << tempo3 << std::endl;
            return false;
         }
      }
      else
         break;
   }
   return true;
}

template<typename I1, typename I2, typename I3, typename O1, typename O2, typename O3>
void BaseTest33<I1, I2, I3, O1, O2, O3>::addCase(const I1 &i1, const I2 &i2, const I3 &i3,
   const O1 &o1, const O2 &o2, const O3 &o3)
{
   i1s.push_back(i1);
   i2s.push_back(i2);
   i3s.push_back(i3);
   o1s.push_back(o1);
   o2s.push_back(o2);
   o3s.push_back(o3);
}

//---------------------------------------------------------------------------
#endif
