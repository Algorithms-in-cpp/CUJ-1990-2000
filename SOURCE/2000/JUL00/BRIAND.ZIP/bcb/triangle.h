//---------------------------------------------------------------------------
#ifndef triangleH
#define triangleH

class Triangle
{
public:
   Triangle() : length1(1.0), length2(1.0), length3(1.0) {}
   bool setLengths(float l1, float l2, float l3);
private:
   float length1; // lengths of sides 1, 2, and 3
   float length2; // clockwise around triangle
   float length3;
};

//---------------------------------------------------------------------------
#endif
