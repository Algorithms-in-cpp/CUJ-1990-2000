//---------------------------------------------------------------------------
#pragma hdrstop

#include "triangle_tests.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

TestSetLengths::TestSetLengths()
{
   addCase(3.0, 2.0, 4.0, true);       // oblique
   addCase(3.0, 4.0, 5.0, true);       // right triangle
   addCase(10.0, 100.0, 100.0, true);  // acute isosceles
   addCase(100.0, 100.0, 100.0, true); // big equilateral
   addCase(6.0, 10.0, 8.0, true);      // another right triangle
   addCase(3.0, 4.0, 2.0, true);       // another oblique
   addCase(1.0, 2.0, 4.0, false);      // bad
   addCase(1.0, 3.0, 1.0, false);      // bad
   addCase(2.0, 1.0, 1.0, true);       // very thin triangle
}
