#pragma hdrstop
#include <condefs.h>

#include <fstream>
#include <iostream>
#include "triangle_tests.h"

//---------------------------------------------------------------------------
USEUNIT("triangle.cpp");
USEUNIT("basetest.cpp");
USEUNIT("triangle_tests.cpp");
//---------------------------------------------------------------------------
#pragma argsused
int main(int argc, char* argv[])
{
   bool okay = true;

   // create a file for test report
   std::fstream fout;
   fout.open("testout.txt", std::ios::out);

   // run the test
   TestSetLengths sltest;
   if(!sltest.run(0, 100, fout))
      okay = false;

   // report results to console
   if(okay)
      std::cout << "all tests okay" << std::endl;
   else
      std::cout << "one or more tests failed" << std::endl;

   fout.close();

   return 0;
}
 