//---------------------------------------------------------------------------
#ifndef triangle_testsH
#define triangle_testsH

#include "basetest.h"
#include "triangle.h"
//---------------------------------------------------------------------------

class TestSetLengths : public BaseTest31<float, float, float, bool>
{
public:
   TestSetLengths();
   void apply(const float &l1, const float &l2, const float &l3, bool &result)
   {
      Triangle triangle;
      result = triangle.setLengths(l1, l2, l3);
   }
   const char *getName() const {return "Test setLengths";}
};

#endif
