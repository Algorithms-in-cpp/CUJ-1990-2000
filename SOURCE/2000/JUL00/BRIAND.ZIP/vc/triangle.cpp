//---------------------------------------------------------------------------
#include "stdafx.h"
#include "triangle.h"
//---------------------------------------------------------------------------


bool Triangle::setLengths(float l1, float l2, float l3)
{
   // check for triangle validity
   if(l1 + l3 <= l2)
      return false;
   if(l2 + l1 <= l3)
      return false;
   if(l3 + l2 <= l1)
      return false;
   length1 = l1;
   length2 = l2;
   length3 = l3;
   return true;
}

