/*
 * Copyright (c) 2000 Stepping Stone Software Ltd
 *                    John Keyes
 * 
 */

import java.util.Vector;

public class TestCollection {

  public static void main(String args []) {
    TestCollection collect = new TestCollection();

    if(args.length == 0) {
	System.out.println("Usage: java TestCollection [ vector | stringvector ]");
	System.exit(1);
    }

    if(args[0].equals("vector")) {
	Vector store = new Vector();
	long start = System.currentTimeMillis();
	for(int i = 0; i < 1000000; i++) {
	    store.addElement("string");
	}
	long finish = System.currentTimeMillis();
	System.out.println((finish-start));
	start = System.currentTimeMillis();
	for(int i = 0; i < 1000000; i++) {
	    String result = (String)store.elementAt(i);
	}
	finish = System.currentTimeMillis();
	System.out.println((finish-start));
    }
    else if(args[0].equals("stringvector")) {
	StringVector store = new StringVector();
	long start = System.currentTimeMillis();
	for(int i = 0; i < 1000000; i++) {
	    store.add("string");
	}
	long finish = System.currentTimeMillis();
	System.out.println((finish-start));
	start = System.currentTimeMillis();
	for(int i = 0; i < 1000000; i++) {
	    String result = store.getStringAt(i);
	}
	finish = System.currentTimeMillis();
	System.out.println((finish-start));
    }
  }
}
