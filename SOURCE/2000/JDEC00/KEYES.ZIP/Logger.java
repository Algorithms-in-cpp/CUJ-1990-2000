/*
 * Copyright (c) 2000 Stepping Stone Software Ltd
 *                    John Keyes
 * 
 */
public class Logger {
  // the instance of this class
  private static Logger theLogger = null;

  /*
    the controller ints should be set in binary
    sequence: 1,2,4,8,16...
    values of log level in between these values
    represent combinations e.g. level 3 = level 1 + level 2
    , level 7 = level 1 + level 2 + level 4
  */

  // this is the controller for info messages
  public final static int CAN_INFO = 1;

  // this is the controller for debug messages
  public final static int CAN_DEBUG = 2;

  // the logging level
  // default setting is for info messages
  public int LOG_LEVEL = 1;

  /**
   * private constructor to only permit this class
   * to create an instance.
   */  
  private Logger() {
  }

  /**
   * getInstance - returns the only instance of this class
   * created.
   */
  public static Logger getInstance() {
    if(theLogger == null) {
      theLogger = new Logger();
    }
    return theLogger;
  }

  /**
   * setLogLevel - set the LOG_LEVEL class variable to level
   */
  public void setLogLevel(int level) {
    if(level >= 0) {
      LOG_LEVEL = level;
    }
  }

  /**
   * canInfo - returns true if the CAN_INFO bit is set
   */
  public boolean canInfo() {
    if((LOG_LEVEL & CAN_INFO) == CAN_INFO) {
      return true;
    }
    return false;
  }

  /**
   * canDebug - returns true if the CAN_DEBUG bit is set
   */
  public boolean canDebug() {
    if((LOG_LEVEL & CAN_DEBUG) == CAN_DEBUG) {
      return true;
    }
    return false;
  }

  /**
   * debugMsg - prints a String to standard output
   */
  public void debugMsg(String msg) {
    System.out.println(msg);
  }

  /**
   * infoMsg - prints a String to standard output
   */
  public void infoMsg(String msg) {
    System.out.println(msg);
  }
}

