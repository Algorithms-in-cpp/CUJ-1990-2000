/*
 * Copyright (c) 2000 Stepping Stone Software Ltd
 *                    John Keyes
 * 
 */
public class Concatenation {

  public static void main(String args []) {
    Concatenation concat = new Concatenation();
    if(args.length == 0) {
	System.out.println("Usage: java Concatenation [ string | stringbuffer ]");
	System.exit(1);
    }

    if(args[0].equals("string")) {
	long start = System.currentTimeMillis();
	for(int i = 0; i < 100000; i++) {
	    concat.printStringDetails();
	}
	long finish = System.currentTimeMillis();
	System.out.println((finish-start));
    }
    else if(args[0].equals("stringbuffer")) {
	long start = System.currentTimeMillis();
	for(int i = 0; i < 100000; i++) {
	    concat.printStringBufferDetails();	
	}
	long finish = System.currentTimeMillis();
	System.out.println((finish-start));
    }
  }

  private void printStringDetails() {
    String name = new String("Joe");
    name+=" is my";
    name+=" name.";
  }

  private void printStringBufferDetails() {    
    StringBuffer name = new StringBuffer("Joe");
    name.append(" is my");
    name.append(" name.");
  }
}
