/*
 * Copyright (c) 2000 Stepping Stone Software Ltd
 *                    John Keyes
 * 
 */
public class StringVector {

  private String [] data;

  private int count;

  public StringVector() {
    // default size is 10
    this(10);
  }

  public StringVector(int initialSize) {
    data = new String[initialSize];
  }

  public void add(String str) {
    // ignore null strings
    if(str == null) {
      return;
    }
    ensureCapacity(count + 1);
    data[count++] = str;
  }

  private void ensureCapacity(int minCapacity) {
    int oldCapacity = data.length;
    if (minCapacity > oldCapacity) {
      String oldData[] = data;
      int newCapacity = oldCapacity * 2;
      data = new String[newCapacity];
      System.arraycopy(oldData, 0, data, 0, count);
    }
  }

  public void remove(String str) {
    if(str == null) {
      // ignore null str 
      return;
    }
    for(int i = 0; i < count; i++) {       
      // check for a match
      if(data[i].equals(str)) {
	// copy data 
        System.arraycopy(data,i+1,data,i,count-1);
        // allow previously valid array element be
	// gc'd
        data[--count] = null;
	return;
      }
    }
  }

  public final String getStringAt(int index) {
    if(index < 0) {
      // if the index is negative
      return null;
    }
    else if(index > count) { 
      // index is > # strings
      return null;
    }
    else {
      // index is good
      return data[index];
    }
  }

  public int size() {
    return count;
  }

  public String [] toStringArray() {
    String [] result = new String[count];
    System.arraycopy(data,0,result,0,count);
    return result;
  }
}
