/*
 * Copyright (c) 2000 Stepping Stone Software Ltd
 *                    John Keyes
 * 
 */
public interface LogAPI {
  
  public void createMsg();

  public void appendLog(String str);

  public void appendLog(int i);

  public void logDebugMsg();

  public void logInfoMsg();
}
