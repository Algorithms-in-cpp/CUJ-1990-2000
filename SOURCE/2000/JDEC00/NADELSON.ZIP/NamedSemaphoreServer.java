package Sem;

import java.rmi.*;
import java.rmi.server.*;

public class NamedSemaphoreServer
{
  public static void main(String args[])
  {
    try
    {
      // An instance of the NamedSemaphoreImpl class is created
      NamedSemaphoreImpl namedSemaphoreServer = new NamedSemaphoreImpl();

      // The class instance is bound to the RMI registry by the name "semaphoreServer"
      Naming.rebind("semaphoreServer", namedSemaphoreServer);
    }
    catch(Exception ex)
    {
      System.out.println("Error: " + ex);
    }
  }
} 