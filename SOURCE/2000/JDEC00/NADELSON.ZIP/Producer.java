package Sem;

import java.rmi.*;
import java.rmi.server.*;
import java.net.*;
import java.io.*;

public class Producer
{
  private Socket clientSocket;
  private DataOutputStream dataOutput;
  private DataInputStream dataInput;
  private NamedSemaphore sem;

  public Producer(String _centralProcessorHostName, String _namedSemaphoreURL)
  {
    try
    {
      // Create a socket and connect to the central processor
      clientSocket = new Socket(InetAddress.getByName(_centralProcessorHostName), 6500);

      // Initialize Socket data streams
      OutputStream out = clientSocket.getOutputStream();
      dataOutput = new DataOutputStream(out);
      InputStream in = clientSocket.getInputStream();
      dataInput = new DataInputStream(in);

      // Connect to the Named Semaphore Server
      sem = (NamedSemaphore)Naming.lookup(_namedSemaphoreURL + "semaphoreServer");
      try
      {
        // Create the consumer semaphore.  Initialize in a "locked" state
        // to prevent the consumer from accessing the central processor before
        // the producer has a change to write to it.
        sem.create("consumer", 0, 1);
      }
      catch(RemoteException ex)
      {
        System.out.println("Consumer Semaphore Already Exists: " + ex);
      }

      try
      {
        // Create the producer semaphore.  Initialize in an "unlocked" state
        // so the producer has a change to put data in the central processor
        // upon startup.
        sem.create("producer", 1, 1);
      }
      catch(RemoteException ex)
      {
        System.out.println("Producer Semaphore Already Exists: " + ex);
      }
    }
    catch(IOException ex)
    {
      System.out.println("Error Creating Client Socket: " + ex);
      System.exit(0);
    }
    catch(NotBoundException ex)
    {
      System.out.println("RMI Communication Problem: " + ex);
      System.exit(0);
    }
  }

  public void writeData(int _maxNum)
  {
    int count = 0;  // Message Counter

    while(true)
    {
      String msg;
      String ack;

      try
      {
        // Lock the producer semaphore.  This semaphore is locked when the
        // producer attempts to write data to the central processor.  It is
        // unlocked by the consumer when it has retrieved the producer's data.
        // The first time through the loop, the producer semaphore is unlocked
        // so that the producer can send data to the central processor before
        // the consumer has a change to access it.
        sem.lock("producer");

        // The "WRITE" command is sent to the central processor indicating that
        // the central processor should store the data sent to it.
        dataOutput.writeUTF("WRITE");

        if (count == _maxNum)
          // If the maximum amount of data specified is sent, an exit message is
          // sent to the central processor.
          msg = "EXIT";
        else
          // A new data set is sent to the central processor
          msg = "Producer: " + count;

        System.out.println(msg);

        // The producer's data is sent and an acknowledgement is recieved
        dataOutput.writeUTF(msg);
        ack = dataInput.readUTF();

        // The consumer semaphore is unlocked.  Unlocking the consumer semaphore
        // enables the consumer to lock this semaphore and access data from the
        // central processor.
        sem.unlock("consumer");

        if (count == _maxNum)
        {
          // If the maximum amout of user-specified data has been sent, the producer
          // exits.  A sleep for 2 seconds is done to ensure that the consumer can lock
          // the "consumer" semaphore and retrieve the EXIT command before the producer
          // removes the semaphores.
          try { Thread.sleep(2000); } catch(Exception ex) { }
          break;
        }
        count++;
      }
      catch(RemoteException ex)
      {
        System.out.println("Error Accessing Named Semaphore: " + ex);
      }
      catch(IOException ex)
      {
        System.out.println("Error Sending Data Over Socket: " + ex);
      }
    }

    try
    {
      // The producer and consumer semaphores are removed from the Named
      // Semaphore Server's catalog.
      sem.remove("producer");
      sem.remove("consumer");
    }
    catch(RemoteException ex)
    {
      System.out.println("Error Removing Named Semaphores: " + ex);
    }
  }

  public static void main(String args[])
  {
    // Usage: java Producer <Central Processor Host Name> <Named Semaphore URL> <Number of Writes to the Central Processor>
    
    // Create a producer object passing it the name of the host that
    // contains the central processor and the name of the url that
    // constains the Named Semaphore Server.  The url must be in the
    // form of rmi://www.yourserver.com/ when the Named Semaphore Server runs
    // on a remote machine.  If the Named Semaphore Server is local than an
    // empty string should be sent (args[1] = "")
    Producer producer = new Producer(args[0], args[1]);

    // Data is written to the central processor for a user-specified number of
    // times.
    producer.writeData(Integer.parseInt(args[2]));
  }
} 