package Sem;

import java.rmi.*;
import java.rmi.server.*;
import java.net.*;
import java.io.*;

public class Consumer
{
  private Socket clientSocket;
  private DataInputStream dataInput;
  private DataOutputStream dataOutput;
  private NamedSemaphore sem;

  public Consumer(String _centralProcessorHostName, String _namedSemaphoreURL)
  {
    try
    {
      // Create a socket and connect to the central processor
      clientSocket = new Socket(InetAddress.getByName(_centralProcessorHostName), 6500);

      // Initialize Socket data streams
      InputStream in = clientSocket.getInputStream();
      OutputStream out = clientSocket.getOutputStream();
      dataInput = new DataInputStream(in);
      dataOutput = new DataOutputStream(out);

      // Connect to the Named Semaphore Server
      sem = (NamedSemaphore)Naming.lookup(_namedSemaphoreURL + "semaphoreServer");
      try
      {
        // Create the consumer semaphore.  Initialize in a "locked" state
        // to prevent the consumer from accessing the central processor before
        // the producer has a change to write to it.
        sem.create("consumer", 0, 1);
      }
      catch(RemoteException ex)
      {
        System.out.println("Consumer Semaphore Already Exists: " + ex);
      }

      try
      {
        // Create the producer semaphore.  Initialize in an "unlocked" state
        // so the producer has a change to put data in the central processor
        // upon startup.
        sem.create("producer", 1, 1);
      }
      catch(RemoteException ex)
      {
        System.out.println("Producer Semaphore Already Exists: " + ex);
      }
    }
    catch(IOException ex)
    {
      System.out.println("Error Creating Client Socket: " + ex);
      System.exit(0);
    }
    catch(NotBoundException ex)
    {
      System.out.println("RMI Communication Problem: " + ex);
      System.exit(0);
    }
  }

  public void readData()
  {
    while(true)
    {
      try
      {
        // Lock the consumer semaphore.  This semaphore is locked when the
        // consumer attempts to retrieve data from the central processor.  This
        // semaphore is unlocked by the producer after the producer sends data to
        // the central processor.
        sem.lock("consumer");

        // The "READ" command is sent to the central processor indicating that
        // the central processor send the data that it has stored.
        dataOutput.writeUTF("READ");

        // The data is retrieved and stored
        String data = dataInput.readUTF();

        // If the data the central processor is storing is "EXIT", the consumer
        // exits.
        if (data.equals("EXIT"))
          System.exit(0);

        // Otherwise the consumer displays the data.
        System.out.println("Consumer: " + data);

        // The "producer" semaphore is unlocked.  This allows the producer to lock
        // this semaphore and send more data to the central processor.
        sem.unlock("producer");
      }
      catch(RemoteException ex)
      {
        System.out.println("Error Accessing Named Semaphore: " + ex);
      }
      catch(IOException ex)
      {
        System.out.println("Error Sending Data Over Socket: " + ex);
      }
    }
  }

  public static void main(String args[])
  {
    // Usage: java Consumer <Central Processor Host Name> <Named Semaphore URL>
    
    // Create a consumer object passing it the name of the host that
    // contains the central processor and the name of the url that
    // constains the Named Semaphore Server.  The url must be in the
    // form of rmi://www.yourserver.com/ when the Named Semaphore Server runs
    // on a remote machine.  If the Named Semaphore Server is local than an
    // empty string should be sent (args[1] = "")
    Consumer consumer = new Consumer(args[0], args[1]);

    // The consumer loops and retrieves all data the producer has provided.
    consumer.readData();
  }
}