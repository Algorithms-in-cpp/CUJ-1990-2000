import java.net.*;
import java.io.*;

public class CentralProcessor extends Thread
{
  private ServerSocket socket;
  private String data = new String();

  public CentralProcessor()
  {
    try
    {
      // A server socket is created and bound to port 6500
      socket = new ServerSocket(6500);
    }
    catch(IOException ex)
    {
      System.out.println("Cannot Create Socket: " + ex);
      System.exit(0);
    }
  }

  public void run()
  {
    try
    {
      while(true)
      {
        // The socket accepts connections and creates a new thread with which
        // to communicate with the connected client
        Socket newSocket = socket.accept();
        ClientCommunicate newClient = new ClientCommunicate(this, newSocket);
        newClient.start();
      }
    }
    catch(IOException ex)
    {
      System.out.println("Error Accepting Connection: " + ex);
    }
  }

  public void setData(String _data) { data = _data; }
  public String getData() { return data; }
  
  public static void main(String args[])
  {
    CentralProcessor centralProcessor = new CentralProcessor();
    centralProcessor.start();
    try { centralProcessor.join(); } catch(Exception ex) { }
  }
} 