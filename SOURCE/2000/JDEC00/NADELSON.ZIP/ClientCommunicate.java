import java.net.*;
import java.io.*;

public class ClientCommunicate extends Thread
{
  private Socket socket;
  private CentralProcessor centralProcessor;

  public ClientCommunicate(CentralProcessor _processor, Socket _socket)
  {
    socket = _socket;
    centralProcessor = _processor;
  }

  public void run()
  {
    try
    {
      // The socket input and output streams are created
      InputStream in = socket.getInputStream();
      OutputStream out = socket.getOutputStream();
      DataInputStream dataInput = new DataInputStream(in);
      DataOutputStream dataOutput = new DataOutputStream(out);

      while(true)
      {
        // The first message sent by either the producer or consumer is the command
        // "READ" or "WRITE".
        String cmd = (String)dataInput.readUTF();

        if (cmd.equals("WRITE"))
        {
          // If the command received is write, store the data and send back
          // an acknowledgement.
          centralProcessor.setData((String)dataInput.readUTF());
          dataOutput.writeUTF("OK");
        }
        else if (cmd.equals("READ"))
        {
          // If the command received is read, send the data stored
          dataOutput.writeUTF(centralProcessor.getData());
        }
      }
    }
    catch(IOException ex)
    {
      System.out.println("Socket Communication Error: " + ex);
    }
  }
}