package Sem;

import java.rmi.*;

interface NamedSemaphore extends Remote
{
  public void create(String _name, int _initialValue, int _maxValue) throws RemoteException;
  public void lock(String _name) throws RemoteException;
  public void unlock(String _name) throws RemoteException;
  public void remove(String _name) throws RemoteException;
  public int getValue(String _name) throws RemoteException;
} 