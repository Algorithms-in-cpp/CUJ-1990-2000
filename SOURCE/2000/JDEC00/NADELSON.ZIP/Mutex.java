package Sem;

public class Mutex
{
  /** Create a Mutex */
  public Mutex()
  {
  }

  /** Locks the Mutex */
  public synchronized void lock()
  {
    // Loop util the wait returns.  If for some reason the wait is
    // interrupted loop again.
    while(true)
    {
      try
      {
        wait();
        break;
      }
      catch(InterruptedException ex)
      {
      }
    }
  }

  /** Unlock the Mutex */
  public synchronized void unlock()
  {
    // Notify all threads waiting on the Mutex that they can lock it.
    notifyAll();
  }
}