
/*
 * CameraSelector.java
 *
 * @author Peter Meehan  Copyright(c) 2000
 *
 * Spotlet that displays a list of preset camera views and allows
 * the user to select one. 
 */

import com.sun.kjava.*;
import java.util.Hashtable;

public class CameraSelector extends Spotlet {

    /*
     * Display constants
     */
    public static final int SCREEN_WIDTH = 160;
    public static final int SCREEN_HEIGHT = 160;
    Graphics g = Graphics.getGraphics();
    
    /*
     * CameraClient dispatches events to imageviewer
     */
    CameraClient dispatcher = null;

    /*
     * Preset views and corresponding URLs
     */
    String presets[][] = {
        {"Living Room","http://.../halfsize.jpg?camera=2"},
        {"Minireef","http://.../halfsize.jpg?camera=5&pan=0&tilt=2&zoom=1"},
        {"Hammer Coral","http://.../halfsize.jpg?camera=5&pan=19&tilt=6&zoom=859"},
        {"Feather Duster","http://.../halfsize.jpg?camera=5&pan=-24&tilt=0&zoom=959"},
        {"Torch Coral","http://.../halfsize.jpg?camera=5&pan=-4&tilt=8&zoom=872"},
        {"Fungi","http://.../halfsize.jpg?camera=5&pan=7&tilt=10&zoom=999"},
        {"Carpet Anenome","http://.../halfsize.jpg?camera=5&pan=16&tilt=-5&zoom=739"},
        {"Coral Colony","http://.../halfsize.jpg?camera=5&pan=3&tilt=11&zoom=739"},
        {"Mushroom Coral","http://.../halfsize.jpg?camera=5&pan=-21&tilt=5&zoom=999"},
        {"Colt Coral","http://.../halfsize.jpg?camera=5&pan=-13&tilt=10&zoom=999"},
        {"Sinularia","http://.../halfsize.jpg?camera=5&pan=-17&tilt=10&zoom=999"},
        {"Sea Sponge","http://.../halfsize.jpg?camera=5&pan=-14&tilt=-6&zoom=725"}
    };
    Hashtable presetURLs = new Hashtable();


    /*
     * UI
     */
    String title = "SELECT A CAMERA VIEW";
    SelectScrollTextBox scrolledList = null;


    /*
     * Construct the list of presets from the preset definitions.
     * Pass this string to the SelectScrolltextBox contructor
     */
    public CameraSelector(CameraClient dispatcher) {
        /*
         * Store CameraClient for event dispatching
         */
        this.dispatcher = dispatcher;

        /*
         * Build list of preset camera names and hash corresponding urls
         */
        StringBuffer buffer = new StringBuffer();
        for (int i=0;i<presets.length;i++) {
            buffer.append(presets[i][0]);
            buffer.append('\n');
            presetURLs.put(presets[i][0],presets[i][1]);
        }
        /*
         * Calculate scrolltextbox geometry
         */
        int titleHeight = g.getHeight(title);
        scrolledList = 
            new SelectScrollTextBox(buffer.toString(),
                                    0,titleHeight,
                                    SCREEN_WIDTH,SCREEN_HEIGHT-titleHeight);
    }
    /*
     * Paint the spotlet
     */
    public void paint() {

        g.clearScreen(); // erase current screen contents

        /*
         * Paint title
         */
        int titleWidth = g.getWidth(title);
        int x = (SCREEN_WIDTH-titleWidth)/2;
        g.drawString(title,x,0,Graphics.INVERT);
        /*
         * Paint scrolledlist
         */
        scrolledList.paint();
    }

    /*
     * Handle key and character entry events
     *
     * @param keycode the key that was pressed or character that was entered
     */
    public void keyDown(int keycode) {
        if (keycode == Spotlet.KEY_HARD1) 
            System.exit(0);
    }

    /*
     * Handle pen down events.
     * Pass event coordinates to Scrolled List and retrieve
     * selection. If selection valid (non-null) pass to imageviewer.
     *
     * @param keycode the key that was pressed or character that was entered
     */
    public void penDown(int x,int y) {
        String desc = scrolledList.getSelection(x,y);
        if (desc != null && desc.length()  0) {
            /*
             * Get corresponding url
             */
            String url = (String)presetURLs.get(desc);
            dispatcher.handleImageRequest(desc,url);
        }
        else 
            Graphics.playSound(Graphics.SOUND_ERROR);
    }
}
