
/**
 * HelloWorld.java
 *
 * Simple CLDC/kjava program.
 *
 * @author Peter Meehan Copyright (c) 2000
 *
 */

import com.sun.kjava.*;

/**
 * All KVM programs extend the Spotlet class. Spotlet
 * provides an execution framework and event management
 * to KVM programs.
 */
public class HelloWorld extends Spotlet {

    /*
     * Palm screen dimensions are constant
     */
    private final int SCREEN_WIDTH = 160;
    private final int SCREEN_HEIGHT = 160;

    /*
     * There is a single graphics context in the KVM
     */
    Graphics g = Graphics.getGraphics();

    /*
     *  Lone UI button
     */
    Button button = null;

    /*
     * When a key is pressed or a character is entered via Graffiti or the
     * soft keyboard, if it is the Agenda hard key or the character 'q'
     * quit.
     */
    public void keyDown(int keycode) {

        if ((keycode == Spotlet.KEY_HARD1) ||
            (keycode == 'q'))
            System.exit(0);
    }

    /*
     * When the pen is tapped on the screen see if the button was pressed.
     * If so quit
     *
     * @param x the x coordinate of the pen down event
     * @param y the y coordinate of the pen down event
     */
    public void penDown(int x,int y) {
        /*
         * test if pen in button and show button feedback
         */
        if (button.pressed(x,y)) { 
            System.exit(0);
        }
    }

    /*
     * Display the hello world button to start
     */
    public HelloWorld() {
        String hello = "Hello World";
        int stringWidth = g.getWidth(hello); // get string dimensions
        int stringHeight = g.getHeight(hello);

        /*
         * Create a centered button.
         */
        button = new Button(hello, 
                            (SCREEN_WIDTH-stringWidth)/2,
                            (SCREEN_HEIGHT-stringHeight)/2);
        g.clearScreen(); // erase screen contents
        button.paint(); // draw the button on the screen
    }

    /*
     * Instantiate the spotlet instance and register for system key events
     */
    public static void main(String args[]) {
        Spotlet spotlet = new HelloWorld();
        spotlet.register(Spotlet.WANT_SYSTEM_KEYS);
    }
}
                                
    
