// Listing 1
#ifndef EVENT_DATA_H
#define EVENT_DATA_H

class EventData 
{
public:
    virtual ~EventData() {};  
};
#endif //EVENT_DATA_H

