// Listing 4

// Author code change subsequent to article publication:
//
// Microsoft Visual C++ 6 gave a runtime error regarding an 
// incorrect calling convention while executing 
// StateMachine::StateEngine(). When StateMachine::StateEngine() 
// calls a state function that uses a void as an input argument 
// (e.g. void Motor::ST_Idle(void)) the fault occurs.
//
// While the code worked on some compilers, it is definitely not 
// portable. The basic problem has to do with the state function 
// signatures. In the article I indicated that a void or EventData* 
// were both acceptable arguments to a state function. This is 
// incorrect if you want portable code. Only a pointer to EventData, 
// or a derived class thereof, is allowed. State functions that 
// don�t require event data should just pass in a pointer to base 
// class EventData. This change ensures that when calling a state 
// function via a pointer, they all have the same function signature.
//
// In class Motor, making the following function signature changes 
// fixes the portability problem:
//
// void ST_Idle(EventData*);
// void ST_Stop(EventData*);
// 
// The code below has been corrected.

#ifndef MOTOR_H
#define MOTOR_H
#include "StateMachine.h"

// structure to hold event data passed into state machine
struct MotorData : public EventData
{
    int speed;
};

// the Motor state machine class
class Motor : public StateMachine
{
public:
    Motor() : StateMachine(ST_MAX_STATES) {}

    // external events taken by this state machine
    void Halt();
    void SetSpeed(MotorData*);
private:
    // state machine state functions
    void ST_Idle(EventData*);
    void ST_Stop(EventData*);
    void ST_Start(MotorData*);
    void ST_ChangeSpeed(MotorData*);

    // state map to define state function order
    BEGIN_STATE_MAP
        STATE_MAP_ENTRY(ST_Idle)
        STATE_MAP_ENTRY(ST_Stop)
        STATE_MAP_ENTRY(ST_Start)
        STATE_MAP_ENTRY(ST_ChangeSpeed)
    END_STATE_MAP

    // state enumeration order must match the order of state
    // method entries in the state map
    enum E_States { 
        ST_IDLE = 0,
        ST_STOP,
        ST_START,
        ST_CHANGE_SPEED,
        ST_MAX_STATES
    };
};
#endif //MOTOR_H


