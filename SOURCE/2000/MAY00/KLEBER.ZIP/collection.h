class MyCollection;
typedef LockAuto<MyCollection> CollectionAutoLock;

class MyCollection : private ThreadSafeMS
{
public:

        MyCollection()
                : ThreadSafeMS()
        {
        }

        ~ MyCollection()
        {
        }

        int Count() const
        {
                assert(IsLocked());
                return m_data.size();
        }

        MyItem& At(const int i)
        {
                assert(IsLocked());
                return m_data[i];
        }

private:

        std::vector<MyItem> m_data;

        // Copy and assignment are not supported
        MyCollection(const MyCollection& rhs);
        MyCollection& operator= (const MyCollection& rhs);

        friend CollectionAutoLock;
};
