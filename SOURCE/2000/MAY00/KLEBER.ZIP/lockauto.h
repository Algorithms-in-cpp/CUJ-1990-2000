template<class _Type>
class LockAuto
{
public:

LockAuto(_Type& res)
                : m_res(res)
        {
                m_res.lock();
        }

        ~LockAuto()
        {
                m_res.unlock();
        }

private:

        _Type&  m_res;

        // Copy and assignment are not supported
        LockAuto(const LockAuto& rhs);
        LockAuto& operator= (const LockAuto& rhs);
};
