template<class _Type>
class LockManual
{
public:

        LockManual(_Type& res)
                : m_res(res)
        {
        }

        ~LockManual()
        {
                if ( m_bOwn && m_res.IsLocked() )
                {
                        m_res.unlock();
                }
        }

        void lock()
        {
                m_res.lock();
                m_bOwn = true;
        }

        void unlock()
        {
                m_res.unlock();
                m_bOwn = false;
        }

private:

        _Type& m_res;
        bool    m_bOwn;

        LockManual(const LockManual& rhs);
        LockManual& operator= (const LockManual& rhs);
};
