class ThreadSafe
{
public:
        ThreadSafe();
        ~ThreadSafe();
        void lock();
        void unlock();
        bool IsLocked() const;

private:

        CRITICAL_SECTION        m_cs;

        // Not supported.
        ThreadSafe(const ThreadSafe& rhs);
        ThreadSafe& operator= (const ThreadSafe& rhs);
};
inline ThreadSafe::ThreadSafe()
        : m_cs()
{
        ::InitializeCriticalSection(&m_cs);
}
inline ThreadSafe::~ThreadSafe()
{
        if ( IsLocked() )
        {
                unlock();
        }
        ::DeleteCriticalSection(&m_cs);
}
inline void ThreadSafe::lock()
{
        ::EnterCriticalSection(&m_cs);
}
inline void ThreadSafe::unlock()
{
        ::LeaveCriticalSection(&m_cs);
}
inline bool ThreadSafe::IsLocked() const
{
        return ( m_cs.LockCount >= 0 );
}
