int ThreadSafeIterate()
{
        MyCollection data;
        CollectionAutoLock lock(data);
        const int iCount = data.Count();
        for ( int i = 0; i < iCount; ++i )
        {
                MyItem& item = data.At(i);
                // do something
        }
}
