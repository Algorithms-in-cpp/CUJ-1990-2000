#include <pthread.h>

class Thread {
protected:
  pthread_t _threadptr;
  void Run() {}
public:
  void Create() { pthread_create(&_threadptr, NULL, thread_func, this); } 
  ~Thread() { pthread_join(_threadptr, NULL); }
  friend void *thread_func(void *);
};

void *thread_func(void *p) {
  Thread *t=reinterpret_cast<Thread *>(p);
  if (t)
    t->Run();
  return 0;
}

int main() {
  Thread t;
  t.Create();
  return 0;
}
