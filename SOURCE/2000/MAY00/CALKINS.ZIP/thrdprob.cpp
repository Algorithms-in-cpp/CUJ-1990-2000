#include <pthread.h>

template <class T>
class Thread {
protected:
  pthread_t _threadptr;
  void Run() {}
public:
  void Create() { pthread_create(&_threadptr, NULL, thread_func, this); } 
  ~Thread() { pthread_join(_threadptr, NULL); }
  friend void *thread_func(void *);
};

// error - can't make the thread function a template function
template <class T>
void *thread_func(void *p) {
  Thread<T> *t=reinterpret_cast<Thread<T> *>(p);
  if (t)
    t->Run();
}

main() {
  Thread<int> t;
  t.Create();
  return 0;
}

