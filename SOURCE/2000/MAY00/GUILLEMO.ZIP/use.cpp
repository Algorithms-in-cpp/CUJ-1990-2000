// ErrorCodes.h
enum ErrorCode
{ Success, MyError1, MyError2, MyError3 };

// main.cpp
#include "ErrorCodes.h"

ErrorCode doSomeJob(int _i)
{
  if (_i == 0)
    return MyError1;
  else if (_i > 10)
    return MyError2;
  
  ... // some code

  return Success;
}


ErrorCode myFunc(void)
{
  doSomeJob(0); // <-- return value not used

  ErrorCode err = doSomeJob(5);
  err = doSomeJob(15); // <-- previous value of err not tested
  if (err != Success) // <-- return value is tested
    return err;
  
  ... // some code
  
  return Success;
}


int main(void)
{
  if (myFunc() == Success)
    return 0;
  else
    return 1;
}
