#ifndef __WIN32Q1_H__
#define __WIN32Q1_H__

#include <windows.h>
#include <process.h>
#include <deque>
#include <iostream>

using namespace std;

// dummy data type, could be anything
class Data {
public:
        Data() : x(0) {}

        Data(int i) : x(i) {}

        int x;
};

// NOTE : this is the first cut without waiting
class BoundedInterthreadQueue {
private:
        deque<Data *>    m_qData;                       // underlying data store
        CRITICAL_SECTION m_csec;                // data store lock
        long             m_nBound;
 
public:
        BoundedInterthreadQueue() {
                m_nBound = 10; // default
                InitializeCriticalSection(&m_csec);
        }

        BoundedInterthreadQueue(int bound) {
                m_nBound = bound;
                InitializeCriticalSection(&m_csec);
        }

        // wrap push_back in a lock
        void put(Data *p) {
                // lock the data
                EnterCriticalSection(&m_csec);

                // 
                if (m_qData.size() < m_nBound) {
                        m_qData.push_back(p);
                }
                else {
                        cout << "error : queue is full, data lost\n" << endl;
                }
                LeaveCriticalSection(&m_csec);
        }

        // wrap get in a lock
        Data *get() {
                Data *p;
                EnterCriticalSection(&m_csec);
                if (!m_qData.empty()) {
                        p = m_qData.front();
                        m_qData.pop_front();
                }
                else {
                        cout << "error : queue is empty\n" << endl;
                        p = 0;
                }
                LeaveCriticalSection(&m_csec);
                return p;
        }
};

#endif
