// myString.cpp : Implementation of CmyString
#include "stdafx.h"
#include "MyStringObject.h"
#include "myString.h"

/////////////////////////////////////////////////////////////////////////////
// CmyString


STDMETHODIMP CmyString::get_counter(long *pVal)
{
	*pVal = m_counter;
	return S_OK;
}

STDMETHODIMP CmyString::capitalize(BSTR* str)
{
	InterlockedIncrement(&m_counter);
	/*long count = m_counter;   ***** these three lines exagerate the counter synchrnization problem
	Sleep(0);
	m_counter = count +1;*/
	BSTR str2 = SysAllocString(*str);
	// capitalize str2 here
	SysFreeString(*str); // **** Comment this out to observe the leak
	*str = str2;

	return S_OK;
}
