	
// myString.h : Declaration of the CmyString

#ifndef __MYSTRING_H_
#define __MYSTRING_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CmyString
class ATL_NO_VTABLE CmyString : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CmyString, &CLSID_myString>,
	public IDispatchImpl<ImyString, &IID_ImyString, &LIBID_MYSTRINGOBJECTLib>
{
public:
	CmyString()
	{
		m_pUnkMarshaler = NULL;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MYSTRING)
DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CmyString)
	COM_INTERFACE_ENTRY(ImyString)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

	HRESULT FinalConstruct()
	{
		m_counter = 0;
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

private:
	long m_counter;

// ImyString
public:
	STDMETHOD(capitalize)(/*[in,out]*/BSTR* str);
	STDMETHOD(get_counter)(/*[out, retval]*/ long *pVal);
};

#endif //__MYSTRING_H_
