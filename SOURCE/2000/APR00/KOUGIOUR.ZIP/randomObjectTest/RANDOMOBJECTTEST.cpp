#include "stdafx.h"

class CRANDOMOBJECTTEST : public HSTSTDriver {
public:
    
	void test()
	{
		RANDOMLib::IRandPtr objRand(__uuidof(RANDOMLib::Rand));

		long val = objRand->nextValue;
		_tprintf(_T("%d\n"), val);
	}
    //------------------------------------------------------------------
    
	// Called at every loop
    virtual HRESULT FreeThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator* objRnd) {
       
		test();

		return S_OK;
    }
    
    //------------------------------------------------------------------
    // Called at every loop
	virtual HRESULT AptThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator* objRnd)  {
  
		test();

          return S_OK;
    }
    
    //-------------------------------------------------------------------
    // Called before creating the threads
    virtual HRESULT OnBeforeStartThreads() {
        
		// **** Add your code here

        return S_OK;
    };

	//-------------------------------------------------------------------
	// Called after the threads have been created
    virtual HRESULT OnAfterStartThreads()  {

		// **** Add your code here

		return S_OK;
	};
    
    //-------------------------------------------------------------------
     // Called before the driver exits
    HRESULT OnAfterThreadsExited() {
   
		// **** Add your code here
        
        return S_OK;
    }
};

HSTSTDriver* g_objDriver = new CRANDOMOBJECTTEST;


//----------------------------------------------------------------------


