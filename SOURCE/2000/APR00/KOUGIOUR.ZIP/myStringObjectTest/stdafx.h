// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__EB012489_A4DB_11D1_BFDE_00201829472A__INCLUDED_)
#define AFX_STDAFX_H__EB012489_A4DB_11D1_BFDE_00201829472A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define STRICT

#define _WIN32_WINNT 0x0400
#include <windows.h>
#include <objbase.h>
#include <atlbase.h>

#include <hsapp.h>
#include <hsCWPRandomGenerator.h>
#include <hsTSTMain.h>
#include <process.h>

#import "../myStringObject/debug/myStringObject.dll"

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__EB012489_A4DB_11D1_BFDE_00201829472A__INCLUDED)
