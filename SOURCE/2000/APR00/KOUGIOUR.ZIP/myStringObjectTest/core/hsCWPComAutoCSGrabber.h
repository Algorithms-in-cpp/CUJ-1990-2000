#ifndef __HSCWPAUTOGRAB__
#define __HSCWPAUTOGRAB__

class HSCWPComAutoCSGrabber {
public:
    HSCWPComAutoCSGrabber(CComAutoCriticalSection* lock) : m_lock(lock) {
        m_lock->Lock();
    }   

    ~HSCWPComAutoCSGrabber()
    {
        m_lock->Unlock();
    }

    CComAutoCriticalSection* m_lock;
};

#endif