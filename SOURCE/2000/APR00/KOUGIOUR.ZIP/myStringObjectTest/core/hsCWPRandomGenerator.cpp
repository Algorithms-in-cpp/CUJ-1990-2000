// RandomGenerator.cpp: implementation of the CRandomGenerator class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <hsCWPRandomGenerator.h>
#include <hsCWPComAutoCSGrabber.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const unsigned long m =  2147483647; // 2 ^ 31 -1
const unsigned long a = 314159269; // see Knuth's "Seminumerical algotithms" p. 102 and p. 170
const unsigned long c = 1;

CRandomGenerator::CRandomGenerator(int seed)
{
    init(seed);
}

CRandomGenerator::~CRandomGenerator()
{
}

void CRandomGenerator::init(int seed)
{
    if (seed != -1) {
        m_X = m_seed = seed;
        return;
    }

    LARGE_INTEGER li;
    if (QueryPerformanceCounter(&li) == 0) {
        m_seed = m_X = (unsigned)GetTickCount() + GetCurrentProcessId() * GetCurrentThreadId();
    } else {
        LARGE_INTEGER liPerf;
        QueryPerformanceFrequency(&liPerf);

        m_seed = m_X = li.LowPart % liPerf.LowPart; 
    }
}

unsigned 
CRandomGenerator::seed()
{
    return m_seed;
}

unsigned CRandomGenerator::GenerateNext()
{
    HSCWPComAutoCSGrabber grabAndRelease(&m_lock);
    __int64 X = m_X;
    X *= a;
    X += c;
    X = X % m;
    m_X = X;

    return m_X;
}

CComBSTR CRandomGenerator::GetComBSTR(int minLen, int maxLen, char start, char end)
{
    CComBSTR ret;
    int len = GetRandomInt(minLen, maxLen);
    char lpszBuffer[1000];
    for (int i = 0; i < len; i++) {
        lpszBuffer[i] = GetRandomChar(start, end);
    }
    lpszBuffer[len] = '\0';
    
    ret = lpszBuffer;

    ATLTRACE("RANDOM %s\n", lpszBuffer);
    
    return ret;
}

int CRandomGenerator::GetRandomInt(int min, int max)
{
    unsigned  val = GenerateNext();
    ATLTRACE("%d \n", val);
    double dtmp = ((double)val / (double)m);
    dtmp *= (double)(max - min + 1);
    int ret = (int)dtmp;
    assert((dtmp >= ret) && (ret + 1 > dtmp));

    ret += min;
    assert(ret >= min);
    assert(ret <= max);
    return ret;
}

char CRandomGenerator::GetRandomChar(char start, char end)
{
    return GetRandomInt(start, end);
}
