// *
// * (C) Copyright 1996 by Healtheon Corp.
// * All Rights Reserved.
// *
// * This is UNPUBLISHED PROPRIETARY SOURCE CODE of Healtheon Incorporated;
// * the contents of this file may not be disclosed to third parties, copied or
// * duplicated in any form, in whole or in part, without the prior written
// * permission of Healtheon Incorporated.
// *
// * RESTRICTED RIGHTS LEGEND:
// * Use, duplication or disclosure by the Government is subject to 
// * restrictions
// * as set forth in subdivision (c)(1)(ii) of the Rights in Technical Data
// * and Computer Software clause at DFARS 252.227-7013, and/or in similar or
// * successor clauses in the FAR, DOD or NASA FAR Supplement. Unpublished
// * rights reserved under the Copyright Laws of the United States.
// *

#include "stdafx.h"
#include "hsApp.h"

#include <strstrea.h>

// The const flags values
HSApp::flags HSApp::fl_null     = 0;       // optional 
HSApp::flags HSApp::fl_req      = 2;       // required     (otherwise optional)
HSApp::flags HSApp::fl_arg      = 4;       // argument     (otherwise option)
HSApp::flags HSApp::fl_option   = 0;       // option       (otherwise argument)
HSApp::flags HSApp::fl_array    = 16;      //
HSApp::flags HSApp::fl_used     = 32;
HSApp::flags HSApp::fl_multiple = 64;

typedef HSApp::CArg* HSApp_CArg_ptr;
//--------------------------------------------------------------------

HSApp::CArg::CArg(
           HSApp* app,
	   char* a_fn,  
	   char* a_m, 
	   char* a_ev,
	   flags a_f 
    ) 
    : m_name(a_fn), m_message(a_m), m_flags(a_f), m_env_variable(a_ev)
{
    // Add ourselves to the list of arguments
    app->add(this);
}

//..................................................................

void
HSApp::add(CArg* arg)
{
    assert(m_args_index <= m_args_max_index);
    if (m_args_index == m_args_max_index) {
	// We run put of space, copy them
	if (m_args_index == 0) m_args_index = 1;
	HSApp_CArg_ptr* tmp = new HSApp_CArg_ptr[2 * m_args_index];
	for (int i = 0; i < m_args_index; i++) {
	    tmp[i] = m_args[i];
	}
	delete[] m_args;
	m_args = tmp;
	m_args_max_index = 2 * m_args_max_index;
    }

    // We now have enough space
    assert(m_args_index < m_args_max_index);

    // Check that this would not be duplicate
    for (int i = 0; i < m_args_index; i++) {
        if (strcmp(m_args[i]->name(), arg->name()) == 0) {
            fprintf(stderr, "HSApp WARNING: option \"%s\" is used more than once\n", arg->name());
        }
    }
    m_args[m_args_index] = arg;
    m_args_index++;  
}


//..................................................................
void 
HSApp::CArg::print_usage(ostream& str)
{
    if (!(this->m_flags & HSApp::fl_req)) str << "[";
    if (!(this->m_flags & HSApp::fl_arg)) str << "-";
    str  << this->m_name  << type();
    if (this->m_flags & HSApp::fl_array) str << " ...";
    if (!(this->m_flags & HSApp::fl_req)) str << "]";
    str << " ";
}

//....................................................................

void 
HSApp::CArg::print_usage_extended(ostream& str)
{
    str << "\t\"";
    if (!(m_flags & fl_arg)) str << "-";
    str << this->m_name << "\"" << " ";
    str << this->m_message  << " ";
    if (m_env_variable != NULL) {
	str << " ENV: $" <<	this->m_env_variable;
    }
    if (!( m_flags & HSApp::fl_req)) {
	str << " DEF: ";
	str << this;
    }
    str << endl;
}

//**********************************************************************

void 
HSApp::parse_argument()
{
    for (int i = 0; i < m_args_index; i++) {
	if (m_args[i]->is_option()) continue;
	if ((m_args[i]->is_used()) && (!m_args[i]->is_array())) continue;  
	
	m_args[i]->add_value_from_lexeme(m_argv[0]); 
	m_args[i]->m_flags |= fl_used;
	return;
    }

    strstream str;
    str << "Unexepected argument " << m_argv[0] << '\0';
    if (!(m_flags & IgnoreUnknownArgs))
	print_usage_and_exit(str.str());
}

//.....................................................

void
HSApp::parse_internal()
{
   while (m_argc-- > 0) {
       if (*m_argv[0] == '-') {
	   parse_flags();
       } else {
	   parse_argument();
       }
       m_argv++;
   }

   for (int i = 0; i < m_args_index; i++) {
       if (!(m_args[i]->is_used()) && m_args[i]->is_required()) {
	   strstream str;
	   str << "missing required argument. name: " << m_args[i]->m_name << '\0';
	   print_usage_and_exit(str.str());
       }
   }
}

//......................................................

void 
HSApp::parse_flags()
{	
    for (int i = 0; i < m_args_index; i++) {
	if (m_args[i]->is_argument()) continue;
	if ((m_args[i]->is_used()) && (!m_args[i]->is_array())) continue;
	// Get the lexeme of this argument if any
	char* lexeme = NULL;
	if ((strlen(m_args[i]->name()) == 1) &&
	    ((m_args[i]->name())[0] == m_argv[0][1])) {
	    if (m_argv[0][2] == '\0') {
		if (!m_args[i]->has_length()) {
		    lexeme = "";
		} else {
		    m_argv++; m_argc--;
		    lexeme = m_argv[0];
		}
	    } else {
		lexeme = &m_argv[0][2];
	    }	
	} else if (strcmp(m_args[i]->name(), 
			&m_argv[0][1]) == 0) {
	    if (!m_args[i]->has_length()) {
		lexeme = "";
	    } else {
		m_argv++; m_argc--;
		lexeme = m_argv[0];
	    }
	} else {
	    continue;
	}
	
	// Now parse the lexeme and store it at the appropriate
	if (lexeme != NULL) {
	    m_args[i]->add_value_from_lexeme(lexeme);
	    m_args[i]->m_flags |= HSApp::fl_used;
        } else {
            strstream str;
	    str << "Argument expected for option " << m_args[i]->name() << ends;
	    print_usage_and_exit(str.str());
        }
	return;
		    
    }
    if (i >= m_args_index) {
	strstream str;
	str << "Unknown option " << m_argv[0] << ends;
	if (!(m_flags & IgnoreUnknownOptions))
	    print_usage_and_exit(str.str());
    }
}

//...............................................

void 
HSApp::set_env_values()
{
    for (int i = 0; i < m_args_index; i++) {
	if (m_args[i]->m_env_variable != NULL) {
	    char* lexeme = getenv(m_args[i]->m_env_variable);
	    if (lexeme != NULL) {
		m_args[i]->set_value_from_lexeme(lexeme, 0); 
	    }	
	}
    }
}

//..............................................

void 
HSApp::print_usage_and_exit(const char* reason, int a_code)
{
    strstream str;
    // Print the first line
    str << "Error: " << reason << endl;
    str << "Usage: ";
    for (int i = 0; i < m_args_index; i++) {
	m_args[i]->print_usage(str);
    }
    str << endl;
    
    // Print the explanations
    for (i = 0; i < m_args_index; i++) {
	m_args[i]->print_usage_extended( str);
    }
    str << '\0';
    fatal(str.str(), a_code);
}

//.................................................

HSApp::HSApp(int a_flags)
{
    m_args_index = 0;
    m_args_max_index = 1;
    m_args = new HSApp_CArg_ptr[1];
    m_flags = a_flags;
}

//...................................................

ostream& 
operator<<(ostream& str, HSApp::CArg* a)
{
    a->print(str);
    return str;
}
