#include "stdafx.h"
#include "hsTstMain.h"
#include  <stdio.h>
#include <conio.h>

HSMain::HSMain() :
m_app_name(this, "hscwprob", "Appication name", "hscwprob",  HSApp::fl_arg | HSApp::fl_req),
m_repeatCount(this, "l", "Repeats the test cases # of times ", 1 ,  HSApp::fl_option ),
m_aptThreads(this, "at", "#of apartment threads ", 1 ,  HSApp::fl_option ),
m_freeThreads(this, "ft", "#of free threads ", 0,  HSApp::fl_option ),
m_regression(this, "e", "set so that the program does not stop at the beginning and end", false ,  HSApp::fl_option ),
m_verbose(this, "v", "Verbose level 1-5", 1, HSApp::fl_option),
m_seed(this, "s", "Seed, default is random", -1, HSApp::fl_option)
{
}

HSMain *hsMain;
CRandomGenerator* freeThreadsRG;
CRandomGenerator* aptThreadsRG;

int innerMain(void);

//-------------------------------------------------------------------------------------------------------------

unsigned  __stdcall 
FreeThreadEntryPoint(LPVOID obj)
{
    DWORD retCode;
    int iter = *((int*)obj);
    
    CoInitializeEx(NULL, COINIT_MULTITHREADED);
    if (hsMain->m_verbose() >= 2)
        _tprintf(_T("F:%3d starting\n"),iter);
    for (int i = 0; i < hsMain->m_repeatCount(); i++) {
        if (hsMain->m_verbose() >= 3) _tprintf(_T("F:%3d:%3d starting loop\n"),iter,i);
        retCode = g_objDriver->FreeThreadTest(i, iter, &freeThreadsRG[iter]); 
        if (hsMain->m_verbose() >= 4) _tprintf(_T("F:%3d:%3d ending loop \n"),iter,i);
    }
    if (hsMain->m_verbose() >= 2)
        _tprintf(_T("F:%3d exiting\n"),iter);
    CoUninitialize();
    
    return retCode ;
}

//---------------------------------------------------------

unsigned __stdcall  
ApartmentThreadEntryPoint(LPVOID obj)
{
    int iter = *((int*)obj);
    
    DWORD retCode;
    
    CoInitializeEx(NULL, COINIT_APARTMENTTHREADED );
    if (hsMain->m_verbose() >= 2)
        _tprintf(_T("A:%3d starting\n"), iter);
    for (int i = 0; i < hsMain->m_repeatCount(); i++) {
        if (hsMain->m_verbose() >= 3) _tprintf(_T("A:%3d:%3d starting loop\n"),iter,i);
        retCode = g_objDriver->AptThreadTest(i, iter, &aptThreadsRG[iter]); 
        if (hsMain->m_verbose() >= 4) _tprintf(_T("A:%3d:%3d ending loop\n"),iter,i);
    }
    if (hsMain->m_verbose() >= 2)
        _tprintf(_T("A:%3d exiting\n"),iter);
    CoUninitialize();
    
    return retCode ;
}

//---------------------------------------------------------
static CRandomGenerator gobjRandom;
void main(int argc, char*argv[])
{
    // Parse the args
    hsMain = new HSMain();
    hsMain->parse(argc, argv);
	gobjRandom.init(hsMain->m_seed());
	_tprintf("The random generator seed is: %d\n", gobjRandom.seed());
    
    CoInitialize(NULL);
    if (! hsMain->m_regression() )
    {
        printf("Press a key to continue\n");
        getch();
    }
    
    innerMain();
    
    if (! hsMain->m_regression() )
    {
        printf("Press a key to end\n ");
        getch();
    }
    CoUninitialize();
    delete hsMain;
}

//---------------------------------------------------------

int innerMain(void)
{
    int testCount = 1;  //test case number.
    
    g_objDriver->OnBeforeStartThreads();
    
    // Create and spawn the apartment threads
    HANDLE * aptThreads = new HANDLE[hsMain->m_aptThreads()];
    int    * aptThreadNumbers = new int[hsMain->m_aptThreads()];
	aptThreadsRG = new CRandomGenerator[hsMain->m_aptThreads()];
    HANDLE * freeThreads = new HANDLE[hsMain->m_freeThreads()];
    int    * freeThreadNumbers = new int[hsMain->m_freeThreads()];
	freeThreadsRG = new CRandomGenerator[hsMain->m_freeThreads()];

    int nAptCounter = 0, nFtCounter = 0;
    
    while ((nAptCounter < hsMain->m_aptThreads()) || (nFtCounter < hsMain->m_freeThreads())) {
        unsigned int threadId;
        if (nAptCounter < hsMain->m_aptThreads()) {
            aptThreadNumbers[nAptCounter] = nAptCounter;
			aptThreadsRG[nAptCounter].init(gobjRandom.GenerateNext());
            aptThreads[nAptCounter] = (HANDLE)_beginthreadex(NULL, 0, ApartmentThreadEntryPoint, 
                &aptThreadNumbers[nAptCounter], CREATE_SUSPENDED , &threadId); // the thread starts suspended
            nAptCounter++;
        }
        
        if (nFtCounter < hsMain->m_freeThreads()) {
            freeThreadNumbers[nFtCounter] = nFtCounter;
			freeThreadsRG[nFtCounter].init(gobjRandom.GenerateNext());
            freeThreads[nFtCounter] =  (HANDLE)_beginthreadex(NULL, 0, FreeThreadEntryPoint,
                &freeThreadNumbers[nFtCounter], CREATE_SUSPENDED , &threadId); // the thread starts suspended
            nFtCounter++;
        }
    }

	// Now Resume all the threads
	 for (int i = 0; i < hsMain->m_aptThreads(); i++) {
       ResumeThread(aptThreads[i]);
    };
	  for (i = 0; i < hsMain->m_freeThreads(); i++) {
      ResumeThread(freeThreads[i]);
    };

    g_objDriver->OnAfterStartThreads();
    
    // wait for apartment threads
    for ( i = 0; i < hsMain->m_aptThreads(); i++) {
        WaitForSingleObject(aptThreads[i], INFINITE);
        CloseHandle(aptThreads[i]);
    };
    delete[] aptThreads;
    delete[] aptThreadNumbers;
    
    // wait for free threads
    for (i = 0; i < hsMain->m_freeThreads(); i++) {
        WaitForSingleObject(freeThreads[i], INFINITE);
        CloseHandle(freeThreads[i]);
    };
    delete[] freeThreads;
    delete[] freeThreadNumbers;

    g_objDriver->OnAfterThreadsExited();
    
    return 0;
}

