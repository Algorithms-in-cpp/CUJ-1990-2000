// RandomGenerator.h: interface for the CRandomGenerator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RANDOMGENERATOR_H__6218B338_132E_11D3_A654_000000000000__INCLUDED_)
#define AFX_RANDOMGENERATOR_H__6218B338_132E_11D3_A654_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRandomGenerator  
{
public:
    void init(int seed = -1); // if -1 one is generated
    
    // return a random printable character
    char GetRandomChar(char start, char end);
    
    // return a random int in the [min, max] range
    int GetRandomInt(int min, int max);
    
    // returns a random string with length in the [minLen, maxLen] range
    CComBSTR GetComBSTR(int minLen, int maxLen, char start = 33, char end = 126);
    
    // Generates and gets the next random number
    unsigned GenerateNext();
    
    CRandomGenerator(int seed = -1);
    virtual ~CRandomGenerator();

    unsigned seed();


private:
    CComAutoCriticalSection m_lock;
    unsigned long m_X;
    unsigned long m_seed; //set only once at the beginning 
    
};

#endif // !defined(AFX_RANDOMGENERATOR_H__6218B338_132E_11D3_A654_000000000000__INCLUDED_)
