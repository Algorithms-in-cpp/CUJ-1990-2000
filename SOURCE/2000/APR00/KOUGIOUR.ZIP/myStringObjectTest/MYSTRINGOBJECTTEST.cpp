#include "stdafx.h"

MYSTRINGOBJECTLib::ImyStringPtr objString;

class CMYSTRINGOBJECTTEST : public HSTSTDriver {
public:    

	HRESULT test()
	{
		BSTR str =  SysAllocString(L"panos");
		HRESULT hr = objString->capitalize(&str);
		if (SUCCEEDED(hr)) SysFreeString(str);
		return hr;
	}
    //------------------------------------------------------------------
    
    virtual HRESULT FreeThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator* objRnd) {
		
		return test();
    }
    
    //------------------------------------------------------------------
    
	virtual HRESULT AptThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator* objRnd)  {
  
          return test();
    }
    
    //-------------------------------------------------------------------
    
    virtual HRESULT OnBeforeStartThreads() 
    {
		objString.CreateInstance(__uuidof(MYSTRINGOBJECTLib::myString)); 
        return S_OK;
    };
    
    //-------------------------------------------------------------------
    
    HRESULT OnAfterThreadsExited()
    {
		printf("counter = %d\n", objString->counter);
		objString.Release();
        return S_OK;
    }
};

HSTSTDriver* g_objDriver = new CMYSTRINGOBJECTTEST;


//----------------------------------------------------------------------


