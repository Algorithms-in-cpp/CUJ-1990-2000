	
// Rand.h : Declaration of the CRand

#ifndef __RAND_H_
#define __RAND_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CRand
class ATL_NO_VTABLE CRand : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CRand, &CLSID_Rand>,
	public IDispatchImpl<IRand, &IID_IRand, &LIBID_RANDOMLib>
{
public:
	CRand()
	{
		m_pUnkMarshaler = NULL;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_RAND)
DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CRand)
	COM_INTERFACE_ENTRY(IRand)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

// IRand
public:
	STDMETHOD(get_nextValue)(/*[out, retval]*/ long *pVal);
};

#endif //__RAND_H_
