This project demonstrates a potential defect(?) with the implemntation of the rand() function. 

When you build this project a  "random" COM object will be created.

You ll notice that every time a thread exits the random generator resets itself and starts generating
the same sequence if numbers.