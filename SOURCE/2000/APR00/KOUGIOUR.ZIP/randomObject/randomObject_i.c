/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Dec 28 19:12:11 1999
 */
/* Compiler settings for D:\users\SiteWare\Documents\Articles\StressCOMObjects\source\randomObject\randomObject.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IRand = {0xEDE6A421,0xB668,0x11D3,{0xA6,0x92,0x00,0x80,0xC7,0x52,0xEC,0x9F}};


const IID LIBID_RANDOMLib = {0xEDE6A415,0xB668,0x11D3,{0xA6,0x92,0x00,0x80,0xC7,0x52,0xEC,0x9F}};


const CLSID CLSID_Rand = {0xEDE6A422,0xB668,0x11D3,{0xA6,0x92,0x00,0x80,0xC7,0x52,0xEC,0x9F}};


#ifdef __cplusplus
}
#endif

