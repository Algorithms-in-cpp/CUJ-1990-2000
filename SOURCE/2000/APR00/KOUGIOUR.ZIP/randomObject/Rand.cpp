// Rand.cpp : Implementation of CRand
#include "stdafx.h"
#include "RandomObject.h"
#include "Rand.h"

/////////////////////////////////////////////////////////////////////////////
// CRand


STDMETHODIMP CRand::get_nextValue(long *pVal)
{
	*pVal = rand();

	return S_OK;
}
