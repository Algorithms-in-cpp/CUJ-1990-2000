#ifndef __HSTSTMAIN__
#define __HSTSTMAIN__

// The global state of the program
class HSMain : public HSApp {
public:
    CCstringArg  m_app_name;
    CIntArg      m_repeatCount;
    CIntArg      m_aptThreads;
    CIntArg      m_freeThreads;
    CToggleArg   m_regression;
    CIntArg      m_verbose;
	CIntArg      m_seed;

    HSMain();
};

extern HSMain      *hsMain;

//-----------------------------------------------------------------------

// This class should be subclassesed by the user of the framework
// and an object should be instantiated and assigned to the
// g_objDriver variable
class HSTSTDriver {
public:
    // Called before creating the threads
    virtual HRESULT OnBeforeStartThreads() {return S_OK;};

    // Called after the threads have been created
    virtual HRESULT OnAfterStartThreads()  {return S_OK;};

    // Called before the driver exits
    virtual HRESULT OnAfterThreadsExited() {return S_OK;};
    
    // Called at every loop
    virtual HRESULT FreeThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator*) {return S_OK;};
    virtual HRESULT AptThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator*) {return S_OK;};
};

extern HSTSTDriver* g_objDriver;

#endif


