#if !defined(AFX_COMSTRESSTESTAPPWIZARDAW_H__EDE6A3BE_B668_11D3_A692_0080C752EC9F__INCLUDED_)
#define AFX_COMSTRESSTESTAPPWIZARDAW_H__EDE6A3BE_B668_11D3_A692_0080C752EC9F__INCLUDED_

// COMStressTestAppWizardaw.h : header file
//

class CDialogChooser;

// All function calls made by mfcapwz.dll to this custom AppWizard (except for
//  GetCustomAppWizClass-- see COMStressTestAppWizard.cpp) are through this class.  You may
//  choose to override more of the CCustomAppWiz virtual functions here to
//  further specialize the behavior of this custom AppWizard.
class CCOMStressTestAppWizardAppWiz : public CCustomAppWiz
{
public:
	virtual CAppWizStepDlg* Next(CAppWizStepDlg* pDlg);
		
	virtual void InitCustomAppWiz();
	virtual void ExitCustomAppWiz();
	virtual void CustomizeProject(IBuildProject* pProject);
};

// This declares the one instance of the CCOMStressTestAppWizardAppWiz class.  You can access
//  m_Dictionary and any other public members of this class through the
//  global COMStressTestAppWizardaw.  (Its definition is in COMStressTestAppWizardaw.cpp.)
extern CCOMStressTestAppWizardAppWiz COMStressTestAppWizardaw;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMSTRESSTESTAPPWIZARDAW_H__EDE6A3BE_B668_11D3_A692_0080C752EC9F__INCLUDED_)
