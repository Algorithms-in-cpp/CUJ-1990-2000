//***********************************************************************************************************************************************
// * Copyright � 1999-2000Healtheon|WebMD Corp. 
// *
// * Permission is hereby granted, free of charge, to any person obtaining 
// * a copy of this software and associated documentation files (the "Software"), to deal in the
//  * Software without restriction, including without limitation the rights to use, copy, modify, 
// * merge, publish, distribute, sublicense, and/or sell copies of the 
// * Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
// *
// * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. 
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL Healtheon|WebMD Corp. BE LIABLE FOR ANY CLAIM, 
// * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH 
// * THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
// *
// * Except as contained in this notice, the name of Healtheon|WebMD Corp. shall not be used in advertising or otherwise to promote the sale, use or
// * other dealings in this Software without prior written authorization from Healtheon|WebMD Corp.. 
//***********************************************************************************************************************************************
#ifndef __HSTSTMAIN__
#define __HSTSTMAIN__

// The global state of the program
class HSMain : public HSApp {
public:
    CCstringArg  m_app_name;
    CIntArg      m_repeatCount;
    CIntArg      m_aptThreads;
    CIntArg      m_freeThreads;
    CToggleArg   m_regression;
    CIntArg      m_verbose;
	CIntArg      m_seed;

    HSMain();
};

extern HSMain      *hsMain;

//-----------------------------------------------------------------------

// This class should be subclassesed by the user of the framework
// and an object should be instantiated and assigned to the
// g_objDriver variable
class HSTSTDriver {
public:
    // Called before creating the threads
    virtual HRESULT OnBeforeStartThreads() {return S_OK;};

    // Called after the threads have been created
    virtual HRESULT OnAfterStartThreads()  {return S_OK;};

    // Called before the driver exits
    virtual HRESULT OnAfterThreadsExited() {return S_OK;};
    
    // Called at every loop
    virtual HRESULT FreeThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator*) {return S_OK;};
    virtual HRESULT AptThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator*) {return S_OK;};

	long m_numOfFreeThreads, m_numOfAptThreads;
	long m_numOfIterations;
};

extern HSTSTDriver* g_objDriver;

#endif


