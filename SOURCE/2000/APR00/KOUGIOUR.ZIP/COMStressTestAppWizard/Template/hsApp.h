//***********************************************************************************************************************************************
// * Copyright � 1999-2000Healtheon|WebMD Corp. 
// *
// * Permission is hereby granted, free of charge, to any person obtaining 
// * a copy of this software and associated documentation files (the "Software"), to deal in the
//  * Software without restriction, including without limitation the rights to use, copy, modify, 
// * merge, publish, distribute, sublicense, and/or sell copies of the 
// * Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
// *
// * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. 
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL Healtheon|WebMD Corp. BE LIABLE FOR ANY CLAIM, 
// * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH 
// * THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
// *
// * Except as contained in this notice, the name of Healtheon|WebMD Corp. shall not be used in advertising or otherwise to promote the sale, use or
// * other dealings in this Software without prior written authorization from Healtheon|WebMD Corp.. 
//***********************************************************************************************************************************************

#ifndef __HSAPP_H_
#define __HSAPP_H_

#define HSWIN32COREEXPORT


// These headers are coming from stdafx.h when the library is built
#include <iostream.h>
#include <string>
#include <vector>
#include <assert.h>
// Global definitions used by the whole app should go here


class HSWIN32COREEXPORT HSApp {
  public:
    // These are const values that can be ored together
    typedef long flags; 
    static flags fl_null; 
    static flags fl_req;      // required
    static flags fl_arg;      // argument
    static flags fl_option;      // option (default)
    static flags fl_array;    // an array of the same type
    static flags fl_multiple;     //  can be used multiple times, 
                                 // first time counts

    enum {IgnoreUnknownOptions = 1,
	  IgnoreUnknownArgs = 2};
    HSApp(int a_flags = 0);

    // An abstract superclass, parent of all the argument classes
    class  HSWIN32COREEXPORT CArg {
      public:
	
	//............................
	CArg(HSApp* a_application,
	     char* a_name,  
	     char* a_message, 
	     char* a_environment_variable,
	     flags a_flags 
	     ) ;
	// ................................

	void print_usage(ostream& str);
    
        // ................................

	void print_usage_extended(ostream& str);
	//...............................................

	int is_required()  const {return m_flags & fl_req;};

	int is_option()    const {return !(m_flags & fl_arg);};

	int is_argument()  const {return m_flags & fl_arg;};

	int is_array() const {return m_flags & fl_array;};

	const char* name() const {return m_name;};

	// Member functions to be redefined by subclasses

	// All but bool (where merely the appearence of the flag
	// signifies the existence) return 1;
	virtual int has_length() const {return 1;};


	// Subclasses must redefine these
	virtual void set_value_from_lexeme(char* lexeme, int i) = 0;

	virtual void add_value_from_lexeme(char* lexeme) = 0;

	virtual const char* type() = 0;

	virtual void print(ostream& str) = 0;


    protected:
	int is_used() const {return m_flags & fl_used;};

	char*       m_name;
	char*       m_message;
	flags       m_flags;
	char*       m_env_variable;

	friend class HSApp;
	
    };

    //.........................................................

    template <class T>
    class HSWIN32COREEXPORT CArgTemplate  : public CArg {
    public:
	CArgTemplate(HSApp* a_application,
		   char* a_name,  
		   char* a_message,
		   T a_default_value,
		   char* a_environment_variable,
		   flags a_flags = 0
		   ) : CArg(a_application, a_name, a_message, a_environment_variable, a_flags) 
	{
	    m_default_value = a_default_value;
            if (a_default_value != NULL)
	        m_value.push_back(a_default_value);
	};

	void set(T c) {m_value.push_back(c);};
	T get_value(long index = 0) {return m_value[index];};
	T operator()() {return m_value[0];};

        // For array arguments
        long size() {return m_value.size();}
        T operator[](int index) {return m_value[index];}

	virtual void print(ostream& str) {
	    if (m_value.size() > 0) str << m_value[0];
	}

	void add_value_from_lexeme(char* lexeme)  {
	    if (is_used()) {
		m_value.push_back(m_default_value);
		set_value_from_lexeme(lexeme, m_value.size() - 1);
	    } else {
		set_value_from_lexeme(lexeme, 0);
	    }
	};
	    

	protected:
	    friend class HSApp;
	    std::vector<T> m_value;
	    T m_default_value;
    };

    //.........................................................

    class  CCharArg : public  CArgTemplate<char> {
    public:
	CCharArg(HSApp* a_application,
	         char* a_name,  
	         char* a_message,
		 char  a_default_value = ' ',
		 flags a_flags = 0,
	         char* a_environment_variable = NULL
		 ) : CArgTemplate<char>(a_application, a_name, a_message, a_default_value, a_environment_variable, a_flags) 
	{
	}

	void set_value_from_lexeme(char* lexeme, int i)  {m_value[i] = lexeme[0];};

	const char* type() {return "<char>";};
    };

    //.........................................................

    class  CCstringArg : public CArgTemplate<char*> {
    public:
	CCstringArg(HSApp* a_application,
		    char* a_name,  
		    char* a_message, 
		    char* a_default_value = "",
		    flags a_flags = 0,
		    char* a_environment_variable = NULL
		 ) : CArgTemplate<char*>(a_application, a_name, a_message,  a_default_value, a_environment_variable, a_flags) 
	{
	    
	}
	void set_value_from_lexeme(char* lexeme, int i) {m_value.resize(i + 1); m_value[i] = lexeme;};

	const char* type() {return "<string>";};
    };
    //.........................................................
    class  CIntArg : public CArgTemplate<int> {
      public:
	CIntArg(HSApp* a_application,
	         char* a_name,  
	         char* a_message,
		 int   a_default_value = 0,
		 flags a_flags = 0,
		
	         char* a_environment_variable = NULL
		 ) : CArgTemplate<int>(a_application, a_name, a_message, a_default_value, a_environment_variable, a_flags) 
	{
	    if (a_default_value ==  0)
	        m_value.push_back(a_default_value);
	}

	virtual void set_value_from_lexeme(char* lexeme, int i) 
        {
	    m_value[i] = atoi(lexeme);
	};

	virtual const char* type() {return "<integer>";};	
    };

    //........................................................
    
    // This can be only an option, it signifies all these options
    // that merely the existense or not set a value
    // e.g. ls -l
    class  CToggleArg : public CArgTemplate<bool> {
    public:
	CToggleArg(HSApp* a_application,
		   char* a_name,  
		   char* a_message,
		   bool   a_default_value = false,
		   flags a_flags = 0,
	         char* a_environment_variable = NULL
		 ) : CArgTemplate<bool>(a_application, a_name, a_message, a_default_value, a_environment_variable, a_flags) 
	{
	    assert(!(a_flags & fl_req));
            if (a_default_value == false)
	        m_value.push_back(a_default_value);
	    
	}

	virtual void set_value_from_lexeme(char* lexeme, int i) 
        {
	    m_value[i] = !m_value[i];
	};

	virtual const char* type() {return "<bool>";};

	void print(ostream& str) {
	    if (m_value[0]) {
		str << "on";
	    } else {
	        str << "off";
	    }
	}
        
        virtual int has_length() const {return 0;};
    };

    //----------------------------------------------------------------
    

    //...............................

    void add(CArg* arg);

    //...............................
 
    void parse(int argc, 
	       char** argv)
    {
	m_argc       = argc;
	m_argv       = argv;
	
	set_env_values();
	parse_internal();
    }

    //...............................


    void print_usage_and_exit(const char*, int code = -1);

    //..................................
    void fatal(char* str, int code = -1) {
	cerr << str << endl;
	_exit(code);
    }

protected:

    void parse_argument();

    void parse_internal();

    void parse_flags();

    void set_env_values();

    // Data members
    int     m_argc;
    char**  m_argv;
    CArg**  m_args; 
    int     m_args_index; 
    int     m_args_max_index;
    int     m_flags;

    static flags fl_used;

    friend class HSApp::CArg;
};

HSWIN32COREEXPORT ostream& operator<<(ostream&, HSApp::CArg*);

#endif
