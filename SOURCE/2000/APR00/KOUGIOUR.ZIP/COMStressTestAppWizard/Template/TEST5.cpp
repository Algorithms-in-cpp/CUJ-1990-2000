#include "stdafx.h"

class C$$ROOT$$ : public HSTSTDriver {
public:    
    //------------------------------------------------------------------
    
	// Called at every loop
    virtual HRESULT FreeThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator* objRnd) {
       
		// **** Add your code here

		return S_OK;
    }
    
    //------------------------------------------------------------------
    // Called at every loop
	virtual HRESULT AptThreadTest(int iIterationCounter, DWORD nThreadId, CRandomGenerator* objRnd)  {
  
		// **** Add your code here

          return S_OK;
    }
    
    //-------------------------------------------------------------------
    // Called before creating the threads
    virtual HRESULT OnBeforeStartThreads() {
        
		// **** Add your code here

        return S_OK;
    };

	//-------------------------------------------------------------------
	// Called after the threads have been created
    virtual HRESULT OnAfterStartThreads()  {

		// **** Add your code here

		return S_OK;
	};
    
    //-------------------------------------------------------------------
     // Called before the driver exits
    HRESULT OnAfterThreadsExited() {
   
		// **** Add your code here
        
        return S_OK;
    }
};

HSTSTDriver* g_objDriver = new C$$ROOT$$;


//----------------------------------------------------------------------


