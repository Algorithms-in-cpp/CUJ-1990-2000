//***********************************************************************************************************************************************
// * Copyright � 1999-2000Healtheon|WebMD Corp. 
// *
// * Permission is hereby granted, free of charge, to any person obtaining 
// * a copy of this software and associated documentation files (the "Software"), to deal in the
//  * Software without restriction, including without limitation the rights to use, copy, modify, 
// * merge, publish, distribute, sublicense, and/or sell copies of the 
// * Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
// *
// * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. 
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL Healtheon|WebMD Corp. BE LIABLE FOR ANY CLAIM, 
// * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH 
// * THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
// *
// * Except as contained in this notice, the name of Healtheon|WebMD Corp. shall not be used in advertising or otherwise to promote the sale, use or
// * other dealings in this Software without prior written authorization from Healtheon|WebMD Corp.. 
//***********************************************************************************************************************************************


// RandomGenerator.h: interface for the CRandomGenerator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RANDOMGENERATOR_H__6218B338_132E_11D3_A654_000000000000__INCLUDED_)
#define AFX_RANDOMGENERATOR_H__6218B338_132E_11D3_A654_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRandomGenerator  
{
public:
    void init(int seed = -1); // if -1 one is generated
    
    // return a random printable character
    char GetRandomChar(char start, char end);
    
    // return a random int in the [min, max] range
    int GetRandomInt(int min, int max);
    
    // returns a random string with length in the [minLen, maxLen] range
    CComBSTR GetComBSTR(int minLen, int maxLen, char start = 33, char end = 126);
    
    // Generates and gets the next random number
    unsigned GenerateNext();
    
    CRandomGenerator(int seed = -1);
    virtual ~CRandomGenerator();

    unsigned seed();


private:
    CComAutoCriticalSection m_lock;
    unsigned long m_X;
    unsigned long m_seed; //set only once at the beginning 
    
};

#endif // !defined(AFX_RANDOMGENERATOR_H__6218B338_132E_11D3_A654_000000000000__INCLUDED_)
