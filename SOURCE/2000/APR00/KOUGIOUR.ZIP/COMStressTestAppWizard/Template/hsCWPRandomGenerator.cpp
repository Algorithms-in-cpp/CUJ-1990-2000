//***********************************************************************************************************************************************
// * Copyright � 1999-2000Healtheon|WebMD Corp. 
// *
// * Permission is hereby granted, free of charge, to any person obtaining 
// * a copy of this software and associated documentation files (the "Software"), to deal in the
//  * Software without restriction, including without limitation the rights to use, copy, modify, 
// * merge, publish, distribute, sublicense, and/or sell copies of the 
// * Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
// *
// * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. 
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL Healtheon|WebMD Corp. BE LIABLE FOR ANY CLAIM, 
// * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH 
// * THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
// *
// * Except as contained in this notice, the name of Healtheon|WebMD Corp. shall not be used in advertising or otherwise to promote the sale, use or
// * other dealings in this Software without prior written authorization from Healtheon|WebMD Corp.. 
//***********************************************************************************************************************************************
// RandomGenerator.cpp: implementation of the CRandomGenerator class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <hsCWPRandomGenerator.h>
#include <hsCWPComAutoCSGrabber.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const unsigned long m =  2147483647; // 2 ^ 31 -1
const unsigned long a = 314159269; // see Knuth's "Seminumerical algotithms" p. 102 and p. 170
const unsigned long c = 1;

CRandomGenerator::CRandomGenerator(int seed)
{
    init(seed);
}

CRandomGenerator::~CRandomGenerator()
{
}

void CRandomGenerator::init(int seed)
{
    if (seed != -1) {
        m_X = m_seed = seed;
        return;
    }

    LARGE_INTEGER li;
    if (QueryPerformanceCounter(&li) == 0) {
        m_seed = m_X = (unsigned)GetTickCount() + GetCurrentProcessId() * GetCurrentThreadId();
    } else {
        LARGE_INTEGER liPerf;
        QueryPerformanceFrequency(&liPerf);

        m_seed = m_X = li.LowPart % liPerf.LowPart; 
    }
}

unsigned 
CRandomGenerator::seed()
{
    return m_seed;
}

unsigned CRandomGenerator::GenerateNext()
{
    HSCWPComAutoCSGrabber grabAndRelease(&m_lock);
    __int64 X = m_X;
    X *= a;
    X += c;
    X = X % m;
    m_X = X;

    return m_X;
}

CComBSTR CRandomGenerator::GetComBSTR(int minLen, int maxLen, char start, char end)
{
    CComBSTR ret;
    int len = GetRandomInt(minLen, maxLen);
    char lpszBuffer[1000];
    for (int i = 0; i < len; i++) {
        lpszBuffer[i] = GetRandomChar(start, end);
    }
    lpszBuffer[len] = '\0';
    
    ret = lpszBuffer;

    ATLTRACE("RANDOM %s\n", lpszBuffer);
    
    return ret;
}

int CRandomGenerator::GetRandomInt(int min, int max)
{
    unsigned  val = GenerateNext();
    ATLTRACE("%d \n", val);
    double dtmp = ((double)val / (double)m);
    dtmp *= (double)(max - min + 1);
    int ret = (int)dtmp;
    assert((dtmp >= ret) && (ret + 1 > dtmp));

    ret += min;
    assert(ret >= min);
    assert(ret <= max);
    return ret;
}

char CRandomGenerator::GetRandomChar(char start, char end)
{
    return GetRandomInt(start, end);
}
