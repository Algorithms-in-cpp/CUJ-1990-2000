#include "stdafx.h"

#include <hsapp.cpp>
#include <hsCWPRandomGenerator.cpp>
#include <hsTSTMain.cpp>
