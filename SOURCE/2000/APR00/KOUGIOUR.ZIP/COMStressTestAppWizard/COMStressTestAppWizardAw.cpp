// COMStressTestAppWizardaw.cpp : implementation file
//

#include "stdafx.h"
#include "COMStressTestAppWizard.h"
#include "COMStressTestAppWizardaw.h"
#include <objmodel/bldguid.h>

#ifdef _PSEUDO_DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// This is called immediately after the custom AppWizard is loaded.  Initialize
//  the state of the custom AppWizard here.
void CCOMStressTestAppWizardAppWiz::InitCustomAppWiz()
{
	// There are no steps in this custom AppWizard.
	SetNumberOfSteps(0);

	// Add build step to .hpj if there is one
	m_Dictionary[_T("HELP")] = _T("1");

	// TODO: Add any other custom AppWizard-wide initialization here.
}

// This is called just before the custom AppWizard is unloaded.
void CCOMStressTestAppWizardAppWiz::ExitCustomAppWiz()
{
	// TODO: Add code here to deallocate resources used by the custom AppWizard
}

// This is called when the user clicks "Create..." on the New Project dialog
CAppWizStepDlg* CCOMStressTestAppWizardAppWiz::Next(CAppWizStepDlg* pDlg)
{
	ASSERT(pDlg == NULL);	// By default, this custom AppWizard has no steps

	// Set template macros based on the project name entered by the user.

	// Get value of $$root$$ (already set by AppWizard)
	CString strRoot;
	m_Dictionary.Lookup(_T("root"), strRoot);
	
	// Set value of $$Doc$$, $$DOC$$
	CString strDoc = strRoot.Left(6);
	m_Dictionary[_T("Doc")] = strDoc;
	strDoc.MakeUpper();
	m_Dictionary[_T("DOC")] = strDoc;

	// Set value of $$MAC_TYPE$$
	strRoot = strRoot.Left(4);
	int nLen = strRoot.GetLength();
	if (strRoot.GetLength() < 4)
	{
		CString strPad(_T(' '), 4 - nLen);
		strRoot += strPad;
	}
	strRoot.MakeUpper();
	m_Dictionary[_T("MAC_TYPE")] = strRoot;

	// Return NULL to indicate there are no more steps.  (In this case, there are
	//  no steps at all.)
	return NULL;
}

void CCOMStressTestAppWizardAppWiz::CustomizeProject(IBuildProject* pProject)
{ 
	
	IConfigurations* pConfigs = NULL; 
	
	pProject->get_Configurations(&pConfigs); 
	
	ASSERT(pConfigs); 
	
	CComPtr<IUnknown> pUnk; 
	
	CComQIPtr<IEnumVARIANT, &IID_IEnumVARIANT> pNewEnum; 
	
	if (SUCCEEDED(pConfigs->get__NewEnum(&pUnk)) && pUnk != NULL) 
		
	{ 
		USES_CONVERSION;
		pNewEnum = pUnk; 
		
		VARIANT varConfig; 
		
		CComQIPtr<IConfiguration, &IID_IConfiguration> pConfig; 
		
		while (pNewEnum->Next(1, &varConfig, NULL) == S_OK) 
			
		{ 
			
			ASSERT (varConfig.vt == VT_DISPATCH); 
			
			pConfig = varConfig.pdispVal; 
			
			VariantClear(&varConfig); 
			
			VARIANT reserved; 

			//Debug vs. release
			CComBSTR bstrName; 
			pConfig->get_Name(&bstrName); 
			BOOL bDebug = (BOOL) _tcsstr(OLE2T(bstrName), _T("Debug"));
			
			
			// Remove old output name (DLL) 
			
			// The subsytem should not be windows
			CComBSTR bstrTool = "link.exe"; 
			CComBSTR bstrOption = "/subsystem:"; 
			pConfig->RemoveToolSettings(bstrTool, bstrOption, reserved); 

			// Set the subsytem to console
			bstrOption += "console"; 			
			pConfig->AddToolSettings(bstrTool, bstrOption, reserved); 

			// Remove windows.obj
			bstrOption = "windows";
			pConfig->RemoveToolSettings(bstrTool, bstrOption, reserved); 

			// Remove mfc dependency
			bstrTool = "mfc";
			bstrOption = "0";
			pConfig->AddToolSettings(bstrTool,  bstrOption, reserved);

			// Remove _WINDOWS
			bstrTool = "cl.exe";
			bstrOption = "/D \"_WINDOWS\"";
			pConfig->RemoveToolSettings(bstrTool, bstrOption, reserved);

			// Add _CONSOLE
			bstrOption = "/D \"_CONSOLE\"";
			pConfig->AddToolSettings(bstrTool, bstrOption, reserved);

			// Add the core dir
			bstrOption  = "/I core";
			pConfig->AddToolSettings(bstrTool, bstrOption, reserved);

			// Add the _MT 
			bstrOption = "/D \"_MT\"";
			pConfig->AddToolSettings(bstrTool, bstrOption, reserved);

			// add the /MT switch
			if (bDebug) {
				bstrOption = "/MTd";
			} else {
				bstrOption = "/MT";
			}
			pConfig->AddToolSettings(bstrTool, bstrOption, reserved);
		} 
		
	} 

}


// Here we define one instance of the CCOMStressTestAppWizardAppWiz class.  You can access
//  m_Dictionary and any other public members of this class through the
//  global COMStressTestAppWizardaw.
CCOMStressTestAppWizardAppWiz COMStressTestAppWizardaw;

