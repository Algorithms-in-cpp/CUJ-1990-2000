#if !defined(AFX_STDAFX_H__EDE6A3BC_B668_11D3_A692_0080C752EC9F__INCLUDED_)
#define AFX_STDAFX_H__EDE6A3BC_B668_11D3_A692_0080C752EC9F__INCLUDED_

// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxcmn.h>			// MFC support for Windows 95 Common Controls
#include "debug.h"			// For ASSERT, VERIFY, and TRACE
#include <customaw.h>		// Custom AppWizard interface

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#include <objbase.h>
#include <atlbase.h>
#endif // !defined(AFX_STDAFX_H__EDE6A3BC_B668_11D3_A692_0080C752EC9F__INCLUDED_)
