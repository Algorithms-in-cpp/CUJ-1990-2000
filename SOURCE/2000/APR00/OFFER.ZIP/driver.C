//
// Listing 3. Driver program for testing Errstream class
//
#include "Errstream.h"

void displayErrMsg(const char *msg)
{
    cerr << "ERROR: " << msg << endl;
}

void main()
{
    errout.setDisplay(displayErrMsg);

    int i, d = 100;
    char *cStr = "string";
    double f = 123.456;

    errout << "character string: " << cStr << dspl;
    errout << "integer:          " << d    << dspl;
    errout << "floating point:   " << f    << dspl;

    errout.open("newErrorLog");

    errout << logOnly
           << "The user doesn't need to see this message"
           << dspl;

    for(i = 0; i < 5; i++)
        errout << "This message only gets logged once" << dspl;
    errout.collect(false);
    for(i = 0; i < 5; i++)
        errout << "This message gets logged every time" << dspl;
    errout.collect(true);

    for(i = 0; i < 5; i++)
    {
        errout << "Encountered error #";
        switch(i)
        {
            case 0:
                errout << differentiate(1) << i;  break;
            case 1:
                errout << differentiate(2) << i;  break;
            default:
                errout << differentiate(3) << i;  break;
        }
        errout << " inside a loop" << dspl;
    }
}
