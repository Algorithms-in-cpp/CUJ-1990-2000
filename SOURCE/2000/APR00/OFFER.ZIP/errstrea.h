//
// Listing 1. Definition of Errstream class
//
#ifndef __ERRSTREAM__
#define __ERRSTREAM__

#include <sys/param.h>
#include <fstream>
#include <string>

#define MAX_STR_SIZE 1024
#define DEFAULT_ERROR_FILE "./errorLog"

#define dspl setDebugFile(__FILE__) << setDebugLine(__LINE__) \
        << Errstream::displayError

class Errstream : public ofstream
{
  public:
    Errstream();
    Errstream(const char* name);
   ~Errstream();

    void setDisplay(void (*f)(const char *))
                                    { _displayImpl = f; }
    void open(const char *name);
    const char *errString() const   { return _str; }
    void clear()                    { _str[0] = '\0'; }
    void line(int l)                { _line = l; }
    int  line() const               { return _line; }
    void file(const std::string &f) { _file = f; }
    std::string file() const        { return _file; }
    void logOnly(bool l)            { _logOnly = l; }
    bool logOnly() const            { return _logOnly; }
    void collect(bool set);
    bool collect() const            { return _collect; }
    void diffLevel(int d)           { _diffLevel = d; }
    int  diffLevel() const          { return _diffLevel; }

    static Errstream &displayError(Errstream &stream);

    Errstream &operator<<(const char *);
    Errstream &operator<<(int);
    Errstream &operator<<(double);
    Errstream &operator<<(Errstream& (*f)(Errstream&))
        { return (*f)(*this); }

  private:
    int         _line, _collectLine;
    std::string _file, _collectFile;
    int         _diffLevel, _collectDiffLevel;
    u_int       _numMultiples;
    bool        _collect, _logOnly, _logOpen;
    char        _logFile[MAXPATHLEN];
    char        _str[MAX_STR_SIZE + 1];

    static void (*_displayImpl)(const char *msg);

    void _openLogFile();
    bool _collectMultipleMsgs();
    void _writeMultiples();
    void _writeDebugInfo();
    void _concatenate(const char *buf, int len=MAX_STR_SIZE);
    bool _okayToWriteToLog();

    Errstream(const Errstream &);
    Errstream &operator=(const Errstream &);
};

extern Errstream errout;

class EMANIP_int
{
    Errstream& (*fct)(Errstream&, int);
    int arg;
  public:
    EMANIP_int(Errstream& (*f)(Errstream&, int), int a)
        : fct(f), arg(a) {}
    friend Errstream& operator<<(Errstream& s,
                                 const EMANIP_int& m)
        { return(m.fct)(s, m.arg); }
};

class EMANIP_string
{
    Errstream& (*fct)(Errstream&, const std::string &);
    std::string arg;
  public:
    EMANIP_string(Errstream& (*f)(Errstream&, const std::string &),
                  const std::string &a) : fct(f), arg(a) {}
    friend Errstream& operator<<(Errstream& s,
                                 const EMANIP_string& m)
        { return(m.fct)(s, m.arg); }
};

Errstream &endl(Errstream &stream);
Errstream &logOnly(Errstream &stream);
EMANIP_int differentiate(int d);
EMANIP_int setDebugLine(int l);
EMANIP_string setDebugFile(const std::string &f);

#endif // __ERRSTREAM__
