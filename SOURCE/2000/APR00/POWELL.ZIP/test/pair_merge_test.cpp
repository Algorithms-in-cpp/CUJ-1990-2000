/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "pair_merge_view.h"
#include "equal_range_view.h"

#include <cstdlib>
#include <deque>
#include <iostream>
#include <functional>

#include "stl_fix.h"

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::deque;
using std::advance;

USING_VIEW_NAMESPACE


typedef equal_range_view< deque<int>, equal_to<int>, const_view_tag, forward_iterator_tag > er_vview;
typedef equal_range_view< deque<int>, equal_to<int>, const_view_tag >rer_vview;

typedef equal_range_view< deque<int>, equal_to<int>, mutable_view_tag >mer_vview;

typedef pair_merge_view<er_vview, er_vview > pairmergVecVec_view;

typedef pair_merge_view<rer_vview, rer_vview,
							// the next line is actually std::less<int> -g-
							std::less<dereference_traits<rer_vview::value_type::value_type>::type>,
							const_view_tag > pairmergVecVec_rview;

typedef pair_merge_view<mer_vview, mer_vview,
							// the next line is actually std::less<int> -g-
							std::less<dereference_traits<mer_vview::value_type::value_type>::type>,
							mutable_view_tag > mpairmergVecVec_rview;


namespace {

using std::ostream;
using std::copy;

ostream& operator<<(ostream& out, er_vview::const_iterator::const_reference const& p) {
  out << "(";
  copy(p.begin(),p.end(),ostream_iterator<int>(out," "));
  return out << ") ";
}


ostream& operator<<(ostream& os, er_vview::const_iterator const & p) {
  os << *p;
  return os;
}

ostream& operator<<(ostream& os, rer_vview::const_iterator const & p) {
  os << *p;
  return os;
}


ostream& operator<<(ostream& os, rer_vview::const_reverse_iterator const & p) {
  os << *p;
  return os;
}

template <class A, class B>
ostream& operator<<(ostream& out, pair<A,B> const& p) {
  return out << "(" << p.first << "," << p.second << ")";
}

};

int main()
{
  deque<int> x(9), y(9);
  for (int i = 0; i < 9; ++i)
  {
     x[i] = 2 * i;
     y[i] = x[i] + 1;
  }


  er_vview x_er(x);
  er_vview y_er(y);

  pairmergVecVec_view	mview(x_er, y_er);
  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);

  cout << "Pair Merge Test: you should see the ordered pairs numbers 0 -> 17:" << endl;
  dump(cout, mview);

  rer_vview rx_er(x);
  rer_vview ry_er(y);

  pairmergVecVec_rview mrview(ry_er, rx_er);
  cout << "Reverse :" << endl;
  rdump(cout, mrview);

  //iterator tests
  forward_test(mrview);
  const_forward_test(mrview);
  reverse_test(mrview);
  const_reverse_test(mrview);

  // mutable test.
  mer_vview mx_er(x);
  mer_vview my_er(y);
  mpairmergVecVec_rview m_mview(my_er, mx_er);
 
  forward_test(m_mview);
  const_forward_test(m_mview);
  reverse_test(m_mview);
  const_reverse_test(m_mview);

  pairmergVecVec_rview::const_reverse_iterator mrv_iter = mrview.rbegin();
  advance(mrv_iter, 16);
  cout << *mrv_iter << endl;
  ++mrv_iter;
  cout << *mrv_iter << endl;

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

