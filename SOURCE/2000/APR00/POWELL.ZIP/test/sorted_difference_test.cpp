/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "sorted_difference_view.h"

#include <cstdlib>
#include <map>
#include <vector>
#include <iostream>
#include <numeric>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::map;
using std::iota;
using std::advance;

USING_VIEW_NAMESPACE

namespace {

using std::ostream;

template <class A, class B>
ostream& operator<<(ostream& out, pair<A,B> const& p) {
  return out << "(" << p.first << "," << p.second << ")";
}

};



int main()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef sorted_difference_view<vector<int>, vector<int> > diff_view;

  diff_view	dxview(x, y);
  diff_view	dyview(y, x);

   cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);
  cout << "Sorted Difference Test: you should see x less the numbers 3, 4:" << endl;
  dump(cout, dxview);

  cout << "Sorted Difference Test: you should see y less the numbers 3, 4:" << endl;
  dump(cout, dyview);

  // iterator category test.
  diff_view::iterator iter_vv(dxview.begin() );
  advance(iter_vv, 2);

  typedef sorted_difference_view<vector<int>, vector<int>,
		std::less<int> > diff_rview;
  diff_rview dxrview(x, y);
  diff_rview dyrview(y, x);

  forward_test<diff_rview>(dxrview);
  const_forward_test<diff_rview>(dxrview);
  reverse_test<diff_rview>(dxrview);
  const_reverse_test<diff_rview>(dxrview);

  cout << "Sorted Difference Test: you should see reverse x less the numbers 3, 4:" << endl;
  rdump(cout, dxrview);

  cout << "Sorted Difference Test: you should see reverse y less the numbers 3, 4:" << endl;
  rdump(cout, dyrview);

  map<int,int> mx, my;
  for (int i=0; i<15; ++i) {
    mx[i] = (i*i)%3;
    my[i+2] = (7*i)%5;
  }

  typedef sorted_difference_view< map<int,int>, map<int,int> > diffMap_view;
  diffMap_view dmview(mx,my);

  cout << "Sorted Difference set Test:" << endl;
  dump(cout,mx);
  dump(cout,my);
  cout << "-> ";
  dump(cout,dmview);

  // iterator category test.
  diffMap_view::iterator iter_mvv(dmview.begin() );
  advance(iter_mvv, 2);

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

