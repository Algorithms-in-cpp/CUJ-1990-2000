/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "downcast_view.h"

#include <cstdlib>
#include <deque>
#include <iostream>
#include <algorithm>

#include "dump.h"
#include "iterator_test.h"
#include "stl_fix.h"

using std::cout;
using std::cin;
using std::endl;
using std::ostream;
using std::for_each;
using std::deque;
using std::advance;

USING_VIEW_NAMESPACE

namespace {
//
// Classes for testing polymorphic containers.
//
struct V {
  int i;
  V(int x) : i(x) {}
  virtual void print() const { cout << "V = " << i; }

  V &operator=(int x) { i = x; return *this; }
};
struct T: public V {
	T(int x) : V(x) {}
  virtual void print() const { cout << "T = " << i; }

  T &operator=(int x) { V::operator=(x); return *this; }
};

struct L: public T {
	L(int x) : T(x) {}
  virtual void print() const { cout << "L = " << i; }

  L &operator=(int x) { T::operator=(x); return *this; }
};

ostream &operator<<(ostream &os, struct V const& v)
{
	v.print();
    return os;
}

// phoney comparison operators. 
bool operator==(V const &lhs, V const &rhs)
{
	return (&lhs == &rhs);	// compare addresses for now.
}

bool operator<(V const &lhs, V const &rhs)
{
	return (&lhs < &rhs);	// compare addresses for now.
}

};

int main()
{
  typedef deque<V*> container_t;
  container_t cvb;
  cvb.push_back(new L(1));
  cvb.push_back(new T(2));
  cvb.push_back(new V(3));

  typedef downcast_view< container_t, T > dcview;
  typedef downcast_view< container_t, T, mutable_view_tag > mdcview;
  dcview cv(cvb);


  cout << "printing of the (T) elements in the downcast view" << endl;
  for_each(cv.begin(),cv.end(),mem_fun_ref(&V::print));
  cout << endl;

  forward_test(cv);
  const_forward_test(cv);

  // iterator category test.
  dcview::iterator f_iter(cv.begin() );
  advance(f_iter, 2);
  
  typedef downcast_view< container_t, T> rdcview;	// bidirectional
  typedef downcast_view< container_t, T, mutable_view_tag> mrdcview;	// bidirectional
  rdcview rcv(cvb);
  cout << "reverse printing of the (T) elements in the downcast view" << endl;
  for_each(rcv.rbegin(),rcv.rend(),mem_fun_ref(&V::print));
  cout << endl;

  forward_test(rcv);
  const_forward_test(rcv);
  reverse_test(rcv);
  const_reverse_test(rcv);

  mdcview mcv(cvb), mcv2;

  forward_test(mcv);
  const_forward_test(mcv);

  mcv2 = mcv;
  swap(mcv2, mcv);
  assert(mcv2 == mcv);
  assert(!(mcv2 != mcv));

  mrdcview mrcv(cvb);

  forward_test(mrcv);
  const_forward_test(mrcv);
  reverse_test(mrcv);
  const_reverse_test(mrcv);

  *(mcv.begin()) = 5;
  cout << *(mcv.begin()) << endl;

  delete cvb[0];
  delete cvb[1];
  delete cvb[2];

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

