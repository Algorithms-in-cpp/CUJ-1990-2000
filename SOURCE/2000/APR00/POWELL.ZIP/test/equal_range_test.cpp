/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "equal_range_view.h"
#include "functors.h"

#include <cstdlib>
#include <vector>
#include <iostream>
#include <algorithm>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::advance;

USING_VIEW_NAMESPACE

typedef equal_range_view< vector<int> > erv;
typedef equal_range_view< vector<int>, equal_to<int>, mutable_view_tag, forward_iterator_tag > m_erv;
typedef equal_range_view< vector<int>, equal_to<int>, mutable_view_tag > rerv;

namespace {

using std::ostream;
using std::copy;

ostream& operator<<(ostream& out, erv::const_iterator::const_reference& p) {
  out << "(";
  copy(p.begin(),p.end(),ostream_iterator<int>(out," "));
  return out << ") ";
}


ostream& operator<<(ostream& os, erv::const_iterator const & p) {
  os << *p;
  return os;
}


ostream& operator<<(ostream& os, rerv::const_reverse_iterator const & p) {
  os << *p;
  return os;
}

};

int main()
{
  cout << ">>>> Equal Range View Test <<<<" << endl;
  
  vector<int> x(30);
  for (unsigned i=0; i<30; ++i)
    x[i] = rand()%6;
  
  vector<int> y(10);
  for (unsigned i=0; i<10; ++i)
    y[i] = rand()%6;

  erv v(x);
  erv v2(y);
  erv v3(x);

  cout << "The container itself:" << endl;
  dump(cout,x);
  cout << "The equal ranges view:" << endl;
  dump(cout,v);

  const_forward_test(v);

  swap(v2,v3);

  m_erv mv(x);
  forward_test(mv);

  rerv vr(x);
  cout << "The reverse equal ranges view:" << endl;
  rdump(cout,vr);

  forward_test(vr);
  const_forward_test(vr);
  reverse_test(vr);
  const_reverse_test(vr);

  cout << "The size of the view: " << v.size() << endl << endl;

  sort(x.begin(),x.end());
  cout << "Sorted the container:" << endl;
  dump(cout,x);
  cout << "The equal ranges view now:" << endl;
  dump(cout,v);
  cout << "The reverse equal ranges view:" << endl;
  rdump(cout,vr);
  cout << "The size of the view: " << v.size() << endl;

  cout << "view == view? " << (v==v) << endl;
  cout << "view < view?  " << (v<v) << endl;

  // iterator tests
  {
	  vector<int> x(9), y(9);
	  for (int i = 0; i < 9; ++i)
	  {
		 x[i] = 2 * i;
		 y[i] = x[i] + 1;
	  }

	  typedef equal_range_view< vector<int> > const er_vview;
	  er_vview x_er(x);
	  er_vview y_er(y);

	  er_vview::const_iterator x_iter = x_er.begin();
	  er_vview::const_iterator y_iter = y_er.begin();

	  cout << *x_iter << " < " << *y_iter << " = " << (*(*x_iter).begin() < *(*y_iter).begin()) << endl;
	  ++x_iter;
	  cout << *x_iter << " < " << *y_iter << " = " << (*(*x_iter).begin() < *(*y_iter).begin()) << endl;
	  ++y_iter;
	  cout << *x_iter << " < " << *y_iter << " = " << (*(*x_iter).begin() < *(*y_iter).begin()) << endl;
	  advance(x_iter, 4);
	  cout << *x_iter << " < " << *y_iter << " = " << (*(*x_iter).begin() < *(*y_iter).begin()) << endl;

	  typedef equal_range_view< vector<int> > const rer_vview;
	  rer_vview rx_er(x);
	  rer_vview ry_er(y);

	  rer_vview::const_reverse_iterator xr_iter = rx_er.rend();
	  rer_vview::const_reverse_iterator yr_iter = ry_er.rend();
	  --xr_iter;
	  --yr_iter;
	  cout << *xr_iter  << " < " <<  *yr_iter << " = " << (*(*xr_iter).begin() < *(*yr_iter).begin()) << endl;
  }


  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

