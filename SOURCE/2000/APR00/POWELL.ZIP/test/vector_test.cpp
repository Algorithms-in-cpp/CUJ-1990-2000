/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "transform_view.h"
#include "filter_view.h"
#include "union_view.h"
#include "dump.h"
#include "iterator_test.h"

#include <cstdlib>
#include <vector>
#include <iostream>
#include <numeric>


using std::cout;
using std::endl;
using std::cin;
using std::vector;
using std::iota;
using std::ostream;
using std::advance;

USING_VIEW_NAMESPACE


class succ {
public:
  class result_type {
    friend class succ;
    int const& ref;
    explicit result_type(int const& cref): ref(cref) {}; // tricky
  public:
    explicit result_type(int& ref_): ref(ref_) {};
    operator int() const { return ref+1; }
    result_type& operator=(int x) { const_cast<int&>(ref) = x-1; return *this; }
  };
  
  typedef int argument_type;
  
  result_type       operator()(int& n)       const { return result_type(n); }
  result_type const operator()(int const& n) const { return result_type(n); }
};

class data {
private:
	int f;
public:  
  typedef int argument_type;
	data(int x = 0) : f(x) {}

	int & operator()(data &d) { return d.f; }
	int const & operator()(data const &d) const { return d.f; }

	data & operator=(int x) { f = x; return *this; }

	friend std::ostream & operator<<(std::ostream &os, data const & d)
	{ return os << d.f; }
};

//
// An odd filter: true for odd arguments
//
class odd {
public:
  bool operator()(int const &n) const {
    return n%2;
  }
};


//
// Vector test
//
int main()
{
  typedef transform_view<vector<int>,succ,mutable_view_tag> view_type;
  typedef filter_view<vector<int>,odd> view2_type;
  typedef union_view<vector<int>,vector<int> > union1_type;
  typedef union_view<view2_type,view2_type> union2_type;
  typedef union_view<view_type,view_type,const_view_tag > runion2_type;
  
  vector<int> x(4), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 0);

  view_type xview(x,succ());
  view_type yview(y,succ());
  view2_type xview2(x,odd());
  view2_type yview2(y,odd());

  cout << "Vector is filled with 0,1,2,3. You should see the" << endl
       << "contents of the successor view: 1,2,3,4:" << endl;
  dump(cout, xview);
  cout << "Random access to element 2 of the view yields "
       << xview[2] << ", should be 3." << endl << endl;

  {
  int j(0);
  for (view_type::iterator i=xview.begin(); i!=xview.end(); ++i, ++j)
    xview[j] = (*i) * (*i);
  }

  forward_test(xview);
  const_forward_test(xview);
  reverse_test(xview);
  const_reverse_test(xview);
  random_access_test(xview);
  const_random_access_test(xview);


  forward_test(xview2);
  const_forward_test(xview2);
  reverse_test(xview2);
  const_reverse_test(xview2);

  // transform iterator category test.
  view_type::iterator t_iter(xview.begin() );
  advance(t_iter, 2);

  // filter iterator category test.
  view2_type::iterator f_iter(xview2.begin() );
  advance(f_iter, 2);

  // Testing the conversion iterator -> const_iterator
  cout << "Squaring the view elements results in: " << endl;
  dump(cout, xview);

  cout << "The original container now contains: " << endl;
  dump(cout, x);

  cout << "Filtering test: you should see only the odd elements of the vector:" << endl;
  dump(cout, xview2);

  cout << "Swapping with successor view [0..8]:" << endl;
  //xview.swap(yview);

  swap(xview2, yview2);
  swap(xview,yview);
  dump(cout, xview);

  cout << "other view:" << endl;
  dump(cout, yview);


  cout << "Union of the original containers:" << endl;
  union1_type u1(x,y), u1b(y,x);
  dump(cout, u1);


  // union iterator category test.
  union1_type::iterator u_iter(u1.begin() );
  advance(u_iter, 2);

  cout << "Union of the views:" << endl;
  union2_type u2(xview2,yview2);
  dump(cout, u2);

  forward_test(u2);
  const_forward_test(u2);

  runion2_type u3(xview, yview);

  reverse_test(u3);
  const_reverse_test(u3);

  rdump(cout, u3);

  std::swap(u1, u1b);

  typedef transform_view<vector<data>,data,mutable_view_tag, int &> trans_view_type;

  vector<data> d(5);
  iota(d.begin(), d.end(), 0);
  trans_view_type dview(d,data() );

  dump(cout, d);
  dump(cout, dview);

  // Test that const_reference is defined correctly.
  cout << const_cast<trans_view_type const&>(dview)[1];
  cout << " " << dview[1] << endl;

  dview[1] = dview[0];

  assignment_test(dview);

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}
