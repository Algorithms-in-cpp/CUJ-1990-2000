/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "pair_merge_view.h"
#include <vector>
#include <iostream>
#include <cstdlib>


using std::cout;
using std::endl;
using std::cin;
using std::vector;
using std::map;
using std::set;
using std::iota;
using std::ostream;


template<class Container>
ostream & dump(ostream & os, const Container & cont)
{
	for( typename Container::const_iterator iter = cont.begin(); iter != cont.end(); ++iter)
	{
		os << *iter << " ";
	}
	os << endl << endl;

	return os;
}

template<class Container>
ostream & rdump(ostream & os, const Container & cont)
{
	for( typename Container::const_reverse_iterator iter = cont.rbegin(); iter != cont.rend(); ++iter)
	{
		os << *iter << " ";
	}
	os << endl << endl;

	return os;
}

template <class A, class B>
ostream& operator<<(ostream& out, const pair<A,B>& p) {
  return out << "(" << p.first << "," << p.second << ")";
}

//template <>
//ostream& operator<< <vector<int>::const_iterator,vector<int>::const_iterator>
//(ostream& out, const pair<vector<int>::const_iterator,vector<int>::const_iterator>& p) {
//  out << "[";
//  copy(p.first,p.second,ostream_iterator<int>(out," "));
//  return out << "]";
//}



int main(void) {
  vector<int> x(20);
  vector<int> y(20);
  for (unsigned i=0; i<20; ++i) {
    x[i] = rand()%6;
    y[i] = rand()%6;
  }
  sort(x.begin(),x.end());
  sort(y.begin(),y.end());
  dump(cout,x);
  dump(cout,y);
  
  typedef pair_merge_view<vector<int>,vector<int> > siv;
  
  siv view(x,y);
  
  for (siv::const_iterator i=view.begin(); i!=view.end(); ++i) {
    cout << "(" << i->first-x.begin() << ":" << *i->first  << "," << i->second-y.begin() << ":" << *i->second << ") ";
  }
  cout << endl;
  
  
  return 0;
}
