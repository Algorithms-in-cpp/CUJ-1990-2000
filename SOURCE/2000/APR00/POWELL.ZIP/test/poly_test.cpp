/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "polymorphic_view.h"

#include <cstdlib>
#include <vector>
#include <iostream>
#include <algorithm>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::for_each;
using std::swap;
using std::advance;

USING_VIEW_NAMESPACE

namespace {
//
// Classes for testing polymorphic containers.
//
struct V {
  int i;
  V(int x) : i(x) {}
  virtual void print() const { cout << "V = " << i; }

  V &operator=(int x) { i = x; return *this; }
};
struct T: public V {
	T(int x) : V(x) {}
  virtual void print() const { cout << "T = " << i; }

  T &operator=(int x) { V::operator=(x); return *this; }
};
struct L: public T {
	L(int x) : T(x) {}
  virtual void print() const { cout << "L = " << i; }

  L &operator=(int x) { T::operator=(x); return *this; }
};

ostream &operator<<(ostream &os, struct V const& v)
{
	v.print();
    return os;
}

// phoney comparison operators. 
bool operator==(V const &lhs, V const &rhs)
{
	return (&lhs == &rhs);	// compare addresses for now.
}

bool operator<(V const &lhs, V const &rhs)
{
	return (&lhs < &rhs);	// compare addresses for now.
}

};

//
// Test for polymorphic views.
//

int main()
{
  typedef polymorphic_view< vector<V*> > pview;
  vector<V*> cvb;
  pview cv(cvb);
  pview cv_copy(cv);

  cvb.push_back(new L(1));
  cvb.push_back(new T(2));
  cvb.push_back(new V(3));
  cout << "printing of the elements in the polymorphic view" << endl;
  for_each(cv.rbegin(),cv.rend(),mem_fun_ref(&V::print));
  cout << endl;

  forward_test(cv);
  const_forward_test(cv);
  reverse_test(cv);
  const_reverse_test(cv);
  random_access_test(cv);
  const_random_access_test(cv);

  // iterator category test.
  pview::iterator f_iter(cv.begin() );
  advance(f_iter, 2);

  cout << (cv < cv_copy) << endl;
  cout << (cv == cv_copy) << endl;
  cout << (cv != cv_copy) << endl;

  swap(cv, cv_copy);
  
  typedef polymorphic_view< vector<V*>, mutable_view_tag > mpview;

  mpview mcv(cvb);
  mcv[0] = 5;
  cout << mcv[0] << endl;

  delete cvb[0];
  delete cvb[1];
  delete cvb[2];

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

