/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include <iostream>


using std::cout;
using std::endl;
using std::cin;

extern void vector_test();
extern void map_test();
extern void slist_test();
extern void intersection_test();
extern void difference_test();
extern void merge_view_test();
extern void poly_test();
extern void sorted_itersection_test();
extern void sorted_difference_test();
extern void sorted_sym_difference_test();
extern void downcast_test();
extern void range_test();
extern void crossproduct_test();
extern void equal_range_view_test();
extern void pair_merge_view_test();
extern void sorted_difference_equal_range_test();
extern void sorted_itersection_equal_range_test();
extern void sorted_sym_difference_range_equal_test();
  

int main(void) {
  vector_test();
  map_test();
  slist_test();
  intersection_test();
  difference_test();
  merge_view_test();
  poly_test();
  sorted_itersection_test();
  sorted_difference_test();
  sorted_sym_difference_test();
  downcast_test();
  range_test();
  crossproduct_test();
  equal_range_view_test();
  pair_merge_view_test();
  sorted_itersection_equal_range_test();
  sorted_difference_equal_range_test();
  sorted_sym_difference_range_equal_test();
  

  cout << "type q <cr> to exit app. ";
  char c;
  while (1) {
    cin >> c;
    cout << c;
    if ( c == 'q' )
      break;
  }
    
  cout << endl;
  return 0;
}
