/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "filter_view.h"
#include "transform_view.h"

#include <cstdlib>
#include <iostream>
#include <numeric>
#include <slist>

#include "dump.h"

using std::cout;
using std::cin;
using std::endl;
using std::slist;
using std::advance;
using std::iota;

USING_VIEW_NAMESPACE

//
// A successor transformation n -> n+1
//
//class succ {
//public:
//  typedef int argument_type;
//  typedef int result_type;
//  result_type operator()(int n) const { return n+1; }
//};

class succ {
public:
  class result_type {
    friend class succ;
    int const& ref;
    explicit result_type(int const& cref): ref(cref) {}; // tricky
  public:
    explicit result_type(int& ref_): ref(ref_) {};
    operator int() const { return ref+1; }
    result_type& operator=(int x) { const_cast<int&>(ref) = x-1; return *this;}
  };
  typedef int argument_type;
  
  result_type       operator()(int& n)       const { return result_type(n); }
  result_type const operator()(int const& n) const { return result_type(n); }
};

//
// An odd filter: true for odd arguments
//
class odd {
public:
  bool operator()(int n) const {
    return n%2;
  }
};


  

// slist test
//

int main()
{
  typedef transform_view<slist<int>,succ,mutable_view_tag> view_slist_type;
  typedef filter_view<slist<int>,odd> view2_s_list_type;

  slist<int> x(4), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 0);

  view_slist_type xview(x,succ());
  view2_s_list_type xview2(y,odd());

  cout << "Vector is filled with 0,1,2,3. You should see the" << endl
       << "contents of the successor view: 1,2,3,4:" << endl;
  
  dump(cout, xview);

  // transform iterator category test.
  view_slist_type::iterator t_iter(xview.begin() );
  advance(t_iter, 2);

   // filter iterator category test.
  view2_s_list_type::iterator f_iter(xview2.begin() );
  advance(f_iter, 2);

  cout << "Filtering test: you should see only the odd elements of the vector:" << endl;
  dump(cout, xview2);

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}
