/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "map_view.h"

#include <cstdlib>
#include <map>
#include <cassert>
#include <iostream>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::map;
using std::advance;

USING_VIEW_NAMESPACE

int main()
{
  // Map keys test
  typedef map_keys< map<char,int> > keys_type;
  typedef map_keys< map<char,int>, mutable_view_tag > mkeys_type;
  typedef map_values< map<char,int> > values_type;
  typedef map_values< map<char,int>, mutable_view_tag  > mvalues_type;
  map<char,int> map1;

  map1['v'] = 1;
  map1['t'] = 2;
  map1['l'] = 3;

  const map<char,int>& map2 = map1;
  

  keys_type keys(map2);
  values_type values(map2);

  cout << "Running through map keys. You should see the keys" << endl
       << "'l', 't', 'v' printed:" << endl;
  
  dump(cout, keys);
  
  const_forward_test_no_lessthan(keys);
  const_reverse_test_no_lessthan(keys);

  // keys iterator category test.
  keys_type::iterator iter_mk(keys.begin() );
  advance(iter_mk, 2);
  assert(*iter_mk == 'v');

  // values iterator category test.
  values_type::iterator iter_mv(values.begin() );
  advance(iter_mv, 2);
  assert(*iter_mv == 1);

  const_forward_test_no_lessthan(values);
  const_reverse_test_no_lessthan(values);

  // STL maps are reversible.
  cout << "STL maps are reversible. Now you should see the keys in "
       << "reverse order:" << endl;
  
  for (keys_type::reverse_iterator i=keys.rbegin(); i!=keys.rend(); ++i) {
    cout << *i;
  }
  cout << endl << endl;
  

  cout << "Running through map values. You should see the unordered values" << endl
       << "1, 2, 3 printed:" << endl;
  
  dump(cout, values);
  cout << endl << endl;
  
  // STL maps are not random access containers -> compile time error
  //  cout << keys.begin()[0];

  mkeys_type mkeys(map1); // dangerous but possible.
  mvalues_type mvalues(map1);

  const_forward_test_no_lessthan(mkeys);
  const_reverse_test_no_lessthan(mkeys);

  const_forward_test_no_lessthan(mvalues);
  const_reverse_test_no_lessthan(mvalues);

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}
