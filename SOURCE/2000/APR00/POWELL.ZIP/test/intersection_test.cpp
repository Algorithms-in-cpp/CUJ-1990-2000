/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "intersection_view.h"

#include <cstdlib>
#include <map>
#include <vector>
#include <iostream>
#include <numeric>
#include <set>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::map;
using std::set;
using std::iota;
using std::advance;

USING_VIEW_NAMESPACE


namespace {

using std::ostream;

template <class A, class B>
ostream& operator<<(ostream& out, pair<A,B> const& p) {
  return out << "(" << p.first << "," << p.second << ")";
}

};


int main()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef intersection_view<vector<int>, vector<int> > inter_view;
  typedef intersection_view<vector<int>, vector<int>, mutable_view_tag > minter_view;

  inter_view	iview(x, y);

  cout << "Intersection Test: you should see only the numbers 3, 4:" << endl;
  dump(cout, iview);

  forward_test(iview);
  const_forward_test(iview);

  minter_view	miview(x, y);
  forward_test(miview);
  const_forward_test(miview);

  set<int> z;
  for (int j = 3; j < 9; ++j)
	  z.insert(j);

  typedef intersection_view<set<int>, vector<int> > interSet_view;

  interSet_view	isvview(z, x);

  cout << "Intersection Test: you should see only the numbers 3, 4:" << endl;
  dump(cout, isvview);

  typedef intersection_view<vector<int>, set<int> > interVecSet_view;
  interVecSet_view	ivsview(x, z);

  cout << "Intersection Test: you should see only the numbers 3, 4:" << endl;
  dump(cout, ivsview);

  map<int,int> mx, my;
  for (int i=0; i<15; ++i) {
    mx[i] = (i*i)%3;
    my[i+2] = (7*i)%5;
  }

  typedef intersection_view< map<int,int>, map<int,int> > interMap_view;
  interMap_view imview(mx,my);

  cout << "Intersection Test:" << endl;
  dump(cout,mx);
  dump(cout,my);
  cout << "-> ";
  dump(cout,imview);

  typedef intersection_view< map<int,int>, vector<int> > interMapVec_view;
  interMapVec_view imvview(mx,x);

  cout << "Intersection Test:" << endl;
  cout << "-> ";
  dump(cout,imvview);

  typedef intersection_view< vector<int>, map<int,int> > interVecMap_view;
  interVecMap_view ivmview(x,mx);

  cout << "Intersection Test:" << endl;
  cout << "-> ";
  dump(cout,ivmview);

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

