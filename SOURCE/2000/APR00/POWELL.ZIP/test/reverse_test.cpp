/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "reverse_view.h"

#include <cstdlib>
#include <vector>
#include <iostream>
#include <numeric>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::iota;
using std::advance;

USING_VIEW_NAMESPACE

int main()
{
	vector<int> x(14);

	iota (x.begin(), x.end(), 0);

	typedef reverse_view<vector<int> > reverse_vv_view;

	reverse_vv_view rvv(x);

    cout << "x set" << endl;
    dump(cout, x);

	cout << "Reverse Test, x.begin -> x.end()." << endl;
    dump(cout, rvv);

	cout << "Reverse Reverse Test, x.rbegin() -> x.rend()." << endl;
    rdump(cout, rvv);

	cout << "Advance 4 from the beginning." << endl;
	reverse_vv_view::iterator r_iter(rvv.begin() );
	advance(r_iter, 4);
	cout << *r_iter << endl;

	cout << "Reverse 4, back to the beginning." << endl;
	advance(r_iter, -4);
	cout << *r_iter << endl;

	cout << "Index 4 " << endl;
	cout << rvv[4] << endl;

	// current STL implementation is missing "vector.at()"
	//cout << "at 4 " << endl;
	//cout << rvv.at(4) << endl;

	cout << "Front & back" << endl;
	cout << rvv.front() << ", " << rvv.back() << endl;

  forward_test(rvv);
  const_forward_test(rvv);
  reverse_test(rvv);
  const_reverse_test(rvv);
  random_access_test(rvv);
  const_random_access_test(rvv);



  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

