/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#include "crossproduct_view.h"

#include <cstdlib>
#include <iostream>
#include <deque>
#include <numeric>
#include <cassert>
#include <algorithm>

#include "stl_fix.h"

#include "dump.h"
#include "iterator_test.h"
#include "functors.h"

using std::cout;
using std::cin;
using std::endl;
using std::deque;
using std::iota;
using std::advance;

USING_VIEW_NAMESPACE


namespace {

template<class T, class S>
ostream & operator<<(ostream & os, const reference_pair<T,S> &rhs)
{
	os << "<" << rhs.first << "," << rhs.second << ">";
	return os;
}

};


int main()
{
  deque<int> x(4);
  deque<int> y(5);

  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 4);


  typedef crossproduct_view<deque<int>, deque<int> > cross_vv_view;
  typedef crossproduct_view<deque<int>, deque<int>, mutable_view_tag > mcross_vv_view;

  cross_vv_view cvv(x,y), cyx(y,x);
  mcross_vv_view mvv(x,y);


  const_forward_test(cvv);
  const_reverse_test(cvv);
  const_random_access_test(cvv);

  forward_test(mvv);
  const_forward_test(mvv);
  reverse_test(mvv);
  const_reverse_test(mvv);
  random_access_test(mvv);
  const_random_access_test(mvv);

  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);

  cout << "Cross product view test. " << endl;
  dump(cout, cvv);

  cout << "Reverse Cross product view test. " << endl;
  rdump(cout, cvv);

  cout << "Advance 4 from the beginning." << endl;
  cross_vv_view::iterator c_iter(cvv.begin() );
  advance(c_iter, 4);
  cout << *c_iter << endl;
  c_iter += 1;
  assert(c_iter == ((cvv.begin()) += 5) );

  cout << "distance (begin,end) == " << distance(cvv.begin(), cvv.end() ) << endl;
  cout << "Reverse 4, back to the beginning." << endl;
  advance(c_iter, -4);
  cout << *c_iter << endl;

  //swap(cvv, cyx);
  assert(cvv != cyx);
  assert(!(cvv == cyx));

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}
