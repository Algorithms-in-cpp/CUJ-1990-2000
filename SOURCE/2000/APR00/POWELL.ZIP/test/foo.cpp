#include "view_base.h"
#include "range.h"
#include "transform_view.h"

#include <iostream>
#include <cstdlib>
#include <iterator>
#include <vector>
#include <numeric>

#include "dump.h"

using std::cout;
using std::cin;
using std::endl;

int main()
{
	cout << "Hello World." << endl;

	vector<int> x(10);

	iota(x.begin(),x.end(), 0);

	dump(cout,x);

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
    return EXIT_SUCCESS;
}