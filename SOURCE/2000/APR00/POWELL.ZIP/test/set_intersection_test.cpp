/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "set_intersection_view.h"

#include <cstdlib>
#include <vector>
#include <iostream>
#include <numeric>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::iota;
using std::advance;

USING_VIEW_NAMESPACE


typedef set_intersection_view<vector<int>, vector<int>, std::equal_to<int>,
    std::equal_to<int>,
    std::less<int>, const_view_tag, forward_iterator_tag > inter_view;
typedef set_intersection_view<vector<int>, vector<int>,
    std::equal_to<int>,
    std::equal_to<int>,
    std::less<int> > inter_rview;

int main()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);


  inter_view	iview(x, y);

  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);
  cout << "Intersection Range Test: you should see only the sets of 3, 4:" << endl;
  dump<inter_view >(cout, iview);
 

  // iterator category test.
  inter_view::iterator iter_vv(iview.begin() );
  advance(iter_vv, 2);

  inter_rview irview(x,y);
  cout << "reverse order test.:" << endl;
  rdump<inter_rview>(cout, irview);
 
  forward_test<inter_rview>(irview);
  const_forward_test<inter_rview>(irview);
  reverse_test<inter_rview>(irview);
  const_reverse_test<inter_rview>(irview);

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

