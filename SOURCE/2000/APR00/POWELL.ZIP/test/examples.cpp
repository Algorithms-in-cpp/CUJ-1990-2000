/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

//#include "concatenation_view.h"
#include <map>
#include <vector>
#include <deque>
#include <iostream>
#include <numeric>
#include <slist>
#include <set>

#include "mapview.h"
#include "filter_view.h"
#include "union_view.h"
#include "polymorphic_view.h"
#include "downcast_view.h"
#include "crossproduct_view.h"
#include "range_view.h"
#include "intersection_view.h"
#include "symmetric_difference_view.h"

#include "merge_view.h"
#include "sorted_intersection_view.h"
#include "sorted_difference_view.h"
#include "sorted_sym_diff_view.h"

#include "equal_range_view.h"
#include "pair_merge_view.h"
#include "sorted_intersection_equal_range_view.h"
#include "sorted_difference_equal_range_view.h"
#include "sorted_sym_diff_equal_range_view.h"
#include "dump.h"

using std::cout;
using std::endl;
using std::cin;
using std::vector;
using std::map;
using std::set;
using std::iota;
using std::ostream;
using std::for_each;

using std::slist;
using std::vector;
using std::deque;
using std::set;
using std::map;

using std::advance;


template<class T, class S>
ostream & operator<<(ostream & os, const ref_pair<T,S> &rhs)
{
	os << "<" << rhs.first << "," << rhs.second << ">";
	return os;
}


//
// Classes for testing polymorphic containers.
//
struct V {
  virtual void print() const { cout << "V"; }
};
struct T: public V {
  virtual void print() const { cout << "T"; }
};
struct L: public T {
  virtual void print() const { cout << "L"; }
};

// phoney comparison operators. 
bool operator==(V const &lhs, V const &rhs)
{
	return (&lhs == &rhs);	// compare addresses for now.
}

bool operator<(V const &lhs, V const &rhs)
{
	return (&lhs < &rhs);	// compare addresses for now.
}
//
// A successor transformation n -> n+1
//
//class succ {
//public:
//  typedef int argument_type;
//  typedef int result_type;
//  result_type operator()(int n) const { return n+1; }
//};

class succ {
public:
  class result_type {
    friend class succ;
    int const& ref;
    explicit result_type(int const& cref): ref(cref) {}; // tricky
  public:
    explicit result_type(int& ref_): ref(ref_) {};
    operator int() const { return ref+1; }
    result_type& operator=(int x) { const_cast<int&>(ref) = x-1; }
  };
  typedef int argument_type;
  
  result_type       operator()(int& n)       const { return result_type(n); }
  result_type const operator()(int const& n) const { return result_type(n); }
};

//
// An odd filter: true for odd arguments
//
class odd {
public:
  bool operator()(int n) const {
    return n%2;
  }
};

//
// Test for polymorphic views.
//

void poly_test() {
  typedef polymorphic_view< vector<V*> > pview;
  vector<V*> c;
  pview cv(c);
  pview cv_copy(cv);

  c.push_back(new L());
  c.push_back(new T());
  c.push_back(new V());
  cout << "printing of the elements in the polymorphic view" << endl;
  for_each(cv.rbegin(),cv.rend(),mem_fun_ref(&V::print));
  cout << endl;

  // iterator category test.
  pview::iterator f_iter(cv.begin() );
  advance(f_iter, 2);

  cout << (cv < cv_copy) << endl;
  cout << (cv == cv_copy) << endl;
  cout << (cv != cv_copy) << endl;

  swap(cv, cv_copy);
  
  delete c[0];
  delete c[1];
  delete c[2];
}

  

// slist test
//

void slist_test()
{
  typedef transform_view<slist<int>,succ,mutable_view_tag> view_slist_type;
  typedef filter_view<slist<int>,odd> view2_s_list_type;

  slist<int> x(4), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 0);

  view_slist_type xview(x,succ());
  view2_s_list_type xview2(y,odd());

  cout << "Vector is filled with 0,1,2,3. You should see the" << endl
       << "contents of the successor view: 1,2,3,4:" << endl;
  
  dump(cout, xview);

  // transform iterator category test.
  view_slist_type::iterator t_iter(xview.begin() );
  advance(t_iter, 2);

   // filter iterator category test.
  view2_s_list_type::iterator f_iter(xview2.begin() );
  advance(f_iter, 2);

 cout << "Filtering test: you should see only the odd elements of the vector:" << endl;
  dump(cout, xview2);
}
//
// Vector test
//
void vector_test() {
  typedef transform_view<vector<int>,succ,mutable_view_tag> view_type;
  typedef filter_view<vector<int>,odd> view2_type;
  typedef union_view<vector<int>,vector<int> > union1_type;
  typedef union_view<view2_type,view_type> union2_type;
  

  vector<int> x(4), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 0);

  view_type xview(x,succ());
  view_type yview(y,succ());
  view2_type xview2(x,odd());

  cout << "Vector is filled with 0,1,2,3. You should see the" << endl
       << "contents of the successor view: 1,2,3,4:" << endl;
  dump(cout, xview);
  cout << "Random access to element 2 of the view yields "
       << xview[2] << ", should be 3." << endl << endl;

  {
  int j(0);
  for (view_type::iterator i=xview.begin(); i!=xview.end(); ++i, ++j)
    xview[j] = (*i) * (*i);
  }

  // transform iterator category test.
  view_type::iterator t_iter(xview.begin() );
  advance(t_iter, 2);

  // filter iterator category test.
  view2_type::iterator f_iter(xview2.begin() );
  advance(f_iter, 2);

  // Testing the conversion iterator -> const_iterator
  cout << "Squaring the view elements results in: " << endl;
  dump(cout, xview);

  cout << "The original container now contains: " << endl;
  dump(cout, x);

  cout << "Filtering test: you should see only the odd elements of the vector:" << endl;
  dump(cout, xview2);

  cout << "Swapping with successor view [0..8]:" << endl;
  //xview.swap(yview);
  //swap(xview,yview);
  dump(cout, xview);

  cout << "other view:" << endl;
  dump(cout, yview);


  cout << "Union of the original containers:" << endl;
  union1_type u1(x,y);
  dump(cout, u1);

  // union iterator category test.
  union1_type::iterator u_iter(u1.begin() );
  advance(u_iter, 2);

  cout << "Union of the views:" << endl;
  union2_type u2(xview2,xview);
  dump(cout, u2);
}

// hack
template <class A, class B>
ostream& operator<<(ostream& out, pair<A,B> const& p) {
  return out << "(" << p.first << "," << p.second << ")";
}


void intersection_test()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef intersection_view<vector<int>, vector<int> > inter_view;

  inter_view	iview(x, y);

  cout << "Intersection Test: you should see only the numbers 3, 4:" << endl;
  dump(cout, iview);

  set<int> z;
  for (int j = 3; j < 9; ++j)
	  z.insert(j);

  typedef intersection_view<set<int>, vector<int> > interSet_view;

  interSet_view	isvview(z, x);

  cout << "Intersection Test: you should see only the numbers 3, 4:" << endl;
  dump(cout, isvview);

  typedef intersection_view<vector<int>, set<int> > interVecSet_view;
  interVecSet_view	ivsview(x, z);

  cout << "Intersection Test: you should see only the numbers 3, 4:" << endl;
  dump(cout, ivsview);

  map<int,int> mx, my;
  for (int i=0; i<15; ++i) {
    mx[i] = (i*i)%3;
    my[i+2] = (7*i)%5;
  }

  typedef intersection_view< map<int,int>, map<int,int> > interMap_view;
  interMap_view imview(mx,my);

  cout << "Intersection Test:" << endl;
  dump(cout,mx);
  dump(cout,my);
  cout << "-> ";
  dump(cout,imview);

  typedef intersection_view< map<int,int>, vector<int> > interMapVec_view;
  interMapVec_view imvview(mx,x);

  cout << "Intersection Test:" << endl;
  cout << "-> ";
  dump(cout,imvview);

  typedef intersection_view< vector<int>, map<int,int> > interVecMap_view;
  interVecMap_view ivmview(x,mx);

  cout << "Intersection Test:" << endl;
  cout << "-> ";
  dump(cout,ivmview);
}

void difference_test()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef symmetric_difference_view<vector<int>, vector<int> > diff_view;

  diff_view	dview(x, y);

  cout << "Symmetric Difference Test: you should not see the numbers 3, 4:" << endl;
  dump(cout, dview);

  set<int> z;
  for (int j = 3; j < 9; ++j)
	  z.insert(j);


  typedef symmetric_difference_view<set<int>, vector<int> > diffSetVec_view;
  diffSetVec_view	dsview(z, x);

  cout << "Symmetric Difference Test: you should not see the numbers 3, 4:" << endl;
  dump(cout, dsview);

  map<int,int> mx, my;
  for (int i=0; i<15; ++i) {
    mx[i] = (i*i)%3;
    my[i+2] = (7*i)%5;
  }

  typedef symmetric_difference_view< map<int,int>, map<int,int> > diffMap_view;
  diffMap_view dmview(mx,my);

  cout << "Symmetric Difference set Test:" << endl;
  dump(cout,mx);
  dump(cout,my);
  cout << "-> ";
  dump(cout,dmview);
}

void merge_view_test()
{
  vector<int> x(9), y(9);
  for (int i = 0; i < 9; ++i)
  {
     x[i] = 2 * i;
     y[i] = x[i] + 1;
  }


  typedef merge_view<vector<int>, vector<int> > mergVecVec_view;

  mergVecVec_view	mview(x, y);
  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);

  cout << "Merge Test: you should see the ordered numbers 0 -> 17:" << endl;
  dump(cout, mview);
  cout << "The difference end() - begin() and then begin() - end(): " << endl;
  cout << mview.end() - mview.begin() << "   " << mview.begin() - mview.end() << endl;
  cout << "distance(begin(),end()):" << endl;
  cout << distance(mview.begin(),mview.end()) << endl;
  cout << "begin() < end() and then end() < begin():" << endl
       << (mview.begin()<mview.end()) << "   " << (mview.end()<mview.begin()) << endl;
  
  // iterator category test.
  mergVecVec_view::iterator iter_vv(mview.begin() );
  advance(iter_vv, 2);

  // default constructible test.
  mergVecVec_view::iterator iter_default;
  
  

  typedef merge_view<vector<int>, vector<int>,
	  std::less<int>,
	  const_view_tag,
	  view_ref,
	  view_ref,
	  two_containers_range_own<vector<int>::const_iterator, vector<int>::const_iterator>
	  > mergBidirectionalVecVec_view;
  mergBidirectionalVecVec_view	mrview(x, y);
  cout << "Merge Test: you should see the ordered numbers 17 -> 0:" << endl;
  rdump(cout, mrview);
}

void sorted_itersection_test()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef sorted_intersection_view<vector<int>, vector<int> > inter_view;

  inter_view	iview(x, y);

  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);
  cout << "Intersection Test: you should see only the numbers 3, 4:" << endl;
  dump(cout, iview);

  // iterator category test.
  inter_view::iterator iter_vv(iview.begin() );
  advance(iter_vv, 2);

  typedef sorted_intersection_view<vector<int>, vector<int>,
    std::less<int>,
    const_view_tag,
    view_ref,
    view_ref,
    two_containers_range_own<vector<int>::const_iterator, vector<int>::const_iterator>
	> inter_rview;
  inter_rview irview(x,y);
  cout << "reverse order test.:" << endl;
  rdump(cout, irview);
}

void sorted_sym_difference_test()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef sorted_symmetrical_difference_view<vector<int>, vector<int> > inter_view;

  inter_view	iview(x, y);

  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);
  cout << "Sorted symmetrical Difference Test: you should not see the numbers 3, 4:" << endl;
  dump(cout, iview);

  // iterator category test.
  inter_view::iterator iter_vv(iview.begin());
  advance(iter_vv, 2);

  typedef sorted_symmetrical_difference_view<vector<int>, vector<int>,
    std::less<int>, const_view_tag,
    view_ref, view_ref,
    two_containers_range_own<vector<int>::const_iterator, vector<int>::const_iterator>,
    two_containers_range_own<vector<int>::const_iterator, vector<int>::const_iterator>
    > inter_rview;
  inter_rview irview(x,y);
  cout << "reverse order test.:" << endl;
  rdump(cout, irview);
}

void sorted_difference_test()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef sorted_difference_view<vector<int>, vector<int> > diff_view;

  diff_view	dxview(x, y);
  diff_view	dyview(y, x);

   cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);
  cout << "Sorted Difference Test: you should see x less the numbers 3, 4:" << endl;
  dump(cout, dxview);

  cout << "Sorted Difference Test: you should see y less the numbers 3, 4:" << endl;
  dump(cout, dyview);

  // iterator category test.
  diff_view::iterator iter_vv(dxview.begin() );
  advance(iter_vv, 2);

  typedef sorted_difference_view<vector<int>, vector<int>,
		std::less<int>, const_view_tag, view_ref, view_ref,
		two_containers_range_own<vector<int>::const_iterator, vector<int>::const_iterator>
	  > diff_rview;
  diff_rview dxrview(x, y);
  diff_rview dyrview(y, x);

  cout << "Sorted Difference Test: you should see reverse x less the numbers 3, 4:" << endl;
  rdump(cout, dxrview);

  cout << "Sorted Difference Test: you should see reverse y less the numbers 3, 4:" << endl;
  rdump(cout, dyrview);

  map<int,int> mx, my;
  for (int i=0; i<15; ++i) {
    mx[i] = (i*i)%3;
    my[i+2] = (7*i)%5;
  }

  typedef sorted_difference_view< map<int,int>, map<int,int> > diffMap_view;
  diffMap_view dmview(mx,my);

  cout << "Sorted Difference set Test:" << endl;
  dump(cout,mx);
  dump(cout,my);
  cout << "-> ";
  dump(cout,dmview);

  // iterator category test.
  diffMap_view::iterator iter_mvv(dmview.begin() );
  advance(iter_mvv, 2);
}


void map_test()
{
  // Map keys test
  typedef map_keys< map<char,int>, const_view_tag, view_ref > keys_type;
  typedef map_values< map<char,int>, const_view_tag, view_ref > values_type;
  map<char,int> map1;

  map1['v'] = 1;
  map1['t'] = 2;
  map1['l'] = 3;

  //const 
  map<char,int>& map2 = map1;
  

  keys_type keys(map2);
  values_type values(map2);

  cout << "Running through map keys. You should see the keys" << endl
       << "'l', 't', 'v' printed:" << endl;
  
  dump(cout, keys);
  
  // keys iterator category test.
  keys_type::iterator iter_mk(keys.begin() );
  advance(iter_mk, 2);
  assert(*iter_mk == 'v');

  // values iterator category test.
  values_type::iterator iter_mv(values.begin() );
  advance(iter_mv, 2);
  assert(*iter_mv == 1);

  // STL maps are reversible.
  cout << "STL maps are reversible. Now you should see the keys in "
       << "reverse order:" << endl;
  
  for (keys_type::reverse_iterator i=keys.rbegin(); i!=keys.rend(); ++i) {
    cout << *i;
  }
  cout << endl << endl;
  

  cout << "Running through map values. You should see the values" << endl
       << "1, 2, 3 printed:" << endl;
  
  dump(cout, values);
  cout << endl << endl;
  
  // STL maps are not random access containers -> compile time error
  //  cout << keys.begin()[0];

}

void downcast_test()
{
  deque<V*> c;
  c.push_back(new L());
  c.push_back(new T());
  c.push_back(new V());

#if 1
  typedef downcast_view< deque<V*>, T > dcview;
  dcview cv(c);
  cout << "printing of the (T) elements in the downcast view" << endl;
  for_each(cv.begin(),cv.end(),mem_fun_ref(&V::print));
  cout << endl;

  // iterator category test.
  dcview::iterator f_iter(cv.begin() );
  advance(f_iter, 2);
  
  typedef downcast_view< deque<V*>, T, const_view_tag> rdcview;	// bidirectional
  rdcview rcv(c);
  cout << "reverse printing of the (T) elements in the downcast view" << endl;
  for_each(rcv.rbegin(),rcv.rend(),mem_fun_ref(&V::print));
  cout << endl;
#endif

  delete c[0];
  delete c[1];
  delete c[2];
}

void crossproduct_test()
{
	vector<int> x(4);
	vector<int> y(5);

	iota (x.begin(), x.end(), 0);
	iota (y.begin(), y.end(), 4);

	typedef crossproduct_view<vector<int>, vector<int> > cross_vv_view;

	cross_vv_view cvv(x,y);

    cout << "x , y sets" << endl;
    dump(cout, x);
    dump(cout, y);

    cout << "Cross product view test. " << endl;
	dump(cout, cvv);

    cout << "Reverse Cross product view test. " << endl;
	rdump(cout, cvv);

	cout << "Advance 4 from the beginning." << endl;
	cross_vv_view::iterator c_iter(cvv.begin() );
	advance(c_iter, 4);
	cout << *c_iter << endl;

	cout << "Reverse 4, back to the beginning." << endl;
	advance(c_iter, -4);
	cout << *c_iter << endl;
}

void range_test()
{
	vector<int> x(14);

	iota (x.begin(), x.end(), 0);

	typedef range_view<vector<int>::iterator > range_vv_view;

	range_vv_view rvv(x.begin() + 1, x.end() - 1);

    cout << "x set" << endl;
    dump(cout, x);

	cout << "Range Test, x.begin + 1 -> x.end() - 1." << endl;
    dump(cout, rvv);

	cout << "Reverse Range Test, x.begin + 1 -> x.end() - 1." << endl;
    rdump(cout, rvv);

	cout << "Advance 4 from the beginning." << endl;
	range_vv_view::iterator r_iter(rvv.begin() );
	advance(r_iter, 4);
	cout << *r_iter << endl;

	cout << "Reverse 4, back to the beginning." << endl;
	advance(r_iter, -4);
	cout << *r_iter << endl;
}

ostream& operator<<(ostream& out, const pair<vector<int>::const_iterator,vector<int>::const_iterator>& p) {
  out << "(";
  copy(p.first,p.second,ostream_iterator<int>(out," "));
  return out << ") ";
}

ostream& operator<<(ostream& os, equal_range_view< vector<int> >::const_iterator const & p) {
  os << *p;
  return os;
}

ostream& operator<<(ostream& os, equal_range_view< vector<int>, equal_to<int>, const_view_tag, view_ref,
					bidirectional_range_own<vector<int>::const_iterator> >::const_iterator const & p) {
  os << *p;
  return os;
}


ostream& operator<<(ostream& os, equal_range_view< vector<int>, equal_to<int>, const_view_tag, view_ref,
					bidirectional_range_own<vector<int>::const_iterator> >::const_reverse_iterator const & p) {
  os << *p;
  return os;
}

void equal_range_view_test() {
  cout << ">>>> Equal Range View Test <<<<" << endl;
  
  vector<int> x(30);
  for (unsigned i=0; i<30; ++i)
    x[i] = rand()%6;
  
  typedef equal_range_view< vector<int> > erv;
  erv v(x);
  cout << "The container itself:" << endl;
  dump(cout,x);
  cout << "The equal ranges view:" << endl;
  dump(cout,v);
  typedef equal_range_view< vector<int>, equal_to<int>, const_view_tag, view_ref,
					bidirectional_range_own<vector<int>::const_iterator> >rerv;
  rerv vr(x);
  cout << "The reverse equal ranges view:" << endl;
  rdump(cout,vr);
  cout << "The size of the view: " << v.size() << endl << endl;

  sort(x.begin(),x.end());
  cout << "Sorted the container:" << endl;
  dump(cout,x);
  cout << "The equal ranges view now:" << endl;
  dump(cout,v);
  cout << "The reverse equal ranges view:" << endl;
  rdump(cout,vr);
  cout << "The size of the view: " << v.size() << endl;

  cout << "view == view? " << (v==v) << endl;
  cout << "view < view?  " << (v<v) << endl;

  // iterator tests
  {
	  vector<int> x(9), y(9);
	  for (int i = 0; i < 9; ++i)
	  {
		 x[i] = 2 * i;
		 y[i] = x[i] + 1;
	  }

	  typedef equal_range_view< vector<int> > const er_vview;
	  er_vview x_er(x);
	  er_vview y_er(y);

	  er_vview::const_iterator x_iter = x_er.begin();
	  er_vview::const_iterator y_iter = y_er.begin();

	  cout << *x_iter << " < " << *y_iter << " = " << ((*x_iter) < (*y_iter)) << endl;
	  ++x_iter;
	  cout << *x_iter << " < " << *y_iter << " = " << ((*x_iter) < (*y_iter)) << endl;
	  ++y_iter;
	  cout << *x_iter << " < " << *y_iter << " = " << ((*x_iter) < (*y_iter)) << endl;
	  advance(x_iter, 4);
	  cout << *x_iter << " < " << *y_iter << " = " << ((*x_iter) < (*y_iter)) << endl;

	  typedef equal_range_view< vector<int>, equal_to<int>, const_view_tag, view_ref,
					bidirectional_range_own<vector<int>::const_iterator> > const rer_vview;
	  rer_vview rx_er(x);
	  rer_vview ry_er(y);

	  rer_vview::const_reverse_iterator xr_iter = rx_er.rend();
	  rer_vview::const_reverse_iterator yr_iter = ry_er.rend();
	  --xr_iter;
	  --yr_iter;
	  cout << *xr_iter  << " < " <<  *yr_iter << " = " << ((*xr_iter) < (*yr_iter)) << endl;
  }

}


void pair_merge_view_test()
{
  vector<int> x(9), y(9);
  for (int i = 0; i < 9; ++i)
  {
     x[i] = 2 * i;
     y[i] = x[i] + 1;
  }

  typedef equal_range_view< vector<int> > const er_vview;

  typedef pair_merge_view<er_vview, er_vview > pairmergVecVec_view;

  er_vview x_er(x);
  er_vview y_er(y);

  pairmergVecVec_view	mview(x_er, y_er);
  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);

  cout << "Merge Test: you should see the ordered pairs numbers 0 -> 17:" << endl;
  dump(cout, mview);
  typedef equal_range_view< vector<int>, equal_to<int>, const_view_tag, view_ref,
					bidirectional_range_own<vector<int>::const_iterator> > const rer_vview;
  typedef pair_merge_view<rer_vview, rer_vview,
							// the next line is actually std::less<int> -g-
							std::less<dereference_traits<rer_vview::value_type::first_type>::type>,
							const_view_tag,
							view_ref,
							view_ref,
							two_containers_range_own<rer_vview::const_iterator, 
													rer_vview::const_iterator> 
							> pairmergVecVec_rview;
  rer_vview rx_er(x);
  rer_vview ry_er(y);

  pairmergVecVec_rview mrview(ry_er, rx_er);
  cout << "Reverse :" << endl;
  rdump(cout, mrview);

  //iterator tests
  pairmergVecVec_rview::const_reverse_iterator mrv_iter = mrview.rbegin();
  advance(mrv_iter, 16);
  cout << *mrv_iter << endl;
  ++mrv_iter;
  cout << *mrv_iter << endl;
}

void sorted_itersection_equal_range_test()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef sorted_intersection_equal_range_view<vector<int>, vector<int> > inter_view;

  inter_view	iview(x, y);

  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);
  cout << "Intersection Range Test: you should see only the sets of 3, 4:" << endl;
  dump(cout, iview);

  // iterator category test.
  inter_view::iterator iter_vv(iview.begin() );
  advance(iter_vv, 2);

  typedef sorted_intersection_equal_range_view<vector<int>, vector<int>,
    std::equal_to<int>,
    std::equal_to<int>,
    std::less<int>,
    const_view_tag,
    view_ref,
    view_ref,
	bidirectional_range_own<vector<int>::const_iterator>,
	bidirectional_range_own<vector<int>::const_iterator>
	> inter_rview;
  inter_rview irview(x,y);
  cout << "reverse order test.:" << endl;
  rdump(cout, irview);
}

ostream& operator<<(ostream& os, map<int,int>::const_iterator const & p) {
  os << "(" << (*p).first << "," << (*p).second << ")";
  return os;
}

ostream& operator<<(ostream& os, equal_range_view< map<int,int> >::const_iterator const & p) {
  os << *p;
  return os;
}


void sorted_difference_equal_range_test()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef sorted_difference_equal_range_view<vector<int>, vector<int> > diff_view;

  diff_view	dxview(x, y);
  diff_view	dyview(y, x);

   cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);
  cout << "Sorted Difference Test: you should see set x less the numbers 3, 4:" << endl;
  dump(cout, dxview);

  cout << "Sorted Difference Test: you should see set y less the numbers 3, 4:" << endl;
  dump(cout, dyview);

  // iterator category test.
  diff_view::iterator iter_vv(dxview.begin() );
  advance(iter_vv, 2);

  typedef sorted_difference_equal_range_view<vector<int>, vector<int>,
		std::equal_to<int>, 
		std::equal_to<int>, 
		std::less<int>, 
		const_view_tag, view_ref, view_ref,
		bidirectional_range_own<vector<int>::const_iterator>,
		bidirectional_range_own<vector<int>::const_iterator>
		> diff_rview;
  diff_rview dxrview(x, y);
  diff_rview dyrview(y, x);

  cout << "Sorted Difference Test: you should see reverse x less the numbers 3, 4:" << endl;
  rdump(cout, dxrview);

  cout << "Sorted Difference Test: you should see reverse y less the numbers 3, 4:" << endl;
  rdump(cout, dyrview);

  map<int,int> mx, my;
  for (int i=0; i<15; ++i) {
    mx[i] = (i*i)%3;
    my[i+2] = (7*i)%5;
  }

  typedef sorted_difference_equal_range_view< map<int,int>, map<int,int> > diffMap_view;
  diffMap_view dmview(mx,my);

  cout << "Sorted Difference set Test:" << endl;
  dump(cout,mx);
  dump(cout,my);
  cout << "-> ";
  dump(cout,dmview);	// This is bizzare! -g-

  // iterator category test.
  diffMap_view::iterator iter_mvv(dmview.begin() );
  advance(iter_mvv, 2);
}

void sorted_sym_difference_range_equal_test()
{
  vector<int> x(5), y(9);
  iota (x.begin(), x.end(), 0);
  iota (y.begin(), y.end(), 3);

  typedef sorted_sym_difference_equal_range_view<vector<int>, vector<int> > inter_view;

  inter_view	iview(x, y);

  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);
  cout << "Sorted symmetrical Difference Test: you should not see the numbers 3, 4:" << endl;
  dump(cout, iview);

  // iterator category test.
  inter_view::iterator iter_vv(iview.begin());
  advance(iter_vv, 2);

  typedef sorted_sym_difference_equal_range_view<vector<int>, vector<int>,
    std::equal_to<int>, 
    std::equal_to<int>, 
    std::less<int>, 
	const_view_tag,
    view_ref, view_ref,
	bidirectional_range_own<vector<int>::const_iterator>,
	bidirectional_range_own<vector<int>::const_iterator>
	> inter_rview;
  inter_rview irview(x,y);
  cout << "reverse order test.:" << endl;
  rdump(cout, irview);
}

int main(void) {
  vector_test();
  map_test();
  slist_test();
  intersection_test();
  difference_test();
  merge_view_test();
  poly_test();
  sorted_itersection_test();
  sorted_difference_test();
  sorted_sym_difference_test();
  downcast_test();
  range_test();
  crossproduct_test();
  equal_range_view_test();
  pair_merge_view_test();
  sorted_difference_equal_range_test();
  sorted_itersection_equal_range_test();
  sorted_sym_difference_range_equal_test();
  

  cout << "type q <cr> to exit app. ";
  char c;
  while (1) {
    cin >> c;
    cout << c;
    if ( c == 'q' )
      break;
  }
    
  cout << endl;
  return 0;
}
#endif // _DUMP_H