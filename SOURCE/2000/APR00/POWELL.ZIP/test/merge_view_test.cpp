/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "merge_view.h"

#include <cstdlib>
#include <vector>
#include <iostream>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::advance;

USING_VIEW_NAMESPACE

int main()
{
  vector<int> x(9), y(9);
  for (int i = 0; i < 9; ++i)
  {
     x[i] = 2 * i;
     y[i] = x[i] + 1;
  }


  typedef merge_view<vector<int>, vector<int>, std::less<int>, const_view_tag, forward_iterator_tag > mergVecVec_view;
  typedef merge_view<vector<int>, vector<int>,
	  std::less<int>,
	  mutable_view_tag > m_mergVecVec_view;

  mergVecVec_view	mview(x, y);
  cout << "x , y sets" << endl;
  dump(cout, x);
  dump(cout, y);

  cout << "Merge Test: you should see the ordered numbers 0 -> 17:" << endl;
  dump(cout, mview);

  const_forward_test(mview);

  m_mergVecVec_view mmview(x,y);
  forward_test(mmview);
  const_forward_test(mmview);

  cout << "The difference end() - begin() and then begin() - end(): " << endl;
  cout << mview.end() - mview.begin() << "   " << mview.begin() - mview.end() << endl;
  cout << "distance(begin(),end()):" << endl;
  cout << distance(mview.begin(),mview.end()) << endl;
  cout << "begin() < end() and then end() < begin():" << endl
       << (mview.begin()<mview.end()) << "   " << (mview.end()<mview.begin()) << endl;
  
  // iterator category test.
  mergVecVec_view::iterator iter_vv(mview.begin() );
  advance(iter_vv, 2);

  // default constructible test.
  mergVecVec_view::iterator iter_default;
  iter_default = mview.end();
  
  

  typedef merge_view<vector<int>, vector<int>,
	  std::less<int>,
	  const_view_tag > mergBidirectionalVecVec_view;
  mergBidirectionalVecVec_view	mrview(x, y);
  cout << "Merge Test: you should see the ordered numbers 17 -> 0:" << endl;
  rdump(cout, mrview);

  forward_test(mrview);
  const_forward_test(mrview);
  reverse_test(mrview);
  const_reverse_test(mrview);

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

