/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "unique_view.h"

#include <cstdlib>
#include <vector>
#include <iostream>
#include <numeric>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::advance;

USING_VIEW_NAMESPACE

int main()
{
  vector<int> x(10);
  {
  int i;
  vector<int>::iterator iter(x.begin());

  for (i = 0; iter != x.end(); ++i, ++iter)
  {
	  *iter = i;
	  ++iter;
	  if (iter == x.end() )
	      break;
	  *iter = i;
  }
  }

  typedef unique_view<vector<int> > unq_view;

  unq_view	uview(x);

  cout << "x set" << endl;
  dump(cout, x);

  cout << "unique Test: you should not see any numbers duplicated.:" << endl;
  dump(cout, uview);

  // iterator category test.
  unq_view::iterator iter_vv(uview.begin());
  advance(iter_vv, 2);

  typedef unique_view<vector<int>,
					std::equal_to<int> > unq_rview;

  unq_rview urview(x);
  cout << "reverse order test.:" << endl;
  rdump(cout, urview);

  forward_test(urview);
  const_forward_test(urview);
  reverse_test(urview);
  const_reverse_test(urview);
  random_access_test(urview);
  const_random_access_test(urview);

  typedef unique_view<vector<int>,
					std::equal_to<int>,
					mutable_view_tag > unq_mview;

  forward_test(urview);
  reverse_test(urview);
  random_access_test(urview);

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}
