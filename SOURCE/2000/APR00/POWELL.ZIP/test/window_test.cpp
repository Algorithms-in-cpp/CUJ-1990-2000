/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "window_view.h"

#include <cstdlib>
#include <vector>
#include <iostream>
#include <numeric>

#include "dump.h"
#include "iterator_test.h"

using std::cout;
using std::cin;
using std::endl;
using std::vector;
using std::iota;
using std::advance;

USING_VIEW_NAMESPACE

int main()
{
  vector<int> x(14);

  iota (x.begin(), x.end(), 0);

  typedef window_view<vector<int> > window_vv_view;

  // two equivalent ways of construction
  //window_vv_view rvv(x, x.begin() + 1, x.end() - 1);
  window_vv_view rvv(x, x.begin() + 1, x.size()-2);

  cout << "x set = ";
  dump(cout, x);

#if 0
	cout << "Rotate Test, x.begin + 1 -> x.end() - 1" << endl;
    dump(cout, rvv);
	cout << "Reverse Test" << endl;
    rdump(cout, rvv);

	window_vv_view::iterator r_iter(rvv.begin() );

	if (rvv.begin() == rvv.end() )	cout << "Begin == end" << endl;
	else	cout << "Begin != end" << endl;

	cout << "size = " << rvv.size() << endl;

	rvv.rotate(4);
	cout << "size = " << rvv.size() << endl;
	r_iter = rvv.begin();
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << *r_iter << " ";
	++r_iter;
	cout << endl;

	if (rvv.begin() == rvv.end() )	cout << "Begin == end" << endl;
	else	cout << "Begin != end" << endl;
#endif
#if 1
	cout << "Rotate Test, x.begin + 1 -> x.end() - 1" << endl;
    dump(cout, rvv);
	cout << "Reverse Test = ";
    rdump(cout, rvv);

	rvv.rotate(4);

	cout << "Rotate Test, x.begin + 1 -> x.end() - 1, rotate 4" << endl;
    dump(cout, rvv);

	cout << "Reverse Test" << endl;
    rdump(cout, rvv);

	cout << "Advance iterator 4 from the beginning. : ";
	window_vv_view::iterator r_iter(rvv.begin() );
	advance(r_iter, 4);
	cout << *r_iter << endl;

	cout << "Reverse 4, back to the beginning. : ";
	advance(r_iter, -4);
	cout << *r_iter << endl;

  forward_test(rvv);
  const_forward_test(rvv);
  reverse_test(rvv);
  const_reverse_test(rvv);

	rvv.rotate(-4);
	cout << "Rotate Test, x.begin + 1 -> x.end() - 1, rotate -4" << endl;
    dump(cout, rvv);

	cout << "Reverse Test, " << endl;
    rdump(cout, rvv);

  forward_test(rvv);
  const_forward_test(rvv);
  reverse_test(rvv);
  const_reverse_test(rvv);

  // random access version.
  typedef window_view<vector<int> > rwindow_vv_view;

  rwindow_vv_view rrvv(x, x.begin() + 1, x.end() - 1);

  random_access_test(rrvv);
  const_random_access_test(rrvv);

  // assignment test.
  typedef window_view<vector<int>, mutable_view_tag > mrwindow_vv_view;
  mrwindow_vv_view mrrvv(x, x.begin() + 1, x.end() - 1);

  forward_test(mrrvv);
  random_access_test(mrrvv);

  mrrvv[0] = -1;
  cout << mrrvv[0] << endl;

#endif

  cout << "type q <cr> to exit app. ";
  char c;
  do {
    cin >> c;
    cout << c;
  } while (c != 'q');
    
  cout << endl;
  return EXIT_SUCCESS;
}

