/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#if !defined(_TRANSFORM_VIEW_H)
#define _TRANSFORM_VIEW_H	1

#if !defined(_VIEW_BASE_H)
#include "view_base.h"
#endif

#if !defined(_RANGE_H)
#include "range.h"
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

#if !defined(_SYS_LIBRARY_STDEXCEPT_)
#include <stdexcept>
#define _SYS_LIBRARY_STDEXCEPT_
#endif


// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp>
	void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool equal(_InputIter1, _InputIter1,
                  _InputIter2);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE
//
// A transformational iterator template.
//
// Note that the reference type is equal to the value type T. That is not
// really what is meant by reference, but the closest we get for transformational
// views.
//

template <class transform,
          class iter_t,
          class T>
class transform_iterator
  : public std::iterator<std::iterator_traits<iter_t>::iterator_category,
                         T,
		         std::iterator_traits<iter_t>::difference_type,
                         pointer_traits<T>::type,
		         T> {
  typedef member_access_proxy<T> ma_type;
  
public:
  typedef std::iterator<std::iterator_traits<iter_t>::iterator_category,
                        T, std::iterator_traits<iter_t>::difference_type,
                        pointer_traits<T>::type,T> inherited;
  typedef const_traits<reference>::type const_reference;

  // Iterators must be default constructible.
  explicit transform_iterator() {}

  transform_iterator(transform trans_, iter_t iter_)
    : iter(iter_), trans(trans_) {}
  
  transform_iterator& operator++()    { ++iter; return *this; }
  transform_iterator  operator++(int) { transform_iterator tmp(*this); ++iter; return *tmp; }

  // Backward stepping. This works only with bidirectional iterators.
  transform_iterator& operator--()    { --iter; return *this; }
  transform_iterator  operator--(int) { transform_iterator tmp(*this); --iter; return *tmp; }
  
  const_reference operator*() const { return trans(*iter); }
  reference       operator*()       { return trans(*iter); }
  const ma_type operator->() const { return ma_type(trans(*iter)); }
  ma_type       operator->()       { return ma_type(trans(*iter)); }


  // These work best with random access iterators.
  transform_iterator& operator+=(int n) { std::advance(iter,n); return *this; }
  transform_iterator operator+(difference_type n) const {
    transform_iterator tmp(*this);
    return tmp += n;
  }
  transform_iterator& operator-=(int n) { advance(iter,-n); return *this; }
  transform_iterator operator-(difference_type n) const {
    transform_iterator tmp(*this);
    return tmp -= n;
  }
  const_reference operator[](difference_type n) const { return *(*this + n); }

  difference_type operator-(const transform_iterator& y ) const {
    if (iter < y.iter) return -std::distance(iter,y.iter);
    else               return std::distance(y.iter,iter);
  }

  template <class iter2, class T2>
  bool operator==(const transform_iterator<transform,iter2,T2>& rhs) const { return iter==rhs.iter; }

  template <class iter2, class T2>
  bool operator< (const transform_iterator<transform,iter2,T2>& rhs) const { return iter < rhs.iter; }

  // Conversion from iterator to const_iterator. This works only if there is a
  // conversion from iter_t to const_iter and T to const_T.
  template<class const_iter, class const_T>
  operator transform_iterator<transform,const_iter,const_T>() const {
    return transform_iterator<transform,const_iter,const_T>(trans,iter); }

  // return the underlying container iterator.
  iter_t &get() { return iter; }
  iter_t const &get() const { return iter; }
     
protected:
  iter_t iter;
  transform trans;

  // Why shall friend declarations not be partial specialized? Ick!
  template<class trans2, class iter2, class T2>
  friend class transform_iterator;
  
};

//
// A transformational view.
//

template <class container,
          class transformation,
          class const_tag = const_view_tag,
          class T=typename transformation::result_type,
          template <class C, class tag> class proxy_template = view_ref>
class transform_view {
public:
  typedef one_container_base<container,const_tag,proxy_template> base_t;
  typedef T                     value_type;
  typedef const_traits<T>::type const_value_type;
  
  typedef ctor_arg<container,const_tag,proxy_template>::type ctor_arg_type;
  typedef view_traits<container,const_tag>::container_type domain_type;
  typedef view_traits<container,const_tag>::iterator       domain_iterator;
  typedef view_traits<container,const_tag>::const_iterator domain_const_iterator;
  typedef transformation transform_type;
  typedef pointer_traits<T>::type  pointer;
  typedef T                                 reference;
  typedef typename const_traits<T>::type    const_reference;
  typedef typename domain_type::size_type size_type;
  typedef typename domain_type::difference_type difference_type;


  typedef transform_iterator<transform_type, domain_iterator,      value_type>              iterator;
  typedef transform_iterator<transform_type, domain_const_iterator,const_value_type>  const_iterator;
  typedef std::reverse_iterator<iterator>        reverse_iterator;
  typedef std::reverse_iterator<const_iterator>  const_reverse_iterator;
    
  explicit transform_view() {}

  transform_view(ctor_arg_type& cont, const transform_type& tr)
    : base(cont), trans(tr) {}
  

  const_iterator begin() const { return const_iterator(trans,base.cont().begin()); }
  const_iterator end()   const { return const_iterator(trans,base.cont().end()); }
  iterator begin() { return iterator(trans,base.cont().begin()); }
  iterator end()   { return iterator(trans,base.cont().end()); }

  size_type size() const { return base.cont().size(); }
  size_type max_size() const { return base.cont().max_size(); }
  bool empty() const { return base.cont().empty(); }

  // front() and back() only work with sequences.
  const_reference front() const { return trans(base.cont().front()); }
  const_reference back()  const { return trans(base.cont().back()); }
  reference front() { return trans(base.cont().front()); }
  reference back()  { return trans(base.cont().back()); }

  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator rend()   const { return const_reverse_iterator(begin()); }
  reverse_iterator rbegin() { return reverse_iterator(end()); }
  reverse_iterator rend()   { return reverse_iterator(begin()); }


  // operator[]() and at()  work only with random access containers.
  const_reference operator[](size_type n) const { return trans(base.cont()[n]); }
  reference       operator[](size_type n)       { return trans(base.cont()[n]); }
  const_reference at(size_type n) const { range_check(n); return (*this)[n]; }
  reference       at(size_type n)       { range_check(n); return (*this)[n]; }


  // pop_front and pop_back only work with sequences
  void pop_front() { base.cont().pop_front(); }
  void pop_back() { base.cont().pop_back(); }

  void swap(transform_view& b) {
	std::swap(base,b.base);
	std::swap(trans,b.trans);
  }
    
protected:
  base_t base;
  transformation trans;

private:
  void range_check(size_type n) const {
    if (n < 0 || n >= size()) throw std::range_error("transform_view");
  }
};



//
// Global comparator operations.
//

template <class container_1,class container_2,
          class transformation_1,class transformation_2,
          class const_tag_1,class const_tag_2,
          class T_1,class T_2,
          template<class C, class const_tag> class proxy_template_1,
		  template<class C, class const_tag> class proxy_template_2>
bool operator==(transform_view<container_1,transformation_1,const_tag_1,T_1,proxy_template_1> const & lhs,
		transform_view<container_2,transformation_2,const_tag_2,T_2,proxy_template_2> const & rhs) {
	return lhs.size() == rhs.size() && std::equal(lhs.begin(), lhs.end(), rhs.begin());
}


template <class container_1,class container_2,
          class transformation_1,class transformation_2,
          class const_tag_1,class const_tag_2,
          class T_1,class T_2,
          template<class C, class const_tag> class proxy_template_1,
		  template<class C, class const_tag> class proxy_template_2>
bool operator<(transform_view<container_1,transformation_1,const_tag_1,T_1,proxy_template_1> const & lhs,
               transform_view<container_2,transformation_2,const_tag_2,T_2,proxy_template_2> const & rhs) {
	return std::lexicographical_compare(lhs.begin(), lhs.end(), rhs.begin(), rhs.end());
}
END_VIEW_NAMESPACE

//
// The swap function
//
namespace std {
template <class container,
          class transformation,
          class const_tag,
          class T,
          template<class C, class tag> class proxy_template>
void swap(VIEW_NAMESPACE::transform_view<container,transformation,const_tag,T,proxy_template>& a,
	  VIEW_NAMESPACE::transform_view<container,transformation,const_tag,T,proxy_template>& b) {
  a.swap(b);
}
};

#endif	// _TRANSFORM_VIEW_H
// $Id: transform_view.h,v 1.5 1999/09/17 16:28:02 bzfweise Exp $
