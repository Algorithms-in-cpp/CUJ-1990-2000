/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_SYMMETRIC_DIFFERENCE_VIEW_H)
#define _SYMMETRIC_DIFFERENCE_VIEW_H	1

#if !defined(_FILTER_VIEW_H)
#include "filter_view.h"
#endif

#if !defined(_UNION_VIEW_H)
#include "union_view.h"
#endif

#if !defined(_STL_TRAITS_H)
#include "stl_traits.h"
#endif

#if !defined(_FUNCTORS_H)
#include "functors.h"
#endif

#if !defined(_AWITHOUTB_VIEW_H)
#include "difference_view.h"
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

#if !defined(_SYS_LIBRARY_ALGORITHM_)
#include <algorithm>
#define _SYS_LIBRARY_ALGORITHM_
#endif

BEGIN_VIEW_NAMESPACE

// typedefs to make it easier to define the symmetric_difference_view.
template<
	class container_a,
	class container_b,
	class const_tag,
	class iterator_tag,
	template <class C, class tag> class proxy_template_a,
	template <class C, class tag> class proxy_template_b
	>
// Not really a namespace but that's all I'm using it for.
class symmetric_difference_namespace
{
private:
  typedef two_containers_base<container_a,container_b,const_tag,
								proxy_template_a,proxy_template_b> base_t;
  // Integrate the const_tag into the container types.
  typedef typename view_traits<container_a,const_tag>::container_type domain_a;
  typedef typename view_traits<container_b,const_tag>::container_type domain_b;
	// Define a difference_view of container_a which excludes any members
	// found in b.
	typedef difference_view<domain_a,domain_b,const_tag,iterator_tag,view_ref,view_ref> aWithoutb_view;

	// Define a difference_view of container_b which excludes any members
	// found in a.
	typedef difference_view<domain_b, domain_a,const_tag,iterator_tag,view_ref,view_ref> bWithouta_view;

	// Define a union_view of the two filtered views.
	// Since each filtered view excludes the members found in the other
	// view, this will be a symmetric_difference_view.
	typedef union_view<aWithoutb_view,bWithouta_view,const_tag,
		iterator_tag,view_own,view_own> base_view;
protected:
	// There is this one more layer so we don't have to export out
	// all of the typedefs we set up in symmetric_difference_namespace.
	class view : private base_t, public base_view
	{
	public:
		explicit view() {}
		view(domain_a &cont_a, domain_b &cont_b)
		  : base_t(cont_a,cont_b),
		  base_view(aWithoutb_view(a(),b()),
					bWithouta_view(b(),a())
			      )
	    {}
	};

};

// Specialization for view_ref proxy.
template<
	class container_a,
	class container_b,
	class const_tag,
	class iterator_tag>
class symmetric_difference_namespace < container_a,container_b,const_tag,iterator_tag,view_ref,view_ref>
{
private:
  // Integrate the const_tag into the container types.
  typedef typename view_traits<container_a,const_tag>::container_type domain_a;
  typedef typename view_traits<container_b,const_tag>::container_type domain_b;
	// Define a difference_view of container_a which excludes any members
	// found in b.
	typedef difference_view<domain_a,domain_b,const_tag,iterator_tag,view_ref,view_ref> aWithoutb_view;

	// Define a difference_view of container_b which excludes any members
	// found in a.
	typedef difference_view<domain_b, domain_a,const_tag,iterator_tag,view_ref,view_ref> bWithouta_view;

	// Define a union_view of the two filtered views.
	// Since each filtered view excludes the members found in the other
	// view, this will be a symmetric_difference_view.
	typedef union_view<aWithoutb_view,bWithouta_view,const_tag,
		iterator_tag,view_own,view_own> base_view;
protected:
	// There is this one more layer so we don't have to export out
	// all of the typedefs we set up in symmetric_difference_namespace.
	class view : public base_view
	{
	public:
		explicit view() {}
		view(domain_a &cont_a, domain_b &cont_b)
		  : base_view(aWithoutb_view(cont_a,cont_b),
					bWithouta_view(cont_b,cont_a)
			      )
	    {}
	};

};


//
// symmetric_difference_view
//
// All the elements that are in container_a and container_b but not both.
//
// Note: This is not particularly efficient in speed, because we visit
//       every element of each container. However it does not require
//       either container to be sorted. If either container has a builtin
//       find fn it will be used.
template<
	class container_a,
	class container_b,
	class const_tag = const_view_tag,
	class iterator_tag = typename combine_iterator_tags<typename container_a::iterator,
	                                                    typename container_b::iterator>::type,
	template <class C, class tag> class proxy_template_a = view_ref,
	template <class C, class tag> class proxy_template_b = view_ref>
class symmetric_difference_view 
  : public symmetric_difference_namespace<container_a,container_b,const_tag,
				iterator_tag,proxy_template_a,proxy_template_b>::view
{
public:
  typedef symmetric_difference_namespace<container_a,container_b,const_tag,
				iterator_tag,proxy_template_a,proxy_template_b>::view inherited;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;


  explicit symmetric_difference_view() {}
  symmetric_difference_view(ctor_arg_type_a &a_cont, ctor_arg_type_b &b_cont)
	  : inherited(a_cont, b_cont) 
	{}
};

END_VIEW_NAMESPACE

#endif // _SYMMETRIC_DIFFERENCE_VIEW_H
