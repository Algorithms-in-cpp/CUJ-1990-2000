/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined (_REFERENCE_PAIR_H)
#define _REFERENCE_PAIR_H	1

#if !defined(_VIEW_TRAITS_H)
#include "view_traits.h"
#endif

BEGIN_VIEW_NAMESPACE
// We have our own "pair" class because we are dealing with
// references to objects and I don't want copies. Also pair<>
// uses  const &T1, thus if T1 is already a reference, we get
// a reference to a reference, otherwise known as a compile time error.
template <class T1, class T2>
struct reference_pair {
  typedef T1 first_type;
  typedef T2 second_type;

  T1 first;
  T2 second;

  typedef reference_traits<T1>::type first_argument;
  typedef reference_traits<T2>::type second_argument;

  reference_pair() : first(T1()), second(T2()) {}
  reference_pair(first_argument a,second_argument b) : first(a), second(b) {}
};

template <class _T1, class _T2,
          class _T3, class _T4>
inline bool operator==(const reference_pair<_T1, _T2>& __x, const reference_pair<_T3, _T4>& __y)
{ 
  return __x.first == __y.first && __x.second == __y.second; 
}

template <class _T1, class _T2,
          class _T3, class _T4>
inline bool operator<(const reference_pair<_T1, _T2>& __x, const reference_pair<_T3, _T4>& __y)
{ 
  return __x.first < __y.first || 
         (!(__y.first < __x.first) && __x.second < __y.second); 
}

template <class _T1, class _T2>
inline reference_pair<_T1, _T2> make_reference_pair(const _T1 __x, const _T2 __y)
{
  return reference_pair<_T1, _T2>(__x, __y);
}

END_VIEW_NAMESPACE

#endif	// __REFERENCE_PAIR_H
