/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#ifndef _MERGE_VIEW_H
#define _MERGE_VIEW_H	1

#if !defined(_TWO_CONTIANERS_BASE_H)
#include "two_containers_base.h"
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

#if !defined(_SYS_LIBRARY_CASSERT_)
#include <cassert>
#define _SYS_LIBRARY_CASSERT_
#endif


// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp>
	void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool equal(_InputIter1, _InputIter1,
                  _InputIter2);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE
//
// A merge_iterator template
//

template <class iter_t_a, class iter_t_b, class range_t>
struct merge_iterator_traits {
  typedef combine_iterator_tags<iter_t_a,iter_t_b>::type tmp1;
  typedef combine_iterator_categories<tmp1,typename range_t::iterator_category>::type tmp2;
  typedef combine_iterator_categories<tmp2,bidirectional_iterator_tag>::type iterator_category;
};


template <class iter_t_a, class iter_t_b,
          class precedes_fn,
          class range_t >
class merge_iterator
  : public std::iterator<typename merge_iterator_traits<iter_t_a,iter_t_b,range_t>::iterator_category,
                    std::iterator_traits<iter_t_a>::value_type,
                    std::iterator_traits<iter_t_a>::difference_type,
                    std::iterator_traits<iter_t_a>::pointer,
                    combine_const_ref<std::iterator_traits<iter_t_a>::reference,
                    std::iterator_traits<iter_t_b>::reference>::type > {
public:

  // Iterators must be default constructible.
  merge_iterator() {}
  
  // view is intentionally non-const, so that range is correctly constructed.
  template<class view>
  merge_iterator(view& v,
		 const iter_t_a& iter_a_, const iter_t_b& iter_b_, 
		 const precedes_fn & comp)
    : range(v), iter_a(iter_a_), iter_b(iter_b_), precedes(comp) {}

  merge_iterator(const range_t& range_,
		 const iter_t_a& iter_a_, const iter_t_b& iter_b_, 
		 const precedes_fn & comp)
    : range(range_), iter_a(iter_a_), iter_b(iter_b_), precedes(comp) {}
  
  
  const reference operator*() const {
    if (iter_a == range.end_a() ) return *iter_b;
    if (iter_b == range.end_b() ) return *iter_a;
    return precedes(*iter_a, *iter_b)? *iter_a: *iter_b; }
  reference operator*() {
    if (iter_a == range.end_a() ) return *iter_b;
    if (iter_b == range.end_b() ) return *iter_a;
    return precedes(*iter_a, *iter_b)? *iter_a: *iter_b; }
  const pointer operator->() const {
    if (iter_a == range.end_a() ) return iter_b.operator->();
    if (iter_b == range.end_b() ) return iter_a.operator->();
    return precedes(*iter_a, *iter_b)? iter_a.operator->(): iter_b.operator->(); }
  pointer operator->() {
    if (iter_a == range.end_a() ) return iter_b.operator->();
    if (iter_b == range.end_b() ) return iter_a.operator->();
   return precedes(*iter_a, *iter_b)? iter_a.operator->(): iter_b.operator->(); }

  // Forward stepping.
  merge_iterator& operator++() {
    if (iter_a == range.end_a() ) ++iter_b;
    else if (iter_b == range.end_b() ) ++iter_a;
    else if(precedes(*iter_a, *iter_b)) ++iter_a;
    else ++iter_b; 
    return *this; }
  merge_iterator operator++(int) {
    merge_iterator tmp=*this; ++*this; return tmp; }

  // Backward stepping. This works only with bidirectional iterators.
  merge_iterator& operator--() {
    if (iter_a == range.begin_a() ) --iter_b;
    else if (iter_b == range.begin_b() ) --iter_a;
    else {
      // avoiding *(iter - 1) allows us to use non random access containers.
      iter_t_a tmp_a = iter_a;
      --tmp_a;
      iter_t_b tmp_b = iter_b;
      --tmp_b;
      
      if (precedes(*tmp_a, *tmp_b) ) iter_b = tmp_b; else iter_a = tmp_a; 
    }
    return *this; }
  merge_iterator operator--(int) {
    merge_iterator tmp=*this; --*this; return tmp; }

  difference_type operator-(const merge_iterator& y ) const {
    // Check that the two iterators are comparable.
    assert(comparable(*this,y));
    if (*this < y) return -(distance(iter_a,y.iter_a) + distance(iter_b,y.iter_b));
    else           return distance(y.iter_a,iter_a) + distance(y.iter_b,iter_b);

  }
    
  // Comparisons
  template <class iter_a_2, class iter_b_2, class range_t_2>
  bool operator==(const merge_iterator<iter_a_2,iter_b_2,precedes_fn,range_t_2>& rhs) const {
    return iter_a==rhs.iter_a && iter_b==rhs.iter_b; }

  template <class iter_a_2, class iter_b_2, class range_t_2>
  bool operator<(const merge_iterator<iter_a_2,iter_b_2,precedes_fn,range_t_2>& rhs) const {
    return iter_a<rhs.iter_a || iter_b<rhs.iter_b; }

  // Conversion from iterator to const_iterator. This works only if
  // there is a conversion from iter_t to const_iter.
  template <class const_iter_a, class const_iter_b, class const_range_t>
  operator merge_iterator<const_iter_a,const_iter_b,precedes_fn,const_range_t>() const {
    return merge_iterator<const_iter_a,const_iter_b,precedes_fn,const_range_t>(range,iter_a,iter_b,precedes); }
  
protected:
  range_t range;
  iter_t_a iter_a;
  iter_t_b iter_b;
  precedes_fn precedes;

private:
  // Gary: I added the comparable invariant during testing operator-().
  //       Don't know if we should let it here.
  // run time check for comparable iterators.
  // Each two iterators belonging to the same view should satisfy the following invariance.
  bool comparable(merge_iterator const& x, merge_iterator const& y) const {
    return (x.iter_a >= y.iter_a || y.iter_b >= x.iter_b) 
      && (y.iter_a >= x.iter_a || x.iter_b >= y.iter_b);
  }

  template <class iter_a_2, class iter_b_2, class precedes_fn_2, class range_t_2>
  friend class merge_iterator;
};

//
// A merge_view.
//
// A view with two sorted containers, where an iterator will
// return the next in order item.
//
// The iterators for the iter_base template can be const_iterators, since they
// only mark the ranges.
//
template <class container_a, class container_b,
          class precedes_fn = std::less<typename container_a::value_type>,
          class const_tag = const_view_tag,
		  class iterator_tag = typename combine_iterator_tags<typename container_a::iterator,
								                              typename container_b::iterator>::type,
          template<class container, class const_tag> class proxy_template_a = view_ref,
          template<class container, class const_tag> class proxy_template_b = view_ref>
class merge_view {
public:
  typedef typename container_a::value_type value_type;
  typedef typename container_a::pointer pointer;
  typedef typename container_a::reference reference;
  typedef typename container_a::const_reference const_reference;
  typedef typename container_a::size_type size_type;
  typedef typename container_a::difference_type difference_type;
  
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;
  typedef view_traits<container_a,const_tag>::container_type domain_a_type;
  typedef view_traits<container_a,const_tag>::iterator domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::container_type domain_b_type;
  typedef view_traits<container_b,const_tag>::iterator domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;
  typedef two_containers_base<domain_a_type,domain_b_type,const_tag,
					proxy_template_a,proxy_template_b> base_t;

  typedef internal_two_range_traits<iterator_tag, container_a, container_b,const_tag>::type	        iter_base;
  typedef internal_two_range_traits<iterator_tag, container_a, container_b,const_tag>::const_type	const_iter_base;

  typedef merge_iterator<domain_a_iterator,domain_b_iterator,precedes_fn,iter_base> iterator;
  typedef merge_iterator<domain_a_const_iterator,domain_b_const_iterator,
    precedes_fn,const_iter_base> const_iterator;
  typedef std::reverse_iterator<iterator> reverse_iterator;
  typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

  explicit merge_view() {}

  merge_view(ctor_arg_type_a& cont_a, ctor_arg_type_b& cont_b, const precedes_fn &comp = precedes_fn())
    : base(cont_a,cont_b),
      precedes(comp)
  {}

  const_iterator begin() const {
    return const_iterator(base,base.a().begin(),base.b().begin(), precedes); }
  const_iterator end() const {
    return const_iterator(base,base.a().end(),base.b().end(), precedes); }
  iterator begin() {
    return iterator(base,base.a().begin(),base.b().begin(), precedes); }
  iterator end() {
    return iterator(base,base.a().end(),base.b().end(), precedes); }

  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator rend() const { return const_reverse_iterator(begin()); }
  reverse_iterator rbegin() { return reverse_iterator(end()); }
  reverse_iterator rend() { return reverse_iterator(begin()); }

  size_type size() const { return base.a().size()+base.b().size(); }
  size_type max_size() const {
    // Here comes a hack against overflow problems. Not really satisfactory, though.
    size_type sum = base.a().max_size()+base.b().max_size();
    size_type maximum = max(base.a().max_size(),base.b().max_size());
    return max(sum,maximum);
  }
  bool empty() const { return base.a().empty() && base.b().empty(); }

  void swap(merge_view &rhs)
  {
	  std::swap(precedes, rhs.precedes);
	  std::swap(base,rhs.base);
  }
protected:
  base_t base;
  precedes_fn precedes;
};


//
// Global precedes_fn operations.
//
template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
          class precedes_fn_1, class precedes_fn_2,
          class const_tag_1, class const_tag_2,
          class iterator_tag_1, class iterator_tag_2,
          template<class container, class const_tag> class proxy_template_a_1,
          template<class container, class const_tag> class proxy_template_b_1,
          template<class container, class const_tag> class proxy_template_a_2,
          template<class container, class const_tag> class proxy_template_b_2>
bool operator==(merge_view<container_a_1,container_b_1,
		precedes_fn_1,const_tag_1,iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const & rhs,
		merge_view<container_a_2,container_b_2,
		precedes_fn_2,const_tag_2,iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const & lhs) {
  return rhs.size() == lhs.size() && std::equal(rhs.begin(), rhs.end(), lhs.begin());
}

template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
          class precedes_fn_1, class precedes_fn_2,
          class const_tag_1, class const_tag_2,
          class iterator_tag_1, class iterator_tag_2,
          template<class container, class const_tag> class proxy_template_a_1,
          template<class container, class const_tag> class proxy_template_b_1,
          template<class container, class const_tag> class proxy_template_a_2,
          template<class container, class const_tag> class proxy_template_b_2>
bool operator<(merge_view<container_a_1,container_b_1,
	       precedes_fn_1,const_tag_1,iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const & rhs,
	       merge_view<container_a_2,container_b_2,
	       precedes_fn_2,const_tag_2,iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const & lhs) {
  return std::lexicographical_compare(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}

END_VIEW_NAMESPACE

//
// The swap function
//

namespace std { 
template <class container_a,class container_b,
          class precedes_fn,
          class const_tag,
		  class iterator_tag,
          template<class container, class const_tag> class proxy_template_a,
          template<class container, class const_tag> class proxy_template_b>
void swap(VIEW_NAMESPACE::merge_view<container_a,container_b,
		precedes_fn,const_tag,iterator_tag,proxy_template_a,proxy_template_b> const & a,
		VIEW_NAMESPACE::merge_view<container_a,container_b,
		precedes_fn,const_tag,iterator_tag,proxy_template_a,proxy_template_b> const & b) {
  a.swap(b);
}
};
#endif	// _MERGE_VIEW_H
