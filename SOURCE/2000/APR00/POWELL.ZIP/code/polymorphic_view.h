/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#if !defined(_POLYMORPHIC_VIEW_H)
#define _POLYMORPHIC_VIEW_H 1

#if !defined(_VIEW_TRAITS_H)
#include "view_traits.h"
#endif 

#if !defined(_TRANSFORM_VIEW_H)
#include "transform_view.h" 
#endif

#if !defined(_FUNCTORS_H)
#include "functors.h"
#endif
  
BEGIN_VIEW_NAMESPACE
//
// A polymorphic view.
//

template <class container,
          class const_tag = const_view_tag,
          template <class C, class tag> class proxy_template = view_ref>
class polymorphic_view
  : public transform_view<container,
                          dereference<const_traits<typename container::value_type>::type>,
                          const_tag,                                            
                          dereference<const_traits<typename container::value_type>::type>::result_type,
                          proxy_template> {
public:
  typedef dereference<const_traits<typename container::value_type>::type> transform_type;
  typedef transform_view<container,transform_type,const_tag,transform_type::result_type,proxy_template> inherited;

  // containers have to be default constructible
  explicit polymorphic_view() {}
  
  explicit polymorphic_view(inherited::ctor_arg_type& cont)
    : inherited(cont,transform_type()) {}
};

END_VIEW_NAMESPACE
#endif
// $Id: polymorphic_view.h,v 1.2 1999/09/13 09:53:15 bzfweise Exp $ 
