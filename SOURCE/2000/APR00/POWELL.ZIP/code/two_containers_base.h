/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined (_TWO_CONTIANERS_BASE_H)
#define _TWO_CONTIANERS_BASE_H	1

#if !defined(_VIEW_BASE_H)
#include "view_base.h"
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif



// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp>
	void swap(_Tp&, _Tp&);
};

BEGIN_VIEW_NAMESPACE
//
// A data containing base class for two container views that can be
// easily referenced by iterators without infinite template recursion.
//


template <class container_a, class container_b,
          class const_tag,
          template<class container, class const_tag> class proxy_template_a,
          template<class container, class const_tag> class proxy_template_b >
class two_containers_base {
public:
    typedef proxy_template_a<container_a,const_tag> inherited_a;
    typedef proxy_template_b<container_b,const_tag> inherited_b;
    typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
    typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;

	// used by two_containers_base_ref.
    typedef view_traits<container_a,const_tag>::container_type domain_type_a;
    typedef view_traits<container_b,const_tag>::container_type domain_type_b;
    
	typedef typename view_traits<container_a,const_tag>::iterator domain_a_iterator;
	typedef typename view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
	typedef typename view_traits<container_b,const_tag>::iterator domain_b_iterator;
	typedef typename view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;
    typedef typename domain_type_a::size_type size_type_a;
    typedef typename domain_type_b::size_type size_type_b;

    // References of ctor_arg_type_[ab] are intentionally non const.
    // There may be a non const reference to the container wanted.
    // See view_base.h for a more detailed discussion.
    two_containers_base(ctor_arg_type_a& cont_a, ctor_arg_type_b& cont_b)
      : proxy_a(cont_a), proxy_b(cont_b) {}

    // Default constructible. Be careful! A default constructed two_containers_base
    // has a completely undefined behavior, the only exception being
    // assignment.
    explicit two_containers_base() {}

    domain_type_a& a() { return proxy_a.cont(); }
    const domain_type_a& a() const { return proxy_a.cont(); }

    domain_type_b& b() { return proxy_b.cont(); }
    const domain_type_b& b() const { return proxy_b.cont(); }


	domain_a_iterator begin_a()  { return proxy_a.cont().begin(); }
	domain_a_const_iterator begin_a() const { return proxy_a.cont().begin(); }
	domain_b_iterator begin_b()  { return proxy_b.cont().begin(); }
	domain_b_const_iterator begin_b() const { return proxy_b.cont().begin(); }

	domain_a_iterator end_a()  { return proxy_a.cont().end(); }
	domain_a_const_iterator end_a() const { return proxy_a.cont().end(); }
	domain_b_iterator end_b()  { return proxy_b.cont().end(); }
	domain_b_const_iterator end_b() const { return proxy_b.cont().end(); }
    
    size_type_a size_a() const { return proxy_a.cont().size(); }
    size_type_b size_b() const { return proxy_b.cont().size(); }


    void swap(two_containers_base& u) { std::swap(proxy_a,u.proxy_a); std::swap(proxy_b,u.proxy_b); }    

protected:
    inherited_a proxy_a;
    inherited_b proxy_b;
};

//
// Range classes for two container iterators that either reference a two_containers_base
// or contain ordering and range end iterators.
//
template <class base, class iter_t_a, class iter_t_b>
class two_containers_base_ref {
public:
  typedef typename base::domain_type_a::size_type size_type_a;
  typedef typename base::domain_type_b::size_type size_type_b;

  // Default constructible. Be careful! A default constructed two_containers_base_ref
  // has a completely undefined behavior, the only exception being
  // assignment.
  explicit two_containers_base_ref() {}

  two_containers_base_ref(base& u_)
    : u(&u_) {}

  // We are using the default copy constructor and assignment operator.

  template <class const_base, class const_iter_a_type, class const_iter_b_type>
  operator two_containers_base_ref<const_base,const_iter_a_type,const_iter_b_type>() const {
    return two_containers_base_ref<const_base,const_iter_a_type,const_iter_b_type>(*u); }
  
  // constant conversion.
  template <class const_iter_a, class const_iter_b>
  two_containers_base_ref(two_containers_base_ref<base,const_iter_a,const_iter_b>& ubr)
    : u(ubr.u) {}

  iter_t_a begin_a() const { return u->begin_a(); }
  iter_t_a end_a() const { return u->end_a(); }
  
  iter_t_b begin_b() const { return u->begin_b(); }
  iter_t_b end_b() const { return u->end_b(); }

  size_type_a size_a() const { return u->size_a(); }
  size_type_b size_b() const { return u->size_b(); }
  
protected:
  base* u;
};


// unidirectional_base_containers_range_own
//
// For use with single direction view. For bidirectional
// use two_containers_range_own.
template <class iter_t_a, class iter_t_b>
class unidirectional_base_containers_range_own {
public:
  typedef combine_three_iterator_tags<iter_t_a, 
				      iter_t_b, 
				      forward_iterator<iterator_traits<iter_t_a>::value_type,
                                      iterator_traits<iter_t_a>::difference_type> >::type iterator_category;

  // Copy constructor from base with const iterators.
  template<class const_iter_t_a, class const_iter_t_b>
  unidirectional_base_containers_range_own(unidirectional_base_containers_range_own<const_iter_t_a,
                                                                                    const_iter_t_b> const& u)
    : stop_a(u.end_a()),
      stop_b(u.end_b()) {}

  // References of base are intentionally non const.
  // There may be a non const reference to the container wanted.
  // If a const base is given, this is handled by the template
  // constructor as well.
  template<class base>
  explicit unidirectional_base_containers_range_own(base& u)
    : stop_a(u.end_a()),
      stop_b(u.end_b()) {}

  template<class const_iter_t_a, class const_iter_t_b>
  unidirectional_base_containers_range_own(const const_iter_t_a& stop_a_,
                                           const const_iter_t_b& stop_b_)
    : stop_a(stop_a_), stop_b(stop_b_) {}

  // Default constructible. Be careful! A default constructed
  // merge_containers_range_own has a completely undefined behavior,
  // the only exception being assignment.
  explicit unidirectional_base_containers_range_own() {}

  iter_t_a end_a() const { return stop_a; }
  iter_t_b end_b() const { return stop_b; }

protected:
  iter_t_a stop_a;
  iter_t_b stop_b;
};

template <class iter_t_a, class iter_t_b>
class two_containers_range_own
: public unidirectional_base_containers_range_own<iter_t_a, iter_t_b>
{
public:
  typedef unidirectional_base_containers_range_own<iter_t_a, iter_t_b> inherited;
  typedef combine_three_iterator_tags<iter_t_a, 
				      iter_t_b, 
				      bidirectional_iterator<iterator_traits<iter_t_a>::value_type,
				      iterator_traits<iter_t_a>::difference_type> >::type iterator_category;

  // Copy constructor from base with const iterators.
  template<class const_iter_t_a, class const_iter_t_b>
  two_containers_range_own(two_containers_range_own<const_iter_t_a, const_iter_t_b> const& u)
    :	inherited(u.end_a(), u.end_b()), start_a(u.begin_a()), start_b(u.begin_b()) {}

  // References of base are intentionally non const.
  // There may be a non const reference to the container wanted.
  // If a const base is given, this is handled by the template
  // constructor as well.
  template<class base>
  explicit two_containers_range_own(base& u)
    : inherited(u), start_a(u.begin_a()), start_b(u.begin_b()) {}

  // Default constructible. Be careful! A default constructed
  // two_containers_range_own has a completely undefined behavior, the
  // only exception being assignment.
  explicit two_containers_range_own() {}


  const iter_t_a begin_a() const { return start_a; }
  const iter_t_b begin_b() const { return start_b; }

  size_t size_a() const { return std::distance(begin_a(),end_a()); }
  size_t size_b() const { return std::distance(begin_b(),end_b()); }

protected:
  iter_t_a start_a;
  iter_t_b start_b;
};


//
// Traits mapping a pair of iterator categories to the smallest xxx_range_own
// range that does not artificailly limit the possibilities of the
// iterator it's based on.
//

template <class iterator_category, class container_a, class container_b, class const_tag>
struct internal_two_range_traits { 
  typedef view_traits<container_a,const_tag>::iterator       domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::iterator       domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;

  typedef unidirectional_base_containers_range_own<domain_a_iterator,
													domain_b_iterator>      type; 
  typedef unidirectional_base_containers_range_own<domain_a_const_iterator,
													domain_b_const_iterator> const_type; 
};

template <class container_a, class container_b, class const_tag>
struct internal_two_range_traits<std::bidirectional_iterator_tag, container_a, container_b, const_tag> {
  typedef view_traits<container_a,const_tag>::iterator       domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::iterator       domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;

  typedef two_containers_range_own<domain_a_iterator,
									domain_b_iterator>      type; 
  typedef two_containers_range_own<domain_a_const_iterator,
									domain_b_const_iterator> const_type; 
};

template <class container_a, class container_b, class const_tag>
struct internal_two_range_traits<std::random_access_iterator_tag, container_a, container_b, const_tag> {
  typedef view_traits<container_a,const_tag>::iterator       domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::iterator       domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;

// This specialization may be wrong, I'm not sure but I think we should be using the
// two_containers_base_ref GWP.
  typedef two_containers_range_own<domain_a_iterator,
									domain_b_iterator>      type; 
  typedef two_containers_range_own<domain_a_const_iterator,
									domain_b_const_iterator> const_type; 
};

template <class container_a, class container_b, class const_tag>
struct two_containers_range_traits {
  typedef combine_iterator_tags<typename container_a::iterator,
								typename container_b::iterator>::type category;
 
  typedef internal_two_range_traits<category,container_a,container_b,const_tag>::type type; 
};

END_VIEW_NAMESPACE

//
// The swap function
//
namespace std {
template <class container_a, class container_b,
  class const_tag,
  template<class container, class const_tag> class base_a,
  template<class container, class const_tag> class base_b >
void swap(VIEW_NAMESPACE::two_containers_base<container_a,container_b,const_tag,base_a,base_b>& a,
	  VIEW_NAMESPACE::two_containers_base<container_a,container_b,const_tag,base_a,base_b>& b) {
  a.swap(b);
}
};

#endif	// __TWO_CONTIANERS_BASE_H
