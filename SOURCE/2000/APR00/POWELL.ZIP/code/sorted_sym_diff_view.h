/* -*- c++ -*-
 * Copyright (c) 1999  
 * Gary Powell, Martin Weiser 
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *
 */
#ifndef _SORTED_SYM_DIFF_VIEW_H
#define _SORTED_SYM_DIFF_VIEW_H	1

#if !defined(_SORTED_DIFFERENCE_VIEW_H)
#include "sorted_difference_view.h"
#endif

#if !defined(_MERGE_VIEW_H)
#include "merge_view.h"
#endif

BEGIN_VIEW_NAMESPACE

// definition of the base, but no implementation,
// just the two specializations.
template<class container_a, class container_b,
	  class comparator,
	  class const_tag,
	  class iterator_tag,
	  template<class container, class const_tag> class proxy_template_a,
	  template<class container, class const_tag> class proxy_template_b
	  >
// Not really a namespace but that's all I'm using it for.
class sorted_symmetrical_difference_namespace
{
private:
  typedef typename view_traits<container_a,const_tag>::container_type domain_a;
  typedef typename view_traits<container_b,const_tag>::container_type domain_b;
  // Define a filter_view of container_a which excludes any members
  // found in b.
  typedef sorted_difference_view<domain_a,domain_b,
            comparator,const_tag,iterator_tag,proxy_template_a, proxy_template_b> aWithoutb_view;

  // Define a filter_view of container_b which excludes any members
  // found in a.
  typedef sorted_difference_view<domain_b, domain_a,
            comparator, const_tag,iterator_tag,proxy_template_b, proxy_template_a> bWithouta_view;

  // Define a merge_view of the two filtered views.
  // Since each filtered view excludes the members found in the other
  // view, this will be a symmetric_difference_view.
  typedef merge_view<aWithoutb_view,bWithouta_view,
                     comparator,const_tag,iterator_tag,view_own,view_own> base_view;
protected:
  // There is this one more layer so we don't have to export out
  // all of the typedefs we set up in symmetric_difference_namespace.
  class view : public base_view
  {
  public:
    view(domain_a &a, domain_b &b, comparator const &c)
      : base_view(aWithoutb_view(a,b,c),
                  bWithouta_view(b,a,c))
    {}
  };
};



//
// A sorted_symmetrical_difference_view.
//
// A view with two sorted containers, where an iterator will
// return the next in order item which is in only one of the containers.
//
//
template <class container_a, class container_b,
	  class comparator = std::less<typename container_a::value_type>,
	  class const_tag = const_view_tag,
	  class iterator_tag = typename combine_iterator_tags<typename container_a::iterator,
								                          typename container_b::iterator>::type,
	  template<class container, class const_tag> class proxy_template_a = view_ref,
	  template<class container, class const_tag> class proxy_template_b = view_ref>
class sorted_symmetrical_difference_view
  : public sorted_symmetrical_difference_namespace<container_a,container_b,
				comparator,const_tag,iterator_tag,proxy_template_a,proxy_template_b>::view
{
public:
  typedef sorted_symmetrical_difference_namespace<container_a,container_b,
					comparator,const_tag,iterator_tag,proxy_template_a,proxy_template_b>::view inherited;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;

  explicit sorted_symmetrical_difference_view() {}
  sorted_symmetrical_difference_view(ctor_arg_type_a& cont_a, ctor_arg_type_b& cont_b,
                                     comparator const &comp = comparator())
    : inherited(cont_a, cont_b, comp) 
  {}
};

END_VIEW_NAMESPACE
#endif	// _SORTED_SYM_DIFF_VIEW_H
