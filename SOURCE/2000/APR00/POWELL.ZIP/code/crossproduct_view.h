/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined (_CROSSPRODUCT_VIEW_H)
#define _CROSSPRODUCT_VIEW_H	1

#if !defined(_VIEW_TRAITS_H)
#include "view_traits.h"
#endif

#if !defined(_TWO_CONTAINERS_BASE_H)
#include "two_containers_base.h"
#endif

#if !defined (_REFERENCE_PAIR_H)
#include "reference_pair.h"
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

#if !defined(_SYS_LIBRARY_STDEXCEPT_)
#include <stdexcept>
#define _SYS_LIBRARY_STDEXCEPT_
#endif

//
// A cross product iterator template
//


// forward declaration so we don't have to include <algorithm>
namespace std {

template <class _Tp> 
void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE
// Forward declare check_equal so that you don't have to include functors.h
template <class iter_t_1, class iter_t_2>
inline bool check_equal(iter_t_1, iter_t_1,
                  iter_t_2, iter_t_2);



template <class iter_t_a, class iter_t_b,
          template<class A, class B> class combinator,	// ref_pair
          class range_t>	
class crossproduct_iterator
: public std::iterator<combine_iterator_tags<iter_t_a,iter_t_b>::type,
                    combinator<std::iterator_traits<iter_t_a>::value_type,
			       std::iterator_traits<iter_t_b>::value_type>,
                    std::iterator_traits<iter_t_a>::difference_type,
                    combinator<std::iterator_traits<iter_t_a>::value_type,
		               std::iterator_traits<iter_t_b>::value_type>*,
                    combinator<std::iterator_traits<iter_t_a>::reference,
			       std::iterator_traits<iter_t_b>::reference> > 
{
public:
  typedef member_access_proxy<combinator<iter_t_a,iter_t_b> > ma_type;

  typedef std::iterator<combine_iterator_tags<iter_t_a,iter_t_b>::type,
		   combinator<std::iterator_traits<iter_t_a>::value_type,
			      std::iterator_traits<iter_t_b>::value_type>,
		   std::iterator_traits<iter_t_a>::difference_type,
		   combinator<std::iterator_traits<iter_t_a>::value_type,
			      std::iterator_traits<iter_t_b>::value_type>*,
		   combinator<std::iterator_traits<iter_t_a>::reference,
			      std::iterator_traits<iter_t_b>::reference> > inherited;
  typedef typename inherited::difference_type difference_type;
  typedef inherited::reference reference;
  typedef combinator<typename std::iterator_traits<iter_t_a>::reference const,
                     typename std::iterator_traits<iter_t_b>::reference const> const_reference;
  typedef typename inherited::pointer pointer;
  typedef const pointer const_pointer;
  
  // Iterators must be default constructible.
  explicit crossproduct_iterator() {}

  template<class view>
  crossproduct_iterator(view& v, iter_t_a const &iter_a_, iter_t_b const &iter_b_)
    : range(v), iter_a(iter_a_), iter_b(iter_b_) {}

  crossproduct_iterator(const range_t& range_, iter_t_a const &iter_a, iter_t_b const &iter_b_)
    : range(range_), iter_a(iter_a_), iter_b(iter_b_) {}
  
  const_reference operator*() const { return const_reference(*iter_a,*iter_b); }
  reference       operator*()       { return reference(*iter_a,*iter_b); }

  ma_type const operator->() const { return ma_type(const_reference(*iter_a,*iter_b)); }
  ma_type       operator->()       { return ma_type(reference(*iter_a,*iter_b)); }

  // Forward stepping.
  crossproduct_iterator& operator++() {
    ++iter_a; 
    if(iter_a==range.end_a()) {
      ++iter_b;
      iter_a = range.begin_a();
    }
    return *this; 
  }
  crossproduct_iterator operator++(int) {
    crossproduct_iterator tmp=*this; ++*this; return tmp; }

  // Backward stepping. This works only with bidirectional iterators.
  crossproduct_iterator& operator--() {	 
    if (iter_a==range.begin_a() || iter_b==range.end_b()) {
      --iter_b;
      iter_a = range.end_a();
    }
    --iter_a; 
    return *this; 
  }
  crossproduct_iterator operator--(int) {
    crossproduct_iterator tmp=*this; --*this; return tmp; }

  crossproduct_iterator& operator+=(difference_type n) {
	if (n < 0) return *this -= -n;

    difference_type a_dist = n % range.size_a();
    difference_type b_dist = (n-a_dist)/static_cast<difference_type>(range.size_a());

 	if (std::distance(iter_a,range.end_a()) <= a_dist) {
	++ b_dist;
	a_dist -= range.size_a();
      }
 
    std::advance(iter_a,a_dist);
    std::advance(iter_b,b_dist);
    return *this; 
  }

  crossproduct_iterator& operator-=(difference_type n) { 
	if (n < 0) return *this += -n;

    difference_type a_dist = n % range.size_a();
    difference_type b_dist = (n-a_dist)/static_cast<difference_type>(range.size_a());

    if (std::distance(range.begin_a(),iter_a) < a_dist) {
	  --b_dist;
	  a_dist -= range.size_a();
    }

	// Works only with bidirectional iterators!
    std::advance(iter_a,-a_dist);
    std::advance(iter_b,-b_dist);
    return *this; 
  }
  
  difference_type operator-(const crossproduct_iterator& y ) const {
    return distanceFromBegin()-y.distanceFromBegin();
  }

  crossproduct_iterator operator+(difference_type n) const {
    crossproduct_iterator tmp(*this);
    return tmp += n;
  }
  crossproduct_iterator operator-(difference_type n) const {
    crossproduct_iterator tmp(*this);
    return tmp -= n;
  }
  
  
  
  // Comparisons
  template <class iter_t_a_2, class iter_t_b_2, class range_t_2>
  bool operator==(const crossproduct_iterator<iter_t_a_2,iter_t_b_2,combinator,range_t_2>& rhs) const {
    return iter_a==rhs.iter_a && iter_b==rhs.iter_b; }

  template <class iter_t_a_2, class iter_t_b_2, class range_t_2>
  bool operator<(const crossproduct_iterator<iter_t_a_2,iter_t_b_2,combinator,range_t_2>& rhs) const  { 
   return distanceFromBegin() < rhs.distanceFromBegin();  }

  // Conversion from iterator to const_iterator. This works only if
  // there is a conversion from iter_t to const_iter and range_t to const_range_t.
  template <class const_iter_a, class const_iter_b, class const_range_t>
  operator crossproduct_iterator<const_iter_a,const_iter_b,combinator,const_range_t>() const {
    return crossproduct_iterator<const_iter_a,const_iter_b,combinator,const_range_t>(range,iter_a,iter_b); }

protected:
  range_t range;
  iter_t_a iter_a;
  iter_t_b iter_b;

private:
  // hacky distance from the begining calculation.
  difference_type distanceFromBegin() const {
    difference_type dist_this = std::distance(range.begin_a(),iter_a);
    dist_this += std::distance(range.begin_b(),iter_b) * range.size_a();
    return dist_this;
  }

  template <class iter_t_a_2, class iter_t_b_2,
            template<class A, class B> class combinator_2,
            class range_t_2>
  friend class crossproduct_iterator;

};

//
// A random access helper class
//
template <class view>
class random_access_helper {
public:
  typedef typename view::size_type size_type;
  
  random_access_helper(view& v_, size_type n_)
    : v(v_), n(n_) {}
  
  typename view::value_type operator[](size_type m) { return view(n,m); }
  
private:
  view& v;
  size_type n;
};

//
// A cross product view.
//
// The iterators for the iter_base template can be const_iterators, since they
// only mark the ranges.
//
template <class container_a, class container_b,
          class const_tag = const_view_tag,
          template<class A, class B> class combinator = reference_pair,
		  class iterator_tag = typename combine_iterator_tags<typename container_a::iterator,
								                              typename container_b::iterator>::type,
          template<class container, class const_tag> class proxy_template_a = view_ref,
          template<class container, class const_tag> class proxy_template_b = view_ref>
class crossproduct_view {
public:
  typedef combinator<typename container_a::value_type,
                     typename container_b::value_type> value_type;
  typedef typename container_a::pointer         pointer;
  typedef typename container_a::reference       reference;
  typedef typename container_a::const_reference const_reference;
  typedef typename container_a::size_type       size_type;
  typedef typename container_a::difference_type difference_type;
  
  typedef view_traits<container_a,const_tag>::container_type domain_type_a;
  typedef view_traits<container_b,const_tag>::container_type domain_type_b;
  typedef view_traits<container_a,const_tag>::iterator domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::iterator domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;

  typedef crossproduct_view<container_a,container_b,const_tag,combinator,iterator_tag,
			proxy_template_a,proxy_template_b> self;

  typedef two_containers_base<container_a,container_b,const_tag,proxy_template_a,proxy_template_b> base_t;

  typedef internal_two_range_traits<iterator_tag, container_a, container_b,const_tag>::type	        iter_base;
  typedef internal_two_range_traits<iterator_tag, container_a, container_b,const_tag>::const_type	const_iter_base;

  typedef crossproduct_iterator<domain_a_iterator,domain_b_iterator,combinator,iter_base> iterator;
  typedef crossproduct_iterator<domain_a_const_iterator,domain_b_const_iterator,
                                combinator,const_iter_base> const_iterator;
  typedef std::reverse_iterator<iterator> reverse_iterator;
  typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;

  explicit crossproduct_view() {}

  crossproduct_view(ctor_arg_type_a& cont_a, ctor_arg_type_b& cont_b)
    : base(cont_a,cont_b) {}

  const_iterator begin() const { return const_iterator(base,base.a().begin(),base.b().begin()); }
  const_iterator end() const   { return const_iterator(base,base.a().begin(),base.b().end()); }
  iterator       begin()       { return iterator(base,base.a().begin(),base.b().begin()); }
  iterator       end()         { return iterator(base,base.a().begin(),base.b().end()); }

  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator rend() const   { return const_reverse_iterator(begin()); }
  reverse_iterator       rbegin()       { return reverse_iterator(end()); }
  reverse_iterator       rend()         { return reverse_iterator(begin()); }

  size_type size() const { return base.a().size()*base.b().size(); }
  size_type max_size() const {
    // Here comes a hack against overflow problems. Not really satisfactory, though.
    size_type prod = base.a().max_size()*base.b().max_size();
    size_type maximum = std::max(base.a().max_size(),base.b().max_size());
    return max(prod,maximum);
  }
  bool empty() const { return base.a().empty() || base.b().empty(); }

  value_type operator()(size_type n, size_type m) const {
    return value_type(base.a()[n],base.b()[m]); }
  
  value_type at(size_type n, size_type m) const { 
    range_check(n, m);
    return value_type(base.a()[n],base.b()[m]); }
  
  typedef random_access_helper<value_type> random_access_helper_Type;

  random_access_helper_Type operator[](size_type n) {
    return random_access_helper_Type(*this,n); }

  void swap(crossproduct_view &rhs)
  { std::swap(base,rhs.base); }


protected:
  base_t base;

private:  
  void range_check(size_type n, size_type m) const {
	if (n < 0 || n >= base.a().size()) throw std::range_error("crossproduct_view");
    if (m < 0 || m >= base.b().size()) throw std::range_error("crossproduct_view");
  }
};


//
// Global comparator operations.
//
template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
          class const_tag_1, class const_tag_2,
          template<class A, class B> class combinator_1,
          template<class A, class B> class combinator_2,
          class iterator_tag_1, class iterator_tag_2,
          template<class container, class const_tag> class proxy_template_a_1,
          template<class container, class const_tag> class proxy_template_b_1,
          template<class container, class const_tag> class proxy_template_a_2,
          template<class container, class const_tag> class proxy_template_b_2>
bool operator==(crossproduct_view<container_a_1,container_b_1,const_tag_1,combinator_1,
				iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const& rhs,
                crossproduct_view<container_a_2,container_b_2,const_tag_2,combinator_2,
				iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const& lhs) {
  return check_equal(lhs.begin(), lhs.end(), rhs.begin(), rhs.end());
}

template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
          class const_tag_1, class const_tag_2,
          template<class A, class B> class combinator_1,
          template<class A, class B> class combinator_2,
          class iterator_tag_1, class iterator_tag_2,
          template<class container, class const_tag> class proxy_template_a_1,
          template<class container, class const_tag> class proxy_template_b_1,
          template<class container, class const_tag> class proxy_template_a_2,
          template<class container, class const_tag> class proxy_template_b_2>
bool operator<(crossproduct_view<container_a_1,container_b_1,const_tag_1,combinator_1,
			   iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const& rhs,
                crossproduct_view<container_a_2,container_b_2,const_tag_2,combinator_2,
				iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const& lhs) {
	return std::lexicographical_compare(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}

END_VIEW_NAMESPACE

namespace std {
//
// The swap function
//
template <class container_a,class container_b,
          class const_tag,
          template<class A, class B> class combinator,
		  class iterator_tag,
          template<class container, class const_tag> class proxy_template_a,
          template<class container, class const_tag> class proxy_template_b>
void swap(VIEW_NAMESPACE::crossproduct_view<container_a,container_b,const_tag,combinator,
		  iterator_tag,proxy_template_a,proxy_template_b> const& a,
          VIEW_NAMESPACE::crossproduct_view<container_a,container_b,const_tag,combinator,
		  iterator_tag,proxy_template_a,proxy_template_b> const& b) {
  a.swap(b);
}

};


#endif	// __CROSSPRODUCT_VIEW_H
