/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_DIFFERENCE_VIEW_H)
#define _DIFFERENCE_VIEW_H	1

#if !defined(_FILTER_VIEW_H)
#include "filter_view.h"
#endif

#if !defined(_UNION_VIEW_H)
#include "union_view.h"
#endif

#if !defined(_FUNCTORS_H)
#include "functors.h"
#endif

#if !defined(_STL_TRAITS_H)
#include "stl_traits.h"
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

#if !defined(_SYS_LIBRARY_ALGORITHM_)
#include <algorithm>	// for pair
#define _SYS_LIBRARY_ALGORITHM_
#endif

BEGIN_VIEW_NAMESPACE

// typedefs to make it easier to define the difference_view.
template <class container_a,
          class container_b,
          class const_tag,
		  class iterator_tag,
          template <class C, class tag> class proxy_template_a,
	      template <class C, class tag> class proxy_template_b>
// Not really a namespace but that's all I'm using it for.
class difference_view_namespace
{
private:
  typedef std::logical_not<bool> logical_not;
  // Integrate the const_tag into the container types.
  typedef typename view_traits<container_a,const_tag>::container_type domain_a;
  typedef typename view_traits<container_b,const_tag>::container_type domain_b;

  typedef match_element<container_b,container_a,const_tag,proxy_template_b> match_in_b_fn;
  typedef MyUnaryCompose<logical_not,match_in_b_fn> predicate_fn;
  
  // Define a filter_view of container_a which excludes any members
  // found in b.
  typedef filter_view<domain_a,predicate_fn,const_tag,iterator_tag,proxy_template_a> base_view;
  
  
protected:
  // There is this one more layer so we don't have to export out
  // all of the typedefs we set up in difference_namespace.
  class view : public base_view
  {
  public:
	explicit view() {}
    view(domain_a &a, domain_b &b)
      : base_view(a,predicate_fn(logical_not(),
                                 match_in_b_fn(b))
                  )
    {}
  };
  
};

//
// difference_view
//
// Non Symetrical Difference view.
// All the elements that are in A but not in B.
//
template<
	class container_a,
	class container_b,
	class const_tag = const_view_tag,
    class iterator_tag = typename std::iterator_traits<typename container_a::iterator>::iterator_category,
	template <class C, class tag> class proxy_template_a = view_ref,
	template <class C, class tag> class proxy_template_b = view_ref>
class difference_view 
  : public difference_view_namespace<container_a,container_b,const_tag,
		iterator_tag, proxy_template_a,proxy_template_b>::view
{
public:
  typedef difference_view_namespace<container_a,container_b,const_tag,
		iterator_tag,proxy_template_a,proxy_template_b>::view inherited;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;

  explicit difference_view() {}
	difference_view(ctor_arg_type_a &a_cont, ctor_arg_type_b &b_cont)
	  : inherited(a_cont, b_cont) 
	{}
};

END_VIEW_NAMESPACE

#endif // _DIFFERENCE_VIEW_H
