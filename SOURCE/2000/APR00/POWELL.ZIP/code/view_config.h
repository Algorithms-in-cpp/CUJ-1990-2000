/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#ifndef _VIEW_CONFIG_H
#define _VIEW_CONFIG_H

// GCC Has namespaces but 2.95 is broken.
//#if __GNUC__ <= 2 && __GNUC_MINOR__ <= 95
//#else
#define USE_VIEW_NAMESPACE 1
//#endif

#if defined(USE_VIEW_NAMESPACE)
#define VIEW_NAMESPACE      views
#define BEGIN_VIEW_NAMESPACE namespace VIEW_NAMESPACE {
#define END_VIEW_NAMESPACE };
#define USING_VIEW_NAMESPACE using namespace VIEW_NAMESPACE;
#else
#define VIEW_NAMESPACE
#define BEGIN_VIEW_NAMESPACE
#define END_VIEW_NAMESPACE
#define USING_VIEW_NAMESPACE
#endif


#endif // _VIEW_CONFIG_H
