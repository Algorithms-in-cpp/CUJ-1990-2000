/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_FUNCTORS_H)
#define _FUNCTORS_H	1

#if !defined(_RANGE_H)
#include "range.h"
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

// Forward declarations
// Note: These are declared so you are not required to have
//       multiple includes if you are not using some portion of these
//       functors. 
namespace std {
template <class IteratorType, class element_type>
IteratorType find(IteratorType, IteratorType, element_type const &); // from <algorithm>

template <class T1, class T2>
struct pair;				// from <algorithm>

template <class T>
struct iterator_traits;	// from <iterator>
};

BEGIN_VIEW_NAMESPACE

template <class T>
struct deconst_traits;	// from "view_traits.h"

// Forward declarations of classes defined in stl_traits.h
template<class container>
class ContainerTrait;		// From "stl_traits.h"

class InternalFindElement;
class NoInternalFindElement;
class PairInternalEqualRange;
class KeyDataPair;
class NotKeyDataPair;


//
// is_nonzero
//
// true if the item is non zero.
//
//
template <class T>
class is_nonzero: public std::unary_function<T const, bool> {
public:
  bool operator()(T const& t) const { return t != 0; }
};

//
// downcast
//
// Given a base class pointer, return a pointer to the derived class.
//

template <class BaseType,
          class DerivedType>
class downcast: public std::unary_function<BaseType *, DerivedType *> {
public:
  DerivedType* operator()(BaseType* b) const {
    return dynamic_cast<DerivedType *>(b);
  }
};

//
// dereference
//
// Given an iterator, return a reference.
//

template <class iter_t>
class dereference: public std::unary_function<iter_t,iterator_traits<deconst_traits<iter_t>::type>::reference> {
public:
  result_type operator()(iter_t i) const { return *i; }
};


// Definition of the template match_element but no implementation!
// That's because there are six correct implementations, and
// are the specializations, defined below.
template<class container_a, class container_b,
          class const_tag = const_view_tag,
          template <class C, class tag> class proxy_template_a = view_ref,
          class FindTypedef_a = typename ContainerTrait<deconst_traits<container_a>::type>::FindType, 
          class KeyDataPair_a = typename ContainerTrait<deconst_traits<container_a>::type>::ValuePairType, 
          class KeyDataPair_b = typename ContainerTrait<deconst_traits<container_b>::type>::ValuePairType 
 >
class match_element;

//
// match_element
//
template<class container_a, class container_b,
          class const_tag,
          template <class C, class tag> class proxy_template_a>
class match_element<container_a,
	container_b,
	const_tag,
	proxy_template_a,
	NoInternalFindElement, 
	NotKeyDataPair, 
	NotKeyDataPair>
  : public std::unary_function<typename container_b::value_type, bool const> 
{
public:
  typedef one_container_base<container_a,const_tag,proxy_template_a> base_t;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef typename container_b::const_reference const_reference;
  match_element() {}
  match_element(ctor_arg_type_a &rhs)
    : base(rhs) {}

  bool const operator()(const_reference x) const {
    return std::find(base.cont().begin(), base.cont().end(), x) != base.cont().end();
  }

private:
	base_t base;
};

// match_element where the container has an internal find, like
// set and multiset.
template<class container_a, class container_b,
          class const_tag,
          template <class C, class tag> class proxy_template_a>
class match_element<container_a,
	container_b, 
	const_tag,
	proxy_template_a,
	InternalFindElement, 
	NotKeyDataPair, 
	NotKeyDataPair>
  :	public std::unary_function<typename container_b::value_type, bool const> 
{
public:
  typedef one_container_base<container_a,const_tag,proxy_template_a> base_t;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef typename container_b::const_reference const_reference;

  match_element() {}
  match_element(ctor_arg_type_a &rhs)
    : base(rhs) {}
  
  bool const operator()(const_reference x) const {
    return base.cont().find(x) != base.cont().end();
  }

private:
	base_t base;
};

//
// match_element where the container does not have an internal find, 
// like list, vector and deque among others.
// And where container_b is a pair<key, data> type, Here
// we return true if the item in a matches the key in b.
// "1" == "{1,data}"
//
template<class container_a, class container_b,
          class const_tag,
          template <class C, class tag> class proxy_template_a>
class match_element<container_a,
	container_b, 
	const_tag,
	proxy_template_a,
	NoInternalFindElement, 
	NotKeyDataPair, 
	KeyDataPair>
  : public std::unary_function<typename container_b::value_type, bool const> 
{
public:
  typedef one_container_base<container_a,const_tag,proxy_template_a> base_t;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef typename container_b::const_reference const_reference;
  match_element() {}
  match_element(ctor_arg_type_a &rhs)
    : base(rhs) {}

  bool const operator()(const_reference x) const {
    return std::find(base.cont().begin(), base.cont().end(), 
			ContainerTrait<deconst_traits<container_b>::type>::key(x)) != base.cont().end();
  }

private:
	base_t base;
};

// match_element where the container has an internal find, like
// set and multiset. And where container_b is a pair<key, data> type, Here
// we return true if the item in a matches the key in b.
// "1" == "{1,data}"
template<class container_a, class container_b,
          class const_tag,
          template <class C, class tag> class proxy_template_a>
class match_element<container_a,
	container_b, 
	const_tag,
	proxy_template_a,
	InternalFindElement, 
	NotKeyDataPair, 
	KeyDataPair>
  :	public std::unary_function<typename container_b::value_type, bool const> 
{
public:
  typedef one_container_base<container_a,const_tag,proxy_template_a> base_t;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef typename container_b::const_reference const_reference;

  match_element() {}
  match_element(ctor_arg_type_a &rhs)
    : base(rhs) {}
  
  bool const operator()(const_reference x) const {
    return base.cont().find(ContainerTrait<deconst_traits<container_b>::type>::key(x))
			!= base.cont().end();
  }

private:
	base_t base;
};


//
// match_element where the container_a has PairInternalEqualRange.
// And container_b is a collection of pair<key, data> type, 
// Both containers have the same pair<key, data> type.
//
template <class container_a, class container_b,
          class const_tag,
          template <class C, class tag> class proxy_template_a>
class match_element<container_a, 
	container_b, 
	const_tag,
	proxy_template_a,
	PairInternalEqualRange, 
	KeyDataPair, 
	KeyDataPair>
  : public std::unary_function<typename container_b::value_type, bool const> {
  typedef typename container_a::const_iterator const_iterator;
public:
  typedef one_container_base<container_a,const_tag,proxy_template_a> base_t;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef typename container_b::const_reference const_reference;

  match_element() {}
  match_element(ctor_arg_type_a &rhs)
    : base(rhs) {}

  bool const operator()(const_reference x) const {
	  std::pair<const_iterator,const_iterator> range
      = base.cont().equal_range(ContainerTrait<deconst_traits<container_a>::type>::key(x));
    
    return std::find(range.first,range.second,x) != range.second;
  }

private:
	base_t base;
};

//
// match_element where the container_a has PairInternalEqualRange.
// And container_a is of pair<key, data> type, but conatainer_b is not.
// container_b::value_type == container_a::value_type.first.
// We rely on the fact that all the standard containers that have
// an equal range function also have a find function.
//
template <class container_a, class container_b,
          class const_tag,
          template <class C, class tag> class proxy_template_a>
class match_element<container_a, 
	container_b, 
	const_tag,
	proxy_template_a,
	PairInternalEqualRange, 
	KeyDataPair, 
	NotKeyDataPair>
  : public std::unary_function<typename container_b::value_type, bool const> {
  typedef typename container_a::const_iterator const_iterator;
public:
  typedef one_container_base<container_a,const_tag,proxy_template_a> base_t;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef typename container_b::const_reference const_reference;

  match_element() {}
  match_element(ctor_arg_type_a &rhs)
    : base(rhs) {}

  bool const operator()(const_reference x) const {
    return base.cont().find(x) != base.cont().end();
   }

private:
	base_t base;
};


// This is a a copy of SGI STL unary_compose but with a default constructor.
template <class Op1, class Op2>
class MyUnaryCompose
: public std::unary_function<typename Op2::argument_type,typename Op1::result_type>
{
private:
	Op1 o1;
	Op2 o2;
public:
	MyUnaryCompose() {}	// default constructable.
	MyUnaryCompose(const Op1 &x, const Op2 &y) : o1(x), o2(y) {}

	typename Op1::result_type
    operator()(const typename Op2::argument_type& x) const
	{
		return o1(o2(x)); 
	}
};

// This is a a copy of SGI STL equal but with a test for the last2.
template <class iter_t_1, class iter_t_2>
inline bool check_equal(iter_t_1 first1, iter_t_1 last1,
                    iter_t_2 first2, iter_t_2 last2) {
  for ( ; first1 != last1 && first2 != last2; ++first1, ++first2)
    if (*first1 != *first2)
      return false;
  return first1==last1 && first2==last2;
}

END_VIEW_NAMESPACE
#endif // _FUNCTORS_H
