/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_ROTATE_VIEW_H)
#define _ROTATE_VIEW_H	1

#if !defined(_UNION_VIEW_H)
#include "union_view.h"
#endif

#if !defined(_RANGE_VIEW_H)
#include "range_view.h"
#endif

BEGIN_VIEW_NAMESPACE
// typedefs to make it easier to define the rotate_view.
template<
	class iterator_type,
	class const_iterator_type,
	class const_tag,
	class iterator_tag
	>
// Not really a namespace but that's all I'm using it for.
class rotate_view_namespace
{
private:
	typedef range_view<iterator_type,const_iterator_type> ranging_view;

	// Define a union_view of two range_views.
	// Since each filtered view excludes the members found in the other
	// view, this will be a symmetric_difference_view.
	typedef union_view<ranging_view,ranging_view,const_tag,
		iterator_tag, view_own,view_own> base_view;

protected:
	// There is this one more layer so we don't have to export out
	// all of the typedefs we set up in rotate_view_namespace.
	class view : public base_view
	{
	public:
		explicit view() {}
		view(iterator_type const &first, iterator_type const &last, iterator_type const &middle)
		  : base_view(ranging_view(middle,last), 
						ranging_view(first,middle))
	    {}
	};

};

//
// rotate_view
//
// Make the elements appear to be shifted in a sequence leftward as follows,
// Display the sequence middle,last, middle,first.

template<
	class iterator_type,
	class const_iterator_type = iterator_type,
	class const_tag = const_view_tag,
	class iterator_tag = typename std::iterator_traits<iterator_type>::iterator_category>
class rotate_view 
  : public rotate_view_namespace<iterator_type,const_iterator_type,
		const_tag,iterator_tag>::view
{
public:
  typedef rotate_view_namespace<iterator_type,const_iterator_type,
					const_tag,iterator_tag>::view inherited;

  explicit rotate_view() {}
  rotate_view(iterator_type const &first, 
				iterator_type const &last, 
				iterator_type const &middle)
	  : inherited(first, last, middle) 
	{}
};

END_VIEW_NAMESPACE

#endif // _ROTATE_VIEW_H
