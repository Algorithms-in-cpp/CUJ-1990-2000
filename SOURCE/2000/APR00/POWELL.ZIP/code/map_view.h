/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#if !defined(MAP_VIEW_H)
#define MAP_VIEW_H	1

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

#if !defined(_TRANSFORM_VIEW_H)
#include "transform_view.h"
#endif

#if !defined(_FILTER_VIEW_H)
#include "filter_view.h"
#endif

BEGIN_VIEW_NAMESPACE
//
// A view that presents the keys of a map.
//

template <class container,
  class const_tag = const_view_tag,
  template<class C, class base_const_tag> class proxy_template = view_ref>
class map_keys
  : public transform_view<container,
    select1st<typename container::value_type>, 
    const_tag, 
    typename container::key_type,
    proxy_template> 
{
public:
  typedef transform_view<container,
    select1st<typename container::value_type>, 
    const_tag, 
    typename container::key_type,
    proxy_template> inherited;
  
  explicit map_keys(inherited::ctor_arg_type& cont)
    : inherited(cont,transform_type()) {}
};

//
// A view that presents the filtered keys of a map.
//

template <class container,
  class predicate, 
  class const_tag = const_view_tag,
  class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
  template<class C, class base_const_tag> class proxy_template = view_ref>
class map_keys_filtered
  : public filter_view<map_keys<container,const_tag,proxy_template>,
                       predicate,
                       const_tag,
					   iterator_tag,
                       proxy_template>

{
public:
  typedef filter_view<map_keys<container,const_tag,proxy_template>,
    predicate,
    const_tag,
	iterator_tag,
    proxy_template > inherited;
  
  explicit map_keys_filtered(inherited::ctor_arg_type& cont,
								inherited::predicate_type const &pred)
    : inherited(cont,pred) {}
};

//
// A view that presents the transformed keys of a map.
//

template <class container,
  class transform,
  class const_tag = const_view_tag,
  class T=typename transform::result_type,
  class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
  template<class C, class base_const_tag> class proxy_template = view_ref>
class map_keys_transformed
  : public transform_view<map_keys<container,const_tag,proxy_template>,
    transform,
    const_tag,
    T,
    proxy_template>

{
public:
  typedef transform_view<map_keys<container,const_tag,proxy_template>,
    transform,
    const_tag,
    T,
    proxy_template> inherited;
  
  explicit map_keys_transformed(inherited::ctor_arg_type& cont,
								  inherited::transform_type const & trans)
    : inherited(cont,trans) {}
};

//
// A view that presents the transformed & filtered keys of a map.
//

template <class container,
          class predicate,
          class transform,
          class const_tag = const_view_tag, 
          class T=typename transform::result_type,
          class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
          template<class C, class base_const_tag> class proxy_template = view_ref>
class map_keys_view
  : public transform_view<map_keys_filtered<map_keys<container,const_tag,proxy_template>,
    predicate,const_tag,iterator_tag,proxy_template>,
    transform,
    const_tag,
    T,
    proxy_template>

{
public:
  typedef map_keys_filtered<map_keys<container,const_tag,proxy_template>,
    predicate,const_tag,iterator_tag,proxy_template> filtered;
  
  typedef transform_view<filtered,transform,const_tag,T,proxy_template> inherited;
  
  explicit map_keys_view(inherited::ctor_arg_type& cont,
			 filtered::predicate_type const &pred,
			 inherited::transform_type const & trans)
    : inherited(filtered(cont, pred),trans) {}
};


//
// A view that presents the values of a map.
//
template <class container,
  class const_tag = const_view_tag,
  template<class C, class base_const_tag> class proxy_template = view_ref>
class map_values
  : public transform_view<container,
    select2nd<typename container::value_type>, 
    const_tag, 
    typename container::data_type,
    proxy_template> 
{
public:
  typedef transform_view<container,
    select2nd<typename container::value_type>, 
    const_tag,typename container::data_type,proxy_template> inherited;
  
  explicit map_values(inherited::ctor_arg_type& cont)
    : inherited(cont,transform_type()) {}
};

//
// A view that presents the filtered values of a map.
//

template <class container,
  class predicate, 
  class const_tag = const_view_tag,
  class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
  template<class C, class base_const_tag> class proxy_template = view_ref>
class map_values_filtered
  : public filter_view<map_values<container,const_tag,proxy_template>,
    predicate,
    const_tag,
	iterator_tag,
    proxy_template>

{
public:
  typedef filter_view<map_values<container,const_tag,proxy_template>,
    predicate,
    const_tag,
	iterator_tag,
    proxy_template> inherited;
  
  explicit map_values_filtered(inherited::ctor_arg_type& cont,
			       inherited::predicate_type const &pred)
    : inherited(cont,pred) {}
};

//
// A view that presents the transformed values of a map.
//

template <class container,
  class transform,
  class const_tag = const_view_tag,
  class T=typename transform::result_type,
  class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
  template<class C, class base_const_tag> class proxy_template = view_ref>
class map_values_transformed
  : public transform_view<map_values<container,const_tag,proxy_template>,
    transform,
    const_tag,
    T,
    proxy_template>

{
public:
  typedef transform_view<map_values<container,const_tag,proxy_template>,
    transform,
    const_tag,
    T,
    proxy_template> inherited;
  
  explicit map_values_transformed(inherited::ctor_arg_type& cont,
				  inherited::transform_type const & trans)
    : inherited(cont,trans) {}
};

//
// A view that presents the transformed & filtered values of a map.
//

template <class container,
          class predicate,
          class transform,
          class const_tag = const_view_tag, 
          class T=typename transform::result_type,
		  class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
          template<class C, class base_const_tag> class proxy_template = view_ref>
class map_values_view
  : public transform_view<map_values_filtered<map_values<container,const_tag,proxy_template>,
    predicate,const_tag,iterator_tag,proxy_template>,
    transform,
    const_tag,
    T,
    proxy_template>

{
public:
  typedef map_values_filtered<map_values<container,const_tag,proxy_template>,
    predicate,
    const_tag,
	iterator_tag,
    proxy_template> filtered;
  
  typedef transform_view<filtered,
    transform,
    const_tag,
    T,
    proxy_template> inherited;
  
  explicit map_values_view(inherited::ctor_arg_type& cont,
			   filtered::predicate_type const &pred,
			   inherited::transform_type const & trans)
    : inherited(filtered(cont, pred),trans) {}
};

END_VIEW_NAMESPACE

#endif
