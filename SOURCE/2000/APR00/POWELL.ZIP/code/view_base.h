/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

//
// Traits classes that map container types and constness tags to iterator types.
//

#if!defined(_VIEW_BASE_H)
#define _VIEW_BASE_H

#if !defined(_VIEW_CONFIG_H)
#include "view_config.h"
#endif

#if !defined(_VIEW_TRAITS_H)
#include "view_traits.h"
#endif

// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp>
	void swap(_Tp&, _Tp&);
};

BEGIN_VIEW_NAMESPACE
//
// Tag classes used for telling views whether their referenced containers
// should be const or mutable.
//
class mutable_view_tag {};
class const_view_tag {};


//
// Traits classes mapping (container,const_tag) pairs to value
// and iterator types.
//
template<class container, class const_tag>
struct view_traits {
  typedef container container_type;
  typedef typename container::iterator iterator;
  typedef typename container::const_iterator const_iterator;
  typedef std::iterator_traits<iterator>::value_type value_type;
};


template <class container>
struct view_traits<container,const_view_tag> {
  typedef const container container_type;
  typedef typename container::const_iterator iterator;
  typedef typename container::const_iterator const_iterator;
  typedef std::iterator_traits<iterator>::value_type value_type;
};

template<class container, class const_tag>
struct reversible_view_traits: public view_traits<container,const_tag> {
  typedef typename container::reverse_iterator reverse_iterator;
  typedef typename container::const_reverse_iterator const_reverse_iterator;
};

template<class container>
struct reversible_view_traits<container,const_view_tag>
  : public view_traits<container,const_view_tag> {
  typedef typename container::const_reverse_iterator reverse_iterator;
  typedef typename container::const_reverse_iterator const_reverse_iterator;
};

//
// Two base classes for views that either contain or reference a container.
//

template<class container, class const_tag>
class view_own {
public:
  typedef view_traits<container,const_tag>::container_type domain_type;
  
  domain_type const& cont() const { return a; }
  domain_type&       cont()       { return a; }

  view_own(domain_type const& b) // we make a copy of our own!
    : a(b) {}

  // Default constructible. Warning: a default constructed view_own
  // is completely undefined with the only exception of subsequent
  // assignment.
  view_own() {}

  void swap(view_own& b) { std::swap(a,b.a); }
  
private:
  domain_type a;
};


template<class container, class const_tag>
class view_ref{
public:
  typedef view_traits<container,const_tag>::container_type domain_type;
  
  domain_type const& cont() const { return *a; }
  domain_type&       cont()       { return *a; }

  // b is intentionally non const. Otherwise we could not refer to mutable
  // containers.
  view_ref(domain_type& b)
    : a(&b) {}

  // Default constructible. Warning: a default constructed view_ref
  // is completely undefined with the only exception of subsequent
  // assignment.
  view_ref() {}

  void swap(view_ref& b) { std::swap(a,b.a); }
  
private:
  domain_type* a;
};


//
// This is a traits class for determining the argument type a view's
// constructor should use for its container argument.
//
//          | const_view_tag | mutable_view_tag
//----------+----------------+------------------
// view_own |    const&      |    const&             <- we make a copy of our own
// view_ref |    const&      |    &
//
// Note that the container_type defined by view_traits does
// not satisfy this requirements. It does the view_own/mutable_view_tag
// case wrong.
//

template <class container, 
		class const_tag, 
		template <class container, class const_tag> class base>
struct ctor_arg { typedef container const type; };

template <class container>
struct ctor_arg<container,mutable_view_tag,view_ref> { typedef container type; };

//
// This is a traits class for determining whether to use the type, or const_type
// of a trait.
template < class raw_type,
			template<class T> class traits_template,
			class const_tag >
struct select_type { typedef typename traits_template<raw_type>::const_type type; };

template < class raw_type,
			template<class T> class traits_template>
struct select_type< raw_type, traits_template, mutable_view_tag > 
{ typedef typename traits_template<raw_type>::type type; };

//
// A simple utility class that allows operator->() to be defined for
// iterators that return temporaries.
//
template <class T>
class member_access_proxy {
  T t;
public:
  typedef reference_traits<T>::const_type const_reference;
  typedef pointer_traits<T>::type         pointer;
  typedef pointer_traits<T>::const_type   const_pointer;
  
  member_access_proxy(const_reference t_)
    : t(t_) {}
  pointer       operator->()       { return &t; }
  const_pointer operator->() const { return &t; }
};

END_VIEW_NAMESPACE

namespace std {

template<class container, class const_tag>
void swap(VIEW_NAMESPACE::view_own<container, const_tag> &a, 
		  VIEW_NAMESPACE::view_own<container, const_tag> &b)
{  a.swap(b); }

template<class container, class const_tag>
void swap(VIEW_NAMESPACE::view_ref<container, const_tag> &a, 
		  VIEW_NAMESPACE::view_ref<container, const_tag> &b)
{  a.swap(b); }

}

#endif // _VIEW_BASE_H
// $Id: view_base.h,v 1.6 1999/09/28 13:50:37 bzfweise Exp $
