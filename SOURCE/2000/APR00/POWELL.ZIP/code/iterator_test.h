/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_ITERATOR_TEST_H)
#define _ITERATOR_TEST_H	1

#if !defined(_SYS_LIBRARY_CASSERT_)
#include <cassert>
#define _SYS_LIBRARY_CASSERT_
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>			// for distance.
#define _SYS_LIBRARY_ITERATOR_
#endif

#if !defined(_SYS_LIBRARY_ALGORITHM_)
#include <algorithm>	// for min
#define _SYS_LIBRARY_ALGORITHM_
#endif


using std::distance;

template<class Container>
void assignment_test(Container & cont)
{
  if (!cont.empty() )
  {
    typename Container::iterator c_iter1(cont.begin());
    typename Container::iterator::value_type x(*c_iter1);	// test construction.

    //x = *c_iter1;	// test assignment.
    *c_iter1 = x;

    assert(x == *c_iter1);
  }
}


template<class Container>
void forward_test(Container & cont)
{
  typename Container::iterator c_iter1;	                // default construction.
  c_iter1 = cont.begin();				// assignment.
  typename Container::iterator c_iter2(cont.end());	// copy construction.
  typename Container::iterator c_iter3(cont.end());

  assert(c_iter2 == c_iter3);	                        // test ==
	
  typename Container::difference_type dist = distance(cont.begin(), cont.end() );
  assert (dist == static_cast<typename Container::difference_type>(cont.size()) );

  typename Container::const_iterator c_iter4(c_iter1);	// const conversion test.

  assert(c_iter1 == c_iter4);	// test == for const_iterator vs non-const iterator.
  assert(!(c_iter1 != c_iter4));

  assert(c_iter4 == c_iter1);	// test == for const_iterator vs non-const iterator.
  assert(!(c_iter4 != c_iter1));

  if (!cont.empty())
    {
      assert(c_iter1 < c_iter2);	               // test <
      assert(c_iter1 != c_iter2);	               // test !=

      assert(c_iter4 < c_iter2);		// mixed const non-const comparison test.
	  assert(!(c_iter2 < c_iter4));
      ++c_iter1;				       // increment.
    }


  swap(c_iter2,c_iter3);				// swap test.

  c_iter4 = cont.begin();				// assignment.
  advance(c_iter4,min(static_cast<int>(cont.size()), 5) );   // advance test.
}

template<class Container>
void const_forward_test(const Container & cont)
{
  typename Container::const_iterator c_iter1;	                // default construction.
  c_iter1 = cont.begin();				        // assignment.
  typename Container::const_iterator c_iter2(cont.end());	// copy construction.
  typename Container::const_iterator c_iter3(cont.end());

  assert(c_iter2 == c_iter3);	                                // test ==
	
  typename Container::difference_type dist = distance(cont.begin(), cont.end() );
  assert (dist == static_cast<typename Container::difference_type>(cont.size()) );

  if (!cont.empty())
    {
      assert(c_iter1 < c_iter2);	                        // test <
      assert(c_iter1 != c_iter2);	                        // test !=
      ++c_iter1;						// increment.
    }

  swap(c_iter2,c_iter3);				        // swap test.
}



template<class Container>
void reverse_test(Container & cont)
{
  typename Container::reverse_iterator c_iter1;	// default construction.
  c_iter1 = cont.rbegin();				// assignment.
  typename Container::reverse_iterator c_iter2(cont.rend());	// copy construction.
  typename Container::reverse_iterator c_iter3(cont.rend());

  assert(c_iter2 == c_iter3);	// test ==
	
  typename Container::difference_type dist = distance(cont.rbegin(), cont.rend() );
  assert (dist == static_cast<typename Container::difference_type>(cont.size()) );
  typename Container::difference_type dist2 = distance(cont.begin(), cont.end() );
  assert(dist == dist2);

  if (!cont.empty())
    {
      assert(c_iter1 < c_iter2);	// test <
      assert(c_iter1 != c_iter2);	// test !=

      ++c_iter1;							// increment.
      --c_iter1;							// decrement.
	  assert(c_iter1 == cont.rbegin() );
    }

  swap(c_iter2,c_iter3);				// swap test.

  typename Container::const_reverse_iterator c_iter4(c_iter1);	// const conversion test.
  c_iter4 = cont.rbegin();				// assignment.
  advance(c_iter4,min(static_cast<int>(cont.size()), 5) );                                           // advance test.
}

template<class Container>
void const_reverse_test(const Container & cont)
{
	typename Container::const_reverse_iterator c_iter1;	// default construction.
	c_iter1 = cont.rbegin();				// assignment.
	typename Container::const_reverse_iterator c_iter2(cont.rend());	// copy construction.
	typename Container::const_reverse_iterator c_iter3(cont.rend());

	assert(c_iter2 == c_iter3);	// test ==
	
  typename Container::difference_type dist = distance(cont.rbegin(), cont.rend() );
  assert (dist == static_cast<typename Container::difference_type>(cont.size()) );
  typename Container::difference_type dist2 = distance(cont.begin(), cont.end() );
  assert(dist == dist2);

  if (!cont.empty())
	{
		assert(c_iter1 < c_iter2);	// test <
		assert(c_iter1 != c_iter2);	// test !=

		++c_iter1;							// increment.
		--c_iter1;							// decrement.
	    assert(c_iter1 == cont.rbegin() );
	}

	swap(c_iter2,c_iter3);				// swap test.
}


template<class Container>
void forward_test_no_lessthan(Container & cont)
{
	typename Container::iterator c_iter1;	// default construction.
	c_iter1 = cont.begin();				// assignment.
	typename Container::iterator c_iter2(cont.end());	// copy construction.
	typename Container::iterator c_iter3(cont.end());

	assert(c_iter2 == c_iter3);	// test ==
	
  typename Container::difference_type dist = distance(cont.begin(), cont.end() );
  assert (dist == static_cast<typename Container::difference_type>(cont.size()) );

	if (!cont.empty())
	{
		assert(c_iter1 != c_iter2);	// test !=
		++c_iter1;							// increment.
	}


	swap(c_iter2,c_iter3);				// swap test.

	typename Container::const_iterator c_iter4(c_iter1);	// const conversion test.
}

template<class Container>
void const_forward_test_no_lessthan(const Container & cont)
{
	typename Container::const_iterator c_iter1;	// default construction.
	c_iter1 = cont.begin();				// assignment.
	typename Container::const_iterator c_iter2(cont.end());	// copy construction.
	typename Container::const_iterator c_iter3(cont.end());

	assert(c_iter2 == c_iter3);	// test ==
	
  typename Container::difference_type dist = distance(cont.begin(), cont.end() );
  assert (dist == static_cast<typename Container::difference_type>(cont.size()) );

	if (!cont.empty())
	{
		assert(c_iter1 != c_iter2);	// test !=
		++c_iter1;							// increment.
	}

	swap(c_iter2,c_iter3);				// swap test.
}



template<class Container>
void reverse_test_no_lessthan(Container & cont)
{
	typename Container::reverse_iterator c_iter1;	// default construction.
	c_iter1 = cont.rbegin();				// assignment.
	typename Container::reverse_iterator c_iter2(cont.rend());	// copy construction.
	typename Container::reverse_iterator c_iter3(cont.rend());

	assert(c_iter2 == c_iter3);	// test ==
	
  typename Container::difference_type dist = distance(cont.rbegin(), cont.rend() );
  assert (dist == static_cast<typename Container::difference_type>(cont.size()) );
  typename Container::difference_type dist2 = distance(cont.begin(), cont.end() );
  assert(dist == dist2);

	if (!cont.empty())
	{
		assert(c_iter1 != c_iter2);	// test !=

		++c_iter1;							// increment.
		--c_iter1;							// decrement.
	    assert(c_iter1 == cont.rbegin() );
	}

	swap(c_iter2,c_iter3);				// swap test.

	typename Container::const_reverse_iterator c_iter4(c_iter1);	// const conversion test.
}

template<class Container>
void const_reverse_test_no_lessthan(const Container & cont)
{
	typename Container::const_reverse_iterator c_iter1;	// default construction.
	c_iter1 = cont.rbegin();				// assignment.
	typename Container::const_reverse_iterator c_iter2(cont.rend());	// copy construction.
	typename Container::const_reverse_iterator c_iter3(cont.rend());

	assert(c_iter2 == c_iter3);	// test ==
	
  typename Container::difference_type dist = distance(cont.rbegin(), cont.rend() );
  assert (dist == static_cast<typename Container::difference_type>(cont.size()) );
  typename Container::difference_type dist2 = distance(cont.begin(), cont.end() );
  assert(dist == dist2);

	if (!cont.empty())
	{
		assert(c_iter1 != c_iter2);	// test !=

		++c_iter1;							// increment.
		--c_iter1;							// decrement.
	    assert(c_iter1 == cont.rbegin() );
	}

	swap(c_iter2,c_iter3);				// swap test.
}

template<class Container>
void random_access_test(Container & cont)
{
	typename Container::iterator c_iter1 = cont.begin();				// assignment.
	typename Container::iterator c_iter_end(cont.end());	// copy construction.

	typename Container::difference_type dist = c_iter_end - c_iter1;

	typename Container::difference_type dist2 = distance(cont.begin(), cont.end() );
    typename Container::difference_type dist3 = cont.begin() - cont.end();
	assert (dist == dist2);
    dist2 = distance(cont.rbegin(), cont.rend() );
	assert (dist == dist2);
	assert((-dist3) == dist2);
	assert (dist == static_cast<typename Container::difference_type>(cont.size()) );

	if (!cont.empty() )
	{
		dist /= 2;
		
		c_iter1 += dist;
		c_iter1 -= dist;
		assert(c_iter1 == cont.begin() );
	}
	assert(c_iter1 == cont.begin() );
}

template<class Container>
void const_random_access_test(const Container & cont)
{
  typename Container::const_iterator c_iter1 = cont.begin();	// assignment.
  typename Container::const_iterator c_iter_end(cont.end());	// copy construction.

  typename Container::difference_type dist = c_iter_end - c_iter1;
  typename Container::difference_type dist2 = distance(cont.begin(), cont.end() );
  typename Container::difference_type dist3 = cont.begin() - cont.end();
  assert (dist == dist2);
  dist2 = distance(cont.rbegin(), cont.rend() );
  assert (dist == dist2);
  assert((-dist3) == dist2);
  assert (dist == static_cast<typename Container::difference_type>(cont.size()) );

  if (!cont.empty() )
    {
      dist /= 2;
		
      c_iter1 += dist;
      c_iter1 -= dist;
 	  assert(c_iter1 == cont.begin() );
   }
  assert(c_iter1 == cont.begin() );
}



#endif // _ITERATOR_TEST_H
