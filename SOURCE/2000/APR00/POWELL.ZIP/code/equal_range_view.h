/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#ifndef _EQUAL_RANGE_VIEW_H
#define _EQUAL_RANGE_VIEW_H 1

#if !defined(_RANGE_VIEW_H)
#include "range_view.h"
#endif

#if !defined(_RANGE_H)
#include "range.h"
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp>
	void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE

// Forward declare check_equal so that you don't have to include functors.h
template <class iter_t_1, class iter_t_2>
inline bool check_equal(iter_t_1, iter_t_1,
                  iter_t_2, iter_t_2);

 
//
// An iterator for stepping through equal ranges of a container.
//
// Note that reference is NOT value_type&, since equal ranges are constructed
// on the fly as temporaries. Nowhere are these ranges actually stored.
//
// This is no more than a bidirectional iterator. (Like filter_iterator, this
// is not an iterator at all, since operator++() is not amortized constant time.)
//
template <class equal_fn, class iter_t, class range_t>
class equal_range_iterator
  : public std::iterator<combine_iterator_categories<typename range_t::iterator_category,
                                                     bidirectional_iterator_tag>::type,
                         range_view<iter_t>,
                         std::iterator_traits<iter_t>::difference_type,
                         range_view<iter_t>*,
                         range_view<iter_t> > {
  
public:
  typedef range_view<iter_t>              value_type;
  typedef value_type                      reference;
  typedef value_type const                const_reference;
  typedef member_access_proxy<value_type> pointer;
  typedef pointer const                   const_pointer;

  
  
  // Iterators need to be default constructible.
  equal_range_iterator() {}

  equal_range_iterator(equal_fn const& equal_, iter_t const& iter, range_t const& range_)
    : equal(equal_), start(iter), range(range_) { advance_stop(); }

  // Element access.
  const_reference operator*()  const { return const_reference(start,stop); }
  reference       operator*()        { return reference(start,stop); }
  const_pointer operator->() const { return const_pointer(value_type(start,stop)); }
  pointer       operator->()       { return pointer(value_type(start,stop)); }
  
  // Forward stepping.
  equal_range_iterator& operator++()    { start = stop; advance_stop(); return *this; }
  equal_range_iterator  operator++(int) { equal_range_iterator tmp = *this; ++(*this); return tmp; }

  // Backward stepping. Requires a bidirectional range and bidirectional iter_t.
  equal_range_iterator& operator--()    { stop = start; reverse_start(); return *this; }
  equal_range_iterator  operator--(int) { equal_range_iterator tmp = *this; --(*this); return tmp; }

  // Comparison. STL relops only generates operators for *one* type. No comparison between
  // iterators and const_iterators possible via relops.
  template <class iter2, class range2>
  bool operator==(equal_range_iterator<equal_fn,iter2,range2> const& rhs) const { return start == rhs.start; }
  template <class iter2, class range2>
  bool operator< (equal_range_iterator<equal_fn,iter2,range2> const& rhs) const { return start <  rhs.start; }

  // Conversion from iterator to const_iterator. This requires a conversion from
  // iter_t to const_iter_t.
  template <class const_iter_t, class const_range_t>
  operator equal_range_iterator<equal_fn,const_iter_t,const_range_t>() const {
    return equal_range_iterator<equal_fn,const_iter_t,const_range_t>(equal,start,range); }
  
protected:
  equal_fn equal;
  iter_t   start;
  iter_t   stop;
  range_t  range;

  void advance_stop() {
    stop = start;
    while (stop != range.end() && equal(*start,*stop))
      ++stop;
  }
  void reverse_start() {
    iter_t tmp = stop;
    // stop points PAST THE END of the run we look for. tmp = --stop points to
    // the elements we look for.
    start = --tmp;
    while (start != range.begin() && equal(*start,*tmp))
      --start;
    // Now start points either JUST BEFORE the run or has been stopped by range.begin().
    // If it points before the run, increment it.
    if (!equal(*start,*tmp))
      ++start;
  }

  // Why shall friend templates not be partially specialized? Ick!
  template <class equal2, class iter2, class range2>
  friend class equal_range_iterator;
};


//
// An equal range view.
//
// This is a view that presents the ranges containing equal elements (runs).
//
template <class container,
          class equal_fn = equal_to<typename container::value_type>,
          class const_tag = const_view_tag,
		  class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
          template <class container, class const_tag> class proxy_template = view_ref>
class equal_range_view {
public:
  typedef one_container_base<container,const_tag,proxy_template> base_t;
  
  typedef ctor_arg<container,const_tag,proxy_template>::type ctor_arg_type;
  typedef typename view_traits<container,const_tag>::container_type domain_type;
  typedef view_traits<container,const_tag>::iterator       domain_iterator;
  typedef typename view_traits<container,const_tag>::const_iterator const_domain_iterator;
  typedef internal_range_traits<iterator_tag, container, const_tag>::type      iter_base;
  typedef internal_range_traits<iterator_tag, container, const_tag>::const_type const_iter_base;
  
  typedef equal_range_iterator<equal_fn,      domain_iterator,      iter_base> iterator;
  typedef equal_range_iterator<equal_fn,const_domain_iterator,const_iter_base> const_iterator;
  typedef std::reverse_iterator<iterator>                            reverse_iterator;
  typedef std::reverse_iterator<const_iterator>                      const_reverse_iterator;

  typedef iterator::value_type value_type;
  typedef iterator::value_type reference;
  typedef range_view<const_domain_iterator> const const_reference;

  typedef iterator::difference_type	difference_type;
  typedef typename domain_type::size_type size_type;
  

  // Constructor.
  explicit equal_range_view(){}
  explicit equal_range_view(ctor_arg_type& domain,equal_fn const& eq = equal_fn() ): base(domain), equal(eq) {}

  iterator       begin()       { return       iterator(equal,base.cont().begin(),iter_base(base.cont())); }
  const_iterator begin() const { return const_iterator(equal,base.cont().begin(),const_iter_base(base.cont())); }
  iterator       end()       { return       iterator(equal,base.cont().end(),iter_base(base.cont())); }
  const_iterator end() const { return const_iterator(equal,base.cont().end(),const_iter_base(base.cont())); }

  reverse_iterator       rbegin()       { return       reverse_iterator(end()); }
  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  reverse_iterator       rend()       { return       reverse_iterator(begin()); }
  const_reverse_iterator rend() const { return const_reverse_iterator(begin()); }

  size_type     size() const { return std::distance(begin(),end()); }
  size_type max_size() const { return base.cont().max_size(); }
  bool         empty() const { return base.cont().empty(); }


  void swap(equal_range_view& b) {
	base.swap(b.base);
	std::swap(equal, b.equal);
  }

protected:
  base_t base;
  equal_fn equal;
};


//
// The comparison operators.
//

template <class container_1,class container_2,
          class equal_fn_1,class equal_fn_2,
          class const_tag_1,class const_tag_2,
		  class iterator_tag_1, class iterator_tag_2,
          template <class container, class const_tag> class proxy_template_1,
          template <class container, class const_tag> class proxy_template_2>
bool operator==(equal_range_view<container_1,equal_fn_1,const_tag_1,iterator_tag_1,proxy_template_1> const& rhs,
		equal_range_view<container_2,equal_fn_2,const_tag_2,iterator_tag_2,proxy_template_2> const& lhs) {
  return check_equal(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}

template <class container_1,class container_2,
          class equal_fn_1,class equal_fn_2,
          class const_tag_1,class const_tag_2,
		  class iterator_tag_1, class iterator_tag_2,
          template <class container, class const_tag> class proxy_template_1,
          template <class container, class const_tag> class proxy_template_2>
bool operator<(equal_range_view<container_1,equal_fn_1,const_tag_1,iterator_tag_1,proxy_template_1> const& rhs,
	       equal_range_view<container_2,equal_fn_2,const_tag_2,iterator_tag_2,proxy_template_2> const& lhs) {
	return std::lexicographical_compare(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}

END_VIEW_NAMESPACE

namespace std {
//
// The swap function.
//
template <class container,
          class equal_fn,
          class const_tag,
		  class iterator_tag,
          template<class container, class const_tag> class proxy_template>
void swap(VIEW_NAMESPACE::equal_range_view<container,equal_fn,const_tag,iterator_tag,proxy_template>& a,
          VIEW_NAMESPACE::equal_range_view<container,equal_fn,const_tag,iterator_tag,proxy_template>& b) {
  a.swap(b);
}
};

#endif 