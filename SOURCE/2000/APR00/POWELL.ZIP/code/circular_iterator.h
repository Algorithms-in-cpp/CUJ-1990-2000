/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_CIRCULAR_ITERATOR_H)
#define _CIRCULAR_ITERATOR_H	1

#if !defined(_RANGE_H)
#include "range.h"
#endif

#if !defined(_RANGE_VIEW_H)
#include "range_view.h"
#endif

// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp> void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};


// Forward declare check_equal so that you don't have to include functors.h
template <class iter_t_1, class iter_t_2>
inline bool check_equal(iter_t_1, iter_t_1,
                  iter_t_2, iter_t_2);



template <class iter_t, class range_t>
class circular_iterator
  : public std::iterator<combine_iterator_categories<typename range_t::iterator_category,
                                                     random_access_iterator_tag>::type,
                         std::iterator_traits<iter_t>::value_type,
                         std::iterator_traits<iter_t>::difference_type,
                         std::iterator_traits<iter_t>::pointer,
                         std::iterator_traits<iter_t>::reference> 
{
public:
  explicit circular_iterator() {}

  template <class container>
  circular_iterator(container const& v, iter_t const& iter_)	// This const container may be a problem. GWP.
    : range(v), iter(iter_) {}

  circular_iterator(iter_t const& start, iter_t const& stop, iter_t const& iter_)
    : range(start,stop), iter(iter_) {}

  circular_iterator(iter_t const& stop, iter_t const& iter_)
    : range(stop), iter(iter_) {}

  // Dereferencing is trivial here
  const reference operator*() const { return *iter; }
  reference       operator*()       { return *iter; }
  const pointer operator->() const { return iter.operator->(); }
  pointer       operator->()       { return iter.operator->(); }

  circular_iterator& operator++() {if (iter==range.end()) iter=range.begin(); else ++iter; return *this; }
  circular_iterator  operator++(int) { circular_iterator tmp=*this; ++*this; return tmp; }

  // Backward stepping works only with bidirectional iterators
  circular_iterator& operator--() { if (iter==range.begin()) iter=range.end(); --iter; return *this; }
  circular_iterator  operator--(int) { circular_iterator tmp=*this; --*this; return tmp; }

  // Random stepping works best with random access iterators
  circular_iterator& operator+=(difference_type n) {
    if (n<0) return *this -= -n;
    difference_type d = std::distance(iter,range.end());
    if (d < n) { iter = range.begin(); n -= (d + 1); }
    std::advance(iter,n);
    return *this;
  }
  circular_iterator& operator-=(difference_type n) {
    if (n<0) return *this += -n;
    difference_type d = std::distance(range.begin(),iter);
    if (d < n) { iter = range.end(); n -= (d + 1); }
    std::advance(iter,-n);
    return *this;
  }
  circular_iterator operator+(difference_type n) const { circular_iterator tmp = *this; return tmp += n; }
  circular_iterator operator-(difference_type n) const { circular_iterator tmp = *this; return tmp -= n; }
  
  difference_type operator-(circular_iterator const &rhs) const 
	{ return distanceFromBegin() - rhs.distanceFromBegin(); }

  // Comparisons
  template<class iter2, class range2>
  bool operator==(const circular_iterator<iter2,range2>& rhs) const { return iter==rhs.iter;}

  // Martin, there is a little problem here.
  // for container 0,1,2,3,4,5
  // rotated 3 such that it looks like 3,4,5,0,1,2
  // For *iter_a == 5 && *iter_b == 0
  // iter_a < iter_b should be true, but will return false.
  // I don't have a back pointer to the window_view so I don't know where the rotate point is.
  template<class iter2, class range2>
  bool operator< (const circular_iterator<iter2,range2>& rhs) const { return iter< rhs.iter; }
   
  // Conversion from iterator to const_iterator. This works only if there is a
  // conversion from iter_t to const_iter and range to const_range_t.
  template<class const_iter,class const_range_t>
  operator circular_iterator<const_iter,const_range_t>() const {
    return circular_iterator<const_iter,const_range_t>(range,iter); }

protected:
  range_t range;
  iter_t  iter;

  // For comparisons.
  template <class iter2, class range2> friend class circular_iterator;
private:
  // wrong distance from the begining calculation. See note about operator<()
  difference_type distanceFromBegin() const {
    difference_type dist_this = std::distance(range.begin(),iter);
    return dist_this;
  }
};



#endif // _CIRCULAR_ITERATOR_H
