/* -*- c++ -*-
 * Copyright (c) 1999  
 * Gary Powell, Martin Weiser 
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *
 */
#if !defined(_SORTED_EQUAL_RANGE_BASE_H)
#define _SORTED_EQUAL_RANGE_BASE_H	1

#if !defined(_PAIR_MERGE_VIEW_H)
#include "pair_merge_view.h"
#endif

#if !defined(_EQUAL_RANGE_VIEW_H)
#include "equal_range_view.h"
#endif

#if !defined(_TRANSFORM_VIEW_H)
#include "transform_view.h"
#endif

#if !defined(_CONCATENATION_VIEW_H)
#include "concatenation_view.h"
#endif

BEGIN_VIEW_NAMESPACE
// definition of the base
template<class container_a, class container_b,
	  class comparator,
	  class equal_fn_a,
	  class equal_fn_b,
	  class const_tag,
	  class iterator_tag,
	  template<class container, class const_tag> class proxy_template_a,
	  template<class container, class const_tag> class proxy_template_b,
	  template<class range_a, class range_b, class const_tag> class SpecializedTransform
	  >
// Not really a namespace but that's all I'm using it for.
class sorted_equal_range_base_namespace
{
private:
	// Integrate the const_tag into the container types.
	typedef typename view_traits<container_a,const_tag>::container_type domain_a;
	typedef typename view_traits<container_b,const_tag>::container_type domain_b;

	typedef equal_range_view< domain_a, equal_fn_a, const_tag, iterator_tag, proxy_template_a> er_container_a;
	typedef equal_range_view< domain_b, equal_fn_b, const_tag, iterator_tag, proxy_template_b> er_container_b;

	// Define a pair_merge_view of the two range views.
	typedef pair_merge_view<er_container_a,er_container_b,
				comparator,
				const_tag, iterator_tag, view_own,view_own
				> merge_runs_view;
	// Define the transformation function.
	typedef SpecializedTransform<er_container_a::const_iterator, 
								er_container_b::const_iterator,
								const_tag> pair_transform;

	// Define a transformation view
	typedef transform_view<merge_runs_view, pair_transform, const_tag,
		typename pair_transform::result_type,view_own >	trans_view;

    // Concatenate the equal ranges.
    typedef concatenation_view<trans_view,const_tag,iterator_tag, view_own> base_view;

protected:
  // There is this one more layer so we don't have to export out
  // all of the typedefs we set up in the _namespace.
  class view : public base_view
  {
  public:
    explicit view() : base_view() {}
    view(domain_a &a, domain_b &b, 
         equal_fn_a const & eq_a,
         equal_fn_b const & eq_b,
         comparator const &c)
      : base_view(trans_view(merge_runs_view(er_container_a(a, eq_a),
                                             er_container_b(b, eq_b),
                                             c),
                             pair_transform()))
    {}
	};
};

END_VIEW_NAMESPACE

#endif	// _SORTED_EQUAL_RANGE_BASE_H
// $Id$
