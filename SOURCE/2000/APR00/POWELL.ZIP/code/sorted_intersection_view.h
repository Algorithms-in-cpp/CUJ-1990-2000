/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#ifndef _SORTED_INTERSECTION_VIEW_H
#define _SORTED_INTERSECTION_VIEW_H	1

#if !defined(_TWO_CONTAINERS_BASE_H)
#include "two_containers_base.h"
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

#if !defined(_SYS_LIBRARY_CASSERT_)
#include <cassert>
#define _SYS_LIBRARY_CASSERT_
#endif



// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp>
	void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool equal(_InputIter1, _InputIter1,
                  _InputIter2);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE
//
// A sorted_intersection_view_iterator template
//

template <class iter_t_a, class iter_t_b,
	  class comparator,
	  class range_t>
class sorted_intersection_view_iterator
: public std::iterator<typename range_t::iterator_category,
                    std::iterator_traits<iter_t_a>::value_type,
                    std::iterator_traits<iter_t_a>::difference_type,
                    std::iterator_traits<iter_t_a>::pointer,
                    combine_const_ref<std::iterator_traits<iter_t_a>::reference,
				      std::iterator_traits<iter_t_b>::reference>::type > {
public:
	typedef std::iterator<combine_iterator_tags<iter_t_a,iter_t_b>::type,
                   std::iterator_traits<iter_t_a>::value_type,
                   std::iterator_traits<iter_t_a>::difference_type,
                   std::iterator_traits<iter_t_a>::pointer,
                   combine_const_ref<std::iterator_traits<iter_t_a>::reference,
				     std::iterator_traits<iter_t_b>::reference>::type> inherited;
  typedef typename inherited::value_type value_type;
  typedef const value_type const_reference;

  // Iterators must be default constructible.
  explicit sorted_intersection_view_iterator() {}
  
  template<class view>
  sorted_intersection_view_iterator(const view& v,
		       const iter_t_a& iter_a_, const iter_t_b& iter_b_,
		       const comparator & comp)
    : range(v), iter_a(iter_a_), iter_b(iter_b_), precedes_fn(comp) 
  { set_initial_conditons(); }

  sorted_intersection_view_iterator(const range_t& range_,
		       const iter_t_a& iter_a, const iter_t_b& iter_b_, 
		       const comparator & comp)
    : range(range_), iter_a(iter_a_), iter_b(iter_b_), precedes_fn(comp)
  { set_initial_conditons(); }
  
  
  const reference operator*() const { return *iter_a; }
  reference operator*() { return *iter_a; }
  const pointer operator->() const { iter_a.operator->(); }
  pointer operator->() { iter_a.operator->(); }
  
protected:

  // Get the beginning iterators at the first matching value.
  void set_initial_conditons()
  {
    if (iter_a != range.end_a() && 
        iter_b != range.end_b() &&
        (precedes_fn(*iter_a,*iter_b) || precedes_fn(*iter_b, *iter_a)) )
      increment();
  }

  template<class iter_type, class T>
  void advance_fn(iter_type &iter, iter_type const &iterEnd, const T &x)
  {
	  do { ++iter; } while(iter != iterEnd && precedes_fn(*iter,x) ) ;
  }

  void increment()
  {
	++iter_a;
	if (iter_a == range.end_a() )
	{
		iter_b = range.end_b();
	}
	else
	{
	  const_reference &a = *iter_a;
	  const_reference &b = *iter_b;
	  if (precedes_fn(a, b))
	  {
		  // advance iter_a until it reaches either the end or
		  // points at the same value as iter_b
		  advance_fn(iter_a, range.end_a(), b);
		  if (iter_a == range.end_a())
			{
			  // no more intersecting values.	
			  iter_b = range.end_b();
			}
	  }
	  else
      {
        advance_fn(iter_b, range.end_b(), a);
        if (iter_b == range.end_b() )
          {
            // no more intersecting values.	
            iter_a = range.end_a();
          }
      }
	}
  }
  
  template<class iter_type, class T>
  void decrement_fn(iter_type &iter, iter_type const &iterBegin, const T &x)
  {
	  do { --iter; } while(iter != iterBegin && precedes_fn(x, *iter) ) ;
  }

  void decrement()
  {
	--iter_a;
	if (iter_b == range.end_b() )
	{
		--iter_b;
	}
	const_reference &a = *(iter_a);
	const_reference &b = *(iter_b);
    if (precedes_fn(a, b))
	{
		decrement_fn(iter_b, range.begin_b(), a);
		if (precedes_fn(a, *iter_b) )
		{
			// no more intersecting values.	
			iter_a = range.begin_a();
		}
	}
    else if (precedes_fn(b, a) )
	{
		decrement_fn(iter_a, range.begin_a(), b);
		if (iter_a == range.begin_a())
		{
			// no more intersecting values.	
			iter_b = range.begin_b();
		}
	}
 }
public:
  // Forward stepping.
  sorted_intersection_view_iterator& operator++() {
  if (iter_b == range.end_b() ) ++iter_a;
    else increment();
    return *this;
  }
  sorted_intersection_view_iterator operator++(int) {
    sorted_intersection_view_iterator tmp=*this; ++*this; return tmp;
  }

  // Backward stepping. This works only with bidirectional iterators
  // and two_containers_range_own range class.
  sorted_intersection_view_iterator& operator--() {
    if (iter_b == range.begin_b() ) --iter_a;
    else decrement(); return *this;
  }
  sorted_intersection_view_iterator operator--(int) {
    sorted_intersection_view_iterator tmp=*this; --*this; return tmp;
  }

  difference_type operator-(const sorted_intersection_view_iterator& y ) const {
    // Check that the two iterators are comparable.
    assert(comparable(*this,y));
    if (*this < y) return std::distance(iter_a,y.iter_a) + std::distance(iter_b,y.iter_b);
    else           return std::distance(y.iter_a,iter_a) + std::distance(y.iter_b,iter_b);
  }
    
  // Comparisons
  template <class iter_a_2, class iter_b_2, class range_t_2>
  bool operator==(const sorted_intersection_view_iterator<iter_a_2,iter_b_2,comparator,range_t_2>& p) const {
    return iter_a==p.iter_a && iter_b==p.iter_b; }

  template <class iter_a_2, class iter_b_2, class range_t_2>
  bool operator<(const sorted_intersection_view_iterator<iter_a_2,iter_b_2,comparator,range_t_2>& p) const {
    assert(comparable(*this,p));
    return iter_a<p.iter_a || iter_b<p.iter_b; }

  // Conversion from iterator to const_iterator. This works only if
  // there is a conversion from iter_t to const_iter.
  template <class const_iter_a, class const_iter_b, class const_range_t>
  operator sorted_intersection_view_iterator<const_iter_a,const_iter_b,comparator,const_range_t>() const {
    return sorted_intersection_view_iterator<const_iter_a,const_iter_b,
                                comparator,const_range_t>(range,iter_a,iter_b, precedes_fn); }
  
protected:
  range_t range;
  iter_t_a iter_a;
  iter_t_b iter_b;
  comparator precedes_fn;

private:
  // Gary: I added the comparable invariant during testing operator-().
  //       Don't know if we should let it here.
  // run time check for comparable iterators.
  // Each two iterators belonging to the same view should satisfy the following invariance.
  bool comparable(sorted_intersection_view_iterator const& x, sorted_intersection_view_iterator const& y) const {
    return (x.iter_a >= y.iter_a || y.iter_b >= x.iter_b) 
      && (y.iter_a >= x.iter_a || x.iter_b >= y.iter_b);
  }
  
  template <class iter_a_2, class iter_b_2, class comparator_2, class range_t_2>
  friend class sorted_intersection_view_iterator;
};


//
// A sorted_intersection_view.
//
// A view with two sorted containers, where an iterator will
// return the next in order item which is in both containers.
//
//
template <class container_a, class container_b,
	  class comparator = std::less<typename container_a::value_type>,
	  class const_tag = const_view_tag,
	  class iterator_tag = typename combine_iterator_tags<typename container_a::iterator,
							                              typename container_b::iterator>::type,
 	  template<class container, class const_tag> class proxy_template_a = view_ref,
	  template<class container, class const_tag> class proxy_template_b = view_ref,
	  template<class a_iter_t, class b_iter_t> class range_t = unidirectional_base_containers_range_own>
class sorted_intersection_view {
public:
  typedef typename container_a::value_type value_type;
  typedef typename container_a::pointer pointer;
  typedef typename container_a::reference reference;
  typedef typename container_a::const_reference const_reference;
  typedef typename container_a::size_type size_type;
  typedef typename container_a::difference_type difference_type;
  
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;
  typedef view_traits<container_a,const_tag>::container_type domain_a_type;
  typedef view_traits<container_a,const_tag>::iterator domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::container_type domain_b_type;
  typedef view_traits<container_b,const_tag>::iterator domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;
  typedef two_containers_base<container_a,container_b,const_tag,
	  proxy_template_a,proxy_template_b> base_t;

  typedef internal_two_range_traits<iterator_tag, container_a, container_b,const_tag>::type	        iter_base;
  typedef internal_two_range_traits<iterator_tag, container_a, container_b,const_tag>::const_type	const_iter_base;

  typedef sorted_intersection_view_iterator<domain_a_iterator,domain_b_iterator,comparator,iter_base> iterator;
  typedef sorted_intersection_view_iterator<domain_a_const_iterator,domain_b_const_iterator,
                               comparator,const_iter_base> const_iterator;
  typedef std::reverse_iterator<iterator> reverse_iterator;
  typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

  explicit sorted_intersection_view() {}

  sorted_intersection_view(ctor_arg_type_a& cont_a, ctor_arg_type_b& cont_b,
		   const comparator &comp = comparator())
    : base(cont_a,cont_b), precedes_fn(comp)
  {}

  const_iterator begin() const {
    return const_iterator(base,base.a().begin(),base.b().begin(), precedes_fn); }
  const_iterator end() const {
    return const_iterator(base,base.a().end(),base.b().end(), precedes_fn); }
  iterator begin() {
    return iterator(base,base.a().begin(),base.b().begin(), precedes_fn); }
  iterator end() {
    return iterator(base,base.a().end(),base.b().end(), precedes_fn); }

  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator rend() const { return const_reverse_iterator(begin()); }
  reverse_iterator rbegin() { return reverse_iterator(end()); }
  reverse_iterator rend() { return reverse_iterator(begin()); }

  size_type size() const { return distance(begin(),end() ); }
  size_type max_size() const {
    // Here comes a hack against overflow problems. Not really satisfactory, though.
    size_type sum = base.a().max_size()+base.b().max_size();
    size_type maximum = max(base.a().max_size(),base.b().max_size());
    return max(sum,maximum);
  }
  bool empty() const { return base.a().empty() || base.b().empty() || (begin() == end() ); }

  void swap(sorted_intersection_view &rhs)
  {
	  std::swap(precedes_fn, rhs.precedes_fn);
	  std::swap(base,rhs.base);
  }
protected:
	base_t base;
	comparator precedes_fn;
};

//
// Global comparator operations.
//
template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
	  class comparator_1, class comparator_2,
	  class const_tag_1, class const_tag_2,
      class iterator_tag_1, class iterator_tag_2,
      template<class container, class const_tag> class proxy_template_a_1,
      template<class container, class const_tag> class proxy_template_b_1,
      template<class container, class const_tag> class proxy_template_a_2,
      template<class container, class const_tag> class proxy_template_b_2>
bool operator==(sorted_intersection_view<container_a_1,container_b_1,
		comparator_1,const_tag_1,iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const & rhs,
		sorted_intersection_view<container_a_2,container_b_2,
		comparator_2,const_tag_2,iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const & lhs) {
	return rhs.size() == lhs.size() && std::equal(rhs.begin(), rhs.end(), lhs.begin());
}

template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
	  class comparator_1, class comparator_2,
	  class const_tag_1, class const_tag_2,
      class iterator_tag_1, class iterator_tag_2,
      template<class container, class const_tag> class proxy_template_a_1,
      template<class container, class const_tag> class proxy_template_b_1,
      template<class container, class const_tag> class proxy_template_a_2,
      template<class container, class const_tag> class proxy_template_b_2>
bool operator<(sorted_intersection_view<container_a_1,container_b_1,
		comparator_1,const_tag_1,iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const & rhs,
	       sorted_intersection_view<container_a_2,container_b_2,
		comparator_2,const_tag_2,iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const & lhs) {
	return std::lexicographical_compare(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}

END_VIEW_NAMESPACE
//
// The swap function
//
namespace std {
template <class container_a, class container_b,
	  class comparator,
	  class const_tag,
	  class iterator_tag,
	  template<class container, class const_tag> class proxy_template_a,
	  template<class container, class const_tag> class proxy_template_b>
void swap(VIEW_NAMESPACE::sorted_intersection_view<container_a,container_b,
	                        comparator,const_tag,iterator_tag,
	                        proxy_template_a,proxy_template_b>& a,
	  VIEW_NAMESPACE::sorted_intersection_view<container_a,container_b,
	                        comparator,const_tag,iterator_tag,
	                        proxy_template_a,proxy_template_b>& b) {
  a.swap(b);
}
};

#endif	// _SORTED_INTERSECTION_VIEW_H
