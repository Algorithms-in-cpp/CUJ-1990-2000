/* -*- c++ -*-
 * Copyright (c) 1999  
 * Gary Powell, Martin Weiser 
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *
 */
#if !defined(_SET_UNION_VIEW_H)
#define _SET_UNION_VIEW_H	1

#if !defined(_SORTED_EQUAL_RANGE_BASE_H)
#include "sorted_equal_range_base.h"
#endif

BEGIN_VIEW_NAMESPACE
// Given a pair of two iterators pointing to ranges of equal values,
// return the union, i.e. a subrange of the first range with no
// more elements that either of the two ranges.  This is semantically
// equivalent to the STL set_union guarantees.
template<class iter_a_t, class iter_b_t, class const_tag>
class TransformUnion 
: public unary_function< pair<iter_a_t, iter_b_t> const, 
			 typename iterator_traits<iter_a_t>::value_type >
{
public:
  typedef typename iterator_traits<iter_a_t>::value_type range_a;
  typedef typename iterator_traits<iter_a_t>::difference_type difference_type_a;
  typedef typename iterator_traits<iter_b_t>::difference_type difference_type_b;

  range_a operator()(pair<iter_a_t, iter_b_t> const &x) const {
    difference_type_a const dist_a = (*(x.first)).size();
    difference_type_b const dist_b = (*(x.second)).size();

    if (dist_a >= dist_b)
      return range_a(*(x.first) );

    return range_a(*(x.second) );
  }
};



//
// A set_union_view.
//
// A view with two sorted containers, where an iterator will
// return the next in order item from the containers.
//
//
template <class container_a, class container_b,
      class equal_fn_a = equal_to<typename container_a::value_type>,
      class equal_fn_b = equal_to<typename container_b::value_type>,
      class comparator = std::less<typename container_a::value_type>,
      class const_tag = const_view_tag,
	  class iterator_tag = typename combine_iterator_tags<typename container_a::iterator,
								                          typename container_b::iterator>::type,
      template<class container, class const_tag> class proxy_template_a = view_ref,
      template<class container, class const_tag> class proxy_template_b = view_ref>
class set_union_view
: public sorted_equal_range_base_namespace<container_a,container_b,
					     comparator,
                                             equal_fn_a,equal_fn_b,
                                             const_tag,
											 iterator_tag,
                                             proxy_template_a,proxy_template_b,
				             TransformUnion>::view
{
public:
  typedef sorted_equal_range_base_namespace<container_a,container_b,
					    comparator,equal_fn_a,equal_fn_b,const_tag,
						iterator_tag,
					    proxy_template_a,proxy_template_b,
					    TransformUnion>::view inherited;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;

  explicit set_union_view() {}

  set_union_view(ctor_arg_type_a& a_cont, 
				 ctor_arg_type_b& b_cont,
                 equal_fn_a const & eq_a = equal_fn_a(),
                 equal_fn_b const & eq_b = equal_fn_b(),
                 comparator const &comp = comparator())
    : inherited(a_cont, b_cont, eq_a, eq_b, comp) 
  {}
};

END_VIEW_NAMESPACE
#endif	// _SET_UNION_VIEW_H
// $Id: