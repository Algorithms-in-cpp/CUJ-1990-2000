/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_FILTER_VIEW_H)
#define _FILTER_VIEW_H	1

#if !defined(_VIEW_BASE_H)
#include "view_base.h"
#endif

#if !defined(_VIEW_TRAITS_H)
#include "view_traits.h"
#endif

#if !defined(_RANGE_H)
#include "range.h"
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif


// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp>
	void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE
// Forward declare check_equal so that you don't have to include "functors.h"
template <class iter_t_1, class iter_t_2>
inline bool check_equal(iter_t_1, iter_t_1,
                  iter_t_2, iter_t_2);
//
// A data containing proxy_template class for filtering views that can be
// easily referenced by iterators without infinite template recursion.
//

template <class container,
          class const_tag,
          class predicate_type,
		  template<class container,class const_tag> class proxy_template = view_ref
		  >
class filter_base  {
public:
  typedef one_container_base<container,const_tag,proxy_template> base_t;
  typedef ctor_arg<container,const_tag,proxy_template>::type ctor_arg_type;
  typedef typename view_traits<container,const_tag>::container_type domain_type;
  
  explicit filter_base() {}
  filter_base(ctor_arg_type& cont, const predicate_type& predicate_)
    : base(cont), predicate(predicate_) {}

  predicate_type pred() const { return predicate; }

  void swap(filter_base& b) {
	std::swap(predicate,b.predicate);
	std::swap(base,b.base);
  }
    
protected:
  base_t base;
  predicate_type predicate;
};


//
// A filtering iterator template
//


template <class predicate,
          class iter_t,
          class range_t>
class filter_iterator
: public std::iterator<combine_iterator_categories<typename range_t::iterator_category,
                                              bidirectional_iterator_tag>::type,                  
                  std::iterator_traits<iter_t>::value_type,
                  std::iterator_traits<iter_t>::difference_type,
                  std::iterator_traits<iter_t>::pointer,
                  std::iterator_traits<iter_t>::reference> {
public:
  // Iterators must be default constructible.
  explicit filter_iterator() {}

  template <class container>
  filter_iterator(predicate const& pred_,container& v, const iter_t& iter_)
    : range(v), iter(iter_), pred(pred_) { advance(); }
  
  filter_iterator(predicate const& pred_, const iter_t& start, const iter_t& stop, const iter_t& iter_)
    : range(stop), iter(iter_), pred(pred_) { advance(); }

  filter_iterator(predicate const& pred_, const iter_t& stop, const iter_t& iter_)
    : range(start,stop), iter(iter_), pred(pred_) { advance(); }

  filter_iterator(predicate const& pred_, const range_t& range_, const iter_t& iter_)
    : range(range_), iter(iter_), pred(pred_) { advance(); }

  const reference operator*() const { return *iter; }
  reference       operator*()       { return *iter; }
  const pointer operator->() const { return iter.operator->(); }
  pointer       operator->()       { return iter.operator->(); }
  

  filter_iterator& operator++()    { ++iter; advance(); return *this; }
  filter_iterator  operator++(int) { filter_iterator tmp=*this; ++*this; return tmp; }

  // Backward stepping. This works only with bidirectional iterators.
  filter_iterator& operator--()    { --iter; reverse(); return *this; }
  filter_iterator  operator--(int) { filter_iterator tmp=*this; --*this; return tmp; }

  // Comparisons.
  template<class iter2, class range2>
  bool operator==(const filter_iterator<predicate,iter2,range2>& rhs) const 
	{ return iter==rhs.iter; }
  template<class iter2, class range2>
  bool operator< (const filter_iterator<predicate,iter2,range2>& rhs) const 
	{ return iter< rhs.iter; }  
  
  // Conversion from iterator to const_iterator. This works only if there is a
  // conversion from iter_t to const_iter and range to const_range_t.
  template<class const_iter,class const_range_t>
  operator filter_iterator<predicate,const_iter,const_range_t>() const {
    return filter_iterator<predicate,const_iter,const_range_t>(pred,range,iter);
  }
  
  // return the underlying container iterator.
  iter_t &get() { return iter; }
  iter_t const &get() const { return iter; }

protected:
  range_t   range;
  iter_t    iter;
  predicate pred;

  // Re-establish the iterator's invariant by forward stepping:
  // range.end()==iter || pred(*iter)
  void advance() {
    while (range.end()!=iter && !pred(*iter))
      ++iter;
  }

  // Re-establish the iterator's invariant by backward stepping:
  // range.end()==iter || pred(*iter)
  //
  // Since there is no guarantee that there is an element in the
  // domain between the present position and the beginning of the
  // domain that satisfies the invariant it is necessary to apply
  // adjust_forward() which is guaranteed to always establish the
  // invariant.
  void reverse() {
    while (range.begin()!=iter && !pred(*iter))
      --iter;
    advance();
  }

  // Why shall friend template not be partially specialized? Ick!
  template<class pred2,class iter2, class range2>
  friend class filter_iterator;
};


//
// A filtering view.
//

template <class container,
		  class predicate, 
          class const_tag = const_view_tag,
		  class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
          template <class C, class tag> class proxy_template = view_ref >
class filter_view: public filter_base<container,const_tag,predicate,proxy_template> {
public:
  typedef typename container::value_type value_type;
  typedef view_traits<container,const_tag>::container_type domain_type;
  typedef view_traits<container,const_tag>::iterator       domain_iterator;
  typedef view_traits<container,const_tag>::const_iterator domain_const_iterator;
  typedef predicate predicate_type;
  typedef typename domain_type::pointer   pointer;
  typedef typename domain_type::reference reference;
  typedef typename domain_type::const_reference const_reference;
  typedef typename domain_type::size_type size_type;
  typedef typename domain_type::difference_type difference_type;
  typedef filter_base<container,const_tag,predicate,proxy_template> inherited;

  typedef internal_range_traits<iterator_tag, container, const_tag>::type      iter_base;
  typedef internal_range_traits<iterator_tag, container, const_tag>::const_type const_iter_base;

  typedef filter_iterator<predicate,domain_iterator,      iter_base>       iterator;
  typedef filter_iterator<predicate,domain_const_iterator,const_iter_base> const_iterator;
  typedef std::reverse_iterator<iterator> reverse_iterator;
  typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
 
  explicit filter_view() {}
  filter_view(ctor_arg_type& cont, const predicate& p)
    : inherited(cont,p) {}

  const_iterator begin() const { return const_iterator(pred(),const_iter_base(base.cont()),base.cont().begin()); }
  const_iterator end()   const { return const_iterator(pred(),const_iter_base(base.cont()),base.cont().end()); }
  iterator       begin()       { return iterator(pred(),iter_base(base.cont()),base.cont().begin()); }
  iterator       end()         { return iterator(pred(),iter_base(base.cont()),base.cont().end()); }

  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator rend()   const { return const_reverse_iterator(begin()); }
  reverse_iterator       rbegin()       { return reverse_iterator(end()); }
  reverse_iterator       rend()         { return reverse_iterator(begin()); }

  size_type size()     const { return distance(begin(),end()); }
  size_type max_size() const { return base.cont().size(); }
  bool      empty()    const { return begin()==end(); }
};



//
// Global comparator operations.
//

template <class container_1,class container_2,
          class predicate_1,class predicate_2,  
          class const_tag_1,class const_tag_2,
		  class iterator_tag_1, class iterator_tag_2,
          template<class C, class const_tag> class proxy_template_1,
		  template<class C, class const_tag> class proxy_template_2>
bool operator==(filter_view<container_1,predicate_1,const_tag_1,iterator_tag_1,proxy_template_1> const& lhs,
		filter_view<container_2,predicate_2,const_tag_2,iterator_tag_2,proxy_template_2> const& rhs) {
  return check_equal(lhs.begin(), lhs.end(), rhs.begin(), rhs.end());
}


template <class container_1,class container_2,
          class predicate_1,class predicate_2,  
          class const_tag_1,class const_tag_2,
		  class iterator_tag_1, class iterator_tag_2,
          template<class C, class const_tag> class proxy_template_1,
		  template<class C, class const_tag> class proxy_template_2>
bool operator<(filter_view<container_1,predicate_1,const_tag_1,iterator_tag_1,proxy_template_1> const& lhs,
	       filter_view<container_2,predicate_2,const_tag_2,iterator_tag_2,proxy_template_2> const& rhs) {
	return std::lexicographical_compare(lhs.begin(), lhs.end(), rhs.begin(), rhs.end());
}

END_VIEW_NAMESPACE

namespace std {
//
// The swap function
//

template <class container,
          class predicate, 
          class const_tag,
          template <class C, class tag> class proxy_template>
void swap(VIEW_NAMESPACE::filter_base<container,const_tag,predicate,proxy_template>& a,
	  VIEW_NAMESPACE::filter_base<container,const_tag,predicate,proxy_template>& b) {
  a.swap(b);
}
};


#endif
// $Id: filter_view.h,v 1.5 1999/09/16 09:21:11 bzfweise Exp $