/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#ifndef _RANGE_VIEW_H
#define _RANGE_VIEW_H	1


#if !defined(_VIEW_BASE_H)
#include "view_base.h"
#endif

#if !defined(_SYS_LIBRARY_CASSERT_)
#include <cassert>
#define _SYS_LIBRARY_CASSERT_
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

#if !defined(_SYS_LIBRARY_STDEXCEPT_)
#include <stdexcept>
#define _SYS_LIBRARY_STDEXCEPT_
#endif

// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp> void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE
// Forward declare check_equal so that you don't have to include "functors.h"
template <class iter_t_1, class iter_t_2>
inline bool check_equal(iter_t_1, iter_t_1,
                  iter_t_2, iter_t_2);

//
// A range view.
//

template <class iterator_type,
          class const_iterator_type = iterator_type >
class range_view {
public:
  typedef iterator_type                                   iterator;
  typedef const_iterator_type                             const_iterator;
  typedef std::reverse_iterator<iterator>                 reverse_iterator;
  typedef std::reverse_iterator<const_iterator>           const_reverse_iterator;
  typedef std::iterator_traits<iterator>::value_type      value_type;
  typedef std::iterator_traits<iterator>::reference       reference;
  typedef std::iterator_traits<const_iterator>::reference const_reference;
  typedef std::iterator_traits<iterator>::pointer         pointer;
  typedef std::iterator_traits<iterator>::difference_type difference_type;
  typedef difference_type size_type;
  
  explicit range_view() {}

  range_view(const iterator& start_, const iterator& stop_)
    : start(start_), stop(stop_) {}

  iterator begin() { return start; }
  iterator end()   { return stop; }
  const_iterator begin() const { return start; }
  const_iterator end()   const { return stop; }
  reverse_iterator rbegin() { return reverse_iterator(end()); }
  reverse_iterator rend()   { return reverse_iterator(begin()); }
  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator rend()   const { return const_reverse_iterator(begin()); }

  size_type size() const { return distance(begin(),end()); }
  size_type max_size() const { return size(); }
  bool empty() const { return begin()==end(); }

  const_reference operator[](size_type n) const { 
    iterator tmp(begin());
    std::advance(tmp,n);
    return *tmp; 
  }
   
  reference operator[](size_type n) {
    iterator tmp(begin());
    std::advance(tmp,n);
    return *tmp;
  }

  reference at(size_type n) { 
    iterator tmp(begin());
    std::advance(tmp,n);
    // Note: we do the test after moving the iterator incase 
    // this is a ranged filter view.
    // Gary: If I remember correctly, iterators may get invalid if
    //       advanced past the end. Are they still guaranteed to be
    //       comparable?
    range_check(tmp);
    return *tmp;
  }
  const_reference at(size_type n) const { 
    iterator tmp(begin());
    std::advance(tmp,n);
    range_check(tmp);
    return *tmp;
  }

  // Note: front,back and pop are supplied because range_view acts like
  //       a sequence.
  reference front() { return *(begin()); }
  reference back() {
    iterator tmp(end());
    --tmp;
    return *tmp;
  }
  const_reference front() const { return *(begin()); }
  const_reference back() const {
    const_iterator tmp(end());
    --tmp;
    return *tmp;
  }

  // Note: The underlying container is not modifed.
  void pop_front() { ++start; }
  void pop_back() { --stop; }
	  

 void swap(range_view &a) {
	 std::swap(start, a.start);
	 std::swap(stop, a.stop);
  }
  
protected:
  iterator start;
  iterator stop;
private:
  void range_check(iterator const &iter) const {
    if ( iter < begin() || iter > end()) 
      throw std::range_error("range_view");
  }
};

template <class container>
class subrange_view:
  public range_view<typename container::iterator,
  typename container::const_iterator> {
public:
  typedef range_view<typename container::iterator, typename container::const_iterator> inherited;
  typedef inherited::iterator aiterator; // Needed by gcc 2.95. Bug?

  explicit subrange_view() {}
  subrange_view(aiterator const& start_, aiterator const& stop_)
    : inherited(start_,stop_) {}
};

//
// Global comparator operations.
//
template <class iterator_type_1, class iterator_type_2,
          class const_iterator_type_1, class const_iterator_type_2>
bool operator==(range_view<iterator_type_1, const_iterator_type_1> const &rhs,
		range_view<iterator_type_2, const_iterator_type_2> const &lhs) {
  return check_equal(lhs.begin(), lhs.end(), rhs.begin(), rhs.end());
}

template <class iterator_type_1, class iterator_type_2,
          class const_iterator_type_1, class const_iterator_type_2>
bool operator<(range_view<iterator_type_1, const_iterator_type_1> const &rhs,
	       range_view<iterator_type_2, const_iterator_type_2> const &lhs) {
  return std::lexicographical_compare(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}
END_VIEW_NAMESPACE

//
// The swap function
//
namespace std {
template <class iterator_type, class const_iterator_type>
void swap (VIEW_NAMESPACE::range_view<iterator_type, const_iterator_type> &a,
	   VIEW_NAMESPACE::range_view<iterator_type, const_iterator_type> &b) {
  a.swap(b);
}
};
#endif	// _RANGE_VIEW_H
