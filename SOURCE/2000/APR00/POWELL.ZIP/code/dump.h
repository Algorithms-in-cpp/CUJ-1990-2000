/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_DUMP_H)
#define _DUMP_H	1

#if !defined (_SYS_LIBRARY_ITERATOR_)
#include <iostream>
#define _SYS_LIBRARY_ITERATOR_	1
#endif



using std::cout;
using std::endl;
using std::ostream;


template<class Container>
ostream & dump(ostream & os, const Container & cont_x)
{
	for( typename Container::const_iterator iter = cont_x.begin(); iter != cont_x.end(); ++iter)
	{
		os << *iter << " ";
	}
	os << endl << endl;

	return os;
}

template<class Container>
ostream & rdump(ostream & os, const Container & cont_x)
{
	for( typename Container::const_reverse_iterator iter = cont_x.rbegin(); iter != cont_x.rend(); ++iter)
	{
		os << *iter << " ";
	}
	os << endl << endl;

	return os;
}



#endif // _DUMP_H
