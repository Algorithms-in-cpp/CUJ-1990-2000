/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *
 * It has been derived from the SGI STL code, so their copyrights are here:
 *
 * Copyright (c) 1994
 * Hewlett-Packard Company
 *
 * Permission to use, copy, modify, distribute and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear
 * in supporting documentation.  Hewlett-Packard Company makes no
 * representations about the suitability of this software for any
 * purpose.  It is provided "as is" without express or implied warranty.
 *
 * Copyright (c) 1996,1997
 * Silicon Graphics
 *
 * Permission to use, copy, modify, distribute and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear
 * in supporting documentation.  Silicon Graphics makes no
 * representations about the suitability of this software for any
 * purpose.  It is provided "as is" without express or implied warranty.
 *
 */

/* NOTE: This is a drop-in replacement for the SGI STL stl_relops.h
   header file. It provides more general comparison operator templates
   as required for views. Be sure to include it BEFORE any STL header.
 */
#if !defined(_VIEW_RELOPS_H)
#define _VIEW_RELOPS_H 1

#if !defined(__SGI_STL_INTERNAL_RELOPS)
#define __SGI_STL_INTERNAL_RELOPS
#else
#error "You must include views include files before any STL header."
#endif

template <class X, class Y>
inline bool operator!=(const X& x, const Y& y) {
  return !(x == y);
}

template <class X, class Y>
inline bool operator>(const X& x, const Y& y) {
  return y < x;
}

template <class X, class Y>
inline bool operator<=(const X& x, const Y& y) {
  return !(y < x);
}

template <class X, class Y>
inline bool operator>=(const X& x, const Y& y) {
  return !(x < y);
}

#endif /* _VIEW_RELOPS_H */