/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_WINDOW_VIEW_H)
#define _WINDOW_VIEW_H	1

#if !defined(_RANGE_H)
#include "range.h"
#endif

#if !defined(_RANGE_VIEW_H)
#include "range_view.h"
#endif

// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp> void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE
// Forward declare check_equal so that you don't have to include functors.h
template <class iter_t_1, class iter_t_2>
inline bool check_equal(iter_t_1, iter_t_1,
                  iter_t_2, iter_t_2);



//
// A sequential circular iterator that counts its rounds.
//
template <class iter_t, class range_t>
class sequential_circular_iterator
  : public std::iterator<typename range_t::iterator_category,
                         std::iterator_traits<iter_t>::value_type,
                         std::iterator_traits<iter_t>::difference_type,
                         std::iterator_traits<iter_t>::pointer,
                         std::iterator_traits<iter_t>::reference> 
{
public:
  typedef typename std::iterator_traits<iter_t>::difference_type difference_type;
  typedef reference const const_reference;
  typedef pointer const   const_pointer;
  
  explicit sequential_circular_iterator() {}

  template <class container>
  sequential_circular_iterator(container& v, iter_t const& iter_, difference_type round_=0)
    : range(v), iter(iter_), round(round_) {}

  sequential_circular_iterator(iter_t const& start, iter_t const& stop, iter_t const& iter_, difference_type round_=0)
    : range(start,stop), iter(iter_), round(round_) {}

  sequential_circular_iterator(iter_t const& stop, iter_t const& iter_, difference_type round_=0)
    : range(stop), iter(iter_), round(round_) {}

  // Dereferencing is trivial here
  const_reference operator*() const { return *iter; }
  reference       operator*()       { return *iter; }
  const_pointer operator->() const { return iter.operator->(); }
  pointer       operator->()       { return iter.operator->(); }

  sequential_circular_iterator& operator++() {if (++iter==range.end()) {
    iter=range.begin(); ++round; } return *this; }
  sequential_circular_iterator  operator++(int) {
    sequential_circular_iterator tmp=*this; ++*this; return tmp; }

  // Backward stepping works only with bidirectional iterators
  sequential_circular_iterator& operator--() {
    if (iter==range.begin()) { iter=range.end(); --iter; --round; } else --iter; return *this; }
  sequential_circular_iterator  operator--(int) {
    sequential_circular_iterator tmp=*this; --*this; return tmp; }

  // Random stepping works best with random access iterators
  sequential_circular_iterator& operator+=(difference_type n) {
    if (n<0) return *this -= -n;
    difference_type size = std::distance(range.begin(),range.end());
    round += n/size;
    n %= size;
    difference_type d = std::distance(iter,range.end());
    if (d <= n) { iter = range.begin(); n -= d; ++round; }
    std::advance(iter,n);
    return *this;
  }
  sequential_circular_iterator& operator-=(difference_type n) {
    if (n<0) return *this += -n;
    difference_type size = std::distance(range.begin(),range.end());
    round -= n/size;
    n %= size;
    difference_type d = std::distance(range.begin(),iter);
    if (n > d) { iter = range.end(); n -= d; --round; }
    std::advance(iter,-n);
    return *this;
  }
  sequential_circular_iterator operator+(difference_type n) const { sequential_circular_iterator tmp = *this; return tmp += n; }
  sequential_circular_iterator operator-(difference_type n) const { sequential_circular_iterator tmp = *this; return tmp -= n; }

  template<class iter2, class range2>
  difference_type operator-(sequential_circular_iterator<iter2,range2> const &rhs) const {
    difference_type size = std::distance(range.begin(),range.end());
    return size*(round-rhs.round) + (iter-rhs.iter);
  }

  // Comparisons
  template<class iter2, class range2>
  bool operator==(const sequential_circular_iterator<iter2,range2>& rhs) const { return round==rhs.round && iter==rhs.iter;}

  template<class iter2, class range2>
  bool operator< (const sequential_circular_iterator<iter2,range2>& rhs) const {
    return round<rhs.round || (round==rhs.round && iter< rhs.iter); }
   
  // Conversion from iterator to const_iterator. This works only if there is a
  // conversion from iter_t to const_iter and range to const_range_t.
  template<class const_iter,class const_range_t>
  operator sequential_circular_iterator<const_iter,const_range_t>() const {
    return sequential_circular_iterator<const_iter,const_range_t>(range,iter,round); }

  // return the underlying container iterator.
  iter_t &get() { return iter; }
  iter_t const &get() const { return iter; }

protected:
  range_t range;
  iter_t  iter;
  difference_type round;

  // For comparisons.
  template <class iter2, class range2> friend class sequential_circular_iterator;
};
  
  
//
// window_view
//

template <class container,
          class const_tag = const_view_tag,
          class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
          template <class container, class const_tag> class proxy_template = view_ref>
class window_view {
public:
  typedef one_container_base<container,const_tag,proxy_template> base_t;
  typedef ctor_arg<container,const_tag,proxy_template>::type ctor_arg_type;
  typedef typename container::size_type size_type;
  typedef view_traits<container,const_tag>::iterator domain_iterator;
  typedef view_traits<container,const_tag>::const_iterator const_domain_iterator;
  typedef internal_range_traits<iterator_tag, view_traits<container,const_tag>::container_type, const_tag>::type       range;
  typedef internal_range_traits<iterator_tag, view_traits<container,const_tag>::container_type, const_tag>::const_type
  const_range;
  typedef range_view<sequential_circular_iterator<domain_iterator,       range>,
                     sequential_circular_iterator<const_domain_iterator, const_range> >
               range_base_t;

  typedef typename range_base_t::iterator iterator;
  typedef typename range_base_t::const_iterator const_iterator;
  typedef std::reverse_iterator<iterator>                 reverse_iterator;
  typedef std::reverse_iterator<const_iterator>           const_reverse_iterator;
  typedef std::iterator_traits<iterator>::value_type      value_type;
  typedef std::iterator_traits<iterator>::reference       reference;
  typedef const reference                                 const_reference;
  typedef std::iterator_traits<iterator>::difference_type difference_type;
  
  explicit window_view() {}

  // distance(first,last) may not be negative, otherwise we get end() < begin(). We could check for
  // first > last and increase the round of end(), but then we need random access iterators.
  // This implies that this constructor can only construct non-wrapped windows.
  window_view(ctor_arg_type& cont_a, 
              domain_iterator const& first, 
              domain_iterator const& last)
    :	base(cont_a),
        range_base(iterator(base.cont(),first),iterator(base.cont(),last)) {}

  // This constructor can construct wrapped windows as well as windows that generate multiple cycles.
  window_view(ctor_arg_type& cont_a, 
              domain_iterator const& first,
              size_type width)
    : base(cont_a),
      range_base(iterator(base.cont(),first),my_advance(iterator(base.cont(),first),width)) {}
  

  iterator       begin()       { return range_base.begin(); }
  const_iterator begin() const { return range_base.begin(); }
  iterator       end()       { return range_base.end(); }
  const_iterator end() const { return range_base.end(); }

  reverse_iterator rbegin() { return reverse_iterator(end()); }
  reverse_iterator rend()   { return reverse_iterator(begin()); }
  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator rend()   const { return const_reverse_iterator(begin()); }

  // This might be speed optimized by factoring out multiple rounds.
  // Not clear whether this would be really an improvement or not.
  size_type size() const     { return std::distance(begin(),end()); }
  size_type max_size() const { return base.cont().max_size(); }
  bool empty() const { return begin()==end(); }

  // Inherited pop_front and pop_back work like shrinking the window.

  // Shift the window right for positive n.
  void rotate(int n) {
	range_base_t::iterator start = range_base.begin();
	range_base_t::iterator stop = range_base.end();
	std::advance(start,n); 
	std::advance(stop,n);
	range_base = range_base_t(start,stop);
  }

    const_reference operator[](size_type n) const { 
    iterator tmp(begin());
    std::advance(tmp,n);
    return *tmp; 
  }
   
  reference operator[](size_type n) {
    iterator tmp(begin());
    std::advance(tmp,n);
    return *tmp;
  }

  reference at(size_type n) { 
    iterator tmp(begin());
    std::advance(tmp,n);
    // Note: we do the test after moving the iterator incase 
    // this is a ranged filter view.
    // Gary: If I remember correctly, iterators may get invalid if
    //       advanced past the end. Are they still guaranteed to be
    //       comparable?
    range_check(tmp);
    return *tmp;
  }
  const_reference at(size_type n) const { 
    iterator tmp(begin());
    std::advance(tmp,n);
    range_check(tmp);
    return *tmp;
  }

  // Note: front,back and pop are supplied because range_view acts like
  //       a sequence.
  reference front() { return *(begin()); }
  reference back() {
    iterator tmp(end());
    --tmp;
    return *tmp;
  }
  const_reference front() const { return *(begin()); }
  const_reference back() const {
    const_iterator tmp(end());
    --tmp;
    return *tmp;
  }

  // Note: The underlying container is not modifed.
  void pop_front() { 
	range_base_t::iterator start = range_base.begin();
	++start; 
	range_base = range_base_t(start,range_base.end());
  }

  void pop_back() { 
	range_base_t::iterator stop = range_base.end();
	--stop; 
	range_base = range_base_t(range_base.begin(), stop);
  }


  void swap(window_view& a) {
	std::swap(base, a.base);
    std::swap(range_base, a.range_base);
  }

protected:
  base_t base;
  range_base_t range_base;

private:
  void range_check(iterator const &iter) const {
    if ( iter < begin() || iter > end() ) 
      throw std::range_error("window_view");
  }

  iterator my_advance(iterator const& i, size_type n) const {
    iterator j(i);
    std::advance(j,n);
    return j;
  }
  
};


//
// Global comparator operations.
//

template <class container_1,class container_2,
          class const_tag_1,class const_tag_2,
		  class iterator_tag_1, class iterator_tag_2,
          template<class C, class const_tag> class proxy_template_1,
		  template<class C, class const_tag> class proxy_template_2>
bool operator==(window_view<container_1,const_tag_1,iterator_tag_1,proxy_template_1> const& lhs,
		window_view<container_2,const_tag_2,iterator_tag_2,proxy_template_2> const& rhs) {
  return check_equal(lhs.begin(), lhs.end(), rhs.begin(), rhs.end());
}


template <class container_1,class container_2,
          class const_tag_1,class const_tag_2,
		  class iterator_tag_1, class iterator_tag_2,
          template<class C, class const_tag> class proxy_template_1,
		  template<class C, class const_tag> class proxy_template_2>
bool operator<(window_view<container_1,const_tag_1,iterator_tag_1,proxy_template_1> const& lhs,
	       window_view<container_2,const_tag_2,iterator_tag_2,proxy_template_2> const& rhs) {
	return std::lexicographical_compare(lhs.begin(), lhs.end(), rhs.begin(), rhs.end());
}

END_VIEW_NAMESPACE

//
// The swap function
//
namespace std {
template <class container,
          class const_tag,
		  class iterator_tag,
          template <class container, class const_tag> class proxy_template>
void swap(VIEW_NAMESPACE::window_view<container,const_tag,iterator_tag,proxy_template> &a,
		  VIEW_NAMESPACE::window_view<container,const_tag,iterator_tag,proxy_template> &b) {
   a.swap(b);
}
};

#endif // _WINDOW_VIEW_H
