/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_UNIQUE_VIEW_H)
#define _UNIQUE_VIEW_H	1

#if !defined(_EQUAL_RANGE_VIEW_H)
#include "equal_range_view.h"
#endif

#if !defined(_TRANSFORM_VIEW_H)
#include "transform_view.h"
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

BEGIN_VIEW_NAMESPACE

template<class T, class R, class const_tag>
class FirstElement 
: public unary_function<T,R>
{
public:
	typedef select_type<argument_type, reference_traits, const_tag>::type c_argType;
	typedef select_type<result_type, reference_traits, const_tag>::type c_ResultType;

	c_ResultType operator()(c_argType x) const
	{
		return *(x.begin());
	}
};

// typedefs to make it easier to define the unique_view.
template <class container,
	      class equal_fn,
          class const_tag,
		  class iterator_tag,
          template <class C, class tag> class proxy_template>
// Not really a namespace but that's all I'm using it for.
class unique_view_namespace
{
private:
  // Integrate the const_tag into the container types.
  typedef typename view_traits<container,const_tag>::container_type domain;
  
  typedef equal_range_view< domain, equal_fn, const_tag, iterator_tag, proxy_template> er_container;

  typedef typename view_traits<er_container, const_tag>::value_type	arg_type;
  typedef typename view_traits<container, const_tag>::value_type	result_type;
 
  typedef FirstElement<arg_type, result_type, const_tag> transform_fn;
	// Define a transformation view
  typedef transform_view<er_container, transform_fn, const_tag,
		result_type,view_own >	base_view;

protected:
  // There is this one more layer so we don't have to export out
  // all of the typedefs we set up in intersection_view_namespace.
  class view : public base_view
  {
  public:
	explicit view() {}
    view(domain &a,equal_fn const & eq)
      : base_view(er_container(a), transform_fn())
    {}
  };
  
};

//
// unique_view
//
// All the unique elements that are in the container
template <class container,
          class equal_fn = equal_to<typename container::value_type>,
          class const_tag = const_view_tag,
		  class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
          template <class C, class tag> class proxy_template = view_ref>
class unique_view
	: public unique_view_namespace<container,equal_fn,const_tag,
                       iterator_tag, proxy_template>::view
{
public:  
  typedef unique_view_namespace<container,equal_fn,const_tag,
                       iterator_tag, proxy_template>::view inherited;
  typedef ctor_arg<container,const_tag,proxy_template>::type ctor_arg_type;
  
  explicit unique_view() {}
  unique_view(ctor_arg_type &cont, equal_fn const & eq = equal_fn())
    :	inherited(cont, eq) 
	{}
};

END_VIEW_NAMESPACE

#endif // _UNIQUE_VIEW_H
