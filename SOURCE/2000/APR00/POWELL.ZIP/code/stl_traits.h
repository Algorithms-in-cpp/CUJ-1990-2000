/* -*- c++ -*-
 * Copyright (c) 1999  
 * Gary Powell, Martin Weiser
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *
 */
#if !defined(_STL_TRAITS_H)
#define _STL_TRAITS_H	1


// Forward declarations of the standard containers.
namespace std {

template <typename _Ty, typename _A>
class slist;

template <typename _Ty, typename _A>
class list;

template <typename _Ty, typename _A>
class vector;

template <typename _Ty, typename _A, unsigned int __bufsiz>
class deque;

template<class _Ty, template<_Ty, class _A> class _Sequence>
class queue;

template <typename _Ty, template<_Ty, class _A> class _Sequence>
class stack;

template <typename _K, typename _Pr, typename _A>
class set;

template <typename _K, typename _Pr, typename _A>
class multiset;

template<typename _K, typename _Ty, typename _Pr, typename _A>
class map;

template<typename _K, typename _Ty, typename _Pr, typename _A>
class multimap;

// Not std but in the SGI version of the STL, and very useful.
template <class _Value, class _HashFcn, class _EqualKey, class _Alloc>
class hash_set;

template <class _Value, class _HashFcn, class _EqualKey, class _Alloc>
class hash_multiset;

template <class _Key, class _Tp, class _HashFcn, class _EqualKey,
          class _Alloc>
class hash_map;

template <class _Key, class _Tp, class _HashFcn, class _EqualKey,
          class _Alloc>
class hash_multimap;

}

BEGIN_VIEW_NAMESPACE
//
// Traits about whether the container has an internal
// find function.
//
class InternalFindElement {};
class NoInternalFindElement {};
class PairInternalEqualRange: public NoInternalFindElement {};
class KeyDataPair {};
class NotKeyDataPair {};


// default container trait.
template<class container>
class ContainerTrait
{
	typedef NoInternalFindElement	FindType;
	typedef NotKeyDataPair          ValuePairType;
};

template<typename _K, typename _Pr, typename _A> 
class ContainerTrait<std::set<_K, _Pr, _A> >
{
	typedef InternalFindElement FindType;
	typedef NotKeyDataPair      ValuePairType;
};

template<typename _K, typename _Pr, typename _A>
class ContainerTrait<std::multiset<_K, _Pr, _A> >
{
	typedef InternalFindElement FindType;
	typedef NotKeyDataPair      ValuePairType;
};

template <class _Value, class _HashFcn, class _EqualKey, class _Alloc>
class ContainerTrait<std::hash_set<_Value, _HashFcn, _EqualKey, _Alloc> >
{
	typedef InternalFindElement FindType;
	typedef NotKeyDataPair      ValuePairType;
};

template <class _Value, class _HashFcn, class _EqualKey, class _Alloc>
class ContainerTrait<std::hash_multiset<_Value, _HashFcn, _EqualKey, _Alloc> >
{
	typedef InternalFindElement FindType;
	typedef NotKeyDataPair      ValuePairType;
};
//
// Note: While map, multimap, hash_map, and hash_multimap have an
// internal find function, it finds the "key" not the data element.
// If you want a match of "{1,A}" == "{1,B}" && "1" == "{1,A}" then
// the internal find is the one for you.
template<typename _K, typename _Ty, typename _Pr, typename _A>
struct ContainerTrait<std::map<_K, _Ty, _Pr, _A> >
{
  typedef std::map<_K, _Ty, _Pr, _A> container;
  typedef PairInternalEqualRange FindType;
  typedef KeyDataPair            ValuePairType;

  static typename container::key_type const&
  key(typename container::value_type const& value) {
    return value.first;
  }
  
};

template<typename _K, typename _Ty, typename _Pr, typename _A>
struct ContainerTrait<std::multimap<_K, _Ty, _Pr, _A> >
{
  typedef std::multimap<_K, _Ty, _Pr, _A> container;
  typedef PairInternalEqualRange FindType;
  typedef KeyDataPair            ValuePairType;

  static typename container::key_type const&
  key(typename container::value_type const& value) {
    return value.first;
  }
};

template <class _Key, class _Tp, class _HashFcn, class _EqualKey,
          class _Alloc>
struct ContainerTrait<std::hash_map<_Key, _Tp, _HashFcn, _EqualKey, _Alloc> >
{
  typedef std::hash_map<_Key, _Tp, _HashFcn, _EqualKey, _Alloc> container;
  typedef PairInternalEqualRange FindType;
  typedef KeyDataPair            ValuePairType;

  static typename container::key_type const&
  key(typename container::value_type const& value) {
    return value.first;
  }
  
};

template <class _Key, class _Tp, class _HashFcn, class _EqualKey,
          class _Alloc>
struct ContainerTrait<std::hash_multimap<_Key, _Tp, _HashFcn, _EqualKey, _Alloc> >
{
  typedef std::hash_multimap<_Key, _Tp, _HashFcn, _EqualKey, _Alloc> container;
  typedef PairInternalEqualRange FindType;
  typedef KeyDataPair            ValuePairType;

  static typename container::key_type const&
  key(typename container::value_type const& value) {
    return value.first;
  }
};

END_VIEW_NAMESPACE

#endif // _STL_TRAITS_H
