/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined (_RANGE_H)
#define _RANGE_H 1

#if !defined(_VIEW_BASE_H)
#include "view_base.h"
#endif


#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp>
	void swap(_Tp&, _Tp&);
};

BEGIN_VIEW_NAMESPACE
//
// Range classes. Ranges provide at least an end() method, returning
// an iterator that points to the end of the denoted range (past the
// end, as always in STL).  Additionally they provide the
// iterator_category type which is forward_iterator_tag or, if
// additionally a begin() method is provided,
// random_access_iterator_tag.  The iterator_category type denotes the
// restrictions this range puts on iterators using this range.
//
// Ranges are assignable and default constructible.
//

//
// A data containing proxy_template class for one container views that can be
// easily referenced by iterators without infinite template recursion.
//
template <class container,
		 class const_tag, 
		 template<class container, class const_tag> class proxy_template>
class one_container_base {
public:
  typedef proxy_template<container,const_tag> inherited;
  typedef ctor_arg<container,const_tag,proxy_template>::type ctor_arg_type;
  typedef typename view_traits<container,const_tag>::container_type domain_type;
  typedef typename view_traits<container,const_tag>::iterator       domain_iterator;
  typedef typename view_traits<container,const_tag>::const_iterator const_domain_iterator;

  // Default constructible. Not useful when default constructed.
  explicit one_container_base() {}

  explicit one_container_base(ctor_arg_type& cont): a(cont) {}

  void swap(one_container_base& u) { std::swap(a,u.a);}    

  domain_type& cont() { return a.cont(); }
  const domain_type& cont() const { return a.cont(); }  

protected:
  inherited a;
};

//
// A bidirectional range given by a containers/ranges begin() and end() methods.
//
template <class container, class const_tag>
class range_ref {
public:
  typedef ctor_arg<container,const_tag,view_ref>::type ctor_arg_type;
  typedef typename view_traits<container,const_tag>::container_type domain_type;
  typedef typename view_traits<container,const_tag>::iterator       domain_iterator;
  typedef typename view_traits<container,const_tag>::const_iterator const_domain_iterator;
  typedef combine_iterator_categories<std::random_access_iterator_tag,
                                      std::iterator_traits<domain_iterator>::iterator_category>::type iterator_category;

  // Default constructible. Not useful when default constructed.
  explicit range_ref(): ref(0) {}

  explicit range_ref(ctor_arg_type & cont): ref(&cont) {}

  const_domain_iterator begin() const { return ref->begin(); }
  domain_iterator       begin()       { return ref->begin(); }
  const_domain_iterator end()   const { return ref->end(); }
  domain_iterator       end()         { return ref->end(); }

  // const conversion.
  template<class const_container, class const_const_tag>
	  operator range_ref<const_container, const_const_tag>() const {
	  return range_ref<const_container, const_const_tag>(*ref); }

protected:
  domain_type* ref;
};

//
// A forward range defined by its end iterator.
//
template <class container, class const_tag>
class forward_range_own {
public:  
  typedef typename view_traits<container,const_tag>::container_type domain_type;
  typedef typename view_traits<container,const_tag>::iterator       iterator;
  typedef typename view_traits<container,const_tag>::const_iterator const_iterator;
  typedef combine_iterator_categories<std::forward_iterator_tag,
                                      std::iterator_traits<iterator>::iterator_category>::type iterator_category;

  // Default constructible. Not useful when default constructed.
  explicit forward_range_own() {}
  explicit forward_range_own(iterator const& rhs): stop(rhs) {}
  explicit forward_range_own(domain_type& rhs): stop(rhs.end()) {}

  // Nonconst -> const conversion
  operator forward_range_own<container,const_view_tag>() const {
    return forward_range_own<container,const_view_tag>(end()); }
  
  iterator       end()  const       { return stop; }

protected:
  iterator stop;
};


//
// A bidirectional range given by its begin and end iterators.
//
template <class container, class const_tag>
class bidirectional_range_own: public forward_range_own<container,const_tag> {
public:
  typedef forward_range_own<container,const_tag> inherited;
  typedef typename view_traits<container,const_tag>::container_type domain_type;
  typedef typename view_traits<container,const_tag>::iterator       iterator;
  typedef typename view_traits<container,const_tag>::const_iterator const_iterator;
  typedef combine_iterator_categories<std::random_access_iterator_tag,
                                      std::iterator_traits<iterator>::iterator_category>::type iterator_category;

  // Default constructible. Not useful when default constructed.
  explicit bidirectional_range_own() {}

  template<class const_iter_t>
  bidirectional_range_own(const_iter_t const& start_, const_iter_t const& stop_)
    : inherited(stop_), start(start_) {}

  explicit bidirectional_range_own(domain_type& cont)
    : inherited(cont), start(cont.begin()) {}

  // Nonconst -> const conversion
  operator bidirectional_range_own<container,const_view_tag>() const {
    return bidirectional_range_own<container,const_view_tag>(begin(),end()); }

  iterator       begin() const    { return start; }

protected:
  iterator start;
};

//
// Traits mapping an iterator category to the smallest xxx_range_own
// range that does not artificailly limit the possibilities of the
// iterator it's based on.
//

template <class iterator_category, class container, class const_tag>
struct internal_range_traits { 
  typedef forward_range_own<container,const_tag>      type; 
  typedef forward_range_own<container,const_view_tag> const_type; 
};

template <class container, class const_tag>
struct internal_range_traits<std::bidirectional_iterator_tag, container, const_tag> {
  typedef bidirectional_range_own<container,const_tag>      type; 
  typedef bidirectional_range_own<container,const_view_tag> const_type; 
};

template <class container, class const_tag>
struct internal_range_traits<std::random_access_iterator_tag, container, const_tag> {
  typedef bidirectional_range_own<container,const_tag> type; 
  typedef bidirectional_range_own<container,const_view_tag> const_type; 
};

template <class container, class const_tag>
struct range_traits {
  typedef std::iterator_traits<typename container::iterator>::iterator_category category;
  
  typedef internal_range_traits<category,container,const_tag>::type type; 
};

END_VIEW_NAMESPACE
//
// The swap function
//
namespace std {
template <class container,
  class const_tag,
  template<class container, class const_tag> class proxy_template >
void swap(VIEW_NAMESPACE::one_container_base<container,const_tag,proxy_template>& a,
	  VIEW_NAMESPACE::one_container_base<container,const_tag,proxy_template>& b) {
  a.swap(b);
}
};

// $Id: range.h,v 1.2 1999/09/16 08:04:29 bzfweise Exp $
#endif
