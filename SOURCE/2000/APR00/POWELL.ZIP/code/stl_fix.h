/* Copyright (c) 1999  
 * Gary Powell, Martin Weiser
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *
 */

#if !defined(_STL_FIX_H)
#define _STL_FIX_H 1

//
// SGI STL as of Oct 99 does not do the iterator comparisons right.
//

// Forward declaration such that we need not include <deque>
//namespace std {
//template <class _Tp, class _Ref, class _Ptr, size_t __bufsiz> struct _Deque_iterator;
//;

template <class T, size_t nodesize>
bool operator==(_Deque_iterator<T,T &,T *,nodesize> const& lhs,
                _Deque_iterator<T,const T &,const T &,nodesize> const& rhs) {
  return rhs==lhs;	// reverse the arguments, and try again.
}

template <class T, size_t nodesize>
bool operator< (_Deque_iterator<T,T &,T *,nodesize> const& lhs,
                _Deque_iterator<T,const T &,const T &,nodesize> const& rhs) {
	return !(rhs < lhs) && !(rhs == lhs);	// reverse the arguments, and try again.
}


#endif // _STL_FIX_H
