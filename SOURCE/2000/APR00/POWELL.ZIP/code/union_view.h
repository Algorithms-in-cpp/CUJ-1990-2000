/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#ifndef _UNION_VIEW_H
#define _UNION_VIEW_H	1

#if !defined(_TWO_CONTAINERS_BASE_H)
#include "two_containers_base.h"
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

#if !defined(_SYS_LIBRARY_STDEXCEPT_)
#include <stdexcept>
#define _SYS_LIBRARY_STDEXCEPT_
#endif


  
// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp> void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool equal(_InputIter1, _InputIter1,
                  _InputIter2);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE

template <class iter_t_a, class iter_t_b>
class union_range_own {
public:
  typedef combine_three_iterator_tags<iter_t_a, 
            iter_t_b, 
            forward_iterator<std::iterator_traits<iter_t_a>::value_type,
            std::iterator_traits<iter_t_a>::difference_type> >::type iterator_category;

  template<class base>
  union_range_own(base& u)
    : stop_a(u.end_a() ) {}
  
  union_range_own(const iter_t_a& stop_a_)
    : stop_a(stop_a_) {}
  
  // Default constructible. Be careful! A default constructed union_base_ref
  // has a completely undefined behavior, the only exception being
  // assignment.
  union_range_own() {}

  const iter_t_a end_a() const { return stop_a; }

protected:
  iter_t_a stop_a;
};

template <class  iter_t_a, class iter_t_b>
class bidirectional_union_range_own: public union_range_own<iter_t_a,iter_t_b> {
public:
  typedef union_range_own<iter_t_a,iter_t_b> inherited;
  typedef combine_iterator_tags<iter_t_a, 
								iter_t_b >::type iterator_category;
  
  template<class base>
  bidirectional_union_range_own(base& u)
    : inherited(u), start_b(u.begin_b()) {}
  
  bidirectional_union_range_own(const iter_t_a& stop_a_, const iter_t_b&  start_b_)
    : inherited(stop_a_), start_b(start_b_) {}
  
  // Default constructible. Be careful! A default constructed union_base_ref
  // has a completely undefined behavior, the only exception being
  // assignment.
  bidirectional_union_range_own() {}

  const iter_t_b begin_b() const { return start_b; }

protected:
  iter_t_b start_b;
};

//
// Traits mapping an iterator category to the smallest xxx_range_own
// range that does not artificailly limit the possibilities of the
// iterator it's based on.
//

template <class iterator_category, class container_a, class container_b, class const_tag>
struct internal_union_traits { 
  typedef view_traits<container_a,const_tag>::iterator       domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::iterator       domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;

  typedef union_range_own<domain_a_iterator,
							domain_b_iterator>      type; 
  typedef union_range_own<domain_a_const_iterator,
						domain_b_const_iterator> const_type;  
};

template <class container_a, class container_b, class const_tag>
struct internal_union_traits<std::bidirectional_iterator_tag, container_a, container_b, const_tag> {
  typedef view_traits<container_a,const_tag>::iterator       domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::iterator       domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;

  typedef bidirectional_union_range_own<domain_a_iterator,
							domain_b_iterator>      type; 
  typedef bidirectional_union_range_own<domain_a_const_iterator,
						domain_b_const_iterator> const_type; 
};

template <class container_a, class container_b, class const_tag>
struct internal_union_traits<std::random_access_iterator_tag, container_a, container_b, const_tag> {
  typedef view_traits<container_a,const_tag>::iterator       domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::iterator       domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;

  typedef bidirectional_union_range_own<domain_a_iterator,
							domain_b_iterator>      type; 
  typedef bidirectional_union_range_own<domain_a_const_iterator,
						domain_b_const_iterator> const_type; 
};

template <class container_a, class container_b, class const_tag>
struct union_traits {
  typedef combine_iterator_tags<typename container_a::iterator,
								typename container_b::iterator>::type category;
  
  typedef internal_union_traits<category,container_a,container_b,const_tag>::type type; 
};


//
// A union iterator template
//


template <class iter_t_a, class iter_t_b,
          class base>
class union_iterator
: public std::iterator<typename base::iterator_category,
    std::iterator_traits<iter_t_a>::value_type,
    std::iterator_traits<iter_t_a>::difference_type,
    std::iterator_traits<iter_t_a>::pointer,
    combine_const_ref<std::iterator_traits<iter_t_a>::reference,
    std::iterator_traits<iter_t_b>::reference>::type > {
public:
  
  // Iterators must be default constructible.
  explicit union_iterator() {}

  template<class view>
  union_iterator(view& v,
		 const iter_t_a& iter_a_, const iter_t_b& iter_b_)
    : range(v), iter_a(iter_a_), iter_b(iter_b_) {}

  explicit union_iterator(const iter_t_a& stop)
    : range(stop) {}

  union_iterator(const iter_t_a& stop, const iter_t_b& start)
    : range(stop,start) {}

  union_iterator(const base& range_,
		 const iter_t_a& iter_a_, const iter_t_b& iter_b_)
    : range(range_), iter_a(iter_a_), iter_b(iter_b_) {}
  

  // The invariant of the iterator is
  // iter_a==range.end_a() || iter_b==range.begin_b()
  
  const reference operator*() const {
    return range.end_a()==iter_a? *iter_b: *iter_a; }
  reference operator*() {
    return range.end_a()==iter_a? *iter_b: *iter_a; }
  const pointer operator->() const {
    return range.end_a()==iter_a? iter_b.operator->(): iter_a.operator->(); }
  pointer operator->() {
    return range.end_a()==iter_a? iter_b.operator->(): iter_a.operator->(); }

  // Forward stepping.
  union_iterator& operator++() {
    if(iter_a==range.end_a()) ++iter_b; else ++iter_a; return *this; }
  union_iterator operator++(int) {
    union_iterator tmp=*this; ++*this; return tmp; }

  // Backward stepping. This works only with bidirectional iterators.
  union_iterator& operator--() {
    if (range.begin_b()==iter_b) --iter_a; else --iter_b; return *this; }
  union_iterator operator--(int) {
    union_iterator tmp=*this; --*this; return tmp; }

  // Random stepping. This works best with random access iterators.
  union_iterator& operator+=(int n) {
    if (n<0) return *this -= -n;
      difference_type m = std::distance(iter_a,range.end_a());
      if (m < n) { iter_a = range.end_a(); std::advance(iter_b,n-m); }
      else std::advance(iter_a,n);
     return *this; 
	}
  union_iterator& operator-=(int n) { 
    if (n<0) return *this += -n;
      difference_type m = std::distance(range.begin_b(),iter_b);
      if (m < n) { iter_b = range.begin_b(); std::advance(iter_a,m-n); }
      else std::advance(iter_b,-n);
     return *this; 
  }

  // Need the bidirectional_union_range_own for this to work.
  difference_type operator-(const union_iterator& rhs ) const {
    if (range.end_a() == iter_a)
	{
		if (rhs.range.end_a() == rhs.iter_a)
		{
			return std::distance(iter_b,rhs.iter_b);	// both iterators in container_b.
		}
		return std::distance(range.begin_b(), iter_b) + std::distance(rhs.iter_a, rhs.range.end_a());
	}
	if (rhs.range.end_a() == rhs.iter_a)
	{
		return -(std::distance(iter_a, range.end_a()) + std::distance(rhs.range.begin_b(), rhs.iter_b));
	}
	return std::distance(iter_a,rhs.iter_a);	// both iterators in container_a.
  }

  union_iterator operator+(difference_type n) const {
    union_iterator tmp(*this);
    return tmp += n;
  }
  union_iterator operator-(difference_type n) const {
    union_iterator tmp(*this);
    return tmp -= n;
  }
  
    
  // Comparisons
  template <class itera2, class iterb2, class range2>
  bool operator==(const union_iterator<itera2,iterb2,range2>& rhs) const {
    return iter_a==rhs.iter_a && iter_b==rhs.iter_b; }
  
  template <class itera2, class iterb2, class range2>
  bool operator<(const union_iterator<itera2,iterb2,range2>& rhs) const {
    return iter_a<rhs.iter_a || iter_b<rhs.iter_b; }

  // Conversion from iterator to const_iterator. This works only if
  // there is a conversion from iter_t to const_iter and base to const_base_t.
  template <class const_iter_a, class const_iter_b, class const_base_t>
  operator union_iterator<const_iter_a,const_iter_b,const_base_t>() const {
    return union_iterator<const_iter_a,const_iter_b,const_base_t>(range,iter_a,iter_b); }
  
    
  reference operator[](difference_type n) const { return *(*this + n); }

protected:
  base range;
  iter_t_a iter_a;
  iter_t_b iter_b;

private:
  // All union_iterators are friends of each other.
  template <class const_iter_a, class const_iter_b, class const_base_t>
  friend class union_iterator;
};

//
// A union view.
//
// The iterators for the iter_base template can be const_iterators, since they
// only mark the ranges.
//
template <class container_a, class container_b,
          class const_tag = const_view_tag,
		  class iterator_tag = typename combine_iterator_tags<typename container_a::iterator,
								                              typename container_b::iterator>::type,
          template<class container, class const_tag> class proxy_template_a = view_ref,
          template<class container, class const_tag> class proxy_template_b = view_ref>
class union_view {
public:
  typedef typename container_a::value_type value_type;
  typedef typename container_a::pointer pointer;
  typedef typename container_a::reference reference;
  typedef typename container_a::const_reference const_reference;
  typedef typename container_a::size_type size_type;
  typedef typename container_a::difference_type difference_type;
  
  typedef two_containers_base<container_a,container_b,const_tag,
								proxy_template_a,proxy_template_b> base_t;

  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;
  typedef typename view_traits<container_a,const_tag>::iterator domain_a_iterator;
  typedef typename view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef typename view_traits<container_b,const_tag>::iterator domain_b_iterator;
  typedef typename view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;

  typedef internal_union_traits<iterator_tag, container_a, container_b,const_tag>::type	        iter_base;
  typedef internal_union_traits<iterator_tag, container_a, container_b,const_tag>::const_type	const_iter_base;

  typedef union_iterator<domain_a_iterator,domain_b_iterator,iter_base> iterator;
  typedef union_iterator<domain_a_const_iterator,domain_b_const_iterator,
    const_iter_base> const_iterator;
  typedef std::reverse_iterator<iterator> reverse_iterator;
  typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

  explicit union_view() {}
  union_view(ctor_arg_type_a& cont_a, ctor_arg_type_b& cont_b)
    : base(cont_a,cont_b) {}

  const_iterator begin() const {
    return const_iterator(base,base.a().begin(),base.b().begin()); }
  const_iterator end() const {
    return const_iterator(base,base.a().end(),base.b().end()); }
  iterator begin() {
    return iterator(base,base.a().begin(),base.b().begin()); }
  iterator end() {
    return iterator(base,base.a().end(),base.b().end()); }

  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator rend() const { return const_reverse_iterator(begin()); }
  reverse_iterator rbegin() { return reverse_iterator(end()); }
  reverse_iterator rend() { return reverse_iterator(begin()); }

  size_type size() const { return base.a().size()+base.b().size(); }
  size_type max_size() const {
    // Here comes a hack against overflow problems. Not really satisfactory, though.
    size_type sum = base.a().max_size()+base.b().max_size();
    size_type maximum = std::max(base.a().max_size(),base.b().max_size());
    return std::max(sum,maximum);
  }
  bool empty() const { return base.a().empty() && base.b().empty(); }

  const_reference operator[] (size_type n) const { 
    iterator tmp(start);
    std::advance(tmp,n);
    return *tmp; 
  }
   
  reference operator[] (size_type n) {
    iterator tmp(start);
    std::advance(tmp,n);
    return *tmp;
  }

  reference at(size_type n) { 
    range_check(n);	
    iterator tmp(start);
    std::advance(tmp,n);
    return *tmp;
  }
  const_reference at(size_type n) const { 
    range_check(n);
    iterator tmp(start);
    std::advance(tmp,n);
    return *tmp;
  }

  // Note: front,back and pop are supplied because union_view acts like
  //       a sequence. (back requires a bidirectional view.)
  reference front() { return *(begin()); }
  reference back() {
    iterator tmp(end());
    --tmp;
    return *tmp;
  }
  const_reference front() const { return *(begin()); }
  const_reference back() const {
    const_iterator tmp(end());
    --tmp;
    return *tmp;
  }

  void swap(union_view &rhs)
  {
	  std::swap(base, rhs.base);
  }

protected:
  base_t base;

private:
  void range_check(size_type n) const {
	  if (n < 0 || n >= size()) throw std::range_error("union_view");
  }
};


//
// Global comparator operations.
//
template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
          class const_tag_1, class const_tag_2,
          class iterator_tag_1, class iterator_tag_2,
          template<class container, class const_tag> class proxy_template_a_1,
          template<class container, class const_tag> class proxy_template_b_1,
          template<class container, class const_tag> class proxy_template_a_2,
          template<class container, class const_tag> class proxy_template_b_2>
bool operator==(union_view<container_a_1,container_b_1,
	       const_tag_1,iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const & rhs,
		union_view<container_a_2,container_b_2,
	       const_tag_2,iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const & lhs) {
  return rhs.size() == lhs.size() && std::equal(rhs.begin(), rhs.end(), lhs.begin());
}

template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
          class const_tag_1, class const_tag_2,
          class iterator_tag_1, class iterator_tag_2,
          template<class container, class const_tag> class proxy_template_a_1,
          template<class container, class const_tag> class proxy_template_b_1,
          template<class container, class const_tag> class proxy_template_a_2,
          template<class container, class const_tag> class proxy_template_b_2>
bool operator<(union_view<container_a_1,container_b_1,
	       const_tag_1,iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const & rhs,
	       union_view<container_a_2,container_b_2,
	       const_tag_2,iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const & lhs) {
	return std::lexicographical_compare(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}

END_VIEW_NAMESPACE

//
// The swap function
//
namespace std {
template <class container_a, class container_b,
          class const_tag,
		  class iterator_tag,
          template<class container, class const_tag> class proxy_template_a,
          template<class container, class const_tag> class proxy_template_b>
void swap (VIEW_NAMESPACE::union_view<container_a,container_b,const_tag,iterator_tag,proxy_template_a,proxy_template_b> &a,
		   VIEW_NAMESPACE::union_view<container_a,container_b,const_tag,iterator_tag,proxy_template_a,proxy_template_b> &b)
{
	a.swap(b);
}
};

#endif	// _UNION_VIEW_H
