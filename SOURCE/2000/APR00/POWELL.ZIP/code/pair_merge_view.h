/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#ifndef _PAIR_MERGE_VIEW_H
#define _PAIR_MERGE_VIEW_H	1

#if !defined(_TWO_CONTIANERS_BASE_H)
#include "two_containers_base.h"
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

#if !defined(_SYS_LIBRARY_ALGORITHM_)
#include <algorithm>	// for pair & swap & lexicographical_compare & equal
#define _SYS_LIBRARY_ALGORITHM_
#endif

#if !defined(_SYS_LIBRARY_CASSERT_)
#include <cassert>
#define _SYS_LIBRARY_CASSERT_
#endif

BEGIN_VIEW_NAMESPACE
// Used only by pair_merge_view
// This compares two ranges [a,b) and [x,y) where it is assumed that
// all the elements in the same range compare equal by the given comparator.
// Thus, the comparison of the ranges just performs a comparison of the first elements.
// Neither of the range may be empty.
template<class comparator, class range_a, class range_b>
class CompareContentsOfPairFirst 
  : public binary_function<range_a const&, range_b const&, bool>
{
private:
comparator precedes_fn;
public:
  CompareContentsOfPairFirst() {}
  
  CompareContentsOfPairFirst(comparator const &comp) : precedes_fn(comp) {}

  bool operator()(range_a const &lhs, range_b const &rhs) const {
    return precedes_fn(*lhs.begin(),*rhs.begin());
  }

  template<class const_range_a, class const_range_b>
	  operator  CompareContentsOfPairFirst<comparator, const_range_a, const_range_b>() const {
	  return CompareContentsOfPairFirst<comparator, const_range_a, const_range_b> (precedes_fn);}
};

//
// A pair_merge_iterator template
//
template <class iter_t_a, class iter_t_b, class range_t>
struct pair_merge_iterator_traits {
  typedef combine_iterator_tags<iter_t_a,iter_t_b>::type tmp1;
  typedef combine_iterator_categories<tmp1,typename range_t::iterator_category>::type tmp2;
  typedef combine_iterator_categories<tmp2,bidirectional_iterator_tag>::type iterator_category;
};


template <class iter_t_a, class iter_t_b,
          class comparator,
          class range_t>
class pair_merge_iterator
: public std::iterator<pair_merge_iterator_traits<iter_t_a,iter_t_b,range_t>::iterator_category,
                    std::pair<iter_t_a, iter_t_b>,
                    std::iterator_traits<iter_t_a>::difference_type,
                    std::pair<iter_t_a, iter_t_b>*,
                    std::pair<iter_t_a, iter_t_b> > {
public:
  typedef std::iterator_traits<iter_t_a>::value_type const& a_reference_type;
  typedef std::iterator_traits<iter_t_b>::value_type const& b_reference_type;
  typedef std::pair<iter_t_a, iter_t_b> const const_reference;

  typedef member_access_proxy<std::pair<iter_t_a, iter_t_b> > pointer;
  typedef const pointer const_pointer;

  // Iterators must be default constructible.
  pair_merge_iterator() {}
  
  template<class view>
  pair_merge_iterator(view& v,
                      const iter_t_a& iter_a_, const iter_t_b& iter_b_, 
                      const comparator & comp)
    : range(v), iter_a(iter_a_), iter_b(iter_b_), precedes(comp) {}

  pair_merge_iterator(const range_t& range_,
                      const iter_t_a& iter_a, const iter_t_b& iter_b_, 
                      const comparator & comp)
    : range(range_), iter_a(iter_a_), iter_b(iter_b_), precedes(comp) {}
  
  const_reference operator*() const {
    if (iter_a!=range.end_a() && iter_b!=range.end_b()) {
      if (precedes(*iter_a,*iter_b)) return const_reference(iter_a,range.end_b());
      if (precedes(*iter_b,*iter_a)) return const_reference(range.end_a(),iter_b);
      return const_reference(iter_a,iter_b);
    }
    return const_reference(iter_a,iter_b);
  }

  reference operator*() { return (const_cast<pair_merge_iterator const *>(this)->operator*()); }
  const_pointer operator->() const { return const_pointer(this->operator*() ); }
  pointer       operator->()       { pointer(this->operator*() ); }

  // Forward stepping.
  pair_merge_iterator& operator++() {
    assert(!(iter_a == range.end_a() && iter_b == range.end_b()) );

    if      (iter_a == range.end_a() ) ++iter_b;
    else if (iter_b == range.end_b() ) ++iter_a;
    else if (precedes(*iter_a, *iter_b) ) ++iter_a;
    else if (precedes(*iter_b, *iter_a) ) ++iter_b;
    else                        { ++iter_a; ++iter_b; }
    return *this; }
  pair_merge_iterator operator++(int) {
    pair_merge_iterator tmp=*this; ++*this; return tmp; }

  // Backward stepping. This works only with bidirectional iterators.
  pair_merge_iterator& operator--() {
    assert(!(iter_a == range.begin_a() && iter_b == range.begin_b() ));

    if      (iter_a == range.begin_a() ) { --iter_b; }
    else if (iter_b == range.begin_b() ) { --iter_a; }
    else {
      // avoiding *(iter - 1) allows us to use non random access containers.
      iter_t_a tmp_a = iter_a;
      --tmp_a;
      iter_t_b tmp_b = iter_b;
      --tmp_b;
      const a_reference_type a = *tmp_a;
      const b_reference_type b = *tmp_b;
      
      if      (precedes(a, b) ) iter_b = tmp_b; 
      else if (precedes(b, a) ) iter_a = tmp_a;
      else                      {iter_a = tmp_a; iter_b = tmp_b; }
    }
    return *this; }
  pair_merge_iterator operator--(int) {
    pair_merge_iterator tmp=*this; --*this; return tmp; }
  
  // Comparisons
  template <class itera2, class iterb2, class comparator2, class range2>
  bool operator==(const pair_merge_iterator<itera2,iterb2,comparator2,range2>& rhs) const {
    return iter_a==rhs.iter_a && iter_b==rhs.iter_b; }
    
  template <class itera2, class iterb2, class comparator2, class range2>
  bool operator< (const pair_merge_iterator<itera2,iterb2,comparator2,range2>& rhs)  const {
    return iter_a<rhs.iter_a || iter_b<rhs.iter_b; }
  

  // Conversion from iterator to const_iterator. This works only if
  // there is a conversion from iter_t to const_iter and range_t to const_range_t.
  template <class const_iter_a, class const_iter_b, class const_comparator, class const_range_t>
  operator pair_merge_iterator<const_iter_a,const_iter_b,
				const_comparator,const_range_t>() const {
    return pair_merge_iterator<const_iter_a,const_iter_b,
				const_comparator,const_range_t>(range,iter_a,iter_b,precedes); }
  
protected:
  range_t range;
  iter_t_a iter_a;
  iter_t_b iter_b;
  comparator precedes;

  template <class itera2, class iterb2, class comparator2, class range2>
  friend class pair_merge_iterator;
};

//
// A pair_merge_view.
//
// A view with two sorted containers, where an iterator will
// return the next in order item.
//
// The iterators for the iter_base template can be const_iterators, since they
// only mark the ranges.
//
template <class container_a, class container_b,
          class precedes_fn = std::less<dereference_traits<typename container_a::value_type::value_type>::type>,
          class const_tag = const_view_tag,
		  class iterator_tag = typename combine_iterator_tags<typename container_a::iterator,
								                              typename container_b::iterator>::type,
          template<class container, class const_tag> class proxy_template_a = view_ref,
          template<class container, class const_tag> class proxy_template_b = view_ref >
class pair_merge_view {
public:
  typedef typename container_a::size_type size_type;
  typedef typename container_a::difference_type difference_type;
  
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;
  typedef view_traits<container_a,const_tag>::container_type domain_a_type;
  typedef view_traits<container_a,const_tag>::iterator       domain_a_iterator;
  typedef view_traits<container_a,const_tag>::const_iterator domain_a_const_iterator;
  typedef view_traits<container_b,const_tag>::container_type domain_b_type;
  typedef view_traits<container_b,const_tag>::iterator       domain_b_iterator;
  typedef view_traits<container_b,const_tag>::const_iterator domain_b_const_iterator;
  typedef two_containers_base<container_a,container_b,const_tag,
				proxy_template_a,proxy_template_b> base_t;
  typedef CompareContentsOfPairFirst<precedes_fn,
	                             typename domain_a_iterator::value_type,
	                             typename domain_b_iterator::value_type> compare_fn;

  typedef CompareContentsOfPairFirst<precedes_fn,
	                             typename domain_a_const_iterator::value_type,
	                             typename domain_b_const_iterator::value_type> const_compare_fn;

  typedef pair<typename container_a::value_type,typename container_b::value_type> value_type;
  typedef pair<typename container_a::value_type,typename container_b::value_type> reference;
  typedef pair<typename container_a::value_type,typename container_b::value_type> const const_reference;
  typedef member_access_proxy<pair<typename container_a::value_type,typename container_b::value_type> > pointer;
  typedef const pointer const_pointer;

  typedef internal_two_range_traits<iterator_tag, container_a, container_b,const_tag>::type	        iter_base;
  typedef internal_two_range_traits<iterator_tag, container_a, container_b,const_tag>::const_type	const_iter_base;


  typedef pair_merge_iterator<domain_a_iterator,      domain_b_iterator,      compare_fn,      iter_base>       iterator;
  typedef pair_merge_iterator<domain_a_const_iterator,domain_b_const_iterator,const_compare_fn,const_iter_base> const_iterator;
  typedef std::reverse_iterator<iterator>       reverse_iterator;
  typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

  // Views need to be default constructible.
  explicit pair_merge_view() {}
  
  pair_merge_view(ctor_arg_type_a& cont_a, ctor_arg_type_b& cont_b, 
                  const precedes_fn &comp = precedes_fn())
    : base(cont_a,cont_b),
      precedes(comp)
  {}

  const_iterator begin() const {
    return const_iterator(base,base.a().begin(),base.b().begin(), precedes); }
  const_iterator end() const {
    return const_iterator(base,base.a().end(),base.b().end(), precedes); }
  iterator begin() {
    return iterator(base,base.a().begin(),base.b().begin(), precedes); }
  iterator end() {
    return iterator(base,base.a().end(),base.b().end(), precedes); }

  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator rend() const { return const_reverse_iterator(begin()); }
  reverse_iterator rbegin() { return reverse_iterator(end()); }
  reverse_iterator rend() { return reverse_iterator(begin()); }

  size_type size() const { return base.a().size()+base.b().size(); }
  size_type max_size() const {
    // Here comes a hack against overflow problems. Not really satisfactory, though.
    size_type sum = base.a().max_size()+base.b().max_size();
    size_type maximum = max(base.a().max_size(),base.b().max_size());
    return max(sum,maximum);
  }
  bool empty() const { return base.a().empty() && base.b().empty(); }

  void swap(pair_merge_view &rhs)
  {
	  std::swap(precedes, rhs.precedes);
	  std::swap(base,rhs.base);
  }
protected:
	base_t base;
	compare_fn precedes;
};

//
// Global precedes_fn operations.
//
template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
          class precedes_fn_1, class precedes_fn_2,
          class const_tag_1, class const_tag_2,
          class iterator_tag_1, class iterator_tag_2,
          template<class container, class const_tag> class proxy_template_a_1,
          template<class container, class const_tag> class proxy_template_b_1,
          template<class container, class const_tag> class proxy_template_a_2,
          template<class container, class const_tag> class proxy_template_b_2>
bool operator==(pair_merge_view<container_a_1,container_b_1,
		precedes_fn_1,const_tag_1,iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const & rhs,
		pair_merge_view<container_a_2,container_b_2,
		precedes_fn_2,const_tag_2,iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const & lhs) {
	return rhs.size() == lhs.size() && std::equal(rhs.begin(), rhs.end(), lhs.begin());
}

template <class container_a_1,class container_b_1,class container_a_2, class container_b_2,
          class precedes_fn_1, class precedes_fn_2,
          class const_tag_1, class const_tag_2,
          class iterator_tag_1, class iterator_tag_2,
          template<class container, class const_tag> class proxy_template_a_1,
          template<class container, class const_tag> class proxy_template_b_1,
          template<class container, class const_tag> class proxy_template_a_2,
          template<class container, class const_tag> class proxy_template_b_2>
bool operator<(pair_merge_view<container_a_1,container_b_1,
		precedes_fn_1,const_tag_1,iterator_tag_1,proxy_template_a_1,proxy_template_b_1> const & rhs,
	       pair_merge_view<container_a_2,container_b_2,
		precedes_fn_2,const_tag_2,iterator_tag_2,proxy_template_a_2,proxy_template_b_2> const & lhs) {
	return std::lexicographical_compare(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}

END_VIEW_NAMESPACE
//
// The swap function
//

namespace std {
template <class container_a, class container_b,
          class precedes_fn,
          class const_tag,
		  class iterator_tag,
          template<class container, class const_tag> class proxy_template_a,
          template<class container, class const_tag> class proxy_template_b>
void swap(VIEW_NAMESPACE::pair_merge_view<container_a,container_b,
	             precedes_fn,const_tag,iterator_tag,proxy_template_a,proxy_template_b>& a,
	  VIEW_NAMESPACE::pair_merge_view<container_a,container_b,
	             precedes_fn,const_tag,iterator_tag,proxy_template_a,proxy_template_b>& b) {
  a.swap(b);
}
};


#endif	// _PAIR_MERGE_VIEW_H
