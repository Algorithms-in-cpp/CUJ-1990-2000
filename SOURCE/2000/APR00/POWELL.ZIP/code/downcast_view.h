/* -*- c++ -*-
 * Copyright (c) 1999  
 * Gary Powell, Martin Weiser
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 *
 */
#if !defined(_DOWNCAST_VIEW_H)
#define _DOWNCAST_VIEW_H	1

#if !defined(_VIEW_TRAITS_H)
#include "view_traits.h"
#endif

#if !defined(_FILTER_VIEW_H)
#include "filter_view.h"
#endif

#if !defined(_FUNCTORS_H)
#include "functors.h"
#endif

#if !defined(_POLYMORPHIC_VIEW_H)
#include "polymorphic_view.h"
#endif

BEGIN_VIEW_NAMESPACE

//
// This struct is misused as a local namespace to ease the writing of all
// those typedefs.
//
template <class container,
          class derivedType,
          class const_tag = const_view_tag,
		  class iterator_tag,
          template <class C, class const_tag> class base = view_ref>
class downcast_namespace {
private:  
  typedef typename view_traits<container,const_tag>::container_type domain_type;
  typedef std::iterator_traits<typename domain_type::value_type>::value_type baseType;
  typedef downcast<baseType,derivedType> downcast_fn;

  typedef downcast_fn::result_type derivedPointerType;
  typedef transform_view<domain_type, downcast_fn,
    const_tag, derivedPointerType, base> downcasted;
  
  typedef is_nonzero<derivedPointerType> is_nonzero_fn;
  typedef filter_view<downcasted, is_nonzero_fn, const_tag, iterator_tag, view_own> filtered;
  
  typedef polymorphic_view<filtered, const_tag, view_own> dereferenced;

protected:
  //
  // Here comes the view itself. Its main purpose compared to "dereferenced"
  // is the convenient constructor.
  //
  class view: public dereferenced {
  public:   
    typedef ctor_arg<container,const_tag,base>::type ctor_arg_type;

    explicit view() {}
    explicit view(ctor_arg_type& cont)
      : dereferenced(filtered(downcasted(cont,
					 downcast_fn()),
			      is_nonzero_fn())) {}
    
  };
};

template <class container,
          class derivedType,
          class const_tag = const_view_tag,
          class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
          template <class C, class const_tag> class base = view_ref>
class downcast_view
  : public downcast_namespace<container,derivedType,const_tag,iterator_tag,base>::view {
  typedef downcast_namespace<container,derivedType,const_tag,iterator_tag,base>::view inherited;
public:
  typedef ctor_arg<container,const_tag,base>::type ctor_arg_type;

  // containers have to be default constructible
  explicit downcast_view() {}
  explicit downcast_view(ctor_arg_type& cont)
    : inherited(cont) {}
};

END_VIEW_NAMESPACE
#endif // _DOWNCAST_VIEW_H
