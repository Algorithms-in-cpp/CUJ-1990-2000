/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */
#if !defined(_INTERSECTION_VIEW_H)
#define _INTERSECTION_VIEW_H	1

#if !defined(_FILTER_VIEW_H)
#include "filter_view.h"
#endif

#if !defined(_STL_TRAITS_H)
#include "stl_traits.h"
#endif

#if !defined(_FUNCTORS_H)
#include "functors.h"
#endif

#if !defined(_TWO_CONTAINERS_BASE_H)
#include "two_containers_base.h"
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif

#if !defined(_SYS_LIBRARY_ALGORITHM_)
#include <algorithm>	// for find
#define _SYS_LIBRARY_ALGORITHM_
#endif

BEGIN_VIEW_NAMESPACE

template <class container_a, class container_b,
          class const_tag,
          class FindType_a,  class FindType_b
		  >
struct intersection_traits {
  typedef view_traits<container_a,const_tag>::container_type domain_type_a;
  typedef view_traits<container_b,const_tag>::container_type domain_type_b;
  typedef domain_type_a element_container;
  typedef domain_type_b search_container;
  typedef FindType_b FindType;
  typedef typename std::iterator_traits<typename container_a::iterator>::iterator_category
	  iterator_category;

  static element_container& getElementContainer(domain_type_a& ca, domain_type_b& cb) { return ca; }
  static search_container&  getSearchContainer (domain_type_a& ca, domain_type_b& cb) { return cb; }
};
template <class container_a, class container_b,
          class const_tag
		  >
struct intersection_traits<container_a,container_b,const_tag,
                           InternalFindElement,NoInternalFindElement> {
  typedef view_traits<container_a,const_tag>::container_type domain_type_a;
  typedef view_traits<container_b,const_tag>::container_type domain_type_b;
  typedef domain_type_b element_container;
  typedef domain_type_a search_container;
  typedef InternalFindElement FindType;
  typedef typename std::iterator_traits<typename container_b::iterator>::iterator_category
	  iterator_category;
  
  static element_container& getElementContainer(domain_type_a& ca, domain_type_b& cb) { return cb; }
  static search_container&  getSearchContainer (domain_type_a& ca, domain_type_b& cb) { return ca; } 
};

// typedefs to make it easier to define the intersection_view.
template <class container_a,
          class container_b, 
          class const_tag,
		  class iterator_tag,
          template <class C, class tag> class proxy_template_a,
		  template <class C, class tag> class proxy_template_b,
          class FindType_a,
          class FindType_b>
// Not really a namespace but that's all I'm using it for.
class intersection_view_namespace
{
private:
  typedef two_containers_base<container_a,container_b,const_tag,
								proxy_template_a,proxy_template_b> base_t;
  // Integrate the const_tag into the container types.
  typedef typename view_traits<container_a,const_tag>::container_type domain_a;
  typedef typename view_traits<container_b,const_tag>::container_type domain_b;
  
  typedef intersection_traits<container_a,container_b,const_tag,
					FindType_a,FindType_b> traits;
  typedef match_element<traits::search_container,
						traits::element_container,
						const_tag,
						view_ref,
						traits::FindType> predicate_fn;
  // Define a filter_view of container_a which includes any members
  // found in b.
  typedef filter_view<traits::element_container,predicate_fn,const_tag,
						iterator_tag,view_ref> base_view;
  
protected:
  // There is this one more layer so we don't have to export out
  // all of the typedefs we set up in intersection_view_namespace.
  class view : private base_t, public base_view
  {
  public:
	explicit view() {}
    view(domain_a &cont_a, domain_b &cont_b)
      :  intersection_view_namespace::base_t(cont_a,cont_b),
		  base_view(traits::getElementContainer(a(),b()),
					predicate_fn(traits::getSearchContainer(a(),b() )))
    {}
  };
  
};
template <class container_a,
          class container_b, 
          class const_tag,
		  class iterator_tag,
          class FindType_a,
          class FindType_b>
// Not really a namespace but that's all I'm using it for.
class intersection_view_namespace<container_a,container_b,const_tag,iterator_tag,view_ref,view_ref,
								FindType_a,FindType_b>
{
private:
  // Integrate the const_tag into the container types.
  typedef typename view_traits<container_a,const_tag>::container_type domain_a;
  typedef typename view_traits<container_b,const_tag>::container_type domain_b;
  
  typedef intersection_traits<container_a,container_b,const_tag,
					FindType_a,FindType_b> traits;
  typedef match_element<traits::search_container,
						traits::element_container,
						const_tag,
						view_ref,
						traits::FindType> predicate_fn;
  // Define a filter_view of container_a which includes any members
  // found in b.
  typedef filter_view<traits::element_container,predicate_fn,const_tag,
						iterator_tag,view_ref> base_view;
  
protected:
  // There is this one more layer so we don't have to export out
  // all of the typedefs we set up in intersection_view_namespace.
  class view : public base_view
  {
  public:
	explicit view() {}
    view(domain_a &cont_a, domain_b &cont_b)
      :  base_view(traits::getElementContainer(cont_a,cont_b),
					predicate_fn(traits::getSearchContainer(cont_a,cont_b )))
    {}
  };
  
};


//
// intersection_view
//
// All the elements that are in both container_a and container_b 
template <
  class container_a,
  class container_b, 
  class const_tag = const_view_tag,
  template <class C, class tag> class proxy_template_a = view_ref,
  template <class C, class tag> class proxy_template_b = view_ref,
  class FindType_a = ContainerTrait<container_a>::FindType,
  class FindType_b = ContainerTrait<container_b>::FindType,
  class iterator_tag = typename intersection_traits<container_a,container_b,const_tag,
                                                    FindType_a,FindType_b>::iterator_category >
class intersection_view
	: public intersection_view_namespace<container_a,container_b, const_tag,
                 iterator_tag,proxy_template_a, proxy_template_b, FindType_a, FindType_b>::view
{
public:  
  typedef intersection_view_namespace<container_a,container_b, const_tag,
                 iterator_tag,proxy_template_a, proxy_template_b, 
				 FindType_a, FindType_b>::view inherited;
  typedef ctor_arg<container_a,const_tag,proxy_template_a>::type ctor_arg_type_a;
  typedef ctor_arg<container_b,const_tag,proxy_template_b>::type ctor_arg_type_b;
  
  explicit intersection_view() {}
  intersection_view(ctor_arg_type_a &a_cont, ctor_arg_type_b &b_cont)
    :	inherited(a_cont,b_cont) 
	{}
};

END_VIEW_NAMESPACE
#endif // _INTERSECTION_VIEW_H
