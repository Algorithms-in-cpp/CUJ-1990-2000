/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#ifndef _REVERSE_VIEW_H
#define _REVERSE_VIEW_H	1

#if !defined(_RANGE_H)
#include "range.h"
#endif

#if !defined(_SYS_LIBRARY_CASSERT_)
#include <cassert>
#define _SYS_LIBRARY_CASSERT_
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp>
	void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool equal(_InputIter1, _InputIter1,
                  _InputIter2);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE
//
// A reverse view.
//

template <class container,
          class const_tag = const_view_tag,
          template <class container, class const_tag> class proxy_template = view_ref>
class reverse_view {
public:
  typedef one_container_base<container,const_tag,proxy_template>  base_t;
  typedef typename base_t::domain_type	domain_type;
  typedef typename reversible_view_traits<container,const_tag>::iterator               reverse_iterator;
  typedef typename reversible_view_traits<container,const_tag>::const_iterator         const_reverse_iterator;
  typedef typename reversible_view_traits<container,const_tag>::reverse_iterator       iterator;
  typedef typename reversible_view_traits<container,const_tag>::const_reverse_iterator const_iterator;
  typedef std::iterator_traits<typename base_t::domain_iterator>::value_type value_type;
  typedef std::iterator_traits<typename base_t::domain_iterator>::reference  reference;
  typedef const reference									const_reference;
  typedef std::iterator_traits<typename base_t::domain_iterator>::pointer    pointer;
  typedef std::iterator_traits<typename base_t::domain_iterator>::difference_type difference_type;
  typedef typename domain_type::size_type size_type;
  typedef base_t::ctor_arg_type ctor_arg_type;
  
  explicit reverse_view() {}

  explicit reverse_view(ctor_arg_type& a)
    : base(a) {}

  iterator begin() { return base.cont().rbegin(); }
  iterator end()   { return base.cont().rend(); }
  const_iterator begin() const { return base.cont().rbegin(); }
  const_iterator end()   const { return base.cont().rend(); }
  reverse_iterator rbegin() { return base.cont().begin(); }
  reverse_iterator rend()   { return base.cont().end(); }
  const_reverse_iterator rbegin() const { return base.cont().begin(); }
  const_reverse_iterator rend()   const { return base.cont().end(); }

  
  size_type size() const { return base.cont().size(); }
  size_type max_size() const { return base.cont().max_size(); }
  bool empty() const { return base.cont().empty(); }

  const_reference operator[](size_type n) const { 
    return base.cont().operator[](base.cont().size() - (++n)); }
   
  reference operator[](size_type n) {
    return base.cont().operator[](base.cont().size() - (++n)); }
 
  reference at(size_type n) { 
    return base.cont().at(base.cont().size() - (++n)); }

  const_reference at(size_type n) const { 
    return base.cont().at(base.cont().size() - (++n)); }

  // front() and back() only work with sequences.
  reference front() { return base.cont().back(); }
  reference back() { return base.cont().front(); }
  const_reference front() const { return base.cont().back(); }
  const_reference back() const { return base.cont().front(); }

  // pop_front and pop_back only work with sequences
  void pop_front() { base.cont().pop_back(); }
  void pop_back() { base.cont().pop_front(); }

  void swap(reverse_view& b) {
	std::swap(base,b.base);
  }
protected:
  base_t base;
};


//
// Global comparator operations.
//
template <class container_1, class container_2,
          class const_tag_1, class const_tag_2,
          template <class container, class const_tag> class proxy_template_1,
          template <class container, class const_tag> class proxy_template_2>
bool operator==(reverse_view<container_1, const_tag_1,proxy_template_1> const &rhs,
		reverse_view<container_2, const_tag_2,proxy_template_2> const &lhs) {
	return lhs.size() == rhs.size() && std::equal(lhs.begin(), lhs.end(), rhs.begin());
}

template <class container_1, class container_2,
          class const_tag_1, class const_tag_2,
          template <class container, class const_tag> class proxy_template_1,
          template <class container, class const_tag> class proxy_template_2>
bool operator<(reverse_view<container_1, const_tag_1,proxy_template_1> const &rhs,
	       reverse_view<container_2, const_tag_2,proxy_template_2> const &lhs) {
  return std::lexicographical_compare(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}

END_VIEW_NAMESPACE

//
// The swap function
//
namespace std {
template <class container,
          class const_tag,
          template <class container, class const_tag> class proxy_template>
void swap(VIEW_NAMESPACE::reverse_view<container,const_tag,proxy_template>& a,
	  VIEW_NAMESPACE::reverse_view<container,const_tag,proxy_template>& b) {
  a.swap(b);
}
};

#endif	// _REVERSE_VIEW_H
