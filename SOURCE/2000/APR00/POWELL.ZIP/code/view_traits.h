/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted 
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#if !defined(_VIEW_TRAITS_H)
#define _VIEW_TRAITS_H

#if !defined(_VIEW_CONFIG_H)
#include "view_config.h"
#endif

// This is the "topmost" views header. Thus include view_relops.h here.
#if !defined(__SGI_STL_INTERNAL_RELOPS)
#include "view_relops.h"
#endif
#if !defined(_VIEW_RELOPS_H)
#error include view_relops.h before stl_relops.h
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

BEGIN_VIEW_NAMESPACE

//
// Dereferencing: Mapping from reference type to base type: T& -> T
//
template <class T> struct dereference_traits           { typedef T type; };
template <class T> struct dereference_traits<T&>       { typedef T type; };
//template <class T> struct dereference_traits<T& const> { typedef T const type; };

//
// Compute the reference type. Remember that references of pointer types
// are completely sensible.
//
template <class T> struct reference_traits     { typedef T& type; typedef T const& const_type; };
template <class T> struct reference_traits<T&> { typedef T& type; typedef T const& const_type; };

//
// Compute the pointer type. Remember that pointers to pointers are
// completely sensible.
//
template <class T> struct pointer_traits     { typedef T* type; typedef T const* const_type; };
template <class T> struct pointer_traits<T&> { typedef T* type; typedef T const* const_type; };

//
// Compute the const type. This is nontrivial for reference types.
//
template <class T> struct const_traits     { typedef T const type; };
template <class T> struct const_traits<T&> { typedef T const& type; };

//
// Compute the nonconst type.
//
template <class T> struct deconst_traits           { typedef T type; };
template <class T> struct deconst_traits<T const>  { typedef T type; };
template <class T> struct deconst_traits<T const&> { typedef T& type; };

//
// Combine traits computing the common denominator of two types.
// This works via a mapping to integers, taking the minimum and
// mapping back to corresponding types.
//

template<int a, int b> struct min_traits { enum { x = a<b? a: b }; };

template <class A, class B,
          template<class T> class map,
          template<class T, int x> class inv>
struct combine_traits {
  typedef typename inv<A,min_traits<map<A>::x,map<B>::x>::x>::type type;
};

// Combine traits for const/nonconst. Const ist the common denominator.
template<class T> struct const_mapping          { enum { x = 1 }; };
template<class T> struct const_mapping<const T> { enum { x = 0 }; };

template<class T, int x> struct mapping_const;
template<class T> struct mapping_const<T,0>   { typedef const T type; };
template<class T> struct mapping_const<T,1>   { typedef T type; };

template <class A, class B>
struct combine_const: public combine_traits<A,B,const_mapping,mapping_const>{};

// Combine traits for value/reference. Value is the common denominator.
template<class T> struct ref_mapping     { enum { x = 0 }; };
template<class T> struct ref_mapping<T&> { enum { x = 1 }; };

template<class T, int x> struct mapping_ref;
template<class T> struct mapping_ref<T,0>  { typedef T type; };
template<class T> struct mapping_ref<T&,0> { typedef T type; };
template<class T> struct mapping_ref<T,1>  { typedef T& type; };
template<class T> struct mapping_ref<T&,1> { typedef T& type; };

template <class A, class B>
struct combine_ref: public combine_traits<A,B,ref_mapping,mapping_ref>{};

// Combine traits for arbitrary value/reference const/nonconst combinations.
template <class A, class B>
struct combine_const_ref {
  typedef combine_ref<A,B>::type a;
  typedef combine_ref<B,A>::type b;
  typedef combine_const<a,b>::type type;
};

// Combine traits for iterator tags.
template <class T> struct iterator_tag_mapping                          { enum { x = 0 }; };
template<> struct iterator_tag_mapping<std::input_iterator_tag>         { enum { x = 1 }; };
template<> struct iterator_tag_mapping<std::forward_iterator_tag>       { enum { x = 2 }; };
template<> struct iterator_tag_mapping<std::bidirectional_iterator_tag> { enum { x = 3 }; };
template<> struct iterator_tag_mapping<std::random_access_iterator_tag> { enum { x = 4 }; };
template<class T, int x> struct mapping_iterator_tag { typedef void type; };
template<class T> struct mapping_iterator_tag<T,1>   { typedef std::input_iterator_tag type; };
template<class T> struct mapping_iterator_tag<T,2>   { typedef std::forward_iterator_tag type; };
template<class T> struct mapping_iterator_tag<T,3>   { typedef std::bidirectional_iterator_tag type; };
template<class T> struct mapping_iterator_tag<T,4>   { typedef std::random_access_iterator_tag type; };

template <class cat_a, class cat_b>
struct combine_iterator_categories
  : public combine_traits<cat_a,cat_b,iterator_tag_mapping,mapping_iterator_tag> {};

template<class A, class B>
struct combine_iterator_tags
  : public combine_traits<std::iterator_traits<A>::iterator_category,
                          std::iterator_traits<B>::iterator_category,
                          iterator_tag_mapping,mapping_iterator_tag> {};

template<class A, class B, class C>
struct combine_three_iterator_tags
{
  typedef combine_traits<std::iterator_traits<A>::iterator_category,
                         std::iterator_traits<B>::iterator_category,
                         iterator_tag_mapping,mapping_iterator_tag>::type min_first_two_types;
  
  typedef combine_traits<min_first_two_types,
	                 std::iterator_traits<C>::iterator_category,
                         iterator_tag_mapping,mapping_iterator_tag>::type type;

};

END_VIEW_NAMESPACE


#endif  // _VIEW_TRAITS_H