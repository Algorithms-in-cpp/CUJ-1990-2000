/* This file is part of the Views Template Library, written by
 * Gary Powell & Martin Weiser
 *
 * Copyright (c) 1999  Gary Powell
 * Copyright (c) 1999  Konrad Zuse Zentrum fuer Informationstechnik Berlin
 *
 * This material is provided "as is", with absolutely no warranty expressed
 * or implied. Any use is at your own risk.
 *
 * Permission to use or copy this software for any purpose is hereby granted
 * without fee, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#if !defined(_CONCATENATION_VIEW_H)
#define _CONCATENATION_VIEW_H 1

#if !defined(_VIEW_BASE_H)
#include "view_base.h"
#endif

#if !defined(_RANGE_H)
#include "range.h"
#endif

#if !defined(_SYS_LIBRARY_ITERATOR_)
#include <iterator>
#define _SYS_LIBRARY_ITERATOR_
#endif

#if !defined(_SYS_LIBRARY_FUNCTIONAL_)
#include <functional>
#define _SYS_LIBRARY_FUNCTIONAL_
#endif


                       
// forward declaration so we don't have to include <algorithm>
namespace std {
template <class _Tp> void swap(_Tp&, _Tp&);

template <class _InputIter1, class _InputIter2>
bool lexicographical_compare(_InputIter1, _InputIter1,
                             _InputIter2, _InputIter2);
};

BEGIN_VIEW_NAMESPACE

// Forward declare check_equal so that you don't have to include functors.h
template <class iter_t_1, class iter_t_2>
inline bool check_equal(iter_t_1, iter_t_1,
                  iter_t_2, iter_t_2);


//
// An iterator for stepping through a range of ranges.
//
// This is no more than a bidirectional iterator, although we could provide a
// more efficient variant of advance() than by incrementing.
//

// Note that the range_t already contains the minimum iterator tag from itself and the iter_t. Only the
// concatenation_iterator bidirectional limit and the element iter category have to be taken into account
// additionally to range_t's category.
template <class elem_iter_t, class range_t>
struct concatenation_iterator_traits {
  typedef combine_iterator_categories<bidirectional_iterator_tag,typename range_t::iterator_category>::type tmp;
  typedef combine_iterator_categories<iterator_traits<elem_iter_t>::iterator_category,tmp>::type iterator_category;
};

template <class iter_t, class element_iter_t, class range_t>
class concatenation_iterator
  : public std::iterator<concatenation_iterator_traits<element_iter_t,range_t>::iterator_category,
                         std::iterator_traits<element_iter_t>::value_type,
                         std::iterator_traits<element_iter_t>::difference_type,
                         std::iterator_traits<element_iter_t>::pointer,
                         std::iterator_traits<element_iter_t>::reference>              
{
public:
  typedef std::iterator_traits<element_iter_t>::value_type value_type;
  typedef std::iterator_traits<element_iter_t>::reference  reference;
  typedef std::iterator_traits<element_iter_t>::pointer    pointer;
  
  explicit concatenation_iterator() {}

  concatenation_iterator(iter_t const& iter_, range_t const& range_)
    : range(range_), iter(iter_) { if (iter!=range.end()) element_iter = iter->begin(); advance(); }

  concatenation_iterator(iter_t const& iter_, range_t const& range_, element_iter_t const& element_iter_)
    : range(range_), iter(iter_), element_iter(element_iter_) {}

  // Element access
  reference       operator*()       { return *element_iter; }
  reference const operator*() const { return *element_iter; }
  pointer       operator->()       { return element_iter.operator->(); }
  pointer const operator->() const { return element_iter.operator->(); }

  // Forward stepping.
  concatenation_iterator& operator++() {
    ++element_iter;
    advance();
    return *this;
  }
  concatenation_iterator  operator++(int) { concatenation_iterator tmp(*this); ++(*this); return tmp; }

  // Backward stepping. Requires a bidirectional range, bidirectional iter_t and element_iter_t.
  concatenation_iterator& operator--() {
    if (iter == range.end() ) {
      --iter;
      element_iter = iter->end();
    }
    while (element_iter==iter->begin()) {
      --iter;
      element_iter = iter->end();
    }
    --element_iter;
    return *this;
  }
  concatenation_iterator  operator--(int) { concatenation_iterator tmp(*this); --(*this); return tmp; }

  // We are not really a random_access_iterator but this may be slightly faster.
  concatenation_iterator& operator+=(difference_type n) {
	  if (n < 0) return (*this) -= -n;
	  advance(n);
	  return *this;
  }

  concatenation_iterator& operator-=(difference_type n) {
	  if (n < 0) return (*this) += -n;
	  reverse(n);
	  return *this;
  }

  concatenation_iterator operator+(difference_type n) const {
    concatenation_iterator tmp(*this);
    return tmp += n;
  }
  concatenation_iterator operator-(difference_type n) const {
    concatenation_iterator tmp(*this);
    return tmp -= n;
  }

  // Comparison.
  template <class iter2, class elem2, class range2>
  bool operator==(concatenation_iterator<iter2,elem2,range2> const& rhs) const {
    return iter==rhs.iter && (range.end()==iter || element_iter==rhs.element_iter); }

  template <class iter2, class elem2, class range2>
  bool operator< (concatenation_iterator<iter2,elem2,range2> const& rhs) const {
    return iter<rhs.iter || (iter==rhs.iter && (range.end()!=iter && element_iter < rhs.element_iter)); }

  // Conversion from iterator to const_iterator. This requires a conversion from
  // iter_t to const_iter_t, and range_t to const_range_t.
  template <class const_iter_t, class const_element_iter_t, class const_range_t>
  operator concatenation_iterator<const_iter_t,const_element_iter_t,const_range_t>() {
    return concatenation_iterator<const_iter_t,const_element_iter_t,const_range_t>(iter,range,element_iter); }

protected:
  range_t        range;
  iter_t         iter;
  element_iter_t element_iter;

private:
  // Advance to next valid position.
  void advance() {
    bool iterValid = iter != range.end();
    while (iterValid && element_iter==iter->end()) {
      ++iter;
      iterValid = iter != range.end();
      if(iterValid) element_iter = iter->begin();
    }
  }

  void advance(difference_type n) {
      bool iterValid = iter != range.end();
	  do {
	    int m = std::distance(element_iter, iter->end() );
	    if (m > n) break;
	    n -= m;
	    ++iter;
	    element_iter = iter->begin();
        iterValid = iter != range.end();
	  } while(iterValid);
	  if (iterValid) std::advance(element_iter, n);
  }

  void reverse(difference_type n) {
      bool iterValid = iter != range.end();
 	  do {
	    int m = std::distance(iter->begin(),element_iter);
	    if (m > n) break;
	    n -= m;
	    --iter;
	    element_iter = iter->end();
        iterValid = iter != range.end();
	  } while (iterValid);
	  if (iterValid) std::advance(element_iter, -n);
  }

  template <class iter2, class elem2, class range2>
  friend class concatenation_iterator;
};

//
// A concatenation view.
//
// This is a view that presents a range of ranges concatenated together into a single range.
//
template <class container,
          class const_tag = const_view_tag,
          class iterator_tag = typename std::iterator_traits<typename container::iterator>::iterator_category,
          template <class container, class const_tag> class proxy_template = view_ref>
class concatenation_view {
public:
  typedef one_container_base<container,const_tag,proxy_template> base_t;
  typedef typename container::size_type        size_type;
  typedef typename container::difference_type difference_type;
  
  
  typedef ctor_arg<container,const_tag,proxy_template>::type ctor_arg_type;
  typedef typename view_traits<container,const_tag>::container_type domain_type;
  typedef view_traits<container,const_tag>::iterator       domain_iterator;
  typedef typename view_traits<container,const_tag>::const_iterator const_domain_iterator;
  typedef view_traits<std::iterator_traits<domain_iterator>::value_type,
                      const_tag>::iterator             element_iterator;
  typedef view_traits<std::iterator_traits<const_domain_iterator>::value_type,
                      const_tag>::const_iterator       const_element_iterator;

  typedef internal_range_traits<iterator_tag, container, const_tag>::type      iter_base;
  typedef internal_range_traits<iterator_tag, container, const_tag>::const_type const_iter_base;

  typedef concatenation_iterator<domain_iterator,      element_iterator,      iter_base>       iterator;
  typedef concatenation_iterator<const_domain_iterator,const_element_iterator,const_iter_base> const_iterator;

  typedef std::reverse_iterator<iterator>       reverse_iterator;
  typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

  explicit concatenation_view() {}
  explicit concatenation_view(ctor_arg_type& domain): base(domain) {}

  iterator       begin()       { return iterator(base.cont().begin(),iter_base(base.cont())); }
  const_iterator begin() const { return const_iterator(base.cont().begin(),const_iter_base(base.cont())); }
  iterator       end()       { return iterator(base.cont().end(),iter_base(base.cont())); }
  const_iterator end() const { return const_iterator(base.cont().end(),const_iter_base(base.cont())); }

  reverse_iterator       rbegin()       { return       reverse_iterator(end()); }
  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  reverse_iterator       rend()       { return       reverse_iterator(begin()); }
  const_reverse_iterator rend() const { return const_reverse_iterator(begin()); }

  size_type     size() const { return std::distance(begin(),end()); } // this can be optimized.
  size_type max_size() const { return base.cont().max_size() * base.cont().begin()->max_size(); }
  bool         empty() const { return base.cont().empty() || size()==0; }

  void swap(concatenation_view& b) { std::swap(base,b.base); }
  
protected:
  base_t base;
};


//
// The comparison operators.
//

template <class container_1,class container_2,
          class const_tag_1,class const_tag_2,
          class iterator_tag_1, class iterator_tag_2,
          template <class container, class const_tag> class proxy_template_1,
          template <class container, class const_tag> class proxy_template_2>
bool operator==(concatenation_view<container_1,const_tag_1,iterator_tag_1,proxy_template_1> const& rhs,
                concatenation_view<container_2,const_tag_2,iterator_tag_2,proxy_template_2> const& lhs) {
  return check_equal(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}


template <class container_1,class container_2,
          class const_tag_1,class const_tag_2,
          class iterator_tag_1, class iterator_tag_2,
          template <class container, class const_tag> class proxy_template_1,
          template <class container, class const_tag> class proxy_template_2>
bool operator<(concatenation_view<container_1,const_tag_1,iterator_tag_1,proxy_template_1> const& rhs,
                concatenation_view<container_2,const_tag_2,iterator_tag_2,proxy_template_2> const& lhs) {
	return std::lexicographical_compare(rhs.begin(), rhs.end(), lhs.begin(), lhs.end());
}

END_VIEW_NAMESPACE

namespace std {
//
// The swap function.
//

template <class container,class const_tag,
          class iterator_tag,
          template <class container, class const_tag> class proxy_template>
		  void swap(VIEW_NAMESPACE::concatenation_view<container,const_tag,iterator_tag,proxy_template>& a,
          VIEW_NAMESPACE::concatenation_view<container,const_tag,iterator_tag,proxy_template>& b) {
  a.swap(b);
}
};

#endif 
// $Id: concatenation_view.h,v 1.6 1999/10/13 12:36:08 bzfweise Exp $
