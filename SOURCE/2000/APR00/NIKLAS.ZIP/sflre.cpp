/* sflre.cpp */
/* Simple File List Regular Expresion */
/* task: maintain '*' and '?' in file masks */
/* see also DDJ 4'1999 */
/* author: Michal Niklas mniklas@computer.org */

#include <ctype.h>

#include "sflre.h"

int match(const char *reg, const char *txt);
/* other name for matchhere() */

static int matchhere(const char *reg, const char *txt);
/* search for re at beginning of text */

static int matchstar(const char *reg, const char *txt);
/* omit chars until txt[j] = reg[0] */


/* the same but with ignoring case */
int matchi(const char *reg, const char *txt);
static int matchihere(const char *reg, const char *txt);
static int matchistar(const char *reg, const char *txt);


int match(const char *reg, const char *txt)
  {
  return matchhere(reg, txt);
  } /* match */


static int matchhere(const char *reg, const char *txt)
  {
  if (reg[0] == '\0')
    return *txt == '\0';
  if (reg[0] == '*')
    return matchstar(reg + 1, txt);
  if (reg[0] == '\\' && (reg[1] == '*' || reg[1] == '?'))
    return *txt == reg[1];
  if (*txt != '\0' && (reg[0] == '?' || reg[0] == *txt))
    return matchhere(reg + 1, txt + 1);
  return 0;
  } /* matchhere */


static int matchstar(const char *reg, const char *txt)
  {
  do
    {
    if (matchhere(reg, txt))
      return 1;
    } while (*txt != '\0' && *txt++ != *reg);
  return 0;
  } /* matchstar */



int matchi(const char *reg, const char *txt)
  {
  return matchihere(reg, txt);
  } /* matich */


static int matchihere(const char *reg, const char *txt)
  {
  if (reg[0] == '\0')
    return *txt == '\0';
  if (reg[0] == '*')
    return matchistar(reg + 1, txt);
  if (reg[0] == '\\' && (reg[1] == '*' || reg[1] == '?'))
    return tolower(*txt) == tolower(reg[1]);
  if (*txt != '\0' && (reg[0] == '?' || tolower(reg[0]) == tolower(*txt)))
    return matchihere(reg + 1, txt + 1);
  return 0;
  } /* matchihere */


static int matchistar(const char *reg, const char *txt)
  {
  do
    {
    if (matchihere(reg, txt))
      return 1;
    } while (*txt != '\0' && tolower(*txt++) != tolower(*reg));
  return 0;
  } /* matchstar */

  
