/* sflre.h */
/* Simple File List Regular Expresion */
/* task: maintain '*' and '?' in file masks */
/* see also DDJ 4'1999 */
/* author: Michal Niklas mniklas@computer.org */

#ifndef SFLRE_INCLUDED
#define SFLRE_INCLUDED

int match(const char *reg, const char *txt);
/* other name for matchhere() */

/* the same but with ignoring case */
int matchi(const char *reg, const char *txt);

#endif
