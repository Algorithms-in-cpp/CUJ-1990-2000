/* addfname.cpp */
/* Michal Niklas */

static const char* usage =
  "Adds file name to specified files\n"
  "addfname [-a] [-s] [-i] [-r] [-f] [-pprintf_format] file_masks\n"
  "  -a - ask\n"
  "  -s - silent\n"
  "  -r - recursive\n"
  "  -i - ignore case\n"
  "  -f - use full file name (with dirs)\n"
  "  -nnr - add file name in nr line (-1 appends to file)\n"
  "  -pprintf_format - use specified printf format,\n"
  "                    placing %s where file name should be\n"
  "  file_masks - masks like \"*.cpp\" or \"*.h\"\n"
  "    (notice usage of \" to avoid shell interpretation\n"
  "    of command line args on unices)\n\n\n"
  " Example of use -- adding file name to all HTML files\n"
  " in HTML comment tag:\n"
  "   addfname -r -i \"-p<!-- %s  -->\" *.htm *.html\n\n";


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

#include <iostream>
#include <string>

#include "cdir.h"

class CNameFileList: public CFileList
  {
  private:
    bool m_ask;       // should we ask user before removing file
    bool m_silent;    // should we show file names
    bool m_use_full_path;
    int m_nameline;
    std::string m_printf_mask;
  public:
    bool Ask() const { return m_ask; };
    bool &Ask() { return m_ask; };
    bool Silent() const { return m_silent; };
    bool UseFullPath() const { return m_use_full_path; };
    int NameLine() const { return m_nameline; };
    const char *PrintfMask() const { return m_printf_mask.c_str(); };
    CNameFileList(char *masks[], int count): CFileList(masks, count)
      {
      m_ask = false;
      m_silent = false;
      m_use_full_path = false;
      m_printf_mask = "%s";
      m_nameline = 1;
      }

    virtual bool ParseArgs(int argc, char *argv[])
      {
      int i;
      for (i = 1; i < argc; ++i)
        {
        if (IsOptionOn(argv[i], 'a'))
          m_ask = true;
        if (IsOptionOn(argv[i], 's'))
          m_silent = true;
        if (IsOptionOn(argv[i], 'f'))
          m_use_full_path = true;
        if (strlen(argv[i]) > 2)
          {
          if (argv[i][0] == '-')
            {
            if (argv[i][1] == 'p')
              m_printf_mask = &argv[i][2];
            if (argv[i][1] == 'n')
              {
              m_nameline = atoi(&argv[i][2]);
              if (m_nameline < 1 && m_nameline != -1)
                m_nameline = 1;
              }
            }
          }
        }
      return CFileList::ParseArgs(argc, argv);
      } // ParseArgs

  }; // CNameFileList

const int COPY_BUFF_SIZE = 16 * 1024;
static char fcopy_buffer[COPY_BUFF_SIZE];

int fcopyline(FILE *fin, FILE *fout)
  {
  if (fgets(fcopy_buffer, COPY_BUFF_SIZE, fin) != NULL)
    fputs(fcopy_buffer, fout);
  } /* fcopyline */

int fcopy(FILE *fin, FILE *fout)
  {
  int br, bw;
  do
    {
    br = fread(fcopy_buffer, 1, COPY_BUFF_SIZE, fin);
    bw = fwrite(fcopy_buffer, 1, br, fout);
    if (bw != br)
      return 1;
    } while (br == COPY_BUFF_SIZE);
  return 0;
  } /* fcopy */


/* add file name to specified line */
static int AddNameTo(const char *full_name, bool use_full_path, const char *fprintf_format, int nameline)
  {
  char *file_name = const_cast <char *> (full_name);
  
  /* if we don't want to use path part of name
     we must separate file name,
	 WARNING: to simplify assuming that dir separator is one char;
	          if your system uses more characters use something like strrsrt */
  const char *sep = GetDirSeparator();
  if (sep != NULL)
    {
    file_name = strrchr(const_cast <char *> (full_name), sep[0]);
    if (!use_full_path && file_name != NULL)
      ++file_name; // must also eat last DIR_SEPARATOR
	}

  FILE *fin, *fout;

  /* we must create backup file */
  std::string BackName = full_name;
  BackName += ".bak";
  /* check if backup file exists */
  if ((fin = fopen(BackName.c_str(), "r")) != NULL)
    {
    fclose(fin);
    /* removing old backup file */
    if (remove(BackName.c_str()) == -1)
      {
      perror(BackName.c_str());
      return 1;
      }
    }
  if (rename(full_name, BackName.c_str()) == -1)
    {
    perror(BackName.c_str());
    return 1;
    }

  if ((fin = fopen(BackName.c_str(), "r")) == NULL)
    {
    perror(BackName.c_str());
    return 1;
    }
  if ((fout = fopen(full_name, "w")) == NULL)
    {
    perror(full_name);
    return 1;
    }

  if (nameline > 1)
    for (int i = 1; i < nameline; ++i)
      fcopyline(fin, fout);
  if (nameline > 0)
    {
    fprintf(fout, fprintf_format, file_name);
    fprintf(fout, "\n");
    }
  fcopy(fin, fout);
  if (nameline = -1)
    {
    fprintf(fout, "\n");
    fprintf(fout, fprintf_format, file_name);
    }
  fclose(fin);
  fclose(fout);
  return 0;
  } /* AddNameTo */


// callback function
static int AddNameToFileCallback(const char *name, void *data)
  {
  CNameFileList *NameFileListPtr = static_cast <CNameFileList *> (data);
  if (NameFileListPtr->Ask())
    {
    std::string tmp_str; // string to store user input
    cout << "add file name to: " << name << " ? (yes,no,all,cancel) ";
    cin >> tmp_str;
    switch (tolower(tmp_str[0]))
      {
      case 'a':
        NameFileListPtr->Ask() = false;
        break;
      case 'y':
        break;
      case 'c':
        throw 1;
      default:
        return 0;
      } // switch 
    }
  if (!NameFileListPtr->Silent())
    cout << "adding name to: " << name << endl;
  if (AddNameTo(name, NameFileListPtr->UseFullPath(),
                      NameFileListPtr->PrintfMask(),
                      NameFileListPtr->NameLine()
                      ) != 0)
    {
    perror(name);
    return 0;
    }
  return 1;
  } // AddNameToFileCallback


static void ShowUsage()
  {
  cerr << usage;
  exit(1);
  }



int main(int argc, char *argv[])
  {
  int i;
  for (i = 1; i < argc; ++i)  // calculate first mask index
    if (argv[i][0] != '-')
      break;
  if (argc == 0 || argc - i == 0)
    ShowUsage();
  CNameFileList NameFileList(&argv[i], argc - i);
  if (NameFileList.ParseArgs(argc, argv))
    {
    try
      {
//      cout << "Ignore case: " << NameFileList.IgnoreCase() << endl;
      NameFileList.ProcessFiles(".", AddNameToFileCallback, NULL, static_cast<void *> (&NameFileList));
      }
    catch (...)
      {
      cerr << "user abort" << endl;
      return 2;
      }
    }
  else
    ShowUsage();
  return 0;
  } // main

