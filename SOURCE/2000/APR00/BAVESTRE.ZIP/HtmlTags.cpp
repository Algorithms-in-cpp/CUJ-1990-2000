#include "stdafx.h"
#include "assert.h"
#include "Htmltags.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace std;

//=============================================================================
// HTML Classes by G.Bavestrelli                   Copyright G.Bavestrelli 2000
// Any feedback is welcome,you can contact me at giovanni.bavestrelli@pomini.it
//=============================================================================

#ifdef _MFC_VER

//-----------------------------------------------------------------------------
// HtmlTag Class using MFC's CString
//-----------------------------------------------------------------------------

// Find the closing tag given the opening one
BOOL HtmlTag::ClosingTag(const CString & OpenTag, CString & CloseTag)
{
  // String must not be empty
  ASSERT(!OpenTag.IsEmpty()); 
  if (OpenTag.IsEmpty()) return FALSE;   

  // Find opening <
  int lesst=OpenTag.Find('<');  
  ASSERT(lesst>=0);
  if (lesst<0) return FALSE;

  // Find closing >
  int great=OpenTag.Find('>',lesst); 
  ASSERT(great>lesst+1);
  if (great<=lesst+1) return FALSE;

  // Find space separating options, if any
  int space=OpenTag.Find(' ',lesst);  
  ASSERT(space<0 || space>lesst+1);  // Space must be after first char
  if (space>0 && space<=lesst+1) return FALSE;

  // Now extract closing tag
  if (space<0 || space>=great)
     CloseTag="</"+OpenTag.Mid(lesst+1,great-lesst); 
  else
     CloseTag="</"+OpenTag.Mid(lesst+1,space-lesst-1)+">"; 

  return TRUE; 
}

HtmlTag::HtmlTag(ostream & stream,const CString & OpenTag)
       :m_Stream(stream)
{
  stream<<(LPCSTR)OpenTag;  
  ClosingTag(OpenTag,m_CloseTag);
}

HtmlTag::~HtmlTag()
{
  m_Stream<<(LPCSTR)m_CloseTag<<"\r\n";
}

CString HtmlTag::Str(const CString & OpenTag,LPCSTR Body)
{ 
  CString CloseTag;
  ClosingTag(OpenTag,CloseTag);
  return OpenTag+Body+CloseTag+"\r\n"; // Ok if Body=NULL
}


#endif // _MFC_VER

//-----------------------------------------------------------------------------
// htmltag class using std::string
//-----------------------------------------------------------------------------

// Find the closing tag given the opening one
bool htmltag::closingtag(const string & OpenTag, string & CloseTag)
{
  // String must not be empty
  assert(!OpenTag.empty()); 
  if (OpenTag.empty()) return false;

  // Find opening <
  string::size_type lesst=OpenTag.find('<');  
  assert(lesst!=string::npos);
  if (lesst==string::npos) return false;

  // Find closing >
  string::size_type great=OpenTag.find('>',lesst); 
  assert(great!=string::npos && great>lesst+1);
  if (great==string::npos || great<=lesst+1) return false;

  // Find space separating options, if any
  string::size_type space=OpenTag.find(' ',lesst);  
  assert(space==string::npos || space>lesst+1);     // Space must be after first char
  if (space!=string::npos && space<=lesst+1) return false; 

  // Now extract closing tag
  if (space==string::npos || space>=great)
  {
     CloseTag="</";
     CloseTag.append(OpenTag,lesst+1,great-lesst); 
  }
  else
  {
     CloseTag="</";
     CloseTag.append(OpenTag,lesst+1,space-lesst-1);
     CloseTag.append(">"); 
  }
  return true; 
}

htmltag::htmltag(ostream & stream,const string & OpenTag)
        :m_Stream(stream)
{
  stream<<OpenTag.c_str();  
  closingtag(OpenTag,m_CloseTag);
}

htmltag::~htmltag()
{
  m_Stream<<m_CloseTag.c_str()<<"\r\n";
}

string htmltag::str(const string & OpenTag,const string & Body)
{ 
  string CloseTag,Result(OpenTag);
  closingtag(OpenTag,CloseTag);

  Result.append(Body);
  Result.append(CloseTag);
  Result.append("\r\n");

  return Result;
}


