#ifndef HTMLTAGS_H
#define HTMLTAGS_H

#include <iostream>
#include <strstream>
#include <sstream>

//=============================================================================
// HTML Classes by G.Bavestrelli                   Copyright G.Bavestrelli 2000
// Any feedback is welcome,you can contact me at giovanni.bavestrelli@pomini.it
//=============================================================================


#ifdef _MFC_VER

//-----------------------------------------------------------------------------
// Generic HtmlTag Class using MFC's CString
//-----------------------------------------------------------------------------

class HtmlTag
{
    std::ostream & m_Stream;
    CString m_CloseTag;

  public:

    HtmlTag(std::ostream & stream,const CString & OpenTag);
   ~HtmlTag();

    static CString Str(const CString & OpenTag, LPCSTR Body = NULL);

  private:

    static BOOL ClosingTag(const CString & OpenTag, CString & CloseTag);
};



//-----------------------------------------------------------------------------
// Utility stream functions using MFC's CString
//-----------------------------------------------------------------------------


// Put a string into an ostream
inline std::ostream & operator << (std::ostream & Stream, const CString & String) 
{
   return Stream<<(LPCSTR)String;
}

// Get a string from an ostrstream
inline CString GetString(std::ostrstream & stream)
{
  CString Str;
  int     Len=stream.pcount();
  strncpy(Str.GetBuffer(Len+1),stream.str(),Len);
  
  Str.ReleaseBuffer(Len);
  stream.freeze(FALSE);
  return Str;
}

#endif // _MFC_VER

//-----------------------------------------------------------------------------
// Generic HtmlTag Class using std::string
//-----------------------------------------------------------------------------

class htmltag
{
    std::ostream & m_Stream;
    std::string    m_CloseTag;

  public:

    htmltag(std::ostream & stream,const std::string & OpenTag);
   ~htmltag();

    static std::string str(const std::string & OpenTag, const std::string & Body="");

  private:

    static bool closingtag(const std::string & OpenTag, std::string & CloseTag);
};


//-----------------------------------------------------------------------------
// Utility stream functions using std::string
//-----------------------------------------------------------------------------


// Put a string into an ostream
inline std::ostream & operator << (std::ostream & Stream, const std::string & String) 
{
   return Stream<<String.c_str();
}

// Get a string from an ostrstream
inline std::string getstring(std::ostrstream & stream)
{
  std::string Str(stream.str(),stream.pcount());
  stream.freeze(0);
  return Str;
}

// Get a string from an ostrstream
inline std::string getstring(std::ostringstream & stream)
{
  return stream.str();
}

// Allow concatenating strings with operator +
inline std::string operator + (const std::string & s1, const std::string & s2)
{
  std::string str(s1);
  str.append(s2); 
  return str;
}


#endif