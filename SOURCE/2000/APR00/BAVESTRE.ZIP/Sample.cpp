#include <iostream>
#include "HtmlTags.h"

using namespace std;

int main(int argc, char* argv[])
{
     htmltag HTML(cout,"<HTML>\r\n");
     { 
       htmltag HEAD(cout,"<HEAD>\r\n");
       htmltag TITLE(cout,"<TITLE>Simple Title");
     }

     htmltag BODY(cout,"<BODY BGCOLOR=gray TEXT=yellow>\r\n");
     
     cout<<htmltag::str("<H1 ALIGN=center>","Simple H1 Heading");
     cout<<htmltag::str("<H2 ALIGN=left>Simple H2 Heading");

     cout<<"<BR>Hello World<HR>\r\n";

     {
       htmltag OL(cout,"<OL>\r\n");
       cout<<htmltag::str("<LI>","This is my first point"); 
       cout<<htmltag::str("<LI>This is my second point"); 
     }

     cout<<htmltag::str("<TABLE BORDER=1>\r\n",
             htmltag::str("<TR>\r\n",
               htmltag::str("<TH>","<IMG SRC=image.gif>")
              +htmltag::str("<TH><IMG SRC=other.gif>")));

    return 0;
}

