#include <stdio.h>

class M
    {
public:
    M()
        {
        printf("M throw\n");
        throw 0;
        }
    };

class X
    {
public:
    X()
        try : m()
            {
            }
        catch (...)
            {
            printf("X catch\n");
            }
private:
    M m;
    };

int main()
    {
    try
        {
        X x;
        }
    catch (...)
        {
        printf("main catch\n");
        }
    printf("main end\n");
    }


