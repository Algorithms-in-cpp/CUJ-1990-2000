// Sample client that creates an embedded sql object, and then 
// allows the user to select data out of the object using sql. 
// Note, the database is stored in shared memory and the access
// is controlled by the C++ object.
#include <afxwin.h>
#include <iostream.h>          
#include "EMBSQL.h"
void main(int argc, char *argv[])
{
     SCCollection *ptr;// holds the row data (a collection)
     void **row;       // a row out of ptr (a row an array)
     char buf[512];    // input buffer

     CESql* a = new CESql();      // get the embsql object
     if (a->ReturnError() != "") {// watch out for errors 
          cout << a->ReturnError() + "\n";
          exit(1);
     }
     a->PrintStack(false);        // set to t to see the stack

     while(true) {         // read from console and execute it
          cout << "embsql>";
          cout.flush();
          cin.getline(buf,512);
          if (buf[0] == 0) exit(0);
          if ((ptr = a->Sql(buf)) != NULL) { // execute the sql
               for (int i=0;a->GetColumnCount()>-1, 
				                i<ptr->GetSize();i++) {
                   // for each row, get it and print it 
                   row = (void **)ptr->GetAt(i);	
                   SCTable::PrintRow(a->GetColumnInfo(),
                         a->GetColumnCount(),row);  // use helper
               }
          }
          if (a->ReturnError() != "") {
               cout << a->ReturnError() + "\n";
               cout.flush();
          }
     }
}