enum columnTypes {
	CUNDEFINED,
	CSTRING,
	CFLOAT,
	CLONG,
	CINT,
	CUNSIGNED,
	CTIME
};

class CColumn : public CObject
{
public:
	DLL_EXPORT CColumn(CString name, int type, int width);	// create a column descriptor
	DLL_EXPORT ~CColumn();
	DLL_EXPORT CString Name();								// name of this column
	DLL_EXPORT int Type();									// type of this column
	DLL_EXPORT int Width();									// maximum width of this column
	DLL_EXPORT void *Value();								// return what this thing points to
	DLL_EXPORT void Value(const void *);					// set the value pointer

	DLL_EXPORT void Value(char *s);							// set a string value
	DLL_EXPORT void Value(int);								// set a value from the int
	DLL_EXPORT void Value(double);							// set a value from a float
	DLL_EXPORT void Value(unsigned);						// set a value from an unsigned
	DLL_EXPORT void SetValueByType(CString);				// set a value from string by type
	DLL_EXPORT void *operator new(size_t t);
	DLL_EXPORT void operator delete(void *ptr);

private:
	SCString *name;							// column name attribute
	int width;								// max width attribute
	int type;								// type of this attribute
	void *value;							// value of this attribute	
};