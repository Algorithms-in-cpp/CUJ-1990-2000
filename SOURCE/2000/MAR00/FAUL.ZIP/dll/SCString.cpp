#include "afxwin.h"
#include "EMBSQL.h"

//
// Allocate a string object in shared memory
void *SCString::operator new(size_t size)
{
	return shared_malloc(size);
}

//
// Deallocate a string object in shared memory
void SCString::operator delete(void *ptr)
{
	shared_free((char *)ptr);
}

//
// Construct the string object
SCString::SCString(CString nm)
{
	value = shared_malloc(nm.GetLength()+1);
	strcpy(value,(LPCSTR)nm);
}

//
// Destroy the string object
SCString::~SCString()
{
	shared_free(value);
}

//
// Return the value of the string object in shared memory as a CString
CString SCString::Value()
{
	return CString(value);
}
