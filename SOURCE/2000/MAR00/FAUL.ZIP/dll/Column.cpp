#include <afxwin.h>
#include "EMBSQL.h"

void *SCColumn::operator new(size_t size)
{
	return (void *)shared_malloc(size);
}

void SCColumn::operator delete(void *ptr)
{
	shared_free((char*)ptr);
}
//
// Create a column attribute in shared memory
SCColumn::SCColumn(CString n, int t, int w)
{
	name = new SCString(n);
	type = t;
	value = NULL;
	if (t == CSTRING) {
		width = w + 1;
	}
	else {
		switch (type) {
		case CTIME:
			width = 20;
			break;
		default:
			width = w;
		}
	}
}

//
// Destructor, release shared memory
SCColumn::~SCColumn() { 
	shared_free((char*)value);
	shared_free((char*)name);
}

//
// Return the name of this attribute
CString SCColumn::Name() { 
	return name->Value(); 
}

//
// Return the type of this attribute
int SCColumn::Type() { 
	return type; 
}

//
// Return the width of this attribute
int SCColumn::Width()    { 
	return width; 
}

//
// Return the void pointer to this attribute
void* SCColumn::Value()  { 
	return value; 
}

//
// Given a void pointer to a new value 'v', and based on the type of
// attribute this is, delete the old value pointer, make a new one
// and copy this new v into this new value
void SCColumn::Value(const void* v)
{ 
	switch(type) {
	case CTIME:	
	case CSTRING:
		Value((char *)v);
		break;
	case CINT:
	case CLONG:
		Value(*(int *)v);
		break;
	case CFLOAT:
		Value(*(double *)v);
		break;
	case CUNSIGNED:
		Value(*(unsigned *)v);
		break;
	}
}

//
// Assign a character pointer
void SCColumn::Value(char *s)
{
	char *c = (char*)shared_malloc(width);
//	if (value) shared_free((char*)value);

	strcpy(c,s);
	value = (void *)c;
}

//
// Assign an integer
void SCColumn::Value(int i)
{
	int *iv = NULL;
	iv = (int*)shared_malloc(sizeof(int));
	if (value) shared_free((char*)value);

	*iv = i;
	value = (void *)iv;
}

// Assign a double
void SCColumn::Value(double d)
{
	double *dv = (double*)shared_malloc(sizeof(double));
	if (value) shared_free((char*)value);
	*dv = d;
	value = (void *)dv;
}

//
// Assign an unsigned
void SCColumn::Value(unsigned u)
{
	unsigned *uv = (unsigned*)shared_malloc(sizeof(unsigned));
	if (value) shared_free((char *)value);
	*uv = u;
	value = (void *)uv;
}

//
// Given a string, convert to the attributes proper type and then
// make the assignment into 'v'.
void SCColumn::SetValueByType(CString s)
{
	CString news;
	char *stopstring;
	switch(type) {
	case CTIME:	
	case CSTRING:
		news =  s.Mid(1,s.GetLength()-2);	// strings are passed with their enclosing quotes
		Value((LPCSTR)news);
		break;
	case CINT:
	case CLONG:
		Value(atoi(s));						// make into int
		break;
	case CFLOAT:
		Value(atof(s));						// make into floating point
		break;
	case CUNSIGNED:							
		unsigned l;
		l = strtol(s, &stopstring, 10 );
		Value(l);							// make into unsigned
		break;
	}
}

