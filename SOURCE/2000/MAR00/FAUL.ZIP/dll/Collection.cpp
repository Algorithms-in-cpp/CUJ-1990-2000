//
// A collection class. Based on CObArray() and adding some stack operations
//

#include "afxwin.h"
#include "EMBSQL.h"
#define XSIZE 128

//
// Allocate object from the shared memory segment
void *SCCollection::operator new(size_t size)
{
	return shared_malloc(size);
}

//
// Deallocate the shared memory for this object
void SCCollection::operator delete(void *ptr)
{
	shared_free((char *)ptr);
}

//
// Constructor, sets up the object's shared memory pointers
SCCollection::SCCollection()
{
	where = 0;
	upper = XSIZE;
	array = (void **)shared_malloc( XSIZE * sizeof(sizeof(CObject*)));
}

//
// Destructor, release the shared memory pointers
SCCollection::~SCCollection()
{
	shared_free((char*)array);
}

//
// Push a string (merely adds) onto the tail of the collection
void SCCollection::Push(CString s)					// push a string object onto the stack
{
	Add((CObject*)new CString(s));
}

//
// Push a collection as a LISTY (merely adds) onto the tail of the collection
void SCCollection::Push(SCCollection *s)
{
	Push("EOLIST");
	CopyIntoStack(s);
	Push("LIST");
}

//
// Pop a string off (takes from the tail of the collection)
CString* SCCollection::Pop()						// pop a single object off the stack
{
	CString* ptr = NULL;
	int where = this->GetSize() - 1;
	if (where < 0) return NULL;
	ptr = (CString*)this->GetAt(where);
	RemoveAt(where);
	return ptr;
}

//
// Make a copy clone of the collection
SCCollection* SCCollection::Copy()
{
	SCCollection *nstk = NULL;
	CString* ptr = NULL;
	CString* nPtr = NULL;

	nstk = new SCCollection();
	for (int i=0;i<this->GetSize();i++) {
		ptr = (CString*)this->GetAt(i);
		nPtr = new CString(*ptr);
		nstk->Add((CObject*)nPtr);
	}
	return nstk;	
}

//
// Copy the collection specified into this collection as a
// series of push operations
void SCCollection::CopyIntoStack(SCCollection* s)
{
	CString *str = NULL;
	for (int i=0;i<s->GetSize();i++) {
		str = (CString*)s->GetAt(i);
		Push(*str);
	}
}

//
// Clear the collection and the pointers within the list
void SCCollection::Clear()
{
	CString *ptr = NULL;
	if (!this)
		return;
	while(this->GetSize() > 0) {
		ptr = (CString*)this->GetAt(0);
		delete ptr;
		this->RemoveAt(0);
	}
}

//
// Print the stack onto stdout
void SCCollection::Print()
{
	CString *s = NULL;
	for (int i=this->GetSize()-1;i>=0;i--) {
		s = (CString*)this->GetAt(i);
		printf("\t%s\n",(LPCSTR)s->GetBuffer(128));
	}
}

/////////////////////////////////////////////////////////

//
// Set the highwater pointer to 0, but don't free the memory
void SCCollection::RemoveAll()
{
	where = 0;
}

//
// Return the pointer to the array
CObject** SCCollection::Array()
{
	return (CObject**)array;
}

//
// Preinitialize the array
void SCCollection::Array(CObject** n)
{
	array = (void **)malloc( XSIZE * sizeof(CObject*));
	if (array == NULL) {
		MessageBox(NULL,"QuickView memory exhausted in CObArrayX::Array()","QuickView Error!",MB_OK);
		exit(1);
	}
	memcpy(array,n,sizeof(CObject*) * where);
}

//
// Return the currency pointer
int SCCollection::GetSize()
{
	return where;
}

//
// Return object at n from shared memory
CObject* SCCollection::GetAt(int n)
{
	if (n >= where || array == NULL)
		return NULL;
	return (CObject*)array[n];
}

//
// Move contents down a notch
void SCCollection::MoveArrayDown(int n)
{
	int i;
	for (i=where;i > n;i--) {
		array[i] = array[i-1];
	}
	where++;
}

//
// Add an object to the array
void SCCollection::Add(CObject *what)
{
	SetAtGrow(where,what);
}

//
// Add an object at n, and grow memory if required
void SCCollection::SetAtGrow(int n,CObject* o)
{
	if (where == upper) {
		upper += XSIZE;
		array = (void**)shared_realloc((char*)array, upper * sizeof(CObject*));
		if (array == NULL) {
			MessageBox(NULL,"QuickView memory exhausted in CObArrayX::SetAtGrow()","QuickView Error!",MB_OK);
			exit(1);
		}
	}
	array[n] = o;
	if (n >= where)
		where++;
}

//
// Remove memory at n
void SCCollection::RemoveAt(int n)
{
	if (n > where)
		return;
	memcpy(&array[n],&array[n+1],(where-n) * sizeof(char**));
	where--;
}