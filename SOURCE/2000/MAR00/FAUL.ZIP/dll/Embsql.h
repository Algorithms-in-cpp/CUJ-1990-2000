
#define DLL_EXPORT __declspec (dllexport)

////////////////////////////////////////////////////
// Memory stuff for MALLOC.CPP
//
//
//	 Assign to each area an index "n". This is currently proportional to
//	the log 2 of size of the area rounded down to the nearest integer.
//	Then all free areas of storage whose length have the same index n are
//	organized into a chain with other free areas of index n (the "bucket"
//	chain). A request for allocation of storage first searches the list of
//	free memory.  The search starts at the bucket chain of index equal to
//	that of the storage request, continuing to higher index bucket chains
//	if the first attempt fails.
//	If the search fails then new memory is allocated.  Only the amount of
//	new memory needed is allocated.  Any old free memory left after an
//	allocation is returned to the free list.
//
//	  All memory areas (free or busy) handled by malloc are also chained
//	sequentially by increasing address (the adjacency chain).  When memory
//	is freed it is merged with adjacent free areas, if any.  If a free area
//	of memory ends at the end of memory (i.e. at the break), and if the
//	variable "endfree" is non-zero, then the break is contracted, freeing
//	the memory back to the system.
//
//	Notes:
//		ov_length field includes sizeof(struct overhead)
//		adjacency chain includes all memory, allocated plus free.
//

// the following items may need to be configured for a particular machine 

// alignment requirement for machine (in bytes) 
#define NALIGN	4

// size of an integer large enough to hold a character pointer 
typedef	long	Size;

//
// CURBRK returns the value of the current system break, i.e., the system's
// idea of the highest legal address in the data area.  It is defined as
// a macro for the benefit of systems that have provided an easier way to
// obtain this number (such as in an external variable)
//

#ifndef CURBRK
#define CURBRK	sbrk()
extern char *sbrk();
#else  CURBRK
#	if	CURBRK == curbrk
extern Size curbrk;
#	endif
#endif CURBRK

//
// note that it is assumed that CURBRK remembers the last requested break to
// the nearest byte (or at least the nearest word) rather than the nearest page
// boundary.  If this is not true then the following BRK macro should be
// replaced with one that remembers the break to within word-size accuracy.
//

#ifndef BRK
int brk(char *p);
#define BRK(x)	brk(x)
#endif  BRK

// END of machine dependent portion 

#define	MAGIC_FREE	0x548a934c
#define	MAGIC_BUSY	0xc139569a

#define NBUCKETS	18

struct qelem {
	struct qelem *q_forw;
	struct qelem *q_back;
};

struct overhead {
	struct qelem	ov_adj;		/* adjacency chain pointers */ 
	struct qelem	ov_buk;		/* bucket chain pointers */
	long		ov_magic;
	Size		ov_length;
};

//
// The following macros depend on the order of the elements in struct overhead
//
#define TOADJ(p)	((struct qelem *)(p))
#define FROMADJ(p)	((struct overhead *)(p))
#define FROMBUK(p)	((struct overhead *)( (char *)p - sizeof(struct qelem)))
#define TOBUK(p)	((struct qelem *)( (char *)p + sizeof(struct qelem)))

#ifdef MALLOC
//
// return to the system memory freed adjacent to the break 
// default is Off
//
char endfree = 0;

// sizes of buckets currently proportional to log 2() 
Size mlsizes[] = {0, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768,
	65536, 131072, 262144, 524288, 1048576, 2097152, 4194304};

// head of adjacency chain 
struct qelem adjhead = { &adjhead, &adjhead };

// head of bucket chains 
struct qelem buckets[NBUCKETS] = {
	&buckets[0],  &buckets[0],	&buckets[1],  &buckets[1],
	&buckets[2],  &buckets[2],	&buckets[3],  &buckets[3],
	&buckets[4],  &buckets[4],	&buckets[5],  &buckets[5],
	&buckets[6],  &buckets[6],	&buckets[7],  &buckets[7],
	&buckets[8],  &buckets[8],	&buckets[9],  &buckets[9],
	&buckets[10], &buckets[10],	&buckets[11], &buckets[11],
	&buckets[12], &buckets[12],	&buckets[13], &buckets[13],
	&buckets[14], &buckets[14],	&buckets[15], &buckets[15],
	&buckets[16], &buckets[16],	&buckets[17], &buckets[17]
};

void (*mlabort)() = {0};

#else
extern char endfree;
extern struct qelem adjhead, buckets[NBUCKETS];
extern Size mlsizes[NBUCKETS];
extern void (*mlabort)();
#endif

Size mlindx(Size n);
void remque(struct qelem *item);
void insque(struct qelem *item, struct qelem *queu);
void shared_free(char *), mllcerr();
char *shared_malloc(int), *shared_realloc(char*,int);

BOOL CreateMappedFile(int);
BOOL CloseMappedFile(BOOL);

char *shared_malloc(int);
char *shared_realloc(char*,int);
void shared_free(char *);

///////////////////////////////
//
// Shared CString
//
class SCString : public CObject
{
public:
	void *operator new(size_t size);		// SHARED memory allocation
	void operator delete(void *ptr);		// SHARED memory deallocation
	SCString(CString nm);					// initializer
	~SCString();							// destructor
	CString Value();						// the CString value of me
private:
	char *value;							// shared memory with my contents
};

////////////////////////////////
//
// COLLECTION.CPP NEEDS

class SCCollection : public CObArray			// A SHARED memory CObArray + some stack stuff
{
public:
	void *operator new(size_t size);		// SHARED MEMORY allocation
	void operator delete(void *ptr);		// SHARED MEMORY allocation	
	SCCollection();							// allocator
	~SCCollection();							// deallocator

	void Push(CString s);					// push a string object onto the stack
	void Push(SCCollection*);				// push a collection onto stack as a LIST
	CString* Pop();							// pop a single object off the stack
	SCCollection* Copy();					// make a copy of this collection
	void CopyIntoStack(SCCollection* s);		// copy the specified collection onto this collection
	void Clear();							// clear the collection and its pointers
	DLL_EXPORT void Print();				// print a trace of this stack
	void RemoveAll();						// remove all records
	void Add(CObject*);						// add a new entry
	void SetAtGrow(int n,CObject* o);		// add, and grow if needed
	void RemoveAt(int n);					// remove an item
//
// Calling programs can use these too
//
	DLL_EXPORT int GetSize();				// return the number of entries
	DLL_EXPORT CObject* GetAt(int n);		// return entry at n

private:
	CObject** Array();						// return the array
	void MoveArrayDown(int n);				// copy the array down
	void Array(CObject** n);				// set the array to this pointer

	void **array;							// shared memory pointers to objects in collection
	int upper;								// upper index
	int where;								// currency pointer

};

//////////////////////////////////
// COLUMN.CPP NEEDS

enum columnTypes {
	CUNDEFINED,								// type is undefined
	CSTRING,								// type is a char string
	CFLOAT,									// type is a float
	CLONG,									// rest are yet to be used
	CINT,									// yet to be used
	CUNSIGNED,								// yet to be used
	CTIME									// yet to be used
};

class SCColumn : public CObject
{
public:
	DLL_EXPORT SCColumn(CString name, int type, int width);	// create a column descriptor
	DLL_EXPORT ~SCColumn();
	DLL_EXPORT CString Name();								// name of this column
	DLL_EXPORT int Type();									// type of this column
	DLL_EXPORT int Width();									// maximum width of this column
	DLL_EXPORT void *Value();								// return what this thing points to
	DLL_EXPORT void Value(const void *);					// set the value pointer

	DLL_EXPORT void Value(char *s);							// set a string value
	DLL_EXPORT void Value(int);								// set a value from the int
	DLL_EXPORT void Value(double);							// set a value from a float
	DLL_EXPORT void Value(unsigned);						// set a value from an unsigned
	DLL_EXPORT void SetValueByType(CString);				// set a value from string by type
	DLL_EXPORT void *operator new(size_t t);
	DLL_EXPORT void operator delete(void *ptr);

private:
	SCString *name;							// column name attribute
	int width;								// max width attribute
	int type;								// type of this attribute
	void *value;							// value of this attribute	
};

/////////////////////////////////////
// TABLE.CPP NEEDS

enum compareEnums {
	CLT,									// Less than							
	CLE,									// Less than equal to
	CEQ,									// Equal to
	CGT,									// Greater than equal to
	CGE										// Greater than equal to
};

#define MAX_COLUMNS 128						// maximum columns supported

class SCTable : public CObject 
{
public:
	void *operator new(size_t size);						// SHARED MEMORY allocator
	void operator delete(void *ptr);						// SHARED MEMORY deallocator
	SCTable(CString nm, SCColumn *cols[], int sz);			// define a table
	~SCTable();												// destructor
	CString SCTable::Name();									// return name of table
	int Columns();											// return # of columns
	SCColumn** GetColumnInfo();								// return the columns
	int Index(CString nm);									// given name of column, return its index
	int Type(int n);										// given a column index, return its type
	int Type(CString nm);									// given a column index return its type
	SCColumn* Column(int n);									// given an index, return the column
	SCColumn* Column(CString n);								// given a name, return the column
	bool AddRow(const void **newRow);						// add the array of voids to the table
	bool AddRow(SCColumn* cols[]);							// add the array of columns to the table
	bool AddRow();											// add a row using the column Value() ptrs
	int RecordInTable(SCColumn* col[], int ops[], int nColumns, int start); // return 1st row that meets the specified criteria
	int Compare(SCColumn *a, SCColumn *b, int op);			// compare column ptrs based on op
	void **GetRow(int i);									// given the index, return the array of void ptrs (the row)
	bool DeleteRow(int i);									// delete the array of pointers at row i
	void DeleteAllRows();									// delete all rows
	int NRows();											// return the number of rows

	bool PrintRow(int which);								// print a row number i of the table
	bool PrintRow(void **);									// print the provided array of void pointers
	DLL_EXPORT static bool PrintRow(SCColumn**,int,void**);	// print the provided row of void pointers, based on the types provided in the columns provided
	static double InterpretAsFloat(int i, void*);			// interpret void pointer as float, based on column position i's type
	static CString* InterpretAsString(int i, void*);		// interpret void pointer as string, based on column position i's type

private:
	SCString *name;											// name of table					
	SCColumn **columns;										// array of defining columns
	int nCols;												// numbner of defining columns
	SCCollection *rows;										// data rows
};

SCTable* FindTable(CString s);			// find a table in the collection of tables

///////////////////////////////////
//
// ExecuteStack.cpp needs


class CEStack : public CObject				// Stack execution object
{
public: 
	void *operator new(size_t size);		// SHARED MEMORY allocator
	void operator delete(void *ptr);		// SHARED MEMORY de-allocator

	CEStack();								// constructor
	void Load(SCCollection *);				// set the stack
	~CEStack();								// destructor
	void DeleteResult();					// delete the results of the sql
	SCCollection* Execute();					// executes the stack
	CString TableInQuestion();				// returns the table in question

private:
	CString* PopProduction();				// pop a production off the stack
	bool ExecuteSelect();					// do a select operation
	bool ExecuteUpdate();					// do an update operation
	bool ExecuteInsert();					// do an insert operation
	bool ExecuteDelete();					// do a delete operation
	bool ExecuteAssign();					// do a literal assignment
	bool ExecuteCreate();					// create a table
	bool ExecuteOperator(CString);			// execute an operator
	double Numberize(CString);				// turn object into a number, if you can
	bool IsOperator(CString);				// is this string an operator
	double Compare(CString a, CString b);	// compare, with wildcards
	CString* GetValue(CString);				// given a string object return the value of what it points to
	double CEStack::DoOperation(CString a, CString b, CString op); // does the indicate operation

private:
	CString tableName;						// table we created
	SCCollection* stack;						// internal execution stack
	CString errorString;					// error string
	void **rowInQuestion;					// pointer to the row being examined
	SCTable* tableInQuestion;				// pointer to the table being examined
	SCCollection* result;					// result collection
};
/////////////////////////////////
//
// PARSER.CPP NEEDS


class CESql : public CObject				// Embedded Shared Memory SQL Object
{
public:	  
	DLL_EXPORT CESql();										// create, using anonymous db shared memory, size = 20MB
	~CESql();												// destructor
	DLL_EXPORT bool DeleteTable(CString table);				// delete a table by name
	DLL_EXPORT bool DefineTable(CString name, SCColumn *cols[], int n); // define a table
	DLL_EXPORT SCColumn** GetColumnInfo(CString nm, int *nC);// get the column info array
	DLL_EXPORT bool AddRow(CString name, SCColumn *cols[]);	// add a row to a table
	DLL_EXPORT SCCollection* Sql(const CString stmt);		// issue an SQL statement
	DLL_EXPORT int Catalog();								// return # of tables in db
	DLL_EXPORT CString GetCatalog(int);						// return catalog at #
	DLL_EXPORT const CString ReturnError();					// return the error string
	DLL_EXPORT void SetError(CString s);					// set the error string
	DLL_EXPORT static SCTable* FindTable(CString nm);		// find a table by name
	DLL_EXPORT static bool IsNumber(const CString);			// is the item a number?
	DLL_EXPORT static bool IsIdentifier(const CString);		// is the item an identifier
	DLL_EXPORT static bool IsStringLiteral(CString);		// is the item a 'string literal'
	DLL_EXPORT SCColumn** GetColumnInfo();					// returns pointer to  columns array of the table from last query
	DLL_EXPORT int GetColumnCount();						// returns # of columns of the table
	DLL_EXPORT void PrintStack(BOOL);						// enables stack printing

private:
	void SetColumnInfo(CString table);						// sets the # of columns of the table in this transaction
	bool Select();											// select root of grammar
	bool Update();											// upodate root of grammar
	bool Insert();											// insert root of grammar
	bool Delete();											// delete root of grammar
	bool CreateTable();										// define a table
	bool GetListIds();										// List of IDs production
	bool GetListExps();										// List of expressions production
	bool GetListDecls();									// Get list of table declarations
	bool WhereClause();										// where root of grammar
	void Accept();											// accept (and advance) input scanner
	bool GetAssignment();									// get an assignment from the intput
	bool GetIdentifier();									// get an identifier from the input scanner
	bool GetNumber();										// get a number from the input scanner
	bool GetStringLiteral();								// get a string literal from the input scanner

	bool GetToken(CString hunt = "", CString span = " \t\n"); // get the next token delimited by the span
	bool AttributeExists(CString, CString);					// Does the attribute exist in table?
	const CString ReturnToken();							// return the last token from the input scanner
//
// Recursive descent parser of the embedded shared memory sql
//
	bool LHS();					// Get left hand side of an assignment statement
	bool E();					// Root of operator precendence grammar of the recursive descent parser
	bool ZPRIME();				// From ZPRIME to F() the productions have more precedence. F is highest
	bool EPRIME();
	bool T();
	bool Z();
	bool TPRIME();
	bool F();
	int TokenToType(CString);
	void Execute(SCCollection*);	// Executes the stack as constructed by the recursive descent parser
//
// private attributes of the object
//
	BOOL printStack;			// stack printing flag
	int nCols;					// number of columns in the table of the last transaction
	SCColumn** columnInfo;		// the pointer to the columns of the table in the last transaction
	CEStack* eStack;			// Stack executor object
	SCCollection* stack;		// the stack to execute
	CString inputString;		// the input string to the parser
	CString errorString;		// the error string, if any from result of parsing
	CString tokenString;		// the last token we recognized
	SCCollection* result;		// the result of the execution of eStack
};

//////////////////////////////////////