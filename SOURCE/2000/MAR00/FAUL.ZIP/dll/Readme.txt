Build Directions

The EMBSQL library, loadstocks and quotes programs are loacted in their
own directories. Each of these programs was built using Microsoft Visual C++
Version 6.0. Follow these instructions to get going.

[1] Build EMBSQL.DLL first.
Go to the EMBSQL directory and point the C++ IDE to EMBSQL.DSP. Build the 
project. The debug version is built by default and the files EMBSQL.DLL and EMBSQL.LIB
are located in the DEBUG directory. After the project builds, copy the EMBSQL.DLL to 
your c:\windows\system on Win95/98 or to c:\winnt\system32 on Windows NT. 
If you don't like copying the DLL into your system directory. Copy it to the same 
place you will execute your loadstocks.exe and quotes.exe program.


[2] Build loadstocks.exe second.
Go to the LOADSTOCKS directory and point the C++ IDE to LOADSTOCKS.DSP. 
Build the project. The debug version of the file LOADSTOCKS.EXE is built by 
default and is located in the directory DEBUG. Caveats:
    a. The EMBSQL.H include file must be in the include files directory of your IDE.
       Choose Tools/Options on the menu bar and click the directories tab. In the
       "Show Directories For" drop down list choose "Include Files". Input the
       location of the EMBSQL.H file
    b. The EMBSQL.LIB library must be in the libraries directory path of your IDE. 
       Choose Tools/Options and then click the directories tab. In the
       "Show Directories For" drop down list choose "Library Files". Input the
       location of the library.

The executable is in the
loadstocks/Debug directory.

[3] Build the quotes.exe last
Go to the QUOTES directory and point the C++ IDE to QUOTES.DSP. Build the
progject. The debug version is built and the file QUOTES.EXE is located in the
directory DEBUG. Caveats:
    a. The EMBSQL.H include file must be in the include files directory of your IDE.
       Choose Tools/Options on the menu bar and click the directories tab. In the
       "Show Directories For" drop down list choose "Include Files". Input the
       location of the EMBSQL.H file
    b. The EMBSQL.LIB library must be in the libraries directory path of your IDE. 
       Choose Tools/Options and then click the directories tab. In the
       "Show Directories For" drop down list choose "Library Files". Input the
       location of the library.
