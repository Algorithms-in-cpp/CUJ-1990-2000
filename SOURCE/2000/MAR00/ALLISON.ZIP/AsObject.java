class AsObject
{
    public static void main(String[] args)
    {
        int[] a = {1, 2, 3};
        int[] b = (int[]) a.clone();
        System.out.println("a.getClass() == " + a.getClass());
        System.out.println("b.getClass() == " + b.getClass());
        System.out.println("a == b: " + (a == b));
        System.out.println("a.equals(b): " + a.equals(b));
        for (int i = 0; i < b.length; ++i)
            System.out.print(b[i] + " ");
    }
}

/* Output:
a.getClass() == class [I
b.getClass() == class [I
a == b: false
a.equals(b): false
1 2 3 
*/
