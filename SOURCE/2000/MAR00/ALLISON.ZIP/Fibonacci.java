class Fibonacci
{
    public static void main(String[] args)
    {
        int[][] fib =
            {{0},
             {0, 1},
             {0, 1, 1},
             {0, 1, 1, 2,},
             {0, 1, 1, 2, 3},
             {0, 1, 1, 2, 3, 5},
             {0, 1, 1, 2, 3, 5, 8}
            };
        for (int i = 0; i < fib.length; ++i)
        {
            for (int j = 0; j < fib[i].length; ++j)
                System.out.print(fib[i][j] + " ");
            System.out.println();
        }
    }
}

/* Output:
0 
0 1 
0 1 1 
0 1 1 2 
0 1 1 2 3 
0 1 1 2 3 5 
0 1 1 2 3 5 8 
*/
