/*
 * Sample C++ application for CRC library.
 */
#include <iostream>
#include "crcplus.h"
#include "teststr.h"

int main()
{
  const unsigned char s[] = TEST_STRING;
  const unsigned char *p;

  Crc *crc = new Crc;

  for (p=s; *p; p++)
    {
      crc->Update(p,1);
    }
  cout << "CRC result=0x" << hex << crc->Value() << endl;
  delete crc;
}
