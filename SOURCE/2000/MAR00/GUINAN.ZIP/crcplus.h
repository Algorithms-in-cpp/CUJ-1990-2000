#ifndef _CRCPLUS_H_
#define _CRCPLUS_H_

class Crc
{
 private:
  unsigned long crc;
 public:
  Crc();
  void Update(const unsigned char *buf, int len);
  unsigned long Value();
  void Reset();
  unsigned long Eval(unsigned char *buf);
};

#endif
