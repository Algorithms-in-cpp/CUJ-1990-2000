/*
 * Sample C application for CRC library.
 */
#include <stdio.h>
#include "crc.h"
#include "teststr.h"

int main()
{
  const unsigned char *s = TEST_STRING;
  const unsigned char *p;
  unsigned long crc;

  crc = init_crc();
  for (p=s; *p; p++)
    {
      crc = update_crc(crc, p, 1);
    }
  printf("CRC result=0x%lx\n", value_crc(crc));
}
