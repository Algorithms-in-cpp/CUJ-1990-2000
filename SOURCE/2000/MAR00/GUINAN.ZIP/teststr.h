#define TEST_STRING "Cross Compililation with GNU tools!"

