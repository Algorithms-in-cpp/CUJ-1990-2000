#include "crcplus.h"
#include "crc.h"

Crc::Crc()
{
  Reset();
}

void Crc::Update(const unsigned char *buf, int len)
{
  crc = update_crc(crc, buf, len);
}

unsigned long Crc::Value()
{
  return value_crc(crc);
}

void Crc::Reset()
{
  crc = 0xFFFFFFFFL;  
}
