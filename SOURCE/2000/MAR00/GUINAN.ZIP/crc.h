#ifndef _CRC_H_
#define _CRC_H_

#ifdef __cplusplus
extern "C" {
#endif
 
unsigned long init_crc();
unsigned long update_crc(unsigned long crc, const unsigned char *buf,
			 int len);
unsigned long value_crc(unsigned long crc);

#ifdef __cplusplus
}
#endif

#endif
