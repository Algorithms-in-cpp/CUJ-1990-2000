ReadMe.txt

MFC Project files in ScenProj.zip

I used VC++ V6.0 to compile these files
to scen.exe; the *.h and *.cpp are probably
compatible with V5.0 but not the DSW and DSP
files.  I upgraded the project from V5.0 to V6.0.

The target Windows machine is a Pentium 300Mhz or
better, display set to 1024 * 768 24 bit truecolor
or better, I have 64Mb memory but 32Mb or even
16Mb might be OK.

Using Windows Explorer I created a CuProjects directory:
(File New Folder)
Or via MS-DOS
mkdir "C:\Program Files\DevStudio\CuProjects"
and
mkdir "C:\Program Files\DevStudio\CuProjects\scen"

I copied ScenProj.zip to
 "C:\Program Files\DevStudio\CuProjects\scen"
and unziped the file there.  Unziping creates
a RES subdirectory and its files.

Run VC6.0 and use File Open to bring these
files into the editor:

SCENDOC  H           2,748  14/09/99  10:42 scenDoc.h
SCENVIEW H           7,337  18/09/99   9:33 scenView.h
SCENDOC  CPP        14,173  14/09/99  10:43 scenDoc.cpp
SCENVIEW CPP        82,074  18/09/99   9:42 scenView.cpp

Select a build configuration Release or Debug
(Debug is the default) and Build, Build scen.exe
generates scen.exe

Run scen.exe, left click on 'Show scene'

To keep the project files to a minimum I have
used no library dialog boxes or controls.
The buttons and number input boxes are
custom; the code is in the project *.cpp files.
The number input boxes only respond to
the backspace key for erase, and to 'return'
to enter the number.

The internal data log memory file discards data
after 7500 lines. There is no warning.

A.T. September 1999

