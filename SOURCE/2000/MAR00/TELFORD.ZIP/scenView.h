// V1.53 scenView.h : interface of the CScenView class
//
/////////////////////////////////////////////////////////////////////////////
 
#if !defined(AFX_SCENVIEW_H__D6177DB0_637A_11D3_9449_44B1F9C00000__INCLUDED_)
#define AFX_SCENVIEW_H__D6177DB0_637A_11D3_9449_44B1F9C00000__INCLUDED_
 
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
 
class CScenView : public CView
{
public:
   
  int m_nScrCoordDisp;
  
  int m_nDataSource;
  int m_nDataOperation;
 
  int m_nWorkSzX;
  int m_nWorkSzY;
 
  int m_nWorkPosTop;
  int m_nWorkPosLeft;
 
  int m_nTextAvail;
 
  int m_nTextDisplay;
 
  int m_nCursorColour;
 
  int m_nCursorX;
  int m_nCursorY;
 
  int m_nCursorScrnX;
  int m_nCursorScrnY;
 
  int m_nCursorDataX;
  int m_nCursorDataY;
 
  int m_nDataPt;
 
  int m_nClientX;
  int m_nClientY;
 
  int m_nBoxColour;  // Work-box colour
 
  int m_nFxo;
  int m_nFyo;
 
  int m_nTextLine;
  int m_nTextLineDoc;
 
  int m_nFontStyle;    // 1 = Text,  2 = Fixed
 
  int m_nDataStart;
 
  int m_nInitText;
 
  int m_nRePaint;
 
  int m_nDbgState;  // 0 = off
 
  int m_nMouseInt;  // Mouse internal
 
  // Timer
 
  int m_nTimer;
  int m_nTimerState;
  int m_nTimerTicks;
 
  UINT m_uMillis;
 
  // Elapsed time
 
  double m_dTw;
 
  double m_dTstart;
  double m_dTelapsed;
 
  // Data input
 
  int m_nDataMode;
 
  int m_nDataInSel;
 
  int m_nSelBase;
 
  int m_nInValueBox;
 
  int m_nInputA;
 
  int m_nInputB;

  int m_nAccept;

  // Perspective

  int m_nSceneID;
  
  int m_nSceneState;

  // DisplayScene

  int m_nDeviceXleft;
  int m_nDeviceYtop;

  int m_nDeviceXsize;
  int m_nDeviceYsize;

  int m_nNumThings;
  int m_nThingIndex;

  int m_nVptype;
  int m_nVnumParts;
  int m_nPartIndex;

  int m_nVpartColour;

  int m_ScDisplayComplete;

  int m_ScMinMax;

  int m_ScFastRender;

  int m_ScDbgValue;

  // end DisplayScene

  // Perspective view transformation
      
  double m_ScOffpPosnX;  // Object world offset from Camera world
  double m_ScOffpPosnY;
  double m_ScOffpPosnZ;

  double m_ScvViewPtZ;  // View point Z distance

  double m_ScvDegAngle;  // Rotation of object world about Y axis
  double m_ScvAngle;     // Radians

  double m_ScvYdrop;   // View Y drop

  double m_ScvZoffset; // View Z offset

  double m_ScvXoffset; // View X offset
  
  double m_ScreenXleft; // Camera world position of screen
  double m_ScreenYtop;
  double m_ScreenXright;
  double m_ScreenYbot;      

  double m_ScreenXrange;

  double m_ScreenGainX;  
  double m_ScreenGainY;  

  double m_WorldToScreenR;  // World size to screen size ratio

  double m_NormWoX;   // Normalised (0.0 to 1.0) origin point
  double m_NormWoY;

  int m_WorgIy;  // Device origin point in pixels
  int m_WorgIx;

  double m_WorgSx;  // Camera world screen origin values
  double m_WorgTy;

  double m_ObjPosX;  // Perspective Thing position
  double m_ObjPosY;
  double m_ObjPosZ;    

  double m_ObjPtX;  // Perspective input 3D point
  double m_ObjPtY;
  double m_ObjPtZ;    
  
  double m_ScreenS;  // Perspective output (S x axis, T y axis)
  double m_ScreenT;

  double m_Ptva;  // Object (Thing) generation parameters (0.0 to 1.0)
  double m_Ptvas; // parameter increment ~= 1 pixel
  double m_Ptvb;
  double m_Ptvbs;
  double m_Ptvr;
  double m_Ptvt;

  double m_PartSizeMax;
  
  double m_nPartOrientation;

  double m_dcs;  // Cos and Sin
  double m_dsn;

  int m_DeviceIx;  // Screen point
  int m_DeviceIy;

  int m_DeviceHorizon;
  
  double m_dVarA;
  double m_dVarB;

  double m_ScPerspective[4][4];  // perspective

  double m_ScnObjCoords[4];    // Object coords  

  double m_rpc[4];    // trf coords  

  //int m_nNumThings;
  
  enum { m_ThingsBuff = 52,
         m_ThingsMax = 50 };

  int m_nThing[m_ThingsBuff];   // Up to 50 Things
    
  // end Perspective

  CString m_sAccept;

  CString m_csSearch;
 
  CString m_csA;
  CString m_csB;
  CString m_csC;
  CString m_csD;

 
  CFont* m_pFixedFont;
  CFont* m_pTextFont;
  CFont* m_pBigFont;
 
  CRect m_rcClient;

  // Selection buttons
 
  enum { m_Selr = 19,
         m_SelBf = 42,
         m_Data = 7,
         m_LinL = 24 };
 
  CRect m_rcWorkRect;
 
  CRect m_rcSkyRect;
 
  CRect m_rcVdataRect;  // Data input rect
 
  CRect m_rcTdataRect;
 
  CRect m_rcWorkRectDet;   // for mouse clicks
 
  CRect m_rcInvSel;
 
  CRect m_rcSel[m_Selr];
 
  char m_cBtnTxt[m_SelBf][m_LinL];
 
  int m_nBtnColour[m_SelBf];
 
  int m_nBtnDisplay[m_SelBf];
 
  CRect m_rcDataPanel;
 
  CRect m_rcVarA;
  CRect m_rcVarB;
 
  // Data input
 
  COLORREF m_crWhite;
  COLORREF m_crBlack;
  COLORREF m_crRed;
  COLORREF m_crGreen;
  COLORREF m_crDarkGreen;
  COLORREF m_crBlue;
  COLORREF m_crLightGray;
  COLORREF m_crDarkGray;
  COLORREF m_crWorkTxtBk;
 
  COLORREF m_crPart;
  COLORREF m_crSky;
  COLORREF m_crScrnDt;
 
  enum { m_NumSets = 8,
         m_NumParam = 8 };
 
  double m_ViewSet[m_NumSets][m_NumParam];
 
  enum { m_LinInL = 12,
         m_LinPrpL = 28,
         m_DataIn = 14 };
 
  // m_nDataInSel index
 
  char m_cDataTxt[m_DataIn][m_LinInL];
 
  char m_cDataPrompt[m_DataIn][m_LinPrpL];
 
  CRect m_rcDataSel[m_DataIn];
 
  double m_DataValue[m_DataIn];
 
  char m_cText[16];
 
 
protected: // create from serialization only
 CScenView();
 DECLARE_DYNCREATE(CScenView)
 
// Attributes
public:
 CScenDoc* GetDocument();
 
// Operations
public:
 
// Overrides
 // ClassWizard generated virtual function overrides
 //{{AFX_VIRTUAL(CScenView)
 public:
 virtual void OnDraw(CDC* pDC);  // overridden to draw this view
 virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
 protected:
 virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
 virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
 virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
 //}}AFX_VIRTUAL
 
// Implementation
public:
  virtual ~CScenView();
 
  double StartClock();
  double GetElapsedTime();
 
  void SetDataTxt();

  // Perspective

  void InitDisplayScene();

  void InitDisplayPart(int);

  void DisplayScene();

  void SetScene(int, int, int, int);

  void SetAllVisible();

  void PerspectiveInit();

  void PerspectiveTr();
  
#ifdef _DEBUG
 virtual void AssertValid() const;
 virtual void Dump(CDumpContext& dc) const;
#endif
 
protected:
 
// Generated message map functions
protected:
 //{{AFX_MSG(CScenView)
 afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
 afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
 afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
 afx_msg void OnTimer(UINT nIDEvent);
 //}}AFX_MSG
 DECLARE_MESSAGE_MAP()
};
 
#ifndef _DEBUG  // debug version in scenView.cpp
inline CScenDoc* CScenView::GetDocument()
   { return (CScenDoc*)m_pDocument; }
#endif
 
/////////////////////////////////////////////////////////////////////////////
 
//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.
 
#endif // !defined(AFX_SCENVIEW_H__D6177DB0_637A_11D3_9449_44B1F9C00000__INCLUDED_)

