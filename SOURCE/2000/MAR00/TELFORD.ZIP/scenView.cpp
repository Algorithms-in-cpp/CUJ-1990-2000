// V1.53 Scen
// 1999 Solarix Software
// scenView.cpp : implementation of the CScenView class
//

#include "stdafx.h"
#include "scen.h"
#include "scenDoc.h"
#include "scenView.h"
#include <direct.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <math.h> 

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScenView

#define INISTA 0
#define ACTN01 1
#define ACTN02 2
#define ACTN03 3
#define ACTN04 4
#define ACTN05 5
#define ACTN06 6
#define ACTN07 7
#define ACTN08 8
#define ACTN09 9
#define ACTN10 10
#define ACTN11 11
#define ACTN12 12
#define ACTN13 13
#define ACTN14 14
#define ACTN15 15
#define ACTN16 16
#define ACTN17 17
#define NEXTSB 18
#define APEXIT 19

#define ACTN20 20
#define ACTN21 21
#define ACTN22 22
#define ACTN23 23
#define ACTN24 24
#define ACTN25 25
#define ACTN26 26
#define ACTN27 27
#define ACTN28 28
#define ACTN29 29
#define SYSINF 30
#define TOPPAG 31
#define NEXPAG 32
#define PREPAG 33
#define LASPAG 34
#define TXLEFT 35
#define TXRIGH 36
#define BACKST 37
#define NEXTSC 38

#define STDGRA 98
#define STDTXT 99

IMPLEMENT_DYNCREATE(CScenView, CView)

BEGIN_MESSAGE_MAP(CScenView, CView)
//{{AFX_MSG_MAP(CScenView)
    ON_WM_CREATE()
    ON_WM_LBUTTONDOWN()
    ON_WM_CHAR()
    ON_WM_TIMER()
//}}AFX_MSG_MAP
// Standard printing commands
ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScenView construction/destruction

CScenView::CScenView()
{  
  int i,nSt,nDbg;
  int xl,xr,yt,yb;
  
  char cCr,cLf;
  
  CString sCrlf("ab");
  
  i = 0;
  nDbg = 0;
  
  m_nDataSource = INISTA;  // Action generator of Data for display
  m_nDataOperation = INISTA;
  
  m_nTextAvail = 0;
  
  m_nTextDisplay = 1;
  
  // Current dimensions of window
  
  m_nClientX = 0;
  m_nClientY = 0;
  
  m_nFxo = 8;
  m_nFyo = 4;
  
  m_nFontStyle = 2;  // 1 = Text,  2 = Fixed
  
  m_nDataStart = 0;
  
  m_nSelBase = 0;  // 1st Btn set
  
  m_pFixedFont = new CFont;
  m_pTextFont = new CFont;
  m_pBigFont = new CFont;
  
  m_nWorkPosTop = 30;
  m_nWorkPosLeft= 188;
  
  m_nWorkSzX = 816;
  m_nWorkSzY = 616;
  
  // CRect
  
  // Make the rect
  
  xl = m_nWorkPosLeft;
  xr = xl + m_nWorkSzX;  // X size
  yt = m_nWorkPosTop;
  yb = yt + m_nWorkSzY;
  
  m_rcWorkRect.SetRect(xl,yt,xr,yb);
  
  m_rcWorkRectDet = m_rcWorkRect;   // for mouse clicks
  
  xl += 72;
  xr = xl + 264;
  yt += 24;
  yb = yt + 168;
  
  m_rcVdataRect.SetRect(xl,yt,xr,yb);
  
  // Make the rect
  
  xl = m_nWorkPosLeft + 72;
  xr = xl + m_nWorkSzX - 128;  // X size
  yt = yb + 32;
  yb = yt + 200;
  
  m_rcTdataRect.SetRect(xl,yt,xr,yb);
  
  m_rcSkyRect.SetRect(0,0,2,2);
  
  // Client rect gets set at OnDraw
  
  xl = 0;
  xr = xl + 64;
  yt = 0;
  yb = yt + 64;
  
  m_rcClient.SetRect(xl,yt,xr,yb);
  
  // Make the array of selection rects
  
  xl = m_nWorkPosLeft - 180;
  xr = xl + 164;
  yt = m_nWorkPosTop;
  yb = yt + 28;
  
  // m_Selr = 19
  
  for(i=0; i<m_Selr; i++){
    
    m_rcSel[i].SetRect(xl,yt,xr,yb);
    yt += 32;
    yb = yt + 28;
    
  }
  
  // Selection button invalidate rect
  
  yt = m_nWorkPosTop;
  
  m_rcInvSel.SetRect(xl,yt,xr,yb);
  
  nSt = 0;
  
  // ACTN01
  
  strcpy(m_cBtnTxt[nSt],"Show Scene");  // 1 Scene ACTN01
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Set Y drop");  // 2 ACTN01
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Set screen gain");  // 3
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Set world angle");  // 4
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Set view pt Z");  // 5
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Set Z offset");  // 6
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  
  strcpy(m_cBtnTxt[nSt],"Set X offset");  // 7
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Set X origin");  // 8
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Set Y origin");  // 9
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Show scrn coords");  // 10 ACTN10
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Show view data");  // 11
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Show transform");  // 12
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"View set A");  // 13
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"View set B");  // 14
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"View set C");  // 15
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"View set D");  // 16
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"View set E");  // 17
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  
  strcpy(m_cBtnTxt[nSt],"Next set");  // 18  Second set of buttons
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Exit");  // 19
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  
  // Second button set
  // + m_nSelBase
  
  // ACTN20
  
  strcpy(m_cBtnTxt[nSt],"Axes on/off");  // 20  ACTN20
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Grid on/off");  // 21 ACTN21
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Box on/off");  // 22 ACTN01
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Tank on/off");  // 23
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Fast render on/off");  // 24
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt]," ");  // 25
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 0;      // Unused
  nSt++;
  strcpy(m_cBtnTxt[nSt]," ");  // 26
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 0;
  
  nSt++;
  strcpy(m_cBtnTxt[nSt]," ");  // 27
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 0;
  nSt++;
  strcpy(m_cBtnTxt[nSt]," ");  // 28
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 0;
  nSt++;
  strcpy(m_cBtnTxt[nSt]," ");  // 29 ACTN29
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 0;
  nSt++;
  
  strcpy(m_cBtnTxt[nSt],"Data log");  // 31
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Top page");  // 32
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Next page");  // 33
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Previous page");  // 34
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Last page");  // 35
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Left");  // 36  Shift long text lines L/R
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Right");  // 37
  m_nBtnColour[nSt] = 0;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt],"Back");  // 38  First button set
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 1;
  nSt++;
  strcpy(m_cBtnTxt[nSt]," ");  // 39
  m_nBtnColour[nSt] = 1;
  m_nBtnDisplay[nSt] = 0;
  nSt++;
  
  
  nDbg = 20;
  
  m_nTextLine = 0;
  m_nTextLineDoc = 0;
  
  m_csSearch.Empty();
  
  m_csA.Empty();
  m_csB.Empty();
  m_csC.Empty();
  m_csD.Empty();
  
  m_nInitText = 0;
  
  m_nDbgState = 0;  // 0 = off
  
  m_nRePaint = 0;   // do once
  
  // Make the array of Data input rects
  
  xl = m_nWorkPosLeft + 24;
  xr = xl + 392;
  yt = m_nWorkPosTop + 96;
  yb = yt + 40;
  
  for(i=0; i<m_DataIn; i++){
    
    strcpy(m_cDataTxt[i],"_");
    
    m_rcDataSel[i].SetRect(xl,yt,xr,yb);
    yt += 32;
    yb = yt + 40;
    
  }
  
  // ACTN01
  
  strcpy(m_cDataPrompt[0]," ");
  strcpy(m_cDataPrompt[1],"Set Y drop  :");
  strcpy(m_cDataPrompt[2],"Screen gain :");
  strcpy(m_cDataPrompt[3],"World angle :");
  strcpy(m_cDataPrompt[4],"Set view Z  :");
  strcpy(m_cDataPrompt[5],"Set Z offset:");
  strcpy(m_cDataPrompt[6],"Set X offset:");
  strcpy(m_cDataPrompt[7],"Set X origin:");
  strcpy(m_cDataPrompt[8],"Set Y origin:");
  strcpy(m_cDataPrompt[9]," ");
  
  m_crWhite = RGB(255, 255, 255);
  m_crBlack = RGB(0, 0, 0);
  m_crRed = RGB(255, 128, 128);
  m_crGreen = RGB(192, 240, 192);
  m_crDarkGreen = RGB(80, 140, 80);
  m_crBlue = RGB(140, 140, 255);
  m_crLightGray = RGB(192, 192, 192);
  m_crDarkGray = RGB(128, 128, 128);
  
  m_crWorkTxtBk = m_crWhite;
  
  m_crPart = RGB(0, 0, 0);  // varies
    
  m_crSky = RGB(204, 130, 186);  // violet
  
  m_crScrnDt = RGB(220, 96, 0);  // orange
  
  m_nDataMode = 0;
  
  m_nBoxColour = 0;   // off
  
  m_nDataInSel = 1;
  
  m_nInValueBox = 0;
  
  m_nInputA = 0;
  m_nInputB = 0;
  
  m_nCursorColour = 2;
  
  m_nCursorX = 0;
  m_nCursorY = 0;
  
  m_nCursorScrnX = 0;
  m_nCursorScrnY = 0;
  
  m_nCursorDataX = -1;
  
  m_nCursorDataY = -1;
  
  m_nDataPt = 0;
  
  m_nTimer = 0;
  m_nTimerState = 0;  // off
  m_nTimerTicks = 0;
  
  UINT m_uMillis = 0;
  
  // Elapsed time
  
  m_dTw = 0.0;
  
  m_dTstart = 0.0;
  m_dTelapsed = 0.0;
  
  m_cText[0] = 0;
  m_cText[1] = 0;

  //Acceptance
  
  m_nAccept = 0;  // 0 for acceptance message to appear
  
  cCr = 13;  
  sCrlf.SetAt(0,cCr);
  
  cLf = 10;
  sCrlf.SetAt(1,cLf);
  
  m_sAccept = "V1.53 scen.exe";
  m_sAccept += sCrlf;
  
  m_sAccept += "This software is experimental code";
  m_sAccept += sCrlf;
  m_sAccept += "for developers. It is not fully tested;";
  m_sAccept += sCrlf;
  m_sAccept += "there may be bugs. It is provided";
  m_sAccept += sCrlf;
  m_sAccept += "for demonstration of concept only,";
  m_sAccept += sCrlf;
  m_sAccept += "and is not production quality";
  m_sAccept += sCrlf;
  m_sAccept += "software. It may be used if these limitations";
  m_sAccept += sCrlf;
  m_sAccept += "and conditions are accepted.";
  m_sAccept += sCrlf;  
    
  // Scene
  
  m_nMouseInt = 0;            // Mouse internal
  
  m_nScrCoordDisp = 0;   // off
  
  //double m_ViewSet[m_NumSets][m_NumParam];
  //m_NumSets = 8
  //m_NumParam = 8

  // Set B
  //Set Y drop   (-40.0)
  //Screen gain  (100)
  //World angle  (-15)
  //Set view Z   (50.0)
  //Set Z offset (-50.0)
  //Set X offset (0.0)
  //Set X origin (0.2)
  //Set Y origin (0.2)
  
  //Y drop       m_ScvYdrop
  //Screen gain  m_ScreenGainX (Y)
  //World angle  m_ScvDegAngle
  //Z view point m_ScvViewPtZ
  //Z offset     m_ScvZoffset
  //X offset     m_ScvXoffset
  //X origin     m_NormWoX
  //Y origin     m_NormWoY
  
  // View set A ACTN13
  
  m_ViewSet[0][0] = -6.0;  //Set Y drop   (-40.0)
  m_ViewSet[0][1] = 100.0; //Screen gain  (100)
  m_ViewSet[0][2] = 0.0;   //World angle  (-15)
  m_ViewSet[0][3] = 10.0;  //Set view Z   (50.0)
  m_ViewSet[0][4] = -10.0; //Set Z offset (-50.0)
  m_ViewSet[0][5] = -3.0;  //Set X offset (0.0)
  m_ViewSet[0][6] = 0.2;   //Set X origin (0.2)
  m_ViewSet[0][7] = 0.2;   //Set Y origin (0.2)
  
  // View set B
  
  m_ViewSet[1][0] = -40.0; //Set Y drop   (-40.0)
  m_ViewSet[1][1] = 100.0; //Screen gain  (100)
  m_ViewSet[1][2] = -15.0; //World angle  (-15)
  m_ViewSet[1][3] = 50.0;  //Set view Z   (50.0)
  m_ViewSet[1][4] = -50.0; //Set Z offset (-50.0)
  m_ViewSet[1][5] = 0.0;   //Set X offset (0.0)
  m_ViewSet[1][6] = 0.2;   //Set X origin (0.2)
  m_ViewSet[1][7] = 0.2;   //Set Y origin (0.2)
  
  // View set C
  
  m_ViewSet[2][0] = -1.0;  //Set Y drop   (-40.0)
  m_ViewSet[2][1] = 500.0; //Screen gain  (100)
  m_ViewSet[2][2] = 0.0;   //World angle  (-15)
  m_ViewSet[2][3] = 3.0;   //Set view Z   (50.0)
  m_ViewSet[2][4] = -3.0;  //Set Z offset (-50.0)
  m_ViewSet[2][5] = -1.0;  //Set X offset (0.0)
  m_ViewSet[2][6] = 0.1;   //Set X origin (0.2)
  m_ViewSet[2][7] = 0.2;   //Set Y origin (0.2)
  
  // View set D
  
  m_ViewSet[3][0] = -2.0;  //Set Y drop   (-40.0)
  m_ViewSet[3][1] = 300.0; //Screen gain  (100)
  m_ViewSet[3][2] = 45.0;   //World angle  (-15)
  m_ViewSet[3][3] = 2.0;   //Set view Z   (50.0)
  m_ViewSet[3][4] = -2.0;  //Set Z offset (-50.0)
  m_ViewSet[3][5] = 0.0;  //Set X offset (0.0)
  m_ViewSet[3][6] = 0.3;   //Set X origin (0.2)
  m_ViewSet[3][7] = 0.2;   //Set Y origin (0.2)
  
  // View set D alt
  
  // m_ViewSet[3][0] = -0.5; //Set Y drop   (-40.0)
  // m_ViewSet[3][1] = 800.0; //Screen gain  (100)
  // m_ViewSet[3][2] = 0.0; //World angle  (-15)
  // m_ViewSet[3][3] = 1.0;  //Set view Z   (50.0)
  // m_ViewSet[3][4] = -1.0; //Set Z offset (-50.0)
  // m_ViewSet[3][5] = -4.0;   //Set X offset (0.0)
  // m_ViewSet[3][6] = -1.2;   //Set X origin (0.2)
  // m_ViewSet[3][7] = 0.05;   //Set Y origin (0.2)
  
  // View set E
  
  m_ViewSet[4][0] = 6.0;  //Set Y drop   (-40.0)
  m_ViewSet[4][1] = 100.0; //Screen gain  (100)
  m_ViewSet[4][2] = 0.0;   //World angle  (-15)
  m_ViewSet[4][3] = 10.0;  //Set view Z   (50.0)
  m_ViewSet[4][4] = -10.0; //Set Z offset (-50.0)
  m_ViewSet[4][5] = -3.0;  //Set X offset (0.0)
  m_ViewSet[4][6] = 0.2;   //Set X origin (0.2)
  m_ViewSet[4][7] = 0.8;   //Set Y origin (0.2)
  
  // Perspective
  
  m_nSceneID = 0;
  
  m_nDeviceXleft = 0;
  m_nDeviceYtop = 0;
  
  m_nDeviceXsize = 0;
  m_nDeviceYsize = 0;
  
  // Perspective view transformation
  
  // View set A
  
  // m_ViewSet[0][0] = -6.0;  // Y drop
  // m_ViewSet[0][1] = 100.0; // Screen gain
  // m_ViewSet[0][2] = 0.0;   // World angle
  // m_ViewSet[0][3] = 10.0;  // view Z
  // m_ViewSet[0][4] = -10.0; // Z offset
  // m_ViewSet[0][5] = -4.0;  // X offset
  // m_ViewSet[0][6] = 0.2;   // X origin
  // m_ViewSet[0][7] = 0.2;   // Y origin
  
  // View set B
  
  // m_ScvYdrop = -40.0;     // -40.0 View Y drop
  // m_ScreenGainX = 100.0;  // Screen gain
  // m_ScreenGainY = 100.0;
  // m_ScvDegAngle = -15.0;  // World angle -15 deg
  // m_ScvViewPtZ =  50.0;   // View point, metres
  // m_ScvZoffset = -50.0;   // -50.0 View Z offset
  // m_ScvXoffset = 0.0;     // 0.0 View X offset
  // m_NormWoX = 0.2;        // Normalised device X origin
  // m_NormWoY = 0.2;
  
  m_ScvYdrop = -6.0;     //  View Y drop
  
  m_ScreenGainX = 100.0; // Screen gain
  m_ScreenGainY = 100.0;
  
  m_ScvDegAngle = 0.0;   // World angle
  
  m_ScvViewPtZ =  10.0;  // View point, metres
  
  m_ScvZoffset = -10.0;  // View Z offset
  
  m_ScvXoffset = -3.0;   // View X offset
  
  m_NormWoX = 0.2;       // Normalised device X origin
  m_NormWoY = 0.2;
  
  m_ScvAngle = 3.14153 * m_ScvDegAngle / 180.0;  // radians
  
  m_WorldToScreenR = 0.5;  
  
  m_WorgIy = 0;  // Device viewport location of Object origin
  m_WorgIx = 0;
  
  m_WorgSx = 0.0; // Camera world viewport location of Object origin
  m_WorgTy = 0.0;
  
  m_ScreenXleft = 0.0; // Camera world viewport position
  m_ScreenXright = 0.0;
  m_ScreenYtop = 0.0;      
  m_ScreenYbot = 0.0;
  
  m_ScreenXrange = 0.0;
  
  m_ObjPosX = 0.0;  // Perspective Object position
  m_ObjPosY = 0.0;
  m_ObjPosZ = 0.0;      
  
  m_ObjPtX = 0.0;  // Perspective input 3D point
  m_ObjPtY = 0.0;
  m_ObjPtZ = 0.0;    
  
  m_ScreenS = 0.0;  // Perspective output
  m_ScreenT = 0.0;
  
  m_DeviceIx = 0;
  m_DeviceIy = 0;

  m_nPartOrientation = 0;

  m_PartSizeMax = 0.0;
  
  m_DeviceHorizon = 0;
  
  PerspectiveInit();  // Set up perspective Tr
  
}

CScenView::~CScenView()
{
  
  delete m_pBigFont;
  delete m_pTextFont;
  delete m_pFixedFont;
  
}

BOOL CScenView::PreCreateWindow(CREATESTRUCT& cs)
{
  // TODO: Modify the Window class or styles here by modifying
  //  the CREATESTRUCT cs
  
  return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CScenView drawing

void CScenView::OnDraw(CDC* pDC)
{
  CScenDoc* pDoc = GetDocument();
  ASSERT_VALID(pDoc);
    
  // 1999 Solarix Software
  
  int i,j,k,ytxt,yps,xtxt;
  int ks,ke,kSel;
  int xl,xr,yt,yb,xm;
  int nx,ny;
  int ix,iy,nPxc,nPxd,nPxm;
  int nDisp;
  int nDbg;
  
  double dMpx,vs,TwoPi;
    
  // Frame line colour
  
  CBrush brFrm(RGB(180, 180, 240));
  
  // Selection rects grouping colours
  
  CBrush brSelrcA(RGB(160, 240, 160));
  
  CBrush brSelrcB(RGB(160, 240, 220));
  
  CBrush* pbrSelrcA = &brSelrcA;
  CBrush* pbrSelrcB = &brSelrcB;
  
  // NB NB all brushes, pens and palettes
  // must be on local OnDraw Stack, NOT
  // View class members.
  
  CBrush DarkGrayBr;
  CBrush LightGrayBr;
  CBrush WhiteBr;
  CBrush BlackBr;
  CBrush RedBr;
  CBrush GreenBr;
  CBrush DarkGreenBr;
  CBrush BlueBr;
  CBrush SkyBr;
  
  CBrush* pDarkGrayBr;
  CBrush* pLightGrayBr;
  CBrush* pWhiteBr;
  CBrush* pBlackBr;
  CBrush* pRedBr;
  CBrush* pGreenBr;
  CBrush* pDarkGreenBr;
  CBrush* pBlueBr;
  CBrush* pSkyBr;
  
  CBrush* pOldBrush;
  
  CPen DarkGrayPn;
  CPen LightGrayPn;
  CPen WhitePn;
  CPen BlackPn;
  CPen ThkWhitePn;
  CPen ThkBlackPn;
  
  CPen pnCursorG(PS_SOLID, 1, m_crLightGray);
  CPen pnCursorW(PS_SOLID, 1, m_crWhite);
  CPen pnCursorB(PS_SOLID, 1, RGB(6, 6, 6));
  
  CPen* pDarkGrayPn;
  CPen* pLightGrayPn;
  CPen* pWhitePn;
  CPen* pBlackPn;
  CPen* pThkWhitePn;
  CPen* pThkBlackPn;
  
  CPen* pOldPen;
  
  pDarkGrayBr = &DarkGrayBr;
  pLightGrayBr = &LightGrayBr;
  pWhiteBr = &WhiteBr;
  pBlackBr = &BlackBr;
  pRedBr = &RedBr;
  pGreenBr = &GreenBr;
  pDarkGreenBr = &DarkGreenBr;
  pBlueBr = &BlueBr;
  pSkyBr = &SkyBr;
  
  pDarkGrayPn = &DarkGrayPn;
  pLightGrayPn = &LightGrayPn;
  pWhitePn = &WhitePn;
  pBlackPn = &BlackPn;
  pThkWhitePn = &ThkWhitePn;
  pThkBlackPn = &ThkBlackPn;
  
  pOldPen = &BlackPn;
  
  CFont* pOldFont;
  
  DWORD dwTotal, dwFree;
  
  CString csA,csB;
  
  char text[84];
  
  nDbg = 0;
  
  WhiteBr.CreateSolidBrush(m_crWhite);
  BlackBr.CreateSolidBrush(m_crBlack);
  RedBr.CreateSolidBrush(m_crRed);
  GreenBr.CreateSolidBrush(m_crGreen);
  DarkGreenBr.CreateSolidBrush(m_crDarkGreen);
  BlueBr.CreateSolidBrush(m_crBlue);
  SkyBr.CreateSolidBrush(m_crSky);
  
  LightGrayBr.CreateSolidBrush(m_crLightGray);
  DarkGrayBr.CreateSolidBrush(m_crDarkGray);
  
  WhitePn.CreatePen(PS_SOLID, 1, m_crWhite);
  BlackPn.CreatePen(PS_SOLID, 1, m_crBlack);
  
  LightGrayPn.CreatePen(PS_SOLID, 1, m_crLightGray);
  DarkGrayPn.CreatePen(PS_SOLID, 1, m_crDarkGray);
  
  ThkWhitePn.CreatePen(PS_DASH, 2, m_crWhite);
  ThkBlackPn.CreatePen(PS_DASH, 2, m_crBlack);
  
  i = 0;
  j = 0;
  k = 0;
  
  dwTotal = 0;
  dwFree = 0;
  
  // Get current dimensions of window
  
  GetClientRect(m_rcClient);
  
  m_nClientX = m_rcClient.right;
  m_nClientY = m_rcClient.bottom;
  
  xtxt = 0;
  ytxt = 0;
  yps = 20;     // MM_TEXT
  
  pDC->TextOut(0, ytxt, " V1.53 Scen");
  pDC->TextOut(200, ytxt, " Solarix Software 1999");
  ytxt += yps;
  
  nDbg = 1;
  
  if(m_nDataSource == STDTXT){
    
    m_nBoxColour = 0;
    
  }
  
  // Test for work-box colour on
  
  if(m_nBoxColour == 0){
    
    // No work-box colour
    
    pDC->FrameRect(m_rcWorkRect, &brFrm);
    
    pDC->SetBkColor(m_crWhite);
    
  }
  else{
    
    // work-box colour on
    
    pOldBrush = pDC->SelectObject(pDarkGreenBr);
    
    pDC->Rectangle(m_rcWorkRect);
    
  }
  
  xtxt = m_nWorkPosLeft + 8;
  ytxt = m_nWorkPosTop + 4;
  
  // Draw selection rects
  
  pOldBrush = pDC->SelectObject(pbrSelrcA);
  
  CPoint cnr;
  
  pDC->SetBkColor(RGB(160, 240, 160));
  
  cnr.x = 20;
  cnr.y = 12;
    
  kSel = m_nDataOperation - 1;
  
  for(i=0; i<m_Selr; i++){
    
    j = m_nSelBase + i;
    
    if(m_nBtnColour[j] == 0 && m_nBtnDisplay[j] == 1){
      pDC->SelectObject(pbrSelrcA);
      pDC->SetBkColor(RGB(160, 240, 160));
      pDC->RoundRect(m_rcSel[i], cnr);
    }
    
    if(m_nBtnColour[j] == 1 && m_nBtnDisplay[j] == 1){
      pDC->SelectObject(pbrSelrcB);
      pDC->SetBkColor(RGB(160, 240, 220));
      pDC->RoundRect(m_rcSel[i], cnr);
    }
    
    nx = m_rcSel[i].left + 16;
    ny = m_rcSel[i].top + 2;
    
    if(m_nBtnDisplay[j] == 1){
      pDC->TextOut(nx,ny,m_cBtnTxt[m_nSelBase+i]);
    }
    
    if(j == kSel){
      
      pDC->TextOut(nx-12,ny,">");
      
    }
    
    pDC->SetBkColor(RGB(160, 240, 160));
    
  }
  
  pDC->SetBkColor(RGB(255, 255, 255));
  
  pDC->SelectObject(pOldBrush);
  
  pOldFont = pDC->SelectObject(m_pFixedFont);
  
  // Check for Import file
  
  nDbg = 2;
  
  if(pDoc->m_nLinesRd > 0){
    
    k = pDoc->m_nLinesRd;  // Size of last file import
    
    m_nDataSource = STDTXT;
    m_nTextAvail = 1;
    
  }
  
  // Initial text on start up, do once
  
  if(m_nDataSource == INISTA){
    
    pDoc->FtReset();
    
    SetFont(m_pBigFont);
    
    pOldFont = pDC->SelectObject(m_pBigFont);
    
    pDC->SetTextColor(m_crBlue);
    
    pDoc->PutTex(" ");
    pDoc->PutTex(" ");
    pDoc->PutTex("            Scen");
    pDoc->PutTex(" ");
    pDoc->PutTex(" ");
    pDoc->PutTex(" An instrumented workbench for");
    pDoc->PutTex(" ");
    pDoc->PutTex(" 3D scenes in perspective.");
    pDoc->PutTex(" ");
    
    xl = m_nWorkPosLeft;
    xr = xl + m_nWorkSzX;
    xm = xl - 48 + m_nWorkSzX / 2;
    yt = m_nWorkPosTop - 38 + m_nWorkSzY / 3;
    yb = m_nWorkPosTop - 24 + m_nWorkSzY;
    
    pDC->MoveTo(xl,yt);
    pDC->LineTo(xr,yt);
    pDC->MoveTo(xl,yb);
    pDC->LineTo(xm,yt);
    pDC->LineTo(xr,yb);
    
    ks = 0;
    
    ke = pDoc->m_nCtLines;
    
    xtxt = m_nWorkPosLeft + 40;
    
    for(i=ks; i<ke; i++){
      
      csA = pDoc->GetString(i);
      
      if(csA.GetLength() > 4){
        pDC->TextOut(xtxt, ytxt, csA);
      }
      
      ytxt += yps;
      ytxt += yps;
      
    }
    
    SetFont(m_pFixedFont);
    
    pOldFont = pDC->SelectObject(m_pFixedFont);
    
    pDC->SetTextColor(RGB(0, 0, 0));
    
    xtxt = m_nWorkPosLeft + 8;
    
  }
  
  if(m_nDataSource == STDGRA && m_nDataOperation == ACTN01 && m_nMouseInt == 1){
    
    // Scene
    
    // SetPixel
    
    nDbg = 2;
    
    if(m_nSceneID < 1){
      
      m_nMouseInt = 0;
      return;
      
    }
    
    
    PerspectiveInit();
    
    // Try make a sky rect
    
    xl = m_nWorkPosLeft;
    xr = xl + m_nWorkSzX;
    yt = m_nWorkPosTop;
    yb = yt + m_nWorkSzY;
    
    if(m_DeviceHorizon > yt && m_DeviceHorizon < yb){
      
      yb = m_DeviceHorizon;
      
      m_rcSkyRect.SetRect(xl,yt,xr,yb);
      
      pOldBrush = pDC->SelectObject(pSkyBr);
      
      //pDC->SetTextColor(RGB(255, 255, 255));
      
      //pDC->SetBkColor(m_crBlue);
      
      pDC->Rectangle(m_rcSkyRect);
      
    }
    
    nPxc = 0;
    nPxd = 0;
    nPxm = 0;
    
    dMpx = 0.0;
    
    nDbg = 3;
    
    xl = m_nWorkPosLeft;
    xr = xl + m_nWorkSzX;
    yt = m_nWorkPosTop;
    yb = yt + m_nWorkSzY;
    
    // start display
    
    // Show grid
    
    if(m_nThing[0] == 1){
      
      // Do Z lines
      
      m_ObjPosX = 1.0;  // Perspective Thing position
      m_ObjPosY = 0.0;
      m_ObjPosZ = 0.0;
      
      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.0;
      m_ObjPtZ = 0.0;
      
      m_PartSizeMax = 24.0;
      
      InitDisplayPart(0);
      
      m_crPart = RGB(200, 200, 255);
      
      for(i=0; i<12; i++){
        
        for(m_Ptva=0.0; m_Ptva<1.0; m_Ptva += m_Ptvas){
          
          m_ObjPtZ = -24.0 * m_Ptva;  // point in 3D
          
          nDbg = 4;
          
          PerspectiveTr();  // Output in m_DeviceIx,m_DeviceIy
          
          ix = m_DeviceIx;
          iy = m_DeviceIy;
          
          nPxc++;
          nPxm++;
          
          nDisp = 1;
          
          if(ix < xl)nDisp = 0;
          if(ix > xr)nDisp = 0;
          if(iy < yt)nDisp = 0;
          if(iy > yb)nDisp = 0;
          
          if(nDisp == 1)pDC->SetPixel(ix, iy, m_crPart);
          
        }
        
        m_ObjPosX += 1.0;  // posn in 3D
        m_ObjPosY = 0.0;
        m_ObjPosZ = 0.0;        
        
      }
      
      // Do X lines
      
      m_ObjPosX = 0.0;  // Perspective Thing position
      m_ObjPosY = 0.0;
      m_ObjPosZ = -1.0;
      
      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.0;
      m_ObjPtZ = 0.0;
      
      m_PartSizeMax = 12.0;
      
      InitDisplayPart(0);
      
      m_crPart = RGB(200, 255, 200);
      
      for(i=0; i<24; i++){
        
        for(m_Ptva=0.0; m_Ptva<1.0; m_Ptva += m_Ptvas){
          
          m_ObjPtX = 12.0 * m_Ptva;  // point in 3D
          
          nDbg = 4;
          
          PerspectiveTr();  // Output in m_DeviceIx,m_DeviceIy
          
          ix = m_DeviceIx;
          iy = m_DeviceIy;
          
          nPxc++;
          nPxm++;
          
          nDisp = 1;
          
          if(ix < xl)nDisp = 0;
          if(ix > xr)nDisp = 0;
          if(iy < yt)nDisp = 0;
          if(iy > yb)nDisp = 0;
          
          if(nDisp == 1)pDC->SetPixel(ix, iy, m_crPart);
          
        }
        
        m_ObjPosX = 0.0;  // posn in 3D
        m_ObjPosY = 0.0;
        m_ObjPosZ -= 1.0;        
        
      }
      
      
      // Check max pixels
      
      if(nPxc > 10000000)goto exds;
      
      if(nPxm > 200000){
        
        nPxm = 0;
        
        dMpx = double(nPxc) / 1000000.0;
        
        sprintf(text,"%4.1lf Mpx  ",dMpx);
        
        nx = m_nWorkPosLeft + m_nWorkSzX / 2;
        ny = m_nWorkPosTop + 8;
        
        pDC->TextOut(nx, ny, text);
        
      }    
      
    }  // end grid visible
    
    // Show box
    
    if(m_nThing[1] == 1){
      
      // Do 6 plates
      
      m_ObjPosX = 5.0;  // Perspective Thing position
      m_ObjPosY = 0.0;
      m_ObjPosZ = -10.0;
      
      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.0;
      m_ObjPtZ = 0.0;
      
      m_PartSizeMax = 1.0;
      
      InitDisplayPart(0);
            
      for(i=0; i<6; i++){
      
        m_ObjPtX = 0.0;  // point in 3D
        m_ObjPtY = 0.0;
        m_ObjPtZ = 0.0;

        if(i == 0){

          m_nPartOrientation = 1;  // XY
          m_ObjPtZ = -1.0;
          m_crPart = RGB(200, 200, 255);    // Blue

        }
        
        if(i == 1){

          m_nPartOrientation = 2;  // XZ
          m_ObjPtY = 0.0;
          m_crPart = RGB(200, 255, 200);    // Green

        }
        
        if(i == 2){

          m_nPartOrientation = 3;  // YZ
          m_ObjPtX = 1.0;
          m_crPart = RGB(255, 200, 200);    // Red

        }
        
        if(i == 3){

          m_nPartOrientation = 3;  // YZ
          m_ObjPtX = 0.0;
          m_crPart = RGB(240, 160, 160);    // Red

        }
        
        if(i == 4){

          m_nPartOrientation = 1;  // XY
          m_ObjPtZ = 0.0;
          m_crPart = RGB(180, 240, 180);    // Green

        }
        
        if(i == 5){

          m_nPartOrientation = 2;  // XZ
          m_ObjPtY = 1.0;
          m_crPart = RGB(180, 180, 240);    // Blue

        }

        for(m_Ptva=0.0; m_Ptva<=1.0; m_Ptva += m_Ptvas){
          
          for(m_Ptvb=0.0; m_Ptvb<=1.0; m_Ptvb += m_Ptvbs){
            
            if(m_nPartOrientation == 1){
              
              // Plate in XY plane
              
              m_ObjPtX = m_Ptva;  // point in 3D
              m_ObjPtY = m_Ptvb;
              
            }
            
            if(m_nPartOrientation == 2){
              
              // Plate in XZ plane
              
              m_ObjPtX = m_Ptva;  // point in 3D
              m_ObjPtZ = -m_Ptvb;
              
            }
            
            if(m_nPartOrientation == 3){
              
              // Plate in YZ plane
              
              m_ObjPtY = m_Ptva;  // point in 3D
              m_ObjPtZ = -m_Ptvb;
              
            }  
            
            nDbg = 4;
            
            PerspectiveTr();  // Output in m_DeviceIx,m_DeviceIy
            
            ix = m_DeviceIx;
            iy = m_DeviceIy;
            
            nPxc++;
            nPxm++;
            
            nDisp = 1;
            
            if(ix < xl)nDisp = 0;
            if(ix > xr)nDisp = 0;
            if(iy < yt)nDisp = 0;
            if(iy > yb)nDisp = 0;
            
            if(nDisp == 1)pDC->SetPixel(ix, iy, m_crPart);
            
          }
          
        }     
        
        // Check max pixels
        
        if(nPxc > 10000000)goto exds;
        
        if(nPxm > 200000){
          
          nPxm = 0;
          
          dMpx = double(nPxc) / 1000000.0;
          
          sprintf(text,"%4.1lf Mpx  ",dMpx);
          
          nx = m_nWorkPosLeft + m_nWorkSzX / 2;
          ny = m_nWorkPosTop + 8;
          
          pDC->TextOut(nx, ny, text);
          
        }
        
      }
      
    }  // end box visible
    
    
    // Show tank
    
    if(m_nThing[2] == 1){
      
      // Do disk, cylinder, disk

      TwoPi = 6.2832;
      
      m_ObjPosX = 2.0;  // Perspective Thing position
      m_ObjPosY = 0.0;
      m_ObjPosZ = -5.0;
      
      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.0;
      m_ObjPtZ = 0.0;
      
      m_PartSizeMax = 2.0;
      
      InitDisplayPart(1);
                  
      // Disk XZ at Y = 0.0

      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.0;
      m_ObjPtZ = 0.0;

      m_crPart = RGB(200, 200, 255);    // Blue

      for(m_Ptvb=0.0; m_Ptvb<=1.0; m_Ptvb += m_Ptvbs){
  
        m_Ptvt = TwoPi * m_Ptvb;  // disk gen angle

        m_dcs = cos(m_Ptvt);  // for speed
        m_dsn = sin(m_Ptvt);
  
        for(m_Ptva=0.0; m_Ptva<=1.0; m_Ptva += m_Ptvas){
            
          // Disk in XZ plane

          m_ObjPtX = m_Ptva * m_dcs;  // point in 3D
          m_ObjPtZ = m_Ptva * m_dsn;
            
          nDbg = 4;
            
          PerspectiveTr();  // Output in m_DeviceIx,m_DeviceIy
            
          ix = m_DeviceIx;
          iy = m_DeviceIy;
            
          nPxc++;
          nPxm++;
            
          nDisp = 1;
            
          if(ix < xl)nDisp = 0;
          if(ix > xr)nDisp = 0;
          if(iy < yt)nDisp = 0;
          if(iy > yb)nDisp = 0;
            
          if(nDisp == 1)pDC->SetPixel(ix, iy, m_crPart);
            
        }
          
      }     
        
      // Check max pixels
        
      if(nPxc > 10000000)goto exds;
        
      if(nPxm > 200000){
          
        nPxm = 0;
          
        dMpx = double(nPxc) / 1000000.0;
          
        sprintf(text,"%4.1lf Mpx  ",dMpx);
          
        nx = m_nWorkPosLeft + m_nWorkSzX / 2;
        ny = m_nWorkPosTop + 8;
          
        pDC->TextOut(nx, ny, text);
          
      }
        
      // Cylinder

      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.0;
      m_ObjPtZ = 0.0;

      m_crPart = RGB(200, 255, 255);    // Blue-Green

      for(m_Ptvb=0.0; m_Ptvb<=1.0; m_Ptvb += m_Ptvbs){
  
        m_Ptvt = TwoPi * m_Ptvb;  // disk gen angle

        m_dcs = cos(m_Ptvt);  // for speed
        m_dsn = sin(m_Ptvt);
    
        // Y axis Cylinder, disk in XZ plane

        m_ObjPtX = m_dcs;  // point in 3D
        m_ObjPtZ = m_dsn;
    
        for(m_Ptva=0.0; m_Ptva<=1.0; m_Ptva += m_Ptvas){
            
          m_ObjPtY = 0.5 * m_Ptva;
            
          nDbg = 4;
            
          PerspectiveTr();  // Output in m_DeviceIx,m_DeviceIy
            
          ix = m_DeviceIx;
          iy = m_DeviceIy;
            
          nPxc++;
          nPxm++;
            
          nDisp = 1;
            
          if(ix < xl)nDisp = 0;
          if(ix > xr)nDisp = 0;
          if(iy < yt)nDisp = 0;
          if(iy > yb)nDisp = 0;
            
          if(nDisp == 1)pDC->SetPixel(ix, iy, m_crPart);
            
        }
          
      }     
        
      // Check max pixels
        
      if(nPxc > 10000000)goto exds;
        
      if(nPxm > 200000){
          
        nPxm = 0;
          
        dMpx = double(nPxc) / 1000000.0;
          
        sprintf(text,"%4.1lf Mpx  ",dMpx);
          
        nx = m_nWorkPosLeft + m_nWorkSzX / 2;
        ny = m_nWorkPosTop + 8;
          
        pDC->TextOut(nx, ny, text);
          
      }
        
      // Disk XZ at Y = 0.5

      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.5;
      m_ObjPtZ = 0.0;

      m_crPart = RGB(255, 180, 180);    // Red

      for(m_Ptvb=0.0; m_Ptvb<=1.0; m_Ptvb += m_Ptvbs){
  
        m_Ptvt = TwoPi * m_Ptvb;  // disk gen angle

        m_dcs = cos(m_Ptvt);  // for speed
        m_dsn = sin(m_Ptvt);
  
        for(m_Ptva=0.0; m_Ptva<=1.0; m_Ptva += m_Ptvas){
            
          // Disk in XZ plane

          m_ObjPtX = m_Ptva * m_dcs;  // point in 3D
          m_ObjPtZ = m_Ptva * m_dsn;
            
          nDbg = 4;
            
          PerspectiveTr();  // Output in m_DeviceIx,m_DeviceIy
            
          ix = m_DeviceIx;
          iy = m_DeviceIy;
            
          nPxc++;
          nPxm++;
            
          nDisp = 1;
            
          if(ix < xl)nDisp = 0;
          if(ix > xr)nDisp = 0;
          if(iy < yt)nDisp = 0;
          if(iy > yb)nDisp = 0;
            
          if(nDisp == 1)pDC->SetPixel(ix, iy, m_crPart);
            
        }
          
      }     
        
      // Check max pixels
        
      if(nPxc > 10000000)goto exds;
        
      if(nPxm > 200000){
          
        nPxm = 0;
          
        dMpx = double(nPxc) / 1000000.0;
          
        sprintf(text,"%4.1lf Mpx  ",dMpx);
          
        nx = m_nWorkPosLeft + m_nWorkSzX / 2;
        ny = m_nWorkPosTop + 8;
          
        pDC->TextOut(nx, ny, text);
          
      }
        

    }  // end tank visible
        
    
    // Show axes
    
    if(m_nThing[3] == 1){

      // Do X axis
      
      m_ObjPosX = 0.0;  // Perspective Thing position
      m_ObjPosY = 0.0;
      m_ObjPosZ = 0.0;
      
      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.0;
      m_ObjPtZ = 0.0;
      
      m_PartSizeMax = 12.0;
      
      InitDisplayPart(0);
      
      m_crPart = RGB(200, 200, 255);   // Blue
      
      for(m_Ptva=0.0; m_Ptva<1.0; m_Ptva += m_Ptvas){
          
        m_ObjPtX = 12.0 * m_Ptva;  // point in 3D
          
        nDbg = 4;
          
        PerspectiveTr();  // Output in m_DeviceIx,m_DeviceIy
          
        ix = m_DeviceIx;
        iy = m_DeviceIy;
          
        nPxc++;
        nPxm++;
          
        nDisp = 1;
          
        if(ix < xl)nDisp = 0;
        if(ix > xr)nDisp = 0;
        if(iy < yt)nDisp = 0;
        if(iy > yb)nDisp = 0;
          
        if(nDisp == 1)pDC->SetPixel(ix, iy, m_crPart);
          
      }
    
      // Y axis
      
      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.0;
      m_ObjPtZ = 0.0;      
      
      m_crPart = RGB(255, 216, 216);   // Red
      
      for(m_Ptva=0.0; m_Ptva<1.0; m_Ptva += m_Ptvas){
          
        m_ObjPtY = 8.0 * m_Ptva;  // point in 3D
          
        nDbg = 4;
          
        PerspectiveTr();  // Output in m_DeviceIx,m_DeviceIy
          
        ix = m_DeviceIx;
        iy = m_DeviceIy;
          
        nPxc++;
        nPxm++;
          
        nDisp = 1;
          
        if(ix < xl)nDisp = 0;
        if(ix > xr)nDisp = 0;
        if(iy < yt)nDisp = 0;
        if(iy > yb)nDisp = 0;
          
        if(nDisp == 1)pDC->SetPixel(ix, iy, m_crPart);
          
      }
    
      // Z axis
      
      m_ObjPtX = 0.0;  // point in 3D
      m_ObjPtY = 0.0;
      m_ObjPtZ = 0.0;
      
      m_crPart = RGB(200, 255, 200);  // Green
      
      for(m_Ptva=0.0; m_Ptva<1.0; m_Ptva += m_Ptvas){
          
        m_ObjPtZ = -24.0 * m_Ptva;  // point in 3D
          
        nDbg = 4;
          
        PerspectiveTr();  // Output in m_DeviceIx,m_DeviceIy
          
        ix = m_DeviceIx;
        iy = m_DeviceIy;
          
        nPxc++;
        nPxm++;
          
        nDisp = 1;
          
        if(ix < xl)nDisp = 0;
        if(ix > xr)nDisp = 0;
        if(iy < yt)nDisp = 0;
        if(iy > yb)nDisp = 0;
          
        if(nDisp == 1)pDC->SetPixel(ix, iy, m_crPart);
          
      }
        
    
    }  // end show axes
    
    // end Things display
    
    exds:
    
    dMpx = double(nPxc) / 1000000.0;
    
    sprintf(text,"%4.1lf Mpx OK",dMpx);
    
    nx = m_nWorkPosLeft + m_nWorkSzX / 2;
    ny = m_nWorkPosTop + 8;
    
    pDC->TextOut(nx, ny, text);
    
    if(m_nScrCoordDisp == 1){
      
      pDC->SetBkColor(m_crScrnDt);
      
      ny = m_nWorkPosTop + m_nWorkSzY - 24;
      
      sprintf(text,"%6.1f",m_ScreenXleft);
      nx = m_nWorkPosLeft + 64;
      pDC->TextOut(nx, ny, text);
      
      vs = (m_ScreenXleft + m_ScreenXright) / 2.0;
      
      sprintf(text,"%6.1f",vs);
      nx = m_nWorkPosLeft + m_nWorkSzX / 2;
      pDC->TextOut(nx, ny, text);
      
      sprintf(text,"%6.1f",m_ScreenXright);
      nx = m_nWorkPosLeft + m_nWorkSzX - 72;
      pDC->TextOut(nx, ny, text);
            
      nx = m_nWorkPosLeft + 4;
      
      sprintf(text,"%6.1f",m_ScreenYbot);
      ny = m_nWorkPosTop + m_nWorkSzY - 48;
      pDC->TextOut(nx, ny, text);
      
      vs = (m_ScreenYbot + m_ScreenYtop) / 2.0;
      
      sprintf(text,"%6.1f",vs);
      ny = m_nWorkPosTop + m_nWorkSzY / 2;
      pDC->TextOut(nx, ny, text);
      
      sprintf(text,"%6.1f",m_ScreenYtop);
      ny = m_nWorkPosTop + 4;
      pDC->TextOut(nx, ny, text);
      
    }
        
    nDbg = 5;
    
    
  }
  
  
  if(m_nDataSource == STDGRA && m_nDataOperation == ACTN11){
    
    // Show View Data
    
    pOldBrush = pDC->SelectObject(pWhiteBr);
    
    pDC->Rectangle(m_rcVdataRect);
    
    nx = m_rcVdataRect.left + 8;
    ny = m_rcVdataRect.top + 4;
    
    //m_ViewSet[2][0] = -1.0;  //Set Y drop   (-40.0)
    //m_ViewSet[2][1] = 500.0; //Screen gain  (100)
    //m_ViewSet[2][2] = 0.0;   //World angle  (-15)
    //m_ViewSet[2][3] = 3.0;   //Set view Z   (50.0)
    //m_ViewSet[2][4] = -3.0;  //Set Z offset (-50.0)
    //m_ViewSet[2][5] = -1.0;  //Set X offset (0.0)
    //m_ViewSet[2][6] = 0.1;   //Set X origin (0.2)
    //m_ViewSet[2][7] = 0.2;   //Set Y origin (0.2)
    
    sprintf(text," Y drop       = %7.2f", m_ScOffpPosnY);
    pDC->TextOut(nx, ny, text);
    ny += yps;
    
    sprintf(text," Screen gain  = %7.2f",m_ScreenGainX);
    pDC->TextOut(nx, ny, text);
    ny += yps;
    
    sprintf(text," World angle  = %7.2f",m_ScvDegAngle);
    pDC->TextOut(nx, ny, text);
    ny += yps;
    
    sprintf(text," Z view point = %7.2f",m_ScvViewPtZ);
    pDC->TextOut(nx, ny, text);
    ny += yps;
    
    sprintf(text," Z offset     = %7.2f", m_ScOffpPosnZ);
    pDC->TextOut(nx, ny, text);
    ny += yps;
    
    sprintf(text," X offset     = %7.2f", m_ScOffpPosnX);
    
    pDC->TextOut(nx, ny, text);
    ny += yps;
    
    sprintf(text," X origin     = %7.2f",m_NormWoX);
    pDC->TextOut(nx, ny, text);
    ny += yps;
    
    sprintf(text," Y origin     = %7.2f",m_NormWoY);
    pDC->TextOut(nx, ny, text);
    ny += yps;
    
  }
  
  if(m_nDataSource == STDGRA && m_nDataOperation == ACTN12){
    
    // Show Transform Data
    
    pOldBrush = pDC->SelectObject(pWhiteBr);
    
    pDC->Rectangle(m_rcTdataRect);
    
    m_ObjPosX = 0.0;
    m_ObjPosY = 0.0;
    m_ObjPosZ = 0.0;
    
    m_ObjPtX = 1.0;  // Test point coords
    m_ObjPtY = 1.0;
    m_ObjPtZ = -1.0;
    
    m_ScDbgValue = 3;
    
    PerspectiveTr();  // transform the point
    
    m_ScDbgValue = 0;
    
    nx = m_rcTdataRect.left + 16;
    ny = m_rcTdataRect.top + 4;
    
    sprintf(text,"Test point X=1  Y=1  Z=-1");
    
    pDC->TextOut(nx, ny, text);
        
    nx = m_rcTdataRect.left + 60;
    ny = m_rcTdataRect.top + 32;
    
    for(i=0; i<4; i++){
      
      vs = m_ScnObjCoords[i];
      
      if(i == 0)sprintf(text,"[%5.1f", vs);
      if(i > 0 && i < 3)sprintf(text,"%5.1f", vs);
      if(i == 3)sprintf(text,"%5.1f]", vs);
      
      pDC->TextOut(nx, ny, text);
      
      nx += 88;
      
    }
    
    for(i=0; i<4; i++){
      
      nx = m_rcTdataRect.left + 392;
      
      for(j=0; j<4; j++){
        
        vs = m_ScPerspective[i][j];
        
        sprintf(text,"%6.2f", vs);
        
        pDC->TextOut(nx, ny, text);
        
        nx += 64;
                
      }
      ny += yps;
    }
    
    nx = m_rcTdataRect.left + 50;
    ny += yps;
    
    for(i=0; i<4; i++){
      
      vs = m_rpc[i];
      
      if(i == 0)sprintf(text,"=[%5.1f", vs);
      if(i > 0 && i < 3)sprintf(text,"%5.1f", vs);
      if(i == 3)sprintf(text,"%6.2f]", vs);
      
      pDC->TextOut(nx, ny, text);
      
      nx += 88;
      
    }
    
    sprintf(text,"Screen S= %8.3f  Screen T= %8.3f",m_ScreenS, m_ScreenT);
    
    nx = m_rcTdataRect.left + 16;
    ny += yps;
    ny += yps;
    
    pDC->TextOut(nx, ny, text);
        
  }
  
  
  if(m_nDataSource == STDTXT){
    
    // Std text listing
    
    // m_nDataOperation has op (Btn)
    
    m_crWorkTxtBk = m_crWhite;
    
    if(m_nBoxColour == 1){
      
      m_crWorkTxtBk = m_crDarkGray;
      
    }
    
    pDC->SetBkColor(m_crWorkTxtBk);
    
    sprintf(text,"Lines: %4d", pDoc->m_nCtLines);
    
    pDC->TextOut(xtxt, ytxt, text);
    ytxt += yps;
    
    //           11111111112222222222333333333344444444445555555555666666666
    // 012345678901234567890123456789012345678901234567890123456789012345678
    
    if(m_nDbgState == 1){
      
      pDC->TextOut(xtxt, ytxt, "          1111111111222222222233333333334444444444555555555566666666667");
      ytxt += yps;
      
      pDC->TextOut(xtxt, ytxt, "01234567890123456789012345678901234567890123456789012345678901234567890");
      ytxt += yps;
      
    }
    
    // Show text buffer
    
    if(m_nTextDisplay == 1 && m_nTextAvail == 1 && pDoc->m_nCtLines > 0){
      
      ks = pDoc->m_nLineStart;
      ke = ks + 27;
      
      for(i=ks; i<ke; i++){
        
        j = i - ks;
        
        csA = pDoc->GetString(i);
        
        csB = csA.Mid(m_nDataStart, 73);
        
        pDC->TextOut(xtxt, ytxt, csB);
        ytxt += yps;
        
        pDC->SetBkColor(m_crWorkTxtBk);
        
      }
      
    }
    
  }
  
  // Data input mode, Initial Values
  
  nDbg = 3;
  
  if(m_nDataMode > 0){
    
    // Draw data input boxes
    
    pOldBrush = pDC->SelectObject(pWhiteBr);
    
    pDC->SetTextColor(RGB(0, 0, 0));
    
    pDC->SetBkColor(RGB(255, 255, 255));
    
    pDC->Rectangle(m_rcDataSel[m_nDataInSel]);
    
    nx = m_rcDataSel[m_nDataInSel].left + 16;
    ny = m_rcDataSel[m_nDataInSel].top + 8;
    
    pDC->TextOut(nx,ny,m_cDataPrompt[m_nDataInSel]);
    
    //nx += 280;
    
    nx += 12 * strlen(m_cDataPrompt[m_nDataInSel]);
    
    pDC->TextOut(nx,ny,m_cDataTxt[m_nDataInSel]);
    
    pDC->SetBkColor(RGB(255, 255, 255));
    
    pDC->SelectObject(pOldBrush);
    
  }

  //m_nAccept = 7;  // Disable for release (7 = no message, debug)
  
  if(m_nAccept == 0){
    
    i = AfxMessageBox(m_sAccept,MB_YESNO);
    
    if(i != IDYES){
      m_nAccept = 9;
      PostQuitMessage(0);
    }
    else{
      m_nAccept = 8;
    }
    
  }  

  m_nMouseInt = 0;            // Mouse internal
  
  nDbg = 4;
  
}


/////////////////////////////////////////////////////////////////////////////
// CScenView printing

BOOL CScenView::OnPreparePrinting(CPrintInfo* pInfo)
{
  // default preparation
  return DoPreparePrinting(pInfo);
}

void CScenView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
  // TODO: add extra initialization before printing
}

void CScenView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
  // TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CScenView diagnostics

#ifdef _DEBUG
void CScenView::AssertValid() const
{
  CView::AssertValid();
}

void CScenView::Dump(CDumpContext& dc) const
{
  CView::Dump(dc);
}

CScenDoc* CScenView::GetDocument() // non-debug version is inline
{
  ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CScenDoc)));
  return (CScenDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScenView message handlers

void CScenView::OnLButtonDown(UINT nFlags, CPoint point)
{
  
  CScenDoc* pDoc = GetDocument();
  ASSERT_VALID(pDoc);
  
  int i,j,k,kLine,nSel,nSelHold;
  int nTotal,nFree;
  int nScid;
  int nDbg;
  
  DWORD dwTotal, dwFree;
  double dTotal, dFree, vs;
    
  MEMORYSTATUS MemStat;
  
  char text[84];
  char buffer[_MAX_PATH];
  
  CString csA;
  
  dwTotal = 0;
  dwFree = 0;
  
  nDbg = 0;
  
  nSel = 0;
  nScid = 0;
  
  i = 0;
  j = 0;
  k = 0;
  
  nSelHold = m_nSelBase;
  
  text[0] = 0;
  
  m_nInitText = 1;  // any click - end of init text mode
  
  // Ignore left clicks in value box
  
  if(m_nInValueBox == 1)return;
  
  // Test click in Work-box
  
  if(m_rcWorkRectDet.PtInRect(point) != 0){
    
    // Select line, click left in text box
    
    m_nMouseInt = 1;            // Mouse internal
    
    m_nDataSource = STDGRA;     // graphics
    
    m_nDataOperation = ACTN01;
    
    m_nBoxColour = 1;
    
    m_nCursorX = point.x;
    m_nCursorY = point.y;
    
    m_nCursorScrnX = m_nCursorX;
    m_nCursorScrnY = m_nCursorY;
    
    m_nCursorDataX = m_nCursorX + m_nFxo - m_nWorkPosLeft;
    
    m_nCursorDataY = m_nCursorY + m_nFyo - m_nWorkPosTop;
    
    m_nDataPt = 0;
    
    m_nTextLine = 0;
    m_nTextLineDoc = 0;
    
    if(m_nCursorDataX >= 0 && m_nCursorDataY >= 0){
      
      m_nDataPt = 1;
      
      kLine = (m_nCursorDataY - 8) / 20;
      
      if(kLine > 0 && m_nTextAvail == 1){
        
        m_nTextLine = kLine;
        m_nTextLineDoc = kLine + pDoc->m_nLineStart;
        
      }
      
    }
    
    
  }
  
  
  for(i=0; i<m_Selr; i++){
    
    if(m_rcSel[i].PtInRect(point) && m_nBtnDisplay[i] == 1)nSel = i+1;
    
  }
  
  if(nSel == 0)goto exlb;
  
  m_nMouseInt = 1;            // Mouse internal
  
  nSel += m_nSelBase;
  
  // Action list here; code for action Btn left down ..............
  
  // Show Scene         1 Scene ACTN01
  // Set Y drop         2 ACTN01
  // Set Screen Gain    3
  // Set World  angle   4
  // Set view Z         5
  // Set Z offset       6
  // Set X offset       7
  // Set screen X left  8
  // Set screen Y base  9
  // Show scrn coords   10  ACTN10
  // Show view data     11
  // Show transform     12
  
  
  if(nSel == ACTN01){
    
    // ACTN01 Action 1 Show Scene
    
    // No clear text buff
    
    //m_nDataSource = STDTXT;     // Std text listing in OnDraw
    
    m_nDataSource = STDGRA;     // Std graphics in OnDraw
    
    m_nDataOperation = ACTN01;
    
    // Append
    
    // m_nTextLine = 0;
    
    // pDoc->m_nLineStart = 0;
    
    // pDoc->FtReset();
    
    m_nTextAvail = 1;
    
    // Code for Action
    
    pDoc->PutTex("  Scene");
    
    m_nBoxColour = 1;
    
    if(m_nSceneID == 0){
      
      SetScene(m_nWorkPosLeft, m_nWorkPosTop, m_nWorkSzX, m_nWorkSzY);
      
      SetDataTxt();   // Prompt values
      
    }
    
  }
  
  nScid = m_nSceneID;
  
  if(nSel == ACTN02 && nScid != 0){
    
    // ACTN02 Action 2 Input  View Y drop
    
    // No clear text buff
    
    //m_nDataSource = STDTXT;     // Std text listing in OnDraw
    
    m_nDataSource = STDGRA;     // Stay in Graphics mode
    
    m_nDataOperation = ACTN02;
    
    // Append
    // m_nTextLine = 0;
    // pDoc->m_nLineStart = 0;
    // pDoc->FtReset();
    
    m_nTextAvail = 1;
    
    //pDoc->PutTex("  Action 2");
    
    //pDoc->PutTex("  Y drop");
    
    m_nDataMode = 1;  // 1 numeric
    
    m_nInValueBox = 1;
    
    m_nDataInSel = 1;  // InputA
    
  }
  
  if(nSel == ACTN03 && nScid != 0){
    
    // ACTN03 Action 3 Input Screen Gain
    
    //m_nDataSource = STDTXT;     // Std text listing in OnDraw
    
    m_nDataSource = STDGRA;     // Stay in Graphics mode
    
    m_nDataOperation = ACTN03;
    
    // Append
        
    m_nTextAvail = 1;
        
    m_nDataMode = 1;
    
    m_nInValueBox = 1;
    
    m_nDataInSel = 2;  // InputB
    
  }
  
  
  
  if(nSel == ACTN04 && nScid != 0){
    
    // ACTN04 Action 4 set Screen angle
    
    m_nDataSource = STDGRA;
    
    m_nDataOperation = ACTN04;
    
    // Append
        
    m_nTextAvail = 1;
        
    m_nDataMode = 1;
    
    m_nInValueBox = 1;
    
    m_nDataInSel = 3;  // Screen angle
    
    
  }
  
  if(nSel == ACTN05 && nScid != 0){
    
    // ACTN05 Action 5 Set view Z
    
    m_nDataSource = STDGRA;     // graphics
    
    m_nDataOperation = ACTN05;
    
    // Append
    
    m_nTextAvail = 1;
        
    m_nDataMode = 1;  // 1 numeric
    
    m_nInValueBox = 1;
    
    m_nDataInSel = 4;  //
    
  }
  
  if(nSel == ACTN06 && nScid != 0){
    
    // ACTN06 Action 6 Set Z offset
    
    m_nDataSource = STDGRA;
    
    m_nDataOperation = ACTN06;
    
    // Append
    
    m_nTextAvail = 1;
        
    m_nDataMode = 1;  // 1 numeric
    
    m_nInValueBox = 1;
    
    m_nDataInSel = 5;  //
    
  }
  
  if(nSel == ACTN07 && nScid != 0){
    
    // ACTN07 Action 7 Set X offset
    
    m_nDataSource = STDGRA;
    
    m_nDataOperation = ACTN07;
    
    // Append
    
    m_nTextAvail = 1;
        
    m_nDataMode = 1;  // 1 numeric
    
    m_nInValueBox = 1;
    
    m_nDataInSel = 6;  //
    
  }
  
  if(nSel == ACTN08 && nScid != 0){
    
    // ACTN08 Action 8 Set screen X origin
    
    //m_NormWoX = 0.2;
    //m_NormWoY = 0.2;
    
    m_nDataSource = STDGRA;     // Std graphics in OnDraw
    
    m_nDataOperation = ACTN08;
    
    // Append
    
    m_nTextAvail = 1;
        
    m_nDataMode = 1;  // 1 numeric
    
    m_nInValueBox = 1;
    
    m_nDataInSel = 7;  //
    
    
  }
  
  if(nSel == ACTN09 && nScid != 0){
    
    // ACTN09 Action 9 Set screen Y origin
    
    m_nDataSource = STDGRA;
    
    m_nDataOperation = ACTN09;
    
    // Append
    
    m_nTextAvail = 1;
        
    m_nDataMode = 1;  // 1 numeric
    
    m_nInValueBox = 1;
    
    m_nDataInSel = 8;  //
    
  }
  
  if(nSel == ACTN10 && nScid != 0){
    
    // ACTN10 Action 10 Show scene coords
    
    //m_nDataSource = STDTXT;     // Std text listing in OnDraw
    
    m_nDataSource = STDGRA;     // Std graphics in OnDraw
    
    m_nDataOperation = ACTN01;
    
    if(m_nScrCoordDisp == 0){
      
      m_nScrCoordDisp = 1;
      
    }
    else{
      
      m_nScrCoordDisp = 0;
      
    }
    
    //Invalidate(FALSE);
    
    //goto exlc;
    
  }
  
  if(nSel == ACTN11 && nScid != 0){
    
    // ACTN11 Action 11 Show view data
    
    m_nDataSource = STDGRA;     // graphics
    
    m_nDataOperation = ACTN11;
    
    InvalidateRect(m_rcInvSel, FALSE);
    
    InvalidateRect(m_rcVdataRect, FALSE);
    
    return;
    
    
  }
  
  if(nSel == ACTN12 && nScid != 0){
    
    // ACTN12 Action 12 Show transform matrix
    
    m_nDataSource = STDGRA;     // graphics
    
    m_nDataOperation = ACTN12;
    
    InvalidateRect(m_rcInvSel, FALSE);
    
    InvalidateRect(m_rcTdataRect, FALSE);
    
    return;
    
  }
  
  if(nSel == ACTN13 && nScid != 0){
    
    // ACTN13 View set A
    
    m_nDataSource = STDGRA;     // graphics
        
    m_nDataOperation = ACTN01;
    
    m_nBoxColour = 1;
    
    m_ScvYdrop = m_ViewSet[0][0];  //Set Y drop   (-40.0)
    m_ScreenGainX = m_ViewSet[0][1]; //Screen gain  (100)
    m_ScreenGainY = m_ViewSet[0][1]; //Screen gain  (100)
    m_ScvDegAngle = m_ViewSet[0][2];   //World angle  (-15)
    m_ScvViewPtZ = m_ViewSet[0][3];  //Set view Z   (50.0)
    m_ScvZoffset = m_ViewSet[0][4]; //Set Z offset (-50.0
    m_ScvXoffset = m_ViewSet[0][5];  //Set X offset (0.0)
    m_NormWoX = m_ViewSet[0][6];   //Set X origin (0.2)
    m_NormWoY = m_ViewSet[0][7];   //Set Y origin (0.2)
    
    SetAllVisible();  // Make all objects visible
    
    SetDataTxt();   // Prompt values
        
  }
  
  if(nSel == ACTN14 && nScid != 0){
    
    // ACTN14 View set B
    
    m_nDataSource = STDGRA;     // graphics
    
    m_nDataOperation = ACTN01;
    
    m_nBoxColour = 1;
    
    m_ScvYdrop = m_ViewSet[1][0];  //Set Y drop   (-40.0)
    m_ScreenGainX = m_ViewSet[1][1]; //Screen gain  (100)
    m_ScreenGainY = m_ViewSet[1][1]; //Screen gain  (100)
    m_ScvDegAngle = m_ViewSet[1][2];   //World angle  (-15)
    m_ScvViewPtZ = m_ViewSet[1][3];  //Set view Z   (50.0)
    m_ScvZoffset = m_ViewSet[1][4]; //Set Z offset (-50.0
    m_ScvXoffset = m_ViewSet[1][5];  //Set X offset (0.0)
    m_NormWoX = m_ViewSet[1][6];   //Set X origin (0.2)
    m_NormWoY = m_ViewSet[1][7];   //Set Y origin (0.2)
    
    SetAllVisible();  // Make all objects visible
    
    SetDataTxt();   // Prompt values
    
  }
  
  if(nSel == ACTN15 && nScid != 0){
    
    // ACTN15 View set C
    
    m_nDataSource = STDGRA;     // graphics
    
    m_nDataOperation = ACTN01;
    
    m_nBoxColour = 1;
    
    m_ScvYdrop = m_ViewSet[2][0];  //Set Y drop   (-40.0)
    m_ScreenGainX = m_ViewSet[2][1]; //Screen gain  (100)
    m_ScreenGainY = m_ViewSet[2][1]; //Screen gain  (100)
    m_ScvDegAngle = m_ViewSet[2][2];   //World angle  (-15)
    m_ScvViewPtZ = m_ViewSet[2][3];  //Set view Z   (50.0)
    m_ScvZoffset = m_ViewSet[2][4]; //Set Z offset (-50.0
    m_ScvXoffset = m_ViewSet[2][5];  //Set X offset (0.0)
    m_NormWoX = m_ViewSet[2][6];   //Set X origin (0.2)
    m_NormWoY = m_ViewSet[2][7];   //Set Y origin (0.2)
    
    SetAllVisible();  // Make all objects visible
    
    SetDataTxt();   // Prompt values
    
  }
  
  if(nSel == ACTN16 && nScid != 0){
    
    // ACTN16 View set D
    
    m_nDataSource = STDGRA;     // graphics
    
    m_nDataOperation = ACTN01;
    
    m_nBoxColour = 1;
    
    m_ScvYdrop = m_ViewSet[3][0];  //Set Y drop   (-40.0)
    m_ScreenGainX = m_ViewSet[3][1]; //Screen gain  (100)
    m_ScreenGainY = m_ViewSet[3][1]; //Screen gain  (100)
    m_ScvDegAngle = m_ViewSet[3][2];   //World angle  (-15)
    m_ScvViewPtZ = m_ViewSet[3][3];  //Set view Z   (50.0)
    m_ScvZoffset = m_ViewSet[3][4]; //Set Z offset (-50.0
    m_ScvXoffset = m_ViewSet[3][5];  //Set X offset (0.0)
    m_NormWoX = m_ViewSet[3][6];   //Set X origin (0.2)
    m_NormWoY = m_ViewSet[3][7];   //Set Y origin (0.2)
    
    SetAllVisible();  // Make all objects visible
    
    SetDataTxt();   // Prompt values
    
  }
  
  if(nSel == ACTN17 && nScid != 0){
    
    // ACTN17 View set E
    
    m_nDataSource = STDGRA;     // graphics
    
    m_nDataOperation = ACTN01;
    
    m_nBoxColour = 1;
    
    m_ScvYdrop = m_ViewSet[4][0];  //Set Y drop   (-40.0)
    m_ScreenGainX = m_ViewSet[4][1]; //Screen gain  (100)
    m_ScreenGainY = m_ViewSet[4][1]; //Screen gain  (100)
    m_ScvDegAngle = m_ViewSet[4][2];   //World angle  (-15)
    m_ScvViewPtZ = m_ViewSet[4][3];  //Set view Z   (50.0)
    m_ScvZoffset = m_ViewSet[4][4]; //Set Z offset (-50.0
    m_ScvXoffset = m_ViewSet[4][5];  //Set X offset (0.0)
    m_NormWoX = m_ViewSet[4][6];   //Set X origin (0.2)
    m_NormWoY = m_ViewSet[4][7];   //Set Y origin (0.2)
    
    SetAllVisible();  // Make all objects visible
    
    m_nThing[1] = 0;  // Make box invisible
    
    m_nThing[2] = 0;  // Make puck invisible
    
    SetDataTxt();   // Prompt values
    
  }
  
  if(nSel == NEXTSB){
    
    // Btn set 0 -> 1
    
    nSelHold = 19;
    
    m_nSelBase = nSelHold;
    
    m_nDataOperation = NEXTSB;
    
    InvalidateRect(m_rcInvSel, TRUE);
    
    return;
    
  }
  
  
  // More Actions...........
  
  
  if(nSel == ACTN20 && nScid != 0){
    
    //  Axes on/off
    
    if(m_nThing[3] == 0){
      m_nThing[3] = 1;
    }
    else{
      m_nThing[3] = 0;
    }
    
    m_nDataOperation = ACTN20;
    
    InvalidateRect(m_rcInvSel, FALSE);
    
    return;
    
  }
  
  if(nSel == ACTN21 && nScid != 0){
    
    //  Grid on/off
    
    if(m_nThing[0] == 0){
      m_nThing[0] = 1;
    }
    else{
      m_nThing[0] = 0;
    }
    
    m_nDataOperation = ACTN21;
    
    InvalidateRect(m_rcInvSel, FALSE);
    
    return;
    
  }
  
  if(nSel == ACTN22 && nScid != 0){
    
    //  Box on/off
    
    if(m_nThing[1] == 0){
      m_nThing[1] = 1;
    }
    else{
      m_nThing[1] = 0;
    }
    
    m_nDataOperation = ACTN22;
    
    InvalidateRect(m_rcInvSel, FALSE);
    
    return;
    
  }
  
  if(nSel == ACTN23 && nScid != 0){
    
    //  Tank on/off
    
    if(m_nThing[2] == 0){
      m_nThing[2] = 1;
    }
    else{
      m_nThing[2] = 0;
    }
    
    m_nDataOperation = ACTN23;
    
    InvalidateRect(m_rcInvSel, FALSE);
    
    return;
    
  }
  
  if(nSel == ACTN24){
    
    // Fast render on/off
    
    if(m_ScFastRender == 0){
      m_ScFastRender = 1;
    }
    else{
      m_ScFastRender = 0;
    }
    
    m_nDataOperation = ACTN24;
    
    InvalidateRect(m_rcInvSel, FALSE);
    
    return;
    
  }
  
  if(nSel == SYSINF){
    
    // DATA log (Sys Info) 31
    // Get Memory usage
    
    m_nDataSource = STDTXT;
    m_nDataOperation = SYSINF;
    
    // Append to text buff
        
    m_nTextAvail = 1;
            
    pDoc->PutTex("Current view:");
    pDoc->PutTex(" ");
    
    sprintf(text," Y drop       = %7.2f", m_ScOffpPosnY);
    pDoc->PutTex(text);
    
    sprintf(text," Screen gain  = %7.2f",m_ScreenGainX);
    pDoc->PutTex(text);
    
    sprintf(text," World angle  = %7.2f",m_ScvDegAngle);
    pDoc->PutTex(text);
    
    sprintf(text," Z view point = %7.2f",m_ScvViewPtZ);
    pDoc->PutTex(text);
    
    sprintf(text," Z offset     = %7.2f", m_ScOffpPosnZ);
    pDoc->PutTex(text);
    
    sprintf(text," X offset     = %7.2f", m_ScOffpPosnX);
    pDoc->PutTex(text);
    
    sprintf(text," X origin     = %7.2f",m_NormWoX);
    pDoc->PutTex(text);
    
    sprintf(text," Y origin     = %7.2f",m_NormWoY);
    pDoc->PutTex(text);
    
    pDoc->PutTex(" ");
    
    sprintf(text," World origin      S %8.3f  T %8.3f",m_WorgSx,m_WorgTy);
    pDoc->PutTex(text);
    
    sprintf(text," World origin device x %d    y %d",m_WorgIx,m_WorgIy);
    pDoc->PutTex(text);
    
    pDoc->PutTex(" ");
    
    // Screen co-ords left
    
    sprintf(text," Screen x left   %8.3f  right  %8.3f",m_ScreenXleft,m_ScreenXright);
    pDoc->PutTex(text);
    
    sprintf(text," Screen y bottom %8.3f  top  %8.3f",m_ScreenYbot,m_ScreenYtop);
    pDoc->PutTex(text);
    pDoc->PutTex(" ");
    
    // Test point tpnt
    
    //double m_ObjPosX;  // Perspective Thing position
    //double m_ObjPosY;
    //double m_ObjPosZ;
    
    //double m_ObjPtX;  // Perspective input 3D point
    //double m_ObjPtY;
    //double m_ObjPtZ;
    
    //double m_ScreenS;  // Perspective output
    //double m_ScreenT;
    
    //int m_DeviceIx;  // Screen point
    //int m_DeviceIy;
    
    m_ObjPosX = 0.0;
    m_ObjPosY = 0.0;
    m_ObjPosZ = 0.0;
    
    //m_ObjPtX = 3.0;  // Test point coords
    //m_ObjPtY = 4.0;
    //m_ObjPtZ = -6.0;
    
    m_ObjPtX = 0.0;  // Test point coords
    m_ObjPtY = 0.0;
    m_ObjPtZ = 0.0;
    
    m_ScDbgValue = 2;
    
    PerspectiveTr();  // transform the point
    
    m_ScDbgValue = 0;
    
    sprintf(text," Test point X %8.3f  Y %8.3f  Z %8.3f",m_ObjPtX, m_ObjPtY, m_ObjPtZ);
    pDoc->PutTex(text);
    pDoc->PutTex(" ");
    
    sprintf(text," Screen S %8.3f     T %8.3f",m_ScreenS, m_ScreenT);
    pDoc->PutTex(text);
    
    sprintf(text," Device x   %d        y %d",m_DeviceIx, m_DeviceIy);
    pDoc->PutTex(text);
    pDoc->PutTex(" ");
    
    m_ObjPtX = 1.0;  // Test point coords
    m_ObjPtY = 1.0;
    m_ObjPtZ = -1.0;
    
    PerspectiveTr();  // transform the point
    
    sprintf(text," Test point X %8.3f  Y %8.3f  Z %8.3f",m_ObjPtX, m_ObjPtY, m_ObjPtZ);
    pDoc->PutTex(text);
    pDoc->PutTex(" ");
    
    csA.Empty();
    
    for(i=0; i<4; i++){
      
      vs = m_ScnObjCoords[i];
      
      if(i == 0)sprintf(text,"[%6.1f", vs);
      if(i > 0 && i < 3)sprintf(text,"%6.1f", vs);
      if(i == 3)sprintf(text,"%6.1f] *", vs);
      
      csA += text;
      
    }
    
    pDoc->PutString(csA);
    pDoc->PutTex(" ");
    
    for(i=0; i<4; i++){
      
      csA.Empty();
      
      for(j=0; j<4; j++){
        
        vs = m_ScPerspective[i][j];
        
        sprintf(text,"%6.2f", vs);
        
        csA += text;
        
        //m_ScnObjCoords[j] = 0.0;    // Object coords
        
      }
      
      pDoc->PutString(csA);
      
    }
    
    pDoc->PutTex(" ");
    
    csA.Empty();
    
    for(i=0; i<4; i++){
      
      vs = m_rpc[i];
      
      if(i == 0)sprintf(text,"=[%6.1f", vs);
      if(i > 0 && i < 3)sprintf(text,"%6.1f", vs);
      if(i == 3)sprintf(text,"%6.2f]", vs);
      
      csA += text;
      
    }
    
    pDoc->PutString(csA);
    pDoc->PutTex(" ");
    
    sprintf(text," Screen S %8.3f     T %8.3f",m_ScreenS, m_ScreenT);
    pDoc->PutTex(text);
    
    sprintf(text," Device x   %d        y %d",m_DeviceIx, m_DeviceIy);
    pDoc->PutTex(text);
    pDoc->PutTex(" ");
    pDoc->PutTex(" ");

    ::GlobalMemoryStatus(&MemStat);
    
    dwTotal = MemStat.dwTotalPhys;
    dwFree = MemStat.dwAvailPhys;
    
    nTotal = int(dwTotal);
    nFree = int(dwFree);
    
    // 64,000,000
    
    pDoc->PutTex("      Scen V1.53");
    pDoc->PutTex(" ");
    pDoc->PutTex("Data log:");
    pDoc->PutTex(" ");
    
    sprintf(text,"Memory: Total = %9d      Free = %9d", nTotal, nFree);
    
    pDoc->PutTex(text);
    
    dTotal = double(dwTotal)/1000000.0;
    dFree = double(dwFree)/1000000.0;
    
    sprintf(text,"              = %5.2f Mb            = %5.2f Mb", dTotal, dFree);
    
    pDoc->PutTex(text);
    pDoc->PutTex(" ");
        
    // Get the current working directory:
    
    pDoc->PutTex("Current directory:");
    
    if(_getcwd(buffer, _MAX_PATH) == NULL ){
      
      
      pDoc->PutTex("_getcwd error");
      
    }
    else{
      
      
      pDoc->PutTex(buffer);
      
      
    }
    pDoc->PutTex(" ");
        
    sprintf(text," Client rect X= %d   Y= %d",m_nClientX, m_nClientY);
    pDoc->PutTex(text);
    pDoc->PutTex(" ");
        
  }
  
  if(nSel == TOPPAG){
    
    // Top page
    
    pDoc->m_nLineStart = 0;
    
  }
  
  if(nSel == NEXPAG){
    
    // Text Next page
    
    pDoc->m_nLineStart += 27;
    
    if(pDoc->m_nLineStart > pDoc->m_nCtLines - 27){
      pDoc->m_nLineStart = pDoc->m_nCtLines - 27;
    }
    
  }
  
  if(nSel == PREPAG){
    
    // Text Previous page
    
    pDoc->m_nLineStart -= 27;
    
    if(pDoc->m_nLineStart < 0){
      pDoc->m_nLineStart = 0;
    }
    
  }
  
  if(nSel == LASPAG){
    
    // Text Last page
    
    pDoc->m_nLineStart = pDoc->m_nCtLines - 27;
    
    if(pDoc->m_nLineStart < 0){
      pDoc->m_nLineStart = 0;
    }
    
  }
  
  if(nSel == TXLEFT){
    
    // Left
    
    if(m_nDataStart == 0){
      
      m_nDataStart = 43;
      
    }
    
  }
  
  if(nSel == TXRIGH){
    
    // Right
    
    if(m_nDataStart == 43){
      
      m_nDataStart = 0;
      
    }
    
  }
  
  if(nSel == BACKST){
    
    // Btn set 1 -> 0
    
    nSelHold = 0;
    
    m_nSelBase = nSelHold;
    
    m_nDataOperation = NEXTSB;
    
    InvalidateRect(m_rcInvSel, TRUE);
    
    return;
    
  }
  
  
  
  if(nSel == APEXIT){
    
    // Exit
    
    m_nDataSource = nSel;
    m_nDataOperation = APEXIT;
    
    PostQuitMessage(0);
    
  }
  
  exlb:
  
  m_nSelBase = nSelHold;

  // Test for data input Actions
  
  if(nSel >= ACTN02 && nSel <= ACTN09){
    
    InvalidateRect(m_rcInvSel, FALSE);
    
    InvalidateRect(m_rcDataSel[m_nDataInSel], FALSE);  // no erase
    
  }
  else{
    
    Invalidate();
    
  }
  
  //exlc:
  
  return;
  
  
}

int CScenView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
  if (CView::OnCreate(lpCreateStruct) == -1)
  return -1;
    
  // This Fn generated by WM_CREATE message handler
  // for View class
  
  // original -
  // ASSERT(m_pFont->CreateFont(8, 0, 0, 0, 400, FALSE, FALSE, 0,
  //                           ANSI_CHARSET, OUT_DEFAULT_PRECIS,
  //                           CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
  //                           DEFAULT_PITCH | FF_SWISS, "Roman"));
  // or "Arial"
  
  int nFontSize;
  
  nFontSize = 18;
  
  // Text font
  
  m_pTextFont->CreateFont(-nFontSize, 0, 0, 0, 400, FALSE, FALSE, 0,
  ANSI_CHARSET, OUT_TT_PRECIS,
  CLIP_DEFAULT_PRECIS, DRAFT_QUALITY,
  VARIABLE_PITCH | FF_SWISS, "Arial");
  
  // Fixed font
  
  m_pFixedFont->CreateFont(-nFontSize, 0, 0, 0, 800, FALSE, FALSE, 0,
  ANSI_CHARSET, OUT_TT_PRECIS,
  CLIP_DEFAULT_PRECIS, DRAFT_QUALITY,
  FIXED_PITCH | FF_MODERN, "Courier New");
  
  // Big font
  
  nFontSize = 36;
  
  m_pBigFont->CreateFont(-nFontSize, 0, 0, 0, 400, FALSE, FALSE, 0,
  ANSI_CHARSET, OUT_TT_PRECIS,
  CLIP_DEFAULT_PRECIS, DRAFT_QUALITY,
  VARIABLE_PITCH | FF_SWISS, "Arial");
  
  SetFont(m_pFixedFont);
  
  return 0;
  
}

void CScenView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{  
  // Data input
  
  CScenDoc* pDoc = GetDocument();
  ASSERT_VALID(pDoc);
  
  int kInp,nLen,nCp;
  UINT nLwr,nHgr;
  double dInp;
  int nDbg;
  
  char text[4];
  
  nDbg = 0;
  
  if(m_nDataMode == 0)goto exla;
  
  if(m_nInValueBox == 0)goto exla;
  
  text[0] = 0;
  
  kInp = 0;
  dInp = 0.0;
  
  // ACTN02 - ACTN08
  
  // Show Scene         1 Scene ACTN01
  // Set Y drop         2 ACTN02
  // Set Screen Gain    3
  // Set World  angle   4
  // Set view Z         5
  // Set Z offset       6
  // Set screen X origin  7
  // Set screen Y origin  8
  // Show scrn coords   9  ACTN09
  // Show view data     10
  // Show transform     11
  
  // m_ScvYdrop;   // View Y drop
  // m_ScvDegAngle;
  // m_ScvViewPtZ;
  // m_ScvZoffset; // View Z offset
  // m_ScreenYtBase;
  // m_ScreenXlBase;
  
  if(m_nDataInSel > -1 && m_nDataInSel < ACTN09){
    
    // Valid data box selected here
    
    // Test for backspace
    
    if(nChar == '\b'){
      
      nLen = strlen(m_cDataTxt[m_nDataInSel]);
      
      if(nLen >= 2){
        
        nCp = nLen - 2;
        
        m_cDataTxt[m_nDataInSel][nCp] = '_';
        
        m_cDataTxt[m_nDataInSel][nCp+1] = 0;   // term
        
        strcpy(m_cText, m_cDataTxt[m_nDataInSel]);
        
        nDbg = 1;
        
      }
      
      InvalidateRect(m_rcDataSel[m_nDataInSel], FALSE);  // no erase
      
    }
    
    nLwr = '0';
    nHgr = '9';
    
    if((nChar >= nLwr && nChar <= nHgr) || nChar == '.' || nChar == '-'){
      
      nLen = strlen(m_cDataTxt[m_nDataInSel]);
      
      if(nLen >= 1 && nLen < 14){
        
        nCp = nLen - 1;
        
        m_cDataTxt[m_nDataInSel][nCp] = nChar;
        
        m_cDataTxt[m_nDataInSel][nCp+1] = '_';
        
        m_cDataTxt[m_nDataInSel][nCp+2] = 0;   // term
        
        strcpy(m_cText, m_cDataTxt[m_nDataInSel]);
        
        nDbg = 1;
        
      }
      
      InvalidateRect(m_rcDataSel[m_nDataInSel], FALSE);  // no erase
      
    }
    
    if(nChar == '\r'){
      
      nLen = strlen(m_cDataTxt[m_nDataInSel]);
      
      if(nLen > 0){
        
        strcpy(m_cText, m_cDataTxt[m_nDataInSel]);
        
        // m_nDataMode = 1 numeric
        
        if(m_nDataMode == 1){
          
          sscanf(m_cText, "%lf", &dInp);
          
          if(dInp >= -1000.0){
            
            if(m_nDataInSel == 1){
              
              //m_nInputA = kInp;  // 1 =  A
              
              // Set Ydrop ACTN02
              
              //m_ScOffpPosnY = m_ScvYdrop;   // -40.0 View Y drop
              //m_ScOffpPosnZ = m_ScvZoffset; // -50.0 View Z offset
              
              m_ScvYdrop = dInp;
              
              m_nDataSource = STDGRA;
              m_nDataOperation = ACTN01;   // Force redraw, Show Scene
              
              m_nMouseInt = 1;            // Mouse internal
              
            }
            
            if(m_nDataInSel == 2){
              
              //m_nInputB = kInp;  // 2 = B ACTN03
              
              m_ScreenGainX = dInp;
              m_ScreenGainY = dInp;
              
              m_nDataSource = STDGRA;
              m_nDataOperation = ACTN01;   // Force redraw
              
              m_nMouseInt = 1;            // Mouse internal
              
            }
            
            if(m_nDataInSel == 3){
              
              // Set screen angle  ACTN04
              
              m_ScvDegAngle = dInp;
              
              m_nDataSource = STDGRA;
              m_nDataOperation = ACTN01;   // Force redraw
              
              m_nMouseInt = 1;            // Mouse internal
              
            }
            
            if(m_nDataInSel == 4){
              
              // Set view point Z  ACTN05
              
              // m_ScvViewPtZ;
              // m_ScvZoffset; // View Z offset

              
              m_ScvViewPtZ = dInp;
              
              m_nDataSource = STDGRA;
              m_nDataOperation = ACTN01;   // Force redraw, Show Scene
              
              m_nMouseInt = 1;            // Mouse internal
              
            }
            
            if(m_nDataInSel == 5){
              
              // Set  Z offset ACTN06
              
              m_ScvZoffset = dInp;
              
              m_nDataSource = STDGRA;
              m_nDataOperation = ACTN01;   // Force redraw, Show Scene
              
              m_nMouseInt = 1;            // Mouse internal
              
            }
            
            if(m_nDataInSel == 6){
              
              // Set  X offset ACTN07
              
              m_ScvXoffset = dInp;
              
              m_nDataSource = STDGRA;
              m_nDataOperation = ACTN01;   // Force redraw, Show Scene
              
              m_nMouseInt = 1;            // Mouse internal
              
            }
            
            if(m_nDataInSel == 7){
              
              // Set screen X base ACTN08
              
              //m_NormWoX = 0.2;
              //m_NormWoY = 0.2;
              
              m_NormWoX = dInp;
              
              m_nDataSource = STDGRA;
              m_nDataOperation = ACTN01;   // Force redraw, Show Scene
              
              m_nMouseInt = 1;            // Mouse internal
              
            }
            
            if(m_nDataInSel == 8){
              
              // Set  screen Y origin ACTN09
              
              m_NormWoY = dInp;
              
              m_nDataSource = STDGRA;
              m_nDataOperation = ACTN01;   // Force redraw, Show Scene
              
              m_nMouseInt = 1;            // Mouse internal
              
            }
            
          }
          
        }
        
      }
      
      m_nDataMode = 0;
      
      m_nInValueBox = 0;
      
      Invalidate();
      
    }
    
  }
  
  exla:
  
  CView::OnChar(nChar, nRepCnt, nFlags);
  
}

void CScenView::OnTimer(UINT nIDEvent)
{
  
  CScenDoc* pDoc = GetDocument();
  ASSERT_VALID(pDoc);
  
  char text[36];
  
  m_nTimerTicks++;
  
  sprintf(text,"Timer: %d",m_nTimerTicks);
  
  pDoc->PutTex(text);
  
  Invalidate();
  
  //CView::OnTimer(nIDEvent);
  
}

double CScenView::StartClock()
{
  
  double dTa;
  
  dTa = 0.0;
  
  m_dTw = 0.0;
  
  m_dTstart = 0.0;
  
  m_dTelapsed = 0.0;
  
  dTa = GetElapsedTime();
  
  m_dTstart = dTa;  // set clock origin time
  
  m_dTelapsed = 0.0;  // reset elapsed time
  
  return m_dTstart;   // if required
  
}

double CScenView::GetElapsedTime()
{
  
  int ntss,ntms;
  
  struct _timeb tsv;
  
  // secs and millisecs since 1970
  
  // <sys/types.h>
  // <sys/timeb.h>
  
  //struct _timeb tsv;
  
  ntss = 0;
  ntms = 0;
  
  // get time
  
  _ftime(&tsv);
  
  ntss = tsv.time;
  ntms = tsv.millitm;
  
  m_dTw = double(ntss) + double(ntms) / 1000.0;
  
  //m_dTw -= 921400000.0;
  
  m_dTelapsed = m_dTw - m_dTstart;
  
  return m_dTelapsed;
  
}

void CScenView::SetDataTxt()
{
  
  char text[12];
  
  sprintf(text,"%7.2f_", m_ScvYdrop);
  strcpy(m_cDataTxt[1], text);
  sprintf(text,"%7.2f_", m_ScreenGainX);
  strcpy(m_cDataTxt[2], text);
  sprintf(text,"%7.2f_", m_ScvDegAngle);
  strcpy(m_cDataTxt[3], text);
  sprintf(text,"%7.2f_", m_ScvViewPtZ);
  strcpy(m_cDataTxt[4], text);
  sprintf(text,"%7.2f_", m_ScvZoffset);
  strcpy(m_cDataTxt[5], text);
  sprintf(text,"%7.2f_", m_ScvXoffset);
  strcpy(m_cDataTxt[6], text);
  sprintf(text,"%7.2f_", m_NormWoX);
  strcpy(m_cDataTxt[7], text);
  sprintf(text,"%7.2f_", m_NormWoY);
  strcpy(m_cDataTxt[8], text);
  
}

// V1.01 PersInit.cpp

// Listing 1 PerspectiveInit()

// V1.06 visidocb.doc

void CScenView::PerspectiveInit()
{
  int i,j,kv;
  
  double vr,sn,cs;
  
  // m_WorldToScreenR = 0.5;
  
  m_WorldToScreenR = m_ScvViewPtZ / (m_ScvViewPtZ - m_ScvZoffset);
  
  // Offsets, Object position + point position
  
  m_ScOffpPosnX = m_ScvXoffset; //   0.0 View X offset
  m_ScOffpPosnY = m_ScvYdrop;   // -40.0 View Y drop
  m_ScOffpPosnZ = m_ScvZoffset; // -50.0 View Z offset
  
  m_ScvAngle = 3.14153 * m_ScvDegAngle / 180.0;  // radians -0.25 ~ 15 deg
  
  sn = sin(m_ScvAngle);  // radians 0.5 ~ 30 deg
  cs = cos(m_ScvAngle);
  
  // Set up perspective transformation matrix (m_ScPerspective)
  
  for(i=0; i<4; i++){
    for(j=0; j<4; j++){
      
      m_ScPerspective[i][j] = 0.0;
      
      m_ScnObjCoords[j] = 0.0;    // Object coords
      
    }
  }
  
  vr = -1.0 / m_ScvViewPtZ; //  +50.0 View point
  
  m_ScPerspective[0][0] = 1.0;  
  m_ScPerspective[1][1] = 1.0;
  m_ScPerspective[2][3] = vr; //  +50.0 View point
  m_ScPerspective[3][3] = 1.0;
  
  // Note m_ScPerspective[3][2] can't be used for Z offset,
  // this element is always equivalent to 0.0
  
  
  m_ScPerspective[0][0] = cs;
  m_ScPerspective[2][0] = sn;
  m_ScPerspective[0][3] = -vr * sn;
  m_ScPerspective[2][3] = vr * cs;
  
  m_ScnObjCoords[3] = 1.0;    // Object coords  
  
  m_ObjPosX = 0.0;  // Object posn
  m_ObjPosY = 0.0;
  m_ObjPosZ = 0.0;    
  
  m_ObjPtX = 0.0;  // (0,0,0) point coords
  m_ObjPtY = 0.0;
  m_ObjPtZ = 0.0;    
  
  // Get screen origin position via world point (0, 0, 0)
  // at normalised screen point (0.2, 0.2)
  
  // m_NormWoX = 0.2;
  // m_NormWoY = 0.2;
  
  m_WorgIy = m_nDeviceYtop + int(double(m_nDeviceYsize) * (1.0 - m_NormWoY));
  
  m_WorgIx = m_nDeviceXleft + int(double(m_nDeviceXsize) * m_NormWoX);
  
  m_ScDbgValue = 1;
  
  PerspectiveTr();  // transform the point; only S and T are valid
  
  m_ScDbgValue = 0;
  
  m_WorgSx = m_ScreenS;
  
  m_WorgTy = m_ScreenT;
  
  // Now DeviceIx and DeviceIy are valid
  
  // Get the Screen viewport coords
  
  kv = m_nDeviceXleft;
  
  m_ScreenXleft = m_WorgSx + double(kv - m_WorgIx) /  m_ScreenGainX; 
  
  kv = m_nDeviceXleft + m_nDeviceXsize;   // x right
  
  m_ScreenXright = m_WorgSx + double(kv - m_WorgIx) /  m_ScreenGainX; 
  
  m_ScreenXrange = fabs(m_ScreenXright - m_ScreenXleft);
  
  kv = m_nDeviceYtop;
  
  m_ScreenYtop = m_WorgTy - double(kv - m_WorgIy) / m_ScreenGainY; 
  
  kv = m_nDeviceYtop + m_nDeviceYsize;   // y bottom
  
  m_ScreenYbot = m_WorgTy - double(kv - m_WorgIy) / m_ScreenGainY; 
  
  // Get horizon
  
  m_ObjPtZ = -1000000.0;  // Horizon point coords    
  
  PerspectiveTr();        // transform the point    
  
  j = m_DeviceIx;
  
  m_DeviceHorizon = m_DeviceIy;
  
}

// V1.01 PersTran.cpp

// Listing 2 PerspectiveTr()

// V1.06 visidocb.doc

void CScenView::PerspectiveTr()
{
  int i,j;
  int ix,iy;
  
  double vb,za;
  
  int nDbg;
  
  // Offset and perspective m_ObjPt (X,Y,Z) to (S,T)
  
  nDbg = 0;
  
  // m_ObjPtX;  // Object point in 3D
  // m_ObjPtY;
  // m_ObjPtZ;
  
  // m_ScOffpPosnX =  0.0;
  // m_ScOffpPosnY = -40.0;   Ydrop
  // m_ScOffpPosnZ = -50.0;   Z view obj dist
  
  // m_ObjPosX = 0.0;  // Perspective Object position
  // m_ObjPosY = 0.0;
  // m_ObjPosZ = 0.0;
  
  m_ScnObjCoords[0] = m_ObjPtX + m_ObjPosX + m_ScOffpPosnX;
  m_ScnObjCoords[1] = m_ObjPtY + m_ObjPosY + m_ScOffpPosnY;
  m_ScnObjCoords[2] = m_ObjPtZ + m_ObjPosZ + m_ScOffpPosnZ;
  
  // matrix multiply
  
  for(j=0; j<4; j++){
    
    vb = m_ScnObjCoords[0] * m_ScPerspective[0][j];
    
    for(i=1; i<4; i++){
      
      vb = vb + m_ScnObjCoords[i] * m_ScPerspective[i][j];
      
      nDbg = 1;
      
    }
    m_rpc[j] = vb;
  }
  
  za = m_rpc[3];
  
  if(za == 0.0)za = 1.0e-15;  // Avoid division by 0
  
  // Rescale for m_rpc[3] = 1.0
  
  m_ScreenS = m_rpc[0] / za;
  m_ScreenT = m_rpc[1] / za;
  
  ix = int(m_ScreenGainX * (m_ScreenS - m_WorgSx) + 0.5) + m_WorgIx; 
  
  iy = int(m_ScreenGainY * (m_WorgTy - m_ScreenT) + 0.5) + m_WorgIy; 
  
  // Ready to set pixel
  
  m_DeviceIx = ix;  // Display device pixel
  m_DeviceIy = iy;
  
}

// Listing 2 PerspectiveTr()

void CScenView::SetScene(int xl, int yt, int xs, int ys)
{
  int i;
  
  // SetScene(m_nWorkPosLeft, m_nWorkPosTop, m_nWorkSzX, m_nWorkSzY);
  
  m_nNumThings = 4;
  
  for(i=0; i<m_nNumThings; i++)m_nThing[i] = 1;  // set visible
  
  m_nSceneID = 1;
  
  m_nDeviceXleft = xl;
  m_nDeviceYtop = yt;
  
  m_nDeviceXsize = xs;
  m_nDeviceYsize = ys;
  
}

void CScenView::InitDisplayPart(int nType)
{
  int nDbg;
  double dxs,sgx,wsr,sxr,thdz,dpixs;
  
  m_Ptva = 0.0;
  m_Ptvb = 0.0;
  m_Ptvr = 0.0;
  
  m_Ptvt = 0.0;
  
  m_dcs = 0.0;
  m_dsn = 0.0;
  
  dxs = double(m_nDeviceXsize);
  sgx = m_ScreenGainX;
  
  //wsr = m_WorldToScreenR;
  
  thdz = m_ObjPosZ;
  
  wsr = m_ScvViewPtZ / (m_ScvViewPtZ - m_ScvZoffset - thdz);
  
  sxr = m_ScreenXrange;
  
  dpixs = dxs * (2.0 * m_PartSizeMax * wsr) / sxr;
  
  if(dpixs < 20.0){
    
    nDbg = 1;
    dpixs = 20.0;
    
  }
  
  if(m_ScFastRender == 1 && dpixs > 200.0)dpixs = 200.0;
  
  m_Ptvas = 1.0 / dpixs; 
  
  if(m_Ptvas < m_dVarA)m_dVarA = m_Ptvas;
  
  if(m_Ptvas > m_dVarB)m_dVarB = m_Ptvas;
  
  m_Ptvbs = m_Ptvas;  

  if(nType == 1){
  
    // Disk or Cylinder

    m_Ptvbs = m_Ptvas / 4.0;  // circumf = ~ Pi*D * sqrt(2)

  }
  
}

// Make all objects visible

void CScenView::SetAllVisible()
{
  int i;
    
  if(m_nNumThings < 1)return;
  
  for(i=0; i<m_nNumThings; i++)m_nThing[i] = 1;  // set visible

}


