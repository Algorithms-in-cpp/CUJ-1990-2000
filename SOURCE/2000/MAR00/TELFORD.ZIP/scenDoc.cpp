// V1.53 scenDoc.cpp : implementation of the CScenDoc class
//
 
#include "stdafx.h"
#include "scen.h"
 
#include "scenDoc.h"
 
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
 
/////////////////////////////////////////////////////////////////////////////
// CScenDoc
 
IMPLEMENT_DYNCREATE(CScenDoc, CDocument)
 
BEGIN_MESSAGE_MAP(CScenDoc, CDocument)
 //{{AFX_MSG_MAP(CScenDoc)
 ON_COMMAND(ID_FILE_EXPORT, OnFileExport)
 ON_UPDATE_COMMAND_UI(ID_FILE_EXPORT, OnUpdateFileExport)
 ON_COMMAND(ID_FILE_IMPORT, OnFileImport)
 ON_UPDATE_COMMAND_UI(ID_FILE_IMPORT, OnUpdateFileImport)
 //}}AFX_MSG_MAP
END_MESSAGE_MAP()
 
/////////////////////////////////////////////////////////////////////////////
// CScenDoc construction/destruction
 
CScenDoc::CScenDoc()
{
 // One-time construction code
 
  m_nLineStart = 0;
 
  m_nFilesType = 0;  // All files
 
  // start CStexbuf
 
  m_nCtChars = 0L;
  m_nCtLines = 0;
  m_nIndex = 0;
 
  m_LineOut.Empty();
  m_lstr.Empty();
 
  m_pFtext = new CStringArray();

  if(m_pFtext == NULL){

    AfxMessageBox("Scen: Not enough memory, please close some applications and retry");

    PostQuitMessage(0);

  }

  m_pFtext->SetSize(128, 64);
 
  m_nNewList = 0;
 
  m_nSearchStart = 0;
  m_nSearchFound = -1;
  m_nSearchLen = 0;
  m_nReplaceLen = 0;
 
  m_csVsearch.Empty();
  m_csVreplace.Empty();
  m_csLhs.Empty();
  m_csRhs.Empty();
 
  // end CStexbuf
 
  m_nLinesWr = 0;
  m_nLinesRd = 0;
 
  m_nFnImp = 0;   // Ask user import filename
  m_nFnExp = 0;   // Ask user export filename
 
  m_nExportFileStart = 0;
  m_nExportFileLimit = 0;
 
  m_nImportAppend = 1;  // Set to import files append
 
  m_csExportFileName.Empty();
 
}
 
CScenDoc::~CScenDoc()
{
  int j;

  // CStringArray

  j = m_pFtext->GetSize();

  if(j > 0){
  
    m_pFtext->RemoveAll();

  }


}
 
BOOL CScenDoc::OnNewDocument()
{
 if (!CDocument::OnNewDocument())
  return FALSE;
 
 // TODO: add reinitialization code here
 // (SDI documents will reuse this document)
 
 return TRUE;
}
 
 
 
/////////////////////////////////////////////////////////////////////////////
// CScenDoc serialization
 
void CScenDoc::Serialize(CArchive& ar)
{
 if (ar.IsStoring())
 {
  // TODO: add storing code here
 }
 else
 {
  // TODO: add loading code here
 }
}
 
/////////////////////////////////////////////////////////////////////////////
// CScenDoc diagnostics
 
#ifdef _DEBUG
void CScenDoc::AssertValid() const
{
 CDocument::AssertValid();
}
 
void CScenDoc::Dump(CDumpContext& dc) const
{
 CDocument::Dump(dc);
}
#endif //_DEBUG
 
/////////////////////////////////////////////////////////////////////////////
// CScenDoc commands
 
// start CStexbuf
 
// CStexbuf Functions
  
// CString GetString(int);
// void    SetString(int, CString&);
// void    SetTex(int, char*);
// void    PutString(CString&);
// void    PutTex(char*);
// int     GetNumLines();
// void    FtReset();
// void    ResetIndex(int);
// void    LocTrimRight(CString& vCstr)
// int     FtReplace(CString& vCstarg, CString& vCsser, CString& vCsrep)
// int     FtFind(CString& vCsser)
// void    TabToSpace(CString& vCstr)
 
CString CScenDoc::GetString(int nLine)
{
 
  if(nLine >= m_nCtLines || nLine < 0){
 
    m_LineOut.Empty();
 
    return m_LineOut;       // no data
 
  }
 
  // Get line
 
  m_lstr = m_pFtext->GetAt(nLine);  // get line
 
  m_LineOut = m_lstr;
 
  return m_LineOut;
 
}
 
void CScenDoc::SetString(int nLine, CString& vString)
{
 
  if(nLine > m_nCtLines || nLine < 0){
 
    return;       // out of range
 
  }
 
  // Set line
 
  m_lstr = vString;
 
  m_pFtext->SetAt(nLine, m_lstr);
 
  return;
 
}
 
void CScenDoc::SetTex(int nLine, char* text)
{
 
  if(nLine > m_nCtLines || nLine < 0){
 
    return;       // out of range
 
  }
 
  // Set line
 
  m_lstr = text;
 
  m_pFtext->SetAt(nLine, m_lstr);
 
  return;
 
}
 
void CScenDoc::PutString(CString& vString)
{
 
  //  CObArray -  limit is memory ?
 
  m_lstr = vString;
 
  m_nCtLines++;
 
  if(m_nCtLines > 7500){

    m_nCtLines = 7500;      // limit at 7500 lines
    
    return;  // Data lost

  }
 
  m_pFtext->SetAtGrow(m_nIndex, m_lstr);

  m_nIndex++;
 
}
 
void CScenDoc::PutTex(char* vtex)
{
 
  m_LineOut = vtex;

  PutString(m_LineOut);
 
}
 
int CScenDoc::GetNumLines()
{
 
  return m_nCtLines;
 
}
 
void CScenDoc::FtReset()
{

  m_nCtChars = 0L;
  m_nCtLines = 0;
  m_nIndex = 0;
 
  m_LineOut.Empty();
  m_lstr.Empty();

  if(m_pFtext != NULL){
  
    m_pFtext->RemoveAll();

  }

  m_nLinesRd = 0;
 
}
 
void CScenDoc::ResetIndex(int nwInd)
{
 
  //
  //  CObArray -  limit is memory ?
 
  if(nwInd > m_nCtLines || nwInd < 0){
 
    return;       // out of range
 
  }
 
  m_nCtLines = nwInd;
 
  m_nIndex = nwInd;  // store over previous lines
 
  m_nLinesRd = 0;
 
}
 
void CScenDoc::LocTrimRight(CString& vCstr)
{
 
  int i,k,n;
  CString csTmm;
 
  k = vCstr.GetLength();
 
  if(k < 1)return;
 
  i = k-1;
 
  csTmm = vCstr;
 
  do{
 
    n = csTmm[i];
    i--;

  }while(i >= 0 && n <= ' ');
 
  if(i == -1)i--;
 
  vCstr = csTmm.Left(i+2);
 
}
 
void CScenDoc::TabToSpace(CString& vCstr)
{
 
  int i,k,n;
 
  k = vCstr.GetLength();
 
  if(k < 1)return;
 
  for(i=0; i<k; i++){
 
    n = vCstr[i];
 
    if(n == 9)vCstr.SetAt(i, ' ');
 
  }
 
}

 
int CScenDoc::FtFind(CString& vCsser)
{
 
  int i,nRec,kR,nsF,kl;
 
  int nDbg;
 
  //int m_nSearchStart;
  //int m_nSearchFound;
  //int m_nSearchLen;
  //int m_nReplaceLen;
 
  //CString m_csVsearch;
  //CString m_csVreplace;
  //CString m_csLhs;
  //CString m_csRhs;
 
  nDbg = 0;
 
  kR = -1;
 
  m_nSearchFound = -1;
 
  m_csLhs.Empty();
  m_csRhs.Empty();
 
  m_csVsearch = vCsser;
 
  m_nSearchLen = m_csVsearch.GetLength();
 
  if(m_nSearchLen < 1)goto exla;
 
  nRec = m_nCtLines;
 
  if(nRec < 1)goto exla;
 
  if(m_nSearchStart >= nRec)goto exla;
 
  // Find the 1st occurrence after SearchStart line
 
  for(i=m_nSearchStart; i<nRec; i++){
 
    m_lstr = m_pFtext->GetAt(i);  // get line
 
    kl = m_lstr.GetLength();
 
    if(kl > 0){
 
      nsF = m_lstr.Find(m_csVsearch);
 
      nDbg = 1;
 
      if(nsF > -1){
 
        // Found
 
        m_csLhs = m_lstr.Left(nsF);  // can be null
 
        m_csRhs = m_lstr.Right(kl - nsF - m_nSearchLen);
 
        kR = i;
 
        goto exla;
 
      }
 
    }
 
 
  }
 
exla:
 
  m_nSearchFound = kR;  // -1 if not found
 
  return kR;
 
}
 
int CScenDoc::FtReplace(CString& vCstarg, CString& vCsser, CString& vCsrep)
{
  int kl,nsF,kR,nDbg;
 
  m_nSearchFound = -1;
  m_nSearchLen = 0;
  m_nReplaceLen = 0;
 
  m_csVsearch.Empty();
  m_csVreplace.Empty();
  m_csLhs.Empty();
  m_csRhs.Empty();
 
  nDbg = 0;
 
  m_csLhs.Empty();
  m_csRhs.Empty();
 
  m_csVsearch = vCsser;
 
  m_csVreplace = vCsrep;
 
  m_nSearchLen = m_csVsearch.GetLength();
 
  if(m_nSearchLen < 1)goto exla;
 
  kl = vCstarg.GetLength();
 
  if(kl < 1)goto exla;
 
  m_nReplaceLen = m_csVreplace.GetLength();
 
  // Find the 1st occurrence in target
 
  nsF = -1;
 
  kR = 0;
 
  do{
 
    kl = vCstarg.GetLength();
 
    if(kl > 0){
 
      nsF = vCstarg.Find(m_csVsearch);
 
      nDbg = 1;
 
      if(nsF > -1){
 
        // Found
 
        m_csLhs = vCstarg.Left(nsF);  // can be null
 
        m_csRhs = vCstarg.Right(kl - nsF - m_nSearchLen);
 
        kR++;
 
        vCstarg.Empty();
 
        vCstarg = m_csLhs + m_csVreplace + m_csRhs;
 
      }
 
      // Keep looping until search fails
 
    }
 
 
  }while(nsF != -1);
 
exla:
 
  return kR;   // number of replacements
 
}
 
// end CStexbuf
 
void CScenDoc::OnVrFileExport(int nFn)
{
 
  m_nFnExp = nFn;
 
  OnFileExport();
 
}
 
void CScenDoc::OnFileExport()
{ 
  int nOpnf;
  int i,j,kt,nWrEn;
  int nDbg;
 
  char txxt[86];
 
  CStdioFile wfile;
 
  CString csPgmPath;
  CString csScenPath;
  CString vstr;
  CString vsnl;
  CString szFilter = "TXT Files(*.TXT)|*.TXT|";
 
  szFilter += "All Files(*.*)|*.*||";
 
  //MSG Message;
 
  nDbg = 0;
 
  //m_nFnExp = 0;  // ask user
 
  if(m_nFnExp == 0){
 
    // Dialog for output file
 
    CFileDialog fdlg(FALSE, NULL, NULL, OFN_OVERWRITEPROMPT, szFilter);
 
    // Generate a warning box if file does not exist
    // OPENFILENAME
 
    fdlg.m_ofn.Flags = fdlg.m_ofn.Flags | OFN_NOREADONLYRETURN;
 
    if(fdlg.DoModal() == IDOK){
 
      csScenPath = fdlg.GetPathName();
      j = csScenPath.GetLength();
      i = csScenPath.ReverseFind('\\');
      m_cstofile = csScenPath.Right(j - i - 1);
 
    }
    else{
      return;  // CANCEL
    }
 
  }
 
  // Fixed file for output
 
  if(m_nFnExp == 1){
 
    // Open a fixed filename for write
 
    csScenPath = "c:\\tmp\\Scenlog.txt";
 
    //i = AfxMessageBox(csScenPath,MB_OKCANCEL);
 
    //if(i != IDOK)return;
 
  }
 
  // Program selected file for output
 
  if(m_nFnExp == 9){
 
    // Open a fixed filename for write
 
    csScenPath = m_csExportFileName;
 
    //i = AfxMessageBox(csScenPath,MB_OKCANCEL);
 
    //if(i != IDOK)return;
 
  }
 
  nDbg = 2;  // debug
 
  nOpnf = wfile.Open(csScenPath, CFile::modeCreate | CFile::modeWrite);
 
  if(nOpnf == 0){
    AfxMessageBox("Cannot create output file");
    return;
  }
 
  m_nLinesWr = 0;
 
  nWrEn = 1;  // Enable write
 
  kt = GetNumLines();  // get doc size
 
  if(m_nExportFileLimit == 0){
    m_nExportFileLimit = kt;
  }
 
  // Write from ExportFileStart to ExportFileLimit
 
  for(i=m_nExportFileStart; i<m_nExportFileLimit; i++){
 
    vstr = GetString(i);
 
    vstr += "\n";
 
    nDbg = 3;  // debug
 
    wfile.WriteString(vstr);
 
    m_nLinesWr++;
  
  }
 
  sprintf(txxt,"\n");
 
  vstr = txxt;
 
  nDbg = 4;  // debug
 
  wfile.WriteString(vstr);
 
  nDbg = 5;
 
  wfile.Close();
 
  sprintf(txxt,"%d Lines written to file %s",m_nLinesWr,csScenPath);
 
  AfxMessageBox(txxt);
 
  UpdateAllViews(NULL);
 
}
 
void CScenDoc::OnUpdateFileExport(CCmdUI* pCmdUI)
{
  // TODO: Add your command update UI handler code here
 
}
 
void CScenDoc::OnVrFileImport(int nFn)
{
 
  m_nFnImp = nFn;
 
  OnFileImport();
 
}
 
void CScenDoc::OnFileImport()
{
  int i,j,k,kl,ki,nEndOfFile;
  int nTotalLines;
  int nCurLine,nChz,nMinLineLen;
  int nNameAvail;
  int nStrExt;
 
  int nDbg;
 
  UINT bytesmax;
  LPCSTR pbufr;
 
  CString LocLin;  // Line of text from file
  CString vLin;
  CString csSavLin;
 
  CString csTmA;
  CString csTmB;
  CString csTmC;
  CString csTmD;
  CString csTmE;
 
  //char text[82];
 
  CStdioFile rfile;
 
  CString szFilter = "TXT Files(*.TXT)|*.TXT|";
 
  szFilter += "All Files(*.*)|*.*||";
 
  CFileDialog fdlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, szFilter);
 
  // Generate a warning box if file does not exist
 
  nNameAvail = 0;
 
  nStrExt = 0;
 
  k = 0;
 
  fdlg.m_ofn.Flags = fdlg.m_ofn.Flags | OFN_FILEMUSTEXIST;
 
  //m_nFnImp = 0;       // ask user
 
  if(m_nFnImp == 0){
 
    // Ask user for file name
 
    if(fdlg.DoModal() == IDOK){

      m_cstxfrpath = fdlg.GetPathName();
      j = m_cstxfrpath.GetLength();
      i = m_cstxfrpath.ReverseFind('\\');
      m_cstxfrfile = m_cstxfrpath.Right(j - i - 1);
 
      nNameAvail = 1;
 
    }
  }
 
 
  if(m_nFnImp == 1){
 
    m_cstxfrpath = "c:\\tmp\\abcdezf.txt";
 
    nNameAvail = 1;
 
  }
 
  if(m_nFnImp == 2){
 
    m_cstxfrpath = "c:\\tmp\\abcdezg.txt";
 
    nNameAvail = 1;
 
  }
 
  //           1111111111222222222233333333334444444444
  // 01234567890123456789012345678901234567890123456789
 
  bytesmax = 460;
 
  ki = 0;
 
  csTmA.Empty();
  csTmB.Empty();
  csTmC.Empty();
  csTmD.Empty();
  csTmE.Empty();
 
  nDbg = 1;  // debug
 
  if(nNameAvail != 0){
 
    j = rfile.Open(m_cstxfrpath, CFile::modeRead);
 
    if(j == 0){
 
      AfxMessageBox("Unable to open input file");
 
      return;
 
    }
 
    nEndOfFile = 0;     // EOF flag store
 
    m_nTotalBytes = 0;
 
    nTotalLines = 0;
    kl = 0;
    nChz = 0;
 
    if(m_nImportAppend == 0){
 
      // Store over any previous list
 
      ResetIndex(ki);
 
    }
 
    nCurLine = ki;
 
    nMinLineLen = 1;
 
    while(nEndOfFile == 0){
 
      // Read to CR LF
 
      pbufr = rfile.ReadString(LocLin.GetBuffer(464), bytesmax);
 
      if(pbufr == NULL)nEndOfFile = 1;
 
      LocLin.ReleaseBuffer();  // Make CString dynamic again
 
      // pbufr : use only for NULL test; no longer points to LocLin buff
 
      if(nEndOfFile == 0){   // if not EOF
 
        // leave off LF char
 
        nDbg = 2;
 
        LocTrimRight(LocLin);
 
        kl = LocLin.GetLength();  // input line
 
        if(kl < 1)LocLin = " ";   // always at least one char
 
        kl = LocLin.GetLength();  // input line
 
        m_nTotalBytes += kl;
 
        if(kl >= nMinLineLen){
 
          // Process non-blank lines
 
          if(kl > 450)kl = 450;
 
          vLin = LocLin.Left(kl);
 
          nChz = vLin[0];
 
          nDbg = 3;
 
          // process/store in text buff
          //           1111111111222222222233333333334444444444
          // 01234567890123456789012345678901234567890123456789
 
          // store in text buff
 
          // file
 
          PutString(vLin);    // add a line to text buff
 
          nCurLine++;
 
        }
 
      }
 
    }
 
  }
 
  rfile.Close();      //  End of file input
 
  nTotalLines = nCurLine;
 
  m_nLinesRd = nCurLine;
 
  m_nNewList = 1;
 
  nDbg = 3;  // debug
 
  UpdateAllViews(NULL);
 
}
 
void CScenDoc::OnUpdateFileImport(CCmdUI* pCmdUI)
{
 
}

