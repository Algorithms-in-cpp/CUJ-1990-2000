// V1.53 scenDoc.h : interface of the CScenDoc class
//
/////////////////////////////////////////////////////////////////////////////
 
#if !defined(AFX_SCENDOC_H__D6177DAE_637A_11D3_9449_44B1F9C00000__INCLUDED_)
#define AFX_SCENDOC_H__D6177DAE_637A_11D3_9449_44B1F9C00000__INCLUDED_
 
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
 
 
class CScenDoc : public CDocument
{
public:
 
  int m_nTextLines;
  int m_nLineStart;
 
  int m_nLinesWr;
  int m_nLinesRd;
 
  int m_nFnImp;
  int m_nFnExp;
 
  int m_nTotalBytes;
 
  int m_nImportAppend;
 
  int m_nFilesType;
 
  // from CStexbuf
 
  int m_nCtChars;
  int m_nCtLines;
  int m_nIndex;
 
  int m_nNewList;
 
  int m_nSearchStart;
  int m_nSearchFound;
 
  int m_nSearchLen;
  int m_nReplaceLen;
 
  int m_nExportFileStart;
  int m_nExportFileLimit;
 
  CString m_lstr;
  CString m_LineOut;
 
  CString m_csExportFileName;
 
  CString m_csVsearch;
  CString m_csVreplace;
  CString m_csLhs;
  CString m_csRhs;
 
  CStringArray* m_pFtext;
 
  // CStexbuf
 
  CString m_csfrfile;
  CString m_cstofile;
  CString m_cstxfrfile;
  CString m_cstxfrpath;
 
 
protected: // create from serialization only
 CScenDoc();
 DECLARE_DYNCREATE(CScenDoc)
 
// Attributes
public:
 
// Operations
public:
 
// Overrides
 // ClassWizard generated virtual function overrides
 //{{AFX_VIRTUAL(CScenDoc)
 public:
 virtual BOOL OnNewDocument();
 virtual void Serialize(CArchive& ar);
 //}}AFX_VIRTUAL
 
// Implementation
public:
 virtual ~CScenDoc();
 
  // CStexbuf
 
  CString GetString(int);
  void SetString(int, CString&);
  void SetTex(int, char*);
  void PutString(CString&);
  void PutTex(char*);
  int GetNumLines();
  void FtReset();
  void ResetIndex(int);
 
  void LocTrimRight(CString&);
 
  void TabToSpace(CString&);
 
  int FtFind(CString&);
 
  int FtReplace(CString&, CString&, CString&);
 
  //  CStexbuf
 
  void OnVrFileImport(int);
  void OnVrFileExport(int);
 
#ifdef _DEBUG
 virtual void AssertValid() const;
 virtual void Dump(CDumpContext& dc) const;
#endif
 
protected:
 
// Generated message map functions
protected:
 //{{AFX_MSG(CScenDoc)
 afx_msg void OnFileExport();
 afx_msg void OnUpdateFileExport(CCmdUI* pCmdUI);
 afx_msg void OnFileImport();
 afx_msg void OnUpdateFileImport(CCmdUI* pCmdUI);
 //}}AFX_MSG
 DECLARE_MESSAGE_MAP()
};
 
/////////////////////////////////////////////////////////////////////////////
 
//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.
 
#endif // !defined(AFX_SCENDOC_H__D6177DAE_637A_11D3_9449_44B1F9C00000__INCLUDED_)

