/////////////////// UtilityMacros.cpp ///////////////// rado ///
//                                                            //
//  Copyright (c) 1999 Radoslav Getov                         //
//                                                            //
//  Permission to use, copy, modify and distribute this       //
//  software is granted without fee, provided that the above  //
//  copyright notice and this permission notice appear in the //
//  modified source and the source files that #include it.    //
//                                                            //
////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////
//                                                            //
//  Test for the macros defined in the header file.           //
//                                                            //
////////////////////////////////////////////////////////////////


#include "UtilityMacros.h"    

#include <assert.h>   // for assert()
#include <string.h>   // for strlen()
#include <iostream>   // for std::cout


//=======================| testREPEAT |=========================
// Test '#REPEAT_XXXX'
//________________________________________________________rado__
static void testREPEAT()
{
#define SIZEOF(array) (sizeof(array)/sizeof(*array))

std::cout << "testREPEAT()\n";

// Test REPEAT_xxx
char str[] = REPEAT (1024, " ");
assert (strlen (str) == 1024);
assert (SIZEOF (str) == 1025);   // including trailing 0

int ones[] = { REPEAT_WC (1024, 1) };
assert (SIZEOF (ones) == 1024);
}

AT_START (
         testREPEAT();
         )



//=======================| test__LINE__ |=======================
// Test UNIQUE_NAME, LINE_STRING, HERE
//________________________________________________________rado__
static void test__LINE__()
{
std::cout << "test__LINE__()\n";

// Test UNIQUE_NAME
int UNIQUE_NAME = 1,
    UNIQUE_NAME = 2;

// Test LINE_STRING & HERE  
#pragma message (HERE " Click on me!")  // MSVC++ 5.0+ only?   
}

AT_START (
         test__LINE__(); 
         )


void x(int,int);
//======================| testControl |=========================
// Test for #LOOP, #ONCE, #SKIP, and #REV_SKIP
//________________________________________________________rado__
static void testControl()
{
std::cout << "testControl()\n";

int any      = 0,
    once     = 0,
    skip     = 0,
    rev_skip = 0;
    
LOOP (50)
   {
   any++;                     // 50*1  == 50
   ONCE (once++;)             // 0+1   == 1
   SKIP (10, skip++; )        // 50/10 == 5
   REV_SKIP (10, rev_skip++;) // 50 - 50/10 = 45
   }

assert (any      == 50 && 
        once     == 1  && 
        skip     == 5  && 
        rev_skip == 45 );

LOOP_C (50, any++;)           // 50 + 50 == 100
assert (any  == 100);
}

AT_START (
         testControl();
         )



//======================| testSAVE |============================
// Test for SAVE, SAVE_T, DELAYED_ASSIGN and DELAYED_ASSIGN_T
//________________________________________________________rado__
static int iSAVE   = 1, 
           iSAVE_T = 2,
           iASS    = 3,
           iASS_T  = 4;  

static void testSAVE()
{
SAVE   (iSAVE)
SAVE_T (int, iSAVE_T)

DELAYED_ASSIGN (iASS, 10);
DELAYED_ASSIGN_T (int, iASS_T, 20);

iSAVE = iSAVE_T = iASS = iASS_T = 0;  
}

AT_START (
         std::cout << "test SAVE\n";
         testSAVE();
         assert (iSAVE   == 1  && 
                 iSAVE_T == 2  && 
                 iASS    == 10 &&
                 iASS_T  == 20 );
         )



//====================| AT_START & AT_END |=====================
// Pay attention to the execution order.
//________________________________________________________rado__
AT_START ( printf ("Before main()\n"     ); )
AT_START ( printf ("More before main()\n"); )

AT_END   ( printf ("More after main()\n" ); )
AT_END   ( printf ("After main()\n"      ); )



//========================| main |==============================
// main() just for building
//________________________________________________________rado__
void main()
{
std::cout << "main()\n";
}
