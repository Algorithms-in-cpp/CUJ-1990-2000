
// SafeList.h : header file
//
#ifndef SAFELIST_H
#define SAFELIST_H
#include <afxtempl.h>
/////////////////////////////////////////////////////////////////////////////
// CSafeList window

template<class TYPE, class ARG_TYPE>
class CSafeList
{
// Construction
public:
   void Lock() const;
   void Unlock() const;
   CSafeList(int nBlockSize = 10);

   CSafeList(const CSafeList& listSrc);

   virtual ~CSafeList();

   // Attributes (head and tail)
        // count of elements
        int GetCount() const;
        BOOL IsEmpty() const;

        // peek at head or tail
        //TYPE& GetHead();
        TYPE GetHead() const;
        TYPE& GetTail();
        TYPE GetTail() const;

// Operations
        // get head or tail (and remove it) - don't call on empty list !
        TYPE RemoveHead();
        TYPE RemoveTail();

        // add before head or after tail
        POSITION AddHead(ARG_TYPE newElement);
        POSITION AddTail(ARG_TYPE newElement);

        // add another list of elements before head or after tail
        void AddHead(CSafeList* pNewList);
        void AddTail(CSafeList* pNewList);
        // remove all elements
        void RemoveAll();

        // iteration
        POSITION GetHeadPosition() const;
        POSITION GetTailPosition() const;
   //TYPE& GetNext(POSITION& rPosition); // return *Position++
   TYPE GetNext(POSITION& rPosition) const; // return *Position++
        TYPE& GetPrev(POSITION& rPosition); // return *Position--
        TYPE GetPrev(POSITION& rPosition) const; // return *Position--

        // getting/modifying an element at a given position
        TYPE& GetAt(POSITION position);
        TYPE GetAt(POSITION position) const;
        void SetAt(POSITION pos, ARG_TYPE newElement);
        void RemoveAt(POSITION position);

        // inserting before or after a given position
        POSITION InsertBefore(POSITION position, ARG_TYPE newElement);
        POSITION InsertAfter(POSITION position, ARG_TYPE newElement);

        // helper functions (note: O(n) speed)
        POSITION Find(ARG_TYPE searchValue, POSITION startAfter = NULL) const;
                // defaults to starting at the HEAD, return NULL if not found
        POSITION FindIndex(int nIndex) const;
                // get the 'nIndex'th element (may return NULL)

// Implementation
protected:
   CRITICAL_SECTION* m_pcsListAccess;
   CList<TYPE,ARG_TYPE> m_List;
};

#include "SafeList.inl"
/////////////////////////////////////////////////////////////////////////////

#endif // SAFELIST_H
