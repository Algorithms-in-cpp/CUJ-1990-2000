#ifndef SAFETYPES_H
#define SAFETYPES_H

template<class T>
class SAFETYPE
{
  public:

  /////////////////////////////////////////////////////////////////
  // constructors and destructor
  SAFETYPE();
  SAFETYPE(const SAFETYPE<T>& SAFETYPEsrc);
  SAFETYPE(const T& t);  
  ~SAFETYPE();

  /////////////////////////////////////////////////////////////////
  // casting and assignment operators
  operator T() const; 
  //operator HANDLE(){return m_hMutex}const; 
  const SAFETYPE<T>& operator=(const SAFETYPE<T>& SAFETYPEsrc);

  /////////////////////////////////////////////////////////////////
  // member methods for atomic lock/unlock of mutex
  void SingleLock()const;
  void SingleUnlock()const;
  void DoubleLock(HANDLE hMutex)const;
  void DoubleUnlock(HANDLE hMutex)const;

  /////////////////////////////////////////////////////////////////
  //global methods for atomic lock/unlock
  friend void AFXAPI gSingleLock(HANDLE hMutex);
  friend void AFXAPI gSingleUnlock(HANDLE hMutex);
  friend void AFXAPI gDoubleLock(HANDLE hMutex1,HANDLE hMutex2);
  friend void AFXAPI gDoubleUnlock(HANDLE hMutex1,HANDLE hMutex2);

  /////////////////////////////////////////////////////////////////
  // member functions for arithmetic binary assignment operators
  const SAFETYPE<T>& operator+=(const SAFETYPE<T>& SAFETYPEsrc);
  const SAFETYPE<T>& operator-=(const SAFETYPE<T>& SAFETYPEsrc);
  const SAFETYPE<T>& operator*=(const SAFETYPE<T>& SAFETYPEsrc);
  const SAFETYPE<T>& operator/=(const SAFETYPE<T>& SAFETYPEsrc);
  const SAFETYPE<T>& operator%=(const SAFETYPE<T>& SAFETYPEsrc);

  /////////////////////////////////////////////////////////////////
  // member functions for bit-wise binary assignment operators
  const SAFETYPE<T>& operator&=(const SAFETYPE<T>& SAFETYPEsrc);
  const SAFETYPE<T>& operator|=(const SAFETYPE<T>& SAFETYPEsrc);
  const SAFETYPE<T>& operator^=(const SAFETYPE<T>& SAFETYPEsrc);
  const SAFETYPE<T>& operator>>=(const SAFETYPE<T>& SAFETYPEsrc);
  const SAFETYPE<T>& operator<<=(const SAFETYPE<T>& SAFETYPEsrc);


  /////////////////////////////////////////////////////////////////
  // member functions for boolean binary relational operators

  friend BOOL AFXAPI operator==(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
  friend BOOL AFXAPI operator==(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);
  friend BOOL AFXAPI operator==(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);

  friend BOOL AFXAPI operator!=(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
  friend BOOL AFXAPI operator!=(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);
  friend BOOL AFXAPI operator!=(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);

  friend BOOL AFXAPI operator<(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
  friend BOOL AFXAPI operator<(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);
  friend BOOL AFXAPI operator<(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);

  friend BOOL AFXAPI operator>(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
  friend BOOL AFXAPI operator>(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);
  friend BOOL AFXAPI operator>(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);

  friend BOOL AFXAPI operator<=(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
  friend BOOL AFXAPI operator<=(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);
  friend BOOL AFXAPI operator<=(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);

  friend BOOL AFXAPI operator>=(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
  friend BOOL AFXAPI operator>=(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);
  friend BOOL AFXAPI operator>=(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);

  friend BOOL AFXAPI operator&&(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
  friend BOOL AFXAPI operator&&(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);
  friend BOOL AFXAPI operator&&(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);

  friend BOOL AFXAPI operator||(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
  friend BOOL AFXAPI operator||(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);
  friend BOOL AFXAPI operator||(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);


  /////////////////////////////////////////////////////////////////
  // member functions for unary operators
  const SAFETYPE<T> operator+();
  const SAFETYPE<T> operator~();
  const SAFETYPE<T> operator-();
  BOOL operator!();

  
  /////////////////////////////////////////////////////////////////
  // member functions for postfix and prefix operators
  const SAFETYPE<T>& operator++();
  const SAFETYPE<T> operator++(int);
  const SAFETYPE<T>& operator--();
  const SAFETYPE<T> operator--(int);

  protected:

  HANDLE m_hMutex;               // access protection
  T m_t;                         // The data 
  

  /////////////////////////////////////////////////////////////////
  // These unary functions disallowed. Put them here to prevent their use.
  const SAFETYPE<T>& operator&();
  const SAFETYPE<T>& operator*();  

};


// global arithmetic binary operators
template<class T>
 SAFETYPE<T> AFXAPI operator+(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator+(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator+(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);

template<class T>
 SAFETYPE<T> AFXAPI operator-(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator-(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator-(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);

template<class T>
 SAFETYPE<T> AFXAPI operator*(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator*(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator*(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);

template<class T>
 SAFETYPE<T> AFXAPI operator/(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator/(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator/(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);

template<class T>
 SAFETYPE<T> AFXAPI operator%(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator%(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator%(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);


/////////////////////////////////////////////////////////////////
// global bit-wise binary operators
template<class T>
 SAFETYPE<T> AFXAPI operator&(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator&(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator&(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);

template<class T>
 SAFETYPE<T> AFXAPI operator|(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator|(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator|(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);

template<class T>
 SAFETYPE<T> AFXAPI operator^(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator^(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator^(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);

template<class T>
 SAFETYPE<T> AFXAPI operator>>(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator>>(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator>>(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);

template<class T>
 SAFETYPE<T> AFXAPI operator<<(const SAFETYPE<T>& SAFETYPEsrc1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator<<(const T& src1,const SAFETYPE<T>& SAFETYPEsrc2);
template<class T>
 SAFETYPE<T> AFXAPI operator<<(const SAFETYPE<T>& SAFETYPEsrc1,const T& src2);


#include "safetypes.inl"

#endif

