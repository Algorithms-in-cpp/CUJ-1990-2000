/////////////////////////////////////////////////////////////////////////
// global functions for atomic lock/unlock
void AFXAPI gSingleLock(HANDLE hMutex)
{
   DWORD dwRes = WAIT_FAILED;

   dwRes = ::WaitForSingleObject(hMutex,DB_INFINITE);
   switch (dwRes)
   {
      case WAIT_OBJECT_0:
      case WAIT_ABANDONED:  // Got it!
      break;

      case WAIT_FAILED:     // oh, darn.
#ifdef _DEBUG
         dwRes = ::GetLastError();
#endif
         //  fall through.
      case WAIT_TIMEOUT:
         ASSERT(FALSE);
      break;
   }
}

void AFXAPI gSingleUnlock(HANDLE hMutex)
{
   VERIFY(::ReleaseMutex(hMutex));
}

void AFXAPI gDoubleLock(HANDLE hMutex1,HANDLE hMutex2)
{
   DWORD dwRes = WAIT_FAILED;
   HANDLE mutexArray[2];

   mutexArray[0] = hMutex1; 
   mutexArray[1] = hMutex2;

   dwRes = ::WaitForMultipleObjects(2,mutexArray,TRUE,DB_INFINITE);
   switch(dwRes)
   {
      case WAIT_OBJECT_0 + 0:
      case WAIT_OBJECT_0 + 1:
      case WAIT_ABANDONED_0 + 0:
      case WAIT_ABANDONED_0 + 1:    // Got it!
      break;

      case WAIT_FAILED:             // oh, darn.
#ifdef _DEBUG
         dwRes = ::GetLastError();
#endif
         //  fall through.
      case WAIT_TIMEOUT:
         ASSERT(FALSE);
      break;
   }
}

void AFXAPI gDoubleUnlock(HANDLE hMutex1,HANDLE hMutex2)
{
   VERIFY(::ReleaseMutex(hMutex1));
   VERIFY(::ReleaseMutex(hMutex2));
}
