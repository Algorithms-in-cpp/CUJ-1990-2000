#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <sstream>
#include "fp.h"

const int BIAS = 127;
const int MIN_EXP = 0;
const int MAX_EXP = 255;
const int P = 15;
const long MIN_NORM = 1L << (P - 1);
const long ONE = 1L << P;
const int QF = 1;
const int SF = 2;

#define IS_ZERO(fp) ((fp).exp == 0 && (fp).frac == 0)
#define IS_INF(fp) ((fp).exp == MAX_EXP && (fp).frac == 0)
#define IS_QNAN(fp) ((fp).exp == MAX_EXP && (fp).frac == QF)
#define IS_SNAN(fp) ((fp).exp == MAX_EXP && (fp).frac == SF)
#define IS_NAN(fp) ((fp).exp == MAX_EXP && (fp).frac != 0)

#define ARG(x) (IS_SNAN(x) ? exception(inv, x) : x)

inline long fp::lf() const
	{	// sign-extend fraction and convert to long
	return long(is_neg ? -frac : frac);
	}

fp::fp()
	{	// construct
	convert(0.0);
	}

fp::fp(const char *str)
	{	// construct from string
	convert(strtod(str, NULL));
	}

fp::fp(double d)
	{	// construct from double
	convert(d);
	}

fp::fp(int e, int f, bool neg)
	{
	is_neg = neg;
	frac = f;
	exp = e + BIAS;
	}

bool fp::eq(const fp& f) const
	{	// return this equals f
	return is_neg == f.is_neg && exp == f.exp && frac == f.frac;
	}

bool fp::lt(const fp& f) const
	{	// return this less than f
	return is_neg
		? exp == f.exp
			? f.frac < frac
			: f.exp < exp
		: exp == f.exp
			? frac < f.frac
			: exp < f.exp;
	}

fp operator + (const fp& f1, const fp& f2)
	{	// add f1 to f2
	fp res = f1;
	res += f2;
	return res;
	}

fp& fp::operator += (const fp& f)
	{	// add f to this fp object
	return f.exp <= exp
		? add(ARG(*this), ARG(f))
		: add(ARG(f), ARG(*this));	
	}

fp operator - (const fp& f1, const fp& f2)
	{	// subtract f2 from f1
	fp res = f1;
	return res -= f2;
	}

fp& fp::operator -= (const fp& f)
	{	// subtract f from this fp object
	return f.exp <= exp
		? add(ARG(*this), -ARG(f))
		: add(-ARG(f), ARG(*this));	
	}

fp operator - (const fp& f)
	{	// negate f
	return fp(f.exp - BIAS, f.frac, !f.is_neg);
	}

fp operator * (const fp& f1, const fp& f2)
	{	// multiply f1 by f2
	fp res = f1;
	res *= f2;
	return res;
	}

fp& fp::operator *= (const fp& f)
	{	// multiply this fp object by f
	fp f1 = ARG(*this);
	fp f2 = ARG(f);
	if (IS_NAN(f1))
		*this = f1;
	else if (IS_NAN(f2))
		*this = f2;
	else if (IS_INF(f1) && IS_ZERO(f2) || IS_ZERO(f1) && IS_INF(f2))
		*this = exception(inv, f1);
	else if (IS_ZERO(f1) || IS_ZERO(f2))
		*this = f1.is_neg == f2.is_neg ? zero : nzero;
	else if (IS_INF(f1) || IS_INF(f2))
		*this = f1.is_neg == f2.is_neg ? pinf : ninf;
	else
		normalize(f1.exp + f2.exp - BIAS, f1.lf() * f2.lf());
	return *this;	
	}

fp operator / (const fp& f1, const fp& f2)
	{	// divide f1 by f2
	fp res = f1;
	res /= f2;
	return res;
	}

fp& fp::operator /= (const fp& f)
	{	// divide this fp object by f
	fp f1 = ARG(*this);
	fp f2 = ARG(f);
	if (IS_NAN(f1))
		*this = f1;
	else if (IS_NAN(f2))
		*this = f2;
	else if (IS_INF(f1) && IS_INF(f2) || IS_ZERO(f1) && IS_ZERO(f2))
		*this = exception(inv, f1);
	else if (IS_ZERO(f1))
		*this = f1.is_neg == f2.is_neg ? zero : nzero;
	else if (IS_ZERO(f2))
		*this = exception(dbz, f2.is_neg ? -f1 : f1);
	else if (IS_INF(f1))
		*this = f1.is_neg == f2.is_neg ? pinf : ninf;
	else if (IS_INF(f2))
		*this = f1.is_neg == f2.is_neg ? zero : nzero;
	else
		normalize(f1.exp - f2.exp + BIAS,
			((f1.lf() << P) / f2.lf()) << P);
	return *this;	
	}

fp& fp::add(const fp& f1, const fp& f2)
	{	// set this object to sum of f1 and f2
	if (IS_NAN(f1))
		*this = f1;
	else if (IS_NAN(f2))
		*this = f2;
	else if (IS_INF(f1) && IS_INF(f2) && f1.is_neg != f2.is_neg)
		*this = exception(inv, f1);
	else if (IS_INF(f1))
		*this = f1;
	else if (IS_INF(f2))
		*this = f2;
	else
		{
		long fracr = f1.lf() << P;
		if (f1.exp - f2.exp < P + 2)
			fracr += ((f2.lf() << P) >> (f1.exp - f2.exp));
		normalize(f1.exp, fracr);
		}
	return *this;	
	}

void fp::convert(double d)
	{	// convert double to fp object
	int e;
	double f = frexp(d, &e);
	if (f == 0.0)
		{	// handle zero specially
		exp = 0;
		frac = 0;
		is_neg = false;
		}
	else
		normalize(e + BIAS, long(f * (1L << P)) << P);
	}

fp& fp::normalize(int e, long fr)
	{	// set this object to normalized value of
		// exponent e and fraction fr
	if (fr == 0)
		{	// handle zero specially
		exp = 0;
		frac = 0;
		return *this;
		}
	is_neg = fr < 0;
	fr = abs(fr);
	if ((ONE << P) <= fr)
		{	// handle fraction overflow
		fr >>= 1;
		++e;
		}
	else
		while (fr < (MIN_NORM << P))
			{	// scale left
			fr <<= 1;
			--e;
			}
	bool inx = round(fr);
	if ((ONE << P) <= fr)
		{	// handle fraction overflow
		fr >>= 1;
		++e;
		}
	if (e < MIN_EXP)
		*this = inx ? exception(exu, fp(e - BIAS + 192, fr >> P, is_neg))
			: fp(0 - BIAS, fr >> (P - e), is_neg);
	else if (MAX_EXP <= e)
		*this = exception(exo, fp(e - BIAS - 192, fr >> P, is_neg));
	else if (inx)	
		*this = exception(ine, fp(e - BIAS, fr >> P, is_neg));
	else	
		*this = fp(e - BIAS, fr >> P, is_neg);
	return *this;
	}

inline long low_bits(long fr)
	{
	return fr & ((1L << P) - 1);
	}

bool fp::round(long& fr)
	{	// round infinite-precision result to fit representation
	bool inx = low_bits(fr) != 0;
	switch (rm)
		{	// select appropriate code for rounding mode
		case rm_zero:
			// empty
			break;
		case rm_up:
			if (!is_neg && low_bits(fr))
				fr += 1L << P;
			break;
		case rm_down:
			if (is_neg && low_bits(fr))
				fr += 1L << P;
			break;
		case rm_nearest:
			if ((fr & (1L << (P - 1))) == 0)
				;
			else if (low_bits(fr) == (1L << (P - 1))
				&& ((fr & (1L << P)) == 0))
				;
			else	
				fr += 1L << P;
			break;
		}
	return inx;
	}

std::ostream& operator << (std::ostream& out, const fp& f)
	{	// insert into stream
	double d;
	if (IS_NAN(f))
		return out << "NaN " << to_string(f);
	else if (IS_INF(f))
		return out << (f.is_neg ? "-" : "") << "Inf " << to_string(f);
	else if (IS_ZERO(f))
		return out << (f.is_neg ? "-" : "") << "0 " << to_string(f);
	else
		{	// convert non-zero value to double
		d = f.frac;
		d /= (1 << P);
		int e = f.exp - BIAS;
		if (e == 0)
			;
		else if (e < 0)
			for (int i = 0; i < -e; ++i)
				d /= 2;
		else	
			for (int i = 0; i < e; ++i)
				d *= 2;
		if (f.is_neg)
			d = -d;
		}
	return out << d << ' ' << to_string(f);
	}

std::string to_string(const fp& f)
	{	// convert to text representation of internal data
	std::ostringstream str;
	str << '(' << (f.is_neg ? "-," : "+,")
		<< (int)(f.exp - BIAS) << ','
		<< std::hex << f.frac << std::dec << ')';
	return str.str();
	}

fp::round_mode fp::rm = fp::rm_nearest;

void fp::set_flag(fp_exception except)
	{
	exc_flg |= except;
	}

bool fp::get_flag(fp_exception except)
	{
	return (exc_flg & except) != 0;
	}

void fp::clear_flags()
	{
	exc_flg = 0;
	}

void fp::set_flags(int flg)
	{
	exc_flg = flg & 0xff;
	}

int fp::get_flags()
	{
	return exc_flg;
	}

fp fp::exception(fpx except, fp arg)
	{	// handle floating point exceptions
	return exc_hndlrs[except]((fp_exception)(1 << except), arg);
	}

const fp fp::pinf(MAX_EXP - BIAS, 0, false);
const fp fp::ninf(MAX_EXP - BIAS, 0, true);
const fp fp::qnan(MAX_EXP - BIAS, QF, false);
const fp fp::snan(MAX_EXP - BIAS, SF, false);
const fp fp::pmax(MAX_EXP - BIAS - 1, 0x7fff, false);
const fp fp::nmax(MAX_EXP - BIAS - 1, 0x7fff, true);
const fp fp::nzero(0 - BIAS, 0, true);

fp fp::ex_dbz(fp::fp_exception except, fp arg)
	{
	set_flag(except);
	return arg.is_neg ? ninf : pinf;
	}

fp fp::ex_exu(fp::fp_exception except, fp arg)
	{
	set_flag(except);
	int ex = arg.exp - BIAS - 192;
	int fr = arg.frac >> (BIAS - ex);
	return fp(0 - BIAS, fr, arg.is_neg);
	}

fp fp::ex_exo(fp::fp_exception except, fp arg)
	{
	set_flag(except);
	return rm == rm_nearest
			? arg.is_neg ? ninf : pinf
		: rm == rm_zero
			? arg.is_neg ? nmax : pmax
		: rm == rm_down
			? arg.is_neg ? ninf : pmax
			: arg.is_neg ? nmax : pinf;
	}

fp fp::ex_ine(fp::fp_exception except, fp arg)
	{
	set_flag(except);
	return arg;
	}

fp fp::ex_inv(fp::fp_exception except, fp)
	{
	set_flag(except);
	return qnan;
	}

static fp def_dbz(fp::fp_exception except, fp arg)
	{
	return fp::ex_dbz(except, arg);
	}

static fp def_exu(fp::fp_exception except, fp arg)
	{
	return fp::ex_exu(except, arg);
	}

static fp def_exo(fp::fp_exception except, fp arg)
	{
	return fp::ex_exo(except, arg);
	}

static fp def_ine(fp::fp_exception except, fp arg)
	{
	return fp::ex_ine(except, arg);
	}

static fp def_inv(fp::fp_exception except, fp arg)
	{
	return fp::ex_inv(except, arg);
	}

fp::exc_hnd fp::set_handler(fp::fp_exception except, fp::exc_hnd hnd)
	{
	exc_hnd prev = exc_hndlrs[except];
	exc_hndlrs[except] = hnd ? hnd : def_hndlrs[except];
	return prev == def_hndlrs[except] ? 0 : prev;
	}

fp::exc_hnd fp::get_handler(fp_exception except)
	{
	return exc_hndlrs[except] == def_hndlrs[except]
		? 0 : exc_hndlrs[except];
	}

fp::exc_hnd fp::exc_hndlrs[EXC_COUNT] =
	{ def_dbz, def_exu, def_exo, def_ine, def_inv };

const fp::exc_hnd fp::def_hndlrs[EXC_COUNT] =
	{ def_dbz, def_exu, def_exo, def_ine, def_inv };

unsigned char fp::exc_flg;

const fp fp::zero(0.0);
const fp fp::one(1.0);
const fp fp::two(2.0);
