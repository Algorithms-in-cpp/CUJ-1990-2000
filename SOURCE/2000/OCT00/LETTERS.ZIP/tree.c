void
tree_depth_traversal1 (struct t_node *root,
   void (*process)(struct t_node *node,
      int first_flag))
{
   // TRUE: 1st exploration of node,  
   //    continue with 1st subnode
   // FALSE: node completely explored, 
   //    continue with sibling
   int dir_flag = TRUE;

   // the current node during exploration
   struct t_node *current = root;

   // the node that signifies when to stop 
   // traversing
   struct t_node *stop = NULL;

   //----- no tree or no user function , 
   // nothing to do
   if ((root == NULL) || (process == NULL)) 
      return;

   // We should stop when 
   // current = the root's parent
   stop = get_parent(root);

   //----- the exploration loop
   while (current != stop)
   {
      // ASSERT (node_exist(current));

      //--- process the node : 
      // TRUE prefix, FALSE postfix
      (* process) (current, dir_flag);

      //--- 1st expl. of the node, 
      // continue with 1st subnode
      // or stay for 2nd part of 
      // the process
      if (dir_flag == TRUE)
      {
         if (has_sub(current))
            current = get_sub(current);
         else
            // 1st exploration of 
            // current node is finished
            // go to 2nd exploration of 
            // the current node
            dir_flag = FALSE;
      }
      else
      {
         if (has_sibling(current))
         {
            // goto 1st exploration of 
            // the sibling (now current)
            current = 
               get_sibling(current);

            dir_flag = TRUE;
         }
         else
            current = get_parent(current);
      }
   }
   // ASSERT ((current == stop) && 
   //       (dir_flag == FALSE));
}



