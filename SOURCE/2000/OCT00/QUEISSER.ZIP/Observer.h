class Subject;

class Observer {
public:
   Observer();
   virtual ~Observer();
   virtual void 
   Update(Subject *changedSubject)=0;
};

class Subject {
   std::list<Observer *> observers;
public:
   Subject();
   virtual ~Subject();
   virtual void Attach(Observer *obs);
   virtual void Detach(Observer *obs);
   virtual void Notify();
};
