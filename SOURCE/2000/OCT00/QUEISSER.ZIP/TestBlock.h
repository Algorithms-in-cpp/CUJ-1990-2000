#include "NamedVal.h"
class TestBlock : public IOParamBlock {
public:
   DECL_NAMED_VAL(int, autoInt);
   DECL_NAMED_VAL(double, autoFloat);
   TestBlock() : 
      CONSTRUCT_AUTOIO_VAL(autoInt, 22),
      CONSTRUCT_AUTOIO_VAL(autoFloat, 1122.33) {}
};

void bar() {
   TestBlock tst;
   SimpleDB fakeDB;

   tst.ReadAll(fakeDB,  "SomeSection");
   tst.WriteAll(fakeDB, "SomeSection");
}
