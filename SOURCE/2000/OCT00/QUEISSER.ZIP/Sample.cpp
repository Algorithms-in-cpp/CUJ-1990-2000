#include <NamedVal.h>
#include <iostream.h>
using namespace std;

struct StructWithNamedVal {
   DECL_NAMED_VAL(int,intMember);
   DECL_NAMED_VAL(double,doubleMember);
   StructWithNamedVal() : CONSTRUCT_NAMED_VAL_I(intMember,555),
      CONSTRUCT_NAMED_VAL_I(doubleMember,345.678) {}
};

void foo() {
   // Define NamedVal, with and without initial values
   DEF_NAMED_VAL(int, PartCount);
   DEF_NAMED_VAL_I(double, Pressure, 23.5);

   // dynamically allocated NamedVal
   DECL_NAMED_VAL(bool, * Active);
   NEW_NAMED_VAL_I(bool, Active, true);

   // assigning to and from and displaying a NamedVal
   double x = Pressure;
   Pressure = 123.45;
   cout<<"name "<<Pressure.Name()<<" val "<<Pressure<<endl;

   // NamedVals in structures work as expected
   StructWithNamedVal bar;
   bar.intMember = 23;
}
