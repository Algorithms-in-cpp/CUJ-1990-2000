// (C) 2000, Fernando Luis Cacciola Carballal.
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
// You are welcome to contact the author at: fcacciola@fibertel.com.ar

// This variant copies the original
// value into its own data to
// preserve the value when the
// original variable goes out of scope.
struct variant1_t
{
   variant1_t():data(NULL){}
  ~variant1_t(){ free(data); }

  template<typename T> variant1_t ( T v )
    :data(malloc(sizeof(T)))
    { memcpy ( data , &v , sizeof(T)); }

  template<typename T> operator T () const
    { return * reinterpret_cast<T*>(data); }

  void* data ;
} ;

/* Sample use:

variant1_t _int ( 2 ) ;
variant1_t _dbl ( 3.14 ) ;
cout << (int)   _int << endl ;
cout << (double)_dbl << endl ;
*/