// (C) 2000, Fernando Luis Cacciola Carballal.
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
// You are welcome to contact the author at: fcacciola@fibertel.com.ar

#ifndef VARIANT_H
#define VARIANT_H

// Class variant_t
// Encapsulates a value of arbitrary type.
// It can be constructed with values of any type without
// explicit casting. Its value can be retrieved by
// converting it to a copy of apropriate type.
// If an attempt is made to convert it to a type other than
// the type used with the constructor, invalid_argument is
// thrown.
// variant_t objects can be efficiently and safely copied
// without loosing the value and type.
//
// Mar 2000, Fernando Luis Cacciola Carballal.
//
class variant_t
{
  public :

   variant_t() : data ( NULL ) {}
   variant_t( const variant_t & rhs )
     { if ( rhs.data != NULL )
         rhs.data->AddRef() ;
       data = rhs.data ;
     }
  ~variant_t()
     { if ( data != NULL )
         data->Release() ;
     }
   // NOTE: This code takes care of self-asignment.
   // DO NOT CHANGE THE ORDER of the statements.
   variant_t& operator = ( const variant_t& rhs )
     {
       if ( rhs.data != NULL )
         rhs.data->AddRef();
       if ( data != NULL )
         data->Release();
       data = rhs.data ;
       return * this ;
     }

  // This member template constructor allows you to
  // instance a variant_t object with a value of any type.
  template<typename T> variant_t ( T v )
    : data ( new Impl<T>(v) )
    { data->AddRef() ; }

  // This generic conversion operator let you retrieve
  // the value held.
  // To avoid template specialization conflicts, it
  // returns an instance of type T, which will be a COPY
  // of the value contained.
  template<typename T> operator T () const
    { return CastFromBase<T>( data )->data ; }

  // With expressions of the form: int a = my_variant ,
  // the compiler needs to take the template argument T
  // from the type of the left side of the assigment.
  // Most compilers won't do that, so you might need this
  // non-operator form, as in:
  // int a = my_variant.get<int>();
  // This forms returns a REFERENCE and not a COPY, which
  // will be significant in some cases.
  template<typename T> const T & get() const
    { return CastFromBase<T>( data )->data ; }

  // This method can be used to test if this variant_t
  // holds a value of type T. It takes no arguments,
  // so it can only be used with a explicit template
  // instancing:
  //   variant_t var(3) ; if ( var.is_type<int>() ) ...
  template<typename T> bool is_type() const
    { return typeid(*data)==typeid(Impl<T>); }

  // This method can be used to test if this variant_t
  // holds a value of type T.
  // It takes one argument, so it can be used with
  // a test variable of the desired type:
  //   int n=3; variant_t var(n) ;
  //   if ( var.is_type(n) ) ...
  template<typename T> bool is_type(T v) const
    { return typeid(*data)==typeid(v); }

  private :

    // This base class provides polymorphism to Impl<>, due
    // to the virtual destructor.
    // It implements the reference counting over Impl<>.
    struct ImplBase
    {
      ImplBase() : refs ( 0 ) {}
      virtual ~ImplBase() {}
      void AddRef () { refs ++ ; }
      void Release() { refs -- ;
                       if ( refs == 0 )
                         delete this ;
                     }
      size_t refs ;
    } ;

    // An instance of Impl<T> is just a straight copy of a
    // value of type T, but re-typed as a polymorphic type.
    // As long as the copy constructor for T is properly
    // implemented, the value will be properly copied.
    template<typename T>
    struct Impl : ImplBase
    {
       Impl ( T v ) : data ( v ) {}
      ~Impl () {}
      T data ;
    } ;

    // The following 2 methods are static because they don't
    // operate on variant_t instances.
    template<typename T>
    static ImplBase* CastToBase ( Impl<T>* v )
      { return v ; } // Implicit convertion here

    template<typename T>
    static Impl<T>* CastFromBase ( ImplBase* v )
    {
      // This upcast will fail if T is other than the T used
      // with the constructor of variant_t.
      Impl<T>* p = dynamic_cast<Impl<T>*> ( v ) ;
      if ( p == NULL )
        throw invalid_argument
         ( typeid(T).name()+string(" is not a valid type"));
      return p ;
    }

    ImplBase* data ;
} ;

#endif
