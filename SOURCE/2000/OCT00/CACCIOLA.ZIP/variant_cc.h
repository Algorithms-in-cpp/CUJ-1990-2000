// (C) 2000, Fernando Luis Cacciola Carballal.
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
// You are welcome to contact the author at: fcacciola@fibertel.com.ar

#ifndef VARIANT_CC_H
#define VARIANT_CC_H

// Class variant_cc_t
// This is a variation of variant_t.
// It implements a 'copy on copy' scheme: that is,
// each time a variant_cc_t is copied it internal
// data is copied too.
// This avoids the shared implementation at the cost of
// copying the value held.
//
// Those portions of this code which differ from variant_t
// have a comment.
//
// Mar 2000, Fernando Luis Cacciola Carballal.
//
class variant_cc_t
{
  public :

    variant_cc_t() : data ( NULL ) {}

    // * Copy the internal data instead of sharing it.
    variant_cc_t( const variant_cc_t & rhs )
      : data ( rhs.data != NULL ? rhs.data->clone()
                                : NULL
             )
      {}

    // No need to test for concurrent users.
   ~variant_cc_t()
      { delete data ; }

    // * Copy the internal data instead of sharing it.
    variant_cc_t& operator = ( const variant_cc_t& rhs )
      {
        if ( data != rhs.data )
        {
          delete data ;
          data = ( rhs.data != NULL ? rhs.data->clone()
                                    : NULL
                 ) ;
        }
        return * this ;
      }

    template<typename T> variant_cc_t ( T v )
      : data ( new Impl<T>(v) )
      {}

    template<typename T> operator T () const
      { return CastFromBase<T>( data )->data ; }

    template<typename T> const T & get() const
      { return CastFromBase<T>( data )->data ; }

    template<typename T> bool is_type() const
      { return typeid(*data)==typeid(Impl<T>); }

    template<typename T> bool is_type(T v) const
      { return typeid(*data)==typeid(v); }

  private :

    // This version has a clone() method so copies
    // of particular Impl<> can be obtained.
    struct ImplBase
    {
      ImplBase() {}
      virtual ~ImplBase () {}
      virtual  ImplBase* clone() const = 0 ;
    } ;

    // The clone() is implemented here.
    template<typename T>
    struct Impl : ImplBase
    {
       Impl ( T v ) : data ( v ) {}
       virtual ~Impl () {}
       virtual ImplBase* clone() const { return new Impl<T>(data) ; }
      T data ;
    } ;

    template<typename T>
    static Impl<T>* CastFromBase ( ImplBase* v )
    {
      Impl<T>* p = dynamic_cast<Impl<T>*> ( v ) ;
      if ( p == NULL )
        throw invalid_argument
         ( typeid(T).name()+string(" is not a valid type"));
      return p ;
    }

    ImplBase* data ;
} ;

#endif
