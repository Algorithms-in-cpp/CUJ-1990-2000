// (C) 2000, Fernando Luis Cacciola Carballal.
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
// You are welcome to contact the author at: fcacciola@fibertel.com.ar

#ifndef ARGLIST_H
#define ARGLIST_H

#include<vector>

#include"variant.h"

// Class ArgumentList.
// Adapts a vector<variant_t> for use as an argument list.
// Arguments can only be added at the end of the list.
// They cannot be removed.
// They can be randomly accesed using at() or operator[].
//
class ArgumentList
{
  public:

    // Ctor,Dtor,CopyCtor, and Assign ommited
    // becuase the defaults are apropriate.

    template<typename T> void push_back ( T Value )
      { _container.push_back ( variant_t ( Value ) ) ; }

    // NOTE: This returns a COPY of the value at pos idx.
    template<typename T> T operator [] ( size_t idx ) const
      { return _container [ idx ] ; }

    // With expressions of the form: int a = arglist[0] ,
    // the compiler needs to take the template argument
    // T from the type of the left side of the assigment.
    // Most compilers won't do that, so you might need
    // this non-operator form, as in:
    //   int a = arglist.at<int>(0);
    // This form returns a REFERENCE and not a COPY.
    template<typename T> const T & at ( size_t idx ) const
      { return _container [ idx ].get<T>() ; }

    bool   empty() const { return _container.empty(); }
    size_t size () const { return _container.size (); }

  private:
    std::vector<variant_t> _container ;
} ;

#endif
