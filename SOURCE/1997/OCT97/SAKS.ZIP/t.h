//
// t.h -- a template for subobjects
//

#include <iostream>
using namespace std;

template <char c>
class T
    {
public:
    T();
    T(T const &);
    T &operator=(T const &);
    };

template <char c>
T<c>::T()
    {
    cout << c << "'s default constructor\n";
    }

template <char c>
T<c>::T(T const &)
    {
    cout << c << "'s copy constructor\n";
    }

template <char c>
T<c> &T<c>::operator=(T const &)
    {
    cout << c << "'s copy assignment\n";
    return *this;
    }
