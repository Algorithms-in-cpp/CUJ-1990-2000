#include <iostream>
using namespace std;

#include "t.h"

typedef T<'B'> B;
typedef T<'M'> M;
typedef T<'N'> N;

class D : public B
    {
public:
    D();
    D(D const &d);
    D &operator=(D const &d);
private:
    M m;
    N n;
    };

D::D()
    {
    }

D::D(D const &d)
    {
    }

D &D::operator=(D const &d)
    {
    return *this;
    }

int main()
    {
    D d1;
    D d2(d1);
    d1 = d2;
    return 0;
    }
