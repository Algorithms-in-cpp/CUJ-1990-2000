#include <iostream>
using namespace std;

#include "t.h"

typedef T<'B'> B;
typedef T<'M'> M;
typedef T<'N'> N;

class D : public B
    {
private:
    M m;
    N n;
    };

int main()
    {
    D d1;
    D d2(d1);
    d1 = d2;
    return 0;
    }
