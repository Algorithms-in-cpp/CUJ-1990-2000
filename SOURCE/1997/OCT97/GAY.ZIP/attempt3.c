class PrintDialog {
   Widget okButton;
   Widget cancelButton;
   Widget printerList;

   char *printerName;

public:
    PrintDialog(Widget parent);

    static void okCallback(Widget,
                           XtPointer,
                           XtPointer);
};

PrintDialog::PrintDialog(Widget parent)
{
    ...
    okButton = XmCreatePushButton(parent,
                                  "OK",
                                  NULL,
                                  0);
    XtAddCallback(okButton,
                  XmNactivateCallback,
                  okCallback,
                  (XtPointer)this);
    ...
}

void PrintDialog::okCallback(Widget w,
                             XtPointer user_data,
                             XtPointer call_data)
{
    PrintDialog *pd = (PrintDialog *)user_data;

    cout << "Selected Printer: " << pd->printerName << endl;
}

int main()
{
    ...
    PrintDialog *pd = new PrintDialog(parent);
    ...
}
