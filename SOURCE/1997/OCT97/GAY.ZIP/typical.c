Widget okButton;

void okCallback(Widget,
                XtPointer,
                XtPointer)
{
// do something about "OK"
}

int main()
{
...
okButton = XmCreatePushButton(parent,
              "OK", NULL, 0);
XtAddCallback(okButton,
              XmNactivateCallback,
              okCallback, NULL);
...
}
