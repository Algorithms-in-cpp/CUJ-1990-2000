// Callback.h

#ifndef _CALLBACK_H_
#define _CALLBACK_H_

void registerCallback(void *);

template <class T>
struct CallbackInfo {
    typedef void (T::*p_func)(Widget, XtPointer, XtPointer);

    T *obj;
    p_func func;
    Widget w;
    _XtString cbType;
    XtPointer udata;
};

template <class T>
void addCallback(T *obj,
                 void (T::*t_func)(Widget, XtPointer, XtPointer),
                 Widget w,
                 _XtString type,
                 XtPointer udata)
{
    CallbackInfo<T> *ci = new CallbackInfo<T>;

    ci->obj    = obj;
    ci->func   = t_func;
    ci->w      = w;
    ci->cbType = type;
    ci->udata  = udata;

    registerCallback((void *)ci);
}

#endif
