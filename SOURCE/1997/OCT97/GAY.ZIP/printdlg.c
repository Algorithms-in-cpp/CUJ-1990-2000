//
// Note that we don't need any
// static functions, pointer
// passsing, or casting on
// anything.

#include "Callback.h"

class PrintDialog {
   Widget okButton;
   Widget cancelButton;
   Widget printerList;

   char *printerName;

public:
    PrintDialog(Widget parent);

    void okCallback(Widget,
                    XtPointer,
                    XtPointer);
};

PrintDialog::PrintDialog(Widget parent)
{
    ...
    okButton = XmCreatePushButton(parent,
                                  "OK",
                                  NULL,
                                  0);
    addCallback(this,
                okCallback, okButton,
                XmNactivateCallback
                NULL);
    ...
}

void PrintDialog::okCallback(Widget w,
                             XtPointer user_data,
                             XtPointer call_data)
{

    cout << "Selected Printer: " << printerName << endl;
}

int main()
{
    ...
    PrintDialog *pd = new PrintDialog(parent);
    ...
}
