class PrintDialog {
   Widget okButton;
   Widget cancelButton;
   Widget printerList;

   char *printerName;

public:
    PrintDialog(Widget parent);

    static void okCallback(Widget,
                           XtPointer,
                           XtPointer);
};

PrintDialog::PrintDialog(Widget parent)
{
    ...
    okButton = XmCreatePushButton(parent,
                                  "OK",
                                  NULL,
                                  0);

    XtAddCallback(okButton,            // <-- This compiles
                  XmNactivateCallback,
                  okCallback,
                  NULL);
    ...
}

void PrintDialog::okCallback(Widget w,
                             XtPointer user_data,
                             XtPointer call_data)
{
    cout << "Selected Printer: "
         << printerName << endl;     // <--- But this doesn't
}

int main()
{
    ...
    PrintDialog *pd = new PrintDialog(parent);
    ...
}
