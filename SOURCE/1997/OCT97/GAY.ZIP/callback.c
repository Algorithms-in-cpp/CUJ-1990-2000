// Callback.C

static void    callbackHandler(Widget, XtPointer, XtPointer);

/* fake object */
class FakeObj;

typedef void (FakeObj::*p_func)(Widget, XtPointer, XtPointer);

typedef CallbackInfo<FakeObj> FakeCallbackInfo;

void callbackHandler(Widget w, XtPointer udata, XtPointer cdata)
{

   FakeCallbackInfo *ci = (FakeCallbackInfo *)udata;

   FakeObj *obj = ci->obj;
   p_func mf    = ci->func;

   (obj->*(mf))(w, ci->udata, cdata);
}

void registerCallback(void *info)
{
   if (info == NULL) return;

   FakeCallbackInfo *ci = (FakeCallbackInfo *) info;

   /* install handler */
   XtAddCallback(ci->w,
                 ci->cbType,
                 (XtCallbackProc)callbackHandler,
                 (XtPointer)info);
}
