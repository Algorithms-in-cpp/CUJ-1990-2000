//
// File: ActiveQueueWithTimeout.h
//
// Created: February 1997
//
// Author: Dr. Thomas Becker
//
// Declaration and member function definitions for template
// class CActiveQueueWithTimeout.

// Protect against multiple inclusion
//
#ifndef __ACTIVE_QUEUE_WITH_TIMEOUT_H_INCLUDED__
#define __ACTIVE_QUEUE_WITH_TIMEOUT_H_INCLUDED__

// Includes
// ========

#include<windows.h>
#include<process.h>
#include<crtdbg.h>
#include"Win32Exceptions.h"

#if _WIN32_WINNT >= 0x0400
  #include"..\Timers\WaitableTimer.h"
#else
  #include"..\timers\WaitableTimerSubst.h"
#endif

///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
class CActiveQueueWithTimeout
//
// The CActiveQueueWithTimout class template realizes a 
// thread-safe queue that is administered by an agent thread 
// and allows timing out of elements that have already been 
// placed into the queue. 
//
// The first template argument indicates the type of the queue
// elements, the second one indicates the length of the queue.
// 
// The constructor takes as its first mandatory argument the
// number of worker threads that will be retrieving elements
// from the queue. If this number is less than the actual
// number of worker threads, the Retrieve member function will
// throw a CWin32Exception with error code 298L
// (ERROR_TOO_MANY_POSTS). If this exception is caught and
// ignored, the queue will operate, but it will allow only
// the specified number of worker threads to operate on queue
// elements simultaneously.
//
// The second mandatory argument to the constructor is a
// function pointer of type void (*)(T&), where T is the
// type of the queue elements. This function will be called
// on elements that are removed from the queue because their
// timeout interval has elapsed. Typically, this function
// reconnects a communications device such as a named pipe.
//
// The third argument to the constructor is optional. It is
// the handle to an exit event. Setting this event will cause
// the Insert and Retrieve member functions to return 
// immediately and terminate the agent thread. This event 
// handle can also be specified later by means of the 
// SetHandleToExitEvent member function. The 
// CActiveQueueWithTimeout destructor will of course also 
// terminate the agent thread.
//
// The Start member function starts the agent thread that
// administers the queue. This function must be called 
// before the first call to the Insert and Retrieve member
// function. The Start member function will also check the
// handles that were created by the constructor and throw
// CWin32Exceptions in case something went wrong.
//
// The Insert member function inserts an element into the 
// queue. This is the function that is typically called by
// a listening thread. Such a thread accepts clients from a 
// communications device and then places in the queue a pointer
// or an array index that identifies e.g. a socket descriptor 
// or a pipe handle. Elements are always copied into the queue;
// therefore, the element type must possess a public copy 
// constructor if it is a user-defined class. The Insert member
// function takes two timeout values as arguments: the timeout
// for the element once it has entered the queue, and the 
// timeout for the Insert member function itself if it has
// to wait because the queue is full.
//
// The Retrieve member function retrieves an element from 
// the queue. This is the function that is typically called
// by worker threads to retrieve a pointer or an array index
// leading to a communications device.
//
// The GetQueueAgentThread member function returns a handle
// to the agent thread that administers the queue, so that
// a supervising thread can watch it.
//
// All CActiveQueueWithTimeout member functions throw
// CWin32Exceptions if Win32 errors are encountered.
// The agent thread terminates with the last error code
// as its return value if it encounters a Win32 error.
//
{

  /////////////////////////////////////////////////////////////
  //
  // Implementation of CActiveQueueWithTimeout: 
  // Member Variables
  //
  /////////////////////////////////////////////////////////////
  
  // The queue: array of T's.
  //
  T m_aTheQueue[dwLEN] ;
  
  // Index of first empty slot in queue. This is where new 
  // elements will be inserted.
  //
  DWORD m_dwFirstEmptySlot ;
  
  // Flag for state of queue: empty or not
  BOOL m_bQueueEmpty ;
  
  // Variables for communication between outside threads that
  // call Insert/Retrieve and the queue agent.
  //
  T m_cInsertElement ;
  DWORD m_dwTimeout ;
  T m_cRetrieveElement ;
  
  // Number of worker threads that will be retrieving from
  // the queue.
  //
  DWORD m_dwNumWorkerThreads ;
  
  // Array of timers corresponding to queue elements. Note:
  // The constructor does not throw any exceptions. Exceptions
  // are thrown by the Start, Set and Cancel member functions 
  // if anything went wrong during construction.
  //
#if _WIN32_WINNT >= 0x0400
  CWaitableTimer m_ahTimers[dwLEN] ;
#else
  CWaitableTimerSubst m_ahTimers[dwLEN] ;
#endif

  // Array of DWORDS that establishes the current 
  // correspondence between queue elements and timers: the 
  // index of the timer for the queue element with index i is 
  // m_adwQueueElementsToTimers[i].
  //
  DWORD m_adwQueueElementsToTimers[dwLEN] ;
  
  // Pointer to function that deals with timed out queue
  // element. In a typical client-server application, this
  // function would have to reconnect the communications 
  // device.
  //
  void (*m_DealWithTimedOutElement)(T&) ;
  
  // Handles for synchronization of inserting in queue
  //
  HANDLE m_hSemAvailableSlotsInQueue ;
  HANDLE m_hEvNewElementWantsInQueue ;
  HANDLE m_hEvRogerToInsert ;
  
  // Handles for synchronization of removal from queue
  //
  HANDLE m_hSemAvailableWorkerThreads ;
  HANDLE m_hEvElementAvailable ;
  HANDLE m_hEvRogerToQueueAgent ;

  // Handle for mutex to protect insertion of new element.
  // We use a mutex because we want timeouts.
  //
  HANDLE m_hInsertMutex ;

  // Handle of queue agent thread
  HANDLE m_hQueueAgentThread ;
  
  // Handle used by the queue agent thread to signal that it's 
  // running
  //
  HANDLE m_hEvAgentRunning ;

  // Exit event for queue agent thread
  HANDLE m_hExitEvent ;

  // Internal exit event for queue agent thread
  HANDLE m_hAgentExitEvent ;

  // Thread function for agent. This must be static, will get
  // this-pointer as argument.
  //
  static UINT __stdcall QueueAgentThread(
    CActiveQueueWithTimeout<T, dwLEN>*
    ) ;

  /////////////////////////////////////////////////////////////
  //
  // Interface of CActiveQueueWithTimeout
  //
  /////////////////////////////////////////////////////////////
  
public:    
  
  // Return values from functions that perform wait operations.
  //
  enum waitResult
  {
    waitTimeout,
    waitExitEvent,
    waitSuccess
  } ;
 
  // Constructs a CActiveQueueWithTimeout object.
  //
  CActiveQueueWithTimeout(
    DWORD dwNumWorkerThreads,
    void (*)(T&),
    HANDLE hExitEvent = NULL) ;

  // Destruction
  //
  ~CActiveQueueWithTimeout() ;

  // Set exit event
  //
  void SetHandleToExitEvent(HANDLE hExitEvent)
  {
    m_hExitEvent = hExitEvent ;
  }
  
  // Starts the queue.
  //
  waitResult Start(
    DWORD dwMilliseconds = INFINITE
    ) ;

  // Returns a handle to the queue agent thread. This is 
  // guaranteed to be meaningful only after the Start member 
  // function has been called. The handle is closed by the
  // destructor.
  //
  HANDLE GetQueueAgentThread()
  {
    return m_hQueueAgentThread ;
  }

  // Inserts an element into the queue.
  //
  waitResult Insert(
    const T& refNewEntry,
    DWORD dwMillisecondsInQueue,
    DWORD dwMilliseconds
    ) ;

  // Retrieves an element from the queue.
  //
  waitResult Retrieve(
    T& refToLocation,
    DWORD dwMilliseconds
    ) ;

} ;


///////////////////////////////////////////////////////////////
//
// Implementation of CActiveQueueWithTimeout member functions
//
///////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
CActiveQueueWithTimeout<T, dwLEN>::CActiveQueueWithTimeout( 
//
// The constructor creates the synchronization objects and 
// initializes the member variables. To avoid exceptions from
// constructors, no error check is made on the Create... APIs.
// The Start member function will throw an exception if the 
// handles are NULL.
//
//
DWORD dwNumWorkerThreads, // number of working threads
//
// Indicates the number of worker threads that will be 
// retrieving from the queue. If this number is less than the
// actual number of worker threads, the Retrieve member 
// function will throw a CWin32Exception with error code 298L
// (ERROR_TOO_MANY_POSTS). If this exception is caught and
// ignored, the queue will operate, but it will allow only
// the specified number of worker threads to operate on queue
// elements simultaneously.
//
//
void (*DealWithTimedOutElement)(T&), // function pointer
//
// Points to the function that is to be applied to elements
// that are timed out of the queue.
//
HANDLE hExitEvent // = NULL exit event
//
// Indicates the handle of the event that causes the agent 
// thread to terminate and the member functions to return 
// immediately.  This handle can be set later by means of the
// SetHandleToExitEvent member function. However, the handle
// must be set to a valid event handle before the Start 
// member function is called.
// 
) : m_dwNumWorkerThreads(dwNumWorkerThreads),
    m_DealWithTimedOutElement(DealWithTimedOutElement),
    m_hExitEvent(hExitEvent),
    m_dwFirstEmptySlot(0),
    m_bQueueEmpty(TRUE)
//
{
  
  // Auxiliaries
  UINT uiThreadId ;

  // Create the semaphore that counts the free slots in the 
  // queue. The Insert member function waits for this semaphore
  // when it tries to insert an element into the queue.
  //
  m_hSemAvailableSlotsInQueue = CreateSemaphore(
    NULL,	// pointer to security attributes 
    dwLEN,	// initial count 
    dwLEN,	// maximum count 
    NULL	// pointer to semaphore-object name  
   ) ;

  // Create the event that the Insert member function uses to 
  // signal to the queue agent that it wants to insert a new 
  // element in the queue.
  //
  m_hEvNewElementWantsInQueue = CreateEvent(
    NULL,	// pointer to security attributes  
    FALSE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );
  
  // Create the event that the the queue agent uses to signal 
  // to the Insert member function that it has received the
  // information necessary to insert the new member.
  //
  m_hEvRogerToInsert = CreateEvent(
    NULL,	// pointer to security attributes  
    FALSE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );
  
  // Create the semaphore that counts the available worker 
  // threads. The queue agent waits for this semaphore when 
  // the queue is not empty.
  //
  m_hSemAvailableWorkerThreads = CreateSemaphore(
    NULL,	// pointer to security attributes 
    0,	// initial count 
    m_dwNumWorkerThreads,	// maximum count 
    NULL	// pointer to semaphore-object name  
   );

  // Create the event that the queue agent uses
  // to signal to the worker threads that there are 
  // elements to be retrieved.
  //
  m_hEvElementAvailable = CreateEvent(
    NULL,	// pointer to security attributes  
    FALSE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );
  
  // Create the event that the the worker threads use
  // to signal to the queue agent that they have 
  // read the element information from the communication
  // buffer.
  //
  m_hEvRogerToQueueAgent = CreateEvent(
    NULL,	// pointer to security attributes  
    FALSE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );
  
  // Create mutex to protect insertion of new element.
  // We use a mutex because we want timeouts.
  //
  m_hInsertMutex = CreateMutex(
    NULL,	// pointer to security attributes 
    FALSE,	// flag for initial ownership 
    NULL 	// pointer to mutex-object name  
    );
  
  // Create the event that the queue agent thread uses to
  // signal that it's running.
  //
  m_hEvAgentRunning = CreateEvent(
    NULL,	// pointer to security attributes  
    TRUE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );
  
  // Create the internal exit event that is used to end
  // the queue agent thread.
  //
  m_hAgentExitEvent = CreateEvent(
    NULL,	// pointer to security attributes  
    TRUE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );
  
  // Create queue agent thread in suspended state. We use
  // _beginthreadex instead of CreateThread in because
  // runtime library functions could be used e.g. by
  // exception constructors.
  //
  m_hQueueAgentThread = (HANDLE) _beginthreadex(
      NULL,	// pointer to thread security attributes  
      0,	// initial thread stack size, in bytes 
      ( UINT (__stdcall *) (LPVOID) ) QueueAgentThread, 
      this,	// argument for new thread 
      CREATE_SUSPENDED,	// creation flags 
      &uiThreadId 	// pointer to returned thread identifier 
      );	

}


///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
CActiveQueueWithTimeout<T, dwLEN>::~CActiveQueueWithTimeout(
//
// The destructor terminates the queue agent thread and closes 
// the handles of the synchronization objects
)
//
{

  // Auxiliaries
  DWORD dwRetVal ;

  try 
  {
    
    // If the handles to the external exit event and the queue
    // agent thread exist, we must stop the queue agent thread.
    //
    if ( NULL != m_hAgentExitEvent 
         &&
         NULL != m_hQueueAgentThread)
    {
      
      // Set internal exit event
      //
      if ( ! SetEvent(m_hAgentExitEvent) ) 
        THROW_WIN32_EXCEPTION ;
      
      // Wait for thread to exit.
      //
      dwRetVal = WaitForSingleObject(
        m_hQueueAgentThread,
        3000
        ) ;
      //
      if ( WAIT_FAILED == dwRetVal ) THROW_WIN32_EXCEPTION ;
      
      // If thread has not exited after 3 secs, try to 
      // terminate brute force. This can happen when the
      // Start function has never been called.
      //
      if ( WAIT_TIMEOUT == dwRetVal
        &&
        ! TerminateThread(m_hQueueAgentThread, 1) )
      {
        THROW_WIN32_EXCEPTION ;
      }
      
      // If the queue agent thread terminated abnormally, it
      // has already thrown a non-propagated exception. No
      // point in throwing again here, because we're in
      // a destructor and cannot propagate.
      
    }
    //
    // End if thread handle and exit event handle were valid    

    if ( NULL != m_hEvAgentRunning )
      CloseHandle(m_hEvAgentRunning) ;
    
    if ( NULL != m_hAgentExitEvent )
      CloseHandle(m_hAgentExitEvent) ;
    
    if ( NULL != m_hQueueAgentThread )
      CloseHandle(m_hQueueAgentThread) ;
    
    if ( NULL != m_hSemAvailableSlotsInQueue )
      CloseHandle(m_hSemAvailableSlotsInQueue) ;
    
    if ( NULL != m_hEvNewElementWantsInQueue )
      CloseHandle(m_hEvNewElementWantsInQueue) ;
    
    if ( NULL != m_hEvRogerToInsert )
      CloseHandle(m_hEvRogerToInsert) ;
    
    if ( NULL != m_hSemAvailableWorkerThreads )
      CloseHandle(m_hSemAvailableWorkerThreads) ;
    
    if ( NULL != m_hEvElementAvailable )
      CloseHandle(m_hEvElementAvailable) ;
    
    if ( NULL != m_hEvRogerToQueueAgent )
      CloseHandle(m_hEvRogerToQueueAgent) ;

    if ( NULL != m_hInsertMutex )
      CloseHandle(m_hInsertMutex) ;

  }
  catch(...) {}

}


///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
CActiveQueueWithTimeout<T, dwLEN>::waitResult 
CActiveQueueWithTimeout<T, dwLEN>::Start(
//
// The Start member function checks if the object handles
// created in the constructor are valid and starts the
// queue agent thread
//
DWORD dwMilliseconds // = INFINITE timeout
//
// Indicates the timeout value in milliseconds or INFINITE.
//
)
//
// Return Value and Exceptions
//
// If the function succeeds, the return value is waitSuccess.
// If a timeout occurs, the return value is waitTimeout.
//
// If the function fails, a CWin32Exception is thrown.
//
{
  
  DWORD dwRetVal ;

  _ASSERT( NULL != m_hExitEvent ) ;
  
  // Check handles because constructor didn't
  //
  if ( NULL == m_hEvAgentRunning 
       ||
       NULL == m_hAgentExitEvent 
       ||
       NULL == m_hQueueAgentThread 
       ||
       NULL == m_hSemAvailableSlotsInQueue
       ||
       NULL == m_hEvNewElementWantsInQueue
       ||
       NULL == m_hEvRogerToInsert
       ||
       NULL == m_hSemAvailableWorkerThreads
       ||
       NULL == m_hEvElementAvailable
       ||
       NULL == m_hEvRogerToQueueAgent
       ||
       NULL == m_hInsertMutex )
  { 
    SetLastError(ERROR_INVALID_HANDLE) ;
    THROW_WIN32_EXCEPTION ;
  }

  // Start queue agent thread
  //
  if ( ! ResumeThread(m_hQueueAgentThread) )
    THROW_WIN32_EXCEPTION ;

  // Wait for thread to signal successful start. This is
  // necessary even though no initialization takes place!
  //
  dwRetVal = WaitForSingleObject(
    m_hEvAgentRunning,
    dwMilliseconds
    ) ;
  //
  if ( WAIT_FAILED == dwRetVal )
    THROW_WIN32_EXCEPTION ;

  // Timeout
  if ( WAIT_TIMEOUT == dwRetVal ) return waitTimeout ;

  return waitSuccess ;

}


///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
UINT __stdcall 
CActiveQueueWithTimeout<T, dwLEN>::QueueAgentThread(
//
// The QueueAgentThread member function provides the 
// functionality of an active queue.
//
CActiveQueueWithTimeout<T, dwLEN> *pThis // thread argument
//
// Indicates the thread argument. Here, the this-pointer 
// will be passed as the argument when the thread is created.
//
)
// 
// Return Value
//
// If the thread terminates gracefully, the return value is 0.
// If an exception occurs, the return value equals the error
// code.
//
// Remarks
//
// The QueueAgentThread function is meant to be started in a 
// separate thread. It provides and administers an active 
// queue. There are two ways to communicate with the queue
// from the outside:
// 
// 1.) The Insert member function inserts an element into the 
//     queue.
// 2.) The Retrieve function retrieves an element from the 
//     queue.
// 
{

  // Array of handles that the agent waits for: internal and
  // external exit events, event that is set by the Insert 
  // member function when a new element is to be inserted, 
  // semaphore that counts available worker threads, and
  // timer handles.
  //
  HANDLE ahWaitHandles[dwLEN + 4] ; 
  
  // Array of handles to be used when waiting for Roger from
  // worker thread.
  //
  HANDLE ahWaitForRogerHandles[3] =
  { 
    pThis->m_hExitEvent,
    pThis->m_hAgentExitEvent,
    pThis->m_hEvRogerToQueueAgent
  } ;

  // Enum for operation that is to be performed. The values
  // correspond to the first four indices of the ahWaitHandles
  // array.
  //
  enum 
  { 
    opExit = 0, 
    opInternalExit = 1, 
    opNewElement = 2, 
    opRetrieveElement = 3
  } ;

  // Auxiliaries
  //
  DWORD dwTimeout ;
  DWORD dwRetVal ;
  DWORD dwRetIndex ;
  DWORD dwSaveAnIndex ;
  DWORD dwIndex ;
  LONG loPreviousCount ;
  DWORD dwQueueIndex ;

  try
  {

    // Signal to Start member function that we're running
    // 
    if ( ! SetEvent(pThis->m_hEvAgentRunning) )
      THROW_WIN32_EXCEPTION ;
      
    // Fill handle array with internal and external exit
    // event, event to signal new element for queue, 
    // semaphore to signal available worker thread, and
    // timer threads.
    //
    ahWaitHandles[0] = pThis->m_hExitEvent ;
    ahWaitHandles[1] = pThis->m_hAgentExitEvent ;
    ahWaitHandles[2] = pThis->m_hEvNewElementWantsInQueue ;
    ahWaitHandles[3] = pThis->m_hSemAvailableWorkerThreads ;
    //
    for (dwIndex = 4; dwIndex < dwLEN + 4; ++dwIndex)
    {
      ahWaitHandles[dwIndex] 
        = (pThis->m_ahTimers)[dwIndex-4].GetHandle() ;
    }
    
    // Initialize correspondence between queue elements and 
    // timers: this is initially 1-1
    //
    for(dwIndex = 0; dwIndex < dwLEN; ++dwIndex)
    {
      (pThis->m_adwQueueElementsToTimers)[dwIndex] = dwIndex ;
    }

    // Main loop waits for internal and external exit event,
    // for Insert function to signal new element for queue,
    // worker thread to become available, and timers to go
    // off.
    //
    while (1)
    {
      
      // If the queue is empty, we only wait for exit events
      // and new elements. There is nothing we can do for 
      // available worker threads, and there are no active
      // timers. If queue is not empty, we also wait for worker
      // threads to signal interest in element and for timers 
      // to go off.
      //
      dwRetVal = WaitForMultipleObjects(
        pThis->m_bQueueEmpty ? 3 : dwLEN + 4,	// number handles
        ahWaitHandles,	// pointer to array 
        FALSE,	// wait flag 
        INFINITE 	// time-out interval in milliseconds 
        );
      //       
      // Throw exception if wait failed
      //
      if ( WAIT_FAILED == dwRetVal ) THROW_WIN32_EXCEPTION ;
      
      //
      // Take action according to wait result: exit, new 
      // element, element to be retrieved, element timeout
      //
      
      dwRetIndex = dwRetVal - WAIT_OBJECT_0 ;
      
      // Exit
      //
      if  ( opExit == dwRetIndex 
            ||
            opInternalExit == dwRetIndex ) break ;
      
      // New element
      //
      if  ( opNewElement == dwRetIndex )
      {
        
        // Retrieve element and timeout value from 
        // communication variable, then set event to notify 
        // the Insert member function that the element has been
        // read from the variable.
        //
        (pThis->m_aTheQueue)[pThis->m_dwFirstEmptySlot] 
          = pThis->m_cInsertElement ;
        dwTimeout = pThis->m_dwTimeout ;
        //
        if ( ! SetEvent(pThis->m_hEvRogerToInsert) )
          THROW_WIN32_EXCEPTION ;
        
        // Set timer. The index of the timer that corresponds 
        // to a queue element with index x equals
        // m_adwQueueElementsToTimers[x]
        //
        (pThis->m_ahTimers)
        [
          (pThis->m_adwQueueElementsToTimers)
          [
            pThis->m_dwFirstEmptySlot
          ] 
        ].Set(dwTimeout) ;

        // Set queue status to not empty and advance index of 
        // first empty slot. This index may be one past the end
        // of the array. That's ok because we will neither read
        // nor write there.
        //
        pThis->m_bQueueEmpty = FALSE ;
        ++ (pThis->m_dwFirstEmptySlot) ;
        
      }
      //
      // End new element to queue
      
      // Element to be retrieved
      //
      if  ( opRetrieveElement == dwRetIndex )
      {  
        
        // The element to be retrieved is always in slot 0 of 
        // the queue. Place the information in the global 
        // communication variable.
        //
        pThis->m_cRetrieveElement = (pThis->m_aTheQueue)[0] ;
        
        // Cancel timer. The index of the timer that 
        // corresponds to a queue element with index x equals
        // m_adwQueueElementsToTimers[x].
        //
        (pThis->m_ahTimers)
        [
          (pThis->m_adwQueueElementsToTimers)[0]
        ].Cancel() ;

        // Cancelling the timer does not affect the state
        // of the timer. If the timer has gone off while we
        // were working in this if-branch, its handle is
        // now set. We must therefore reset it here.
        //
        if ( WAIT_FAILED == WaitForSingleObject(
          (pThis->m_ahTimers)
          [
           (pThis->m_adwQueueElementsToTimers)[0]
          ].GetHandle(),
          0
          ) ) THROW_WIN32_EXCEPTION ;

        // Decrement index of first empty slot, then pull 
        // contents of queue back by one slot. If queue is now 
        // empty, set flag m_bQueueEmpty to TRUE.
        //
        --(pThis->m_dwFirstEmptySlot) ;
        //
        for (dwIndex = 0 ; 
             dwIndex < pThis->m_dwFirstEmptySlot ; 
             ++dwIndex)
        {
          (pThis->m_aTheQueue)[dwIndex] 
            = (pThis->m_aTheQueue)[dwIndex + 1] ;
        }
        //
        if ( 0 == pThis->m_dwFirstEmptySlot ) 
        {
          pThis->m_bQueueEmpty = TRUE ;
        }
        
        // Now perform the parallel "pullback operation" on the
        // array of correspondences between queue elements and 
        // timers. In addition, the timer of the removed queue 
        // element must not be thrown away. It must be made to 
        // correspond the new first empty slot.
        //
        dwSaveAnIndex = (pThis->m_adwQueueElementsToTimers)[0];
        //
        for (dwIndex = 0 ; 
             dwIndex < pThis->m_dwFirstEmptySlot ; 
             ++dwIndex)
        {
          (pThis->m_adwQueueElementsToTimers)[dwIndex] = 
            (pThis->m_adwQueueElementsToTimers)[dwIndex + 1] ;
        }
        //
        (pThis->m_adwQueueElementsToTimers)
        [
          pThis->m_dwFirstEmptySlot
        ] = dwSaveAnIndex ;
        
        // Increment the count on the semaphore that counts the 
        // number of available slots in the queue. This is used 
        // by the Insert member function to decide whether to 
        // signal the presence of a new element.
        //
        if ( ! ReleaseSemaphore(
          pThis->m_hSemAvailableSlotsInQueue,
          1,
          &loPreviousCount
          ) )
        {
          THROW_WIN32_EXCEPTION ;
        }
        
        // Notify threads of element availability. We know 
        // that at least one thread will answer: this if-branch
        // was entered because the semaphore 
        // hSemAvailableWorkerThreads was signalled. On the 
        // other hand, no more than one thread will answer the 
        // request, because hEvElementAvailable is an auto 
        // reset event.
        //
        if ( ! SetEvent(pThis->m_hEvElementAvailable) )
          THROW_WIN32_EXCEPTION ;
        
        // Wait for Roger from a thread, signalling that the
        // information has been received. The first and 
        // second entry in the array are the exit events.
        //
        //
        dwRetVal = WaitForMultipleObjects(
          3,	// number of handles in array 
          ahWaitForRogerHandles,	// pointer to array 
          FALSE,	// wait flag 
          INFINITE 	// time-out interval in milliseconds 
          );
        //       
        // Throw exception if wait failed
        //
        if ( WAIT_FAILED == dwRetVal ) THROW_WIN32_EXCEPTION ;
        
        // Break out of loop if one of the exit events
        // was set
        //
        dwRetIndex = dwRetVal - WAIT_OBJECT_0 ;
        //     
        if  ( opExit == dwRetIndex 
            ||
            opInternalExit == dwRetIndex ) break ;
      
      }    
      //
      // End element to be retrieved
      
      // Element timeout
      //
      if  ( dwRetIndex > opRetrieveElement )
      {
        
        // Determine the queue element that currently 
        // corresponds to the timer that went off. The index of
        // that timer is dwRetIndex - 4.
        //
        for (dwIndex = 0 ; dwIndex < dwLEN ; ++dwIndex)
        {
          if ( (pThis->m_adwQueueElementsToTimers)[dwIndex] 
            == dwRetIndex - 4) break ;
        }
        //
        dwQueueIndex = dwIndex ;      
        
        // Call the function whose address was passed in the
        // argument. This function does what needs to be done
        // to deal with a timed out client.
        
        (* pThis->m_DealWithTimedOutElement)(
          (pThis->m_aTheQueue)[dwQueueIndex]
          ) ;
        
        // Decrement index of first empty slot, then pull 
        // contents of queue, beginning at index dwQueueIndex, 
        // back by one slot. If queue is now empty, set flag 
        // bQueueEmpty to TRUE.
        //
        --(pThis->m_dwFirstEmptySlot) ;
        //
        for (dwIndex = dwQueueIndex ; 
             dwIndex < pThis->m_dwFirstEmptySlot ; 
             ++dwIndex)
        {
          (pThis->m_aTheQueue)[dwIndex] 
            = (pThis->m_aTheQueue)[dwIndex + 1] ;
        }
        //
        if ( pThis->m_dwFirstEmptySlot == 0 ) 
        {
          pThis->m_bQueueEmpty = TRUE ;
        }
        
        // Now perform the parallel "pullback operation" on the
        // array of correspondences between queue elements and 
        // timers. In addition, the timer of the removed queue 
        // element must not be thrown away. It must be made to 
        // correspond the new first empty slot.
        //
        dwSaveAnIndex 
          = (pThis->m_adwQueueElementsToTimers)[dwQueueIndex] ;
        //
        for (dwIndex = dwQueueIndex; 
             dwIndex < pThis->m_dwFirstEmptySlot; 
             ++dwIndex)
        {
          (pThis->m_adwQueueElementsToTimers)[dwIndex] = 
            (pThis->m_adwQueueElementsToTimers)[dwIndex + 1] ;
        }
        //
        (pThis->m_adwQueueElementsToTimers)
        [
          pThis->m_dwFirstEmptySlot
        ] = dwSaveAnIndex ;
        
        // Increment the count on the semaphore that counts 
        // the number of available slots in the queue. This is 
        // used by the main loop to decide whether to signal 
        // the presence of a new client.
        //
        ReleaseSemaphore(
          pThis->m_hSemAvailableSlotsInQueue,
          1,
          &loPreviousCount
          ) ;
        
      }
      //
      // End element timeout

    }
    // 
    // End forever loop 
  
  }
  catch(CWin32Exception& eWin32)
  {
    // We do not propagate the exception because this is
    // a thread function. Instead, return the error code.
    //
    return eWin32.GetErrorCode() ;
  }

  return 0 ;

}


///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
CActiveQueueWithTimeout<T, dwLEN>::waitResult 
CActiveQueueWithTimeout<T, dwLEN>::Insert(
//
// The insert function places a new element into the queue.            
//
const T& refNewElement, // new element
//
// Refers to the new element that is to be inserted.
//
DWORD dwMillisecondsInQueue, // timeout in queue
//
// Indicates the timeout value in milliseconds or INFINITE
// for elements in the queue.
//
DWORD dwMilliseconds // timeout
//
// Indicates the timeout value in milliseconds or INFINITE
// for the wait operation when the queue is full.
//
)
//
// Return Value and Exceptions
//
// If the function succeeds, the return value is waitSuccess.
// If a timeout occurs, the return value is waitTimeout.
// If the function notices that the exit event was set,
// the return value is waitExitEvent.
//
// If the function fails, a CWin32Exception is thrown.
//
{

  // Auxiliaries
  //
  HANDLE ahSynchObjectAndExitEvent[2] ;
  DWORD dwRetVal ;
  BOOL bReleaseMutex = FALSE ;

  _ASSERT( NULL != m_hExitEvent ) ;
  
  try 
  {

    // The entire operation must be protected with a mutex
    // so more than one thread can insert. We must simultaneously 
    // wait for the exit event so that the thread is notified of 
    // an exit request.
    //
    ahSynchObjectAndExitEvent[0] = m_hInsertMutex ;
    ahSynchObjectAndExitEvent[1] = m_hExitEvent ;
    //
    dwRetVal = WaitForMultipleObjects(
      2,	// number of handles in the object handle array 
      ahSynchObjectAndExitEvent,	// pointer to array 
      FALSE,	// wait flag 
      dwMilliseconds 	// time-out interval in milliseconds 
      );
    //
    if ( WAIT_FAILED == dwRetVal || 
         WAIT_ABANDONED == dwRetVal )
    {
      bReleaseMutex = FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Timeout
    if ( WAIT_TIMEOUT == dwRetVal ) return waitTimeout ;
    
    // If exit event was signaled, just return waitExitEvent
    //
    if ( 1 == dwRetVal - WAIT_OBJECT_0 ) return waitExitEvent ;
    
    // Place element and timeout into the  communication member
    // variables refNewClientInQueue
    //
    m_cInsertElement = refNewElement ;
    m_dwTimeout = dwMillisecondsInQueue ;
    
    // Wait for an empty slot in the queue.
    // We must simultaneously wait for the exit event so 
    // that the thread is notified of an exit request.
    //
    ahSynchObjectAndExitEvent[0] = m_hSemAvailableSlotsInQueue ;
    ahSynchObjectAndExitEvent[1] = m_hExitEvent ;
    //
    dwRetVal = WaitForMultipleObjects(
      2,	// number of handles in the object handle array 
      ahSynchObjectAndExitEvent,	// pointer to array 
      FALSE,	// wait flag 
      dwMilliseconds 	// time-out interval in milliseconds 
      );
    //
    if ( WAIT_FAILED == dwRetVal )
    {
      bReleaseMutex = TRUE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Timeout: Don't forget to release the mutex
    //
    if ( WAIT_TIMEOUT == dwRetVal )
    {
      if ( ! ReleaseMutex(m_hInsertMutex) )
      {
        bReleaseMutex = FALSE ;
        THROW_WIN32_EXCEPTION ;
      }
      return waitTimeout ;
    }
    
    // If exit event was signaled, return waitExitEvent
    //
    if ( 1 == dwRetVal - WAIT_OBJECT_0 )
    {
      if ( ! ReleaseMutex(m_hInsertMutex) )
      {
        bReleaseMutex = FALSE ;
        THROW_WIN32_EXCEPTION ;
      }
      return waitExitEvent ;
    }
    
    // Set event to signal to queue agent that a new element 
    // needs to be inserted in the queue. 
    //
    if ( ! SetEvent(m_hEvNewElementWantsInQueue) )
    {
      bReleaseMutex = TRUE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Wait till the queue agent sends its Roger to confirm
    // that it has reacted to the setting of the event. Without
    // this wait operation, the Insert function could be called
    // again without any  reaction from the queue agent!
    //
    ahSynchObjectAndExitEvent[0] = m_hEvRogerToInsert ;
    ahSynchObjectAndExitEvent[1] = m_hExitEvent ;
    //
    dwRetVal = WaitForMultipleObjects(
      2,	// number of handles in the object handle array 
      ahSynchObjectAndExitEvent,	// pointer to array 
      FALSE,	// wait flag 
      dwMilliseconds 	// time-out interval in milliseconds 
      );
    //
    if ( WAIT_FAILED == dwRetVal )
    {
      bReleaseMutex = TRUE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Timeout: Don't forget to release the mutex
    //
    if ( WAIT_TIMEOUT == dwRetVal )
    {
      if ( ! ReleaseMutex(m_hInsertMutex) )
      {
        bReleaseMutex = FALSE ;
        THROW_WIN32_EXCEPTION ;
      }
      return waitTimeout ;
    }
    
    // If exit event was signaled, return waitExitEvent
    //
    if ( 1 == dwRetVal - WAIT_OBJECT_0 )
    {
      if ( ! ReleaseMutex(m_hInsertMutex) )
      {
        bReleaseMutex = FALSE ;
        THROW_WIN32_EXCEPTION ;
      }
      return waitExitEvent ;
    }
    
    if ( ! ReleaseMutex(m_hInsertMutex) )
    {
      bReleaseMutex = FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
  
  }
  catch (CWin32Exception&)
  {
  
    // If the exception was thrown while we were in posession
    // of the mutex, we must try to release it. Note: no
    // propagation of exception from catch block to avoid
    // covering up the real exception. Just throw so that
    // logging can take place.
    //
    if ( bReleaseMutex && ! ReleaseMutex(m_hInsertMutex) )
    {
      try
      {
        THROW_WIN32_EXCEPTION ;
      }
      catch (...) {}        
    
    }
    
    throw ;

  }
  //
  // End catch block

  return waitSuccess ;
      
}


///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
CActiveQueueWithTimeout<T, dwLEN>::waitResult
CActiveQueueWithTimeout<T, dwLEN>::Retrieve(
// 
// The Retrieve function retrieves a pipe index from the queue.
//
T& refLocation, // location to retrieve to
//
// Refers to the T location that will receive the result.
//
DWORD dwMilliseconds // timeout
//
// Indicates the timeout value in milliseconds or INFINITE.
//
) 
//
// Return Value and Exceptions
//
// If the function succeeds, the return value is waitSuccess.
// If the wait operation timed out, the return value is 
// waitTimeout.
// If the function notices that the exit event was set,
// the return value is waitExitEvent.
//
// If the function fails, a CWin32Exception is thrown.
//
{

  // Auxiliaries
  //
  HANDLE ahSynchObjectAndExitEvent[2] ;
  DWORD dwRetVal ;
  LONG loPrevCount ;
    
  _ASSERT( NULL != m_hExitEvent ) ;
  
  // Signal willingness to retrieve an element by releasing 
  // the semaphore that counts the available worker threads.
  //
  if ( ! ReleaseSemaphore(
    m_hSemAvailableWorkerThreads, 
    1, 
    &loPrevCount
    ) )
  {
    THROW_WIN32_EXCEPTION ;
  }

  // Wait for queue agent to set the event that signals an
  // availability of an element.
  //
  ahSynchObjectAndExitEvent[0] = m_hEvElementAvailable ;
  ahSynchObjectAndExitEvent[1] = m_hExitEvent ;
  //
  dwRetVal = WaitForMultipleObjects(
    2,	// number of handles in the object handle array 
    ahSynchObjectAndExitEvent,	// pointer to array 
    FALSE,	// wait flag 
    dwMilliseconds 	// time-out interval in milliseconds 
    );
  //
  if ( WAIT_FAILED == dwRetVal ) THROW_WIN32_EXCEPTION ;

  // Timeout
  if ( WAIT_TIMEOUT == dwRetVal ) return waitTimeout ;

  // If exit event was signaled, just return waitExitEvent
  //
  if ( 1 == dwRetVal - WAIT_OBJECT_0 ) return waitExitEvent ;

  // Retrieve queue element from communication buffer 
  refLocation = m_cRetrieveElement ;

  // Send Roger to queue agent. Without the Roger, the queue 
  // agent could modify the communication buffer again before 
  // this thread has read it.
  //
  if ( ! SetEvent(m_hEvRogerToQueueAgent) )
    THROW_WIN32_EXCEPTION ;

  return waitSuccess ;

}

#endif
//
// End protection against multiple inclusion

