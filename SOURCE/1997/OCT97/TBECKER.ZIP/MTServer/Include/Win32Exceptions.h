//
// File: Win32Exceptions.h
//
// Created: February 1997
//
// Author: Dr. Thomas Becker
//
// Declaration of the CWin32Exception CSehException classes

// Protect against multiple inclusion
//
#ifndef __WIN32_EXCEPTIONS_H_INCLUDED__
#define __WIN32_EXCEPTIONS_H_INCLUDED__

// Includes
// ========

#include<windows.h>
#include<eh.h>
#include<string.h>
#include<TCHAR.h>


// Macros
// ======

#define THROW_WIN32_EXCEPTION throw \
CWin32Exception(GetLastError(), ___FILE___, __LINE__ )

// Bummer: File macro not supported in UNICODE
//
#ifdef UNICODE
  #define ___FILE___ _TEXT("__FILE__ macro not supported in UNICODE")
#else
 #define ___FILE___ __FILE__
#endif


///////////////////////////////////////////////////////////////
//
class CWin32Exception
//
// The CWin32Exception class is used to propagate the return 
// value of GetLastError() after the failure of a Win32 API. 
// In this simple version, we pass along the error code as well 
// as the filename and line number indicating where the error 
// occurred.
//
// A real-life version should include a logging mechanism,
// either directly in this class or in a base class. Such
// a mechanism ensures that exceptions that cannot be
// propagated (e.g. exceptions occurring in a destructor)
// do not get lost.
//
{

  // Error code
  DWORD m_dwErrorCode ;

  // File name. 
  _TCHAR m_achFileName[MAX_PATH] ;

  // Line number
  DWORD m_dwLineNo ;

public:

  // Constructor sets members from arguments
  //
  CWin32Exception(
    DWORD dwErrorCode,
    LPTSTR pchFileName, // UNICODE DOES NOT SUPPORT FILE MACRO
    DWORD dwLineNo
    )
    : m_dwErrorCode(dwErrorCode),
      m_dwLineNo(dwLineNo)
  { 
  
    memset(
      m_achFileName, 
      '\0', 
      sizeof(m_achFileName)
      ) ;
    
    _tcsncpy(
      m_achFileName, 
      pchFileName, 
      max(_tcslen(pchFileName), MAX_PATH)
      ) ;
  
  }

  // Get method for error code
  DWORD GetErrorCode() { return m_dwErrorCode ; }

  // Get method for file name.
  //
  LPTSTR GetFileName() { return m_achFileName ; }

  // Get method for line number
  DWORD GetLineNo() { return m_dwLineNo ; }


} ;


///////////////////////////////////////////////////////////////
//
class CSehException
//
// The CSehException class is used to translate SEH-Exceptions
// into typed C++ exceptions. The user of this class must call
// the _set_se_translator function on a per thread basis to 
// install a function that gets called when a C structured 
// exception occurs. This function must then simply throw a 
// CSehException. For a more detailed explanation, see the 
// documentation of _set_se_translator and the article 
// "Structured exception handling" in the C++ Language 
// Reference.
// 
// It is possible to place a lot more information into this 
// exception; here, we are content with the exception code.
//
{

  // C structured exception code
  unsigned int m_uiExceptionCode ;
  
public:

  // Constructor sets exception code from argument
  //
  CSehException(unsigned int uiExceptionCode)
    : m_uiExceptionCode(uiExceptionCode) {}

  // Get method for exception code
  unsigned int GetExceptionCode() { return m_uiExceptionCode ; }

} ;

#endif
//
// End protection from multiple inclusion
