//
// File: PassiveQueue.h
//
// Created: February 1997
//
// Author: Dr. Thomas Becker
//
// Declaration and member function definitions for class
// CPassiveQueue.

// Protect against multiple inclusion
//
#ifndef __PASSIVE_QUEUE_H_INCLUDED__
#define __PASSIVE_QUEUE_H_INCLUDED__

// Includes
// ========

#include<windows.h>
#include<crtdbg.h>
#include"Win32Exceptions.h"


///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
class CPassiveQueue
//
// The CPassiveQueue class template realizes a simple thread-safe 
// FIFO queue. 
//
// The first template argument indicates the type of the queue
// elements, the second one indicates the length of the queue.
// 
// The constructor takes as an optional argument the handle to
// an exit event. Setting this event will cause the Insert and 
// Retrieve member functions to return immediately. This event 
// handle can also be specified later by means of the 
// SetHandleToExitEvent member function.
//
// The Insert member function inserts an element into the 
// queue. This is the function that is typically called by
// a listening thread. Such a thread accepts clients from a 
// communications device and then places in the queue a pointer
// or an array index that identifies e.g. a socket descriptor 
// or a pipe handle. Elements are always copied into the queue;
// therefore, the element type must possess a public copy 
// constructor if it is a user-defined class.
//
// The Retrieve member function retrieves an element from 
// the queue. This is the function that is typically called
// by worker threads to retrieve a pointer or an array index
// leading to a communications device.
//
// All member functions throw CWin32Exceptions if Win32 errors 
// are encountered.
//
{

  /////////////////////////////////////////////////////////////
  //
  // Implementation of CPassiveQueue: Member Variables
  //
  /////////////////////////////////////////////////////////////
  
  // Handle for exit event
  HANDLE m_hExitEvent ;
  
  // Handles for synchronization objects
  //
  HANDLE m_hInSem ;
  HANDLE m_hOutSem ;
  HANDLE m_hMutex ;

  // The queue: array of T's.
  //
  T m_aTheQueue[dwLEN] ;

  // Index of current insertion slot
  DWORD m_dwInsertIndex ;

  // Index of current retrieval slot
  DWORD m_dwOutIndex ;

  /////////////////////////////////////////////////////////////
  //
  // Interface of CPassiveQueue
  //
  /////////////////////////////////////////////////////////////
  
public:    
  
  // Return values from functions that perform wait operations.
  //
  enum waitResult
  {
    waitTimeout,
    waitExitEvent,
    waitSuccess
  } ;
  
  // Constructs a CPassiveQueue object.
  CPassiveQueue(HANDLE hExitEvent = NULL) ;

  // Destruction
  ~CPassiveQueue() ;

  // Inserts an element into the queue.
  //
  waitResult Insert(
    const T& refNewEntry,
    DWORD dwMilliseconds
    ) ;

  // Retrieves an element from the queue.
  //
  waitResult Retrieve(
    T& refToLocation,
    DWORD dwMilliseconds
    ) ;

  // Places the handle to the exit event in a private member
  // variable.
  //
  void SetHandleToExitEvent(HANDLE hExitEvent)
  {
    m_hExitEvent = hExitEvent ;
  }
  
} ;


///////////////////////////////////////////////////////////////
//
// Implementation of CPassiveQueue member functions
//
///////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
CPassiveQueue<T, dwLEN>::CPassiveQueue( 
//
// The constructor creates the synchronization objects and 
// initializes the member variables. To avoid exceptions from
// constructors, no error check is made on the Create... APIs.
// The Insert and Retrieve member functions will throw 
// exceptions if the handles are NULL.
//
HANDLE hExitEvent // = NULL exit event
//
// Indicates the handle of the event that causes all member
// functions to return immediately. This handle can be set
// later by means of the SetHandleToExitEvent member function.
// However, the handle must be set to a valid event handle
// before the Insert or Retrieve member functions are called
// for the first time.
//
) : m_hExitEvent(hExitEvent), 
    m_dwInsertIndex(0), 
    m_dwOutIndex(0)
//
{
  
  // Create mutex for exclusive access to queue. We use a mutex
  // instead of a critical section because we need timeouts, 
  // and we want to wait on an exit event simultaneously.
  // No error checking here.
  //
  m_hMutex = CreateMutex(
    NULL,	// pointer to security attributes 
    FALSE,	// flag for initial ownership 
    NULL 	// pointer to mutex-object name  
   );
  
  // Create semaphore to manage insertion into queue.
  // There are dwLEN many slots, and they are all
  // empty at the beginning. No error checking here.
  //
  m_hInSem = CreateSemaphore(
    NULL,	// pointer to security attributes 
    dwLEN,	// initial count 
    dwLEN,	// maximum count 
    NULL 	// pointer to semaphore-object name  
    );
  
  // Create semaphore to manage removal from queue.
  // There are dwLEN many slots, and they are all
  // empty at the beginning. No error checking here.
  //
  m_hOutSem = CreateSemaphore(
    NULL,	// pointer to security attributes 
    0,	// initial count 
    dwLEN,	// maximum count 
    NULL 	// pointer to semaphore-object name  
    );

}


///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
CPassiveQueue<T, dwLEN>::~CPassiveQueue()
//
// The destructor closes the handles of the synchronization 
// objects.
//
{

  // Close handles of synchronization objects
  //
  if ( NULL != m_hInSem ) CloseHandle(m_hInSem) ;
  if ( NULL != m_hOutSem ) CloseHandle(m_hOutSem) ;
  if ( NULL != m_hMutex ) CloseHandle(m_hMutex) ;
  
}

///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
CPassiveQueue<T, dwLEN>::waitResult 
CPassiveQueue<T, dwLEN>::Insert(
//
// The Insert member function places a new element into the 
// queue.            
//
const T& refNewElement, // new element
//
// Refers to the new element that is to be inserted.
//
DWORD dwMilliseconds // timeout
//
// Indicates the timeout value in milliseconds or INFINITE.
//
)
//
// Return Value and Exceptions
//
// If the function succeeds, the return value is waitSuccess.
// If a timeout occurs, the return value is waitTimeout.
// If the function notices that the exit event was set,
// the return value is waitExitEvent.
//
// If the function fails, a CWin32Exception is thrown.
//
{

  // Auxiliaries
  //
  HANDLE ahSynchObjectAndExitEvent[2] ;
  DWORD dwRetVal ;
  LONG loPrevCount ;
  BOOL bReleaseInSem = FALSE ;
  BOOL bReleaseOutSem = FALSE ;
  BOOL bReleaseMutex = FALSE ;

  try
  {
  
    // Check synch objects here because constructor did not
    // check upon creation
    //
    if ( NULL == m_hMutex 
      || NULL == m_hInSem 
      || NULL == m_hOutSem ) 
    {
      bReleaseInSem = FALSE ;
      bReleaseOutSem = FALSE ;
      bReleaseMutex= FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Wait for empty slot in queue to become available.
    // We must simultaneously wait for the exit event so 
    // that the thread is notified of an exit request.
    //
    ahSynchObjectAndExitEvent[0] = m_hInSem ;
    ahSynchObjectAndExitEvent[1] = m_hExitEvent ;
    //
    dwRetVal = WaitForMultipleObjects(
      2,	// number of handles in the object handle array 
      ahSynchObjectAndExitEvent,	// pointer to array 
      FALSE,	// wait flag 
      dwMilliseconds 	// time-out interval in milliseconds 
      );
    
    // Throw exception if wait failed
    //
    if ( WAIT_FAILED == dwRetVal )
    {
      bReleaseInSem = FALSE ;
      bReleaseOutSem = FALSE ;
      bReleaseMutex= FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Timeout ocurred
    if ( WAIT_TIMEOUT == dwRetVal ) return waitTimeout ;
    
    // Exit event was signaled
    //
    if ( 1 == dwRetVal - WAIT_OBJECT_0 ) return waitExitEvent ;
    
    // Wait for mutex for exclusive access to queue.
    //
    ahSynchObjectAndExitEvent[0] = m_hMutex ;
    ahSynchObjectAndExitEvent[1] = m_hExitEvent ;
    //
    dwRetVal = WaitForMultipleObjects(
      2,	// number of handles in the object handle array 
      ahSynchObjectAndExitEvent,	// pointer to array 
      FALSE,	// wait flag 
      INFINITE 	// time-out interval in milliseconds 
      );
    
    // Throw exception if wait failed or wait abandoned.
    //
    if ( WAIT_FAILED == dwRetVal 
      || WAIT_ABANDONED == dwRetVal)
    {
      bReleaseInSem = TRUE ;
      bReleaseOutSem = FALSE ;
      bReleaseMutex= FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Timeout: Return, but note that we have a count on the 
    // in-semaphore now, which we must give back
    //
    if ( WAIT_TIMEOUT == dwRetVal ) 
    {
      if ( ! ReleaseSemaphore(m_hInSem, 1, &loPrevCount) )
      {
        bReleaseInSem = FALSE ;
        bReleaseOutSem = FALSE ;
        bReleaseMutex= FALSE ;
        THROW_WIN32_EXCEPTION ;
      }
      return waitTimeout ;
    }
    
    // Exit event was signaled.
    //
    if ( 1 == dwRetVal - WAIT_OBJECT_0 ) return waitExitEvent ;
    
    // Insert refNewElement at position m_dwInsertIndex,
    // advance position, then increase count of filled slots.
    //
    m_aTheQueue[m_dwInsertIndex] = refNewElement ;
    m_dwInsertIndex = ++m_dwInsertIndex % dwLEN ;
    
    // Release Mutex and out-semaphore
    //
    if ( ! ReleaseMutex(m_hMutex) )
    {
      bReleaseInSem = FALSE ;
      bReleaseOutSem = TRUE ;
      bReleaseMutex= FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    //
    if ( ! ReleaseSemaphore(m_hOutSem, 1, &loPrevCount) )
    {
      bReleaseInSem = FALSE ;
      bReleaseOutSem = FALSE ;
      bReleaseMutex= FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    return waitSuccess ;
  
  }
  catch(CWin32Exception&)
  {
    // Try to release semaphores and mutex if necessary.
    // Do not propagate exceptions so that original exception
    // does not get covered up.
    //
    if ( bReleaseMutex )
    {
      try 
      {
        if ( ! ReleaseMutex(m_hMutex) ) THROW_WIN32_EXCEPTION ;
      }
      catch(...){}
    }
    //
    if ( bReleaseInSem )
    {
      try 
      {
        if ( ! ReleaseSemaphore(
          m_hInSem, 
          1, 
          &loPrevCount) ) THROW_WIN32_EXCEPTION ;
      }
      catch(...){}
    }
    //
    if ( bReleaseOutSem )
    {
      try 
      {
        if ( ! ReleaseSemaphore(
          m_hOutSem, 
          1, 
          &loPrevCount) ) THROW_WIN32_EXCEPTION ;
      }
      catch(...){}
    }
    
    throw ;

  }
  // 
  // End catch for entire function

}

///////////////////////////////////////////////////////////////
//
template <class T, DWORD dwLEN>
CPassiveQueue<T, dwLEN>::waitResult
CPassiveQueue<T, dwLEN>::Retrieve(
// 
// The Retrieve memeber function retrieves a pipe index from 
// the queue.
//
T& refLocation, // location to retrieve to
//
// Refers to the T location that will receive the result.
//
DWORD dwMilliseconds // timeout
//
// Indicates the timeout value in milliseconds or INFINITE.
//
) 
//
// Return Value and Exceptions
//
// If the function succeeds, the return value is waitSuccess.
// If the wait operation timed out, the return value is 
// waitTimeout.
// If the function notices that the exit event was set,
// the return value is waitExitEvent.
//
// If the function fails, a CWin32Exception is thrown.
//
{

  // Auxiliaries
  //
  HANDLE ahSynchObjectAndExitEvent[2] ;
  DWORD dwRetVal ;
  LONG loPrevCount ;
  BOOL bReleaseInSem = FALSE ;
  BOOL bReleaseOutSem = FALSE ;
  BOOL bReleaseMutex = FALSE ;

  try 
  {
    
    // Check synch objects here because constructor did not
    // check upon creation
    //
    if ( NULL == m_hMutex 
      || NULL == m_hInSem 
      || NULL == m_hOutSem )
    {
      bReleaseInSem = FALSE ;
      bReleaseOutSem = FALSE ;
      bReleaseMutex= FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Wait for non-empty slot in queue to become available.
    // We must simultaneously wait for the exit event so 
    // that the thread is notified of an exit request.
    //
    ahSynchObjectAndExitEvent[0] = m_hOutSem ;
    ahSynchObjectAndExitEvent[1] = m_hExitEvent ;
    //
    dwRetVal = WaitForMultipleObjects(
      2,	// number of handles in the object handle array 
      ahSynchObjectAndExitEvent,	// pointer to array 
      FALSE,	// wait flag 
      dwMilliseconds 	// time-out interval in milliseconds 
      );
    //
    if ( WAIT_FAILED == dwRetVal )
    {
      BOOL bReleaseInSem = FALSE ;
      BOOL bReleaseOutSem = FALSE ;
      BOOL bReleaseMutex = FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Timeout
    if ( WAIT_TIMEOUT == dwRetVal ) return waitTimeout ;
    
    // If exit event was signaled, just return waitExitEvent
    //
    if ( 1 == dwRetVal - WAIT_OBJECT_0 ) return waitExitEvent ;
    
    // Wait for mutex for exclusive access to queue.
    //
    ahSynchObjectAndExitEvent[0] = m_hMutex ;
    ahSynchObjectAndExitEvent[1] = m_hExitEvent ;
    //
    dwRetVal = WaitForMultipleObjects(
      2,	// number of handles in the object handle array 
      ahSynchObjectAndExitEvent,	// pointer to array 
      FALSE,	// wait flag 
      dwMilliseconds 	// time-out interval in milliseconds 
      );
    
    // Throw exception if wait failed or wait abandoned.
    //
    if ( WAIT_FAILED == dwRetVal || WAIT_ABANDONED == dwRetVal)
    {
      BOOL bReleaseInSem = FALSE ;
      BOOL bReleaseOutSem = TRUE ;
      BOOL bReleaseMutex = FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Timeout: Return, but note that we have a count on the 
    // out-semaphore now, which we must give back
    //
    if ( WAIT_TIMEOUT == dwRetVal ) 
    {
      if ( ! ReleaseSemaphore(m_hOutSem, 1, &loPrevCount) )
      {
        BOOL bReleaseInSem = FALSE ;
        BOOL bReleaseOutSem = FALSE ;
        BOOL bReleaseMutex = FALSE ;
        THROW_WIN32_EXCEPTION ;
      }
      
      return waitTimeout ;
      
    }
    
    // Exit event was signaled
    //
    if ( 1 == dwRetVal - WAIT_OBJECT_0 ) return waitExitEvent ;
    
    // Retrieve element at index m_dwOutIndex, increment 
    // m_dwOutIndex
    //
    refLocation = m_aTheQueue[m_dwOutIndex] ;
    m_dwOutIndex = ++m_dwOutIndex % dwLEN ;
    
    // Release Mutex and in-semaphore
    //
    if ( ! ReleaseMutex(m_hMutex) )
    {
      BOOL bReleaseInSem = TRUE ;
      BOOL bReleaseOutSem = FALSE ;
      BOOL bReleaseMutex = FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    //
    if ( ! ReleaseSemaphore(m_hInSem, 1, &loPrevCount) )
    {
      BOOL bReleaseInSem = FALSE ;
      BOOL bReleaseOutSem = FALSE ;
      BOOL bReleaseMutex = FALSE ;
      THROW_WIN32_EXCEPTION ;
    }
    
    return waitSuccess ;
    
  }
  catch(CWin32Exception&)
  {
    // Try to release semaphores and mutex if necessary.
    // Do not propagate exceptions so that original exception
    // does not get covered up.
    //
    if ( bReleaseMutex )
    {
      try 
      {
        if ( ! ReleaseMutex(m_hMutex) ) THROW_WIN32_EXCEPTION ;
      }
      catch(...){}
    }
    //
    if ( bReleaseInSem )
    {
      try 
      {
        if ( ! ReleaseSemaphore(
          m_hInSem, 
          1, 
          &loPrevCount) ) THROW_WIN32_EXCEPTION ;
      }
      catch(...){}
    }
    //
    if ( bReleaseOutSem )
    {
      try 
      {
        if ( ! ReleaseSemaphore(
          m_hOutSem, 
          1, 
          &loPrevCount) ) THROW_WIN32_EXCEPTION ;
      }
      catch(...){}
    }
    
    throw ;

  }
  // 
  // End catch for entire function

}



#endif
//
// End protection against multiple inclusion
