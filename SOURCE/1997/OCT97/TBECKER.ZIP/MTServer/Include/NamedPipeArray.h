//
// File: NamedPipeArray.h
//
// Created: February 1997
//
// Author: Dr. Thomas Becker
//
// Declaration and member function definition of the CNamedPipeArray class

// Protect against multiple inclusion
//
#ifndef __NAMED_PIPE_ARRAY_H_INCLUDED__
#define __NAMED_PIPE_ARRAY_H_INCLUDED__

// Includes
// ========

#include<windows.h>
#include<string.h>
#include<crtdbg.h>
#include<TCHAR.h>
#include"Win32Exceptions.h"


////////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
class CNamedPipeArray
//
// The CNamedPipeArray class template provides an array of
// instances of a named pipe and functions to read and write
// the server end of these pipe instances.
//
// The template argument specifies the number of instances
// of the named pipe.
// 
// The constructor takes as its arguments the name of the pipe
// and the handle to the exit event. The pipe name must be of
// the form "\\.\pipe\mypipe". Clients must replace the "."
// with the name of the server machine.Setting the exit event
// causes all member functions to abandon their respective
// waits and to return immediately. Both the pipe name and
// the handle to the exit event can be set later by means
// of the SetPipeName and SetHandleToExitEvent member 
// functions, respectively. The constructor only takes care
// of the internal setup of the class object; no pipes are
// created yet.
//
// The pipe instances are actually created and connected
// when the Listen member function is called for the first
// time. This function then waits for clients to connect.
// When a client has connected, the function provides the
// index of the pipe instance that the client is using.
// The Listen member function is typically called by a
// listen thread in an infinite loop.
//
// The index that the Listen member function returns can
// be used to read, write, flush, and reconnect the pipe 
// instances by means of the Read, Write, Flush, and Reconnect
// member functions. Internally, these functions use 
// asynchronous read and write operations so they can react 
// immediately to an exit request. To the user of the class, 
// however, the read and write operations appear to be 
// synchronous.
//
// All member functions throw CWin32Exceptions when they 
// encounter an error.
//
// CNamedPipeArray objects are meant to be used once during
// the lifetime of a program. Disconnecting the pipes and
// then reusing the entire object requires synchronization
// measures that have not been taken into consideration with
// this design.
//
{

  /////////////////////////////////////////////////////////////
  //
  // Implementation of CNamedPipeArray: Member Variables
  //
  /////////////////////////////////////////////////////////////
  
  // Pipe name. Maximum total length of a pipe name is 256
  _TCHAR m_achPipeName[257 * sizeof(_TCHAR)] ;
  
  // Array of pipe handles and array of overlapped structs for
  // asynchronous connection of pipes
  //
  HANDLE m_ahPipes[dwNumPipeInstances] ;
  OVERLAPPED m_aOverlapped[dwNumPipeInstances] ;

  // Array of overlapped handles plus exit event handle. 
  // These are associated with the pipes. The Listen member 
  // function will wait on these.
  //
  HANDLE m_ahOlEventsAndExitEvent[dwNumPipeInstances+1] ;

  // Handle of exit event
  HANDLE m_hExitEvent ;
  
  // Flag indicating if pipes are created and connected. 
  BOOL m_bPipesCreatedAndConnected ;

  /////////////////////////////////////////////////////////////
  //
  // Implementation of CNamedPipeArray: Member Functions
  //
  /////////////////////////////////////////////////////////////
  
  // Create and connect named pipes. Called once by the Listen 
  // member function when m_bPipesCreatedAndConnected is FALSE
  //
  void CreateAndConnectPipes() ;

  // Disconnect named pipes, close handles, null everything
  void Hangup() ;

  /////////////////////////////////////////////////////////////
  //
  // Interface of CNamedPipeArray
  //
  /////////////////////////////////////////////////////////////
  
public:    
  
  // Return values from functions that perform wait operations.
  //
  enum waitResult
  {
    waitTimeout, // timeout occurred
    waitExitEvent, // exit event was set
    waitSuccess  // operation completed successfully
  } ;
  
  // Constructs a CNamedPipeArray object.
  //
  CNamedPipeArray(
    LPTSTR pchPipeName = NULL,
    HANDLE hExitEvent = NULL
    ) ;

  // Destruction
  //
  ~CNamedPipeArray() ;

  // Places the handle to the exit event in a private member
  // variable.
  //
  void SetHandleToExitEvent(HANDLE hExitEvent)
  {
    m_hExitEvent = hExitEvent ;
  }
  
  // Places the pipe name in a private member variable.
  //
  void SetPipeName(LPTSTR pchPipeName)
  {
    memset(m_achPipeName, '\0', sizeof(m_achPipeName)) ;
    _tcsncpy(
      m_achPipeName, 
      pchPipeName, 
      max(_tcslen(pchPipeName), 256)
      ) ;
  }
  
  // Listens for clients to connect.
  //
  waitResult Listen(
    DWORD& refdwIndex,
    DWORD dwMilliseconds
    ) ;

  // Reads from the server end of a pipe instance.
  //
  waitResult Read(
    DWORD dwIndex,
    LPVOID lpBuffer,
    DWORD dwNumberOfBytesToRead,
    LPDWORD lpdwNumberOfBytesRead,
    DWORD dwMilliseconds
   );

  // Writes to the server end of a pipe instance.
  // (similar to WriteFile)
  //
  waitResult Write(
    DWORD dwIndex,
    LPCVOID lpBuffer,	
    DWORD dwNumberOfBytesToWrite,	
    LPDWORD lpdwNumberOfBytesWritten,	
    DWORD dwMilliseconds
   );
  
  // Flushes the server end of a pipe instance.
  //
  void Flush(
    DWORD dwIndex
    ) ;

  // Performs a Disconnect and subsequent asynchronous connect 
  // on the server end of a pipe instance.
  //
  void Reconnect(
    DWORD dwIndex
    ) ;

} ;


////////////////////////////////////////////////////////////////
//
// Implementation of CNamedPipeArray member functions
//
////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
CNamedPipeArray<dwNumPipeInstances>::CNamedPipeArray(
//
// The constructor sets the m_pchPipeName and m_hExitEvent 
// member variables from the arguments. It then initializes all
// other member variables in a meaningful way.
//
LPTSTR pchPipeName, // = NULL, pipe name
//
// Points to the name of the pipe.
//
HANDLE hExitEvent // = NULL, handle of exit event
//
// Indicates the exit event that causes all member functions to
// return immediately. This handle can be set later by means 
// of the SetHandleToExitEvent member function. However, the 
// handle must be set to a valid event handle before the Listen 
// member function is called for the first time.
//
)
//
{
  
  // Set pipe name and exit event from argument
  //
  memset(m_achPipeName, '\0', sizeof(m_achPipeName)) ;
  _tcsncpy(
    m_achPipeName, 
    pchPipeName, 
    max(_tcslen(pchPipeName), 256)
    ) ;
  //
  m_hExitEvent = hExitEvent ;

  // Set all pipe handles to INVALID_HANDLE_VALUE, null all 
  // other arrays
  //
  for ( DWORD i=0; i<dwNumPipeInstances; ++i )
  {
    m_ahPipes[i] = INVALID_HANDLE_VALUE ;
  }
  //
  memset(m_aOverlapped, '\0', sizeof(m_aOverlapped)) ;
  //
  memset(
    m_ahOlEventsAndExitEvent, 
    '\0', 
    sizeof(m_ahOlEventsAndExitEvent)
    ) ;
  
  // Pipes not created/connected
  m_bPipesCreatedAndConnected = FALSE ;

}
  

///////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
CNamedPipeArray<dwNumPipeInstances>::~CNamedPipeArray(
//
// The destructor calls Hangup to disconnect all named pipes
// and close all handles. Exceptions are not propagated.
//
)
//
{
  try{Hangup();}catch(...){}
}


///////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
CNamedPipeArray<dwNumPipeInstances>::waitResult 
CNamedPipeArray<dwNumPipeInstances>::Listen(
//
// The Listen member function waits for a client to connect to 
// one of the pipe instances, then returns the index of the 
// connected pipe.
//
DWORD& refdwIndex, // reference to index
// 
// Refers to the DWORD location to receive the index of the 
// connected pipe.
//
DWORD dwMilliseconds // timeout
//
// Indicates the timeout value in milliseconds or INFINITE.
//
)
//
// Return Value and Exceptions
// 
// If the function succeeds, the return value is waitSuccess.
// If the function notices that the exit event was set,
// the return value is waitExitEvent.
//
// If the function fails, a CWin32Exception is thrown.
//
// Remarks
//
// The function creates and connects the named pipes when it 
// is called for the first time. In case of an exception, pipes
// and events are cleaned up. 
//
// To terminate the listening, set the exit event. This will 
// also cause all read and write operations to return 
// immediately. Note that there may still be asynchronous
// read or write operations in progress in this case.
//
// After a timeout has occurred, the Listen function can
// be called again any time. Clients that have connected
// during the absence of Listen will not be lost unless
// they themselves have closed their handles.
//
// When the function is called with a timeout of 0 ms, it
// is guaranteed that the return value will be waitTimeout. 
// The only effect of the function in this case is to create 
// and connect the named pipes if they do not already exist.
//
{

  DWORD dwRetVal ;
  DWORD dwRetIndex ;
  
  try
  {
    // Create and connect named pipes first time 
    // around. The CreateAndConnecPipes function 
    // may throw a CWin32Exception, which we just 
    // propagate. (Hangup will be called twice in
    // this case, no problem).
    //
    if ( !m_bPipesCreatedAndConnected )
    {
      CreateAndConnectPipes() ;
      m_bPipesCreatedAndConnected = TRUE ;
    }
    
    // Make sure no client is accepted when timeout
    // was 0.
    //
    if ( 0 == dwMilliseconds ) return waitTimeout ;

    // Make sure exit event has been set
    _ASSERT(NULL != m_hExitEvent) ;
    
    // Wait for clients to connect or exit event being set
    //
    dwRetVal = WaitForMultipleObjects(
      dwNumPipeInstances+1,	// number of handles  
      m_ahOlEventsAndExitEvent,	// pointer to array 
      FALSE,	// wait flag 
      dwMilliseconds 	// time-out interval in milliseconds 
      );
    //
    if ( WAIT_FAILED == dwRetVal ) THROW_WIN32_EXCEPTION ;

    // Timeout occurred
    if ( WAIT_TIMEOUT == dwRetVal ) return waitTimeout ;

    // Index of event that caused the multiple wait to return
    dwRetIndex = dwRetVal - WAIT_OBJECT_0 ;
    
    // Exit event was signaled
    if ( dwNumPipeInstances == dwRetIndex ) 
    {
      return waitExitEvent ;
    }

    // Now we have successfully connected to a client. The
    // event that caused the WFMO to return must be reset 
    // immediately. The index is placed into the dwIndex 
    // argument.
    //
    ResetEvent(m_ahOlEventsAndExitEvent[dwRetIndex]) ;
    refdwIndex = dwRetIndex ;
    return waitSuccess ;
  
  }
  catch(CWin32Exception&)
  {
    // Exception: clean up pipes and handles, throw. Ignore
    // exceptions from Hangup to prevent actual exception 
    // from getting lost.
    //
    try { Hangup() ;} catch(...) {}
    throw ; 
  }

}  
 

///////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
CNamedPipeArray<dwNumPipeInstances>::waitResult 
CNamedPipeArray<dwNumPipeInstances>::Read(
//
// The Read member function reads from a pipe instance whose 
// index has been obtained from the Listen member function.
//  
DWORD dwIndex,	// index of pipe instance to read 
//
// Indicates the index of the pipe instance to read from. 
// The index must have been obtained from the Listen member 
// function.
//
LPVOID lpBuffer,	// address of buffer that receives data  
//
// As in ReadFile.
//
DWORD dwNumberOfBytesToRead,	// number of bytes to read 
//
// As in ReadFile.
//
LPDWORD lpdwNumberOfBytesRead,	// &number of bytes read 
//
// As in ReadFile.
//
//
DWORD dwMilliseconds // timeout value
//
// Indicates the timeout in milliseconds for the wait operation,
// or INFINITE.
//
)
//
// Return Value and Exceptions
// 
// If the function succeeds, the return value is waitSuccess.
// If the wait operation timed out, the return value is 
// waitTimeout.
// If the function notices that the exit event was set,
// the return value is waitExitEvent.
//
// If the function fails, a CWin32Exception is thrown.
//
// Remarks
//
// When the client closes her end of the pipe, the function 
// throws an exception with error code ERROR_BROKEN_PIPE. In 
// this case, the pipe instance can simply be reconnected by 
// means of the Reconnect member function. All other exceptions
// should be considered unrecoverable.
//
{

  // Overlapped element for asynchronous read/write
  OVERLAPPED ol ;
  
  // Event for overlapped struct
  HANDLE hOlEvent = NULL ;
  
  HANDLE ahOlExit[2] ;
  DWORD dwRetVal;
  
  _ASSERT(0 <= dwIndex && dwIndex < dwNumPipeInstances) ;
  _ASSERT(INVALID_HANDLE_VALUE != m_ahPipes[dwIndex]) ;

  try
  {
    // Create event for overlapped struct.
    //
    hOlEvent = CreateEvent(
      NULL,	// pointer to security attributes  
      TRUE,	// flag for manual-reset event 
      FALSE,	// flag for initial state 
      NULL 	// pointer to event-object name  
      );
    //
    if ( NULL == hOlEvent ) THROW_WIN32_EXCEPTION ;
    
    // Read dwNumberOfBytesToRead bytes from the pipe.
    //
    memset(&ol, 0x00, sizeof(OVERLAPPED) ) ;
    ol.hEvent = hOlEvent ;
    ResetEvent(ol.hEvent) ;
    //
    dwRetVal = ReadFile(
      m_ahPipes[dwIndex],	// index of pipe instance 
      lpBuffer,	// address of buffer that receives data  
      dwNumberOfBytesToRead,	// number of bytes to read 
      lpdwNumberOfBytesRead,	// &number of bytes read 
      &ol 	// address of overlapped struct
      ) ;
    
    // If ReadFile failed because of ERROR_IO_PENDING: wait 
    // for completion. After GetOverlappedResult has returned,
    // GetLastError will contain the error status for the
    // ReadFile operation. We must simultaneously wait
    // for the exit event.
    //
    if ( ! dwRetVal && ERROR_IO_PENDING == GetLastError() )
    {
      
      // Wait for completion or exit event
      //
      ahOlExit[0] = ol.hEvent ;
      ahOlExit[1] = hExitEvent ;
      dwRetVal = WaitForMultipleObjects(
        2,	// number of handles in the object handle array 
        ahOlExit,	// pointer to the object-handle array 
        FALSE,	// wait flag 
        dwMilliseconds 	// time-out interval in milliseconds 
        );
      
      // Wait error
      //
      if ( WAIT_FAILED == dwRetVal ) THROW_WIN32_EXCEPTION ;
      
      // Timeout ocurred
      //
      if ( WAIT_TIMEOUT == dwRetVal )
      {
        CloseHandle( hOlEvent ) ;
        return waitTimeout ;
      }
      
      // Exit event was set
      //
      if ( 1 == dwRetVal - WAIT_OBJECT_0 )
      {
        CloseHandle( hOlEvent ) ;
        return waitExitEvent ;
      }
        
      // Read completed. Get overlapped result.
      //
      dwRetVal = GetOverlappedResult(
        m_ahPipes[dwIndex],	// handle of communications device
        &ol,	// address of overlapped structure 
        lpdwNumberOfBytesRead,	// actual bytes count
        FALSE 	// wait flag 
        ) ;
    }
    
    // Now dwRetVal and GetLastError are as if the read
    // operation had been synchronous. Deal with errors.
    //
    if ( ! dwRetVal ) THROW_WIN32_EXCEPTION ;
    
    CloseHandle( hOlEvent ) ;
    return waitSuccess ;
    
  }
  catch(CWin32Exception&)
  {
    if ( NULL != hOlEvent ) CloseHandle( hOlEvent ) ;
    throw ;
  }

}


///////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
CNamedPipeArray<dwNumPipeInstances>::waitResult 
CNamedPipeArray<dwNumPipeInstances>::Write(
//
// The Write member function writes to a pipe instance whose 
// index has been obtained from the Listen member function.
//  
DWORD dwIndex,	// index of pipe instance to write 
//
// Indicates the index of the pipe instance to write to. The 
// index must have been obtained from the Listen member 
// function.
//
LPCVOID lpBuffer,	// pointer to data to write to file   
//
// As in WriteFile.
//
DWORD dwNumberOfBytesToWrite,	// number of bytes to write 
//
// As in WriteFile.
//
LPDWORD lpdwNumberOfBytesWritten,	// number of bytes written
//
// As in WriteFile.
//
//
DWORD dwMilliseconds // timeout value
//
// Indicates the timeout in milliseconds for the wait 
// operation, or INFINITE.
//
)
//
// Remarks
//
// When the client closes her end of the pipe, the function 
// throws an exception with error code ERROR_NO_DATA. In this 
// case, the pipe instance can simply be reconnected by means 
// of the Reconnect member function. All other exceptions 
// should be considered unrecoverable.
//
// Return Value and Exceptions
// 
// If the function succeeds, the return value is waitSuccess.
// If the wait operation timed out, the return value is 
// waitTimeout.
// If the function notices that the exit event was set,
// the return value is waitExitEvent.
//
// If the function fails, a CWin32Exception is thrown.
//
{

  
  // Overlapped element for asynchronous read/write
  OVERLAPPED ol ;
  
  // Event for overlapped struct
  HANDLE hOlEvent = NULL ;
  
  HANDLE ahOlExit[2] ;
  DWORD dwNumBytes ;
  DWORD dwRetVal;
  
  _ASSERT(0 <= dwIndex && dwIndex < dwNumPipeInstances) ;
  _ASSERT(INVALID_HANDLE_VALUE != m_ahPipes[dwIndex]) ;

  try
  {
    // Create event for overlapped struct.
    //
    hOlEvent = CreateEvent(
      NULL,	// pointer to security attributes  
      TRUE,	// flag for manual-reset event 
      FALSE,	// flag for initial state 
      NULL 	// pointer to event-object name  
      );
    //
    if ( NULL == hOlEvent ) THROW_WIN32_EXCEPTION ;
    
    // Write to pipe. 
    //
    memset(&ol, 0x00, sizeof(OVERLAPPED) ) ;
    ol.hEvent = hOlEvent ;
    ResetEvent(ol.hEvent) ;
    //
    dwRetVal = WriteFile(
      m_ahPipes[dwIndex],	// handle to file to write to 
      lpBuffer,	// pointer to data to write to file 
      dwNumberOfBytesToWrite,	// number of bytes to write 
      lpdwNumberOfBytesWritten,	// &number of bytes written 
      &ol 	// address of structure needed for overlapped I/O
      ) ;
    
    // If WriteFile failed because of ERROR_IO_PENDING: wait 
    // for completion. After GetOverlappedResult has returned,
    // GetLastError will contain the error status for the
    // WriteFile operation.  We must simultaneously wait
    // for the exit event.
    //
    if ( ! dwRetVal && ERROR_IO_PENDING == GetLastError() )
    {
      
      // Wait for completion or exit event
      //
      ahOlExit[0] = ol.hEvent ;
      ahOlExit[1] = hExitEvent ;
      dwRetVal = WaitForMultipleObjects(
        2,	// number of handles in the object handle array 
        ahOlExit,	// pointer to the object-handle array 
        FALSE,	// wait flag 
        INFINITE 	// time-out interval in milliseconds 
        );
      
      // Wait error
      //
      if ( WAIT_FAILED == dwRetVal ) THROW_WIN32_EXCEPTION ;
      
      // Timeout
      //
      if ( WAIT_TIMEOUT == dwRetVal )
      {
        CloseHandle( hOlEvent ) ;
        return waitTimeout ;
      }
      
      // Exit event was set
      //
      if ( 1 == dwRetVal - WAIT_OBJECT_0 )
      {
        CloseHandle( hOlEvent ) ;
        return waitExitEvent ;
      }
      
      // Write completed: get overlapped result
      //
      dwRetVal = GetOverlappedResult(
        m_ahPipes[dwIndex],	// handle of communications device  
        &ol,	// address of overlapped structure 
        &dwNumBytes,	// address of actual bytes count 
        TRUE 	// wait flag 
        ) ;
    }
    
    // Now dwRetVal and GetLastError are as if the write
    // operation had been synchronous. Deal with errors.
    //
    if ( ! dwRetVal ) THROW_WIN32_EXCEPTION ;
    
    CloseHandle( hOlEvent ) ;
    return waitSuccess ;  

  }
  catch(CWin32Exception&)
  {
    if ( NULL != hOlEvent ) CloseHandle( hOlEvent ) ;
    throw ;
  }

}


///////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
void CNamedPipeArray<dwNumPipeInstances>::Flush(
//
// The Flush member function calls the FlushFileBuffers API on 
// the pipe instance with the specified index.
//
DWORD dwIndex // pipe index
//
// Indicates the index of the pipe instance to be flushed.
//
)
//
// Return Value and Exceptions
// 
// If the function fails, a CWin32Exception is thrown.
//
// Remarks
// 
// The function  must be called to prevent loss of data that
// the client has not yet read when the server writes to a 
// pipe and then disconnects that pipe.
//
// When the client closes her end of the pipe, the function 
// throws an exception with error code ERROR_BROKEN_PIPE. In 
// this case, the pipe instance can simply be reconnected by 
// means of the Reconnect member function. All other 
// exceptions should be considered unrecoverable.
//
// Note: there is no timeout or simultaneous wait for an exit 
// event. A client who refuses to read can hang the server 
// here. It is recommended to use a protocol that requires the 
// client to send a Roger at the end of a transaction. This 
// avoids calls to the Flush function altogether.
//
{

  _ASSERT(0 <= dwIndex && dwIndex < dwNumPipeInstances) ;
  _ASSERT(INVALID_HANDLE_VALUE != m_ahPipes[dwIndex]) ;

  if ( ! FlushFileBuffers(m_ahPipes[dwIndex]) )
    THROW_WIN32_EXCEPTION ;

} 


///////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
void CNamedPipeArray<dwNumPipeInstances>::Reconnect(
//
// The Reconnect member function disconnects and reconnects a 
// pipe instance after a client has been served on the pipe 
// instance. This function must only be called for indices that 
// have been obtained from the Listen member functions.
//
DWORD dwIndex // pipe index
//
// Indicates the index of the pipe to be reconnected.
//
)
//
// Return Value and Exceptions
//
// If the function fails, a CWin32Exception is thrown.
//
{

  BOOL bRetVal ;

  _ASSERT(0 <= dwIndex && dwIndex < dwNumPipeInstances) ;
  _ASSERT ( INVALID_HANDLE_VALUE != m_ahPipes[dwIndex] ) ;

  // Disconnect named pipe. 
  //
  if ( ! DisconnectNamedPipe(m_ahPipes[dwIndex]) )    
    THROW_WIN32_EXCEPTION ;
  
  // Reconnect asynchronously
  //
  bRetVal = ConnectNamedPipe(
    m_ahPipes[dwIndex],	// handle to named pipe to connect  
    & m_aOverlapped[dwIndex] // pointer to overlapped structure 
    ) ;	
  //
  if ( ! bRetVal 
       && 
       ERROR_IO_PENDING != GetLastError()
       &&
       ERROR_PIPE_CONNECTED != GetLastError() )
  {
    THROW_WIN32_EXCEPTION ;
  }
  
}


///////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
void 
CNamedPipeArray<dwNumPipeInstances>::CreateAndConnectPipes(
//
// The CreateAndConnect member function creates 
// dwNumPipeInstances many instances of the pipe named 
// pchPipeName with corresponding overlapped structs, then 
// connects the named pipes asynchronously.
//
)
//
// Return Value and Exceptions
//
// If the function fails, it throws a CWin32Exception. All 
// pipes and events that have been created until the error 
// occurred are cleaned up.
//
{

  DWORD dwIndex ;
  BOOL bRetVal ;
  
  // Security descriptor and attributes for named pipe
  //
  BYTE abSD[SECURITY_DESCRIPTOR_MIN_LENGTH] ;
  PSECURITY_DESCRIPTOR p_secdesSD 
    = (PSECURITY_DESCRIPTOR) abSD ;
  SECURITY_ATTRIBUTES secattrSA;

  try
  {
    
    // Initialize security descriptor.
    //
    if ( !InitializeSecurityDescriptor(
      p_secdesSD, 
      SECURITY_DESCRIPTOR_REVISION) ) THROW_WIN32_EXCEPTION ; 
    
    // Set discretionary access control list to NULL. This 
    // allows everybody all access.
    //
    if (!SetSecurityDescriptorDacl(
      p_secdesSD, 
      TRUE, 
      (PACL) NULL, 
      FALSE
      ) ) THROW_WIN32_EXCEPTION ;
    
    secattrSA.nLength = sizeof(secattrSA) ;
    secattrSA.lpSecurityDescriptor = p_secdesSD ;
    secattrSA.bInheritHandle = FALSE ;

    // Overlapped structs must be nulled.
    memset(
      m_aOverlapped, 
      0x00, 
      dwNumPipeInstances * sizeof(OVERLAPPED)) ;
    
    // Create all named pipes
    //
    for (dwIndex=0; dwIndex < dwNumPipeInstances; dwIndex++)
    {
      
      // Create named pipe
      //
      m_ahPipes[dwIndex] = CreateNamedPipe(
        m_achPipeName,	// pointer to pipe name 
        PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED ,	// mode 
        PIPE_TYPE_BYTE | PIPE_WAIT,	// pipe-specific modes 
        dwNumPipeInstances,	// maximum number of instances  
        4096,	// output buffer size, in bytes 
        4096,	// input buffer size, in bytes 
        0,	// default time-out time, in milliseconds 
        &secattrSA 	// pointer to security attributes structure 
        );
      //
      if ( INVALID_HANDLE_VALUE == m_ahPipes[dwIndex] )
      {
         THROW_WIN32_EXCEPTION ;
      }

    }
    //
    // End for-loop creating named pipes

    // Now connect all named pipes asynchronously. This is
    // done in a separate for-loop, because we don't want
    // any clients to connect until we know all pipe instances
    // have been created successfully.
    //
    for (dwIndex=0; dwIndex < dwNumPipeInstances; dwIndex++)
    {

      // Create overlapped event for named pipe connection
      //
      m_ahOlEventsAndExitEvent[dwIndex] = CreateEvent(
        NULL,	// pointer to security attributes  
        TRUE,	// flag for manual-reset event 
        FALSE,	// flag for initial state 
        NULL 	// pointer to event-object name  
        );
      //
      if ( NULL == m_ahOlEventsAndExitEvent[dwIndex] )
      {
        THROW_WIN32_EXCEPTION ;
      }
      
      // Connect the instance of the pipe asynchronously,
      // using the event as overlapped event. Note: the function
      // returns FALSE in two cases that aren't really errors.
      // ERROR_PIPE_CONNECTED means a client has already 
      // snatched the pipe instance. ERROR_IO_PENDING means 
      // that the asynchronous call was successful, but no 
      // client has connected yet.
      //
      m_aOverlapped[dwIndex].hEvent 
        = m_ahOlEventsAndExitEvent[dwIndex] ;
      bRetVal = ConnectNamedPipe(
        m_ahPipes[dwIndex],	// handle to named pipe to connect  
        & m_aOverlapped[dwIndex] 	// &overlapped structure 
        ) ;
      //
      if ( ! bRetVal 
           && 
           ERROR_IO_PENDING != GetLastError() 
           &&
           ERROR_PIPE_CONNECTED != GetLastError() )
      {
        THROW_WIN32_EXCEPTION ;
      }
    }
    //
    // End for-loop connection named pipes
    
    // Place handle of exit event in array 
    // m_ahOlEventsAndExitEvent
    //
    m_ahOlEventsAndExitEvent[dwNumPipeInstances] 
      = m_hExitEvent ;
    
  }
  catch(CWin32Exception&)
  {
    
    // Ignore exception from Hangup so actual exception won't
    // get lost.
    //
    try { Hangup() ; } catch(...) {}
    throw ;
  }

}

////////////////////////////////////////////////////////////////////
//
template <DWORD dwNumPipeInstances>
void CNamedPipeArray<dwNumPipeInstances>::Hangup(
//
// The Hangup member functions disconnects the named pipes, 
// closes all handles, and nulls the arrays.
//
)
//
// Return Value and Exceptions
//
// If the function fails, it throws a CWin32Exception.
//
// Remarks
//
// The function can be called multiple times. Actually,
// closing the handles is not all that important when one exits
// the process. However, it is very important to disconnect all
// named pipes. If the server side of a named pipe exits 
// without disconnecting and a client holds on to the pipe, 
// that pipe instances remains busy.
//
{
  
  DWORD dwIndex ;
  
  // Disconnect pipes, close their handles, set entry in
  // handle array to NULL. 
  //
  for (dwIndex=0; dwIndex < dwNumPipeInstances; dwIndex++)
  {
    if ( INVALID_HANDLE_VALUE != m_ahPipes[dwIndex] )
    {
      if ( ! DisconnectNamedPipe(m_ahPipes[dwIndex]) )
      {
        THROW_WIN32_EXCEPTION ;
      }
      
      if ( ! CloseHandle(m_ahPipes[dwIndex]) )
      {
        THROW_WIN32_EXCEPTION ;
      }
      
      m_ahPipes[dwIndex] = INVALID_HANDLE_VALUE ;
      
    }
    //
    // End if pipe handle is not INVALID_HANDLE_VALUE
    
  }
  //
  // End loop through pipe handle array

  // Close all *overlapped event* handles in array 
  // m_ahOlEventsAndExitEvent and set entries to NULL.
  //
  for ( dwIndex = 0 ; 
        dwIndex < dwNumPipeInstances ;
        ++dwIndex )
  {
    if ( NULL != m_ahOlEventsAndExitEvent[dwIndex] )
    {
      if ( ! CloseHandle(m_ahOlEventsAndExitEvent[dwIndex]) )
      {
        THROW_WIN32_EXCEPTION ;
      }
      m_ahOlEventsAndExitEvent[dwIndex] = NULL ;
    }
  }

  // Null arrays of overlapped structs.
  //
  memset(m_aOverlapped, '\0', sizeof(m_aOverlapped)) ;
  
  // Pipes not created/connected
  m_bPipesCreatedAndConnected = FALSE ;

}


#endif
//
// End protection against multiple inclusion
