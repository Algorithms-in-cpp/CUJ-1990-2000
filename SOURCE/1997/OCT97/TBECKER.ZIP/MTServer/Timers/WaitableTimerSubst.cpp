//
// File: CWaitableTimerSubst.cpp	
//
// Created: February 1996
//
// Author: Dr. Thomas Becker
//
// A C++ class that provides a functionality similar to Win32
// waitable timers until such time as these become available in
// Visual C++ under NT.
//

// Includes
// ========

#include<windows.h>
#include"WaitableTimerSubst.h"

/////////////////////////////////////////////////////////////
//
// Implementation Of CWaitableTimerSubst Member Functions
//
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
CWaitableTimerSubst::CWaitableTimerSubst(
//
// The CWaitableTimerSubst default constructor creates the
// thread and the alarm event as well as the internal 
// synchronization objects.
//
BOOL bAlarmEventManual // = FALSE, manual reset alarm event
//
// Indicates if the alarm event should be a manual reset
// event.
//
) : m_loExitFlag(0)
//
// Remarks
//
// After construction, the timer is in an inactive state, 
// and the alarm event is not signalled. No error checks 
// are made to prevent exceptions propagating from the
// constructor. Validity checks on the handles will be 
// performed in member functions.
//
{
  
  // Initialize critical section
  InitializeCriticalSection(&cs) ;
  
  // Create alarm event. Note: no error check here, will be
  // performed later by member functions.
  //
  m_hAlarmEvent = CreateEvent(
    NULL,	// pointer to security attributes  
    bAlarmEventManual,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );

  // Create ready event. Note: no error check here, will be 
  // performed later by member functions.
  //
  m_hReadyEvent = CreateEvent(
    NULL,	// pointer to security attributes  
    TRUE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    ) ;
  
  // Create start event. Note: no error check here, will be
  // performed later by member functions.
  //
  m_hStartEvent = CreateEvent(
    NULL,	// pointer to security attributes  
    FALSE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );
  
  // Create cancel event. Note: no error check here, will be
  // performed later by member functions.
  //
  m_hCancelEvent = CreateEvent(
    NULL,	// pointer to security attributes  
    FALSE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );
  
  // Create timer thread with priority TIME_CRITICAL. Note: 
  // no error check here, will be performed later by member 
  // functions. We use _beginthreadex instead of CreateThread
  // because you never know who will use runtime lib functions
  // (exception constructors!).
  //
  UINT uiThreadId ;
  m_hTimerThread = (HANDLE) _beginthreadex(
    NULL,	// pointer to thread security attributes  
    0,	// initial thread stack size, in bytes 
    ( UINT (__stdcall *) (LPVOID) ) TimerThread,	
    this,	// argument for new thread 
    0,	// creation flags 
    &uiThreadId 	// pointer to returned thread identifier 
    );	
  //
  SetThreadPriority(
    m_hTimerThread, 
    THREAD_PRIORITY_TIME_CRITICAL) ;

} 

///////////////////////////////////////////////////////////////
//
CWaitableTimerSubst::~CWaitableTimerSubst(
//
// The CThreadTimer destructor cancels the timer, closes 
// all handles, and deletes the critical section.
//
)
//
{
  
  try
  {
   
    // Stop timer.
    //
    if ( NULL != m_hCancelEvent &&
      NULL != m_hStartEvent &&
      NULL != m_hTimerThread )
    {
      InterlockedIncrement(&m_loExitFlag) ;
      if ( ! SetEvent(m_hCancelEvent) ) THROW_WIN32_EXCEPTION ;
      if ( ! SetEvent(m_hStartEvent) ) THROW_WIN32_EXCEPTION ;
      
      DWORD dwRetVal = WaitForSingleObject(
        m_hTimerThread, 
        3000) ;
      //
      if ( WAIT_FAILED == dwRetVal ) THROW_WIN32_EXCEPTION ;
      
      // If thread has not exited after 3 secs, try to 
      // terminate brute force.
      //
      if ( WAIT_TIMEOUT == dwRetVal
           &&
           ! TerminateThread(m_hTimerThread, 1) )
      {
        THROW_WIN32_EXCEPTION ;
      }
      
      // If the timer thread terminated abnormally, it
      // has already thrown a non-propagated exception. No
      // point in throwing again here, because we're in
      // a destructor and cannot propagate.

    }

    // Delete critical section
    DeleteCriticalSection(&cs) ;
    
    // Close handles. 
    //
    if ( NULL != m_hTimerThread )
      CloseHandle(m_hTimerThread) ;
    if ( NULL != m_hAlarmEvent )
      CloseHandle(m_hAlarmEvent) ;
    if ( NULL != m_hReadyEvent )
      CloseHandle(m_hReadyEvent) ;
    if ( NULL != m_hStartEvent )
      CloseHandle(m_hStartEvent) ;
    if ( NULL != m_hCancelEvent )
      CloseHandle(m_hCancelEvent) ;

  }
  catch(...){}

}


/////////////////////////////////////////////////////////////
//
UINT __stdcall CWaitableTimerSubst::TimerThread(
//
// The timer thread function waits for the timer to be set,
// then sets the alarm event after waiting for the specified
// time interval, unless cancellation occurs first.
//
CWaitableTimerSubst *pThis // thread function argument
//
// Indicates the thread argument.
//
)
//
// Return value
//
// If an error occurs, the function returns the last error
// code.
//
// Remarks
//
// The thread function is a static member function of the
// class because its address must be passed to the 
// CreateThread function. The this pointer is passed as the
// argument.
//
{
  
  try
  {
    
    // Event handles were not checked by constructor, so
    // they must be checked here
    //
    if ( NULL == pThis->m_hAlarmEvent ||
      NULL == pThis->m_hReadyEvent ||
      NULL == pThis->m_hStartEvent ||
      NULL == pThis->m_hCancelEvent  ) 
    {
      SetLastError(ERROR_INVALID_HANDLE) ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Each run through the infinite loop is one cycle of 
    // the timer.
    //
    while (1)
    {
      
      // Signal readyness to the Set member function. This 
      // gives the Set member function a chance to safely set 
      // the timeout value and to reset the alarm, ready, and 
      // cancel events.
      //
      if ( !SetEvent( pThis->m_hReadyEvent) ) 
        THROW_WIN32_EXCEPTION ;
      
      
      // The Set member function starts the timer by setting
      // the start event. 
      //
      if ( WAIT_FAILED == WaitForSingleObject(
        pThis->m_hStartEvent, 
        INFINITE) )THROW_WIN32_EXCEPTION ;
      
      // THIS IS WHERE THE TIMER ENTERS WHAT WE CALL THE 
      // ACTIVE STATE. THE ACTIVE STATE LASTS TIL THE END
      // OF THE WHILE LOOP.
      
      // Now we can be sure that the Set member function has
      // set the timeout value and reset the alarm, ready, and
      // cancel events. Wait for cancel event with timeout.
      //
      DWORD dwWaitResult = WaitForSingleObject(
        pThis->m_hCancelEvent, 
        pThis->m_dwMilliSeconds) ;
      
      if ( WAIT_FAILED == dwWaitResult ) 
        THROW_WIN32_EXCEPTION ;
      
      // If exit flag is set, exit thread
      if ( pThis->m_loExitFlag ) break ;
      
      // If timeout is reached (timer was not cancelled), set 
      // alarm event.
      //
      if ( WAIT_TIMEOUT == dwWaitResult )
      {
        if ( ! SetEvent(pThis->m_hAlarmEvent) )
          THROW_WIN32_EXCEPTION ;
      }
      
    }
    
  }
  catch(CWin32Exception& eWin32)
  {
    return eWin32.GetErrorCode() ;
  }
  
  return 0 ;
  
}

  
/////////////////////////////////////////////////////////////
//
void CWaitableTimerSubst::Set(
//
// The Set member function sets the timer to the specified 
// number of  milliseconds.
// 
DWORD dwMilliSeconds // timer interval
// 
// Indicates the timer interval in milliseconds.
//
)
//
// Return Value and Exceptions
//
// If the function fails, it throws a CWin32Exception.
//
// Remarks
//
// The function can be called anytime. When the timer is in 
// the active state and waiting for the time interval to 
// elapse, it is started anew without the alarm event being 
// set.
//
{
  
  try
  {

    // Enter critical section to make Set and Cancel thread
    // safe.
    //
    EnterCriticalSection(&cs) ;
    
    // The timer could be in the active state. Calling the
    // Cancel member functions ensures that the timer thread
    // is waiting for the start event to be set.
    //
    Cancel() ;
    
    // Now the timer thread is waiting on the start event.
    // This gives us the chance to prepare everything for the 
    // next timer interval: set interval and reset alarm event,
    // ready event, and cancel event.
    //
    m_dwMilliSeconds = dwMilliSeconds ;
    if ( ! ResetEvent(m_hAlarmEvent) ||
      ! ResetEvent(m_hReadyEvent) ||
      ! ResetEvent(m_hCancelEvent) ) THROW_WIN32_EXCEPTION ;
    
    
    // Finally, we can release the timer thread to actually 
    // get the timer going.
    //
    if ( ! SetEvent (m_hStartEvent) ) THROW_WIN32_EXCEPTION ;
    
    // Leave critical section to make Set and Cancel thread
    // safe
    //
    LeaveCriticalSection(&cs) ;

  }
  catch(...)
  {
    LeaveCriticalSection(&cs) ;
    throw ;
  }
  
}

/////////////////////////////////////////////////////////////
//
void CWaitableTimerSubst::Cancel(
//
// The Cancel member function interrupts the timer and
// causes it to enter the inactive state.
// 
)
//
// Return Value and Exceptions
//
// If the function fails, it throws a CWin32Exception.
//
// Remarks
// 
// The cancel member function does not affect the state of
// the alarm event. All that is guaranteed is that when
// the cancel function returns, the timer is in the inactive
// state, waiting to be set off again. 
//
// When the function  catches the timer in the active state
// while it is waiting for the time period to elapse, the wait
// is abandoned and the alarm event is not set. 
//
// When the function catches the timer in the active state
// after the time period has elapsed, the cancel operation
// has no effect. The same is true when the timer is caught
// in the inactive state.
//
{
  
  DWORD dwExitCode ;
  
  try
  {

    // Enter critical section to make Set and Cancel thread
    // safe
    //
    EnterCriticalSection(&cs) ;
    
    // Check handles because this was not done in constructor.
    //
    if ( m_hTimerThread == NULL ||
      m_hReadyEvent == NULL ||
      m_hStartEvent == NULL ||
      m_hAlarmEvent == NULL ||
      m_hCancelEvent == NULL ) 
    {
      SetLastError(ERROR_INVALID_HANDLE) ;
      THROW_WIN32_EXCEPTION ;
    }
    
    // Check if thread is actually running, because invalid
    // event handles could have caused it to terminate with
    // an exception.
    //
    if ( ! GetExitCodeThread(m_hTimerThread, &dwExitCode) )
      THROW_WIN32_EXCEPTION ;
    //
    SetLastError(ERROR_INVALID_HANDLE) ;
    if ( STILL_ACTIVE != dwExitCode) THROW_WIN32_EXCEPTION ;
    
    // The timer may or may not be active. We must cancel it by
    // setting the cancel event ( = release from wait with 
    // timeout).
    //
    if ( ! SetEvent(m_hCancelEvent) ) THROW_WIN32_EXCEPTION ;
    
    // Next, we must wait for the thread to signal that it is 
    // in the state of waiting on the start event. Note: The
    // ready event is a manual reset event, so it will remain
    // signalled after the wait.
    //
    if ( WAIT_FAILED == WaitForSingleObject(
      m_hReadyEvent, 
      INFINITE) ) THROW_WIN32_EXCEPTION ;
    
    // Leave critical section to make Set and Cancel thread
    // safe
    //
    LeaveCriticalSection(&cs) ;
    
  }
  catch(...)
  {
    LeaveCriticalSection(&cs) ;
    throw ;
  }
  
}

