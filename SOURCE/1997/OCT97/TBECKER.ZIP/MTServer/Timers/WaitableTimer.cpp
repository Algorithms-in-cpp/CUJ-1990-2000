//
// File: CWaitableTimer.cpp	
//
// Created: February 1996
//
// Author: Dr. Thomas Becker
//
// A C++ class that wraps the Win32 waitable timer object. 
// Timers are restricted to non-periodic having no completion
// routine. The reason for providing this wrapper is to make
// it easier to switch to a substitute when working with
// NT version 3.51 or less. Waitable timers did not become
// available until version 4.0.
//

// Includes
// ========

#include<windows.h>
#include"WaitableTimer.h"

/////////////////////////////////////////////////////////////
//
// Implementation Of CWaitableTimer Member Functions
//
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
CWaitableTimer::CWaitableTimer(
//
// The CWaitableTimer default constructor creates the waitable
// timer object.
//
BOOL bManualReset // = FALSE, manual reset timer
//
// Indicates if the timer should be a manual reset timer.
//
)
//
// Remarks
//
// After construction, the timer is in an inactive state, 
// and the handle is not signalled. No error checks 
// are made to prevent exceptions propagating from the
// constructor. Validity checks on the handles will be 
// performed in member functions.
//
{
  
  // Create waitable timer event. Note: no error check here,
  // will be performed later by member functions.
  //
  m_hWaitableTimer = CreateWaitableTimer( 
    NULL, // pointer to security attributes 
    bManualReset, // flag for manual reset state 
    NULL // pointer to timer object name 
    ); 

} 

///////////////////////////////////////////////////////////////
//
CWaitableTimer::~CWaitableTimer(
//
// The CThreadTimer destructor closes the handle.
//
)
//
{
  
  // Close handle. 
  //
  if ( NULL != m_hWaitableTimer )
    CloseHandle(m_hWaitableTimer) ;

}


  
/////////////////////////////////////////////////////////////
//
void CWaitableTimer::Set(
//
// The Set member function sets the timer to the specified 
// number of  milliseconds.
// 
DWORD dwMilliSeconds // timer interval
// 
// Indicates the timer interval in milliseconds.
//
)
//
// Return Value and Exceptions
//
// If the function fails, it throws a CWin32Exception.
//
// Remarks
//
// The function can be called anytime. When the timer is in 
// the active state and waiting for the time interval to 
// elapse, it is started anew without the handle being 
// signaled.
//
{
  
  // Check handle because this was not done in constructor.
  //
  if ( NULL == m_hWaitableTimer ) 
  {
    SetLastError(ERROR_INVALID_HANDLE) ;
    THROW_WIN32_EXCEPTION ;
  }
 
  // Set timer
  //
  LARGE_INTEGER lintDueTime ;
  lintDueTime.QuadPart = - (LONGLONG) UInt32x32To64(
    10000, // specifies first unsigned 32-bit integer
    dwMilliSeconds // specifies second unsigned 32-bit integer
    ); 
  //
  if ( !SetWaitableTimer( 
    m_hWaitableTimer, // handle to a timer object 
    &lintDueTime, // when timer will become signaled 
    0, // periodic timer interval 
    NULL, // pointer to the completion routine 
    NULL, // data passed to the completion routine
    FALSE // flag for resume state 
    ) ) THROW_WIN32_EXCEPTION ;
    
}

/////////////////////////////////////////////////////////////
//
void CWaitableTimer::Cancel(
//
// The Cancel member function interrupts the timer and
// causes it to enter the inactive state.
// 
)
//
// Return Value and Exceptions
//
// If the function fails, it throws a CWin32Exception.
//
// Remarks
// 
// The cancel member function does not affect the state of
// the handle. All that is guaranteed is that when
// the cancel function returns, the timer is in the inactive
// state, waiting to be set off again. 
//
// When the function  catches the timer in the active state
// while it is waiting for the time period to elapse, the wait
// is abandoned and the handle is not signaled. 
//
// When the function catches the timer in the inactive state,
// the cancel operation has no effect.
//
{
  
  // Check handle because this was not done in constructor.
  //
  if ( NULL == m_hWaitableTimer ) 
  {
    SetLastError(ERROR_INVALID_HANDLE) ;
    THROW_WIN32_EXCEPTION ;
  }
 
  // Set timer
  //
  if ( !CancelWaitableTimer( 
    m_hWaitableTimer // handle to a timer object 
    ) ) THROW_WIN32_EXCEPTION ;
  
}

