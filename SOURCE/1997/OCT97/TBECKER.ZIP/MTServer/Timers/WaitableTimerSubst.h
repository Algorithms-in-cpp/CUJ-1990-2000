//
// File: CWaitableTimerSubst.h	
//
// Created: February 1996
//
// Author: Dr. Thomas Becker
//
// A C++ class that provides a functionality similar to Win32
// waitable timers until such time as these become available in
// Visual C++ under NT.
//

// Protect against multiple inclusion
//
#ifndef __TIMERTHREAD_H_INCLUDED__
#define __TIMERTHREAD_H_INCLUDED__

///////////////////////////////////////////////////////////////
//
// Include Files
// =============
//
///////////////////////////////////////////////////////////////

#include<windows.h>
#include<process.h>
#include"..\include\Win32Exceptions.h"


///////////////////////////////////////////////////////////////
//
class CWaitableTimerSubst
//
// The CWaitableTimerSubst class provides a the functionality
// of non-periodic Win32 waitable timers without completion routine
// until such time as these become available in Visual C++ under NT.
//
// The constructor starts a thread that waits on a start 
// event. The Set member function sets this start event. That 
// causes the thread to become active, i.e., to wait for the 
// time interval specified by the Set member function. After 
// this time interval has elapsed, the thread sets an alarm 
// event. The alarm event can be obtained by means of the 
// GetHandle member function. Whether the alarm event is 
// an auto reset or manual reset event is specified in the 
// constructor call. Each time the Set function is called, 
// the alarm event is reset to the non-signalled state.
//
// Example:
//
// CWaitableTimerSubst someTimer ;
// someTimer.Set(3000) ;
//
// Three seconds later, the event that is returned by
// someTimer.GetHandle() will be set. 
//
// When the Set member function is called again while the timer
// is active and waiting for the time period to elapse, the 
// alarm event is not set and the time interval starts over 
// again.
// 
// When the Cancel member function is called while the timer
// is active and waiting for the time period to elapse, 
// the timer enters the inactive state without setting the 
// alarm event.
//
// Note: When you try to call the Set or Cancel member 
// functions while the timer is active, it can never
// be guaranteed that the time interval does not complete
// and the alarm event does not get set before Set or Cancel 
// get a chance to interrupt the timer. The Set member function
// always resets the alarm event to the non-signalled state.
// The Cancel member function, by contrast, does not affect
// the state of the alarm event at all.
//
// The constructor does not perform any error checking. The
// Set and Cancel member functions throw a CWin32Exception 
// with error code ERROR_INVALID_HANDLE if they find that 
// the constructor failed to create an event or thread.
// 
// If the destructor encounters an error, it throws a 
// CWin32Exception but does not propagate it.
//
{

  /////////////////////////////////////////////////////////////
  //
  // Implementation of CThreadTimer
  //
  /////////////////////////////////////////////////////////////
  
  // Time interval for timer, set by Set member function
  DWORD m_dwMilliSeconds ;
  
  // Flag that tells the timer thread to exit. Set by dtor.
  LONG m_loExitFlag ;
  
  // Handle for thread that performs the wait operation
  HANDLE m_hTimerThread ;
  
  // Handle for alarm event. Set by timer thread when time has
  // expired.
  HANDLE m_hAlarmEvent ;

  // Handle for timer ready event. Set by the thread function
  // to indicate that the timer thread is ready to start a new 
  // wait.
  //
  HANDLE m_hReadyEvent ;

  // Handle for start event. Set by the Set member function to
  // indicate that the timer thread should start waiting for
  // the specified interval and then set the alarm event, 
  // unless interrupted by the Cancel member function.
  //
  HANDLE m_hStartEvent ;

  // Handle for cancle event. Set by the Cancel member function
  // to indicate that the timer thread should abandon the wait 
  // and wait for a new start.
  //
  HANDLE m_hCancelEvent ;

  // Critical section to make the Set and Cancel member 
  // functions thread safe.
  // 
  CRITICAL_SECTION cs ;
  
  // Timer thread function. The function is static because its
  // address will be passed to the _beginthreadex function.
  //
  static UINT __stdcall TimerThread(
    CWaitableTimerSubst*
    ) ;

  ////////////////////////////////////////////////////////////
  //
  // Interface of CWaitableTimerSubst
  //
  /////////////////////////////////////////////////////////////
  
public:

  // Constructs a CWaitableTimerSubst object.
  //
  CWaitableTimerSubst(
    BOOL bAlarmEventManual = FALSE
    ) ;

  // Destructor
  //
  ~CWaitableTimerSubst() ;
  
  // Sets the timer.
  // 
  void Set(DWORD dwMilliSecondsArg) ;

  // Cancels the timer.
  void Cancel() ;

  // Returns a handle to the alarm event. This is the event 
  // that a thread which uses the timer should wait on.
  // The handle is closed by the destructor.
  //
  HANDLE GetHandle() { return m_hAlarmEvent ; }

} ;

#endif
//
// End protection against multiple inclusion
