//
// File: CWaitableTimer.h	
//
// Created: February 1996
//
// Author: Dr. Thomas Becker
//
// A C++ class that wraps the Win32 waitable timer object. 
// Timers are restricted to non-periodic having no completion
// routine. The reason for providing this wrapper is to make
// it easier to switch to a substitute when working with
// NT version 3.51 or less. Waitable timers did not become
// available until version 4.0.
//

// Protect against multiple inclusion
//
#ifndef __WAITABLE_TIMER_H_INCLUDED__
#define __WAITABLE_TIMER_H_INCLUDED__

///////////////////////////////////////////////////////////////
//
// Include Files
// =============
//
///////////////////////////////////////////////////////////////

#include<windows.h>
#include<process.h>
#include"..\include\Win32Exceptions.h"

///////////////////////////////////////////////////////////////
//
class CWaitableTimer
//
// The CWaitableTimer class wraps the Win32 waitable timer 
// object. Here, timers are restricted to non-periodic having 
// no completion routine. The reason for providing this wrapper
// is to make it easier to switch to a substitute when working
// with NT version 3.51 or less. Waitable timers did not 
// become available until version 4.0.
//
// The constructor creates a waitable timer. The Set member
// function activates the timer, causing it to become signaled
// after the specified amount of time.
//
// Example:
//
// CWaitableTimer someTimer ;
// someTimer.Set(3000) ;
//
// Three seconds later, the handle that is returned by
// someTimer.GetHandle() will become signaled. 
//
// When the Set member function is called again while the timer
// is active and waiting for the time period to elapse, the 
// handle is not signaled and the time interval starts over 
// again.
// 
// When the Cancel member function is called while the timer
// is active and waiting for the time period to elapse, 
// the timer enters the inactive state without signaling the 
// handle.
//
// Note: When you try to call the Set or Cancel member 
// functions while the timer is active, it can never
// be guaranteed that the time interval does not complete
// and the handle does not get signaled before Set or Cancel 
// get a chance to interrupt the timer. The Set member function
// always resets the handle to the non-signalled state.
// The Cancel member function, by contrast, does not affect
// the state of the timer at all.
//
// The constructor does not perform any error checking. The
// Set and Cancel member functions throw a CWin32Exception 
// with error code ERROR_INVALID_HANDLE if they find that 
// the constructor failed to create the timer.
// 
// If the destructor encounters an error, it throws a 
// CWin32Exception but does not propagate it.
//
{

  /////////////////////////////////////////////////////////////
  //
  // Implementation of CThreadTimer
  //
  /////////////////////////////////////////////////////////////
  
  // Time interval for timer, set by Set member function
  DWORD m_dwMilliSeconds ;
  
  // Handle for waitable timer
  HANDLE m_hWaitableTimer ;
  

  ////////////////////////////////////////////////////////////
  //
  // Interface of CWaitableTimer
  //
  /////////////////////////////////////////////////////////////
  
public:

  // Constructs a CWaitableTimer object.
  //
  CWaitableTimer(
    BOOL bManualReset = FALSE
    ) ;

  // Destructor
  //
  ~CWaitableTimer() ;
  
  // Sets the timer.
  // 
  void Set(DWORD dwMilliSecondsArg) ;

  // Cancels the timer.
  void Cancel() ;

  // Returns a handle to the timer object.
  //
  HANDLE GetHandle() { return m_hWaitableTimer ; }

} ;

#endif
//
// End protection against multiple inclusion
