//
// File: Client.c	
//
// Created: January 11 1997
//
// Author: Dr. Thomas Becker
//
// Testclient for multithreaded server project


///////////////////////////////////////////////////////////////////////
//
// Include Files
// =============
//
///////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>
#include <conio.h>

///////////////////////////////////////////////////////////////////////
//
// Local Macros
// ============
//
///////////////////////////////////////////////////////////////////////

// #define RAPID_FIRE
#define PIPE_NAME "\\\\.\\pipe\\MTServer" 
#define WIDTH 25


///////////////////////////////////////////////////////////////////////
//
// Declarations of Local (Static) Functions
// ========================================
//
///////////////////////////////////////////////////////////////////////

void Session(
  HANDLE hOlEvent, 
  DWORD dwProgress
  ) ;


///////////////////////////////////////////////////////////////////////
//
// Function Definitions
// ====================
//
///////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////
//
void main(
//     
// The main function starts sessions with the server in an
// infinite loop. If RAPIPD_FIRE is defined, the sessions
// follow each other in rapid succession; otherwise, the
// user is prompted after each session.
//
)
//
{

  // Event handle for pipe operations
  HANDLE hOlEvent ;
  
  // Auxiliaries
  //
  int count ;
  char c ;

  // Create overlapped event. Do this here so it's done only once.
  //
  hOlEvent = CreateEvent(
    NULL,	// pointer to security attributes  
    TRUE,	// flag for manual-reset event 
    FALSE,	// flag for initial state 
    NULL 	// pointer to event-object name  
    );
  //
  if ( NULL == hOlEvent )
  {
    fprintf(stderr, "Could not create overlapped event" ) ;
    ExitProcess(1) ;
  }
  
  
  // Inifinite loop runs sessions. If RAPID_FIRE is defined,
  // just fire sessions; otherwise, prompt users.
  //
  c = 'y' ;
  count = 0 ;
  while (c == 'y' || c == 'Y' )
  {
    Session(hOlEvent, count+1) ;
    count = ++count % WIDTH ;
#ifndef RAPID_FIRE
    printf("\nWould you like another session? (y/n) ") ;
    fflush(stdout) ;
    c=getche() ;
#endif
  }

}


////////////////////////////////////////////////////////////////////
//
void Session(
//
// The Session function conducts a session with the server.
// 
HANDLE hOlEvent,
//
// Indicates the overlapped event for the pipe operations.
// This is passed to the function so it does not have to
// be recreated for each sessions.
//
DWORD dwProgress
//
// The function prints this many stars to indicate progress.
//
)
//
// Remarks
//
// The functions first opens the named pipe pchPipeName.
// It then writes a character to the pipe. If RAPID_FIRE is defined,
// this character is '\0'; otherwise, the user is prompted for the
// character. The function then reads a pair of ints and prints 
// them, interpreting the first one as a pipe number and the
// second one as a thread number.
//
{

  // Pipe handle
  HANDLE hPipe ;
  
  // Overlapped structure for pipe operations
  OVERLAPPED ol ;

  // Pair of pipe number and thread number as received
  // from server
  struct
  {
    DWORD dwPipeNo ;
    DWORD dwThreadNo ;
  } sPair ;
  
  // Auxiliaries
  //
  DWORD dwRetVal ;
  DWORD dwLastError ;
  DWORD dwNumberOfBytes ;
  char c ;
#ifdef RAPID_FIRE
  char outbuf[WIDTH+1] ;
#endif

  
  // Wait for pipe connection
  //
  while  (1)
  {
    
    printf("\nTrying to open named pipe...") ;
    fflush(stdout) ;
    hPipe = CreateFile( 
      PIPE_NAME,      /* pipe name           */ 
      GENERIC_READ |  /* read/write access   */ 
      GENERIC_WRITE, 
      0,              /* no sharing          */ 
      NULL,           /* no security attr.   */ 
      OPEN_EXISTING,  /* opens existing pipe */ 
      0,              /* default attributes  */ 
      NULL);          /* no template file    */ 
    
    // Leave loop if pipe connected
    if (hPipe != INVALID_HANDLE_VALUE) break; 
    
    // Error ERROR_FILE_NOT_FOUND means pipe does not
    // exist.
    dwLastError = GetLastError() ;
    if ( ERROR_FILE_NOT_FOUND == dwLastError ) 
    {
      printf("server not ready.\n") ;
      return ;
    }
    
    
    // CreateFile may have failed because the pipe is 
    // busy. In that case, we wait for pipe to become
    // available by calling WaitNamedPipe. Note: Even
    // when WaitNamedPipe has returned, CreateFile may
    // fail again, because another client snatched the
    // pipe in between.
    //
    dwLastError = GetLastError() ;
    if ( ERROR_PIPE_BUSY != dwLastError ) 
    {
      printf("aborted with error %d\n", dwLastError) ;
      return ;
    }
    
    printf("\nAll instances busy. Waiting...") ;
    fflush(stdout) ;
    
    // Wait for pipe to become available
    //
    if ( ! WaitNamedPipe(PIPE_NAME, NMPWAIT_WAIT_FOREVER) ) 
    {
      printf("\nWait error.\n") ;
      return ;
    }
    
  }

  // If RAPID_FIRE is not defined, prompt the user for a server command.
  // Otherwise, just send '\0'.
  //
  c='\0' ;
#ifndef RAPID_FIRE
  printf("\nPlease enter a server command.\n\
  s: server sleeps five seconds before sending reply\n\
  t: terminate session\n\
  x: cause an exception in the server thread\n\
  q: terminate server\n\
  Any other key: send reply\n\
Command: ") ;
  fflush(stdout) ;
  c=getche() ;
#endif

  // Write character to pipe. We must use an overlapped
  // event because the pipe was created in overlapped mode.
  //
  memset(&ol, 0x00, sizeof(OVERLAPPED) ) ;
  ol.hEvent = hOlEvent ;
  ResetEvent(ol.hEvent) ;
  //
  dwRetVal = WriteFile(
    hPipe,	// handle to file to write to 
    &c,	// pointer to data to write to file 
    1,	// number of bytes to write 
    &dwNumberOfBytes,	// pointer to number of bytes written 
    & ol 	// pointer to structure needed for overlapped I/O
    ) ;	
 
  // If WriteFile failed because of ERROR_IO_PENDING: wait for
  // completion. After GetOverlappedResult has returned,
  // GetLastError will contain the error status for the
  // WriteFile operation.
  //
  if ( ! dwRetVal && ERROR_IO_PENDING == GetLastError() )
  {
    dwRetVal = GetOverlappedResult(
      hPipe,	// handle of file, pipe, or communications device  
      &ol,	// address of overlapped structure 
      &dwNumberOfBytes,	// address of actual bytes count 
      TRUE 	// wait flag 
      ) ;
  }
  
  // Now dwRetVal and GetLastError are as if the write
  // operation had been synchronous. Deal with errors.
  //
  if ( ! dwRetVal )
  {
    
    // If WriteFile failed with ERROR_PIPE_NOT_CONNECTED, 
    // then the server has disconnected the pipe.
    //
    if ( ERROR_PIPE_NOT_CONNECTED == GetLastError() )
    {
      fprintf(
        stderr,
        "\nWrite encountered a broken pipe.") ;
      CloseHandle(hPipe) ;
      return ;
    }
    //
    // Other WriteFile errors
    //
    else
    {
      fprintf(
        stderr,
        "\nWrite failed. Error %d",
        GetLastError()) ;
      CloseHandle(hPipe) ;
      return ;
    }
    
  }
  //
  // End if WriteFile failed
    
  // Read a pair of DWORDS from pipe. We must use an overlapped
  // event because the pipe was created in overlapped mode.
  //
  memset(&ol, 0x00, sizeof(OVERLAPPED) );
  ol.hEvent = hOlEvent ;
  ResetEvent(ol.hEvent) ;
  //
  dwRetVal = ReadFile(
    hPipe,	// handle of file to read 
    &sPair,	// address of buffer that receives data  
    sizeof(sPair),	// number of bytes to read 
    &dwNumberOfBytes,	// address of number of bytes read 
    &ol 	// address of structure for data 
    ) ;

  // If ReadFile failed because of ERROR_IO_PENDING: wait 
  // for completion. After GetOverlappedResult has returned,
  // GetLastError will contain the error status for the
  // ReadFile operation.
  //
  if ( ! dwRetVal && ERROR_IO_PENDING == GetLastError() )
  {
    dwRetVal = GetOverlappedResult(
      hPipe,	// handle of file, pipe, or communications device  
      &ol,	// address of overlapped structure 
      &dwNumberOfBytes,	// address of actual bytes count 
      TRUE 	// wait flag 
      ) ;
  }
  
  // Now dwRetVal and GetLastError are as if the read
  // operation had been synchronous. Deal with errors.
  //
  if ( ! dwRetVal )
  {
    
    // If ReadFile failed with ERROR_PIPE_NOT_CONNECTED
    // then the server has disconnected the pipe.
    //
    if ( ERROR_PIPE_NOT_CONNECTED == GetLastError() )
    {
      fprintf(
        stderr,
        "\nRead encountered a broken pipe.") ;
      CloseHandle(hPipe) ;
      return ;
    }
    //
    // Other ReadFile errors
    //
    else
    {
      fprintf(
        stderr,
      "\nError reading from pipe, Error %d",
        GetLastError()) ;
      CloseHandle(hPipe) ;
      return ;
    }
  }
  //
  // End if ReadFile failed

  // Print result of read operation
  //
  printf(
    "\nServed by pipe %d and thread %d",
    sPair.dwPipeNo,
    sPair.dwThreadNo
    ) ;
  fflush(stdout) ;
  
#ifdef RAPID_FIRE
  // Output a moving bar to make progress visible
  //
  memset(outbuf, '*', dwProgress) ;
  memset(outbuf+dwProgress, ' ', WIDTH-dwProgress) ;
  outbuf[WIDTH] = '\0' ;
  printf("%s\n", outbuf) ;
  fflush(stdout) ;
#endif

  CloseHandle(hPipe) ;

}


