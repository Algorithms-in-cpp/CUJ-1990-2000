//
// File: MTServerV1.cpp
//
// Created: January 1997
//
// Author: Dr. Thomas Becker
//
// Example of a multithreaded server with queue. See 
// MTServer.htm for a detailed description.
//
// Version 1: Uses the CPassiveQueue class as its queue. This 
//            means that once a client has entered the queue, 
//            there is no timeout anymore. The only way a 
//            client can be removed from the queue is by means 
//            of the Retrieve member function.
//
// Remarks:
//
// When building the project, make sure to specify the /MT 
// (Release) or /MTd (Debug) option to link with the 
// multithreaded version of the runtime library. In Developer 
// Studio, this option can be set under 
// "C/C++ - Code Generation - Use runtime library".
//

////////////////////////////////////////////////////////////////
//
// Include Files
// =============
//
////////////////////////////////////////////////////////////////

#include<windows.h>
#include<eh.h>
#include<process.h>
#include<stdio.h>
#include<TCHAR.h>
#include"..\include\PassiveQueue.h"
#include"..\include\NamedPipeArray.h"
#include"..\include\Win32Exceptions.h"


////////////////////////////////////////////////////////////////
//
// Local Macros
// ============
//
////////////////////////////////////////////////////////////////

// Parameters for queue and pipe array. LEN_QUEUE and 
// NUM_PIPE_INSTANCES *must* be known at compile time,
// because they are template parameters.
//
#define NUM_THREADS 3
#define LEN_QUEUE 2
#define NUM_PIPE_INSTANCES NUM_THREADS + LEN_QUEUE + 1
#define PIPE_NAME _TEXT("\\\\.\\pipe\\MTServer")
#define GRACE_PERIOD 3000 

////////////////////////////////////////////////////////////////
//
// Definitions of Local (Static) Variables
// =======================================
//
////////////////////////////////////////////////////////////////

// The pipe array
CNamedPipeArray<NUM_PIPE_INSTANCES> cThePipeArray(PIPE_NAME) ;

// The queue
CPassiveQueue<DWORD, LEN_QUEUE> cThePassiveQueue ;

// Handle of listen thread
HANDLE hListenThread = NULL ;

// Array of event handles for exit event, listen thread, and
// worker thread handles. These are the handles that the main
// thread waits on during the entire duration of the program.
//
static HANDLE ahExitEventAndThreads[NUM_THREADS + 2] ;

// Handle for exit event
static HANDLE hExitEvent = NULL ;


////////////////////////////////////////////////////////////////
//
// Declarations of Local (Static) Functions
// ========================================
//
////////////////////////////////////////////////////////////////

// Reaction to CTRL+C etc.
//
static BOOL __stdcall ConsoleCtrlHandler(
    DWORD dwCtrlType 	//  control signal type
   );

// Translates Microsoft structured exceptions into
// C++-exceptions
//
static void _se_translator_func ( 
  unsigned int, 
  struct _EXCEPTION_POINTERS* 
  );

// Initialization of multithreaded server
//
static void InitMTServer(
  ) ;

// Thread function for listen thread
//
static UINT __stdcall ListenThread(
  LPVOID
  ) ;
// Thread function for worker threads
//
static UINT __stdcall WorkerThread(
  LPVOID
  ) ;

// Simple client session 
//
static void ServeClient(
  DWORD,  
  DWORD 
  ) ;

// Log an error message.
//
void MsgOut(
  WORD,
  CWin32Exception&
  ) ;
//
void MsgOut(
  WORD,
  CSehException&
  ) ;
//
void MsgOut(
  WORD ,
  LPTSTR
  ) ;

// Cleanup on exit
//
void GlobalCleanup(
  ) ;


///////////////////////////////////////////////////////////////
//
// Function Definitions
// ====================
//
///////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
//
void main(
//
// The main function initializes the server by calling the
// InitMTServer function, then watches the listen thread and
// the worker threads until the exit event is set.
//
)
//
{
  
  // Auxiliaries
  //
  DWORD dwRetVal ;
  DWORD dwRetIndex ;
  
  // Treat console events such as CTRL+C, logoff, shutdown
  SetConsoleCtrlHandler(ConsoleCtrlHandler, TRUE) ;

  // Translate C structured exceptions into C++ exceptions
  _set_se_translator(_se_translator_func) ;
 
  try
  {

    // Initialize pipes, threads, sync objects, start threads
    //
    try
    {
      InitMTServer() ;
    }
    catch(CWin32Exception&)
    {
      MsgOut(
        EVENTLOG_ERROR_TYPE,
        _TEXT("MTServer failed to initialize")
        ) ;
      
      throw ;
    }
    
    // Server running.
    //
    MsgOut(
      EVENTLOG_INFORMATION_TYPE,
      _TEXT("MTServer has initialized successfully")
      ) ;
    
    // Wait for one of the worker threads or the 
    // listen thread to terminate, or for the exit event to be
    // set. NOTE: The exit event also causes the threads to 
    // exit. This means that when WaitForMultipleObjects 
    // returns, the exit event *and* a thread handle could be 
    // siganalled. In this case, the return value of 
    // WaitForMultipleObjects names the exit event because it 
    // is first in the array.
    //
    dwRetVal = WaitForMultipleObjects(
      NUM_THREADS+2, // number of handles
      ahExitEventAndThreads, // pointer to array 
      FALSE,	// wait flag 
      INFINITE 	// time-out interval in milliseconds 
      );
    //
    if ( WAIT_FAILED == dwRetVal )
    {
      throw CWin32Exception(
        GetLastError(),
        ___FILE___,
        __LINE__
        ) ;
    }
    
    // Index of event that caused the multiple wait to return
    dwRetIndex = dwRetVal - WAIT_OBJECT_0 ;
    
    // If the exit event was not set, then a thread has
    // terminated abnormally. Log a message and set the exit
    // event, hoping for some sort of graceful exit.
    
    if (0 != dwRetIndex )
    {
      MsgOut(
        EVENTLOG_ERROR_TYPE,
        _TEXT("A thread has exited abnormally.\nWill attempt\
 graceful server termination")
        ) ;
      
      SetEvent(hExitEvent) ;
    }
    
    // Now the exit event has been set. That means all threads 
    // have been notified and should exit shortly. All we have 
    // to do is give the threads a grace period before we 
    // return. Note: the first handle in the array 
    // ahExitEventAndThreads is the exit event, the second is 
    // the listen thread, the rest are the thread handles.
    //
    //
    dwRetVal = WaitForMultipleObjects(
      NUM_THREADS+1,	// number of handles 
      &ahExitEventAndThreads[1],	// pointer to the array 
      TRUE,	// wait flag 
      GRACE_PERIOD 	// time-out interval in milliseconds 
      );
    //
    if ( WAIT_FAILED == dwRetVal )
    {
      throw CWin32Exception(
        GetLastError(),
        ___FILE___,
        __LINE__
        ) ;
    }
    
    if ( WAIT_TIMEOUT == dwRetVal )
    {
      MsgOut(
        EVENTLOG_WARNING_TYPE,
        _TEXT("Not all threads exited gracefully")
        ) ;
    }

    GlobalCleanup() ;
    MsgOut(
      EVENTLOG_INFORMATION_TYPE,
      _TEXT("MTServer has been terminated")
      ) ;
   
  }
  catch(CWin32Exception& eWin32)
  {
    MsgOut(
      EVENTLOG_ERROR_TYPE,
      _TEXT("MTServer has terminated abnormally")
      ) ;

    MsgOut(
      EVENTLOG_ERROR_TYPE,
      eWin32
      ) ;

    GlobalCleanup() ;
  }
  catch(CSehException& eSeh)
  {
    MsgOut(
      EVENTLOG_ERROR_TYPE,
      _TEXT("MTServer has terminated abnormally")
      ) ;
    
    MsgOut(
      EVENTLOG_ERROR_TYPE,
      eSeh
      ) ;

    GlobalCleanup() ;
  }

}


////////////////////////////////////////////////////////////////
//
void InitMTServer(
//
// The InitMTServerFunction creates the sync objects and 
// starts the listen thread and the worker threads.
//
)
//
// Return Value and Exceptions
//
// If the function fails, a CWin32Exception is thrown. 
//
// Remarks
//
// There is no cleanup in case of failure. Since some threads 
// may already be running, failure should be considered 
// unrecoverable.
//
{

  // Auxiliaries
  //
  UINT uiThreadId ;
  DWORD dwIndex ;

  // Create the exit event for the main loop in the listen 
  // thread.
  //
  hExitEvent = CreateEvent(
        NULL,	// pointer to security attributes  
        TRUE,	// flag for manual-reset event 
        FALSE,	// flag for initial state 
        NULL 	// pointer to event-object name  
        );
  //
  if ( NULL == hExitEvent ) 
  {
    throw CWin32Exception(
      GetLastError(),
      ___FILE___,
      __LINE__
      ) ;
  }

  // Communicate event handle to pipe array and queue so that
  // all wait operations can wait on the exit event.
  // (Has nothing to do with the SetEvent() API!)
  //
  cThePipeArray.SetHandleToExitEvent(hExitEvent) ;
  cThePassiveQueue.SetHandleToExitEvent(hExitEvent) ;

  // Create NUM_THREADS many threads with the function 
  // WorkerThread and place their handles in the array 
  // ahExitEventAndThreads. The main control loop will use 
  // this array to monitor the threads.
  //
  memset(
    ahExitEventAndThreads, 
    0x00, 
    (NUM_THREADS + 2) * sizeof(HANDLE)) ;
  //
  for (dwIndex=2; dwIndex<NUM_THREADS+2; ++dwIndex)
  {
    ahExitEventAndThreads[dwIndex] = 
      (HANDLE) _beginthreadex(
        NULL,	// pointer to thread security attributes  
        0,	// initial thread stack size, in bytes 
        WorkerThread,	// pointer to thread function 
        (char *) dwIndex-2,	// argument for new thread 
        0,	// creation flags 
        &uiThreadId 	// pointer to returned thread identifier 
        );	
    //
    if ( NULL == ahExitEventAndThreads[dwIndex] )
    {
      throw CWin32Exception(
        GetLastError(),
        ___FILE___,
        __LINE__
        ) ;
    }

  }

  // Place event handle in array ahExitEventAndThreads
  ahExitEventAndThreads[0] = hExitEvent ;
  
  // Start listen thread
  //
  hListenThread = (HANDLE) _beginthreadex(
    NULL,	// pointer to thread security attributes  
    0,	// initial thread stack size, in bytes 
    ListenThread,	// pointer to thread function 
    0,	// argument for new thread 
    0,	// creation flags 
    &uiThreadId 	// pointer to returned thread identifier 
    );	

  //
  if ( NULL == hListenThread )
  {
    throw CWin32Exception(
      GetLastError(),
      ___FILE___,
      __LINE__
      ) ;
  }
  
  // Place handle of listen thread in the array 
  // ahExitEventAndThreads
  //
  ahExitEventAndThreads[1] = hListenThread ;
  
}


///////////////////////////////////////////////////////////////
//
UINT __stdcall ListenThread(
//
// The ListenThread function waits in a loop for a client to
// connect to one of the named pipes. When a client has 
// connected, the index of the connected pipe is inserted into 
// the queue.
//
LPVOID lpvArg
//
// Not used
//
)
//
// Return Value and Exceptions
//
// A return value of 0 indicates normal termination.
// If the thread encounters an error, it logs an error
// and returns 1.
//
{

  // Index of connected pipe
  DWORD dwPipeIndex ;

  // Return values from listening and inserting
  //
  CNamedPipeArray<NUM_PIPE_INSTANCES>::waitResult 
    enListenRetVal ;
  //
  CPassiveQueue<DWORD, LEN_QUEUE>::waitResult 
    enInsertRetVal ;
  
  // Translate C structured exceptions into C++ exceptions
  _set_se_translator(_se_translator_func) ;
  
  try
  {

    // Main loop waits for client to connect to a thread. When
    // a client has connected, the pipe handle and the 
    // corresponding overlapped event handle are inserted in 
    // the queue. We must also wait for the exit event.
    //
    while ( 1 )
    {
      
      // Wait for client to connect, receive pipe index
      //
      enListenRetVal = cThePipeArray.Listen(
        dwPipeIndex,
        INFINITE
        ) ;
      
      // Break if exit event was set
      //
      if ( CNamedPipeArray<NUM_PIPE_INSTANCES>::waitExitEvent 
             == enListenRetVal ) break ;
      
      // Insert index of connected pipe.
      //
      enInsertRetVal = cThePassiveQueue.Insert(
        dwPipeIndex,
        INFINITE
        ) ;
      
      // Break if exit event was set
      //
      if (CPassiveQueue<DWORD, LEN_QUEUE>::waitExitEvent 
            == enInsertRetVal) break ;
    }

  }
  catch(CWin32Exception& eWin32)
  {
    MsgOut(
      EVENTLOG_ERROR_TYPE,
      eWin32
      ) ;
    return 1 ;
  }
  catch(CSehException& eSeh)
  {
    MsgOut(
      EVENTLOG_ERROR_TYPE,
      eSeh
      ) ;
    return 1 ;
  }

  // Loop was left because exit event was set.
  return 0 ;

}


///////////////////////////////////////////////////////////////
//
UINT __stdcall WorkerThread(
//
// The WorkerThread function runs an inifinite loop during which
// it removes a pipe index from the queue, reads a client 
// command, sends a message to the client, and reconnects the 
// pipe asynchronously. Wait operations always check for the 
// exit event to be set.
//
LPVOID lpvArg
//
// Indicates the index of the thread
//
)
//
// Return Value and Exceptions
//
// A return value of 0 indicates a normal end of the thread.
// If the thread encounters an error, it logs an error and
// returns 1.
//
{

  // Index of pipe retrieved from queue
  DWORD dwPipeIndex ;

  // Return value from retrieval
  //
  CPassiveQueue<DWORD, LEN_QUEUE>::waitResult enRetrieveRetVal ;

  // Translate C structured exceptions into C++ exceptions
  _set_se_translator(_se_translator_func) ;
  
  try
  {

    // The main loop retrieves a client from the queue and 
    // services it.
    //
    while(1)
    {
      
      // Retrieve a pipe index from queue. 
      //
      enRetrieveRetVal = cThePassiveQueue.Retrieve(
        dwPipeIndex,
        INFINITE
        ) ;
      
      // Break if exit event was set
      //
      if (CPassiveQueue<DWORD, LEN_QUEUE>::waitExitEvent 
        == enRetrieveRetVal) break ;
      
      // Serve client. Functions throws CWin32Exception
      // or CSehException
      //
      ServeClient(
        dwPipeIndex,
        (DWORD) lpvArg
        ) ;

      // Disconnect named pipe and reconnect asynchronously
      //
      cThePipeArray.Reconnect(dwPipeIndex) ;
      
    }
    //
    // End main loop servicing clients
    
    return 0 ;
  
  }
  catch(CWin32Exception& eWin32)
  {
    // Win32Exception: Output error and terminate thread
    //
    MsgOut(
      EVENTLOG_ERROR_TYPE,
      eWin32
      ) ;
    return eWin32.GetErrorCode() ;
  }
  catch(CSehException& eSeh)
  {
    // C structured exception: Output error and terminate 
    // thread with exit code 1 (abnormal)
    //
    MsgOut(
      EVENTLOG_ERROR_TYPE,
      eSeh
      ) ;
    return 1 ;
  }

}


///////////////////////////////////////////////////////////////
//
void ServeClient(
//
// The ServeClient example function reads a byte from the pipe
// with the given index and takes some action accordingly.
//
DWORD dwPipeIndex, // pipe index
//
// Indicates the index of the pipe to read from
//
DWORD dwThreadNo // thread index
//
// Indicates the 0-based index of the servicing worker thread
//
) 
//
{

  // Information to be sent to client
  struct 
  {
    DWORD dwPipeIndex ;
    DWORD dwThreadNo ;
  } sReplyPackage ;
  
  // Return values from I/O operations
  //
  CNamedPipeArray<NUM_PIPE_INSTANCES>::waitResult enIoRetVal ;

  // Auxiliaries
  //
  char c ;
  DWORD dwNumBytes ;
  char* pchExceptionRaiser = NULL ;

  // Fill reply package
  //
  sReplyPackage.dwPipeIndex = dwPipeIndex + 1 ;
  sReplyPackage.dwThreadNo = dwThreadNo + 1 ;

  // Read a character from the pipe. If an exception
  // occurs with error code ERROR_BROKEN_PIPE, that means
  // that the client has disconnected. We may simply
  // reconnect to a new client.
  //
  try
  {
    enIoRetVal = cThePipeArray.Read(
      dwPipeIndex,
      &c,
      sizeof(_TCHAR),
      &dwNumBytes,
      INFINITE
      ) ;
  }
  catch(CWin32Exception& eWin32)
  {
    if ( ERROR_BROKEN_PIPE == eWin32.GetErrorCode() )
    {
      MsgOut(
        EVENTLOG_INFORMATION_TYPE,
        _TEXT("A client has disconnected during a session")
        ) ;
      return ;
    }
    else
    {
      throw ;
    }
  }
  
  // Return if exit event was set
  //
  if (CNamedPipeArray<NUM_PIPE_INSTANCES>::waitExitEvent 
    == enIoRetVal) return ;
  
  // Command q means quit.
  //
  if ( 'q' == c ) 
  {
    SetEvent(hExitEvent) ;
    return ;
  }
  
  // Command s means sleep five seconds.
  //
  if ( 's' == c ) Sleep(5000) ; 
  
  // Command t means terminate client session. We break
  // out of the client loop and reconnect.
  //
  if ( 't' == c ) return ; 
  
  // Command x means raise an exception.
  //
  if ( 'x' == c )
  {
    c = *pchExceptionRaiser ;
  }
  
  // Write answer to pipe. If an exception occurs and
  // the error code is ERROR_NO_DATA, then that means
  // the client has closed her end of the pipe. We
  // may just reconnect to a new client.
  //
  try
  {
    enIoRetVal = cThePipeArray.Write(
      dwPipeIndex,
      &sReplyPackage,
      sizeof(sReplyPackage),
      &dwNumBytes,
      INFINITE
      ) ;
  }
  catch(CWin32Exception& eWin32)
  {
    if ( ERROR_NO_DATA == eWin32.GetErrorCode() )
    {
      MsgOut(
        EVENTLOG_INFORMATION_TYPE,
        _TEXT("A client has disconnected during a session")
        ) ;
      return ;
    }
    else
    {
      throw ;
    }
  }
  
  // Return if exit event was set
  //
  if (CNamedPipeArray<NUM_PIPE_INSTANCES>::waitExitEvent 
    == enIoRetVal) return ;
  
  // Flush file buffers to prevent loss of data that the 
  // client has not yet read. Note: there is no timeout 
  // or simultaneous wait for an exit event. A client 
  // that refuses to read can hang the server here.
  //
  // If an exception occurs with error code ERROR_BROKEN_PIPE,
  // that means that the client has disconnected. We may 
  // simply reconnect to a new client.
  //
  try
  {
    cThePipeArray.Flush(dwPipeIndex) ;
  }
  catch(CWin32Exception& eWin32)
  {
    if ( ERROR_BROKEN_PIPE == eWin32.GetErrorCode() )
    {
      MsgOut(
        EVENTLOG_INFORMATION_TYPE,
        _TEXT("A client has disconnected during a session")
      ) ;
      return ;
    }
    else
    {
      throw ;
    }
  }
  
  // Leave conversation with client
  return ;
  
}

  
////////////////////////////////////////////////////////////////////
//
void MsgOut(
// 
// The MsgOut functions print information from exceptions to
// stdout
//
WORD wType, // message type
//
// Indicates the type of the message. This can be one of
// EVENTLOG_ERROR_TYPE, EVENTLOG_WARNING_TYPE, and
// EVENTLOG_INFORMATION_TYPE
//
CWin32Exception& eWin32 // exception
//
// Indicates the exception to be logged.
//
)
//
{

  LPVOID lpErrorMessage ;

  // Retrieve system messsage for last error
  //
  FormatMessage( 
    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
    NULL,
    eWin32.GetErrorCode(),
    MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT),
    (LPTSTR) &lpErrorMessage,
    0,
    NULL 
  );
  
  // Print message
  _tprintf(
    _TEXT("\nError %d\n%sFile: %s\nLine: %d\n"), 
    eWin32.GetErrorCode(), 
    lpErrorMessage,
    eWin32.GetFileName(), 
    eWin32.GetLineNo()
    ) ;
  
  fflush(stdout) ;   

  // Free the buffer.
  LocalFree(lpErrorMessage);

}


////////////////////////////////////////////////////////////////////
//
void MsgOut(
// 
// The MsgOut functions print information from exceptions to
// stdout
//
WORD wType, // message type
//
// Indicates the type of the message. With a CSehException,
// this should definitely be EVENTLOG_ERROR_TYPE
//
CSehException& eSeh // exception
//
// Indicates the exception to be logged.
//
)
//
{

  LPTSTR pchMsg ;
  
  switch ( eSeh.GetExceptionCode() )
  {
  case EXCEPTION_ACCESS_VIOLATION	:
    pchMsg = _TEXT("Exception: Access violation") ;
    break ;
  case EXCEPTION_DATATYPE_MISALIGNMENT :
    pchMsg = _TEXT("Exception: Datatype misalignment") ;
    break ;
  case EXCEPTION_ARRAY_BOUNDS_EXCEEDED :
    pchMsg = _TEXT("Exception: Array bounds exceeded") ;
    break ;
  case EXCEPTION_FLT_DENORMAL_OPERAND :
    pchMsg = _TEXT("Exception: Floating point value too small") ;
    break ;
  case EXCEPTION_FLT_DIVIDE_BY_ZERO :
    pchMsg = _TEXT("Exception: Division by zero") ;
    break ;
  case EXCEPTION_FLT_INEXACT_RESULT :
    pchMsg = _TEXT("Exception: Bad floating point result") ;
    break ;
  case EXCEPTION_FLT_INVALID_OPERATION :	
    pchMsg = _TEXT("Exception: Floating point exception") ;
    break ;
  case EXCEPTION_FLT_OVERFLOW :
    pchMsg = _TEXT("Exception: Floating point stack overflow") ;
    break ;
  case EXCEPTION_FLT_STACK_CHECK :	
    pchMsg = _TEXT("Exception: Floating point stack exception") ;
    break ;
  case EXCEPTION_FLT_UNDERFLOW :
    pchMsg = _TEXT("Exception: Floating point stack underflow") ;
    break ;
  case EXCEPTION_INT_DIVIDE_BY_ZERO :
    pchMsg = _TEXT("Exception: Integer division by zero") ;
    break ;
  case EXCEPTION_INT_OVERFLOW :
    pchMsg = _TEXT("Exception: Integer overflow") ;
    break ;
  case EXCEPTION_PRIV_INSTRUCTION :	
    pchMsg = _TEXT("Exception: Illegal instruction") ;
    break ;
  case EXCEPTION_NONCONTINUABLE_EXCEPTION :
    pchMsg = _TEXT("Exception: Non-continuable exception") ;
    break ;
  default:
    pchMsg = _TEXT("Unknown exception") ;
  
  }    
    
  _tprintf(_TEXT("\n%s\n"), pchMsg) ;

}


////////////////////////////////////////////////////////////////////
//
void MsgOut(
// 
// The MsgOut functions print information from exceptions to
// stdout
//
WORD wType, // message type
//
// Indicates the type of the message. This can be one of
// EVENTLOG_ERROR_TYPE, EVENTLOG_WARNING_TYPE, and
// EVENTLOG_INFORMATION_TYPE
//
LPTSTR pchMsg // message
//
// Points to the message to be printed
//
)
//
{

  // Print message
  _tprintf(_TEXT("\n%s.\n"), pchMsg) ;
  fflush(stdout) ;   
}


////////////////////////////////////////////////////////////////////
//
void GlobalCleanup(
// 
// The GlobalCleanup function closes all global handles and
// disconnects all pipes.
//
)
//
// Remarks
//
// Closing the handles is not all that important when one exits
// the process. However, it is very important to disconnect all
// named pipes. If the server side of a named pipe exits without
// disconnecting and a client holds on to the pipe, that pipe
// instance remains busy.
//
{

  DWORD dwIndex ;

  // Close all *thread* handles in array ahExitEventAndThreads
  //
  for ( dwIndex = 1 ; 
        dwIndex < NUM_THREADS+2 ;
        ++dwIndex )
  {
    if ( NULL != ahExitEventAndThreads[dwIndex] )
      CloseHandle(ahExitEventAndThreads[dwIndex] ) ;
  }

  // Close handle of exit event
  if ( NULL != hExitEvent) CloseHandle(hExitEvent) ;

}
  
///////////////////////////////////////////////////////////////
//
BOOL __stdcall ConsoleCtrlHandler(
    DWORD dwCtrlType 	//  control signal type
)
//
// Remarks
//
// The main function sets this function as the handler
// for all console events such as CTRL+C, logoff, shutdown
// etc.
//
{
  SetEvent(hExitEvent) ;
  return TRUE ;
}

///////////////////////////////////////////////////////////////
//
void _se_translator_func ( 
//
// The _se_translator_func function translates a C structured 
// exception into a C++ exception.
//
unsigned int uiExceptionCode, // exception code
// 
// Indicates the exception code. This is the return value
// of GetExceptionCode.
//
struct _EXCEPTION_POINTERS* // exception pointers
//
// Points to an EXCEPTION_POINTERS struct. This is the return
// value of GetExceptionInformation.
//
)
//
// Remarks
//
// This function is set as the translator function for C 
// structured exceptions at the beginning of each thread
// function. 
// In this simple example, we pass only the exception code
// of the C structured exception to the C++ exception.
//
{
  throw CSehException(uiExceptionCode) ;
}
