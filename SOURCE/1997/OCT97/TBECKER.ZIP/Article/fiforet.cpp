char Retrieve()
{
  char chRetVal ;
  DWORD dwPrevCount ;
  static int iRetPos = 0 ;

  WaitForSingleObject(hOccSem, INFINITE) ;
  EnterCriticalSection(&cs) ;

  chRetVal = achTheQueue[iRetPos] ;
  iRetPos = (++iRetPos % LEN_QUEUE) ;

  LeaveCriticalSection(&cs) ;
  ReleaseSemaphore(hFreeSem, 1, &dwPrevCount) ;

  return chRetVal ;
}

