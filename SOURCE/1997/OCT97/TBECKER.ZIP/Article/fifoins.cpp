void Insert(char c)
{
  DWORD dwPrevCount ;

  static int iInsPos = 0 ;

  WaitForSingleObject(hFreeSem, INFINITE) ;
  EnterCriticalSection(&cs) ;

  achTheQueue[iInsPos] = c ;
  iInsPos = (++iInsPos % LEN_QUEUE) ;

  LeaveCriticalSection(&cs) ;
  ReleaseSemaphore(hOccSem, 1, &dwPrevCount) ;

}
