// Wait for clients to connect or exit event being set. When a
// client connects to a pipe, the corresponding overlapped event
// is siganled.
//
dwRetVal = WaitForMultipleObjects(
  dwNumPipeInstances+1, // number of handles  
  m_ahOlEventsAndExitEvent, // pointer to array 
  FALSE, // wait flag 
  dwMilliseconds // time-out interval in milliseconds 
  );
//
if ( WAIT_FAILED == dwRetVal ) THROW_WIN32_EXCEPTION ;

// Timeout occurred
if ( WAIT_TIMEOUT == dwRetVal ) return waitTimeout ;

// Index of event that caused the multiple wait to return
dwRetIndex = dwRetVal - WAIT_OBJECT_0 ;

// Exit event was signaled
if ( dwNumPipeInstances == dwRetIndex ) 
{
  return waitExitEvent ;
}

// Now we have successfully connected to a client. The
// event that caused the WFMO to return must be reset 
// immediately. The index is placed into the dwIndex 
// argument.
//
ResetEvent(m_ahOlEventsAndExitEvent[dwRetIndex]) ;
refdwIndex = dwRetIndex ;
return waitSuccess ;
