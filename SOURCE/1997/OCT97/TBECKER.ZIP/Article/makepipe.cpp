// Create all instances of the named pipe.
//
for (dwIndex=0; dwIndex < dwNumPipeInstances; dwIndex++)
{

  // Create named pipe. Note: in case of failure, the handle
  // is INVALID_HANDLE_VALUE, *not* NULL.
  //
  m_ahPipes[dwIndex] = CreateNamedPipe(
    m_achPipeName,  // pointer to pipe name 
    PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED ,  // mode 
    PIPE_TYPE_BYTE | PIPE_WAIT,  // pipe-specific modes 
    dwNumPipeInstances,  // maximum number of instances  
    4096,  // output buffer size, in bytes 
    4096,  // input buffer size, in bytes 
    0,  // default time-out time, in milliseconds 
    &secattrSA  // pointer to security attributes structure 
    );
  //
  if ( INVALID_HANDLE_VALUE == m_ahPipes[dwIndex] )
  {
    THROW_WIN32_EXCEPTION ;
  }

}
//
// End for-loop creating named pipes
 
// Now connect all named pipes asynchronously. This is
// done in a separate for-loop, because we don't want
// any clients to connect until we know all pipe instances
// have been created successfully.
//
for (dwIndex=0; dwIndex < dwNumPipeInstances; dwIndex++)
{

  // Create overlapped event for named pipe connection
  //
  m_ahOlEventsAndExitEvent[dwIndex] = CreateEvent(
    NULL,  // pointer to security attributes  
    TRUE,  // flag for manual-reset event 
    FALSE,  // flag for initial state 
    NULL   // pointer to event-object name  
    );
  //
  if ( NULL == m_ahOlEventsAndExitEvent[dwIndex] )
  {
    THROW_WIN32_EXCEPTION ;
  }
      
  // Connect the instance of the pipe asynchronously,
  // using the event as overlapped event. Note: the function
  // returns FALSE in two cases that aren't really errors.
  // ERROR_PIPE_CONNECTED means a client has already snatched
  // the pipe. ERROR_IO_PENDING means that the asynchronous 
  // call was successful, but no client has connected yet.
  //
  m_aOverlapped[dwIndex].hEvent 
    = m_ahOlEventsAndExitEvent[dwIndex] ;
  bRetVal = ConnectNamedPipe(
    m_ahPipes[dwIndex],  // handle to named pipe to connect  
    &m_aOverlapped[dwIndex]  // &overlapped structure 
    ) ;
  //
  if ( ! bRetVal 
       && 
       ERROR_IO_PENDING != GetLastError() 
       &&
       ERROR_PIPE_CONNECTED != GetLastError() )
  {
    THROW_WIN32_EXCEPTION ;
  }
}
//
// End for-loop connection named pipes
