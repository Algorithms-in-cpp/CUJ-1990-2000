// GUESTBOOKL.CPP - Implementation file for our ISAPI GuestBook
//    GuestBook
//   3/15/97  By Don Gaspar
//      For the C/C++ Users Journal
//
//  Copyright 1997 by Don Gaspar and Gigantor Software. All rights reserved.
//  Rights for publication and distribution granted to C/C++ Users Journal.
//

#include "stdafx.h"
// our custom header
#include "GuestBookl.h"

// more headers provided by others
#include <fstream.h>
#include <iostream.h>
#include <function.h>
#include <algo.h>
#include <vector.h>

///////////////////////////////////////////////////////////////////////
// The one and only CWinApp object
// NOTE: You may remove this object if you alter your project to no
// longer use MFC in a DLL.

CWinApp theApp;

///////////////////////////////////////////////////////////////////////
// command-parsing map

BEGIN_PARSE_MAP(CGuestBook, CHttpServer)
 ON_PARSE_COMMAND(SignGuestBook, CGuestBook, ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR ITS_PSTR)
 ON_PARSE_COMMAND_PARAMS("first_name last_name company address1 address2 city state zip phone_number email_address comments")

 ON_PARSE_COMMAND(Default, CGuestBook, ITS_PSTR)
 DEFAULT_PARSE_COMMAND(Default, CGuestBook)
END_PARSE_MAP(CGuestBook)

// some useful things we've provided
ostream& 
operator<< ( ostream &inOStream, const GuestInfoRef &inGuest )
{
 inOStream << inGuest.first_name << "|";
 inOStream << inGuest.last_name << "|";
 inOStream << inGuest.company << "|";
 inOStream << inGuest.address1 << "|";
 inOStream << inGuest.address2 << "|";
 inOStream << inGuest.city << "|";
 inOStream << inGuest.state << "|";
 inOStream << inGuest.zip << "|";
 inOStream << inGuest.phone_number << "|";
 inOStream << inGuest.email_address << "|";
 inOStream << inGuest.comments  << "|" << endl;
 return inOStream;
}

ostream& 
operator<< ( ostream &inOStream, const GuestInfo &inGuest )
{
 inOStream << inGuest.first_name << "|";
 inOStream << inGuest.last_name << "|";
 inOStream << inGuest.company << "|";
 inOStream << inGuest.address1 << "|";
 inOStream << inGuest.address2 << "|";
 inOStream << inGuest.city << "|";
 inOStream << inGuest.state << "|";
 inOStream << inGuest.zip << "|";
 inOStream << inGuest.phone_number << "|";
 inOStream << inGuest.email_address << "|";
 inOStream << inGuest.comments  << "|";
 return inOStream;
}

istream& 
operator>> ( istream &inIStream, GuestInfo &outGuest )
{
 inIStream.getline(outGuest.first_name,32,'|');
 inIStream.getline(outGuest.last_name,32,'|');
 inIStream.getline(outGuest.company,32,'|');
 inIStream.getline(outGuest.address1,32,'|');
 inIStream.getline(outGuest.address2,32,'|');
 inIStream.getline(outGuest.city,32,'|');
 inIStream.getline(outGuest.state,32,'|');
 inIStream.getline(outGuest.zip,16,'|');
 inIStream.getline(outGuest.phone_number,16,'|');
 inIStream.getline(outGuest.email_address,64,'|');
 inIStream.getline(outGuest.comments,256,'|');
 return inIStream;
}

// here's our comparitor we use in the STL sort()...
bool
guest_bigger_than( const GuestInfo &inGuest1, const GuestInfo &inGuest2 )
{
 signed int comp = _stricmp( inGuest1.last_name, inGuest2.last_name );
 if ( comp ==0 ) // same last names???
  comp = _stricmp(inGuest1.first_name, inGuest2.first_name );
 
 return comp < 0;
} // string_bigger_than...

// here's where we check for uniqueness of names for STL's unique()...
bool
check_uniqueness( const GuestInfo &inGuest1, const GuestInfo &inGuest2 )
{
 return ( ( !_stricmp( inGuest1.first_name, inGuest2.first_name ) &&
  !_stricmp(inGuest1.last_name, inGuest2.last_name ) &&
  !_stricmp(inGuest1.email_address, inGuest2.email_address )) ? true : false ); 
} // check_uniqueness...


///////////////////////////////////////////////////////////////////////
// The one and only CGuestBook object

CGuestBook theExtension;


///////////////////////////////////////////////////////////////////////
// CGuestBook implementation

CGuestBook::CGuestBook()
{
}

CGuestBook::~CGuestBook()
{
}

BOOL CGuestBook::GetExtensionVersion(HSE_VERSION_INFO* pVer)
{
 // Call default implementation for initialization
 CHttpServer::GetExtensionVersion(pVer);

 // Load description string
 TCHAR sz[HSE_MAX_EXT_DLL_NAME_LEN+1];
 ISAPIVERIFY(::LoadString(AfxGetResourceHandle(),
   IDS_SERVER, sz, HSE_MAX_EXT_DLL_NAME_LEN));
 _tcscpy(pVer->lpszExtensionDesc, sz);
 return TRUE;
}

///////////////////////////////////////////////////////////////////////
// CGuestBook command handlers

void CGuestBook::Default(CHttpServerContext* pCtxt)
{
 StartContent(pCtxt);
 WriteTitle(pCtxt);

 *pCtxt << _T("This should NEVER be called if your pages and PARSEMAP");
 *pCtxt << _T(" were correctly written!\r\n");

 EndContent(pCtxt);
}

//
// CGuestBook::ViewGuestBook -- member that displays the sorted list of
//         guests that have signed in at our site.
//

void
CGuestBook::ViewGuestBook( CHttpServerContext *pCtxt )
{
 *pCtxt << "<p><center>\r\nPeople who have signed our Guest Book for the C/C++ Users Journal\r\n </center></p>";

 CSingleLock lock(&m_criticalParts, TRUE);       // restrict access
 try 
 {
  vector<GuestInfo> theGuests;
  ifstream inputFile("OurGuestBook");       // the file to use
  istream_iterator<GuestInfo,ptrdiff_t> iter(inputFile),end;  // iterator
  copy( iter, end, inserter(theGuests,theGuests.begin()) );  // copy to our vector
  inputFile.close();            // all done for now

  // sort and remove duplicates!
  ofstream outputFile("OurGuestBook");
  ostream_iterator<GuestInfo> oiter(outputFile);
  sort( theGuests.begin(), theGuests.end(), guest_bigger_than ); // alphabetically
  vector<GuestInfo>::iterator last =
   unique( theGuests.begin(), theGuests.end(),check_uniqueness ); // remove duplicates
  theGuests.erase( last, theGuests.end() );
  copy( theGuests.begin(), last, oiter );    // write the output file!
  outputFile.close();
  
  for ( vector<GuestInfo>::iterator myiter = theGuests.begin();myiter != theGuests.end(); myiter++ )
   *pCtxt << "<p><center>\r\n" << myiter->first_name << " " << myiter->last_name << "\r\n</center></p>";
 }

 catch(...)
 {
  lock.Unlock();
  *pCtxt << "<p><center>DANGER WILL ROBINSON, DANGER. Please contact don@gigantor.com with this message.</center></p>";
 }

 lock.Unlock();            // OK, let someone else use it
} // CGuestBook::ViewGuestBook...

//
// CGuestBook::SignGuestBook -- member to take the input data and write to our
//         file for storage. Later we can do something
//         with the data.
//

void
CGuestBook::SignGuestBook( CHttpServerContext *pCtxt, LPTSTR inFirstName, LPTSTR inLastName,
       LPTSTR inCompanyName, LPTSTR inAddress1, LPTSTR inAddress2,
       LPTSTR inCity, LPTSTR inState, LPTSTR inZip, LPTSTR inPhone,
       LPTSTR inEmail, LPTSTR inComments)
{
 StartContent(pCtxt);
 
 // note that we check to see certain portions have been filled in by the user
 // you could have different messages for each one if you wanted.
 if( !inFirstName || !inLastName || !inAddress1 || !inCity || !inState || !inZip
  || !inPhone || ! inEmail )
 {
  *pCtxt << "<p><center>Sorry, but your name was <b>not</b> added successfully to our guestbook.</center></p>";
  *pCtxt << "<p><center>You have not completed all of the required information.</center></p>";
  EndContent(pCtxt);     // ends our HTML page sent to the user
 }
 else
 {
  *pCtxt << "<p><center>Your name has been added to our guestbook!</center></p>";
  *pCtxt <<  "<p><center>Thank you for reading the C/C++ Users Journal.</center></p>";

  // now store into our local file for records
  GuestInfoRef  guest;   // make a new record
  guest.first_name = inFirstName;  // and then fill it up
  guest.last_name = inLastName;
  guest.company = inCompanyName;
  guest.address1 = inAddress1;
  guest.address2 = inAddress2;
  guest.city = inCity;
  guest.state = inState;
  guest.zip = inZip;
  guest.phone_number = inPhone;
  guest.email_address = inEmail;
  guest.comments = inComments;

  // keep others from using the file while we are
  CSingleLock lock(&m_criticalParts, TRUE);
   ofstream guestFile("OurGuestBook",ios::ate | ios::out); // append "At The End"
   guestFile << guest;     // put it in our file
   guestFile.close();     // save our changes
  lock.Unlock();       // OK, let someone else use it

  ViewGuestBook( pCtxt );
  EndContent( pCtxt );     // ends our HTML page sent to the user 
 }
} // CGuestBook::SignGuestBook...

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CGuestBook, CHttpServer)
 //{{AFX_MSG_MAP(CGuestBook)
 //}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif // 0



///////////////////////////////////////////////////////////////////////
// If your extension will not use MFC, you'll need this code to make
// sure the extension objects can find the resource handle for the
// module.  If you convert your extension to not be dependent on MFC,
// remove the comments arounn the following AfxGetResourceHandle()
// and DllMain() functions, as well as the g_hInstance global.

/****

static HINSTANCE g_hInstance;

HINSTANCE AFXISAPI AfxGetResourceHandle()
{
 return g_hInstance;
}

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ulReason,
     LPVOID lpReserved)
{
 if (ulReason == DLL_PROCESS_ATTACH)
 {
  g_hInstance = hInst;
 }

 return TRUE;
}

****/
