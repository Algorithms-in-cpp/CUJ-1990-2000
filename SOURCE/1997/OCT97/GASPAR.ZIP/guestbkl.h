// GUESTBOOKL.H - Header file for GuestBook ISAPI DLL
//    GuestBook
//  3/15/97  By Don Gaspar
//     For the C/C++ Users Journal
// 
//  Copyright 1997 by Don Gaspar and Gigantor Software. All rights reserved.
//  Rights for publication and distribution granted to C/C++ Users Journal.
//    


#include "resource.h"

// this structure parallels the data on our HTML form
struct GuestInfo
{
 char first_name[32];
 char last_name[32];
 char company[32];
 char address1[32];
 char address2[32];
 char city[32];
 char state[32];
 char zip[16];
 char phone_number[16];
 char email_address[64];
 char comments[256];
};

// this was created for convenience
// instead of using strcpy's to the above structure whn coming
// in from the server, here we just use the ptr's already allocated
// mostly done out of laziness
struct GuestInfoRef
{
 LPTSTR first_name;
 LPTSTR last_name;
 LPTSTR company;
 LPTSTR address1;
 LPTSTR address2;
 LPTSTR city;
 LPTSTR state;
 LPTSTR zip;
 LPTSTR phone_number;
 LPTSTR email_address;
 LPTSTR comments;
};

// now for class declarations...
// our GuestBook class 
class CGuestBook : public CHttpServer
{
private:
 CCriticalSection m_criticalParts;
public:
 CGuestBook();
 ~CGuestBook();

 void SignGuestBook( CHttpServerContext *pCtxt, LPTSTR inFirstName, LPTSTR inLastName,
       LPTSTR inCompanyName, LPTSTR inAddress1, LPTSTR inAddress2,
       LPTSTR inCity, LPTSTR inState, LPTSTR inZip, LPTSTR inPhone,
       LPTSTR inEmail, LPTSTR inComments);
private:
 void ViewGuestBook( CHttpServerContext *pCtxt );

// Overrides
 // ClassWizard generated virtual function overrides
  // NOTE - the ClassWizard will add and remove member functions here.
  //    DO NOT EDIT what you see in these blocks of generated code !
 //{{AFX_VIRTUAL(CGuestBook)
 public:
 virtual BOOL GetExtensionVersion(HSE_VERSION_INFO* pVer);
 //}}AFX_VIRTUAL

 // TODO: Add handlers for your commands here.
 // For example:

 void Default(CHttpServerContext* pCtxt);

 DECLARE_PARSE_MAP()

 //{{AFX_MSG(CGuestBook)
 //}}AFX_MSG
};

