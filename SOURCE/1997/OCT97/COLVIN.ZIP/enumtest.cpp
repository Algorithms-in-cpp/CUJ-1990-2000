///////////////////////////////////////////////////////////////
// ENUMTEST.CPP

#include "enumiter.h"
#include "iterenum.h"
#include <stdio.h>

main() {

   // make an enumerator from an array of strings
   wchar_t* wstr[3] = { L"one", L"two", L"three" };
   IteratorAsEnum <
      wchar_t**, wchar_t*, IEnumString, &IID_IEnumString
   > wstrenum(wstr,wstr+3);

   // print the strings
   wchar_t* p;
   ULONG n;   
   while (!wstrenum.Next(1,&p,&n))
      wprintf(L"%s\n",p);
   wstrenum.Reset();

   // make an iterator from the string enumerator
   EnumAsIterator <
      IEnumString, wchar_t*
   > iter(&wstrenum), end;

   // print the strings again
   for (; iter != end; ++iter)
      wprintf(L"%s\n",*iter);
}
