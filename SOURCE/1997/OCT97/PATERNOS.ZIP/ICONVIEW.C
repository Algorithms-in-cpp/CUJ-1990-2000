#define STRICT
#include <windows.h>
#include <shellapi.h>
#include <commdlg.h>
#include <string.h>
#include "resource.h"

/* Function prototypes */
UINT CALLBACK __export FileOpenHookProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
void CALLBACK SwitchToThisWindow(HWND, BOOL);

/* Global variable */
HINSTANCE hInst;


int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
OPENFILENAME ofn;

if (hPrevInstance)
 {
  /* Undocumented function; restores and activates window */
  SwitchToThisWindow(FindWindow("#32770","Icon Viewer"),TRUE);
  return -1;
 }

/* Set global variable */
hInst = hInstance;

memset(&ofn,'\0',sizeof(OPENFILENAME));
ofn.lStructSize = sizeof(OPENFILENAME);
ofn.hwndOwner = NULL;
ofn.lpstrFilter =
  "Icon Files (*.ICO)\0*.ico\0Executable Files (*.exe)\0*.exe\0\0";
ofn.nFilterIndex = 1;
ofn.lpstrFile = NULL;
ofn.nMaxFile = 0;
ofn.lpstrFileTitle = NULL;
ofn.lpstrInitialDir = NULL;
ofn.lpstrTitle = "Icon Viewer";
ofn.lpstrDefExt = NULL;
ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_ENABLEHOOK | OFN_ENABLETEMPLATE;
ofn.hInstance = hInst;
ofn.lpTemplateName = "FILEOPEN";
ofn.lpfnHook = FileOpenHookProc;

GetOpenFileName(&ofn);

return TRUE;
   
}


UINT CALLBACK __export FileOpenHookProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
static HWND hGraphicWnd;
static HICON hExtractedIcon;
static RECT graphicRect;
static int nIconX, nIconY, nGraphicsRectWidth, nGraphicsRectHeight;
HDC hdc;
DWORD dwIndex;
char szBuffer[256];

switch(msg)
{
 case WM_DESTROY:
  /* Clean up */
  if (hExtractedIcon)
   DestroyIcon(hExtractedIcon);
  break;
 case WM_INITDIALOG:
  /* Get handle to graphic window */
  hGraphicWnd = GetDlgItem(hwndDlg,IDC_GRAPHIC_RESOURCE);

  /* Get the graphic window's dimensions */
  GetWindowRect(hGraphicWnd,&graphicRect);

  /* Calculate the width and height of the graphic window */
  nGraphicsRectWidth = graphicRect.right - graphicRect.left;
  nGraphicsRectHeight = graphicRect.bottom - graphicRect.top;

  /* Calculate x and y to center the icon */
  nIconX = (nGraphicsRectWidth - GetSystemMetrics(SM_CXICON)) / 2;
  nIconY = (nGraphicsRectHeight - GetSystemMetrics(SM_CYICON)) / 2;
  break;			
	
 case WM_PAINT:
  InvalidateRect(hGraphicWnd,NULL,TRUE);
  UpdateWindow(hGraphicWnd);

  /* Get handle to icon window device context */
  hdc = GetDC(hGraphicWnd);
			
  DrawIcon(hdc,nIconX,nIconY,hExtractedIcon);
  
  ReleaseDC(hGraphicWnd,hdc);
  break;

 case WM_COMMAND:
  switch(LOWORD(wParam))
   { 
    case 1120:
     if (HIWORD(lParam) == LBN_SELCHANGE)
      {
       /* Get the current file selection */
       dwIndex = SendDlgItemMessage(hwndDlg,LOWORD(wParam),LB_GETCURSEL,0,0L);
       if (dwIndex != LB_ERR)
        {
         /* Select the string */
         SendDlgItemMessage(hwndDlg,LOWORD(wParam),LB_GETTEXT,(WPARAM) dwIndex,(LPARAM) (LPCSTR) szBuffer);

         /* Update the graphic display */
         InvalidateRect(hGraphicWnd,NULL,TRUE);
         UpdateWindow(hGraphicWnd);

         /* Get handle to icon window device context */
         hdc = GetDC(hGraphicWnd);

        /* Free previous icon if any */
        if (hExtractedIcon)
         DestroyIcon(hExtractedIcon);

        /* Extract new icon, draw on obtained device context */
        hExtractedIcon = ExtractIcon(hInst,szBuffer,0);

        DrawIcon(hdc,nIconX,nIconY,hExtractedIcon);

	/* Free the device context */
	ReleaseDC(hGraphicWnd,hdc);
      }
     }
    break;						
  }
 break;
}

return FALSE;
	
}
