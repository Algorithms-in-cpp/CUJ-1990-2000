#ifndef SIZED_TYPES_H
#define SIZED_TYPES_H
     
#include <limits>
#include "ctassert.h"
     
//BEGIN MACHINE-DEPENDENT PART
     
typedef unsigned char uint8;
typedef signed char int8;
typedef unsigned short uint16;
typedef short int16;
typedef unsigned uint32;
typedef int int32;
     
//END MACHINE-DEPENDENT PART
     
//Force compile-time error if the typedefs are inappropriate for this
//platform.
     
namespace sized_integer_tests {
  using namespace std;
     
  ctassert<numeric_limits<int8>::is_integer> t1; 
  ctassert<numeric_limits<uint8>::is_integer> t2; 
  ctassert<numeric_limits<int16>::is_integer> t3; 
  ctassert<numeric_limits<uint16>::is_integer> t4; 
  ctassert<numeric_limits<int32>::is_integer> t5; 
  ctassert<numeric_limits<uint32>::is_integer> t6;
     
  ctassert<numeric_limits<int8>::is_signed> t7; 
  ctassert<numeric_limits<int16>::is_signed> t8; 
  ctassert<numeric_limits<int32>::is_signed> t9;
     
  ctassert<!numeric_limits<uint8>::is_signed> t10; 
  ctassert<!numeric_limits<uint16>::is_signed> t11; 
  ctassert<!numeric_limits<uint32>::is_signed> t12;
     
  ctassert<numeric_limits<int8>::radix == 2> t13; 
  ctassert<numeric_limits<uint8>::radix == 2> t14; 
  ctassert<numeric_limits<int16>::radix == 2> t15; 
  ctassert<numeric_limits<uint16>::radix == 2> t16; 
  ctassert<numeric_limits<int32>::radix == 2> t17; 
  ctassert<numeric_limits<uint32>::radix == 2> t18;
     
  ctassert<numeric_limits<int8>::digits == 7> t19; 
  ctassert<numeric_limits<uint8>::digits == 8> t20; 
  ctassert<numeric_limits<int16>::digits == 15> t21; 
  ctassert<numeric_limits<uint16>::digits == 16> t22; 
  ctassert<numeric_limits<int32>::digits == 31> t23; 
  ctassert<numeric_limits<uint32>::digits == 32> t24;
}
     
#endif
     
