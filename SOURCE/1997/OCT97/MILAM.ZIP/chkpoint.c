/**********************************************************************/
/* File Id:                     chkpoint.c.                           */
/* Author:                      Stan Milam.                           */
/* Date Written:                25 Nov. 96.                           */
/* Description:                                                       */
/*     The functions in this file are a package which serve to im-    */
/*     plement a checkpoint/restart capability for programs written   */
/*     in C.  This is accomplished by maintaining up-to-date infor-   */
/*     mation about each open file (filename, open mode, and          */
/*     position), and important values in memory in a checkpoint      */
/*     file.  This information is saved periodically with the         */
/*     checkpoint() function call.  If a program is restarting the    */
/*     information is retrieved when calling restart().  The result   */
/*     is the files are automatically opened and respositioned and    */
/*     designated memory is restored.  Using this package a program   */
/*     can be designed to restart from a point of failure.            */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "adjust.h"
#include "chkpoint.h"

/**********************************************************************/
/* Attempt to adjust for the environment (DOS/UNIX).                  */
/**********************************************************************/

#ifdef _UNIX
#   include <sys/types.h>
#   include <sys/stat.h>
#else
#   include <sys\types.h>
#   include <sys\stat.h>
#endif

/**********************************************************************/
/* Define the default directory for checkpoint log files.             */
/**********************************************************************/

#define DFLT_DIR "."

/**********************************************************************/
/* A convenient typedef for the stat structure.                       */
/**********************************************************************/

typedef struct stat STAT_T;

/*********************************************************************/
/* The following structure is the checkpoint header which is written */
/* as the first information in the log file.                         */
/*********************************************************************/

typedef struct {
    int      FileCount;               /* How many files were open. */
    unsigned sa_length;               /* Size of the memory save area. */
}LOGHDR_T;

/*********************************************************************/
/* The following structure is used to store information about an open*/
/* file.                                                             */
/*********************************************************************/

typedef struct {
    char   filename[CHKSIZ];           /* Full pathname of the file. */
    char   open_mode[5];               /* Open mode of the file. */
    fpos_t file_position;              /* Position in the file. */
}FILEINFO_T;

/*********************************************************************/
/* The following structure is used to build a linklist of open files.*/
/*********************************************************************/

typedef struct {
    void       *next;                  /* Classic next pointer. */
    FILE       *fp;                    /* File pointer for this file. */
    FILEINFO_T fileinfo;               /* Nuff said? */
}FILELIST_T;

/*********************************************************************/
/* Static variables which are shared by all functions in the file.   */
/*********************************************************************/

static char *chkpoint_dir;             /* Where checkpoint directory is */
static int FileCount = 0;              /* Count of open files in list. */
static char WrkBuf[CHKSIZ];            /* Scratch work buffer. */
static char *LogFile = NULL;           /* Full path to logfile. */
static FILELIST_T *FileList = NULL;    /* Head of the linked list. */

/**********************************************************************/
/* Name:                                                              */
/*     add_list_item().                                               */
/*                                                                    */
/* Description:                                                       */
/*     Add a FILELIST_T structure to a linked list.                   */
/*                                                                    */
/* Arguments:                                                         */
/*     FILELIST_T **linkset - Address of the base pointer to the      */
/*     list.  FILELIST_T *newmbr   - Address of the new member to the */
/*     list.                                                          */
/*                                                                    */
/* Return Value:                                                      */
/*     None.                                                          */
/*                                                                    */
/**********************************************************************/

static void add_list_item ( FILELIST_T **linkset, FILELIST_T *newmbr ) {

     newmbr -> next = *linkset;
     *linkset = newmbr;
}

/**********************************************************************/
/* Name:                                                              */
/*     remove_list_item().                                            */
/*                                                                    */
/* Description:                                                       */
/*     Removes a FILELIST_T structure from the linklist.              */
/*                                                                    */
/* Arguments:                                                         */
/*     FILELIST_T **linkbase - Address of the base item in list.      */
/*     FILELIST_T *member    - Address of member to remove from list. */
/*                                                                    */
/* Return Value:                                                      */
/*     EXIT_SUCCESS or EXIT_FAILURE.                                  */
/*                                                                    */
/**********************************************************************/

static int remove_list_item ( FILELIST_T **linkbase, FILELIST_T *member ) {

    FILELIST_T *wrk;
    int        rv = EXIT_FAILURE;

    /******************************************************************/
    /* Is the first member of the list the one to be removed?         */
    /******************************************************************/

    if ( ( wrk = *linkbase ) == member ) {
        rv = EXIT_SUCCESS;
        *linkbase = member -> next;
        member -> next = NULL;
    }

    /******************************************************************/
    /* Have to search the list for the one we want.                   */
    /******************************************************************/

    else for ( ; wrk -> next; wrk = wrk -> next ) {
        if ( member == wrk -> next ) {
            rv = EXIT_SUCCESS;
            wrk -> next = member -> next;
            member -> next = NULL;
        }
    }
    return rv;
}

/**********************************************************************/
/* Name:                                                              */
/*    get_file_list()                                                 */
/*                                                                    */
/* Description:                                                       */
/*      This function searches the internal linked list to match the  */
/*      file pointer argument.  When found a pointer to the matching  */
/*      structure is returned.  Otherwise a NULL pointer value is     */
/*      returned.                                                     */
/*                                                                    */
/* Arguments:                                                         */
/*      FILE *fp - The address of a file handle returned from         */
/*                 ckp_open().                                        */
/*                                                                    */
/* Return Values:                                                     */
/*      A pointer to type FILELIST_T when a match is found for *fp.   */
/*      A NULL value is returned when not found.                      */
/*                                                                    */
/**********************************************************************/

static FILELIST_T *get_file_list( FILE *fp ) {

    FILELIST_T *rv;

    for ( rv = FileList; rv != NULL; rv = rv -> next )
        if ( rv -> fp == fp )
            break;

    return rv;
}

/**********************************************************************/
/* Name:                                                              */
/*     get_file_pointer()                                             */
/*                                                                    */
/* Description:                                                       */
/*     This function is used internally to search for a file that     */
/*     is already open and return its file pointer if it is.          */
/*                                                                    */
/* Arguments:                                                         */
/*     char *filespec - A Pointer to a character string which con-    */
/*                      tains the path and name of the file to open.  */
/*                                                                    */
/* Return Values:                                                     */
/*     A pointer to a FILE structure.  A NULL value is returned when  */
/*     the search fails.                                              */
/*                                                                    */
/**********************************************************************/

static FILE *get_file_pointer( const char *filespec ) {

    FILELIST_T *filelist;             /* Used to walk the list */
    FILE       *rv = NULL;            /* Return Value */

    for (filelist = FileList; filelist != NULL; filelist = filelist -> next) {
        if ( strcmp( filespec, filelist -> fileinfo.filename ) == 0 ) {
            rv = filelist -> fp;
            break;
        }
    }
    return rv;
}

/**********************************************************************/
/* Name:                                                              */
/*     ckp_open().                                                    */
/*                                                                    */
/* Description:                                                       */
/*     Wrapper function for fopen().  Opened files are placed into a  */
/*     linked list.                                                   */
/*                                                                    */
/* Arguments:                                                         */
/*      char *filespec - The path and name of the file to be opened.  */
/*      char *mode     - The mode used to open the file.              */
/*                                                                    */
/* Return Values:                                                     */
/*      A pointer to type FILE defined in stdio.h.  A NULL pointer    */
/*      will be returned if the file could not be opened.             */
/*                                                                    */
/**********************************************************************/

void *ckp_open( char *filespec, char *mode ) {

    FILE       *rv, *fp;
    FILELIST_T *filelist;

    /******************************************************************/
    /* If the file is already in the list just return its open file   */
    /* pointer.                                                       */
    /******************************************************************/

    if ( ( fp = get_file_pointer( filespec ) ) != NULL )
        rv = fp;

    /******************************************************************/
    /* Open the file and return NULL just like fopen() when there     */
    /* are errors.                                                    */
    /******************************************************************/

    else if ( ( fp = fopen( filespec, mode ) ) == NULL )
        rv = NULL;

    /******************************************************************/
    /* Attempt to allocate memory for another member in the linked    */
    /* list of file information.  Deal with the errors.               */
    /******************************************************************/

    else if ( ( filelist = calloc( 1, sizeof(*filelist) ) ) == NULL ) {
        rv = NULL;
        fclose( fp );
        if ( *mode == 'w' ) remove( filespec );
    }

    /******************************************************************/
    /* Increment the internal file count, populate the file infor-    */
    /* mation and add to the linked list.                             */
    /******************************************************************/

    else {
        FileCount++;
        filelist -> fp = rv = fp;
        strcpy(filelist -> fileinfo.open_mode, mode );
        strcpy(filelist -> fileinfo.filename, filespec);
        add_list_item( &FileList, filelist );
    }
    return rv;
}

/**********************************************************************/
/* Name:                                                              */
/*     ckp_close().                                                   */
/*                                                                    */
/* Description:                                                       */
/*     Wrapper for fclose().  Close the file and remove it from the   */
/*     linked list so that future calls to checkpoint() do not log    */
/*     information about the file.                                    */
/*                                                                    */
/* Arguments:                                                         */
/*      FILE *fp - A pointer to an open file opened with ckp_open().  */
/*                                                                    */
/* Return Values:                                                     */
/*       0 = Success.                                                 */
/*                                                                    */
/**********************************************************************/

int ckp_close( void *fp ) {

    int        rv;
    FILELIST_T *filelist = get_file_list( fp );

    /******************************************************************/
    /* If there is nothing in the list, how can we close a file?      */
    /******************************************************************/

    if ( filelist == NULL )
        rv = -1;

    /******************************************************************/
    /* Decrement the internal file count, close the file and remove   */
    /* it from the internal list.                                     */
    /******************************************************************/

    else {
        FileCount--;
        rv = fclose ( filelist -> fp );
        remove_list_item( &FileList, filelist );
        free( filelist );
    }
    return rv;
}

/**********************************************************************/
/* Name:                                                              */
/*     rebuild_file_list().                                           */
/*                                                                    */
/* Description:                                                       */
/*     This function's responsibility is to rebuild the linked list   */
/*     of open files from the information in the logfile.             */
/*                                                                    */
/* Arguments:                                                         */
/*     FILE *chkpoint_fp - File pointer to logfile.                   */
/*     LOGHDR_T *log_header - Address of the logfile header record.   */
/*                                                                    */
/* Return Value:                                                      */
/*     EXIT_SUCCESS or EXIT_FAILURE.                                  */
/*                                                                    */
/**********************************************************************/

static int rebuild_filelist( FILE *chkpoint_fp, LOGHDR_T *log_header ) {

    FILE       *fp;
    FILEINFO_T *fileinfo;
    FILELIST_T *filelist;
    int        x_sub, rv = EXIT_SUCCESS;

    /******************************************************************/
    /* Enter a loop to rebuild the filelist.                          */
    /******************************************************************/

    for ( x_sub = 0; x_sub < log_header -> FileCount; x_sub++ ) {

        /**************************************************************/
        /* Allocate memory for a FILELIST_T structure.                */
        /**************************************************************/

        if ( ( filelist = calloc( 1, sizeof(*filelist) ) ) == NULL ) {
            rv = EXIT_FAILURE;
            break;
        }

        /**************************************************************/
        /* Get the address of the FILEINFO_T structure and begin to   */
        /* put data in it.                                            */
        /**************************************************************/

        fileinfo = &filelist -> fileinfo;
        if ( fread( fileinfo, sizeof(*fileinfo), 1, chkpoint_fp ) != 1 ) {
            rv = EXIT_FAILURE;
            break;
        }

        /**************************************************************/
        /* If the original file modes was anything but read it must   */
        /* be replaced with "r+b" so it can be opened and             */
        /* repositioned without destroying the file.                  */
        /**************************************************************/

        if ( *strcpy( WrkBuf, fileinfo -> open_mode ) != 'r' )
            strcpy( WrkBuf, "r+b" );

        /**************************************************************/
        /* Attempt to open the file.  If open fails we must give up   */
        /* as a reliable restart is not possible. User must decide    */
        /* what to do.                                                */
        /**************************************************************/

        if ( ( fp = fopen( fileinfo -> filename, WrkBuf ) ) == NULL ) {
            rv = EXIT_FAILURE;
            break;
        }
        else {

            /**********************************************************/
            /* Position the file to where it was at the last          */
            /* checkpoint.                                            */
            /**********************************************************/

            if ( fsetpos( fp, &filelist -> fileinfo.file_position ) != 0 ) {
                rv = EXIT_FAILURE;
                break;
            }

            /**********************************************************/
            /* Increment the internal counter and add to the linked   */
            /* list.                                                  */
            /**********************************************************/

            FileCount++;
            filelist -> fp = fp;
            add_list_item( &FileList, filelist );
        }
    }
    return rv;
}

/**********************************************************************/
/* Name:                                                              */
/*     restart_from_log_file()                                        */
/*                                                                    */
/* Description:                                                       */
/*      This function uses the information from the checkpoint        */
/*      logfile to rebuild open all file opened with ckp_open() at    */
/*      the time the program failed.  These files will be used to     */
/*      rebuild the internal linked list of open files and they must  */
/*      all be repositioned where they were at the time of the last   */
/*      call to checkpoint().  In addition, if an area of memory was  */
/*      saved at the last call to checkpoint it will also be          */
/*      restored.                                                     */
/*                                                                    */
/* Arguments:                                                         */
/*      void *save_area - The address of the program's save area.     */
/*                                                                    */
/* Return Value:                                                      */
/*      EXIT_SUCCESS or EXIT_FAILURE.                                 */
/*                                                                    */
/**********************************************************************/

static int restart_from_log_file( void *save_area ) {

    LOGHDR_T log_header;
    FILE     *chkpoint_fp;
    int      rv = EXIT_SUCCESS;

    /******************************************************************/
    /* Attempt to open the logfile.                                   */
    /******************************************************************/

    if ( ( chkpoint_fp = fopen( LogFile, "r") ) == NULL )
        rv = EXIT_FAILURE;

    /******************************************************************/
    /* Read the header record from the logfile.                       */
    /******************************************************************/

    else if ( fread( &log_header, sizeof(log_header), 1, chkpoint_fp ) != 1)
        rv = EXIT_FAILURE;

    /******************************************************************/
    /* Now rebuild the linked list of open files.                     */
    /******************************************************************/

    else if ( rebuild_filelist( chkpoint_fp, &log_header ) == EXIT_FAILURE )
        rv = EXIT_FAILURE;

    /******************************************************************/
    /* If there was a save area we must read it too.                  */
    /******************************************************************/

    else if ( log_header.sa_length > 0 )
       if ( fread( save_area, log_header.sa_length, 1, chkpoint_fp ) != 1 )
           rv = EXIT_FAILURE;

    /******************************************************************/
    /* Make sure the logfile is closed.                               */
    /******************************************************************/

    if ( chkpoint_fp != NULL )
        fclose( chkpoint_fp );

    return rv;
}

/**********************************************************************/
/* Name:                                                              */
/*     restart()                                                      */
/*                                                                    */
/* Description:                                                       */
/*     The restart() function is responsible for determining whether  */
/*     a program is starting normally, or restarting.  If it is de-   */
/*     termined the program is restarting logic is invoked to rebuild */
/*     the program's open files and restore the memory save area.     */
/*                                                                    */
/* Arguments:                                                         */
/*      char *ckp_id    - A character string which should be unique   */
/*                        for this program.  This id is used as       */
/*                        the major component of the filename used    */
/*                        as the checkpoint logfile, with the         */
/*                        string ".CKP" appended to it.               */
/*                        Therefore, this id must conform to local    */
/*                        file naming standards.                      */
/*                                                                    */
/*      void *save_area - The address of a save area which is where   */
/*                        restart() will place info saved at          */
/*                        checkpoint.                                 */
/*                                                                    */
/* Return Values:                                                     */
/*       0 = Program is starting normally.                            */
/*       1 = Program is restarting.                                   */
/*      -1 = Some problem was detected which would not allow the      */
/*           checkpoint/restart package to work properly. Most likely */
/*           this is a permission problem.                            */
/*                                                                    */
/**********************************************************************/

int restart( char *ckp_id, void *save_area ) {

    FILE   *fp;
    int    rv = 0;
    STAT_T statbuf;
    char   tmpbuf[CHKSIZ];

    /*****************************************************************/
    /* Bad things would happen if restart() were called twice and did*/
    /* not handle it.                                                */
    /*****************************************************************/

    if ( LogFile == NULL ) {

        /**************************************************************/
        /* Use the checkpoint id to create a checkpoint filename.     */
        /**************************************************************/

        sprintf( tmpbuf, "%s.CKP", ckp_id );

        /*************************************************************/
        /* Get the name of a directory to put the checkpoint file in.*/
        /* First see if an environment variable is used, and if not  */
        /* we must use the default value.                            */
        /*************************************************************/

        chkpoint_dir = getenv( "CHKPOINT_DIR" );
        if ( chkpoint_dir == NULL )
            chkpoint_dir = DFLT_DIR;

        /**************************************************************/
        /* Now, see if the directory really exists, and if so is it   */
        /* really a directory.                                        */
        /**************************************************************/

        if ( stat( chkpoint_dir, &statbuf ) == -1 )
            rv = -1;
        else if ( ( statbuf.st_mode & S_IFDIR ) != S_IFDIR )
            rv = -1;

        /*************************************************************/
        /* Now see if a checkpoint file already exist.  If one does  */
        /* the program is being restarted.                           */
        /*************************************************************/

        else {
            sprintf( WrkBuf, "%s%s%s", chkpoint_dir, PATHCHAR, tmpbuf );

            /**********************************************************/
            /* See if the file exists.  If so the program is restart- */
            /* ing.                                                   */
            /**********************************************************/

            if ( stat( WrkBuf, &statbuf ) == 0 ) {
                LogFile = strdup( WrkBuf );
                rv = restart_from_log_file( save_area );
                rv = (rv == EXIT_SUCCESS) ? 1 : -1;
            }
            else {

                /******************************************************/
                /* No file present.  Try to open in write mode to see */
                /* if we can.  If not there is something wrong.       */
                /******************************************************/

                if ( ( fp = fopen( WrkBuf, "w" ) ) == NULL )
                    rv = -1;
                else {
                    fclose( fp );
                    remove( WrkBuf );
                    LogFile = strdup( WrkBuf );
                }
            }
        }
    }
    return rv;
}

/**********************************************************************/
/* Name:                                                              */
/*     create_checkpoint_logfile().                                   */
/*                                                                    */
/* Description:                                                       */
/*     This function is called when the program wants to create a     */
/*     checkpoint.  It attempts to save all information about files   */
/*     opened with ckp_open() and then write the content of the save  */
/*     area to the logfile as well.                                   */
/*                                                                    */
/* Argument:                                                          */
/*     void *save_area  - Address of the area of memory to save.      */
/*     unsigned sa_size - The size of the save area.                  */
/*                                                                    */
/* Return Values:                                                     */
/*     EXIT_SUCCESS or EXIT_FAILURE.                                  */
/*                                                                    */
/**********************************************************************/

static int create_checkpoint_logfile( void *save_area, unsigned sa_size ) {

    FILELIST_T *filelist;
    FILEINFO_T fileinfo;
    LOGHDR_T   log_header;
    FILE       *chkpoint_fp;
    int        rv = EXIT_SUCCESS;

    /******************************************************************/
    /* Attempt to open the checkpoint logfile.                        */
    /******************************************************************/

    if ( ( chkpoint_fp = fopen( LogFile, "w+b" ) ) == NULL )
        rv = EXIT_FAILURE;
    else {

        /**************************************************************/
        /* Create the header record in the logfile.                   */
        /**************************************************************/

        log_header.sa_length = sa_size;
        log_header.FileCount = FileCount;

        if ( fwrite( &log_header, sizeof(log_header), 1, chkpoint_fp ) != 1 ) {
            rv = EXIT_FAILURE;
            fclose( chkpoint_fp );
        }
        else {

            /**********************************************************/
            /* For each file in the linked list write its information */
            /* to the logfile.                                        */
            /**********************************************************/

            filelist = FileList;
            while ( filelist != NULL ) {
                fileinfo = filelist -> fileinfo;

                /******************************************************/
                /* Determine if the file output.  If it is its        */
                /* buffers must be flushed.                           */
                /******************************************************/

                if ( *fileinfo.open_mode != 'r' )
                    fflush( filelist -> fp );

                /******************************************************/
                /* Now get the current position of the file.  Save    */
                /* everything in the logfile.                         */
                /******************************************************/

                fgetpos( filelist -> fp, &fileinfo.file_position );
                if (fwrite(&fileinfo, sizeof(fileinfo), 1, chkpoint_fp) != 1) {
                    rv = EXIT_FAILURE;
                    break;
                }

                filelist = filelist -> next;
            }

            /**********************************************************/
            /* If there have been no failures and there is a save     */
            /* area write the save area to the logfile.               */
            /**********************************************************/

            if ( rv != EXIT_FAILURE )
                if ( save_area != NULL && sa_size > 0 )
                    if ( fwrite( save_area, sa_size, 1, chkpoint_fp ) != 1 )
                        rv = EXIT_FAILURE;

            /**********************************************************/
            /* Close the logfile.                                     */
            /**********************************************************/

            fclose( chkpoint_fp );
        }
    }
    return rv;
}

/**********************************************************************/
/* Name:                                                              */
/*     cleanup_checkpoint_logfile().                                  */
/*                                                                    */
/* Description:                                                       */
/*     Performs cleanup operations when the final checkpoint is made  */
/*     with the last_time_flag set to a non-zero value.               */
/*                                                                    */
/* Arguments:                                                         */
/*     None.                                                          */
/*                                                                    */
/* Return Value:                                                      */
/*     None.                                                          */
/*                                                                    */
/**********************************************************************/

static void cleanup_checkpoint_logfile(void) {

    FILELIST_T *filelist;

    /******************************************************************/
    /* Close all the open files in the linked list and remove them    */
    /* from the linked list.                                          */
    /******************************************************************/

    for ( filelist = FileList; filelist != NULL; filelist = FileList ) {
        fclose( filelist -> fp );
        remove_list_item( &FileList, filelist);
        free( filelist );
    }

    /******************************************************************/
    /* Remove the logfile from the filesystem and free the memory     */
    /* used to store its name.  Set the pointer back to NULL, and     */
    /* set the file counter back to 0.  You never know:  Programmer   */
    /* may want to close down then start over again in the same       */
    /* program.                                                       */
    /******************************************************************/

    remove ( LogFile );
    free( LogFile );
    LogFile = NULL;
    FileCount  = 0;
}

/**********************************************************************/
/* Name:                                                              */
/*     checkpoint()                                                   */
/*                                                                    */
/* Description:                                                       */
/*     This function is called to create the checkpoint logfiles or   */
/*     to remove them when the program has completed processing.      */
/*                                                                    */
/* Arguments:                                                         */
/*     void     *save_area - The address of a programmer supplied     */
/*                           save area.                               */
/*     unsigned sa_size    - The size of the save area buffer passed  */
/*                           by the programmer.                       */
/*     int      flag       - A value used to indicate this is the     */
/*                           last checkpoint.  When this value is     */
/*                           TRUE all files will be closed and the    */
/*                           logfile will be removed.                 */
/*                                                                    */
/* Return Values:                                                     */
/*     EXIT_SUCCESS or EXIT_FAILURE.                                  */
/*                                                                    */
/**********************************************************************/

int checkpoint( void *save_area, unsigned sa_size, int last_time_flag ) {

    int rv = EXIT_SUCCESS;

    /******************************************************************/
    /* Check to see if there is a checkpoint log file to open.  The   */
    /* filename is built and assigned by restart() which must be in-  */
    /* voked before checkpoint().                                     */
    /******************************************************************/

    if ( LogFile == NULL )
        rv = EXIT_FAILURE;

    /******************************************************************/
    /* If the last_time_flag is set we must close all open files and  */
    /* remove the checkpoint logfile.                                 */
    /******************************************************************/

    else if ( last_time_flag != 0 )
        cleanup_checkpoint_logfile();

    /******************************************************************/
    /* Must create the checkpoint logfile, and save program state     */
    /* information.                                                   */
    /******************************************************************/

    else
        rv = create_checkpoint_logfile( save_area, sa_size );

    return rv;
}
