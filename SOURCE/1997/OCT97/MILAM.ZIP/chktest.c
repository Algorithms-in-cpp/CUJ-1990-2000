/**********************************************************************/
/* Program Id.                    chktest.c.                          */
/* Author:                        Stan Milam.                         */
/* Date Written:                  26 Nov. 96.                         */
/*                                                                    */
/* Description:                                                       */
/*    This program serves to test and demonstrate the functions which */
/*    comprise the checkpoint/restart system.                         */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "chkpoint.h"

/*********************************************************************/
/* This structure will have dual purposes.  First it contains the in-*/
/* put buffers for both input files.  Second it is the save area used*/
/* in checkpoint/restarting.                                         */
/*********************************************************************/

typedef struct save_area {
    long long_value;
    char inbuf1[BUFSIZ];
    char inbuf2[BUFSIZ];
}SAVEAREA_T;

int main( void ) {

    FILE *in1, *in2, *out;
    char chk_id[] = "chktest";
    static SAVEAREA_T save_area;
    int  i_sub, rv = EXIT_SUCCESS, status;

    switch ( restart( chk_id, &save_area ) ) {

        /***************************************************************/
        /* The program was attempting to restart but some error occured*/
        /***************************************************************/

        case -1 :
            puts("Error: An error occured while restarting the program");
            rv = EXIT_FAILURE;
            break;

        /*************************************************************/
        /* The program is starting normally. In this case the files  */
        /* will be opened just as though fopen() were used.          */
        /*************************************************************/

        case  0 :

            puts("The program is starting normally.");

            /**********************************************************/
            /* The files are opened by the ckp_open() function just   */
            /* as as the same as fopen() would.  Opening a file with  */
            /* the ckp_open() function allows checkpoint() to know    */
            /* about the file.                                        */
            /**********************************************************/

            in1 = ckp_open( "chkdata.d1",  "r" );
            in2 = ckp_open( "chkdata.d2",  "r" );
            out = ckp_open( "chkdata.out", "w" );

            /**********************************************************/
            /* Now read both input files.  Write the record from the  */
            /* first one every time, write the record from the 2nd    */
            /* every other time.  Call checkpoint() every 100 times   */
            /* through the loop.  Quit after 500 records and leave    */
            /* a checkpoint log record.                               */
            /**********************************************************/

            for ( i_sub = 0; i_sub < 500; i_sub++ ) {
                fgets( save_area.inbuf1, BUFSIZ, in1 );
                fputs( save_area.inbuf1, out );

                if ( (i_sub + 1) % 2 == 0 ) {
                    fgets( save_area.inbuf2, BUFSIZ, in2 );
                    fputs( save_area.inbuf2, out );
                }

                if ( (i_sub + 1) % 100 == 0 ) {
                    save_area.long_value = (long) i_sub;
                    status = checkpoint(&save_area, sizeof(save_area), 0);
                    if ( status == EXIT_FAILURE ) {
                        puts( "Error while attempting to checkpoint.");
                        rv = EXIT_FAILURE;
                        break;
                    }
                }
            }

            /*********************************************************/
            /* Now read a few hundred more records without taking a  */
            /* checkpoint.                                           */
            /*********************************************************/

            for ( i_sub = 0; i_sub < 400; i_sub++ ) {
                fgets(save_area.inbuf1, BUFSIZ, in1);
                fgets(save_area.inbuf2, BUFSIZ, in2);
                fprintf(out, "DUMMY: %s", save_area.inbuf1);
            }

            break;

        /*************************************************************/
        /* In this case the program is restarting. We open the files */
        /* and start where we left off at the last checkpoint.  Even */
        /* though we are opening the files we are only getting the   */
        /* file handles to them.  restart() opened them and repos-   */
        /* itioned them for us.                                      */
        /*************************************************************/

        case  1 :

            i_sub = 0;
            puts("The program is RESTARTING!");

            /*********************************************************/
            /* Get handles to files already opened by restart().     */
            /*********************************************************/

            in1 = ckp_open( "chkdata.d1",  "r" );
            in2 = ckp_open( "chkdata.d2",  "r" );
            out = ckp_open( "chkdata.out", "w" );

            while ( fgets( save_area.inbuf1, BUFSIZ, in1 ) != NULL ) {
                fprintf(out, "RESTART %s", save_area.inbuf1);
                if ( ++i_sub % 100 == 0 ) {
                    save_area.long_value += i_sub;
                    status = checkpoint( &save_area, sizeof(save_area), 0);
                    if ( status == EXIT_FAILURE ) {
                        puts( "Error while attempting to checkpoint." );
                        rv = EXIT_FAILURE;
                        break;
                    }
                }
            }

            /**********************************************************/
            /* Do final checkpoint to clean up.  This will close all  */
            /* files opened with ckp_open().                          */
            /**********************************************************/

            if ( rv == EXIT_SUCCESS ) checkpoint( NULL, 0, 1 );
            break;
    }

    return rv;
}
