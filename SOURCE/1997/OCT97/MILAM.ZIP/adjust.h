/**********************************************************************/
/* File Id:                     adjust.h.                             */
/* Author:                      Stan Milam.                           */
/* Date Started:                26 Aug. 93.                           */
/* Description:                                                       */
/*     This file attempts to adjust for different operating systems   */
/*     We will see if we are successful or not.                       */
/*                                                                    */
/**********************************************************************/

#ifndef ADJUST_H
#	define ADJUST_H 1

/**********************************************************************/
/* Test to see if we are using a DOS or UNIX based compiler.          */
/**********************************************************************/

#if defined (__TURBOC__) || defined (__POWERC) || defined (MSC_VER) || defined (M_I86)
#   define _DOS
#   define CHKSIZ 512
#   define PATHCHAR "\\"
#   define PATHDELM ";"
#else
#   define _UNIX
#   define CHKSIZ 4096
#   define PATHCHAR "/"
#   define PATHDELM ":"
#   define O_BINARY 0
#endif

#endif
