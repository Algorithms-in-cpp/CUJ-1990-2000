[Caption: Figure 2 -- Using restart at program initialization]

static FILE *init_program( int argc, char **argv,
                           PGMINFO_T *pgminfo ) {

   int  rc;
   FILE *rv = NULL;
   char pgmid[] = "example";

   /****************************************************************/
   /* Initialize the program information area.                     */
   /****************************************************************/

   memset( pgminfo, 0, sizeof( *pgminfo ) );

   /****************************************************************/
   /* Attempt to connect to the database.                          */
   /****************************************************************/

   if ( sql_connect( pgm_id ) == SQL_FAILURE )
      rv = NULL;
   else {

      /*************************************************************/
      /* Note the fact the program started and call the restart    */
      /* function.                                                 */
      /*************************************************************/

      sql_log( LOGACT, "Program Started.\n");
      switch ( restart( pgm_id, pgminfo ) ) {

         /**********************************************************/
         /* Did an error occur restarting the program.             */
         /**********************************************************/

         case -1 :
            sql_log( LOGERR, "Error encountered restarting!\n" );
            break;

         /**********************************************************/
         /* Program is starting normally.                          */
         /**********************************************************/

         case 0  :

            if ( argc < 2 )
               sql_log( LOGERR, "Error: No input file supplied.\n" );
            else {
               strcpy( pgminfo -> input_file, argv[1] );
               if ((rv = ckp_open(pgminfo->input_file, "r")) == NULL)
                  sql_log(LOGERR, "Error: Unable to open file: %s\n",
                          pgminfo -> input_file );
            }
            break;

         /**********************************************************/
         /* Program is restarting.                                 */
         /**********************************************************/

         case 1 :
            if ( (rv = ckp_open(pgminfo->input_file, "r" ) ) 
                == NULL )
               sql_log(LOGERR, "Error Unable to open file %s when "
                       "restarting the program.\n",
                       pgminfo -> file );
            break;
      }
   }
   return rv;
}
