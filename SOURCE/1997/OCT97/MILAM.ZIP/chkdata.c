/**********************************************************************/
/* File Id:                    chkdata.c.                             */
/* Author:                     Stan Milam.                            */
/* Description:                                                       */
/*     Simple program to produce data files for use with the chktest  */
/*     program.  Usage:                                               */
/*                                                                    */
/*         chkdata >chkdata.d1                                        */
/*         chkdata >chkdata.d2                                        */
/*                                                                    */
/*     Now, you are ready to run chktest.                             */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>

int main( void ) {

    int i;

    for (i = 0; i < 5000; i++)
        printf("%04d: Programming is fun if you know how.\n", i);

    return 0;
}
