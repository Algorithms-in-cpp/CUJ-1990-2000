To test and demonstrate the checkpoint/restart package the CHKTEST.C
program is included.  Before you compile and run this program you will
need to create the test datasets.  To do this compile the program
CHKDATA.C and run it twice in the following manner:

chkdata >chkdata.d1
chkdata >chkdata.d2

This will create the files chkdata.d1 and chkdata.d2 which will be used
by the chktest program.  The chktest program first calls restart() and
if starting normally, opens the two data files with ckp_open() then
proceeds to read from these files, writing their input to a third output
file (also opened with ckp_open()).  With one of the input files only
every other record is read and written to the output.  A checkpoint is
created after every 100 passes through the main loop.  The main loop is
exited after 500 passes.  Another loop is entered where 400 records are
written to the output file prefixed with the word "DUMMY:".  The program
then exits without calling the final checkpoint().  This leaves a
checkpoint logfile.

Examine the output file (chkdata.out) and confirm the existence of the
records prefixed with "DUMMY".  Note the position in the file where
these records begin to appear.

Now, run the program again.  This time it will print a message that it
is restarting.  The two input files and the output files are opened and
repositioned at the exact point where the last call the checkpoint() was
made.  The program begins reading from the input files and writing to
the output file.  This time, however, the output records are prefixed
with the word "RESTART".  This time when the program finishes it makes
a final call to checkpoint() to close all files opened with ckp_open()
and removes the checkpoint logfile.

Again, examine the output file (chkdata.out).  Move to the line where
the "DUMMY" records started.  You should now see those records replaced
with ones prefixed with the word "RESTART".

Also demonstrated by the program but not emphasized is the restoration
of the savearea when the program restarts.  You may confirm this by
using a printf() statement in the code that executes with a restart or
just use a debugger.
