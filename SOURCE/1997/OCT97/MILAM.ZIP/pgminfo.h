[Caption: Figure 1 -- The program information structure]

#include <stdio.h>  /* For FILENAME_MAX */
#include <stdlib.h> /* For EXIT_SUCCESS
                       & EXIT_FAILURE. */
#include <string.h>
#include "chkpoint.h"

typedef struct {
    unsigned long insert_count;
    unsigned long update_count;
    unsigned long delete_count;
    unsigned long error_count;
    unsigned long record_count;
    char input_file[FILENAME_MAX];
} PGMINFO_T;

