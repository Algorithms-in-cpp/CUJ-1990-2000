[Caption: Figure 3 -- Using checkpoint to segment large transactions]

int main_process( FILE *fp, PGMINFO_T *pgminfo ) {

    int  count = 0;
    char inbuf[BUFSIZ];

    while( fgets( inbuf, sizeof(inbuf), fp ) != NULL ) {

        count++;
        pgminfo -> record_count++;

        switch( *inbuf ) {

            case 'I' :
                if ( insert_data( inbuf ) == EXIT_FAILURE )
                    return EXIT_FAILURE;
                break;

            case 'D' :
                if ( delete_data( inbuf ) == EXIT_FAILURE )
                    return EXIT_FAILURE;
                break;

            case 'U' :
                if ( update_data( inbuf ) == EXIT_FAILURE )
                    return EXIT_FAILURE;
                break;

            default :
                sql_log( LOGERR, "Invalid record: %s\n", inbuf );
                pgminfo -> error_count++;
        }

        /*******************************************************/
        /* Commit after 200 data records.                      */
        /*******************************************************/

        if ( count == 200 ) {
            if ( sql_commit() == SQL_SUCCESS ) {
                count = 0;
                checkpoint( pgminfo, sizeof(*pgminfo), 0 );
            }
            else {
                sql_log( LOGERR, "Unable to commit!\n" );
                return EXIT_FAILURE;
            }
        }
    }

    /***********************************************************/
    /* Final commit/checkpoint() to remove checkpoint logfile. */
    /***********************************************************/

    if ( sql_commit() == SQL_SUCCESS )
        checkpoint( NULL, 0, 1 );
    else {
        sql_log( LOGERR, "Unable to do the final commit!\n" );
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
