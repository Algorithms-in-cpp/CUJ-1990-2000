/**********************************************************************/
/* File Id:                    chkpoint.h.                            */
/* Author:                     Stan Milam.                            */
/* Date Written:               25 Nov. 96.                            */
/* Description:                                                       */
/*     Function prototypes for checkpoint/restart package.            */
/*                                                                    */
/**********************************************************************/

#ifndef CHKPOINT_H
#  define CHKPOINT_H 1
#  ifdef _cplusplus
extern "C" {
#  endif

int  ckp_close ( void *fp );
int  restart( char *ckp_id, void *save_area );
void *ckp_open ( char *filename, char *open_mode );
int  checkpoint(void *save_area, unsigned sa_size, int last_time_flag);

#   ifdef _cplusplus
}
#   endif
#endif
