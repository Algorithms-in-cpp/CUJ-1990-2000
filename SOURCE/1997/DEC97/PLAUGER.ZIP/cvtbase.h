    // STRUCT codecvt_base
class codecvt_base : public locale::facet {
public:
    enum result {ok, partial, error, noconv};
    codecvt_base(size_t _R = 0)
        : locale::facet(_R) {}
    bool always_noconv() const throw ()
        {return (do_always_noconv()); }
    int max_length() const throw ()
        {return (do_max_length()); }
    int encoding() const throw ()
        {return (do_encoding()); }
    ~codecvt_base() {}
protected:
    virtual bool do_always_noconv() const throw ()
        {return (true); }
    virtual int do_max_length() const throw ()
        {return (1); }
    virtual int do_encoding() const throw ()
        {return (1); }
    };

    // bitmask operators for codecvt_base::result
inline codecvt_base::result&
    operator&=(codecvt_base::result& _X,
        codecvt_base::result _Y)
    {_X = (codecvt_base::result)((int)_X & (int)_Y); return _X; }
inline codecvt_base::result&
    operator|=(codecvt_base::result& _X,
        codecvt_base::result _Y)
    {_X = (codecvt_base::result)((int)_X | (int)_Y); return _X; }
inline codecvt_base::result&
    operator^=(codecvt_base::result& _X,
        codecvt_base::result _Y)
    {_X = (codecvt_base::result)((int)_X ^ (int)_Y); return _X; }
inline codecvt_base::result
    operator&(codecvt_base::result _X,
        codecvt_base::result _Y)
    {return ((codecvt_base::result)((int)_X & (int)_Y)); }
inline codecvt_base::result
    operator|(codecvt_base::result _X,
        codecvt_base::result _Y)
    {return ((codecvt_base::result)((int)_X | (int)_Y)); }
inline codecvt_base::result
    operator^(codecvt_base::result _X,
        codecvt_base::result _Y)
    {return ((codecvt_base::result)((int)_X ^ (int)_Y)); }
inline codecvt_base::result
    operator~(codecvt_base::result _X)
    {return ((codecvt_base::result)~(int)_X); }
