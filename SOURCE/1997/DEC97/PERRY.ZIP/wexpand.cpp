void LP::Expand3x3 (
    unsigned char val, unsigned char *block, unsigned width)
{
    *block += val / 4; // First row
    *++block += val / 2;
    *++block += val / 4;
    block += width - 2;
    *block += val / 2; // Second row
    *++block += val;
    *++block += val / 2;
    block += width - 2;
    *block += val / 4; // Third row
    *++block += val / 2;
    *++block += val / 4;
}

void LP::Expand2x3 (
    unsigned char val, unsigned char *block, unsigned width)
{
    *block += val / 4; // First row
    *++block += val / 2;
    block += width - 1;
    *block += val / 2; // Second row
    *++block += val;
    block += width - 1;
    *block += val / 4; // Third row
    *++block += val / 2;
}

void LP::Expand3x2 (
    unsigned char val, unsigned char *block, unsigned width)
{
    *block += val / 4; // First row
    *++block += val / 2;
    *++block += val / 4;
    block += width - 2;
    *block += val / 2; // Second row
    *++block += val;
    *++block += val / 2;
}

void LP::Expand2x2 (
    unsigned char val, unsigned char *block, unsigned width)
{
    *block += val / 16; // First row
    *++block += val / 8;
    block += width - 1;
    *block += val / 8; // Second row
    *++block += val / 4;
}
