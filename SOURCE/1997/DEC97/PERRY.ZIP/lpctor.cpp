LP::LP (unsigned width, unsigned height, 
     const unsigned char *image,
     unsigned levels, unsigned *bpp)
{
    // Build pyramid structure and copy initial image

    if (!width || !height || !levels || !image)
        throw "Invalid parameter";

    _width = width;
    _height = height;

    // Adjust levels if width or height is too small

    while (width >> (levels - 1) == 0 || height >> (levels - 1) == 0)
        --levels;

    _levels = levels;
    _bpp = new unsigned [levels];

    if (!_bpp)
        throw "Memory allocation error";

    for (unsigned level = 0; level < levels; level++)
        _bpp[level] = bpp[level];

    AllocateLevels ();

    // Copy image into level 0

    memcpy (_r_images[0], image, _width * _height);
}
