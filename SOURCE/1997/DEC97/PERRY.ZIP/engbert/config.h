/*                  CONFIG.H
**
*/


#define PACK_PROGRAM_NAME "PACK2"
#define UNPACK_PROGRAM_NAME "UNPACK2"
#define EXTENSION "PK2"
#define MAGIC_HEADER "\137\233"


/* return values of compress(): */

#define WRITE_ERR 1

/* configuration stuff: */

#define COMPRESS

