/*                        DECOMP.C
**
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include "config.h"
#include "proto.h"

signed int bit;  /*global shared with BITS.C */

int decompress() {

unsigned int long length;
unsigned int character;
unsigned int byte_count;
unsigned int character_count;
extern signed int user_byte;

	byte_count = 0;
	character_count = 0;
	init_bits();
	init_list();

	fread(&length,sizeof(length),1,stdin);

	user_byte = getc(stdin);
	/* ignore any EOF return value here! */
	putc(user_byte,stdout);
	update_list(&byte_count, &character_count);

	length--;  /*for the first byte read above*/
	bit = read_bit();
	/* bit is global !!! , first bit set here,
	** rest in decode_byte()! */

	while ( bit != EOF && length){
		/* if bit == EOF, the file was tampered with */
		decode_byte(0, character_count+1, byte_count+1);
		  /* decode_byte() sets global user_byte*/
		update_list(&byte_count, &character_count);

		putc (user_byte,stdout);
		length--;
	} /*while */
	fflush(stdout);
	fprintf(stderr,"byte_count is %u\n",byte_count);
	if (ferror(stdout)) return WRITE_ERR;
	else return 0;
} /*decompress()*/

