
/* file identity.c: */
int is_our_extension (char *file_extension);
char *return_extension ();
int write_file_header();

/* file usage.c: */
int usage();
char **get_arguments(int argc, char **argv, int *overwrite, char *output_directory);

/* file main.c: */
void onintr ();
int writeerr();
int copy_mode();
int copy_date_time();
int main(int argc, char **argv );

/* file comp.c: */
int compress(long file_length);

/* file bits.c: */
int write_byte (unsigned char byte);
int flush_bits();
void write_bit (unsigned char bit);
int init_bits();

/* file nodes.c: */
void encode_byte(unsigned int start, unsigned int list_count, unsigned int count);
void update_list( unsigned int *byte_count, unsigned int *character_count);
