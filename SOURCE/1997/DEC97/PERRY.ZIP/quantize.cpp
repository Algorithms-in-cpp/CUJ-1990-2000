void LP::Quantize ()
{
    // Quantize by removing least significant bits

    for (unsigned level = 0; level < _levels; level++)
    {
        if (_bpp[level] > 8)
            throw "Bits per pixel is out of range";

        if (_bpp[level] == 8)
            continue;

        unsigned char *image = _l_images[level];

        for (unsigned index = 0; 
            index < (_width >> level) * (_height >> level); 
            index++)
        {
            // Shift off the bits

            image[index] = image[index] >> (8 - _bpp[level]);
        }
    }
}

