unsigned char
LP::Reduce3x3 (const unsigned char *block, unsigned width)
{
    // Reduce a block using a 3 by 3 equivalent weighting function

    unsigned r;

    r = *block; // First row
    r += *++block * 2;
    r += *++block;
    block += width - 2;
    r += *block * 2; // Second row
    r += *++block * 4;
    r += *++block * 2;
    block += width - 2;
    r += *block; // Third row
    r += *++block * 2;
    r += *++block;

    return r / 16;
}

unsigned char
LP::Reduce2x3 (const unsigned char *block, unsigned width)
{
    // Reduce a block using a 3 by 3 equivalent weighting function

    // Reflect left column to right column

    unsigned r;

    r = *block * 2; // First row
    r += *++block * 2;
    block += width - 1;
    r += *block * 4; // Second row
    r += *++block * 4;
    block += width - 1;
    r += *block * 2; // Third row
    r += *++block * 2;

    return r / 16;
}

unsigned char
LP::Reduce3x2 (const unsigned char *block, unsigned width)
{
    // Reduce a block using a 3 by 3 equivalent weighting function

    // Reflect top row to bottom row

    unsigned r;

    r = *block * 2; // First row
    r += *++block * 4;
    r += *++block * 2;
    block += width - 2;
    r += *block * 2; // Second row
    r += *++block * 4;
    r += *++block * 2;

    return r / 16;
}

unsigned char
LP::Reduce2x2 (const unsigned char *block, unsigned width)
{
    // Reduce a block using a 3 by 3 equivalent weighting function

    // Reflect left column to right column
    // Reflect top row to bottom row

    unsigned r;

    r = *block * 4; // First row
    r += *++block * 4;
    block += width - 1;
    r += *block * 4; // Second row
    r += *++block * 4;

    return r / 16;
}

