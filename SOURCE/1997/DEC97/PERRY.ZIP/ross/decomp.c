
Figure 4
--------

A function to decompress a data record compressed with Huffman encoding.


#include <stdio.h>
#include "hufftree.h"

/*
   --------------------------------- decode -----------------------------
*/

void decode(char *bufin, int *outlen, char *bufout)
{ short h;
  int obit;
  int nin = 0, nout = 0;
  int byt, cnt = 8;
  unsigned char size;

  size = (unsigned char)bufin[nin++];
  while (nout < size)
  { h = root;
    while (ht[h].right != NULL)
    { if (cnt == 8)
      { byt = bufin[nin];
        nin++;
        cnt = 0;
      }
      obit = byt & 0x80;
      byt <<= 1;
      cnt++;
      if (obit)
        h = ht[h].left;
      else
        h = ht[h].right;
    }
    bufout[nout++] = h;
  }
  *outlen = nout;
}


