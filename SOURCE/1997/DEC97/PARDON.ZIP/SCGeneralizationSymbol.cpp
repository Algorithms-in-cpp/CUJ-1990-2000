/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#include <igbundle.hpp>
#include <igline.hpp>
#include <igpyline.hpp>
#include <igrafctx.hpp>

#include "SCGeneralizationSymbol.hpp"
#include "SCClassSymbol.hpp"

IGraphicBundle SCGeneralizationSymbol::bundle;
const int SCGeneralizationSymbol::ARROW_LENGTH =  20;
const int SCGeneralizationSymbol::ARROW_WIDTH =  2*5;

/********************************************************/
SCGeneralizationSymbol::SCGeneralizationSymbol(
                  const SCClassSymbol& aParent,
                  const SCClassSymbol& aChild)
/********************************************************/
  : iParentSymbol(&aParent), iChildSymbol(&aChild)
{
  bundle.setPenColor(IColor::black)
               .setFillColor(IColor::white)
               .setMixMode(IGraphicContext::defaultMixMode())
               .setDrawOperation( IGraphicBundle::fillAndFrame );
}

/********************************************************/
SCGeneralizationSymbol::~SCGeneralizationSymbol()
/********************************************************/
{
}

/********************************************************/
SCGeneralizationSymbol& SCGeneralizationSymbol::determineLayout()
/********************************************************/
{
   const SCClassSymbol *pSuperSymbol = parentSymbol();
   const SCClassSymbol *pSubSymbol   = childSymbol();

   /*
    *   left      | flush |    right
    *             |       |
    *                                  above
    *       ----- ********* ------
    *             *       *              flush
    *       ----- ********* ------
    *                                  below
    */

   int xSuperLeft   = pSuperSymbol->xPosition();
   int xSuperCenter = pSuperSymbol->xPosition()
                             + 0.5 * pSuperSymbol->xSize();
   int xSuperRight = pSuperSymbol->xPosition()
                             + pSuperSymbol->xSize();
   int ySuperBottom = pSuperSymbol->yPosition();
   int ySuperCenter = pSuperSymbol->yPosition()
                             + 0.5 * pSuperSymbol->ySize();
   int ySuperTop    = pSuperSymbol->yPosition()
                             + pSuperSymbol->ySize();
 
   int xSubLeft = pSubSymbol->xPosition();
   int xSubCenter = pSubSymbol->xPosition()
                             + 0.5 * pSubSymbol->xSize();
   int xSubRight = pSubSymbol->xPosition()
                             + pSubSymbol->xSize();
   int ySubBottom = pSubSymbol->yPosition();
   int ySubCenter = pSubSymbol->yPosition()
                             + 0.5 * pSubSymbol->ySize();
   int ySubTop    = pSubSymbol->yPosition()
                             + pSubSymbol->ySize();

   int xBegin, yBegin, xEnd, yEnd;

   if (xSubRight < xSuperLeft) { // to the left
      if (ySubTop < ySuperBottom) {  // below left
          xBegin = xSubCenter;
          yBegin = ySubTop;
          xEnd   = xSuperCenter;
          yEnd   = ySuperBottom;
      } else if (ySubBottom > ySuperTop) { // above left
          xBegin = xSubCenter;
          yBegin = ySubBottom;
          xEnd   = xSuperCenter;
          yEnd   = ySuperTop;
      } else { // flush left
          xBegin = xSubRight;
          yBegin = ySubCenter;
          xEnd   = xSuperLeft;
          yEnd   = ySuperCenter;
      } /* endif */
   } else if (xSubLeft > xSuperRight) { // to the right
      if (ySubTop < ySuperBottom) {  // below right
          xBegin = xSubCenter;
          yBegin = ySubTop;
          xEnd   = xSuperCenter;
          yEnd   = ySuperBottom;
      } else if (ySubBottom > ySuperTop) { // above right
          xBegin = xSubCenter;
          yBegin = ySubBottom;
          xEnd   = xSuperCenter;
          yEnd   = ySuperTop;
      } else { // flush right
          xBegin = xSubLeft;
          yBegin = ySubCenter;
          xEnd   = xSuperRight;
          yEnd   = ySuperCenter;
      } /* endif */
   } else {  // flush above or below
      if (ySubTop < ySuperBottom) {  // flush below
          xBegin = xSubCenter;
          yBegin = ySubTop;
          xEnd   = xSuperCenter;
          yEnd   = ySuperBottom;
      } else if (ySubBottom > ySuperTop) { // flush above
          xBegin = xSubCenter;
          yBegin = ySubBottom;
          xEnd   = xSuperCenter;
          yEnd   = ySuperTop;
      } else { // flush flush === > overlap !!
          xBegin = xSubLeft;
          yBegin = ySubCenter;
          xEnd   = xSuperRight;
          yEnd   = ySuperCenter;
      } /* endif */
   } /* endif */

   setShape(IPoint(xBegin, yBegin), IPoint(xEnd, yEnd));

  return *this;
}

/********************************************************/
const SCClassSymbol * SCGeneralizationSymbol::parentSymbol() const
/********************************************************/
{
   return iParentSymbol;
}

/********************************************************/
const SCClassSymbol * SCGeneralizationSymbol::childSymbol() const
/********************************************************/
{
   return iChildSymbol;
}

/********************************************************/
SCGeneralizationSymbol& SCGeneralizationSymbol::buildGraphics()
/********************************************************/
{
   removeAll();

   setGraphicBundle( bundle );

   int xBegin  = xPosition();
   int xEnd    = xBegin + xSize();
   int yBegin  = yPosition();
   int yEnd    = yBegin + ySize();

   addAsLast(*new IGLine(IPoint(xBegin, yBegin), IPoint(xEnd, yEnd)));

   IGPolygon *pArrow = new IGPolygon(IPointArray());
   pArrow->addPoint(IPoint(xEnd + ARROW_LENGTH,  yEnd + ARROW_WIDTH/2)); 
   pArrow->addPoint(IPoint(xEnd,  yEnd)); 
   pArrow->addPoint(IPoint(xEnd + ARROW_LENGTH,  yEnd - ARROW_WIDTH/2));
   pArrow->rotateBy( 
         angleFromPoints(
             IPoint(xEnd, yEnd), IPoint(xBegin, yBegin)),
         IPoint(xEnd,yEnd) );

   addAsLast(*pArrow);

   return *this;
}

