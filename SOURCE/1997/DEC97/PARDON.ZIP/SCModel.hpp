/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#include <istring.hpp>

class SCClass {
public:
   SCClass(const char * const aName)
     : iName(aName) { }
   ~SCClass() { };
   IString name() const { return iName; }
   SCClass& setName (const IString& newValue)
       { iName = newValue; return *this; }
private:
   IString iName;
};

class SCGeneralization {
public:
   SCGeneralization(const SCClass& parent, const SCClass& child)
     : pParent(&parent), pChild(&child)  { }
   ~SCGeneralization() { }
private:
   const SCClass *pParent;
   const SCClass *pChild;
};
