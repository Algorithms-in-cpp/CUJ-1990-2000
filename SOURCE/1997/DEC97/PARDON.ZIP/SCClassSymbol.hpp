/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#ifndef _SCClassSymbol_Included__
   #define _SCClassSymbol_Included__

#ifndef _SCElementView_Included__
   #include "SCElementView.hpp"
#endif

class SCClass;

class _Export SCClassSymbol : public SCElementView {
public:
   SCClassSymbol(const SCClass& aClass);
   virtual ~SCClassSymbol();
   virtual SCClassSymbol& determineLayout();
   virtual SCClassSymbol& buildGraphics();

   const SCClass * _class() const;
   IBoolean isMoveable() const;
   IString name() const;
private:
   const SCClass *iClass;
   static IGraphicBundle bundle;
   static const double CLASSNAME_PORTION;
   static const int CLASSNAME_MARGIN;
   static const double CLASSMETHOD_PORTION;
};

#endif // _SCClassSymbol_Included__
