/********************************************/
SCClassSymbol& SCClassSymbol::buildGraphics()
/********************************************/
{
  removeAll();

  setGraphicBundle( bundle );

  int xLeft    = xPosition();
  int xRight   = xLeft + xSize();
  int yBottom  = yPosition();
  int yTop     = yBottom + ySize();

  IGRectangle *pBox = new IGRectangle(IRectangle(
                               IPoint(xLeft, yBottom), 
                               ISize(xSize(), ySize())));

  addAsFirst(*pBox);

  int yAttrTop = yTop - CLASSNAME_PORTION * ySize();
  addAsLast(* (new IGLine(IPoint(xLeft, yAttrTop), 
                          IPoint(xRight, yAttrTop))));

  IGString *pName = new IGString(name(), 
                             IPoint(xLeft + CLASSNAME_MARGIN,
                                    yAttrTop + CLASSNAME_MARGIN),
                             IFont());
  addAsLast(*pName);

  int yMethTop = yBottom + CLASSMETHOD_PORTION * ySize();
  addAsLast(*new IGLine(
                         IPoint(xLeft, yMethTop), 
                         IPoint(xRight, yMethTop)));
  return *this;
}
