/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#include <iwindow.hpp>
#include <iapp.hpp>
#include <imsgbox.hpp>

#ifdef SC_SHOW_BUG
  #include <icoordsy.hpp>
#endif

#include "SCMainWindow.hpp"


//*************************************************************************
// main  - Application entry point                                        *
//*************************************************************************
int main(int argc, char ** argv)
{
#ifdef SC_SHOW_BUG
   ICoordinateSystem::setApplicationOrientation(
          ICoordinateSystem::originLowerLeft);
#endif
   IApplication::current().setArgs(argc, argv);

   SCMainWindow *iPart;
   IMessageBox::Response resp = IMessageBox::unknown;

   do {
      try {
         iPart = new SCMainWindow();
         iPart->initializePart();
         }
      catch (IException& exc) { 
         resp = IMessageBox(IWindow::desktopWindow()).show(
                  exc.text(),
                  IMessageBox::retryCancelButton);
         }
      }
   while (resp == IMessageBox::retry);

   if (resp == IMessageBox::cancel) 
          IApplication::current().exit();


   iPart->setAutoDeleteObject();
   iPart->show();
   IApplication::current().run();
   return 0;

} /* end main */
