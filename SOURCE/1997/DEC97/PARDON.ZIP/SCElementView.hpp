/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#ifndef _SCElementView_Included__
   #define _SCElementView_Included__

#include <iglist.hpp>
#include <istdntfy.hpp>

class IPoint;

class _Export SCElementView : public IGList, public IStandardNotifier {
public:
   SCElementView ();
   virtual  ~SCElementView ();

   int  xPosition () const;
   int  yPosition () const;
   int  xSize () const;
   int  ySize () const;
   SCElementView& moveTo   (int newX, int newY);
   SCElementView& setShape (int newX, int newY, int newWidth, int newHeight);
   SCElementView& setShape (IPoint pos, ISize size);
   SCElementView& setShape (IPoint pos, IPoint end);

   virtual IBoolean isMoveable() const;

   virtual SCElementView& determineLayout() = 0;
   virtual SCElementView& buildGraphics() = 0;

   static INotificationId const shapeId;

   static double angleFromPoints( const IPoint& center, const IPoint& drop );
private:
   int iX, iY, iWidth, iHeight;
};

#endif // _SCElementView_Included__
