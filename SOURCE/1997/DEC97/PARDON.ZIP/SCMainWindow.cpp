/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#ifndef _IFRAME_
#include <iframe.hpp>
#endif

#ifndef _IVPORT_
#include <ivport.hpp>
#endif

#ifndef __SCDrawingArea_Included__
  #include "SCDrawingArea.hpp"
#endif

#ifndef _IRECT_
#include <irect.hpp>
#endif

#ifndef _IPOINT_
#include <ipoint.hpp>
#endif


#ifndef _INOTIFEV_
  #include <inotifev.hpp>
#endif

#ifndef _SCMAINWINDOW_
  #include "SCMainWindow.hpp"
#endif

#define WND_MAIN            0x1000         //Main Window ID

const INotificationId SCMainWindow::readyId = "SCMainWindow::readyId";

/**************************************************/
unsigned long SCMainWindow::defaultId()
/**************************************************/
{
   return(WND_MAIN);
}


/**************************************************/
const IRectangle SCMainWindow::defaultFramingSpec()
/**************************************************/
{
   return(IRectangle(IPoint(30, IWindow::desktopWindow()->size().height() - 35 - 400),ISize(400, 400)));
}


/**************************************************/
IString SCMainWindow::defaultTitle()
/**************************************************/
{
   return("Skop�s Consulting Object Designer");
}


/**************************************************/
SCMainWindow::SCMainWindow(
      unsigned long id, 
      IWindow* parent, 
      IWindow* owner, 
      const IRectangle& rect, 
      const IFrameWindow::Style& style, 
      const char* title)
/**************************************************/
   : IFrameWindow(id, parent, owner, rect, style, title)
{
   iViewPort1 = new IViewPort(
      IC_FRAME_CLIENT_ID, 
      this, 
      this, 
      IRectangle());
   iDrawing = new SCDrawingArea(
      id+1,
      iViewPort1, 
      iViewPort1, 
      IRectangle(IPoint(0,0),ISize(700, 400)));

   this->setFocus();
   this->setClient(iViewPort1);
}


/**************************************************/
SCMainWindow::~SCMainWindow()
/**************************************************/
{
   delete iViewPort1;
   delete iDrawing;
}

/**************************************************/
SCMainWindow & SCMainWindow::initializePart()
/**************************************************/
{
   makeConnections();
   notifyObservers(INotificationEvent(readyId, *this));
   return *this;
}

/**************************************************/
Boolean SCMainWindow::makeConnections()
/**************************************************/
{
   this->enableNotification();
   iViewPort1->enableNotification();
   iDrawing->enableNotification();

   return true;
}
