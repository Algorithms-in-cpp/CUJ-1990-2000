class _Export SCGeneralizationSymbol : public SCElementView {
public:
  SCGeneralizationSymbol(const SCClassSymbol& aParent,
                         const SCClassSymbol& aChild);
  virtual ~SCGeneralizationSymbol();

  virtual SCGeneralizationSymbol& determineLayout();
  virtual SCGeneralizationSymbol& buildGraphics();

  const SCClassSymbol * parentSymbol() const;
  const SCClassSymbol * childSymbol() const;
private:
  const SCClassSymbol *iParentSymbol;
  const SCClassSymbol *iChildSymbol;
  static IGraphicBundle bundle;
  static const int ARROW_LENGTH;
  static const int ARROW_WIDTH;

};
