class SCElementShapeObserver : public IObserver {
public:
   SCElementShapeObserver(SCElementView *pSource,
                          SCDrawingArea *pTarget)
   { 
       iSource = pSource; 
       iTarget = pTarget; 
       handleNotificationsFor(*iSource);
   }
   ~SCElementShapeObserver() {};
protected:
  IObserver& dispatchNotificationEvent (
               const INotificationEvent& anEvent)
  {
      if (anEvent.notificationId() == SCElementView::shapeId) {
            iTarget->prepareGraphic(*iSource);
      } 
      return *this;
  }
  SCElementView *iSource;
  SCDrawingArea *iTarget;
};
