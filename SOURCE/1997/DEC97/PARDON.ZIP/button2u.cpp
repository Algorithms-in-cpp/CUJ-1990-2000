/*************************************************************/
SCDrawingArea& SCDrawingArea::button2Up( const IPoint& point )
/*************************************************************/
{
  if (moveGraphic) {
     if ( point != startingPt) {
        moveRect.translateBy( point - previousPt );
        moveRect.drawOn( gc );
        moveRect.resetTransformMatrix();
        refresh( moveRect.boundingRect(gc).expandBy(1) );

        int xNew =
          moveGraphic->xPosition() + point.x() - startingPt.x();
        int yNew =
          moveGraphic->yPosition() + point.y() - startingPt.y();
        moveGraphic->moveTo(xNew, yNew);
     }
     moveGraphic = 0;
     capturePointer(false);
 }
 return *this;
}
