/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#ifndef _SCGeneralizationSymbol_Included__
   #define _SCGeneralizationSymbol_Included__

#ifndef _SCElementView_Included__
   #include "SCElementView.hpp"
#endif

class SCClassSymbol;

class _Export SCGeneralizationSymbol : public SCElementView {
public:
   SCGeneralizationSymbol(const SCClassSymbol& aParent, const SCClassSymbol& aChild);
   virtual ~SCGeneralizationSymbol();

   virtual SCGeneralizationSymbol& determineLayout();
   virtual SCGeneralizationSymbol& buildGraphics();

   const SCClassSymbol * parentSymbol() const;
   const SCClassSymbol * childSymbol() const;
private:
   const SCClassSymbol *iParentSymbol;
   const SCClassSymbol *iChildSymbol;
   static IGraphicBundle bundle;
   static const int ARROW_LENGTH;
   static const int ARROW_WIDTH;

};

#endif // _SCGeneralizationSymbol_Included__
