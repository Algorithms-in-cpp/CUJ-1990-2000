/**************************************************************/
SCGeneralizationSymbol& SCGeneralizationSymbol::buildGraphics()
/**************************************************************/
{
  removeAll();

  setGraphicBundle( bundle );

  int xBegin  = xPosition();
  int xEnd    = xBegin + xSize();
  int yBegin  = yPosition();
  int yEnd    = yBegin + ySize();

  addAsLast(*new IGLine(IPoint(xBegin, yBegin), IPoint(xEnd, yEnd)));

  IGPolygon *pArrow = new IGPolygon(IPointArray());
  pArrow->addPoint(IPoint(xEnd + ARROW_LENGTH,
                          yEnd + ARROW_WIDTH/2)); 
  pArrow->addPoint(IPoint(xEnd,  yEnd)); 
  pArrow->addPoint(IPoint(xEnd + ARROW_LENGTH,
                          yEnd - ARROW_WIDTH/2));
  pArrow->rotateBy( angleFromPoints(
            IPoint(xEnd, yEnd), IPoint(xBegin, yBegin)),
        IPoint(xEnd,yEnd) );

  addAsLast(*pArrow);

  return *this;
}
