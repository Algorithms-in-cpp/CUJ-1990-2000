/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 * Part of this source is taken from the sample code that comes with   *
 * the IBM VisualAge for C++ product. Therefore, use of this code is   *
 * subject to the additional restriction that you hold a valid licence *
 * to this product.                                                    *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#include <math.h>  // for angleFromPoints

#ifndef _INOTIFEV_
   #include <inotifev.hpp>   //  for OCL Notification Framework
#endif

#ifndef __SCElementView_Included_
   #include "SCElementView.hpp"   // our own class declaration
#endif

const INotificationId SCElementView::shapeId = "SCElementView::shape";

/********************************************************************/
SCElementView::SCElementView()
/********************************************************************/
   : IStandardNotifier()
   ,IGList()
   , iX(0)
   , iY(0)
   , iWidth(0)
   , iHeight(0)
{
   enableNotification();
}

/********************************************************************/
SCElementView::~SCElementView()
/********************************************************************/
{
}

/********************************************************************/
int  SCElementView::xPosition() const
/********************************************************************/
{
   return iX;
}

/********************************************************************/
int  SCElementView::yPosition() const
/********************************************************************/
{
   return iY;
}

/********************************************************************/
int  SCElementView::xSize() const
/********************************************************************/
{
   return iWidth;
}

/********************************************************************/
int  SCElementView::ySize() const
/********************************************************************/
{
   return iHeight;
}

/********************************************************************/
SCElementView& SCElementView::setShape(int newX, int newY, int newWidth, int newHeight)
/********************************************************************/
{
   // not in part file
   if (iX != newX || iY != newY || iWidth != newWidth || iHeight != newHeight)
   {
     iX = newX;
     iY = newY;
     iWidth = newWidth;
     iHeight = newHeight;
     notifyObservers(INotificationEvent(shapeId, *this));
   }
   return *this;
}

/********************************************************************/
SCElementView& SCElementView::moveTo(int newX, int newY)
/********************************************************************/
{
   setShape(newX, newY, xSize(), ySize());
   return *this;
}

/**********************************************************************/
SCElementView& SCElementView::setShape(IPoint pos, ISize size)
/**********************************************************************/
{
   setShape(pos.x(), pos.y(), size.width(), size.height());

   return *this;
}

/**********************************************************************/
SCElementView& SCElementView::setShape(IPoint begin, IPoint end)
/**********************************************************************/
{
   // size can be negative !
   setShape(begin.x(), begin.y(), end.x() - begin.x(), end.y() - begin.y());

   return *this;
}

/********************************************************************/
IBoolean SCElementView::isMoveable() const
/********************************************************************/
{
   return false;
}

/********************************************************************/
double SCElementView::angleFromPoints( const IPoint& center, const IPoint& drop )
/********************************************************************/
{
  IPoint temp;
  double angle;

  temp  = drop - center;
  angle = atan2((double)temp.y(), (double)temp.x());
  angle *= 57.295779;

  if ( angle < 0.0 )
    angle += 360.0;

  return angle;
}


