/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#ifndef __SCDrawingArea_Included__
   #define __SCDrawingArea_Included__

#include <igrafctx.hpp>
#include <idrawcv.hpp>
#include <imoushdr.hpp>
#include <imousevt.hpp>
#include <igrect.hpp>

class SCElementView;

class _Export SCDrawingArea : public IDrawingCanvas,
                   public IMouseHandler
{

public:
   SCDrawingArea(unsigned long id,
                IWindow * parent,
                IWindow * owner, 
                const IRectangle & rect = IRectangle(), 
                const IDrawingCanvas::Style & style 
                  = (IDrawingCanvas::defaultStyle() | IWindow::clipSiblings));

   virtual ~SCDrawingArea ( );

   SCDrawingArea& openDiagram();

   virtual SCElementView *selectedElement(IPoint point);
   virtual SCElementView *selectedElement();

   virtual SCDrawingArea& addAsFirst(SCElementView&);
   virtual SCDrawingArea& addAsLast (SCElementView&);


protected:
   friend class SCElementShapeObserver;
   virtual SCDrawingArea& prepareGraphic(SCElementView& graphic);

   virtual IGList * graphicList() const;  // hide it from public

   virtual Boolean
      mouseMoved           ( IMouseEvent&        event ),
      mouseClicked         ( IMouseClickEvent&   event );
#ifdef NIETMEER
      mousePointerChange   ( IMousePointerEvent& event );
#endif
   virtual SCDrawingArea
     &button1Down         ( const IPoint&       point ),
     &button1Up           ( const IPoint&       point ),
     &button1DoubleClick  ( const IPoint&       point ),
     &button2Click        ( const IPoint&       point ),
     &button2Down         ( const IPoint&       point ),
     &button2Up           ( const IPoint&       point ),
     &button2DoubleClick  ( const IPoint&       point );

private:
  IGraphicContext    gc;
  SCElementView*     moveGraphic;
  SCElementView*     selectedGraphic;
  IGRectangle        moveRect;
  IPoint             startingPt;
  IPoint             previousPt;
};

#endif
