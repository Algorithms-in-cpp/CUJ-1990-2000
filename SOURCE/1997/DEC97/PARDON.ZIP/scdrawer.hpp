class _Export SCDrawingArea : public IDrawingCanvas,
                  public IMouseHandler {
public:
  SCDrawingArea(unsigned long id, IWindow * parent,IWindow * owner,
                const IRectangle & rect = IRectangle(), 
                const IDrawingCanvas::Style & style = 
                  IDrawingCanvas::defaultStyle());

  virtual ~SCDrawingArea ( );

  SCDrawingArea& openDiagram();

  virtual SCElementView *selectedElement(IPoint point);
  virtual SCElementView *selectedElement();

  virtual SCDrawingArea& addAsFirst(SCElementView&);
  virtual SCDrawingArea& addAsLast (SCElementView&);

protected:
  virtual SCDrawingArea& prepareGraphic(SCElementView& graphic);

  virtual IGList * graphicList() const;  // hide it from "public"

  virtual Boolean
     mouseMoved           ( IMouseEvent&        event ),
     mouseClicked         ( IMouseClickEvent&   event ),
     mousePointerChange   ( IMousePointerEvent& event );

  virtual SCDrawingArea
    &button1Down         ( const IPoint& point ),
    &button1Up           ( const IPoint& point ),
    &button1DoubleClick  ( const IPoint& point ),
    &button2Click        ( const IPoint& point ),
    &button2Down         ( const IPoint& point ),
    &button2Up           ( const IPoint& point ),
    &button2DoubleClick  ( const IPoint& point );

private:
 IGraphicContext    gc;
 SCElementView*     moveGraphic;
 SCElementView*     selectedGraphic;
 IGRectangle        moveRect;
 IPoint             startingPt;
 IPoint             previousPt;
};
