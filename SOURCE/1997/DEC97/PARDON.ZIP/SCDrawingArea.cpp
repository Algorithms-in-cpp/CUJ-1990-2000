/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 * Part of this source is taken from the sample code that comes with   *
 * the IBM VisualAge for C++ product. Therefore, use of this code is   *
 * subject to the additional restriction that you hold a valid licence *
 * to this product.                                                    *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#include <ifont.hpp>
#include <inotifev.hpp>
#include <iobservr.hpp>

#include <icoordsy.hpp>

#ifndef __SCDrawingArea_Included__
   #include "SCDrawingArea.hpp"
#endif

#ifndef __SCElementView_Included__
   #include "SCElementView.hpp"
#endif
#ifndef __SCClassSymbol_Included__
   #include "SCClassSymbol.hpp"
#endif
#ifndef __SCGeneralizationSymbol_Included__
   #include "SCGeneralizationSymbol.hpp"
#endif

#include "SCModel.hpp"

#define TEXT_X_MARGIN   5
#define CLASS_DEFAULT_X_SIZE 80
#define CLASS_DEFAULT_Y_SIZE 100


/************************************************************
 * This observes the shape of any element on behalf of
 * the drawing area where it is displayed.
 * The area will:
 *  - erase the previous drawing
 *  - build the graphics for the new shape
 *  - draw the new shape
 ************************************************************/
class SCElementShapeObserver : public IObserver {
public:
    SCElementShapeObserver(SCElementView *pSource,
                            SCDrawingArea *pTarget)
    { 
        iSource = pSource; 
        iTarget = pTarget; 
        handleNotificationsFor(*iSource);
    }

    ~SCElementShapeObserver() {};
protected:
   IObserver& dispatchNotificationEvent (const INotificationEvent& anEvent)
   {
       if (anEvent.notificationId() == SCElementView::shapeId)
       {
          try {
             iTarget->prepareGraphic(*iSource);
          } /* end try */
          catch ( IException& exc ) {
          } /* end catch */
       } /* endif */
       return *this;
   }
   SCElementView *iSource;
   SCDrawingArea *iTarget;
};


/*****************************************************************
 * This observes the shape (size & position) of a class symbol
 * on behalf of those line-shaped symbols that connect to it.
 * They will adjust their position to match the change.
 *****************************************************************/

class SCClassSymbolInheritanceObserver : public IObserver {
public:
    SCClassSymbolInheritanceObserver(
                       SCClassSymbol *pSource,
                       SCGeneralizationSymbol *pTarget)
    { 
        iSource = pSource; 
        iTarget = pTarget;
        handleNotificationsFor(*iSource);
    }

    ~SCClassSymbolInheritanceObserver() {};
protected:
   IObserver& dispatchNotificationEvent (const INotificationEvent& anEvent)
   {
       if (anEvent.notificationId() == SCElementView::shapeId)
       {
          try {
             if (iTarget) {
                iTarget->determineLayout();
             } /* endif */
          } /* end try */
          catch ( IException& exc ) {
          } /* end catch */
       } /* endif */
       return *this;
   }
   SCClassSymbol *iSource;
   SCGeneralizationSymbol *iTarget;
};

//********************************************
// Constructor
//********************************************
SCDrawingArea::SCDrawingArea( unsigned long windowId, IWindow* parent,
                          IWindow* owner, const IRectangle & rect,
                          const IDrawingCanvas::Style & style)
  : IDrawingCanvas( windowId, parent, owner, rect, style),
    gc(handle()), moveGraphic(0), selectedGraphic(0),
    moveRect(IRectangle()), startingPt(), previousPt()
{
  gc.setMixMode( IGraphicBundle::xor )
    .setPenColor( IColor::white )
    .setFillColor( IColor::white )
    .setDrawOperation( IGraphicBundle::frame )
    .setHitApertureSize(ISize(5,5));

  setGraphicContext( &gc );

  setGraphicList( new IGList() );

  IMouseHandler::handleEventsFor(this);

  openDiagram();
}

/**********************************************************************/
SCDrawingArea::~SCDrawingArea( )
/**********************************************************************/
{
  delete graphicList();
}

/**********************************************************************/
IGList * SCDrawingArea::graphicList() const
/**********************************************************************/
{  
   return IDrawingCanvas::graphicList(); 
}

/**********************************************************************/
SCElementView *SCDrawingArea::selectedElement()
/**********************************************************************/
{
   return selectedGraphic;
}

/**********************************************************************/
SCElementView *SCDrawingArea::selectedElement(IPoint point)
/**********************************************************************/
{
    selectedGraphic = (SCElementView *) graphicList()->topGraphicUnderPoint( point, gc );
   return selectedGraphic;
}

/**********************************************************************/
SCDrawingArea& SCDrawingArea::addAsFirst(SCElementView& graphic)
/**********************************************************************/
{
   prepareGraphic( graphic );
   graphicList()->addAsFirst(graphic);

   // make sure we stay up to date on size/position changes
   new SCElementShapeObserver(&graphic, this);

   return *this;
}

/**********************************************************************/
SCDrawingArea& SCDrawingArea::addAsLast(SCElementView& graphic)
/**********************************************************************/
{
   prepareGraphic( graphic );
   graphicList()->addAsLast(graphic);

   // make sure we stay up to date on size/position changes
   new SCElementShapeObserver(&graphic, this);

   return *this;
}

/**********************************************************************/
SCDrawingArea& SCDrawingArea::prepareGraphic(SCElementView& graphic)
/**********************************************************************/
{
   // erase previous graphics, if any
   refresh( graphic.boundingRect(gc).expandBy(1) );

   graphic.buildGraphics();

   refresh(graphic.boundingRect(gc).expandBy(1));

   return *this;
}

/*------------------------------------------------------------------------------
| SCDrawingArea::mouseClicked                                                    |
|                                                                              |
------------------------------------------------------------------------------*/
/**********************************************************************/
Boolean SCDrawingArea::mouseClicked( IMouseClickEvent& event )
/**********************************************************************/
{
  /*
   * Analyze the mouse click events.
   */
  Boolean bRc = false;
  if ( event.mouseButton() == IMouseClickEvent::button1 &&
       event.mouseAction() == IMouseClickEvent::down )
  {
    button1Down(event.mousePosition());
    bRc = false;
  }
  else if ( event.mouseButton() == IMouseClickEvent::button1 &&
            event.mouseAction() == IMouseClickEvent::up )
  {
    button1Up(event.mousePosition());
    bRc = true;
  }
  else if ( event.mouseButton() == IMouseClickEvent::button1 &&
            event.mouseAction() == IMouseClickEvent::doubleClick )
  {
    button1DoubleClick(event.mousePosition());
    bRc = true;
  }
  else if ( event.mouseButton() == IMouseClickEvent::button2 &&
            event.mouseAction() == IMouseClickEvent::click )
  {
    button2Click(event.mousePosition());
  }
  else if ( event.mouseButton() == IMouseClickEvent::button2 &&
            event.mouseAction() == IMouseClickEvent::down )
  {
    button2Down(event.mousePosition());
  }
  else if ( event.mouseButton() == IMouseClickEvent::button2 &&
            event.mouseAction() == IMouseClickEvent::up )
  {
    button2Up(event.mousePosition());
  }

  return bRc;
}


/*------------------------------------------------------------------------------
| SCDrawingArea::mouseMoved                                                      |
|                                                                              |
| Handle button 1 down mouse move events.  This allows data points to be       |
| moved while the object is drawn with a rubber band effect.                   |
------------------------------------------------------------------------------*/
/**********************************************************************/
Boolean SCDrawingArea::mouseMoved( IMouseEvent& event )
/**********************************************************************/
{
  IPoint point(event.mousePosition());
  if ( hasPointerCaptured() )
  {
    IRectangle windowRect(this->rect());
    windowRect.moveTo(IPoint(0,0));
    if (!windowRect.contains(point))
    {
      if ((short)point.x() < (short)windowRect.left())
        point.setX(windowRect.left());
      else if ((short)point.x() > (short)windowRect.right())
        point.setX(windowRect.right());
      else if ((short)point.y() < (short)windowRect.bottom())
        point.setY(windowRect.bottom());
      else if ((short)point.y() > (short)windowRect.top())
        point.setY(windowRect.top());

      IPoint mapPt( IWindow::mapPoint( point,
                                       this->handle(),
                                       IWindow::desktopWindow()->handle()));

      IWindow::movePointerTo( mapPt );
    }
  }

  // If we're moving an object
  if (moveGraphic)
  {
    moveRect.drawOn( gc );
    moveRect.translateBy( point - previousPt );
    moveRect.drawOn( gc );
    previousPt = point;
  }
  return false;
}

/*
 **************************************************************
 * The next routines handle the mouse button clicks.
 * Here, only the drag operation is acted upon
 **************************************************************
 */

/**********************************************************************/
SCDrawingArea& SCDrawingArea::button1Up( const IPoint& point )
/**********************************************************************/
{
  return *this;
}

/**********************************************************************/
SCDrawingArea& SCDrawingArea::button1Down( const IPoint& point )
/**********************************************************************/
{
  return *this;
}

/**********************************************************************/
SCDrawingArea& SCDrawingArea::button1DoubleClick( const IPoint& point )
/**********************************************************************/
{
  return *this;
}

/**********************************************************************/
SCDrawingArea& SCDrawingArea::button2Down( const IPoint& point )
/**********************************************************************/
{
   moveGraphic = selectedElement( point );
   if ( moveGraphic )
   {
      if (moveGraphic->isMoveable()) {
         moveRect.setEnclosingRect(moveGraphic->boundingRect( gc ));
         previousPt = point;
         startingPt = point;
         capturePointer();
      } else {
         moveGraphic = 0;
      }
   }
   return *this;
}

/**********************************************************************/
SCDrawingArea& SCDrawingArea::button2Up( const IPoint& point )
/**********************************************************************/
{
   if (moveGraphic)
   {
      if ( point != startingPt) 
      {
         moveRect.translateBy( point - previousPt );
         moveRect.drawOn( gc );
         moveRect.resetTransformMatrix();
         this->refresh( moveRect.boundingRect(gc).expandBy(1) );
 
         int xNew = moveGraphic->xPosition() + point.x() - startingPt.x();
         int yNew = moveGraphic->yPosition() + point.y() - startingPt.y();

         moveGraphic->moveTo(xNew, yNew);

      } /* endif point != startingPt*/

      moveGraphic = 0;
      capturePointer(false);

  } /* endif moveGraphic */

  return *this;
}

/**********************************************************************/
SCDrawingArea& SCDrawingArea::button2Click( const IPoint& point )
/**********************************************************************/
{
   if (moveGraphic)
   {
      moveGraphic = 0;
      capturePointer(false);
   } /* endif moveGraphic */

   SCElementView *pElement = selectedElement(point);
   if (pElement) {
 //     pElement->popupMenu();
   }
   return *this;
}

/**********************************************************************/
SCDrawingArea& SCDrawingArea::button2DoubleClick( const IPoint& point )
/**********************************************************************/
{
   return *this;
}

/*
 **************************************************************
 * The following routines have to do with the stub model loader
 * These should be removed or reworked in a real application
 **************************************************************
 */

/********************************************************/
static SCGeneralizationSymbol *addInheritanceSymbol(
                                   SCClassSymbol *pParentSymbol,
                                   SCClassSymbol *pChildSymbol)
/********************************************************/
{
   /*
    * Stub helper routine to build the hard-coded model
    */
   SCGeneralizationSymbol *pSym = new SCGeneralizationSymbol(*pParentSymbol, *pChildSymbol);
   pSym->determineLayout();

   // make the generalization symbol track both class symbols
   new SCClassSymbolInheritanceObserver
                              (pChildSymbol, pSym);
   new SCClassSymbolInheritanceObserver
                              (pParentSymbol, pSym);

   return pSym;
}
/********************************************************/
static SCClassSymbol *addClassSymbol(const char * const pszName,
                               int xPos, int yPos)
/********************************************************/
{
   /*
    * Stub helper routine to build the hard-coded model
    */
   SCClass *pClass = 0;
   SCClassSymbol *pClassSymbol = 0;

   pClass = new SCClass(pszName);

   pClassSymbol = new SCClassSymbol(*pClass);

   int xSize = CLASS_DEFAULT_X_SIZE;
   int ySize = CLASS_DEFAULT_Y_SIZE;
   int xTextWidth = IFont().textWidth(pClass->name()) + 2 * TEXT_X_MARGIN;
   if (xTextWidth > xSize) {
      xSize = xTextWidth;
   } /* endif */

   pClassSymbol->setShape(IPoint(xPos, yPos),ISize(xSize, ySize));

   return pClassSymbol;
}

/********************************************************/
SCDrawingArea& SCDrawingArea::openDiagram()
/********************************************************/
{
   SCClassSymbol *pPerson = 0;
   SCClassSymbol *pClassSymbol = 0;

   static int xPos[3] = { 80, 20, 120 };
   static int yPosPM[3] = { 160, 20, 20 };
   static int yPosWin[3] = { 20, 160, 160 };

   int *yPos;

   if (ICoordinateSystem::applicationOrientation()
          ==  ICoordinateSystem::originLowerLeft) {
      yPos = yPosPM;
   } else {
      yPos = yPosWin;
   }

   pClassSymbol = addClassSymbol("Person", xPos[0], yPos[0]);
   addAsLast(*pClassSymbol);

   pPerson = pClassSymbol;
   pClassSymbol = addClassSymbol("Teacher", xPos[1], yPos[1]);
   addAsLast(*pClassSymbol);
   addAsLast(*addInheritanceSymbol(pPerson, pClassSymbol));

   pClassSymbol = addClassSymbol("Student", xPos[2], yPos[2]);
   addAsLast(*pClassSymbol);
   addAsLast(*addInheritanceSymbol(pPerson, pClassSymbol));

   return *this;
}

/*
 * End of file
 */
