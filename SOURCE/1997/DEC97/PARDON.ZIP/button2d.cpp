/***************************************************************/
SCDrawingArea& SCDrawingArea::button2Down( const IPoint& point )
/***************************************************************/
{
  moveGraphic = selectedElement( point );
  if ( moveGraphic ) {
     if (moveGraphic->isMoveable()) {
        moveRect.setEnclosingRect(moveGraphic->boundingRect( gc ));
        previousPt = point;
        startingPt = point;
        capturePointer();
     } else {
        moveGraphic = 0;
     }
  }
  return *this;
}
