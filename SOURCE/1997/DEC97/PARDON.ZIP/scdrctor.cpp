SCDrawingArea::SCDrawingArea(unsigned long windowId, IWindow* parent,
                             IWindow* owner, const IRectangle & rect,
                             const IDrawingCanvas::Style & style)
 : IDrawingCanvas( windowId, parent, owner, rect),
   gc(handle()), moveGraphic(0), selectedGraphic(0),
   moveRect(IRectangle()), startingPt(), previousPt()
{

 gc.setMixMode( IGraphicBundle::xor ).setPenColor( IColor::white )
   .setFillColor( IColor::white )
   .setDrawOperation( IGraphicBundle::frame )
   .setHitApertureSize(ISize(5,5));

 setGraphicContext( &gc );
 setGraphicList( new IGList() );

 IMouseHandler::handleEventsFor(this);

 openDiagram();
}
