/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#include <igbundle.hpp>
#include <igline.hpp>
#include <igpyline.hpp>
#include <igrafctx.hpp>
#include <ifont.hpp>
#include <igrect.hpp>
#include <igstring.hpp>
#include <icoordsy.hpp>

#include "SCClassSymbol.hpp"

#include "SCModel.hpp"  // for SCClass::name()

IGraphicBundle SCClassSymbol::bundle;
const int      SCClassSymbol::CLASSNAME_MARGIN   =  5;

const double   SCClassSymbol::CLASSNAME_PORTION =  0.2;
const double   SCClassSymbol::CLASSMETHOD_PORTION = 0.4;

/********************************************************/
SCClassSymbol::SCClassSymbol(const SCClass& aClass)
/********************************************************/
  : iClass(&aClass)
{
  bundle.setPenColor(IColor::black)
               .setFillColor(IColor::yellow)
               .setMixMode(IGraphicContext::defaultMixMode())
               .setDrawOperation( IGraphicBundle::fillAndFrame );
}

/********************************************************/
SCClassSymbol::~SCClassSymbol()
/********************************************************/
{
}

/********************************************************/
SCClassSymbol& SCClassSymbol::determineLayout()
/********************************************************/
{
   return *this;
}

/********************************************************/
const SCClass * SCClassSymbol::_class() const
/********************************************************/
{
   return iClass;
}

/********************************************************************/
IString  SCClassSymbol::name() const
/********************************************************************/
{
   if (iClass) {
     return iClass->name();
   } /* endif */
   return "No Name";
}

/********************************************************/
SCClassSymbol& SCClassSymbol::buildGraphics()
/********************************************************/
{
   removeAll();

   setGraphicBundle( bundle );

   int xLeft    = xPosition();
   int xRight   = xLeft + xSize();
   int xName    = xLeft + CLASSNAME_MARGIN;      // nog_doen: centreren
   int yBottom, yTop, yAttrTop, yName, yMethTop;

   if (ICoordinateSystem::applicationOrientation()
          ==  ICoordinateSystem::originLowerLeft) {
      yBottom  = yPosition();
      yTop     = yPosition() + ySize();
      yAttrTop = yTop - CLASSNAME_PORTION * ySize();
      yName    = yAttrTop + CLASSNAME_MARGIN;   // nog_doen: centreren
      yMethTop = yBottom + CLASSMETHOD_PORTION * ySize();
   } else {
      yBottom  = yPosition() + ySize();
      yTop     = yPosition();
      yAttrTop = yTop + CLASSNAME_PORTION * ySize();
      yName    = yTop + CLASSNAME_MARGIN;  // nog_doen: centreren
      yMethTop = yBottom - CLASSMETHOD_PORTION * ySize();
   }

   IGRectangle *pBox = new IGRectangle(IRectangle(
                                IPoint(xPosition(), yPosition()),
                                ISize(xSize(), ySize())));

   addAsFirst(*pBox);

   addAsLast(* (new IGLine(
                          IPoint(xLeft, yAttrTop), 
                          IPoint(xRight, yAttrTop))));


   IGString *pName = new IGString(name(), IPoint(xName, yName), IFont());
   addAsLast(*pName);

   addAsLast(*new IGLine(
                          IPoint(xLeft, yMethTop), 
                          IPoint(xRight, yMethTop)));

   return *this;
}

/********************************************************************/
IBoolean SCClassSymbol::isMoveable() const
/********************************************************************/
{
   return true;
}


