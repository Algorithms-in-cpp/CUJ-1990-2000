/***********************************************************************
 * Copyright Skopos Consulting, 1997                                   *
 * All rights reserved.                                                *
 *                                                                     *
 * Use of this source for private, non-commercial purposes             *
 * is herewith granted. For any other use you have to request          *
 * our written approval first.                                         *
 *                                                                     *
 * Redistribution is allowed, provided that all the sources in this    *
 * package are redistributed together, in their entirety and unaltered.*
 ***********************************************************************/
#ifndef _SCMAINWINDOW_
#define _SCMAINWINDOW_  


#ifndef _IFRAME_
#include <iframe.hpp>
#endif

#ifndef _IRECT_
#include <irect.hpp>
#endif

#ifndef _ISTRING_
#include <istring.hpp>
#endif

class SCMainWindow;
class IViewPort;
class SCDrawingArea;


class SCMainWindow : public IFrameWindow {
public:
   SCMainWindow(
      unsigned long id = defaultId(),
      IWindow* parent = IWindow::desktopWindow(),
      IWindow* owner = 0,
      const IRectangle& rect = defaultFramingSpec(),
      const IFrameWindow::Style& style = IFrameWindow::defaultStyle ( ),
      const char* title = defaultTitle());

   virtual  ~SCMainWindow();

   static unsigned long defaultId();
   static const IRectangle defaultFramingSpec();
   static IString defaultTitle();
   virtual SCMainWindow & initializePart();
   SCMainWindow * getFrameWindow() { return this; };

   static const INotificationId readyId;

protected:
   Boolean makeConnections();

private:
   IViewPort * iViewPort1;
   SCDrawingArea * iDrawing;


};

#endif
