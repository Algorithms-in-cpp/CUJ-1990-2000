// pfxxcept.h
#include "xcept.h"

using std::exception;
using std::string;

class PFX_Exception : public exception
{
public:
    PFX_Exception(int cod, const string& msg = "")
        : exception(s_ErrorStrings[cod] + ":" +  msg)
    {}
    enum {BAD_OBJ_ID, CONNECT_ERROR, RECORDSET_ERROR,
          REQUERY_ERROR, UPDATE_ERROR, LOCK_ERROR,
          VERSION_ERROR, TRANS_ERROR, READ_ONLY_ERROR,
          INIFILE_ERROR,
          NUM_ERRORS};

private:
    static string s_ErrorStrings[NUM_ERRORS];
};
