// unexpect.cpp
#include <iostream>
#include <except.h>
#include <stdlib.h>

main()
{
    void f() throw();
    void handler();
    
    set_unexpected(handler);
    f();
}

void f() throw()
{
    throw 1;
}

void handler()
{
    cout << "Detected unexpected exception\n";
    exit(EXIT_FAILURE);
}

// Output:
Detected unexpected exception
