// xcept.h:	Useful throw macros

#include <exception>
#include <string>

// Macro trick to quote a number:
#define str_(x) #x
#define xstr_(x) str_(x)

// Macro for convenient exception throwing
// (includes standard message, file, line #)
#define Throw(Type, cod) \
throw Type ## _Exception(Type ## _Exception:: ## cod, \
                         std::string(__FILE__ ## ":Line "
                         ## xstr_(__LINE__)))

#define Throw2(Type, cod, txt) \
throw Type ## _Exception(Type ## _Exception:: ## cod, \
                         txt + std::string(":" ## \
                         __FILE__ ## ":Line " ## \
                         xstr_(__LINE__)))
