// destroy3.cpp
#include <stdio.h>

main()
{
    void f(const char*);
    try
    {
        f("destroy3.cpp");
    }
    catch(int)
    {
        puts("Caught exception");
    }
}

void f(const char* fname)
{
    FILE* fp = fopen(fname,"r");
    if (fp)
    {
        throw 1;
        fclose(fp);     // This won't happen
    }
}

// Output:
Caught exception
