// pfxxcept.cpp

#include "pfxxcept.h"

string
PFX_Exception::s_ErrorStrings[NUM_ERRORS] =
{
    "Bad Objid",
    "Connection open failed",
    "Recordset open failed",
    "Recordset requery failed",
    "Recordset update failed",
    "Record lock failed",
    "Object out of date with database",
    "Transaction error",
    "Attempt to Write a ReadOnly object",
    "INI File name missing"
}; 
