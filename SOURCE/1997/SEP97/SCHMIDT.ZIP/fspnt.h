[Caption: Listing 2 -- <f>auto_pointer<d> using free store]


template<class t>
class auto_free_store_pointer : public auto_pointer
    {
public:
    ~auto_free_store_pointer();
    auto_free_store_pointer(t * = NULL);
    auto_free_store_pointer(const auto_free_store_pointer &);
private:
    auto_free_store_pointer(void *);
    };
