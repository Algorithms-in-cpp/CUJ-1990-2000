#if !defined INC_auto_heap_pointer
    #define  INC_auto_heap_pointer

#define AUTO_POINTER auto_heap_pointer

#include "auto_pointer.h"

template<class t>
inline void AUTO_POINTER<t>::~AUTO_POINTER()
    {
    if (is_owner_)
        delete pointer_;
    }

#undef AUTO_POINTER

#endif // !defined INC_auto_heap_pointer
