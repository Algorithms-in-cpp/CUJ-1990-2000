template<class t>
class auto_heap_pointer : public auto_pointer
    {
public:
    ~auto_heap_pointer();
    auto_heap_pointer(t * = NULL);
    auto_heap_pointer(const auto_heap_pointer &);
private:
    auto_heap_pointer(void *);
    };
