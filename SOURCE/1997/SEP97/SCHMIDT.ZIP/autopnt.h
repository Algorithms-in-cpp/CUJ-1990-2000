[Caption: Listing 1 -- <f>auto_pointer<d> base class]

template<class t>
class auto_pointer
    {
public:
    operator t *() const;
    t **operator&();
    t * const *operator&() const;
    t& operator*() const;
    t* operator->() const;
    t* release() const;
protected:
    virtual ~auto_pointer() = 0;
    auto_pointer(t * = NULL);
    auto_pointer(const auto_pointer &);
    auto_pointer
        &operator=(const auto_pointer &);
private:
    operator void *() const;
    t &operator[](size_t) const;
    mutable bool is_owner_;
    t *pointer_;
    };
