#if !defined INC_auto_free_store_pointer
    #define  INC_auto_free_store_pointer

#define AUTO_POINTER auto_free_store_pointer

#include "auto_pointer.h"

template<class t>
inline void AUTO_POINTER<t>::~AUTO_POINTER()
    {
    if (is_owner_ && pointer_ != NULL)
        free(pointer_);
    }

#undef AUTO_POINTER

#endif // !defined INC_auto_free_store_pointer
