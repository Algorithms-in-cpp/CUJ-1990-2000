// lib.h

inline
char const *foo()
    {
    return "function";
    }

