#include <iostream>
#include "lib.h"

using namespace std;

class foo
    {
public:
    foo();
    operator char const *() const;
    };

foo::foo()
    {
    }

foo::operator char const *() const
    {
    return "class";
    }

int main()
    {
    char const *p;
    p = foo();
    cout << p << '\n';
    return 0;
    }
