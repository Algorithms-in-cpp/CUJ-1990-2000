#include "stdafx.h"
#include "wininet.h"
#include "internet.h"
     
#define AGENT_NAME "MyBrowser1.0"
     
     
CInternet::CInternet()
{
 DWORD dwError;
 // Initialize the Win32 Internet functions 
 m_hSession = ::InternetOpen(AGENT_NAME, 
    INTERNET_OPEN_TYPE_PRECONFIG, // Use registry settings. 
    NULL, // Proxy name. NULL indicates use default.
    NULL, // List of local servers. NULL indicates default. 
    0) ;
     
  dwError = GetLastError();
}
     
CInternet::~CInternet()
{
 // Close Win32 Internet session.
 ::InternetCloseHandle(m_hSession);
}
     
     
void CInternet::GetURL(char* szFullUrl, LPTSTR szContents,
                       int maxContentSize) 
{
 HINTERNET hHttpFile;
 char szSizeBuffer[32];
 DWORD dwLengthSizeBuffer = sizeof(szSizeBuffer); 
 DWORD dwFileSize;
 DWORD dwBytesRead;
 BOOL bSuccessful;
     
     
     
 hHttpFile = InternetOpenUrl(m_hSession, // handle to session
    szFullUrl, // Full url of file to retrieve 
    NULL, // headers, optional
    0, // header length
    0, // flags
    0 // context for callbacks
    );
     
  if (hHttpFile)
  {
   // Determine the size 
   BOOL bQuery = ::HttpQueryInfo(hHttpFile,
             HTTP_QUERY_CONTENT_LENGTH, 
             szSizeBuffer, 
             &dwLengthSizeBuffer,
             NULL) ;
   dwFileSize=atol(szSizeBuffer);
     
   BOOL bRead = ::InternetReadFile(hHttpFile, 
             szContents, 
             dwFileSize,  
             &dwBytesRead); 
   if (bRead) bSuccessful = TRUE;
     
   ::InternetCloseHandle(hHttpFile); // Close the connection.
  }
  else
  {
   // Connection failed.
   bSuccessful = FALSE;
  }
     
     
     
     
}
     
class CInternet
{
public:
 CInternet();
     
 void GetURL(LPTSTR szUrl, LPTSTR szContents, int maxContentSize);
     
private:
 HINTERNET m_hSession;
     
};
