[Caption: Listing 1 -- Failed attempt to read large file]

/* To get the text files of the books of
 * the Bible                               */
/* Filename        Nrbytes       Book      */
/* --------        -------       ----      */
/* 19pas.txt       257 790       Psalms    */
/* 65jud.txt         3 840       Judas     */
/* 64jo3.txt         1 767       John 3    */
/* 63jo2.txt         1 714       John 2    */
#include <iostream.h>
#include <alloc.h>
#include <stdio.h>
#define ul unsigned long
#define nrbytes 257790ul

void main() {
    ul i,ib,ie;
    char c, char txt [nrbytes];
    FILE *tst;
    ib=i=0;
    if((tst=fopen("19psa.txt","rt"))==NULL){
        fprintf(stderr,
            "Cannot open input file.\n"); }
    while((c=getc(tst))!=EOF)txt[i++]=c;
    fclose(tst);
    ie=i;
    printf("i=%5ld,     ib=%5ld,     ie=%5ld,"
           "    nrbytes=%5ld\n",
           i, ib, nrbytes);
    }
