// env.C

#include <cgi/tappl.h>
#include <cgi/process.h>
#include <cgi/defs.h>
#include <cgi/environ.h>

// class declaration
class EnvTest : public cgiProcessor {
public:
   virtual int process(cgiDataList& data);
};

int EnvTest::process(cgiDataList&)
{
   cgiEnvironment e;

   cout << "REQUEST_METHOD = " << e.source() << endl
        << "The browser "
        << (e.acceptsImages() ? "does" : "does not")
        << " accept images." << endl;

   if (e.source() == cgiget)
      cout << "The GET data is:" << endl
           << e.getFormInput() << endl;
   else if (e.source() == cgipost)
      cout << "The POST data length is "
           << e.getDataLength() << endl;

   return 0;
}

// main program
int main()

{
   // instantiate and run the CGI application
   cgiTApplication<EnvTest> app;
   app.run();

   return 0;
}
