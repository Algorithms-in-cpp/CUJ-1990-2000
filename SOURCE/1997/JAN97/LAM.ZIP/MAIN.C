[Caption: The main program for a CGIFramework application]

// main.C - CGIFramework main program
#include <cgi/tappl.h>
#include "myproc.h"

int main()
{
   // instantiate and run the CGI application
   cgiTApplication<myProcessor> app;
   app.run();

   return 0;
}


