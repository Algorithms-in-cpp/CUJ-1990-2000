// noparse.C

#include <cgi/tappl.h>
#include <cgi/process.h>
#include <cgi/defs.h>

// class declaration
class NoParseHdr : public cgiProcessor {
public:
   virtual int process(cgiDataList& data);
};

int NoParseHdr::process(cgiDataList&)
{
   return 1;   // fails
}

// main program
int main()

{
   // instantiate and run the CGI application
   cgiTApplication<NoParseHdr> app;
   app.run();

   return 0;
}
