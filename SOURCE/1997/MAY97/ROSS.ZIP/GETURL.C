[Caption: Listing 2 - function geturl]


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void getURL(char **argv, char *hostName,
            char *resource, int *httpPort)
{
  char buf[512];
  char *cp;

  /* parse URL from arg 1 */
  if (cp = strstr(argv[1], "//")) 
    strcpy(buf, cp+2);     /* skip protocol */
  else
    strcpy(buf, argv[1]);
  strcpy(resource, "/");
  if (cp = strchr(buf, '/'))
  { *cp = '\0';
    strcat(resource, cp+1);
  }
  strcpy(hostName, buf);
  if (cp = strchr(hostName, ':'))
  { *cp = '\0';
    *httpPort = atoi(cp+1);
  }
  
}
