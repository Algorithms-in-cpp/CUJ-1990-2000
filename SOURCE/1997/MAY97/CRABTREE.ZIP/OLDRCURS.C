void OldSchool_Recurse() {
    WIN32_FIND_DATA fd;
    HANDLE hFind=FindFirstFile("*",&fd);
    BOOL bFoundAnother=(hFind!=INVALID_HANDLE_VALUE);
    while(bFoundAnother) {
        /* begin do whatever with the file... */
        printf("%s\n",fd.cFileName);
        /* end do whatever with the file... */
        if((fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)&&
           (fd.cFileName[0]!='.')) {
            SetCurrentDirectory(fd.cFileName);
            OldSchool_Recurse();
            SetCurrentDirectory("..");
        }
        bFoundAnother=FindNextFile(hFind,&fd);
    }
    FindClose(hFind);
}
