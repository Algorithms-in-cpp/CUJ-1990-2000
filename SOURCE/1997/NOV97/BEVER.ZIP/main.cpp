//
// Main.cpp
// Sample test program
//
// To be used with article from C++ Users Journal
// Developed by Jim Beveridge, May, 1997
//

#include <stdio.h>
#include "Set.h"

int main()
{
    Set<int> set1;
    set1.Add(5);
    set1.Add(7);

    Set<int> set2;
    set2 = set1;

    Set<double> set3;
    set3.Add(3.1415927);

    printf("%d\n", set1.Lookup(4) );
    printf("%d\n", set1.Lookup(7) );

    return 0;
}
