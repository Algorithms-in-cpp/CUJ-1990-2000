        // STRUCT ctype_base
struct ctype_base : public locale::facet {
    enum _Mask {alnum = _DI|_LO|_UP|_XA, alpha = _LO|_UP|_XA,
        cntrl = _BB, digit = _DI, graph = _DI|_LO|_PU|_UP|_XA,
        lower = _LO, print = _DI|_LO|_PU|_SP|_UP|_XA|_XD,
        punct = _PU, space = _CN|_SP|_XS, upper = _UP,
        xdigit = _XD};
    _BITMASK(_Mask, mask);
    ctype_base(size_t _R = 0)
        : locale::facet(_R) {}
    ~ctype_base() {}
    };
