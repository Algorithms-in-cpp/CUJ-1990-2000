        // TEMPLATE CLASS ctype
template<class _E>
    class ctype : public ctype_base {
public:
    typedef _E char_type;
    bool is(mask _M, _E _C) const
        {return (do_is(_M, _C)); }
    const _E *is(const _E *_F, const _E *_L, mask *_V) const
        {return (do_is(_F, _L, _V)); }
    const _E *scan_is(mask _M, const _E *_F,
        const _E *_L) const
        {return (do_scan_is(_M, _F, _L)); }
    const _E *scan_not(mask _M, const _E *_F,
        const _E *_L) const
        {return (do_scan_not(_M, _F, _L)); }
    _E tolower(_E _C) const
        {return (do_tolower(_C)); }
    const _E *tolower(_E *_F, const _E *_L) const
        {return (do_tolower(_F, _L)); }
    _E toupper(_E _C) const
        {return (do_toupper(_C)); }
    const _E *toupper(_E *_F, const _E *_L) const
        {return (do_toupper(_F, _L)); }
    _E widen(char _X) const
        {return (do_widen(_X)); }
    const char *widen(const char *_F, const char *_L,
        _E *_V) const
        {return (do_widen(_F, _L, _V)); }
    char narrow(_E _C, char _D = '\0') const
        {return (do_narrow(_C, _D)); }
    const _E *narrow(const _E *_F, const _E *_L, char _D,
        char *_V) const
        {return (do_narrow(_F, _L, _D, _V)); }
    static locale::id id;
    explicit ctype(size_t _R = 0)
        : ctype_base(_R) {_Init(_Locinfo()); }
    ctype(const _Locinfo& _Lobj, size_t _R = 0)
        : ctype_base(_R) {_Init(_Lobj); }
    static size_t _CDECL _Getcat()
        {return (_X_CTYPE); }
protected:
    virtual ~ctype()
        {if (_Ctype._Delfl)
            free((void *)_Ctype._Table); }
    void _Init(const _Locinfo& _Lobj)
        {_Ctype = _Lobj._Getctype(); }
    virtual bool do_is(mask _M, _E _C) const
        {return ((_Ctype._Table[narrow(_C)] & _M) != 0); }
    virtual const _E *do_is(const _E *_F, const _E *_L,
        mask *_V) const
        {for (; _F != _L; ++_F, ++_V)
            *_V = _Ctype._Table[narrow(*_F)];
        return (_F); }
    virtual const _E *do_scan_is(mask _M, const _E *_F,
        const _E *_L) const
        {for (; _F != _L && !is(_M, *_F); ++_F)
            ;
        return (_F); }
    virtual const _E *do_scan_not(mask _M, const _E *_F,
        const _E *_L) const
        {for (; _F != _L && is(_M, *_F); ++_F)
            ;
        return (_F); }
    virtual _E do_tolower(_E _C) const
        {return (widen(_Tolower(narrow(_C), &_Ctype))); }
    virtual const _E *do_tolower(_E *_F, const _E *_L) const
        {for (; _F != _L; ++_F)
            *_F = _Tolower(*_F, &_Ctype);
        return ((const _E *)_F); }
    virtual _E do_toupper(_E _C) const
        {return (widen(_Toupper(narrow(_C), &_Ctype))); }
    virtual const _E *do_toupper(_E *_F, const _E *_L) const
        {for (; _F != _L; ++_F)
            *_F = _Toupper(*_F, &_Ctype);
        return ((const _E *)_F); }
    virtual _E do_widen(char _X) const
        {return (_WIDEN(_E, _X)); }
    virtual const char *do_widen(const char *_F, const char *_L,
        _E *_V) const
        {for (; _F != _L; ++_F, ++_V)
            *_V = _WIDEN(_E, *_F);
        return (_F); }
    virtual char do_narrow(_E _C, char) const
        {return (_NARROW(_E, _C)); }
    virtual const _E *do_narrow(const _E *_F, const _E *_L,
        char, char *_V) const
        {for (; _F != _L; ++_F, ++_V)
            *_V = _NARROW(_E, *_F);
        return (_F); }
private:
    _Locinfo::_Ctypevec _Ctype;
    };

template<class _E>
    locale::id ctype<_E>::id;
