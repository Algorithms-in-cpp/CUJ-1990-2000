        // CLASS ctype<char>
template<>
    class ctype<char> : public ctype_base {
public:
    typedef char _E;
    typedef _E char_type;
    bool is(mask _M, _E _C) const
        {return ((_Ctype._Table[(unsigned char)_C] & _M) != 0); }
    const _E *is(const _E *_F, const _E *_L, mask *_V) const
        {for (; _F != _L; ++_F, ++_V)
            *_V = _Ctype._Table[(unsigned char)*_F];
        return (_F); }
    const _E *scan_is(mask _M, const _E *_F,
        const _E *_L) const
        {for (; _F != _L && !is(_M, *_F); ++_F)
            ;
        return (_F); }
    const _E *scan_not(mask _M, const _E *_F,
        const _E *_L) const
        {for (; _F != _L && is(_M, *_F); ++_F)
            ;
        return (_F); }
    _E tolower(_E _C) const
        {return (do_tolower(_C)); }
    const _E *tolower(_E *_F, const _E *_L) const
        {return (do_tolower(_F, _L)); }
    _E toupper(_E _C) const
        {return (do_toupper(_C)); }
    const _E *toupper(_E *_F, const _E *_L) const
        {return (do_toupper(_F, _L)); }
    _E widen(char _X) const
        {return (do_widen(_X)); }
    const _E *widen(const char *_F, const char *_L, _E *_V) const
        {return (do_widen(_F, _L, _V)); }
    _E narrow(_E _C, char _D = '\0') const
        {return (do_narrow(_C, _D)); }
    const _E *narrow(const _E *_F, const _E *_L, char _D,
        char *_V) const
        {return (do_narrow(_F, _L, _D, _V)); }
    static locale::id id;
    explicit ctype(const mask *_Tab = 0, bool _Df = false,
        size_t _R = 0)
        : ctype_base(_R)
        {_Init(_Locinfo());
        if (_Ctype._Delfl)
            free((void *)_Ctype._Table), _Ctype._Delfl = false;
        if (_Tab == 0)
            _Ctype._Table = _Cltab;
        else
            _Ctype._Table = _Tab, _Ctype._Delfl = _Df; }
    ctype(const _Locinfo& _Lobj, size_t _R = 0)
        : ctype_base(_R) {_Init(_Lobj); }
    static size_t _CDECL _Getcat()
        {return (_X_CTYPE); }
    static const size_t table_size;
protected:
    virtual ~ctype()
        {if (_Ctype._Delfl)
            free((void *)_Ctype._Table); }
    void _Init(const _Locinfo& _Lobj)
        {_Ctype = _Lobj._Getctype();
        if (_Cltab == 0)
            _Cltab = _Ctype._Table, _Ctype._Delfl = false; }
    virtual _E do_tolower(_E _C) const
        {return (_Tolower((unsigned char)_C, &_Ctype)); }
    virtual const _E *do_tolower(_E *_F, const _E *_L) const
        {for (; _F != _L; ++_F)
            *_F = _Tolower(*_F, &_Ctype);
        return ((const _E *)_F); }
    virtual _E do_toupper(_E _C) const
        {return (_Toupper((unsigned char)_C, &_Ctype)); }
    virtual const _E *do_toupper(_E *_F, const _E *_L) const
        {for (; _F != _L; ++_F)
            *_F = _Toupper(*_F, &_Ctype);
        return ((const _E *)_F); }
    virtual _E do_widen(char _X) const
        {return (_X); }
    virtual const _E *do_widen(const char *_F, const char *_L,
        _E *_V) const
        {memcpy(_V, _F, _L - _F);
        return (_L); }
    virtual _E do_narrow(_E _C, char _D) const
        {return (_C); }
    virtual const _E *do_narrow(const _E *_F, const _E *_L,
        char _D, char *_V) const
        {memcpy(_V, _F, _L - _F);
        return (_L); }
    const mask *table() const throw ()
        {return (_Ctype._Table); }
    static const mask *classic_table() throw ()
        {if (_Cltab == 0)
            locale::classic();    // force locale::_Init() call
        return (_Cltab); }
private:
    _Locinfo::_Ctypevec _Ctype;
    static const mask *_Cltab;
    };

locale::id ctype<char>::id;
