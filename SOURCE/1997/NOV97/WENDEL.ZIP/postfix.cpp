int run_time::postfix(int d_idx)
{
  pt tmp = d_array[d_idx][0];

  if (d_idx + 1 < d_array_size)
    if (d_array[d_idx+1][0] == tmp) return d_idx+1;

  for (int j=d_idx-1; j>=0 && d_array[j][0] == tmp; j--);
  
  return j+1;
}
