int vector::operator<(vector &v)
{
  if (x[0][0] < v.x[0][0]) return 1;
  if (x[0][0] > v.x[0][0]) return 0;
  if (x[0][1] < v.x[0][1]) return 1;
  if (x[0][1] > v.x[0][1]) return 0;

  //  if execution reaches here then the two vectors share the same
  //  first vertex.
  //compare the angle of the two vectors with the unit vector.
  vector unit(pt(1.0,0.0,0.0),pt(0.0,0.0,0.0));

  double l_angle = angle(unit, *this);
  double r_angle = angle(unit, v);

  if (l_angle < r_angle) return 1;
  return 0;
}
