int triangulation::between(pt point, pt low, pt high)
{
  if (low[0] == high[0]) {
    if (low[1] < high[1]) {
      if (point[1] <= low[1]) return false;
      if (point[1] >= high[1]) return false;
      return true;
    } else {
      if (point[1] >= low[1]) return false;
      if (point[1] <= high[1]) return false;
      return true;
    }
  }
  if (low[0] < high[0]) {
    if (point[0] <= low[0]) return false;
    if (point[0] >= high[0]) return false;
    return true;
  } else {
    if (point[0] >= low[0]) return false;
    if (point[0] <= high[0]) return false;
    return true;
  }
}
