// destroy2.cpp
#include <iostream>
using namespace std;

class Foo
{
public:
    Foo() {cout << "Foo constructor" << endl;}
    ~Foo() {cout << "Foo destructor" << endl;}
};

main()
{
    void f();
    try         // Turn on exception handling
    {
        f();
    }
    catch(int)
    {
        cout << "Caught exception" << endl;
    }
    return 0;
}

void f()
{
    void g();
    Foo x;
    g();
}

void g()
{
    Foo x;
    throw 1;
}

// Output:
Foo constructor
Foo constructor
Foo destructor
Foo destructor
Caught exception
