// terminat.cpp
#include <iostream>
#include <exception>
#include <stdlib.h>
using namespace std;

void handler()
{
    cout << "Renegade exception!\n";
    exit(EXIT_FAILURE);
}

void f();

main()
{
    set_terminate(handler);

    try
    {
        f();
    }
    catch(long)
    {
        cerr << "caught a long" << endl;
    }
}

void f()
{
    throw 1;
}

// Output:
Renegade exception!
