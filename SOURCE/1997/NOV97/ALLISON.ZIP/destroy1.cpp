// destroy1.cpp
#include <iostream>
#include <setjmp.h>
using namespace std;

class Foo
{
public:
    Foo() {cout << "Foo constructor\n";}
    ~Foo() {cout << "Foo destructor\n";}
};

jmp_buf env;

main()
{
    void f();
    if (setjmp(env) == 0)
        f();
    else
        cout << "Returned via longjmp" << endl;
    return 0;
}

void f()
{
    void g();
    Foo x;
    g();
}

void g()
{
    Foo x;
    longjmp(env,1);
}

// Output:
Foo constructor
Foo constructor
Returned via longjmp
