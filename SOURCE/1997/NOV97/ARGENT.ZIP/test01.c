int f001()
{
 return 1; 
}
int f002()
{
 return 2; 
}
     
int main(int argc, char *argv[])
{
  int i;
     
  if ( argc > 1 )
    i = f001();
  else
    i = f002();
     
}
     
     
