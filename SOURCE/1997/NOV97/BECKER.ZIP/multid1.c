#include <strstream>
#include <iostream>
#include <iomanip>

int main()
{
    const int NUMROWS = 20;
    const int NUMCOLS = 82;
    int i;

    char **pchararray;
    pchararray = new char*[NUMROWS];
    for( i = 0; i < NUMROWS; i++ )
        pchararray[i] = new char[NUMCOLS];

    for( i = 0; i < NUMROWS; i++ )
        {
        strstream str( pchararray[i], NUMCOLS, ios::in );
        str << "Row number " << setw(2) << i << ends;
        cout << pchararray[i] << endl;
        }

    for( i = 0; i < NUMROWS; i++ )
        delete [] pchararray[i];
    delete [] pchararray;

    return 0;
}
