...

int i;
double a, b, c, d, t0, h, t, p;
double points[NUM_STEPS], col3[NUM_STEPS - 1]; 
double col4[NUM_STEPS - 2], col5[NUM_STEPS - 3];
double firstFD, secondFD, thirdFD;

    /*    Set up coefficients, step size, etc. */

a = 3.0;
b = -2.0;
c = 1.0;
d = 4.0;

t0 = 0.0;
h = 0.1;

    /*    Compute polynomial points */

for (i = 0; i < NUM_STEPS; i++) {
    t = t0 + (double)i * h;
    p = a * t * t * t + b * t * t + c * t + d;
    points[i] = p;
}

    /*    Compute colums 3, 4, and 5 */

for (i = 0; i < NUM_STEPS - 1; i++) {
    col3[i] = points[i + 1] - points[i];
}
for (i = 0; i < NUM_STEPS - 2; i++) {
    col4[i] = col3[i + 1] - col3[i];
}
for (i = 0; i < NUM_STEPS - 3; i++) {
    col5[i] = col4[i + 1] - col4[i];
}

...
