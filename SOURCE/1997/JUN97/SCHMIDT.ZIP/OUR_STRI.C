#include "our_string.h"

#include <string.h>

void construct(string * const this, const char *data)
    {
    if (data == NULL)
        {
        this->length_ = 0;
        this->data_ = NULL;
        }
    else
        {
        this->length_ = strlen(data);
        this->data_ = (char *) malloc(this->length_ + 1);
        strcpy(this->data_, data);
        }
    }

static void destruct(string * const this)
    {
    if (this->data_ != NULL)
        free(this->data_);
    }

static size_t length(const string * const this)
    {
    return this->length_;
    }

const struct string_interface_ STRING =
    {
    construct,
    destruct,
    length
    };
