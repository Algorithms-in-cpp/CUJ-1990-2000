void construct(string * const this, const char *data)
    {
    /*
     * create proxy stub boilerplate
     */
    unsigned int proxy[] =
        {
        0xE0001,
        0x0,    /* 'this' pointer */
        0x8000,
        0x0     /* member function */
        };
    proxy[1] = (unsigned int) this;
    /*
     * create 'destruct' proxy stub
     */
    proxy[3] = (unsigned int) destruct;
    this->length = malloc(sizeof proxy );
    memcpy(this->destruct, proxy, sizeof proxy);
    /*
     * create 'length' proxy stub
     */
    proxy[3] = (unsigned int) length;
    this->length = malloc(sizeof proxy);
    memcpy(this->length, proxy, sizeof proxy);
    /*
     * ... rest is same as before
     */
    }


