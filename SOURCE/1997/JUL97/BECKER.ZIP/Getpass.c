[Caption: Listing 1 -- password input with backspace handling]

char *getpass2( const char *prompt ) 
{
     static char pass[9];
     char *current = pass;
     int ch;
     printf( "%s", prompt );
     for(;;)
          {
    ch = getch();
     
    /* printable characters are part of the password */
          if( isprint(ch) )
               {
               *current++ = (char)ch;
               putch( '*' );
               }
     
    /* ENTER terminates input */
          else if( ch == '\r' )
               break;
     
    /* backspace erases previous character */
          else if( ch == '\b' && current != pass )
               {
               current--;
               putch( '\b' );
               putch( ' ' );
               putch( '\b' );
               }
     
    /* if we have eight characters we're done */
          if( current == pass+8)
               break;
          }
     *current = '\0';
     return pass;
}
     
