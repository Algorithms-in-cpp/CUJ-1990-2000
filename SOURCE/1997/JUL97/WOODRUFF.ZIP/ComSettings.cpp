// ComSettings.cpp : implementation file
//

#include "stdafx.h"
#include "GUITerm.h"
#include "ComSettings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComSettings dialog


CComSettings::CComSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CComSettings::IDD, pParent)
{
	//{{AFX_DATA_INIT(CComSettings)
	m_csBaudRate = _T("");
	m_csDataBits = _T("");
	m_bLocalEcho = FALSE;
	m_csFlowControl = _T("");
	m_csParity = _T("");
	m_csPort = _T("");
	m_csStopBits = _T("");
	m_bSendCRLF = FALSE;
	//}}AFX_DATA_INIT
}


void CComSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComSettings)
	DDX_CBString(pDX, IDC_BAUDRATE, m_csBaudRate);
	DDX_CBString(pDX, IDC_DATABITS, m_csDataBits);
	DDX_Check(pDX, IDC_ECHO, m_bLocalEcho);
	DDX_CBString(pDX, IDC_FLOWCTRL, m_csFlowControl);
	DDX_CBString(pDX, IDC_PARITY, m_csParity);
	DDX_CBString(pDX, IDC_PORT, m_csPort);
	DDX_CBString(pDX, IDC_STOPBITS, m_csStopBits);
	DDX_Check(pDX, IDC_CRLF, m_bSendCRLF);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CComSettings, CDialog)
	//{{AFX_MSG_MAP(CComSettings)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComSettings message handlers
