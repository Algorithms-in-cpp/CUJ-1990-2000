//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GUITerm.rc
//
#define IDD_ABOUTBOX                    100
#define CG_IDD_PROGRESS                 102
#define CG_IDS_PROGRESS_CAPTION         103
#define IDR_MAINFRAME                   128
#define IDR_GUITERTYPE                  129
#define IDD_SETTINGS_DLG                130
#define IDC_PORT                        1000
#define IDC_BAUDRATE                    1001
#define IDC_PARITY                      1002
#define IDC_DATABITS                    1003
#define CG_IDC_PROGDLG_PROGRESS         1003
#define IDC_STOPBITS                    1004
#define IDC_FLOWCTRL                    1005
#define CG_IDC_PROGDLG_STATUS           1005
#define IDC_ECHO                        1006
#define IDC_CRLF                        1007
#define ID_FILE_SETTINGS                32771
#define ID_FILE_CONNECT                 32772
#define ID_FILE_DISCONNECT              32773
#define ID_FILE_XSEND                   32775
#define ID_FILE_XRECEIVE                32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
