// GUITermView.h : interface of the CGUITermView class
//
/////////////////////////////////////////////////////////////////////////////

class CGUITermView : public CEditView
{
protected: // create from serialization only
	CGUITermView();
	DECLARE_DYNCREATE(CGUITermView)

// Attributes
public:
	CGUITermDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGUITermView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGUITermView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGUITermView)
	afx_msg void OnChange();
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnEditPaste();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
    // wParam = size of block, lParam = pointer to the data
    afx_msg LONG OnCommData(WPARAM wParam, LPARAM lParam);
};

#ifndef _DEBUG  // debug version in GUITermView.cpp
inline CGUITermDoc* CGUITermView::GetDocument()
   { return (CGUITermDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
