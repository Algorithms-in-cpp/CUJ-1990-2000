// ComSettings.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CComSettings dialog

class CComSettings : public CDialog
{
// Construction
public:
	CComSettings(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CComSettings)
	enum { IDD = IDD_SETTINGS_DLG };
	CString	m_csBaudRate;
	CString	m_csDataBits;
	BOOL	m_bLocalEcho;
	CString	m_csFlowControl;
	CString	m_csParity;
	CString	m_csPort;
	CString	m_csStopBits;
	BOOL	m_bSendCRLF;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComSettings)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CComSettings)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
