---------------- Listing 10: The file oswrite.c ------------

// oswrite -- ostream::write(const char *, int)
#include <ostream>

ostream& ostream::write(const char *s, int n)
	{	// put n bytes
	_TRY_IO_BEGIN
	if (!opfx() || rdbuf()->sputn(s, n) != n)
		setstate(badbit);
	osfx();
	_CATCH_IO_END
	return (*this);
	}

