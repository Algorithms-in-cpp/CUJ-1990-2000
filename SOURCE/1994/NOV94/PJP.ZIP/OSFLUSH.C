---------- Listing 9: The file osflush.c -------------------

// osflush -- ostream::flush() 
#include <ostream> 
 
ostream& ostream::flush() 
	{	// drain any buffered output 
	_TRY_IO_BEGIN 
	if (good() && rdbuf()->pubsync() == EOF) 
		setstate(badbit); 
	_CATCH_IO_END 
	return (*this); 
	}


