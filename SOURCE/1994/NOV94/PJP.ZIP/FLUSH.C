----------------- Listing 13: The file flush.c ----------------

// flush -- flush(ostream&)
#include <ostream>

ostream& flush(ostream& os)
	{	// flush output
	os.flush();
	return (os);
	}

