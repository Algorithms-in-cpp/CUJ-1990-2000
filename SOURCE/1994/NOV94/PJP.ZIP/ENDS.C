-------------------- Listing 12: The file ends.c --------------

// ends -- ends(ostream&)
#include <ostream>

ostream& ends(ostream& os)
	{	// terminate output string
	os.put('\0');
	return (os);
	}

