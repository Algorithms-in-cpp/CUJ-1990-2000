------------------ Listing 3: The file osipoint.c -------------

// osipoint -- ostream::operator<<(void *)
#include <ostream>

ostream& ostream::operator<<(void *x)
	{	// insert a void *
	_TRY_IO_BEGIN
	if (!opfx())
		setstate(badbit);
	else
		{	// put pieces of pointer
		const int NL = 1 +
			(sizeof (void *) - 1) / sizeof (unsigned long);
		union {
			void *pv;
			unsigned long lo[NL];
			} u;
		u.lo[NL - 1] = 0, u.pv = x;
		for (int i = 0; ; )
			{	// put ints separated by colons
			_Print("B lx", u.lo[i]);
			if (NL <= ++i)
				break;
			rdbuf()->sputc(':');
			}
		}
	osfx();
	_CATCH_IO_END
	return (*this);
	}

