------------- Listing 7: The file osistrin.c -------------

// osistring -- ostream::operator<<(const char *) 
#include <string.h> 
#include <ostream> 
 
ostream& ostream::operator<<(const char *x) 
	{	// insert a string 
	_TRY_IO_BEGIN 
	if (!opfx()) 
		setstate(badbit); 
	else 
		_Pad("   s", (char *)x, strlen(x)); 
	osfx(); 
	_CATCH_IO_END 
	return (*this); 
	}


