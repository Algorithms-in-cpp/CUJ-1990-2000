-------------------- Listing 11: The file endl.c ------------

// endl -- endl(ostream&)
#include <ostream>

ostream& endl(ostream& os)
	{	// terminate output line
	os.put('\n');
	os.flush();
	return (os);
	}


