----------------- Listing 6: The file osput.c -----------------

// osput -- ostream::put(char) 
#include <ostream> 
 
ostream& ostream::put(char ch) 
	{	// put a char 
	_TRY_IO_BEGIN 
	if (!opfx() || rdbuf()->sputc(ch) == EOF) 
		setstate(badbit); 
	osfx(); 
	_CATCH_IO_END 
	return (*this); 
	}

