------------- Listing 8: The file osistrea.c -----------------

// osistream -- ostream::operator<<(streambuf&) 
#include <ostream> 
 
ostream& ostream::operator<<(streambuf& sb) 
	{	// insert from streambuf 
	_Bool copied = 0; 
	_TRY_IO_BEGIN 
	if (opfx()) 
		{	// copy characters until failure 
		char buf[512]; 
		int n; 
		for (; 0 < (n = sb.sgetn(buf, sizeof (buf))); 
			copied = 1) 
			_TRY_BEGIN 
				if (rdbuf()->sputn(buf, n) != n) 
					break; 
			_CATCH_ALL 
				setstate(failbit); 
				_RERAISE; 
			_CATCH_END 
		} 
	if (!copied) 
		setstate(failbit); 
	osfx(); 
	_CATCH_IO_END 
	return (*this); 
	}

