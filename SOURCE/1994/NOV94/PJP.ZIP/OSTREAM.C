---------- Listing 2: The file ostream.c ----------------

// ostream -- ostream basic members
#include <ostream>

ostream::~ostream()
	{	// destruct an ostream -- DO NOTHING
	}

_Bool ostream::opfx()
	{	// setup for output
	if (good() && tie() != 0)
		tie()->flush();
	return (good());
	}

void ostream::osfx()
	{	// wrapup after output
	if (flags() & unitbuf)
		flush();
	}

