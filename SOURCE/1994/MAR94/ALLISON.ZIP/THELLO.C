
LISTING 11 - "Hello, World!" using Trigraphs
/* thello.c:    Greeting program using trigraphs */
#include <stdio.h>

main(int argc, char *argv??(??))
??<
    if (argc > 1 && argv??(0??) != NULL)
        printf("Hello, %s!??/n",argv??(1??));
    else
        printf("Hello, world!??/n");
    return 0;
??>

