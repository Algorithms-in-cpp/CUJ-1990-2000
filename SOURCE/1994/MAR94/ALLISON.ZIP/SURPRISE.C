
LISTING 7 - Preprocessed source with a surprise
main()
{
int SURPRISE! = 1, x2 = 2, x3 = 3;
printf("x1" " = %" "d" "\n",SURPRISE!);
printf("x2" " = %" "d" "\n",x2);
printf("x3" " = %" "d" "\n",x3);
return 0;
}

