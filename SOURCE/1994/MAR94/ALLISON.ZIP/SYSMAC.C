
LISTING 1 -
Prints the Pre-defined Macros /* sysmac.c:    Print system macros */

#include <stdio.h>

main()
{
    printf("__DATE__ == %s\n",__DATE__);
    printf("__FILE__ == %s\n",__FILE__);
    printf("__LINE__ == %d\n",__LINE__);
    printf("__TIME__ == %s\n",__TIME__);
    printf("__STDC__ == %d\n",__STDC__);
    return 0;
}

/* Output:
__DATE__ == Dec 18 1993
__FILE__ == sysmac.c
__LINE__ == 9
__TIME__ == 19:05:06
__STDC__ == 1
*/

