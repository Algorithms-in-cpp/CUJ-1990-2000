
Listing 2 
DEMO.C
/*  Test Program for Rom Loader */
/* Large model with some far data*/
#include <conio.h>
#include <dos.h>

char msg[15] = "Hello World\n\r";
int locint;
int directvideo=1; /*BC direct to hw*/
int far test;
int far test2=0x55aa;
int far * tptr = &test;

void main(void)
{
int far * ptr2 = &test;
test = 0x1111;
locint = test+1;
 cputs(msg);
}

