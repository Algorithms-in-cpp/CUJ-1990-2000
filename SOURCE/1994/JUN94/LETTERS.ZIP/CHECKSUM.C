@CSOURCE6 = // Short example to demonstrate principles discussed<R>
// Note : *'_ signals a Nassi-Schneidermann statement<R>
<R>
s<%-3>Sample_data *psSampleData; // pntr to sample data struct<%0><R>
int iErrCode;  // return code from sampling routine<R>
//*'_C getch - read the reply from the keyboard<R>
char cReply = getch();<R>
//*'_I Does the operator want another sample<R>
if (toupper(cReply) == 'Y') {<R>
	//*'_Y Continue, read another sample, etc<R>
	p<%-2>sSampleData = psSampleData; // init pntr to buffe<%0>r<R>
	//*'_C GetNextSample - read another sample<R>
	iErrCode = GetNextSample(psSampleData);<R>
END_if<R>
else {<R>
	//*'_N Terminate the process<R>
	iErrCode = 0;<R>
END_else<R>
//*'_Endif Does the operator want another sample<R>
//*'_CS What was the return code (from GetNextSample)<R>
switch (iErrCode) {<R>
	//*'_0 Return code = 0, finished with samples<R>
	case SMPL_DONE :<R>
	break;<R>
	//*'_1 Everything OK, store sample<R>
	case SMPL_OK :<R>
	break;<R>
	//*'_9 Default! Abort sample process<R>
	default :<R>
	break;<R>
END_switch<R>
/<%-4>/*'_Endcase What was the return code (from GetNextSample)<%0>

