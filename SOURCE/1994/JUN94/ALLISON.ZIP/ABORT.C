LISTING 11 - Intercepts the SIGABRT (abort) signal

/* abort.c:    Handle SIGABRT */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>


void abort_handler(int sig);

main()
{
    /* Install signal handler */
    if (signal(SIGABRT,abort_handler) == SIG_ERR)
        fputs("Error installing abort handler\n",stderr);

    abort();
    abort();
    return 0;
}

void abort_handler(int sig)
{
    fputs("Abort signal intercepted\n",stderr);
}

/* Output:
Abort signal intercepted
Abnormal program termination
*/

