Listing 1: An attempt at nested for loops

int main(void) {
static int ij, ik, lt, lm;
    for (ik=0;ik<3;ik++)
    for (ij=0;ij<3; ij++){
        printf("*%d %d*", ij,ik);

            for (lt=0;lt<3;lt++)
            for (lm=0;lm<3;lm++) {
            printf("/%d %d/", lm,lt);}}}
