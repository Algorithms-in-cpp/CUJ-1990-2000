
#define TEST_SUFFIX "sfx  test"

main()
{
char *sfx;  /* to check suffix for violation. */

    /* stuff deleted. */

    do {

	strcpy(buf, testin[testcase]);
	sfx = buf + strlen(buf)+1;
	strcpy(sfx, TEST_SUFFIX);

        /* tested function call return value deleted. */

	if (strcmp(buf,testout[testcase]) != 0) {
	    /* error messages deleted. */
	}
	if (strcmp(sfx, TEST_SUFFIX) != 0) {
	    /* new error messages. */
	}
    } while (not end of test data);
    /* final report deleted. */
}

