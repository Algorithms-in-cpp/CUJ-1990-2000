
	while (*from) {
	    if (blank or tab) {
		/* stuff deleted. */
	    }
	    /* its not a blank or tab now. */
	    if (*from) 
		/*  We use terminator to end outer while so
		    don't advance past it. */
		/*  We force termination after end of outer while so
		    don't copy terminator either. */
		*to++ = *from++;
	}
	*to = '\0';
	}

