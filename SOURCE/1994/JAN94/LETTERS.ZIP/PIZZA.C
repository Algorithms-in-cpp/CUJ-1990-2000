
/* pizza.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct PIZZA
{
    int key;
    char stuff[10];
};

main()
{
    struct PIZZA *myPizza = calloc(10,sizeof(struct PIZZA));
    myPizza->key = 0;
    strcpy(myPizza->stuff,"good food");
    printf("%d: %s\n",myPizza[0].key,myPizza[0].stuff);
    return 0;
}

