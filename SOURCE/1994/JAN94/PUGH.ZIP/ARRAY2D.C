#define DIM1  1
#define DIM2  1
 
typedef int INT_ARRAY_DIM2[DIM2];
 
INT_ARRAY_DIM2 array_2d[DIM1];
const INT_ARRAY_DIM2 array_2d_of_const[DIM1] = {{1}};
 
void function1 ()
{
INT_ARRAY_DIM2 *pointer_2d = array_2d;
const INT_ARRAY_DIM2 *pointer_2d_to_const_1 = array_2d_of_const;
const INT_ARRAY_DIM2 *pointer_2d_to_const_2 = array_2d;
}
