#include <stdio.h>
main()
{
    int i = 100;

    i *= 23.4;
    printf("%d\n",i);
    printf("100 * 23.4 %s 2340.0\n",
           (100 * 23.4 == 2340.0) ? "==" : "!=");
    return 0;
}

/* Output:
2339
100 * 23.4 != 2340.0
*/

