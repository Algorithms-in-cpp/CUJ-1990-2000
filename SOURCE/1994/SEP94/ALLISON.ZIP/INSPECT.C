#include <stdio.h>

void inspect(const void *ptr, size_t nbytes)
{
    int i;
    const unsigned char *p = ptr;

    for (i = 0; i < nbytes; ++i)
        printf("byte #%d: %02X\n",i,p[i]);
    putchar('\n');
}

main()
{
    char c = 'a';
    int i = 100;
    long n = 100000L;
    double pi = 3.141529;
    char s[] = "hello";

    inspect(&c,sizeof c);
    inspect(&i,sizeof i);
    inspect(&n,sizeof n);
    inspect(&pi,sizeof pi);
    inspect(s,sizeof s);
    return 0;
}

