#include <iostream.h>
#include "rational.h"

main()
{
    Rational x, y(4), z(5,7);

    x = 3;
    cout << "x == " << x << endl;
    cout << "y == " << y << endl;
    cout << "z == " << z << endl;

    cout << "x + y == " << x + y << endl;
    cout << "y - z == " << y - z << endl;
    cout << "x * 2 == " << x * 2 << endl;
    cout << "2 / y == " << 2 / y << endl;
    return 0;
}

/* Output:
x == 3 / 1
y == 4 / 1
z == 5 / 7
x + y == 7 / 1
y - z == 23 / 7
x * 2 == 6 / 1
2 / y == 1 / 2

