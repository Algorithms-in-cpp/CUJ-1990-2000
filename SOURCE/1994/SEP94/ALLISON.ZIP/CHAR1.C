/* char1.c */
#include <stdio.h>
main()
{
    char c1 = 100;
    char c2 = 200;
    char c3 = c1 + c2;

    printf("c1 == %d\n",c1);
    printf("c2 == %d\n",c2);
    printf("c3 == %d\n",c3);
    return 0;
}

/* Output:
c1 == 100
c2 == -56
c3 == 44

