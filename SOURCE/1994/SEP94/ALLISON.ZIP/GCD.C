int gcd(int x, int y)
{
    int rem;

    while (y != 0)
    {
        rem = x % y;
        x = y;
        y = rem;
    }
    return x;
}

