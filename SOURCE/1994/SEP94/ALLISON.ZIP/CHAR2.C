/* char2.c */
#include <stdio.h>
main()
{
    char c1 = 100;
    char c2 = 200;
    char c3 = c1 + c2;

    printf("c1 == 0x%X\n",c1);
    printf("c2 == 0x%X\n",c2);
    printf("c3 == 0x%X\n",c3);
    return 0;
}

/* Output:
c1 == 0x64
c2 == 0xFFC8
c3 == 0x2C
*/

