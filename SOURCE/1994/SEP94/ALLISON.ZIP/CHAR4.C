#include <stdio.h>
main()
{
    unsigned char c1 = 100;
    unsigned char c2 = 200;
    unsigned char c3 = c1 + c2;

    printf("c1 == 0x%X\n",c1);
    printf("c2 == 0x%X\n",c2);
    printf("c3 == 0x%X\n",c3);
    return 0;
}

c1 == 0x64
c2 == 0xC8
c3 == 0x2C

