#include <stdio.h>
main()
{
    unsigned char c1 = 100;
    unsigned char c2 = 200;
    unsigned char c3 = c1 + c2;

    printf("c1 == %u\n",c1);
    printf("c2 == %u\n",c2);
    printf("c3 == %u\n",c3);
    return 0;
}

/* Output:
c1 == 100
c2 == 200
c3 == 44

