#include <stdio.h>
#include <limits.h>

main()
{
    float x = ULONG_MAX;
    double y = ULONG_MAX;
    long double z = ULONG_MAX;

    printf("%f\n",x);
    printf("%f\n",y);
    printf("%Lf\n",z);
    return 0;
}

/* Output:
4294967296.000000
4294967295.000000
4294967295.000000
*/

