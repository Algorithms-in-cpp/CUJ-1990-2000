#include <iostream.h>
#include "bitstr.h"

main()
{
    bitstring b("00110");

    cout << "b == " << b << endl;
    for (int i = 0; i < b.length(); ++i)
        cout << "b[" << i << "] == " << b[i] << endl;

    b[0] = 1;
    cout << "b == " << b << endl;
    return 0;
}

/* Output:
b == 00110
b[0] == 0
b[1] == 0
b[2] == 1
b[3] == 1
b[4] == 0
b == 10110
*/

