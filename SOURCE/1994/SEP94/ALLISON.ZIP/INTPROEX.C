#include <stdio.h>

main()
{
    char x = 124;
    char y = x + x;

    printf("x == %02X\n",x);
    printf("x + x == %02X\n",x+x);
    printf("y == %02X\n\n",y);
    return 0;
}

/* Output:
x == 7C
x + x == F8
y == FFF8
*/

