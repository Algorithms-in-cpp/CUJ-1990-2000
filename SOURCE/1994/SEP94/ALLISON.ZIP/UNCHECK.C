#include <stdio.h>
#include <string.h>

class string
{
public:
    string(char *s)
      {strcpy(data = new char[strlen(s)+1], s);}
    operator char*()
      {return data;}
private:
    int dummy;
    char *data;
};


main()
{
    string s = "hello";
    printf("%s\n",(char *) s);
    printf("%s\n",s);
    return 0;
}

/* Output:
hello
(null)
*/

