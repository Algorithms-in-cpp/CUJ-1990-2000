#include <stdio.h>

void f2(int,double);

main()
{
    f1(1,3);
    f1(1.0, 3.0);

    f2(1,3);
    f2(1.0,3.0);
    f2(1.0e6,3.0e6);
    return 0;
}

f1(x,y)     /* Old-style function declaration */
int x;
double y;
{
    printf("%d, %f\n",x,y);
}

void f2(int x, double y)
{
    printf("%d, %f\n",x,y);
}

/* Output:
1, 0.000000
1, 3.000000
1, 3.000000
1, 3.000000
1, 3.000000
16960, 3000000.000000
*/

