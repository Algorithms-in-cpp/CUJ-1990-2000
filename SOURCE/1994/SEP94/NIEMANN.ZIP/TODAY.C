#include <stdio.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <io.h>
#include <dos.h>

/* return 1 if file date is today, 0 otherwise */
int main(int argc, char *argv[]) {
    int fd;
    struct ftime ftime;
    struct date stime;

    fd = open (argv[1], O_RDONLY|O_BINARY);
    if (fd == -1) return (0);
    if (getftime (fd, &ftime)) return (0);
    getdate (&stime);
    if (stime.da_year == (ftime.ft_year + 1980)
    &&  stime.da_mon == ftime.ft_month
    &&  stime.da_day == ftime.ft_day)
        return (1);
    return (0);
    }

As can be seen, today returns a 1 if the designated file is
dated today, and a 0 otherwise.  A sample invocation, from autoexec.bat,
follows:

today scandisk.log
if not errorlevel 1 scandisk /autofix /nosave /nosummary i:
