@C SOURCE 8 = /* Entry Object */<R>
<R>
#import <<Object.h>><R>
<R>
@interface Entry : Object<R>
{<R>
  double amount;<R>
  id acct;<R>
}<R>
<R>
+ new;<R>
<R>
-setAmount:(double)theAmt;<R>
-(double)getAmount;<R>
-postEntry;<R>
 .<R>
 .<R>
@end<R>
<R>
/* Entry Object */<R>
<R>
#import <<Entry.h>><R>
<R>
@implementation Entry<R>
<R>
+ new<R>
{<R>
   [super new];<R>
}<R>
-init;<R>
{<R>
  acct = [Account new];<R>
}<R>
-setAmount:(double)theAmt<R>
{<R>
   amount = theAmt;<R>
}<R>
-(double)getAmount<R>
{<R>
   return amount;<R>
}<R>
-postEntry<R>
{<R>
  [acct debitBalance:amount];<R>
  //subtract<R>
}<R>
 .<R>
@end<R>
<R>
/* main */<R>
<R>
#import <<Entry.h>><R>
<R>
main(void)<R>
{<R>
  id Check;<R>


@C SOURCE 8 =   Check = [Entry new];<R>
  [Check setAmount: 12.56];<R>
  [Check setPayee: "MediaScape"];<R>
  [Check postEntry];<R>
  // [Account postEntry: check];<R>
  .<R>
  [Check storeOn: "Entry.io"];<R>
<R>
}<R>
/* End of File */

