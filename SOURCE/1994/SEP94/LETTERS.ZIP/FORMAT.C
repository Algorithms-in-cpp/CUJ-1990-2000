#include <stdio.h>
#include <string.h> 

void FormatOutput(char *String)
 { 
  int x,c,d,i;
  char Work[20];

  x = strlen(String)-1;

  for(i=1,c=x+(x/3)+1,d=x;c>0;--c,--d,++i)
   {
    if(i%4==0) // or if(!i%4)
     { 
      *(Work+(--c)) = ',';
      i=1; 
     }
    *(Work+(c-1)) = *(String+d); 
   }
  Work[x+(x/3)+1] = '\0';
  strcpy(String,work);
 }

void main(int argc, char *argv[])
 {
  FormatOutput(argv[1]);

  printf("String format output = [ %s ]\n", argv[1]);
 }

// End of File 

