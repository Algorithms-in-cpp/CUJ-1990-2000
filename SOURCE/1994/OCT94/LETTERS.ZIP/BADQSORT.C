 // Globals
typedef struct data
// Total size = 16
     {
     int net ;
     long x ;
     long y ;
     .....
     }  DATA ;

DATA huge *p1 ;
// Used in cmp()
DATA huge *p2 ;
main()
{
     DATA huge *ptr1 ;
     // Data > 64,000k, thus DATA is huge
     DATA huge *ptr2 ;
     .....
     // Action - allocate memory for
     // 10000 structures
     ptr1 = faralloc (10000 * sizeof(DATA)) ;
     // Code that loads structures
     // from an external file
     // Now sort by net (first parm in
     // DATA struct)
     qsort((void *)ptr1, 10000,
           sizeof(DATA), cmp) ;
}

//Prototype
int cmp (const void *p11, const void *p22)
{
     p1 = (DATA HUGE *)p11 ;
     p2 = (DATA huge *)p22 ;

     // Comparison
     if (p1->net == p2->net)
         .....
     return (result_of_comparison) ;
}

// END

