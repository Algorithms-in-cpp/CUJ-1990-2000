/***************************************************************/
/*             (c) Copyright 1993 by Stan Milam                */
/*                                                             */
/***************************************************************/

date_t mkdate( struct dt *dt ) {

    date_t rv;
    int    max_day;
    int    year, month, day_of_month, day_of_year, leap_year;

    /***********************************************************/
    /* Get values from the structure into local variables.     */
    /***********************************************************/

    year         = dt -> dt_year;
    month        = dt -> dt_month;
    day_of_month = dt -> dt_mday;
    day_of_year  = dt -> dt_yday;

    /***********************************************************/
    /* Convert the year into a sequential number, but check for*/
    /* errors first.                                           */
    /***********************************************************/

    if ( year < 0 || year > 9999 ) return ( (date_t) -1);

    rv = years_to_days(year);
    leap_year = is_it_a_leap_year(year);

    /***********************************************************/
    /* Try to use the month and day of month first to get the  */
    /* number of days elpased since the beginning of the year. */
    /* Use the day of the year if we do not have the above.    */
    /* Check everything along the way.                         */
    /***********************************************************/

    if (month >= 0 && month < 12) {
        if ( day_of_month > 0 ) {
            rv += months_to_days( month + 1, leap_year );
            max_day = month_table[month];
            if ( month == 1 ) max_day += leap_year;
            if ( day_of_month <= max_day ) rv += day_of_month;
            else rv = (date_t) -1;
        }
        else if ( day_of_year >= 0 ) {
            max_day = leap_year ? 365 : 364;
            if ( day_of_year <= max_day ) rv += day_of_year + 1;
            else rv = (date_t) -1;
        }
        else rv = (date_t) -1;
    }
    else rv = (date_t) -1;
    return rv;
}

