/***************************************************************/
/*              (c) Copyright 1993 by Stan Milam               */
/*                                                             */
/***************************************************************/

struct dt *localdate( date_t *arg ) {

    date_t   day;
    unsigned year;
    static   struct dt dt;
    int      yday, mday, leapyear, month, wday;

    /***********************************************************/
    /* Make sure we are in range.  Upper limit is 31-Dec-9999. */
    /***********************************************************/

    day = *arg;
    if ( day < (date_t) 1L || day > (date_t) MAXDATE ) return NULL;

    /***********************************************************/
    /* 146097 is years_to_days(400).                           */
    /***********************************************************/

    year = (unsigned) ((day * 400L) / 146097L + 1L);
    while ( years_to_days(year + 1) < day ) year++;

    /***********************************************************/
    /* Compute the remaining values from what we know already. */
    /***********************************************************/

    leapyear = is_it_a_leap_year(year);
    mday = (int) (day - years_to_days( year )); yday = mday - 1;
    month = days_to_months( &mday, leapyear);
    wday =  (int) (day % 7L);

    /***********************************************************/
    /* Assign to our internal structure.                       */
    /***********************************************************/

    dt.dt_year = year;
    dt.dt_mday = mday;
    dt.dt_yday = yday;
    dt.dt_wday = wday;
    dt.dt_month= month;
    dt.dt_leap_year = leapyear;
    return &dt;
}
