/***************************************************************/
/*            (c) Copyright 1993 by Stan Milam                 */
/*                                                             */
/***************************************************************/

date_t date( date_t *arg ) {

    date_t rv;

    /***********************************************************/
    /* Use time_to_date() which uses the ANSI time() function  */
    /* to do the actual date conversion.                       */
    /***********************************************************/

    rv = time_to_date( time( NULL ) );

    /***********************************************************/
    /* If an argument is supplied put the value in it.         */
    /***********************************************************/

    if ( arg != NULL ) *arg = rv;
    return rv;
}

