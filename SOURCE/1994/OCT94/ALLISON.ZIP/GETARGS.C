LISTING 2
/* getargs.c:     Reads files of arguments */
#include <stdio.h>

extern char **arglist(int,char **,int *);
extern void free_arglist(int,char **);

main(int argc, char *argv[])
{
    int i, nargs;
    char **args = arglist(--argc,++argv,&nargs);

    for (i = 0; i < nargs; ++i)
        printf("%d: %s\n",i,args[i]);
    free_arglist(nargs,args);
    return 0;
}

/* Sample Execution:
c:> getargs @arg.dat
0: little
1: lamb
2: where
3: no
4: one
5: along
6: came
7: a
8: spider
9: has
10: gone
11: before
12: little
13: lamb
*/

