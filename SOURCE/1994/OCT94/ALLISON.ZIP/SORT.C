LISTING 1
/* sort.c: Sort strings */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define MAXLINES 1024

static int scomp(const void *, const void *);

main(int argc, char *argv[])
{
    int i, n;
    char *strings[MAXLINES], buf[BUFSIZ];

    if (argc > 1)
        assert(freopen(argv[1],"r",stdin));

    for (n = 0; n < MAXLINES && fgets(buf,BUFSIZ,stdin); ++n)
    {
        strings[n] = malloc(strlen(buf)+1);
        assert(strings[n]);
        strcpy(strings[n],buf);
    }

    qsort(strings, n, sizeof strings[0], scomp);

    for (i = 0; i < n; ++i)
    {
        fputs(strings[i],stdout);
        free(strings[i]);
    }
    return 0;
}

static int scomp(const void *p1, const void *p2)
{
    char *a = * (char **) p1;
    char *b = * (char **) p2;
    return strcmp(a,b);
}

