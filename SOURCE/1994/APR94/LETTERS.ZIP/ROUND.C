@CSOURCE8 = #include <<math.h>><R>
extern double round_cent (double);<R>
<R>
#define SMALLNUM .00000000001  /*super small number (100's)*/<R>
        /*(smallnum is added to a double before truncating to an integer<R>
          to ensure that a number like 5.99999999999999999 is really 
6.0)<R>
         */<R>
<R>
double round_cent (num)<R>
/*     round_cent rounds a number to the cents place (round to .01).*/<R>
double num; /*number to round*/<R>
{<R>
       double tdoub; /*temporary double*/<R>
<R>
       tdoub = num * 100.0 + .5 + SMALLNUM;   /*move num to left<R>
                                                and add .50000000001 
for rounding*/<R>
       tdoub = floor (tdoub); /*drop decimals*/<R>
       return (tdoub * .01); /*move num back to right*/<R>
}<R>
<R>
/* End of File */ 

