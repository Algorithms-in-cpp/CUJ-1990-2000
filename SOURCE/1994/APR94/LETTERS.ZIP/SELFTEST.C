@CSOURCE6.5 = #define EPROM_SIZE	0x10000<R>
<R>
unsigned char volatile	*eprom;<R>
unsigned char		sum;<R>
<R>
f<%-2>or (eprom = 0; eprom << (EPROM_SIZE - 1); ++eprom)<R>
<%0>{<R>
	sum += *eprom;<R>
}<R>
<R>
*eprom = sum;	/* RAM based debugging support */<R>
<R>
if (*eprom != sum)<R>
{<R>
	/* Failed diagnostics */<R>
}<R>
<R>
	/* Continue with other code */<R>
<R>
/* End of File */ 

