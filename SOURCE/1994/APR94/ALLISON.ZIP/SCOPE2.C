LISTING 2 - Illustrates Function and File Scope
/* scope2.c:    Illustrate function and file scope */

#include <stdio.h>

main()
{
    void f1(int);
    void f2(void);

    f1(23);
    f2();
    return 0;
}

int i = 13;

void f1(int i)
{
    for (;;)
    {
        float i = 33.0;

        printf("%f\n",i);
        goto exit;
    }

exit:
    printf("%d\n",i);
}

void f2(void)
{
    printf("%d\n",i);
}

/* Output:
33.000000
23
13
*/
