LISTING 1 - Illustrates Local Scope
/* scope1.c:    Illustrate local scope */

#include <stdio.h>

void f(int val);

main()
{
    f(1);
    return 0;
}

void f(int i)
{
    printf("i == %d\n",i);
    {
        int j = 10;
        int i = j;
        printf("i == %d\n",i);
    }
}

/* Output:
i == 1
i == 10
*/
