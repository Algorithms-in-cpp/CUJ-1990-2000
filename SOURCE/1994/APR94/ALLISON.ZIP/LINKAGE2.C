LISTING 6 -
/* linkage2.c:  Links with linkage1.c */

*** NOTE to EDITOR: This must be set in small type and perhaps
span across the page to stay intact - IT MUST NOT WRAP!
Thank you. ***

#include <stdio.h>

extern int i;               /* External Linkage */

static int j = 3;           /* Internal Linkage */

void f3(void)               /* External Linkage */
{
    printf("%d\n",i+j);
}

