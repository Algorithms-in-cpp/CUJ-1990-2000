LISTING 3 -
/* lifetime.c:  Illustrate static storage duration */

#include <stdio.h>

main()
{
    int count(void);
    int i;

    for (i = 0; i < 5; ++i)
        printf("%d\n",count());
    return 0;
}

int count(void)
{
    static int n = 0;

    return ++n;
}

/* Output:
1
2
3
4
5
*/
