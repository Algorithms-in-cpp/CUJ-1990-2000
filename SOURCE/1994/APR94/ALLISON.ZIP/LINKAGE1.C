LISTING 5 -
/* linkage1.c:  Links with linkage2.c */

*** NOTE to EDITOR: This must be set in small type and perhaps
span across the page to stay intact - IT MUST NOT WRAP!
Thank you. ***

#include <stdio.h>

static void f1(int);
static void f2(void);

main()
{
    extern void f1(int);    /* Internal Linkage */
    extern void f2(void);   /* Internal Linkage */
    extern void f3(void);   /* External Linkage */

    f1(23);
    f2();
    f3();
    return 0;
}

int i = 13;                 /* External Linkage */

static void f1(int i)       /* Internal Linkage */
{
    for (;;)
    {
        float i = 33.0;     /* No Linkage */

        printf("%f\n",i);
        goto exit;
    }

exit:                       /* No linkage */
    printf("%d\n",i);
}

static void f2(void)        /* Internal Linkage */
{
    printf("%d\n",i);
}

/* Output:
33.000000
23
13
16
*/
