#define BASE  91          /* # possible output chars */
#define FIRST_CODE  '!'   /* lowest output character */
#define MAKE_PRINT(c)  ((c)+FIRST_CODE) 

put_2_ASCII (n)
unsigned int n;
{
/* put_2_ASCII() converts the 13-bit argument to two
** characters and writes them to the output file.
*/
    unsigned int rem;
    rem = n % BASE;
    n = n / BASE;
    putc (MAKE_PRINT(n), outf);
    putc (MAKE_PRINT(rem), outf);
}
