#define BASE  91          /* # possible output chars */
#define FIRST_CODE  '!'   /* lowest output character */
#define BASEVAL(c)  ((c)-FIRST_CODE)
...
  int t = getcode();          /* get next valid char */
  int u = getcode();          /* get next valid char */
  return BASEVAL(t) * BASE + BASEVAL(u);

