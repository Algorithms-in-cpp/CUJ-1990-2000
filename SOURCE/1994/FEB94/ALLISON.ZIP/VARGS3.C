LISTING 4 - Uses the macros in stdarg.h to process a variable-length
argument list
/* vargs3.c */
#include <stdio.h>
#include <stdarg.h>

void int_string_pairs(size_t npairs,...)
{
    int n;
    char *s;
    va_list args;

    va_start(args,npairs);
    while (npairs--)
    {
        n = va_arg(args,int);
        s = va_arg(args,char *);
        printf("%d, %s\n",n,s);
    }
    va_end(args);
}

main()
{
    int_string_pairs(3,1,"one",2,"two",3,"three");
    return 0;
}
