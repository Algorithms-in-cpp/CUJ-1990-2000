LISTING 2 - Extracts integers/string argument pairs
/* vargs1.c */
#include <stdio.h>

void int_string_pairs(size_t npairs,...)
{
    int n;
    char *s;
    char *p = (char *) &npairs + sizeof npairs;

    while (npairs--)
    {
        n = *(int *) p;
        p += sizeof n;
        s = *(char **) p;
        p += sizeof s;
        printf("%d, %s\n",n,s);
    }
}

main()
{
    int_string_pairs(3,1,"one",2,"two",3,"three");
    return 0;
}

/* Output:
1, one
2, two
3, three
