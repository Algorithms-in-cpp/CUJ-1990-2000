LISTING 3 - Encapsulates the parameter extraction logic
/* vargs2.c */
#include <stdio.h>

#define first_arg(x,p) \
  p = (char *) &x + sizeof(x)
#define next_arg(p,T,x) \
  x = *(T*)p; p += sizeof(T)

void int_string_pairs(size_t npairs,...)
{
    int n;
    char *s, *p;

    first_arg(npairs,p);
    while (npairs--)
    {
        next_arg(p,int,n);
        next_arg(p,char *,s);
        printf("%d, %s\n",n,s);
    }
}

main()
{
    int_string_pairs(3,1,"one",2,"two",3,"three");
    return 0;
}
