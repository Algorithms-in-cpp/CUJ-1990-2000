LISTING 7 - Uses a va_list to populate tables

#include <stddef.h>
#include <stdarg.h>
#include "column.h"

typedef struct Table
{
    Column *columns;
    size_t num_columns;
    /* other details omitted */
} Table;

void table_put_row(Table *tp, int row, ...)
{
    if (tp);
    {
        int i;
        va_list strings;

        /* Load each column element from va_list */
        va_start(strings,row);
        for (i = 0; i < tp->num_columns; ++i)
            column_put(tp->columns[i],row,
                       va_arg(strings,char *));
        va_end(strings);
    }
}
