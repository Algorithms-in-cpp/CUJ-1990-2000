LISTING 1 - Finds the largest of n integers
/* max1.c */
#include <stdio.h>

int maxn(size_t n,...)
{
    int x;
    int *p = (int *) (&n + 1);
    int m = *p;

    while (--n)
    {
        x = *++p;
        if (x > m)
            m = x;
    }
    return m;
}

main()
{
    printf("max = %d\n",maxn(3,1,3,2));
    return 0;
}

/* Output:
max = 3
