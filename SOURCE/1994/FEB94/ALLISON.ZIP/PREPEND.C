LISTING 9 - Illustrates the use of prepend
#include <stdio.h>
#include <assert.h>

#define WIDTH 11

extern int prepend(char *, unsigned, char *);

main()
{
    char s[WIDTH+1];
    int offset = WIDTH;

    s[offset] = '\0';
    offset = prepend(s,offset,"three");
    assert(offset >= 0);
    puts(s+offset);

    offset = prepend(s,offset,"two");
    assert(offset >= 0);
    puts(s+offset);

    offset = prepend(s,offset,"one");
    assert(offset >= 0);
    puts(s+offset);
    return 0;
}

/* Output:
three
twothree
onetwothree
