#if 0  /* The following is for example and test only */
/*-E- Description of a function in a C style comment;
**      Additional formal documentation on additional lines */
/*      Multiple comments are ok. */
int foobar1(
        char *arg1,             /* first arg description */
                /* more description */
        char *arg2              /* second arg description */
        )
{
    dummy contents;
}
//-E- One line desc. of data preceded by a C++ style comment.
//      Additional formal documentation on additional lines.
double widget[5] = { 1.1, 2.2, 3.3, 4.4, 5.5 };

#endif

Sample program output from: makefun <makefun.c>:

/*This is automatically generated, not a source file! */

extern
/*-E- Description of a function in a C style comment;
**      Additional formal documentation on additional lines */
/*      Multiple comments are ok. */
int foobar1(
        char *arg1,             /* first arg description */
                /* more description */
        char *arg2              /* second arg description */
        )
;

extern
//-E- One line desc. of data preceded by a C++ style comment.
//      Additional formal documentation on additional lines.
double widget[5] ;

/*------------------ end ---------------------*/

