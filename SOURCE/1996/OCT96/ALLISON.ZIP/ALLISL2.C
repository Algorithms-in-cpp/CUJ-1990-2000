// user.c (separation style)

#define trace my_tracer
#define INCR(v) (v)++
extern int count;

template<class T> T sum(vector<T>& v);

void g(vector<int>& vi)
{
    int s = sum(vi);
}
