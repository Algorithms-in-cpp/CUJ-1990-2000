// sum.c:

#define INCR 2
void trace(void*);
static int count;

template<class T> T sum(vector<T>& v)
{
    count += INCR;
    trace(v);
    T r = 0;
    for (int i = 0; i < v.size(); i++)
        r += v[i];
}


// user.c (inclusion style)

#define trace my_tracer
#define INCR(v) (v)++
extern int count;

#include "sum.c"

void g(vector<int>& vi)
{
    int s = sum(vi);
}
