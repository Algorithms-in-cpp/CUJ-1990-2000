C_Like_Expression c2("1 + 3 == 8/2 && 0");
cout << c2.GetExp() << " => "  << c2.GetValue()<< endl << endl;

Pascal_Like_Expression p2("1 + 3 = 8/2 and 0");
cout << p2.GetExp() << " => "  << p2.GetValue()<< endl << endl;

Symbol_Table sym;
sym.Set("v1",5); sym.Set("v2",9); sym.Set("v3",32);
sym.Set("Temperature",50);

C_Like_Expression c3("Temperature*v1/v2+v3");
cout << c3.GetExp() << " => "  << c3.GetValue(sym)<< endl << endl;

C_Like_Expression c4("1 && (1==v1 || !(4-1-2-1))");
cout << c4.GetExp() << " => "  << c4.GetValue(sym)<< endl << endl;

sym.Set("TRUE",1);
Pascal_Like_Expression p4("TRUE and (1=v1 or not(4-1-2-1))");
cout << p4.GetExp() << " => "  << p4.GetValue(sym)<< endl << endl;


Output:

3. 1 + 3 == 8/2 && 0 => 0

4. 1 + 3 = 8/2 and 0 => 0

Temperature*v1/v2+v3 => 59.7778

1 && (1==v1 || !(4-1-2-1)) => 1

TRUE AND (1=v1 or NOT(4-1-2-1)) => 1
