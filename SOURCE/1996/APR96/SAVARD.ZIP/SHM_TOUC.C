/* Begin of shm_touch.c */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include "shm_pack.h"

void main(int argc, char *argv[])
{
  int    i;
  SMEM   *smd;

  if (argc == 1)
  { fprintf(stderr,"Usage: %s <key>[:size] ... \n",argv[0]);
    exit(-1);
  }

  for(i=1; i<argc; i++)
  {
    int    key;
    SMEM  *smd;

    key = atoi(argv[i]);
    smd = shm_access(key,0);
    if (smd != NULL)
      smd->time = time(NULL);
    else
    {
      char *ptr;
      int  size = 1; /* 1-byte shared memory */

      ptr = strchr(argv[i],':');
      if (ptr)
	size = atoi(&ptr[1]);

      smd = shm_create(key,"rw",size); /* create shared memory */
    }

    if (smd == NULL)
      fprintf(stderr,"Cannot create %d\n",key);
  }
}

/* End of shm_touch.c */

