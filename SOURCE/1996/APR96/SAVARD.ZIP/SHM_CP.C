/* Begin of shm_cp.c */

#include <stdio.h>
#include "shm_pack.h"

void  main(int argc, char *argv[])
{
  int    i,key;
  SMEM   *src, *dest;

  if (argc != 3)
  { fprintf(stderr,"Usage: %s <src_key> <dest_key> \n",argv[0]);
    exit(-1);
  }

  /* Check if <src_key> exists... */
  key = atoi(argv[1]);
  src = shm_access(key,0);
  if (src == NULL)
  { fprintf(stderr,"shm_cp: %d non-existent\n",key);
    exit(-1);
  }

  /* ...and <dest_key> does not*/
  key = atoi(argv[2]);
  dest = shm_access(key,0);
  if (dest != NULL)
  { fprintf(stderr,"shm_cp: cannot overwrite %d \n",key);
    exit(-1);
  }

  /* Creating <dest_key> */
  dest = shm_create(key,"rw",src->size);

  /* Copying <src_key> into <dest_key> */
  while(!shm_eosm(src))
  {
    int nBytes;
    char Buffer[BUFSIZ];

    nBytes = shm_read(Buffer,1,BUFSIZ,src);
    shm_write(Buffer,1,nBytes,dest);
  }
}

/* End of shm_cp.c */
