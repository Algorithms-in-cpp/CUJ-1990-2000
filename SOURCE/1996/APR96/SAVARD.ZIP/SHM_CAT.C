/* Begin of shm_cat.c */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "shm_pack.h"

static void shmDump(SMEM *smd)
{
  char Buffer[128];

  while(!shm_eosm(smd))
  {
    int nBytes;

    nBytes = shm_read(Buffer,1,128,smd);
    fwrite(Buffer,1,nBytes,stdout);
  }
}

void main(int argc, char *argv[])
{
  int    i;
  SMEM *smd;

  if (argc == 1)
  { fprintf(stderr,"Usage: %s <key> ... \n",argv[0]);
    exit(-1);
  }

  for(i=1; i<argc; i++)
  {
    int    key;
    SMEM *smd;

    key = atoi(argv[i]);
    smd = shm_access(key,0); /* 0 = Read only */

    if (smd == NULL)
      fprintf(stderr,"No accessible shared memory with key %d\n",key);
    else
      shmDump(smd);
  }
}

/* End of shm_cat.c */
