/* Begin of shm_rm.c */

#include <stdio.h>
#include "shm_pack.h"

void main(int argc, char *argv[])
{
  int    i;
  SMEM   *smd;

  if (argc == 1)
  { fprintf(stderr,"Usage: %s <key> ... \n",argv[0]);
    exit(-1);
  }

  for(i=1; i<argc; i++)
  {
    int    key;
    SMEM  *smd;

    key = atoi(argv[i]);
    smd = shm_access(key,0);
    if (smd == NULL)
      fprintf(stderr,"shm_rm: %d non-existent\n",key);
    else
    {
      shm_close(smd);
      shm_delete(key);
    }
  }
}

/* End of shm_rm.c */
