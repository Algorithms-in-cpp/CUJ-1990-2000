/* Begin of dummy.c */
/* These files are dummy pin & unpin functions.  They exist to avoid
 * linkage error.  If your want use the pin facilities, check the
 * appropriate function calls and libraries to link on your environment
 * (Type 'man pin' for more details)
 */

int   pin(long addr, int size) {}
int unpin(long addr, int size) {}

/* End of dummy.c */
