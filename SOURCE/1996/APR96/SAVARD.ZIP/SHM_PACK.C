/* Begin of shm_pack.c */

/**
 **  Description:
 **    shm_pack is a package which manages shared memories like a
 **    virtual file. It makes easier the manipulation of shared memories
 **    for any programmer who is familiar with file manipulation.
 **    It provides some protections to avoid to memory corrumption.
 **
 **/

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/pin.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "shm_pack.h"

#define READ_ONLY 0

/* Create a shared memory [cf: fopen(file,"w") ]
 *
 * shm_create(80,"",65536) :
 *   create a 64k shared-memory at key 80 (only owner can access)
 *
 * shm_create(80,"r",65536) :
 *   idem, but other than owner can read
 *
 * shm_create(80,"rw",65536) :
 *   idem, but other than owner can read & write
 */
SMEM *shm_create(int key, const char *mode, int size)
{
  int   addr;
  int   shmid;
  SMEM *smd = NULL;
  int   bCreate;
  struct shmid_ds shmid_d;
  int Permission;

  /* Default permission : only owner has right to read/write */
  Permission = IPC_CREAT | S_IRUSR | S_IWUSR;

  /* Search for read permission */
  if (strchr(mode,'r'))
    Permission |= S_IRGRP | S_IROTH;

  /* Search for write permission */
  if (strchr(mode,'w'))
    Permission |= S_IWGRP | S_IWOTH;

  /* Try to create shared memory */
  shmid = shmget(key,size,Permission);
  if (shmid < 0)
    return NULL;

  /* Try to attach with it */
  addr = (int)shmat(shmid,0,0);
  if (-1 == addr)
    return NULL;

  /* Set time */
  if (-1 == shmctl(shmid,IPC_STAT,&shmid_d))
    return NULL;

  shmid_d.shm_ctime = time(NULL);
  shmctl(shmid,IPC_SET,&shmid_d);

  /* Allocate & set the shared memory descriptor */
  smd = (SMEM *)malloc(sizeof(SMEM));
  smd->addr   = (void *)addr;
  smd->size   = size;
  smd->key    = key;
  smd->mode   = !(READ_ONLY);  /* Allow to write in a newly-created shmem! */
  smd->offset = 0;
  smd->tmp    = NULL;
  return smd;
}

/* Access a already-exist shared memory, either in read or
 * write mode. [cf: fopen(file,"r") ]
 */
SMEM *shm_access(int key, int mode)
{
  int   addr;
  int   shmid;
  SMEM *smd = NULL;
  int   bCreate;
  struct shmid_ds shmid_d;

  /* Try to access shared memory */
  shmid = shmget(key,0,0);
  if (shmid < 0)
    return NULL;

  /* Try to attach with it */
  addr = (int)shmat(shmid,0,0200);
  if (addr == -1)
    return NULL;

  /* Allocate & set the shared memory descriptor */
  smd = (SMEM *)malloc(sizeof(SMEM));
  smd->key    = key;
  smd->addr   = (void *)addr;
  smd->mode   = mode;
  smd->offset = 0;
  smd->tmp    = NULL;

  if (-1 == shmctl(shmid,IPC_STAT,&shmid_d))
    return NULL;

  smd->size = shmid_d.shm_segsz;
  smd->time = shmid_d.shm_ctime;
  return smd;
}

SMEM *shm_open(int key, const char *mode)
{
  SMEM *shmem;

  if (strchr(mode, 'r'))
    /* If no '+' in mode, access in read-only */
    shmem = shm_access(key, strchr(mode, '+'));
  else
  {
    /* Dont't know the size yet, so create a tmp file */
    shmem        = (SMEM *)malloc(sizeof(SMEM));
    shmem->tmp   = tmpfile();
    shmem->key   = key;
  }

  if (shmem) /* Open successfully a shmem */
    if (strchr(mode, 'p'))
    {
      shmem->pin = 1;
      pin(shmem->addr, shmem->size);
    }

  return shmem;
}


/* Read 'nElem' elements of 'nSize' size from shared memory [cf: fread() ] */
int   shm_read(void *ptr, int nSize, int nElem, SMEM *smd)
{
 char *cpRight;
 char *cpLeft;
 int  nBytes;
 int i;
 int shmid;

 /* If read from a tmp file */
 if (smd->tmp)
   return fread(ptr, nSize, nElem, smd->tmp);

 /* Return error if shared memory doesn't exist */
 shmid = shmget(smd->key,0,0);
 if (shmid < 0)
   return -1;

 /* If End-Of-Shared-Memory is reached, return 0 bytes read */
 if (smd->offset > smd->size)
   return 0;

 /* How many bytes to read */
 nBytes = nSize * nElem;

 /* Does not exceed End-Of-Shared-Memory */
 if ((smd->offset + nBytes) > smd->size)
   nBytes = (smd->size - smd->offset);

 /* left and right arguments */
 cpLeft  =  (char *)ptr;
 cpRight =  (char *)(smd->addr);
 cpRight += (smd->offset);

 /* Read the bytes (use memcpy) */
 for(i=0; i<nBytes; i++)
   cpLeft[i] = cpRight[i];

 /* Set smd->offset and return number of elements read */
 smd->offset += nBytes;
 return (nBytes/nSize);
}

/* Write 'nElem' elements of 'nSize' size into shared memory [cf: fwrite() ] */
int   shm_write(void *ptr, int nSize, int nElem, SMEM *smd)
{
 char *cpRight;
 char *cpLeft;
 int i;
 int nBytes;
 int shmid;

 /* If write into a tmp file */
 if (smd->tmp)
   return fwrite(ptr, nSize, nElem, smd->tmp);

 /* Return error if shared memory doesn't exist */
 shmid = shmget(smd->key,0,0);
 if (shmid < 0)
   return -1;

 /* Prevent writing if READ_ONLY */
 if (smd->mode == READ_ONLY)
   return 0;

 /* If End-Of-Shared-Memory is reached, return 0 bytes written */
 if (smd->offset > smd->size)
   return 0;

 /* How many bytes to write */
 nBytes = nSize * nElem;

 /* Does not exceed End-Of-Shared-Memory */
 if ((smd->offset + nBytes) > smd->size)
   nBytes = (smd->size - smd->offset);

 /* left and right arguments */
 cpLeft  = (char *)(smd->addr)+(smd->offset);
 cpRight = (char *)ptr;

 /* Writes the bytes */
 for(i=0; i<nBytes; i++)
   cpLeft[i] = cpRight[i];

 /* Set smd->offset and return number of elements written */
 smd->offset += nBytes;
 return (nBytes/nSize);
}

/* Close a shared memory [cf: fclose() ] */
int   shm_close(SMEM *smd)
{
 if (smd == NULL)
   return -1;

 if (smd->tmp)
 {
    long size;
    SMEM *new_smd;
    char buffer[BUFSIZ];

    size = ftell(smd->tmp);
    new_smd = shm_create(smd->key, "w", size);

    /* copy tmp file into shared memory */
    fseek(smd->tmp, 0, SEEK_SET);
    while (!feof(smd->tmp))
    {
      int n_item;

      n_item = fread(buffer,1,BUFSIZ,smd->tmp);
      shm_write(buffer,1,n_item,new_smd);
    }

    /* tmp file is automatically deleted */
    fclose(smd->tmp);
 }

 if (smd->pin)
   unpin(smd->addr, smd->size);

 shmdt(smd->addr);
 free(smd);
 smd = NULL;
 return 0;
}

/* Delete a shared memory [cf: unlink(file) ] */
int   shm_delete(int key)
{
  int  shmid;
  struct shmid_ds shmid_d;

  /* Try to access shared memory */
  shmid = shmget(key,0,0);
  if (shmid < 0)
    return -1;

  /* Remove the shared memory (equivalent to 'ipcrm -m shmid' ) */
  return shmctl(shmid,IPC_RMID,&shmid_d);
}

/* End of shm_pack.c */
