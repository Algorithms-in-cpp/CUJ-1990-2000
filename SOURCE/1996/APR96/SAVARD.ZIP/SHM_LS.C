/* Begin of shm_ls.c */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "shm_pack.h"

static char *execute(char *command)
{
 static char targetFile[L_tmpnam];
 char cLine[64];

 /* Generate temporary filename */
 tmpnam(targetFile);

 /* Build the command line */
 sprintf(cLine,"%s > %s\n",command,targetFile);

 /* Perform the system call */
 if (0 != system(cLine))
   return NULL;

 return targetFile;
}

static void smPrint(int key)
{
 SMEM   *smd;
 char   strTime[32];

 smd = shm_access(key,0); /* 0 = Read Only */
 if (smd == NULL)
 {
   printf("%38s\n","<No Access>");
   return;
 }

 strcpy(strTime,ctime(&smd->time));
 strTime[16] = '\0';
 printf("  %10d %s %12d\n",smd->size,&strTime[4],smd->key);

 shm_close(smd);
}

void main()
{
 FILE *fd;
 char *filename;
 char line[128];

 filename = execute("ipcs");
 fd = fopen(filename,"r");
 if (fd == NULL)
    return;

 while(!feof(fd))
 {
   fgets(line,80,fd);
   if (line[0] == 'm')
   {
     int key;

     line[19] = '\0';
     line[49] = '\0';
     printf("%s",&line[20]);
     sscanf(&line[9],"0x%x",&key);
     smPrint(key);
   }
 }

 fclose(fd);
 unlink(filename);
}

/* End of shm_ls.c */
