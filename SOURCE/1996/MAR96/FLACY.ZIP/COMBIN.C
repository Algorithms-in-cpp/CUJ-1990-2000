void combin(long n, void (* emit) (unsigned char), 
                    void (* delimit) () ) 
{
   register unsigned long comb,
                          N = n;
                          mask;
                          element,
                          two_exp_n,
/* Test that n is not too large  */
   for (comb = 1;comb <= N; comb++){
     two_exp_n = two_exp_n << 1;
     if (two_exp_n <= 0){     	
       printf("n too large for this machine.\n");
       exit(1);
     }
   }
/* For each of 2^n combinations . . .   */

   for (comb = 1;comb <= two_exp_n; comb++){
     mask = 1;
     delimit();
/* . . . emit the elements of that combination. */
     for (element = 1; element < = N; element++){
       if (mask & comb) emit((unsigned char)element);
       mask = mask << 1;
     } 
   }
}
