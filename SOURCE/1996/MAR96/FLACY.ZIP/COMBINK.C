void combink(long n, long k, void (* emit) (unsigned char), 
                             void (* delimit) () )
{
   register unsigned long comb,
                          N = n;
                          mask;
                          element,
                          counter,
                          two_exp_n,
                          K = k;
/* Test that n is not too large  */
   for (comb = 1;comb <= N; comb++){
     two_exp_n = two_exp_n << 1;
     if (two_exp_n <= 0){     	
       printf("n too large for this machine.\n");
       exit(1);
     }
   }
/* For each of 2^n combinations . . .   */
   for (comb=1;comb<=two_exp_n; comb++) {
     mask = 1;
     counter = 0;
/*  . . . count the elements . . .      */
     for (element=1;element<=N;element++) {
     if (mask & i) counter++;
     mask = mask << 1;
     } 
/* . . .  and emit them if they number exactly k  */  
     if (counter == K) {   
        mask = 1;
        delimit();

        for (element=1;element<=N;element++) {
          if (mask & comb) emit((unsigned char)element);
          mask = mask << 1;
        } 
     }
   }
}



==========================================================================
     /                (Sorry      Larry Brunelle (larryb@eecs.umich.edu)
    /   ^  /~ /~\/     for the    home phone:  (313) 971-8649
   <__ /-\/  /  /      typos.)    Box 3321   Ann Arbor, MI  48106-3321

 U of M EECS Dept., 30A ATL, 1101 Beal, Ann Arbor, MI 48109-2110  936-2830
==========================================================================
"They're so good to us, and we're so tired of it all."  - Thom McCahill
--------------------------------------------------------------------------
Opinions are mine, free, & worth it.  Your agreement, and U-M's, may vary.
==========================================================================


