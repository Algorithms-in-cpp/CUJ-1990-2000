/* ============ */
/* GetInt.c	*/
/* ============ */
#include <stdio.h>

#define	FLUSH_LINE(u)			\
    {					\
	int	x;			\
	do				\
	{				\
	    x = getc(u);		\
	}				\
	while (x != EOF && x != '\n');	\
    }
/* ==================================================== */
/* GetInt - prompts operator with s to get integer i	*/
/* ==================================================== */
# if defined(__STDC__) || defined(__PROTO__)
void
GetInt(char *s, int *i)
# else
void
GetInt(s, i)
char	*s;
int	*i;
# endif
{
    fprintf(stderr, "%s", s);

    scanf("%d", i);

    FLUSH_LINE(stdin);
}
