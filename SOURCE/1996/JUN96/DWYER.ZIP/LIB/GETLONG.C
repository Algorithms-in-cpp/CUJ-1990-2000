/* ============ */
/* GetLong.c	*/
/* ============ */
#include <stdio.h>

#define	FLUSH_LINE(u)			\
    {					\
	int	x;			\
	do				\
	{				\
	    x = getc(u);		\
	}				\
	while (x != EOF && x != '\n');	\
    }
/* ==================================================== */
/* GetLong - prompts operator with s to get long int i	*/
/* ==================================================== */
# if defined(__STDC__) || defined(__PROTO__)
void
GetLong(char *s, long *i)
# else
void
GetLong(s, i)
char	*s;
long	*i;
# endif
{
    fprintf(stderr, "%s", s);

    scanf("%ld", i);

    FLUSH_LINE(stdin);
}
