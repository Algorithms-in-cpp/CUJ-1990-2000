/* ============ */
/* tstanlz.c	*/
/* ============ */
/* ==================================================================== */
/* 		Main Program the Test AnalyzeNextPermutation		*/
/* ==================================================================== */
#include <time.h>
void
main()
{
    int     k, UniqNum;

    PRMUT_DATA_STRU  PermuteData;

    PermuteData.NumObs	    = 120;
    PermuteData.NumElements = 4;
    PermuteData.RandFun     = rand;

    srand((unsigned)time(NULL));

    for (k = 0; k < PermuteData.NumObs; ++k)
    {
	UniqNum = AnalyzeNextPermutation(&PermuteData);
	(printf("UniqNum = %4u\n", UniqNum));
    }
}
# endif
