

HexWeb HTML


my_routine.c
-------------------------------------------
#include "macros.h"

#define FUNC_NAMEm "my_routine"

status_code = foo();

if (status_code != SUCCESS) 
    GPm_ERROR(status_code); 

ERROR_HANDLE:

/* clean up */
/* free memory, close files etc. */

return status_code;


macros.h
-------------------------------------------

#define GPm_ERROR(val) \
 GPm_STATUS(val, FUNC_NAMEm); \
 status_code = val; \
 goto ERROR_HANDLE

#define GPm_STATUS(Code, Func) \
 Log_Error(Code, Func, __FILE__,_LINE__)
/* End of File */


