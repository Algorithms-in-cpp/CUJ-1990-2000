/* ============ */
/* isatty.c	*/
/* ============ */
#include <sys/types.h>
#include <sys/stat.h>

int	isatty(int  FH)
{
	int	RetStatus = 0;

	struct	_stat	FileStatus;

	RetStatus = _fstat(FH, &FileStatus);

	if (_fstat(FH, &FileStatus) == 0)
	{
		RetStatus = (FileStatus.st_mode & _S_IFCHR);
	}

	return RetStatus;
}
