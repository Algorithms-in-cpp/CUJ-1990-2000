/* ============ */
/* xx.c	*/
/* ============ */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* ==================================================================== */
/* */
/* ==================================================================== */
void
main
()
{
	char	c[4] = {'a',0,0,0};
	int	k = 1;
	fpos_t	Pos = 0;
	//rewind(stderr);
	if (fgetpos(stderr, &Pos) != 0)
		printf("fgetpos # 1 failed\n"), exit(1);
	printf("Starting Position in stderr = %ld\n", Pos);
	fprintf(stderr, "%s", "Introduction\n");

	if (fgetpos(stderr, &Pos) != 0)
		printf("fgetpos # 2 failed\n"), exit(1);
	//rewind(stderr);
	printf("Position After Printing     = %ld\n", Pos);

	k = fread(c, 1, 1, stderr);
	if (fgetpos(stderr, &Pos) != 0)
		printf("fgetpos # 3 failed\n"), exit(1);
	printf("Position After  Reading     = %ld\n", Pos);
	--Pos;
	if (fsetpos(stderr, &Pos) != 0)
		printf("fgetpos # 3 failed\n"), exit(1);

	if (fgetpos(stderr, &Pos) != 0)
		printf("fgetpos # 4 failed\n"), exit(1);
	printf("Position After  fsetpos     = %ld\n", Pos);
	fprintf(stderr, "%s", "Introduction # 2\n");

	if (k == 0)
	{
		printf( "Read from stderr failed\n" );
	}
	else
	{
		printf("k = %d, c = %x\n", k, *c);
		printf( "Read from stderr succeeded\n" );
	}
}
