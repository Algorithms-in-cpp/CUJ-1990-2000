/*						qatanh.c	*/
#include "qhead.h"
extern QELT qone[];

int qatanh( x, y )
QELT x[], y[];
{
QELT a[NQ], b[NQ];

qmov( x, a );
a[0] = 0;
if( qcmp( a, qone ) >= 0 )
	{
	mtherr( "qatanh", DOMAIN );
	qinfin(y);
	y[0] = x[0];
	return 0;
	}
qmov( qone, a );
qadd( x, a, a );
qmov( qone, b );
qsub( x, b, b );
qdiv( b, a, a );
qlog( a, y );   /* 0.5 * ln((1+x)/(1-x)) */
y[1] -= 1;
return 0;
}
