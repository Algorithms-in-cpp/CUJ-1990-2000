//--------------------------------------------------------------
//
//  DragNote.c
//      Carl Zmola - 1-19-96
//
//--------------------------------------------------------------

#define STRICT
#include <windows.h>

// win32 doesn't need this
#include "shellapi.h"   // Contains Drag/Drop APIs

#include "dragto.h"

HINSTANCE  app_hinstance;
char       szCommandName[COMMAND_LENGTH];

//--------------------------------------------------------------

int PASCAL
WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
         LPSTR lpCmdLine,  int nCmdShow)
{
    MSG         msg;
    WNDCLASS    wc;
    HWND        hMainWnd;
    HMENU       hmenu;
    char        szAppName[COMMAND_LENGTH];
    char        szClassName[COMMAND_LENGTH];  

    if (0 == LoadString(hInstance,IDS_COMMAND,
                        szCommandName,COMMAND_LENGTH)){
        MessageBox(HWND_DESKTOP,
            "No Command Name Specified in the String Table.",
            "error",MB_ICONHAND|MB_TASKMODAL);
        return 0;
    }    

    if (0 == LoadString(hInstance,IDS_CNAME,
                        szClassName, COMMAND_LENGTH)){
        MessageBox(HWND_DESKTOP,
            "No Class Name Specified in the String Table.",
            "error",MB_ICONHAND|MB_TASKMODAL);
        return 0;
    }

    LoadString( hInstance,IDS_NAME,szAppName,COMMAND_LENGTH);
    
    if (NULL==hPrevInstance)
    {
        wc.style = NULL;
        wc.lpfnWndProc = MainWndProc;
        wc.cbClsExtra = 0;
        wc.cbWndExtra = 0;
        wc.hInstance = hInstance;
        wc.hIcon = LoadIcon (hInstance, "DragTo");
        wc.hCursor = LoadCursor (NULL, IDC_ARROW);
        wc.hbrBackground = GetStockObject (WHITE_BRUSH);
        wc.lpszMenuName =  NULL;
        wc.lpszClassName = szClassName;

        if (!RegisterClass (&wc))
            return (FALSE);
    }
//--------------------------------------------------------------
    hMainWnd = CreateWindow (szClassName, szAppName,
                             WS_POPUP | WS_SYSMENU,0,0,0,0,
                            NULL, NULL, hInstance, NULL);

    if (NULL==hMainWnd) return (FALSE); // CreateWindow failed

    // Register the the main window for Drag/Drop messages.
    DragAcceptFiles (hMainWnd, TRUE);

    // add options to the system menu
    hmenu= GetSystemMenu(hMainWnd,FALSE);
    AppendMenu(hmenu, MF_SEPARATOR, 0 , NULL);
    AppendMenu(hmenu, MF_STRING, IDM_ABOUT , "About ");

    // remove items from the system menu
    DeleteMenu(hmenu, 5,MF_BYPOSITION);  // separator
    DeleteMenu(hmenu, 4,MF_BYPOSITION);  // Maximize
    DeleteMenu(hmenu, 3,MF_BYPOSITION);  // minimize
    DeleteMenu(hmenu, 2,MF_BYPOSITION);  // size
    DeleteMenu(hmenu, 0,MF_BYPOSITION);  // restore

    ShowWindow (hMainWnd, SW_MINIMIZE);
    UpdateWindow (hMainWnd);

    app_hinstance = hInstance;

    while (GetMessage (&msg,NULL,NULL,NULL))
    {
        TranslateMessage (&msg);
        DispatchMessage (&msg);
    }
    return (msg.wParam);
}

//--------------------------------------------------------------

long FAR PASCAL __export
MainWndProc (HWND hWnd, UINT message,
             WPARAM wParam, LPARAM lParam)
{
    DLGPROC lpDialogProc;

    switch (message)
    {
        case WM_DROPFILES:
            On_DropFiles(wParam,lParam);
            break;

        case WM_QUERYOPEN:
            return 0;
	
        case WM_SYSCOMMAND:
            switch (wParam)
            {
                case IDM_ABOUT:
                    lpDialogProc = (DLGPROC) MakeProcInstance (
                        (FARPROC)About, app_hinstance);
                    DialogBox (app_hinstance,"AboutBox",
                               hWnd,lpDialogProc);
                    FreeProcInstance ((FARPROC)lpDialogProc);
                    break;
          
                default:
                    return (DefWindowProc (hWnd, message,
                                           wParam, lParam));
            }   // switch (wParam)
            break;

        case WM_DESTROY:
            PostQuitMessage (0);
            break;

        default:
            return (DefWindowProc (hWnd, message,
                                   wParam, lParam));

    } // switch (message)

    return (0);

} // MainWndProc()


//--------------------------------------------------------------
BOOL CALLBACK __export
About (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            return (TRUE);

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                case IDCANCEL:
                    EndDialog (hDlg, TRUE);
                    return (TRUE);

                default:
                    break;
            } // switch (wParam)
    } // switch (message)

    return (FALSE);

} // About()

//--------------------------------------------------------------

int
On_DropFiles(WPARAM wparam, LPARAM lparm){
    HANDLE  hFilesInfo;
    WORD    wIndex;
    WORD    num_files_dropped;
    char    szFileName [FILE_NAME_LENGTH];

    hFilesInfo = (HANDLE) wparam;

    // Get the total number of files dropped
    num_files_dropped = DragQueryFile (hFilesInfo, (UINT)-1,
                                       NULL, 0);

    // Retrieve each file name and add to the list box
    for (wIndex=0; wIndex < num_files_dropped; wIndex++)
    {
        DragQueryFile (hFilesInfo,wIndex,(LPSTR) szFileName,
                       FILE_NAME_LENGTH);
        ShellExecute(NULL,NULL,szCommandName,szFileName,
                     NULL,SW_SHOW);
    }   // for
    DragFinish (hFilesInfo);
    return 0;
}
