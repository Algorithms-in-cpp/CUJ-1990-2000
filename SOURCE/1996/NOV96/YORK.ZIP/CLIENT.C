#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include <time.h>

#include "sample.h"
/*
poll keyboard & parallel port
return key pressed, process port if necessary
*/
int readKey(void)
{
  do {
    if (kbhit())
      return getch();
    if (PP_RecievePending(lpt)) {
      processRequest();
      return -1;
    }
  } while (1);
}

/*
read a string from the keyboard
[buf] points to result buffer
[sz]  max size of (buf)
return # of bytes in string
*/
int readString(char *buf, int sz)
{
  int pos = 0;
  int key;

  buf[0]=0;

  do {
    key = readKey();
    if (key != 13) {
      if (key == -1)
        printf("\n%s", buf);
      else if (key == 8) {
        if (pos) {
          putch(key);
          --pos;
        }
      } else if (pos + 1 < sz) {
        buf[pos++] = key;
        putch(key);
      }
    }
  } while (key != 13);

  buf[pos]=0;
  printf("\n");
  return strlen(buf);
}

char *skipSpace(char *x)
{
  while (isspace(*x))
    x++;
  return x;
}

#define isCmd(src, test) (strnicmp(src, test, strlen(test)) == 0)
/*
  read:
    send : 'r' + filename
    recv : 'a' + file size (4)

    send : 'n' + file position (4) + bytes requested
    recv : bytes requested
    ...

    send : 'e' (error)
           'f' (finished)
*/
void clientGet(const char *remote, const char *local)
{
  FILE *out;
  BYTE *buf;
  int   sentLen,     /* bytes sent */
        rcvdLen;     /* bytes rcvd */
  int   ct;
  long  fileLen;
  long    totalIn = 0;
  clock_t dataElapsed;   /* this starts before the first data block */

  out = fopen(local, "wb");
  if (!out) {
    printf("GET>>error opening (%s)\n", local);
    goto cleanup;
  }
  buf = malloc(8192);
  if (!buf) {
    printf("GET>>error allocating buffer\n");
    goto cleanup;
  }
  buf[0] = 'g';
  strcpy(buf+1, remote);
  sentLen = 1 + strlen(remote) + 1;
  ct = PP_Write(lpt, buf, sentLen);
  if (sentLen != ct) {
    printf("GET>>error sending filename (%d of %d sent)\n",
      ct,
      sentLen);
    goto cleanup;
  }
  rcvdLen = PP_Read(lpt, &fileLen, sizeof(fileLen));
  if (rcvdLen != sizeof(fileLen)) {
    printf("GET>>error recieveing file length (%d of %d rcvd)\n",
      rcvdLen, sizeof(fileLen));
    goto cleanup;
  }
  if (fileLen == -1) {
    printf("GET>>source file not found\n");
    goto cleanup;
  }
  /*
    allocate space for output file
  */
  fseek(out, fileLen-1, SEEK_SET);
  fputc(' ', out);
  rewind(out);
  /*
  read file
  */
  printf("File length: %ld\n", fileLen);
  dataElapsed = clock();
  while (totalIn < fileLen) {
    sentLen = PP_Write(lpt, "n", 1);
    if (sentLen != 1) {
      printf("GET>>ack error\n");
      goto cleanup;
    }
    rcvdLen = PP_Read(lpt, buf, 8192);
    fwrite(buf, 1, rcvdLen, out);
    totalIn += rcvdLen;
    printf("  rcvd %ld\r", totalIn);
    if (rcvdLen != 8192)
      break;
  }
  dataElapsed = clock() - dataElapsed;
  if (totalIn < fileLen)
    printf("  Error: only %ld of %ld bytes recieved\n", totalIn, fileLen);
  sentLen = PP_Write(lpt, "q", 1);
  if (sentLen != 1)
    printf("GET>>quit error\n");
  printf("Elapsed time: %.2f\n", (float) dataElapsed / CLK_TCK);
  if (!dataElapsed)
    dataElapsed++;
  printf("   bytes/sec: %.2f\n", (float) totalIn * CLK_TCK / dataElapsed);
cleanup:
  if (out)
    fclose(out);
  if (buf)
    free(buf);
}

/*
  put is resolved by requesting the other machine to do a get of this file
*/
void clientPut(const char *local, const char *remote)
{
  char *buf = malloc(1024);
  if (buf) {
    int len = strlen(remote) + strlen(local) + 3;
    int sentLen;
    buf[0] = 'p';
    strcpy(buf+1, remote);
    strcpy(buf+1+strlen(buf), local);
    sentLen = PP_Write(lpt, buf, len);
    if (sentLen != len)
      printf("PUT>>write error %d of %d written\n", sentLen, len);
    free(buf);
  } else
    printf("PUT>> cannot allocate buffer\n");
}

void processClient(void)
{
  char *buf = malloc(1024);
  char *argv[64];
  int   argc;
  char *ptr;
  for ( ; ; ) {
    readString(buf, 1024);
    ptr = buf;
    while (isspace(*ptr))
      ptr++;
    for (argc = 0; (argc < 64) && *ptr; argc++) {
      argv[argc] = ptr;
      while (*ptr && !isspace(*ptr))
        ptr++;
      if (isspace(*ptr))
        *(ptr++) = 0;
      while (isspace(*ptr))
        ptr++;
    }
    if (argc > 0) {
      if (isCmd(argv[0], "exit") || isCmd(argv[0], "off"))
        break;
      else if (isCmd(argv[0], "get")) {
        if ((argc < 2) || (argc > 3))
          printf("Format: GET remote [local]\n");
        else {
          char *local;
          if (argc == 3)
            local = argv[2];
          else {
            local = strrchr(argv[1], '\\');
            if (!local)
              local = strrchr(argv[1], ':');
            if (local)
              local++;
            else
              local = argv[1];
          }
          clientGet(argv[1], local);
        }
      } else if (isCmd(buf, "put")) {
        if ((argc < 2) || (argc > 3))
          printf("Format: GET remote [local]\n");
        else {
          char *remote;
          if (argc == 3)
            remote = argv[2];
          else {
            remote = strrchr(argv[1], '\\');
            if (!remote)
              remote = strrchr(argv[1], ':');
            if (remote)
              remote++;
            else
              remote = argv[1];
          }
          clientPut(argv[1], remote);
        }
      }
    } else
      printf("CL>> ??unkown command??\n");
  }
  PP_ClearQueue(lpt);
  free(buf);
}
