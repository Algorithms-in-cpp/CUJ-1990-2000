#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include <time.h>
#include <io.h>

#include "sample.h"

static BYTE *ioBuf;

/*
  simple get:
    recv: 'g' + filename + '\0'
    send: file length (-1 on file not found)
    recv: 'n'
    send: file block
    ...repeat until all blocks sent
    recv: 'q'

  on entry, ioBuf+1 contains file name (or we wouldn't be here)
*/
LOCAL void svrGet(void)
{
  FILE *inFile;
  long  fileLen;
  int   inLen;
  int   outLen;
  long  totalOut = 0;
  BOOL  done = FALSE;

  printf("SVR GET>> open(%s)\n", ioBuf+1);
  inFile = fopen(ioBuf+1, "rb");
  fileLen = (inFile)
    ? filelength(fileno(inFile))
    : -1;
  outLen = PP_Write(lpt, &fileLen, sizeof(fileLen));

  if (outLen != sizeof(fileLen)) {
    printf(
      "  file length xmit error (%d of %d sent)",
      (int) outLen,
      (int) sizeof(fileLen)
    );
    done = TRUE;
  }
  if (!inFile) {
    perror("   cannot open file");
    done = TRUE;
  }
  while (!done) {
    inLen = PP_Read(lpt, ioBuf, 1);
    if (inLen != 1) {
      printf("\n  read error on ack (%d read)\n", inLen);
      done = TRUE;
    } else {
      if (fileLen == totalOut) {
        if (ioBuf[0] != 'q')
          printf("\n  read error on quit ('q' expected, %02x found)\n", ioBuf[0]);
        done = TRUE;
      } else if (ioBuf[0] != 'n') {
        printf("\n  read error on ack ('n' expected, %02x read)\n", ioBuf[0]);
        done = TRUE;
      } else {
        inLen = fread(ioBuf, 1, 8192, inFile);
        outLen = PP_Write(lpt, ioBuf, inLen);
        if (outLen != inLen)
          printf("\n  data write error (%d of %d written)\n", outLen, inLen);
        totalOut += inLen;
        printf("total out: %ld\r", totalOut);
        if ((totalOut != fileLen) && (inLen != 8192))
          printf("\n  local file read error (%d of 8192 read)\n", inLen);
      }
    }
  }
  if (inFile);
    fclose(inFile);
}

LOCAL void svrPut(void)
{
  char *local = ioBuf + 1;
  char *remote = local + strlen(local) + 1;
  printf("SVR PUT>>%s %s\n", local, remote);
  clientGet(local, remote);
}

/*
  requests begin with a single letter followed by parameters
  'g' = get + filename
  'p' = put + filename
*/
void processRequest(void)
{
  int len;
  if (!ioBuf)
    ioBuf = malloc(8192);   /* note -- this must be smaller or equal
                               to the receive buffer set on open */

  len = PP_Read(lpt, ioBuf, 8192);
  if ( len >= 1) {
    BYTE cmd = ioBuf[0];
    printf("SVR>> request (%c)\n", cmd);
    switch (cmd) {
      case 'g': svrGet(); break;
      case 'p': svrPut(); break;
      default:  printf("SVR>> unknown request (%2x)\n", cmd);
    }
  }
  PP_ClearQueue(lpt);
}
