#include <stdio.h>
#include <string.h>
#include <dos.h>
#include "local.h"

/*
  set (fn) to service (irqNo), and initialize the PIC as necessary
  0x00 <= irqNo <= 0x0f
*/
void interrupt (*initIRQ(int irqNo, void interrupt (*fn)()))
{
  unsigned intNo;
  unsigned cmd0x21;
  unsigned cmd0xa1;
  void interrupt (*retFn)();

  if (irqNo < 8) {
    intNo = irqNo + 0x08;
    cmd0x21 = 1U << irqNo;
    cmd0xa1 = 0;
  } else {
    intNo   = (irqNo - 0x08) + 0x70;
    cmd0x21 = 1U << 2;
    cmd0xa1 = 1U << (irqNo - 0x08);
  }

  retFn = getvect(intNo);
  setvect(intNo, fn);

  if (cmd0xa1)
    outportb(0xa1, inportb(0xa1) & ~cmd0xa1);
  outportb(0x21, inportb(0x21) & ~cmd0x21);

  return retFn;

}

/*
  cleanup the irq service by (1) restoring the original vector, and
  (2) turning off the necessary PIC bits
*/
void cleanupIRQ(int irqNo, void interrupt (*fn)())
{
  unsigned intNo;
  unsigned cmd0x21;
  unsigned cmd0xa1;

  if (irqNo < 8) {
    intNo = irqNo + 0x08;
    cmd0x21 = 1U << irqNo;
    cmd0xa1 = 0;
  } else {
    intNo   = (irqNo - 0x08) + 0x70;
    cmd0x21 = 1U << 2;
    cmd0xa1 = 1U << (irqNo - 0x08);
  }

  if (cmd0xa1) {
    outportb(0xa1, inportb(0xa1) | cmd0xa1);
    if (inportb(0xa1) == 0xff)
      cmd0x21 = 0;
  }
  if (cmd0x21)
    outportb(0x21, inportb(0x21) | cmd0x21);

  setvect(intNo, fn);
}

