#include "local.h"
#include "byteque.h"

/*
  return TRUE if byte is enqueued,
         FALSE if queue is full
*/
BOOL BYTEQUEUE_enqueue(BYTEQUEUE *que, int byte)
{
  if (que->inQueue == que->len)
    return FALSE;
  else {
    que->buf[que->tail++] = byte;
    if (que->tail == que->len)
      que->tail = 0;
    if (++que->inQueue > que->maxInQueue)
      que->maxInQueue = que->inQueue;
    return TRUE;
  }
}

/*
  return (-1) if queue is empty
  otherwise return next byte from queue
*/
int  BYTEQUEUE_dequeue(BYTEQUEUE *que)
{
  if (!que->inQueue)
    return -1;
  else {
    int ret;
    ret = que->buf[que->head++];
    if (que->head == que->len)
      que->head = 0;
    que->inQueue--;
    return ret;
  }
}

