#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <assert.h>
#include "ppio.h"
#include "sample.h"

/*
this is the parallel port
*/
GLOBAL PP *lpt;

/*
format:
  sample port_# [n]
  where (1 <= port # <= 3)
  [n] sets nybble mode, default = byte
*/
int main(int argc, char **argv)
{
  int portNo = (argc >= 2) ? atoi(argv[1]) : -1;
  if ((argc < 2) || (argc > 3) || (portNo < 1) || (3 < portNo)) {
    fprintf(
      stderr,
      "format:\n"
      "\tlptest port_# [n]\n"
      "port # = 1, 2, or 3\n"
    );
    return 1;
  } else {
    PPMODE mode = ((argc == 3) && (argv[2][0] == 'n')) 
      ? PP_NYBBLE
      : PP_BYTE;
    clrscr();
    printf("\n");
    lpt = PP_Open(portNo, -1, -1, 16384, mode);

    processClient();
    PP_Close(lpt);
    return 0;
  }
}

