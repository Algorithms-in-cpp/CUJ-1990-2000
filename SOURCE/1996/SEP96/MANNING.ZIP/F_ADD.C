float f_add(float * flt_arr)
{
  long i;
  float sum = 0.0;

  for (i = 0; i < ARR_SIZE; i++)
    sum += flt_arr[i];
  return sum;
}
