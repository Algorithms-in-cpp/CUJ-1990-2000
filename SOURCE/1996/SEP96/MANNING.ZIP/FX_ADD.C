float fx_add(float * flt_arr)
{
  long i;
  double sum = 0.0;

  for (i = 0; i < ARR_SIZE; i++)
    sum += flt_arr[i];
  return sum;
}
