/* PrintInCImp.c: C functions for Java class */

#include <stdio.h>
#include <StubPreamble.h>
#include "PrintInC.h"



/*** Java to C demo: Print data values ***/
long PrintInC_doPrint(struct HPrintInC *this,
                      int64_t l,
                      HArrayOfInt *ai, long iCount,
                      double d,
                      struct Hjava_lang_String *s)
{
   int charsPrinted=0, idx=0;
   long *i;


   /* Print value of "long" (Java int) */
   charsPrinted += printf("C: l = %ld\n", l);


   /* Print array of longs */
   i = unhand(ai)->body;
   for (idx=0; idx < iCount; idx++)
      charsPrinted += printf("C: i[%d] = %d\n", idx, i[idx]);


   /* Print value of "double */
   charsPrinted += printf("C: d = %f\n", d);


   /* Print Java string */
   charsPrinted += printf("C: s = %s\n", makeCString(s));


   /* Return total characters printed */
   return charsPrinted;
}
