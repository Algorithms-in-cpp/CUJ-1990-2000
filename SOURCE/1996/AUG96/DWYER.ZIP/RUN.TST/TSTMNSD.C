/* ============ */
/* tstmnsd.c	*/
/* ============ */
/* ====================================================================	*/
/*		Tests Function RunMeanStdDev				*/
/* ====================================================================	*/
#include <assert.h>
#include <stdio.h>
#include <miscdefs.h>
#include <math.h>

void
main()
{
    while (main)
    {
	UINT	NumSegs, SetSize, Unique;
	double	Mean, StdDev;

	AbortGracefully();

	GetUint("Enter Number of Integers in Data Set:    ", &SetSize);
	GetUint("Enter Number of Unique Integers Desired: ", &Unique);
	GetUint("Enter Number of Segments to be Counted:  ", &NumSegs);

	RunMeanStdDev(SetSize, Unique, &Mean, &StdDev);
	printf("%15u  Unique Integers\n%15u  Segments\n",
		Unique, NumSegs);
	printf("%15.f  Mean Number of Variates Required\n", NumSegs * Mean);
	printf("%15.f  Standard Deviation\n", StdDev * sqrt(NumSegs)));
    }
}
