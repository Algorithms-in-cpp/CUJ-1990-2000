/* ============ */
/* GetLDBL.c	*/
/* ============ */
#include <stdio.h>

#define	FLUSH_LINE(u)			\
    {					\
	int	x;			\
	do				\
	{				\
	    x = getc(u);		\
	}				\
	while (x != EOF && x != '\n');	\
    }
/* ==================================================== */
/* GetLDBL - prompts operator with s to get long double	*/
/* ==================================================== */
# if defined(__STDC__) || defined(__PROTO__)
void
GetLDBL(char *s, long double *d)
# else
void
GetLDBL(s, d)
char   *s;
long    double *d;
# endif
{
    fprintf(stderr, "%s", s);

    scanf("%Le", d);

    FLUSH_LINE(stdin);
}
# if TEST
void
main()
{
    long    double  target;

    while (main)
    {
	GetLDBL("Enter next long double: ", &target);

	printf("You entered %.21Le\n", target);
    }
}
# endif
