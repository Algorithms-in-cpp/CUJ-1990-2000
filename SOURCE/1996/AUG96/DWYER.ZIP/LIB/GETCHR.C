/* ============ */
/* GetChr.c	*/
/* ============ */
#include <stdio.h>

#define	FLUSH_LINE(u)			\
    {					\
	int	x;			\
	do				\
	{				\
	    x = getc(u);		\
	}				\
	while (x != EOF && x != '\n');	\
    }
/* ==================================================== */
/* GetChr - prompts operator with s to get character  c */
/* ==================================================== */
# if defined(__STDC__) || defined(__PROTO__)
void
GetChr(char *s, char *c)
# else
int
GetChr(s, c)
char   *s;
char   *c;
# endif
{
    fprintf(stderr, "%s", s);

    scanf("%c", c);

    FLUSH_LINE(stdin);
}
