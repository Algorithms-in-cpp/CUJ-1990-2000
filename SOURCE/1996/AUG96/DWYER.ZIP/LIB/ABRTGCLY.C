/* ============ */
/* abrtgcly.c	*/
/* ============ */
#include <signal.h>
#include <stdlib.h>
/* ==================================================================== */
/* HaltProcess - Performs exit via AbortGracefully when ^C is Pressed	*/
/* ==================================================================== */
# if 0
# if defined(__STDC__) || defined(__PROTO__)
static void
HaltProcess(int unused)
# else
static void
HaltProcess(unused)
int	unused;
# endif
{
    if (unused || !unused)
	exit(1);
}
# endif
/* ==================================================================== */
/* AbortGracefully - does the right thing at <CTRL> C or <CTRL> break	*/
/* ==================================================================== */
# if defined(__STDC__) || defined(__PROTO__)
void
AbortGracefully(void)
# else
void
AbortGracefully()
# endif
{
    /* -------------------- */
    /* Execute exit() on ^C */
    /* -------------------- */
# if 0
    signal(SIGINT, HaltProcess);
# endif
    signal(SIGINT, exit);
}
