/* ============ */
/* GetDbl.c	*/
/* ============ */
#include <stdio.h>

#define	FLUSH_LINE(u)			\
    {					\
	int	x;			\
	do				\
	{				\
	    x = getc(u);		\
	}				\
	while (x != EOF && x != '\n');	\
    }
/* ==================================================== */
/* GetDbl - prompts operator with s to get double	*/
/* ==================================================== */
# if defined(__STDC__) || defined(__PROTO__)
void
GetDbl(char *s, double *d)
# else
void
GetDbl(s, d)
char	*s;
double	*d;
# endif
{
    fprintf(stderr, "%s", s);

    scanf("%le", d);

   FLUSH_LINE(stdin);
}
