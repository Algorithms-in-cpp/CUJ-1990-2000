/* ============ */
/* GetUint.c	*/
/* ============ */
#include <stdio.h>

#define	FLUSH_LINE(u)			\
    {					\
	int	x;			\
	do				\
	{				\
	    x = getc(u);		\
	}				\
	while (x != EOF && x != '\n');	\
    }
typedef	unsigned int	UINT;
/* ==================================================== */
/* GetUint - prompts operator with s to get UINT i	*/
/* ==================================================== */
# if defined(__STDC__) || defined(__PROTO__)
void
GetUint(char *s, UINT *i)
# else
void
GetUint(s, i)
char	*s;
UINT	*i;
# endif
{
    {
	unsigned long Trial;

	fprintf(stderr, "%s", s);

	scanf("%lu", &Trial);

	*i = (UINT)Trial;
    }

    FLUSH_LINE(stdin);
}
