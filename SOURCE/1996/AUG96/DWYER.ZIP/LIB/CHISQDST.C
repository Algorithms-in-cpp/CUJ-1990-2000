/* ============ */
/* chisqdst.c	*/
/* ============ */
#include <defcodes.h>
#include <math.h>

#include "mconf.h"
/* ==================================================================== */
/* ChiSqDist = Yields Chi-Square Range for Percent & Degrees of Freedom	*/
/* ==================================================================== */
void
ChiSqDist(double ChiSqPct, double DegFree,
	  double *RangeVal_1, double *RangeVal_2)
{
    *RangeVal_1 = chdtri(DegFree, 1.0-ChiSqPct);
    *RangeVal_2 = chdtri(DegFree,     ChiSqPct);
}
