long expand[256];

void init_interleave_table(void)
{ int i, j, expanded;
  for(i=0;i<256;i++) {
    expanded = 0;
    for(j=0;j<8;j++)
      expanded |= (i&(1<<j))<<(2*j);
    expand[i] = expanded;
  }
}

long interleave_color(int r, int g, int b)
{
  return ((expand[r]<<2) 
          | (expand[g]<<1) 
          | (expand[b]));
}

