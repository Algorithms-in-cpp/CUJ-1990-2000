/*   Listing 2

     Test driver for forfun().
*/

#include <stdio.h>
#define MAXNUMLOOPS 10

void forfun (int *, int *, int *, int , int);
void work(int *, int);

main()
{
int r[MAXNUMLOOPS], startval[MAXNUMLOOPS], endval[MAXNUMLOOPS],
     lastloopsub;

/*  Specify test data  */
/*  Must have  0 <= lastloopsub <= MAXNUMLOOPS - 1  */
lastloopsub = 2;

startval[0] = 0;
startval[1] = 1;
startval[2] = 5;
endval[0] = 2;
endval[1] = 4;
endval[2] = 7;
/*  End of test data specification */

/*  Explicitly nested for statements */
for (r[0] = startval[0]; r[0] <= endval[0]; r[0]++)
for (r[1] = startval[1]; r[1] <= endval[1]; r[1]++)
for (r[2] = startval[2]; r[2] <= endval[2]; r[2]++)
     work(r, lastloopsub);

/*  Recursively nested for statements  */
forfun (r, startval, endval, 0, lastloopsub);

exit (0);
}  /*  end of  main()  */

void work(int * r, int lastloopsub)
{
int loop;
for (loop = 0; loop <= lastloopsub; loop++)
      printf("r[%d] = %d ", loop, r[loop]);
printf("\n");
}  /*  end of work()  */
