/*  Listing 1  */

void forfun (int *r, int *startval, int *endval,
     int loop, int lastloopsub)
{
/*  initialization  */
r[loop] = startval[loop];

/*  continuation condition  */
while ( r[loop] <= endval[loop] ){
      /*  recursion termination condition  */
      if (loop == lastloopsub){
            /*  do work of the innermost loop  */
            work(r, lastloopsub);
            }
      else{
            forfun(r,startval,endval,(loop+1),lastloopsub);
            }
      /*  Increment looping variable  */
      r[loop]++;
      }
}  /*  end of forfun()  */
