/* Listing 9 */

/* formtemp.c -- use form templates */

/*
   Generate declarations and definitions for

     int max(int,int);
     stack<char>
*/
#define max max_iii
#define max_TYPE int
#define stack_ITEM char
#define stack stack_char
#define stack_scope(memFnc) stack_char_ ## memFnc
#include "def_gen.c"

/*
   Generate declarations and definitions for

     stack<int,10U>
*/
#define stack_ITEM int
#define stack_MAX_ITEMS 10U
#define stack stack_int_10U
#define stack_scope(memFnc) stack_int_10U_ ## memFnc
#include "def_gen.c"

#include <stdio.h>
#include <stdlib.h>

main()
{
    struct stack_char ToDo;
    struct stack_int_10U CountDown;
    int i, * iptr;

    (void) printf("Which is greater? %d or %d?  "
        "Answer: %d!\n",4,5,max_iii(4,5));

    stack_char_init(&ToDo);
    stack_char_push(&ToDo,"wash car");
    stack_char_push(&ToDo,"cut grass");
    stack_char_push(&ToDo,"buy groceries");
    stack_char_push(&ToDo,"cash paycheck");
    while (stack_char_top(&ToDo))
        (void) printf("%s\n",stack_char_pop(&ToDo));

    stack_int_10U_init(&CountDown);
    for (i = 1; !stack_int_10U_full(&CountDown); i++)
    {
        iptr = (int *) malloc(sizeof(int));
        if (!iptr)
            break;
        * iptr = i;
        (void) stack_int_10U_push(&CountDown,iptr);
    }
    while (stack_int_10U_top(&CountDown))  {
        (void) printf("%d ",
            * stack_int_10U_top(&CountDown));
        free(stack_int_10U_pop(&CountDown));
    }
    (void) printf("Blast Off!\n");
    return 0;
}
