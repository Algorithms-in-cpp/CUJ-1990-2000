LISTING 3 - Illustrates wide character strings
#include <stddef.h>
#include <stdio.h>

main()
{
    char str[] = "hello";
    wchar_t wcs[] = L"hello";

    printf("sizeof str = %d\n",sizeof str);
    printf("sizeof wcs = %d\n",sizeof wcs);
    return 0;
}

/* Output:
sizeof str = 6
sizeof wcs = 12
*/

