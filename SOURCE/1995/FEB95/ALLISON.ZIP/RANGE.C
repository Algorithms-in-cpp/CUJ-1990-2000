LISTING 2 -  Uses <limits.h> to choose a suitable numeric type
/* range.c */
#include <stdio.h>
#include <limits.h>

#define LOWER_BOUND  <your min here>
#define UPPER_BOUND  <your max here>

/* Determine minimal numeric type for range */
#if LOWER_BOUND < LONG_MIN || LONG_MAX < UPPER_BOUND
    typedef double Num_t;
#elif LOWER_BOUND < INT_MIN || INT_MAX < UPPER_BOUND
    typedef long Num_t;
#elif LOWER_BOUND < SCHAR_MIN || SCHAR_MAX < UPPER_BOUND
    typedef int Num_t;
#else
    typedef signed char Num_t;
#endif

main()
{
    Num_t x;

    printf("sizeof(Num_t) == %d\n",sizeof x);
    return 0;
}

