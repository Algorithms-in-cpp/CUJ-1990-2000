LISTING 1 - 
/* bit3.c:    Toggle bits in a word */
#include <stdio.h>
#include <limits.h>

#define WORD      unsigned int
#define NBYTES    sizeof(WORD)
#define NBITS    (NBYTES * CHAR_BIT)
#define NXDIGITS (NBYTES * 2)

main()
{
    WORD n = 0;
    int i, j;

    for (j = 0; j < 2; ++j)
        for (i = 0; i < NBITS; ++i)
        {
            n ^= (1 << i);
            printf("%0*X\n",NXDIGITS,n);
        }

    return 0;
}

/* Output:
0001
0003
0007
000F
001F
003F
007F
00FF
01FF
03FF
07FF
0FFF
1FFF
3FFF
7FFF
FFFF
FFFE
FFFC
FFF8
FFF0
FFE0
FFC0
FF80
FF00
FE00
FC00
F800
F000
E000
C000
8000
0000
*/

