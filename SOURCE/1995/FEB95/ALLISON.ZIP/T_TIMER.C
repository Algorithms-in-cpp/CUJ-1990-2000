LISTING 5 - Illustrates the stopwatch functions

/* t_timer.c:  Tests the stopwatch functions */

#include <stdio.h>
#include <limits.h>
#include "timer.h"

main()
{
    long i;

    timer_reset();

     /* Delay */
    for (i = 0; i < LONG_MAX; ++i)
          ;

    /* Get elapsed time */
    printf("elapsed time: %lf secs\n",timer_elapsed());
    return 0;
}

/* Output:
elapsed time: 565.070000 secs
*/

