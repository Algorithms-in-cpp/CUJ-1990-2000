LISTING 4 - offsetof exposes alignment within a structure

#include <stddef.h>
#include <stdio.h>

struct Person
{
     char name[15];
     int age;
};

main()
{
     printf("%d\n",offsetof(struct Person, age));
     return 0;
}

/* Output:
16
*/

