--------------------- Listing 4: The file strstfre.c --------------

// strstfreeze -- strstreambuf::freeze(bool)
#include <<strstream>>

void strstreambuf::freeze(bool freezeit)
	{	// freeze a dynamic string
	if (freezeit && !(_Strmode & _Frozen))
		{	// disable writing
		_Strmode |= _Frozen;
		_Pendsave = epptr();
		setp(pbase(), pptr(), eback());
		}
	else if (!freezeit && _Strmode & _Frozen)
		{	// re-enable writing
		_Strmode &= ~_Frozen;
		setp(pbase(), pptr(), _Pendsave);
		}
	}
