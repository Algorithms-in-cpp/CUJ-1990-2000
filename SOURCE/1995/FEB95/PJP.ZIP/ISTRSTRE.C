--------------------- Listing 6: The file istrstre.c --------------

// istrstream -- istrstream basic members
#include <<strstream>>

istrstream::~istrstream()
	{	// destruct an istrstream
	}

