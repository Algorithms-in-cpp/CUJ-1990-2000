--------------------- Listing 7: The file ostrstre.c --------------

// ostrstream -- ostrstream basic members
#include <<string.h>>
#include <<strstream>>
_STD_BEGIN

ostrstream::ostrstream(char *s, int n, openmode mode)
	: ios(&_Sb), ostream(&_Sb),
	_Sb(s, n, s == 0 || !(mode & app) ? s : s + strlen(s))
	{	// write at terminating null (if there)
	}

ostrstream::~ostrstream()
	{	// destruct an ostrstream
	}
