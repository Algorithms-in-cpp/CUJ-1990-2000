

/* Listing 9: Program to Count Word Frequency */
/* Counts words then displays word frequency. */
/* Input: one word per line read from stdin   */

#include "aa.h"

#define WORD_COUNT(word) (*(int *)aa_addr(aa_id,word))
#define UNUSED 0

main()
{
  int i, count;
  char **words, word_buffer[100];
  AA *aa_id=aa_create(STRING_KEY,UNUSED,sizeof(int),500,0);

  while(gets(word_buffer) != NULL)
	WORD_COUNT(word_buffer)++;

  aa_keys(aa_id,(void ***)&words,&count);
  for (i=0; i<count; i++)
     printf("  Word: %-30s Frequency: %d\n",
	    words[i],WORD_COUNT(words[i]));
}
