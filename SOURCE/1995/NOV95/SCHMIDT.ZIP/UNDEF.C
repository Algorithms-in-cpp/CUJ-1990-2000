void f(void)
    {
    static void g(); /* function declared non-extern
                        at block scope */
    struct t
        {
        char : 2;    /* bitfield other than int */
        };           /* all struct members anonymous */
    int i;
    int j = i;       /* reference uninitialized/unassigned
                        automatic variable */
    j /= 0;          /* division by zero */
    j = i++ * ++i;   /* object modified twice
                        between sequence points */
    j = '\z';        /* unspecified escape sequence */
    printf("huh?");  /* variable-length argument list
                        function without prototype */
    }
