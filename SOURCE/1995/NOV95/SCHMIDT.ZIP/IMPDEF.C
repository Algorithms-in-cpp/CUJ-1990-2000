#include <stddef.h>

extern int X234567;  /* # of significant initial
                        characters (beyond 6) in extern */
                     /* whether extern case is distinct */
char c = sizeof(c);  /* sizeof(char) */
                     /* sign of char */
int m = 5 % -2;      /* sign of remainder */
int n = NULL;        /* value of NULL after expansion */
int *p = 1;          /* casting int to pointer */
struct t
    {
    int i : 2;       /* whether plain int bit-field
                        treated as signed or unsigned */
    unsigned u : 16; /* whether bit-field can straddle
                        storage boundary */
    };               /* order of bit-fields */
