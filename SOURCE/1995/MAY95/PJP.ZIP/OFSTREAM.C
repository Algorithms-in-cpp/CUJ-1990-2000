------------- Listing 5: The file ofstream.c ------------------

// ofstream -- ofstream basic members
#include <fstream>

ofstream::~ofstream()
        {       // destruct an ofstream
        }
