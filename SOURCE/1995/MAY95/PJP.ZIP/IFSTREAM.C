------------- Listing 4: The file ifstream.c ------------------

// ifstream -- ifstream basic members
#include <fstream>

ifstream::~ifstream()
        {       // destruct an ifstream
        }
