------------- Listing 7: The file istdiost.c ------------------

// istdiostream -- istdiostream basic members
#include <fstream>

istdiostream::~istdiostream()
        {       // destruct an istdiostream
        }
