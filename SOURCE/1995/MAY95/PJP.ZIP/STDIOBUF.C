------------- Listing 6: The file stdiobuf.c ------------------

// stdiobuf -- stdiobuf basic members
#include <fstream>

stdiobuf::~stdiobuf()
        {       // destruct a stdiobuf
        }
