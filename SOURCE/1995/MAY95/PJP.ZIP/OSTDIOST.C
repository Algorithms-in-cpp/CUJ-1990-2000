------------- Listing 8: The file ostdiost.c ------------------

// ostdiostream -- ostdiostream basic members
#include <fstream>

ostdiostream::~ostdiostream()
        {       // destruct an ostdiostream
        }
