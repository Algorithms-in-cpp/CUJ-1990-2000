/*
 * Listing 9 - flipy.c
 */

#include <stdio.h>
#include "ips_image.h"

void flipy();

int
main(argc, argv)
int argc;
char **argv;
{
	ips_header	header;
	ips_image	image, newimage;

	if (argc<3) {
		printf("Usage: %s infile outfile", argv[0]);
		exit(1);
	}

	ips_to_img(&header, &image, argv[1]);

	flipy(&header, &image, &newimage);

	img_to_ips(&header, &newimage, argv[2]);

	exit(0);
}



void
flipy(header, image, newimage)
ips_header *header;
ips_image  *image, *newimage;
{
	long cnt;

	memcpy(newimage->cmap, image->cmap, sizeof(XColor) * 256);

	newimage->data =
		(unsigned char *)malloc(header->width *
			header->height);

	for(cnt=0;cnt < header->width * header->height;cnt++)
		newimage->data[cnt] =
			image->data[(header->width * header->height) -
			cnt];
}
