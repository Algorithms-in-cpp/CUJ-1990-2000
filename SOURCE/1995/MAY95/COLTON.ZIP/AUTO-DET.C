/*
 * Listing 7 - auto-detect.c
 */

#include <stdio.h>
#include <unistd.h>

int
main(argc, argv)
int argc;
char **argv;
{
	FILE *fp;
	char buf[1000];
	char buf2[1000];
	char magic_number[12];
	char format[5];


	if(argc < 3) {
		printf("Usage: %s infile outfile\n", argv[0]);
		exit(1);
	}

	fp = fopen(argv[1], "r");

	fread(magic_number, sizeof(char),
		sizeof(magic_number), fp);

	fclose(fp);

	if (strncmp(magic_number,"GIF8",4) == 0)
		(void) strcpy(format,"GIF");

	else if ((magic_number[1] == 0x00) &&
				(magic_number[2] == 0x00)) {
			if ((magic_number[5] == 0x00) &&
					(magic_number[6] == 0x00))
				if ((magic_number[4] == 0x07) ||
						(magic_number[7] == 0x07))
					strcpy(format,"XWD");

	} else exit(1);

	if(strlen(format) == 0) exit(1);

	sprintf(buf2, "%s/%s",
		getenv("LOADERS_DIR"), format);

    if(access(buf2, R_OK) != 0) {
		printf("\n%s: %s format not available.\n",
			argv[0], format);

		exit(1);
	}

	sprintf(buf, "%s %s %s", buf2, argv[1], argv[2]);

	return system(buf);
}
