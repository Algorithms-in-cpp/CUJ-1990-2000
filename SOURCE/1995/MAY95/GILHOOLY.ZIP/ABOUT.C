#undef GLOBALS
#include "winjes.h"

BOOL CALLBACK AboutProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        case WM_INITDIALOG:
          SetFocus(GetDlgItem(hWnd, IDOK));
          break;
          
        case WM_CLOSE:
          EndDialog(hWnd, TRUE);
          break;


        
        case WM_COMMAND:
          switch (wParam)
          {     
            case IDOK:
              EndDialog(hWnd, TRUE);
              break;

            case IDCANCEL:
              EndDialog(hWnd, FALSE);
              break;
          }
          break;
    }     
    
    return FALSE;
}
 
