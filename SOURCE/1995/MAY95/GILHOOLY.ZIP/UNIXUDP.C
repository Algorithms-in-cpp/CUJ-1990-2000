get a socket()
bind() it to an address
while (recvfrom())
{
  process the incoming message
}

