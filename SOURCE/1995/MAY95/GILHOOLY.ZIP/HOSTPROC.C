#undef GLOBALS
#include "winjes.h"

BOOL CALLBACK HostProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        case WM_INITDIALOG:
          SetFocus(GetDlgItem(hWnd, IDC_HOST));
          break;
          
        case WM_COMMAND:
          switch (wParam)
          {     
            case IDOK:
              GetDlgItemText(hWnd, IDC_HOST,    (LPSTR)OutMessage.szHostName, MAXHOST);
              GetDlgItemText(hWnd, IDC_MESSAGE, (LPSTR)OutMessage.szCommand, MAXBUFFER);
              EndDialog(hWnd, TRUE);
              break;

            case IDCANCEL:
              EndDialog(hWnd, FALSE);
              break;
          }
          break;
    }     
    
    return FALSE;
}
 
