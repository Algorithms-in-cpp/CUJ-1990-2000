/* Listing 8, printf.c, version 2 */
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "check.h"	/* Listing 5 */
#include "printf.h"	/* Listing 7 */

static struct Func func =
   {
   "int",
   "printf",
   "(const char format[], ...)",
   NULL,
   NULL
   };

/* == DB_printf() from Listing 4 == */

PrintfLike * Ptr_printf(const char file[], 
                        const char line[])
   {
   func.file = file;
   func.line = line;
   return DB_printf;
   }

