Listing 1

  int xDelta = x1-x0;
  int yDelta = y1-y0;
  int numerator = 0;

  for(x=x0, y=y0; x < x1; x++) {
    numerator += yDelta;
    if (numerator > xDelta) {
      numerator -= xDelta;
      y++;
    }
    plot_point(x,y);
  }
