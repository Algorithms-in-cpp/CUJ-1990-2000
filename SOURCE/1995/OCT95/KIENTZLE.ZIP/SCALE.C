Listing 2

void scale_nonsmooth
   (PIXEL *src, int srcWidth,
    PIXEL *dest, int destWidth)
{
  int srcPos=0, destPos=0;
  int numerator=0;

  while(destPos < destWidth) {
    dest[destPos++]=src[srcPos];
    numerator += srcWidth;
    while (numerator > destWidth) {
      numerator -= destWidth;
      srcPos++;
    }
  }
}
