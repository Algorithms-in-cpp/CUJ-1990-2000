Listing 3 - Examples of the K & R
indenting style applied C/C++ if-else and
while statements.

if (expression) {
    statement;
    statement;
    ...
} else {
    statement;
    statement;
    ...
}

while (expression) {
    statement;
    statement;
    ...
}
