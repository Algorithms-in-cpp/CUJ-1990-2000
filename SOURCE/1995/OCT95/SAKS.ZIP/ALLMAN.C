Listing 5 - Examples of the Allman
indenting style applied to C/C++ if-else
and while statements.

if (expression)
{
    statement;
    statement;
    ...
}
else
{
    statement;
    statement;
    ...
}

while (expression)
{
    statement;
    statement;
    ...
}
