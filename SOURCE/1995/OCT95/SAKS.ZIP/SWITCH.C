Listing 6 - Examples of switch statements
using each of the popular indenting
styles.

a) K & R

switch (expression) {
case expression:
    statement;
    break;
case expression:
    statement;
    break;
default:
    statement;
    break;
}

b) Whitesmiths

switch (expression)
    {
case expression:
    statement;
    break;
case expression:
    statement;
    break;
default:
    statement;
    break;
    }

c) Allman

switch (expression)
{
case expression:
    statement;
    break;
case expression:
    statement;
    break;
default:
    statement;
    break;
}
