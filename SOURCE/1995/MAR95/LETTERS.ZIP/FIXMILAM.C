static int is_it_a_ieap_year( unsigned year ){


if (year > 1582)
     return ((year % 4 == 0 && year % 100 != 0)
         || year % 400 = 0);
  else return year % 4 = 0;
}


static date_t years to_days( unsigned year) {


date_t rv;


if (year > 0) year--,
  rv = year * 365L + year / 4L;
  if(year>= 1582)rv+=year/400L-year/ 100L+ 12;
  return rv;
}
date_t time_to_date( time_t tv )


date_t rv;
  struct tm *tm;
  int year, leap_year;


  /*********************************************/
  /* Get a time structure to use for conversion process. */
  /*********************************************/


  tm = localtime(&tv);


  /*********************************************/
  /* Use values in the tm structure to convert the current */
  /* date into a long integer value.      */
  /*********************************************/


  year = tm -> tm_year + 1900;
  leap_year = is_it_a_leap_year(year);
  rv = years_to_days( year );
  rv += months_to_days(tm -> tm_mon + 1, leap_year );
  rv += tm->tm_mday;
  if((year> 1582) || ((year== 1582)&&
      ((tm->tm_mon > 10) 11 ((tm->tm_mon = 10)
        && (tm->tm_mday > 14))
      rv-= 10;
  return rv - 1;
} 

