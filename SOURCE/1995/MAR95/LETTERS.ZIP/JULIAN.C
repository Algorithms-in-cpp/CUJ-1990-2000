/* Julian Easter */

int jeaster (int year)
{
  
  int A, B, C, D, E, Month, Day;

  A = year % 4;
  B = year % 7;
  C = year % 19;
  D = (19 * C + 15) % 30;
  E = (2 * A + 4 * B - D + 34) % 7;
  Month = (D + E + 114) / 31;
  Day = ((D + E + 114) % 31) + 1;
  return (Month + Day * 10);
}
/* unwrap using month = return % 10 */
/*                day = return / 10 */ 

