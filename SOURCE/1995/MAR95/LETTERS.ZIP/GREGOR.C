/* Gregorian Easter */

int geaster (int year)
{
  int A, B, C, D, E, F, G, H, I, K, L, M, Month, Day;

  if (year < 1583) return 0;
  A = year % 19;
  B = year / 100;
  C = year % 100;
  D = B / 4;
  E = B % 4;
  F = (B + 8) / 25
  G = (B - F + 1) / 3;
  H = (19 * A + B - D - G + 15) % 30;
  I = C / 4;
  K = C % 4;
  L = (32 + 2 * E + 2 * I - H - K) % 7;
  M = (A + 11 * H + 22 * L) / 451;
  Month = (H + L - 7 * M + 114) / 31;
  Day + (((H + L - 7 * M + 114) % 31) + 1);
  return (Month + Day * 10);
}
/* unwrap using Month = result % 10 */
/*                Day = result / 10 */ 

