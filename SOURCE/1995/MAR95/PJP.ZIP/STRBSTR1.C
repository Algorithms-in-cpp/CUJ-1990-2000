------------- Listing 4: The file strbstr1.c ------------------

// strbstr1 -- stringbuf::str(const string&)
#include <<sstream>>

void stringbuf::str(const string& str)
        {       // construct stringbuf from string
        _Tidy();
        _Init(str.length(), (char *)str.c_str(), 0, _Strmode);
        }
