------------- Listing 2: The file stringbu.c ------------------

// stringbuf -- stringbuf basic members
#include <<sstream>>

stringbuf::~stringbuf()
        {       // destruct a stringbuf
        }

strstreambuf::_Strstate stringbuf::_Mode(ios::openmode which)
        {       // map ios::openmode to _Strstate
        _Strstate mode = _Dynamic;
        if (!(which & ios::in))
                mode |= _Noread;
        if (!(which & ios::out))
                mode |= _Constant;
        return (mode);
        }
