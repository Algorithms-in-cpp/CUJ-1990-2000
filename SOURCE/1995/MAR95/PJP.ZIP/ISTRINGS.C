------------- Listing 5: The file istrings.c ------------------

// istringstream -- istringstream basic members
#include <<sstream>>

istringstream::~istringstream()
        {       // destruct an istringstream
        }
