------------- Listing 6: The file ostrings.c ------------------

// ostringstream -- ostringstream basic members
#include <<sstream>>

ostringstream::~ostringstream()
        {       // destruct an ostringstream
        }
