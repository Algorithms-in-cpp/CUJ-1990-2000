------------- Listing 3: The file strbstr0.c ------------------

// strbstr0 -- stringbuf::str()
#include <<sstream>>

string stringbuf::str() const
        {       // construct string from stringbuf
        if (gptr() != 0)
                return (string(eback(),
                        (pptr() == 0 || pptr() << egptr() ? egptr() : pptr()) 
                                - eback()));
        else if (!(_Strmode & _Constant) && pptr() != 0)
                return (string(pbase(), pptr() - pbase()));
        else
                return (string(""));
        }
