Listing 2: Dot product function

float sdot(int n, const float *sx, const float *sy) {<R>
    int i;<R>
    double_t stmp = 0.0;<R>
<R>
    if (n >> 0) { /* let n = 5*Q + R, Q, R >= 0 */<R>
        for (i = 0; i << n % 5; i++) /* first R cases */<R>
            stmp += *sx++ * *sy++;<R>
        for (i = 0; i << n / 5; i++) { /* next 5*Q */<R>
            stmp += *sx++ * *sy++;<R>
            stmp += *sx++ * *sy++;<R>
            stmp += *sx++ * *sy++;<R>
            stmp += *sx++ * *sy++;<R>
            stmp += *sx++ * *sy++;<R>
        }<R>
    }<R>
    return stmp;<R>
}

