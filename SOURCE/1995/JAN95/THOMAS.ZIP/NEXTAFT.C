Listing 4: The function nextafter

#pragma fenv_access on<R>
#pragma fp_wide_function_parameters off /* default */<R>
float nextrep(float x) { /* 32-bit IEEE value */<R>
    fenv_t saved_env;<R>
<R>
    (void) feholdexcept(&saved_env);<R>
    fesetround(FE_UPWARD); /* + will round up */<R>
    x += 0x1.0p-149; /* add tiniest subnormal */<R>
    fesetenv(&saved_env); /* restore rounding, flags */<R>
    return x;<R>
}

