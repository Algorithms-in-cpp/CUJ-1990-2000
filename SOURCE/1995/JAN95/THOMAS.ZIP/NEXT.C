Listing 3: Finding the next value

float x1, x2, x3, x4, x5;<R>
x1 = 0x0.800001p1;          /* hex floating constant */<R>
x2 = nextafterf(1.0, 2.0);  /* next from 1 to 2 */<R>
x3 = 1.00000012f;           /* 2^-23 approx= 1.2e-7 */<R>
x4 = 1.0 + pow(2.0, -23.0); /* evaluate increment */<R>
x5 = nextrep(1.0f);         /* defined later */<R>


Listing 4: The function nextafter

#pragma fenv_access on<R>
#pragma fp_wide_function_parameters off /* default */<R>
float nextrep(float x) { /* 32-bit IEEE value */<R>
    fenv_t saved_env;<R>
<R>
    (void) feholdexcept(&saved_env);<R>
    fesetround(FE_UPWARD); /* + will round up */<R>
    x += 0x1.0p-149; /* add tiniest subnormal */<R>
    fesetenv(&saved_env); /* restore rounding, flags */<R>
    return x;<R>
}

