LISTING 3 - Converts a hex-string to a number via sscanf

#include <stdio.h>

long atox(char *s)
{
     long n = 0L;
     sscanf(s,"%x",&n);
     return n;
}

