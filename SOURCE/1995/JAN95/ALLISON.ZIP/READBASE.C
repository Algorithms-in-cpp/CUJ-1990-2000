LISTING 10 - Uses strtol() to read numbers in different bases

#include <stdio.h>
#include <stdlib.h>

main()
{
    char *input = "101 123 45678 90abc g";
    char *nextp = input;
    long bin, oct, dec, hex, beyond;

    bin = strtol(nextp,&nextp,2);
    oct = strtol(nextp,&nextp,8);
    dec = strtol(nextp,&nextp,10);
    hex = strtol(nextp,&nextp,16);
    beyond = strtol(nextp,&nextp,17);

    printf("bin = %ld\n",bin);
    printf("oct = %lo\n",oct);
    printf("dec = %ld\n",dec);
    printf("hex = %lx\n",hex);
    printf("beyond = %ld\n",beyond);
    return 0;
}

/* Output: */
bin = 5
oct = 123
dec = 45678
hex = 90abc
beyond = 16

