LISTING 6 - Outline of a file viewing program that illustrates file positioning

/* view.c:  A simple 4-way-scrolling file browser */

/* cls(), display(), read_a_screen() omitted... */

main(int argc, char *argv[])
{
    fpos_t top_pos, stk_[MAXSTACK];
    /* Details omitted... */

top:
    /* Display initial screen */
    rewind(f);
    fgetpos(f,&top_pos);
    /* Details omitted... */

    for (;;)
    {
        switch(c = toupper(getchar()))
        {
            case 'D':   /* Display the next screen */
                if (!feof(f))
                {
                    PUSH(top_pos);
                    fgetpos(f,&top_pos);
                    read_a_screen(f);
                    display(file);
                }
                break;

            case 'U':   /* Display the previous screen */
                if (stkptr_ > 0)
                {
                    top_pos = POP();
                    fsetpos(f,&top_pos);
                    read_a_screen(f);
                    display(file);
                }
                break;

            case 'T':   /* Display first screen */
                stkptr_ = 0;
                goto top;

            case 'B':   /* Display last screen */
                while (!feof(f))
                {
                    PUSH(top_pos);
                    fgetpos(f,&top_pos);
                    read_a_screen(f);
                }
                display(file);
                break;

            case 'Q':   /* Quit */
                cls();
                return EXIT_SUCCESS;
        }
        /* Details omitted... */
    }
}

