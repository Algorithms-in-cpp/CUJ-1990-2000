LISTING 11 - An even better version of atox() using strtol()

#include <stdlib.h>

long atox(char *s)
{
    return strtol(s,NULL,16);
}

