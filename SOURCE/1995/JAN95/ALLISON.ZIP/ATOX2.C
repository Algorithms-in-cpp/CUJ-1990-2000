LISTING 2 - A portable version of Listing 1

#include <ctype.h>
#include <assert.h>
#include <string.h>

long atox(char *s)
{
     char xdigs[] = "0123456789ABCDEF";
     long sum;

     assert(s);

     /* Skip whitespace */
     while (isspace(*s))
          ++s;

     /* Do the conversion */
     for (sum = 0L; isxdigit(*s); ++s)
     {
          int digit = strchr(xdigs,toupper(*s)) - xdigs;
          sum = sum*16L + digit;
     }

     return sum;
}

