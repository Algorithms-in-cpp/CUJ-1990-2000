LISTING 4 - A Function that copies a file via character I/O

/* copy1.c */
#include <stdio.h>

int copy(FILE *dest, FILE *source)
{
    int c;

    while ((c = getc(source)) != EOF)
        if (putc(c,dest) == EOF)
            return EOF;
    return 0;
}

