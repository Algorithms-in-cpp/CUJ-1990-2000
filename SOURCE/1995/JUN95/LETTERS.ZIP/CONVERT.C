/*
** Use a C programming trick here to increase
** performance. By casting the value as a
** character pointer and then subscripting, we
** can access the individual bytes in an long
** or short integer.
*/
#define ByteNo(x,y) \
        (((char *) (x))[(y)])

void swap_long_bytes( long *theLong )
{
        register char tempChar;
        
        /* swap bytes 0 and 3 */
        tempChar = ByteNo(theLong,0);
        ByteNo(theLong,0) = ByteNo(theLong,3);
        ByteNo(theLong,3) = tempChar;
        
        /* swap bytes 1 and 2 */
        tempChar = ByteNo(theLong,1);
        ByteNo(theLong,1) = ByteNo(theLong,2);
        ByteNo(theLong,2) = tempChar;
}

void swap_short_bytes( short *theShort )
{
        register char tempChar;

        /* swap bytes 0 and 1 */
        tempChar = ByteNo(theShort,0);
        ByteNo(theShort,0) = ByteNo(theShort,1);
        ByteNo(theShort,1) = tempChar;
}

