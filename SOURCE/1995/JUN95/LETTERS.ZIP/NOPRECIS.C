// The computer lie.
// Joe McCarty
// The problem with expressing an infinite
// quantity of numbers in a finite machine.
// Look at the program and predict the results.
// Then try running the program.

#include <stdio.h>
#include <math.h>

void test(int flag){
double x=4.999999999;
int exp=0;
printf("x= %20.18f\n",x);        //The original number
while(x<1000.0){x=x*10.0;exp--;} //Adjust for truncation
                                 //tion or rounding
while(x>10000.0){x=x/10;exp++;}
if(flag)x=(double)(int)x;       //Truncate
if(!flag)x=(double)(int)(x+.5); //Round
printf("x= %20.18f\n",x);       //Show result
x=x*pow(10.0,exp);              //Back to original exponent
printf("x= %20.18f\n\n",x);       //Show result
}//end test

void main(){
 test(0);
 test(1);
}//end main

/*
x= 4.999999998999999920
x= 5000.000000000000000000
x= 5.000000000000000000

x= 4.999999998999999920
x= 4999.000000000000000000
x= 4.998999999999999670
*/ 

