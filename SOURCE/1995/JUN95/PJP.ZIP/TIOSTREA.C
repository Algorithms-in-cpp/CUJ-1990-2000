------------- Listing 3: The file tiostrea.c ------------------


// test <iostream>
#include <assert.h>
#include <iostream>
#include <iostream>

int main()
    {       // test basic workings of iostream definitions
    assert(cin.good() && cin.exceptions() == ios::goodbit
        && cin.flags() == (ios::skipws | ios::dec)
        && cin.precision() == 6 && cin.width() == 0
        && cin.fill() == ' ');
    assert(cout.good() && cout.exceptions() == ios::goodbit
        && cout.flags() == (ios::skipws | ios::dec)
        && cout.precision() == 6 && cout.width() == 0
        && cout.fill() == ' ');
    assert(cerr.good() && cerr.exceptions() == ios::goodbit
        && cerr.flags()
            == (ios::skipws | ios::dec | ios::unitbuf)
        && cerr.precision() == 6 && cerr.width() == 0
        && cerr.fill() == ' ');
    assert(clog.good() && clog.exceptions() == ios::goodbit
        && clog.flags() == (ios::skipws | ios::dec)
        && clog.precision() == 6 && clog.width() == 0
        && clog.fill() == ' ');
    cout << "Can write on streams:" << endl;
    cout << "\tcout" << endl;
    cerr << "\tcerr" << endl;
    clog << "\tclog" << endl;
    assert(cout.good());
    assert(cerr.good());
    assert(clog.good());
    cout << "SUCCESS testing <iostream>" << endl;
    return (0);
    }

