#include <stdio.h>
#include <string.h>
int ssFind(int n, char *txt, int m, char *pat)
{ int nmatch = 0;
  char *cp;
  cp = txt;
  while (cp = strstr(cp, pat))
  { printf("%d\n",cp-txt);
    nmatch++;
    cp++;
  }
  return(nmatch);
}
Figure 4. String searching function using C library function strstr().

