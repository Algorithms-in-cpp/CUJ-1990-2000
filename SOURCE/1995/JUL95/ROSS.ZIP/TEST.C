#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define MB 400000
#define MP 256
#define NCOPY 3
char *txtbuf;
int xxxFind(int n, char *txt, int m, char *pat);
main(int argc, char **argv)
{
  char patbuf[MP];
  FILE *in;
  int i, m, n, t0, t1;
  int nmatch = 0;
  if (argc < 3)
  { fprintf(stderr,"usage: %s pattern file\n",argv[0]);
    exit(0);
  }
  if ((in = fopen(argv[2], "r")) == NULL)
  { fprintf(stderr,"cannot open input file: %s\n",argv[2]);
    exit(0);
  }
  strcpy(patbuf, argv[1]);
  m = strlen(patbuf);
  txtbuf = malloc(NCOPY*MB);
  n = 0;
  for (i=0; i<NCOPY; i++)
  { n += fread(txtbuf+n, sizeof(char), MB, in);
    rewind (in);
  }
  close(in);
  t0 = clock();
  nmatch = xxxFind(n, txtbuf, m, patbuf);
  t1 = clock() - t0;
  printf("%d matches took %.3f\n", nmatch, (float)t1/CLOCKS_PER_SEC);
}
Figure 2. Main program for testing string searching functions.
