#include <stdio.h>
int bfFind(int n, char *txt, int m, char *pat)
{ 
  int i, j, k, lim;
  int nmatch = 0;
  lim = n - m + 1;
  i = 0;
  while (i<lim) {
    k = i;
    for (j=0; j<m && txt[k] == pat[j]; j++)
       k++;
    if (j == m) {
      nmatch++;
      printf("%d \n", i);
      i += m;
    }
    else
      i++;
  }
  return(nmatch);
}
