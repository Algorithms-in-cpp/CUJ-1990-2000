#include <stdio.h>
#include <string.h>
int fcFind(int n, char *txt, int m, char *pat)
{ int i, j, k;
  int nmatch = 0;
  char *cp;
  cp = strchr(txt, pat[0]);
  while (cp)
  { i = cp - txt;
    k = i;
    for (j=0; j<m && txt[k] == pat[j]; j++)
 k++;
    if (j == m)
    { nmatch++;
 printf("%d \n", i);
 cp = strchr(txt+i+m, pat[0]);
    }
    else
 cp = strchr(txt+i+1, pat[0]);
  }
  return(nmatch);
}
Figure 3. First character string searching function.

