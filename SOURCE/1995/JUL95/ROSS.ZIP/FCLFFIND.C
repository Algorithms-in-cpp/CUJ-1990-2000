#include <stdio.h>
#include <string.h>
int fclfFind(int n, char *txt, int m, char *pat, int pos)
{ int i, j, k;
  int nmatch = 0;
  char *cp;
  cp = strchr(txt, pat[pos]);
  while (cp)
  { i = cp - txt;
    k = i - pos;
    for (j=0; j<m && txt[k] == pat[j]; j++)
 k++;
    if (j == m)
    { nmatch++;
 printf("%d \n", i-pos);
 cp = strchr(txt+i+m, pat[pos]);
    }
    else
 cp = strchr(txt+i+1, pat[pos]);
  }
  return(nmatch);
}
Figure 5. First character, low frequency string searching function.

