#include <stdio.h>
#define ALPHABETSZ 128
#define PATGRD 0xfe
#define TXTGRD 0xff
static int d[ALPHABETSZ];
void bmhInit(char *txt, int m, char *pat)
{ int i;
  /* initialize */
  pat[0] = PATGRD;
  txt[0] = TXTGRD;
  for (i=0; i<ALPHABETSZ; i++)
    d[i] = m;
  for (i=1; i<m; i++)
    d[pat[i]] = m - i;
}
int bmhFind(int n, char *txt, int m, char *pat)
{ int i, j, k;
  int nmatch = 0;
  i = m;
  while (i <= n)
  { k = i;
    for (j=m; txt[k] == pat[j]; j--)
       k--;
    if (j == 0) {
      nmatch++;
      printf("%d \n", k);
    }
    i += d[txt[i]];
  }
  return(nmatch);
}
