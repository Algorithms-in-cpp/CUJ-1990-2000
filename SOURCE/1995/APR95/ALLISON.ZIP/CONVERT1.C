LISTING 1 - Illustrates the need for function prototypes

/* convert1.c */
#include <stdio.h>

main()
{
    dprint(123);
    dprint(123.0);
    return 0;
}

dprint(d)
double d;
{
    printf("%f\n",d);
}

/* Output:
0.000000
123.000000
*/

