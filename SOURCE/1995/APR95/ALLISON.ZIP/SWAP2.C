LISTING 9 - A function template for swap()

//swap2.c 
#include <iostream.h>
#include "complex.h"

template<class T>
void swap(T &x, T &y)
{
    T temp = x;
    x = y;
    y = temp;
}

main()
{
    int i = 1, j = 2;
    swap(i,j);
    cout << "i == " << i << ", j == " << j << endl;

    double x = 3.0, y = 4.0;
    swap(x,y);
    cout << "x == " << x << ", y == " << y << endl;

    char *s = "hi", *t = "there";
    swap(s,t);
    cout << "s == " << s << ", t == " << t << endl;

    complex c1(5,6), c2(7,8);
    swap(c1,c2);
    cout << "c1 == " << c1 << ", c2 == " << c2 << endl;
    return 0;
}

// Output:
i == 2, j == 1
x == 4, y == 3
s == there, t == hi
c1 == (7,8), c2 == (5,6)

