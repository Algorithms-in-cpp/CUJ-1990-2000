LISTING 5 - Illustrates program linkage (see also Listing 6)

void f(int);

main()
{
    f(1);
    return 0;
}

