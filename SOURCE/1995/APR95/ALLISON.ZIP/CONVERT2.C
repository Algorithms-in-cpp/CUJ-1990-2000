LISTING 2 - Illustrates automatic conversion via function
prototypes

/* convert2.c */
#include <stdio.h>

void dprint(double);

main()
{
    dprint(123);
    dprint(123.0);
    return 0;
}

void dprint(double d)
{
    printf("%f\n",d);
}

/* Output:
123.000000
123.000000
*/

