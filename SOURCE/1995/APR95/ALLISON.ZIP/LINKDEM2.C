LISTING 6 - A function intended to link with Listing 5

#include <stdio.h>

void f(double x)
{
    printf("f: %f\n",x);
}

