/* ************************************ */
/* Remote Procedure Call (RPC) functions for NetBios */
/* Copyright AJB Beddow 27-Jul-93 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <ctype.h>
#include "netfn.h"

/* Pointer to list of Net Name descriptors */
struct netrpcserver *netrpcserverlist = NULL ;

/* Note there is only one client (master) per machine */
/* Client net id */
int masterid = -1 ;  
/* Client name */
char mastername[18] ;

/* Error Messages */
char *errmes1 = "Net Bios not detected - exiting\n" ;
/* Net Bios Error Messages */
char *neterrmess[] = {
	"No error",
        "Illegal Buffer length",
        "",
        "Invalid Command",
        "",
        "Time out",
        "Message Incomplete",
        "",
        "Invalid local session number",
        "Out of resources",
        "Session closed",
        "Command cancelled",
        "",
        "Duplicate local name",
        "Name table full",
        "Delete name completed with session in progress",
        "",
        "Local session table full",
        "Remote computer not listening",
        "Invalid name number",
        "Name not found",
        "Name not found or * in remote name field",
        "Name already exists on network",
        "Name was deleted",
        "Remote connection lost",
        "Name conflict",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "Interface busy",
        "Too many commands issued",
        "Invalid adapter number (LANA)",
        "Command completed before cancel",
        "",
        "Invalid cancel command" } ;

