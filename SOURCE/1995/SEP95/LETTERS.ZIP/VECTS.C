/* Listing 2: d2.asm */

/********User modified function**
*********for getvect))**********/
void interrupt(*getv(int intnum))
  (__CPPARGS)
{
long old=0;

asm{
    CLI;   /* Disable intrpts */
    PUSH AX;     /* Save regs */
    PUSH BX
    PUSH DS

;   /* Int number passed by
;      function call          */

    MOV BX, intnum;
    SHL BX,2;

;   /* Zero the data segment to
;      point to vector table  */

    XOR AX,AX
    MOV DS,AX
    MOV AX,[BX]

;   /* Get low word of vector */

    MOV WORDPTR old,AX
    MOV AX,[BX+2]

;   /* Get high wrd of vector */

    MOV WORDPTR old+2,AX
    POP DS; /*  Restore regs  */
    POP BX
    POP AX
    STI;    /* Enable intrpts */
    }
(long) oldhandler 
   = old:  /* Klunky, but it 
              works and avoids 
              type mismatches */

return oldhandler;
}
/***User modified function******
****for setvect() *************/
void 
setv(int, 
     void interrupt(*3)_CPPARGS))
{
asm{
    CLI
    PUSH AX; /* Save regs */
    PUSH BX; /* on stack
    PUSH DS
    PUSH BP

;   /* The zero segment is used
;      for the interrupt vector
;      table                   */

    XOR AX,AX
    MOV DS,AX

;   /* Get the interrupt number
;      from the calling program
;      into BX(X4)             */

    MOV BX,[BP+04]
    SHL BX,2

;   /* Use it to place the low
;      word                    */
    MOV AX,[BP+06]
    MOV [BX],AX

;   /* then place the high wrd */
    
    MOV AX,[BP+08]

;   /* (Turbo debugger 4.02
;       doesn't show this
;       happening, even with
;       unmodified Borland
;       example                */ 
    MOV [BX+2],AX
    POP BP
    POP DS
    POP BX; /* Restore regs    */
    POP AX 
    STI; /* Enable interrupts. */
    }
return
}


