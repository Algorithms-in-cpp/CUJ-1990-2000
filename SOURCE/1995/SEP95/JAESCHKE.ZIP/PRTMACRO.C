------------------- Listing 3: Printing Macro Names for Locales -------

#include <<locale.h>><R>
#include "locnames.h"<R>
#include <<stdio.h>><R>
<R>
main()<R>
{<R>
	char *ploc_str;<R>
<R>
	ploc_str = setlocale(LC_ALL, LOC_German);<R>
	if (ploc_str == NULL) {<R>
		printf("Can't establish locale %s\n", STR(LOC_German));<R>
		return 0;<R>
	}<R>
<R>
	printf("Established locale %s\n", STR(LOC_German));<R>
<R>
	return 0;<R>
}

