-------------- Listing 1: A Simple Example ---------------

#include <<locale.h>><R>
#include <<stdio.h>><R>
#include <<ctype.h>><R>
#include <<time.h>><R>
<R>
main()<R>
{<R>
	char locale[31];<R>
	char *ploc_str;<R>
	int c;<R>
	time_t system_time;<R>
	char time_text[81];<R>
<R>
	printf("Enter locale name: ");<R>
/*1*/	scanf("%30s%*c", locale);<R>
<R>
/*2*/	ploc_str = setlocale(LC_ALL, locale);<R>
	if (ploc_str == NULL) {<R>
		printf("Can't establish locale \"%s\"\n", locale);<R>
		return 0;<R>
	}<R>
<R>
	printf("Established locale \"%s\"\n", locale);<R>
<R>
	printf("Enter a single character: ");<R>
/*3*/	c = getchar();<R>
<R>
/*4*/	printf("Character '%c' %s alphabetic\n", c,<R>
		isalpha(c) ? "is" : "is not");<R>
<R>
/*5*/	printf("The value 12.345 is written as %.3f\n", 12.345);<R>
<R>
	system_time = time(NULL);<R>
<R>
/*6*/	strftime(time_text, sizeof(time_text), "%x %A %B %d\n",<R>
		localtime(&system_time));<R>
	printf(time_text);<R>
<R>
	return 0;<R>
}

