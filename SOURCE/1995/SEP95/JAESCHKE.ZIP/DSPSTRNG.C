---------------------- Listing 4: Displaying Some Locale Strings --------

#include <<stdio.h>><R>
#include <<locale.h>><R>
#include "locnames.h"<R>
<R>
main()<R>
{<R>
/*1*/	printf("|%s|\n", setlocale(LC_ALL,   NULL));<R>
/*2*/	printf("|%s|\n", setlocale(LC_CTYPE, LOC_French));<R>
/*3*/	printf("|%s|\n", setlocale(LC_TIME,  NULL));<R>
/*4*/	printf("|%s|\n", setlocale(LC_ALL,   NULL));<R>
<R>
	return 0;<R>
}
