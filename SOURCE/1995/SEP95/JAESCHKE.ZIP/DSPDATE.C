-------------- Listing 5: Displaying Dates in Spanish ----------

void handle_dates()<R>
{<R>
	char *ploc_str;<R>
	char *ploc_save;<R>
<R>
/*1*/	ploc_str = setlocale(LC_TIME, NULL);<R>
/*2*/	ploc_save = malloc(strlen(ploc_str) + 1);<R>
/*3*/	strcpy(ploc_save, ploc_str);<R>
	printf("Saved current LC_TIME\n");<R>
<R>
/*4*/	setlocale(LC_TIME, LOC_Spanish);<R>
	printf("Established %s LC_TIME\n", STR(LOC_Spanish));<R>
<R>
	printf("Doing %s-specific date/time processing\n", STR(LOC_Spanish));<R>
<R>
/*5*/	setlocale(LC_TIME, ploc_save);<R>
	printf("Restored saved LC_TIME\n");<R>
	free(ploc_save);<R>
}
