-------------- Listing 6: Calling localeconv ---------------

#include <<stdio.h>><R>
#include <<locale.h>><R>
#include "locnames.h"<R>
<R>
main()<R>
{<R>
	struct lconv *pst;<R>
<R>
	setlocale(LC_ALL, LOC_French);<R>
	pst = localeconv();<R>
<R>
	printf("Locale: %s\n", STR(LOC_French));<R>
	printf("decimal_point:   %s\n", pst->>decimal_point);<R>
	printf("int_curr_symbol: %s\n", pst->>int_curr_symbol);<R>
<R>
	return 0;<R>
}
