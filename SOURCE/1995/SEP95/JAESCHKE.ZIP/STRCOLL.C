----------------- Listing 7: Calling strcoll --------------


#include <<stdio.h>><R>
#include <<string.h>><R>
#include <<locale.h>><R>
#include "locnames.h"<R>
<R>
main()<R>
{<R>
	char str1[6], str2[6];<R>
	int i;<R>
<R>
	if (setlocale(LC_ALL, LOC_French) == NULL) {<R>
		printf("Can't establish French locale\n");<R>
	}<R>
<R>
	printf("Enter two strings: ");<R>
	scanf("%5s %5s", str1, str2);<R>
<R>
	i = strcoll(str1, str2);<R>
	if (i == 0) {<R>
		printf("The strings are the same\n");<R>
	}<R>
	else if (i << 0) {<R>
		printf("%s << %s\n", str1, str2);<R>
	}<R>
	else {<R>
		printf("%s >> %s\n", str1, str2);<R>
	}<R>
<R>
	return 0;<R>
}
