//excerpt of file burrb.cpp
     
....
     
void BB_PCI20000::Wait(int clock,int counter,long timems)
{ 
  if ((clock<0)||(clock>=nclock)||(counter<0)||(counter>=ncounter))
    throw (
      CardError(
        "You are exceding the number of available devices"));
  Clock[clock]->Set(1,3,1); //  set 1kHz (1e3) 
  Clock[clock]->Start();
  int seconds=floor(timems/1000);
  int remainder=timems%1000;   //fraction of one second 
  for(int j=0;j<=seconds;++j)
  {
    long ms;
    // At the last second use the fraction 
    (j==seconds)? ms=remainder:ms=1000;
    Counter[counter]->Set(2,PRELOAD,false);  //no reset on read 
    Counter[counter]->Start();
    //now I must wait as long as the counter is ready to count
    while (Counter[counter]->Read() ==
           Counter[counter]->RetPreload()); 
    //now it's ready
    while (Counter[counter]->Read()<=ms); 
    Counter[counter]->Stop();
  }
}
     
....

