#include <constrea.h>
#include <stdio.h>
#include "wave.h"
#include "BurrB.h"

VCard *board1,*board2; //will rapresent Burr-Brown cards and sound card
constream outStream;   //used for output on the screen in console mode

unsigned int mainPage();
void CFGPage();
void AOPage();
void AIPage();
void CNTPage();
void CLKPage();
void OSCPage();
void ExcError(CardError);

void main()
{

  outStream.clrscr();
  outStream<<"\n\n        Program used to display polymorphism" <<endl;
  outStream<<"        in the costruction of a multi I/O system"<<endl;
  outStream<<"\n\n\n\n  press Enter.";
  getc(stdin);
  try
  {
    board1=new BB_PCI20000;
    board1->CreateConfig();

  }
  catch (CardError Error)
  {
    ExcError(Error); // the burr-brown cards doesn't work or is absent!
  }                  // the ExcError function is called
  try
  {
    board2=new Wave_device;
    board2->CreateConfig();

  }
  catch (CardError Error)
  {
    ExcError(Error);// The sound card doesn't exist!
  }


 while(int choose=mainPage())
 {
   switch(choose)
    {

     case 1:CFGPage();break;
     case 2:AOPage();break;
     case 3:AIPage();break;
     case 4:CNTPage();break;
     case 5:CLKPage();break;
     case 6:OSCPage();break;
    }
 } // end of while
delete board1;
delete board2;
}

unsigned mainPage()
{
  unsigned choose;
  outStream.clrscr();
  outStream<<"  \n\n    Choose an option\n\n";
  outStream<<" 1) view configuration\n";
  outStream<<" 2) use an analog output device\n";
  outStream<<" 3) use an analog input device\n";
  outStream<<" 4) use a counter device\n";
  outStream<<" 5) use a clock device\n";
  outStream<<" 6) use an oscillator device\n";
  outStream<<" 0) exit\n\n";
  outStream<<" Make your choice: ";
  cin>>choose;
  return choose;
}

void CFGPage()
{
 outStream.clrscr();
 outStream<<"\n    Your courrently available cards are:\n"<<endl;
 outStream<<" 1) "<<board1->IdCard()<<endl;
 outStream<<"    number of Analog outputs: "<<board1->RetAONumber()<<endl;
 outStream<<"    number of Analog inputs:  "<<board1->RetAINumber()<<endl;
 outStream<<"    number of counters:       "<<board1->RetCNTNumber()<<endl;
 outStream<<"    number of multi-counters: "<<board1->RetMCNTNumber()<<endl;
 outStream<<"    number of clocks:         "<<board1->RetCLKNumber()<<endl;
 outStream<<"    number of oscillators:    "<<board1->RetOSCNumber()<<endl;
 outStream<<"\n 2) "<<board2->IdCard()<<endl;
 outStream<<"    number of Analog outputs: "<<board2->RetAONumber()<<endl;
 outStream<<"    number of Analog inputs:  "<<board2->RetAINumber()<<endl;
 outStream<<"    number of counters:       "<<board2->RetCNTNumber()<<endl;
 outStream<<"    number of multi-counters: "<<board2->RetMCNTNumber()<<endl;
 outStream<<"    number of clocks:         "<<board2->RetCLKNumber()<<endl;
 outStream<<"    number of oscillators:    "<<board2->RetOSCNumber()<<endl;
 outStream<<"\n\n Press Enter."<<endl;
 getc(stdin);
 }

void AOPage()
{
   int AODev;  //number of device used
   float AOVolt;
   clrscr();
   outStream<<"\n\n  Which Analog Output would you like to use? ";
   cin>>AODev;
   outStream<<"\n  Insert the Voltage to produce: ";
   cin>>AOVolt;
   try
   {
    board1->WriteAO(AODev,AOVolt);
   }
    catch (CardError Error)
   {
   ExcError(Error);
   }
}

void AIPage()
{
   int AIDev;  //number of device used
   clrscr();
   outStream<<"\n\n  Which Analog Input would you like to read? ";
   cin>>AIDev;
   try
   {
    outStream<<"The analog input reads this value: "<<board1->ReadAI(AIDev)<<endl;
   }
     catch (CardError Error)
   {
  ExcError(Error);
   }
   outStream<<"\n\n\n\n  press Enter."<<endl;
   getc(stdin);
}

void CNTPage()
{
   int CNTDev;  //number of device used
   clrscr();
   outStream<<"\n\n  Which counter would you like to use? ";
   cin>>CNTDev;
   try
   {
     board1->StartCounter(CNTDev,2,0xffff,true);
     outStream<<"Press Enter to read counter,'0' to exit"<<endl<<endl;
      while(getc(stdin)!='0')
     {
      gotoxy(2,7);
      outStream<<"the counter reads:  "<<board1->ReadCounter(CNTDev)<<"       ";
     };
   }
   catch (CardError Error)
   {
     ExcError(Error);
   }
   outStream<<"\n\n\n\n  press Enter."<<endl;
   getc(stdin);
}

void CLKPage()
{
   int CLKDev;   //number of device used
   int mantissa; // the mantissa of the frequency
   short exp;    // the exponent of the frequency
   clrscr();
   outStream<<"\n\n  Which clock would you like to use? ";
   cin>>CLKDev;
   outStream<<"\nEnter frequency mantissa: ";
   cin>>mantissa;
   outStream<<"\nEnter frequency exponent: ";
   cin>>exp;

   try
   {
     board1->StartClock(CLKDev,mantissa,exp);
   }
   catch (CardError Error)
   {
   ExcError(Error);
   }
   outStream<<"\n\n\n\n  press Enter."<<endl;
   getc(stdin);
}


void OSCPage()
{
   int OSCDev;  //number of device used
   float OSCVolt;
   float OSCFreq;
   float OSCPhase;
   clrscr();
   outStream<<"\n\n  Which Oscillator would you like to use? ";
   cin>>OSCDev;
   outStream<<"\n  Insert the amplitude in Volt: ";
   cin>>OSCVolt;
   outStream<<"\n  Insert its frequency: ";
   cin>>OSCFreq;
   outStream<<"\n  Insert its phase: ";
   cin>>OSCPhase;
   try
   {
     board2->StartOsc(OSCDev,0,OSCFreq,OSCPhase,OSCVolt);
   }
    catch (CardError Error)
   {
    ExcError(Error);
   }
   outStream<<"\n\n\n\n  press Enter."<<endl;
   getchar();
}

void ExcError(CardError Error)
{
    constream errorWin;
    string ErrorStr=Error.RetMsg();
    errorWin.window(10,10,70,20);
    errorWin.clrscr();
    gotoxy(10,10);
    textattr(LIGHTRED);
    errorWin << "\n\n An exception was thrown:\n" <<ErrorStr.c_str()<<endl;
    errorWin<<"\n\n  press Enter."<<endl;
    getc(stdin);
    textattr(LIGHTGRAY);
    errorWin.clrscr();
}

