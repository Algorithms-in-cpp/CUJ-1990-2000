// Implementation of clock classes for the Burr_Brown
#include "CLK_BB.h"
#include "pciw.h"
#include <math.h>
// Modulo PCI 20007M

void CLK_PCI20007M::Start()
{
 RGEnable(RetSlot(),RetPos(),RetChn());
}

void CLK_PCI20007M::Stop()
{
 RGDisable(RetSlot(),RetPos(),RetChn());
}

void CLK_PCI20007M::Set(int mant,short esp,float duty_cycle)
{
 double freq=mant*pow10(esp);   //this is the frequency in Hz
 if ((freq>2e6)||(freq<2e-3))
       throw CardError("this frequency is out of range");
  if ((duty_cycle>1)||(duty_cycle<0))
     throw (CardError("this duty-cycle is unrealizable"));
  // n1 and n2 are special values to meet the requirements of this counter
 int n2=1+1.0/duty_cycle;
 int n1=8.0e6/(freq*n2);
 RGConfigure(RetSlot(),RetPos(),RetChn(),n1,n2,2);
}

CLK_PCI20007M::CLK_PCI20007M(int slotVal,int posVal,int chnVal) :
               VCLK(slotVal,posVal,chnVal)
{
}

CLK_PCI20007M::CLK_PCI20007M() : VCLK()
{
}

CLK_PCI20007M::~CLK_PCI20007M()
{
}

