
#include "vmod.h"

CardError::CardError(string message):msg(message){};

string CardError::RetMsg() {return msg;} ;


