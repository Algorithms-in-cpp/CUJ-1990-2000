#if !defined BURRB_H
#define BURRB_H
#include "vcard.h"

class BB_PCI20000 :public VCard //class for a Burr-Brown card
{
  public:
  BB_PCI20000();
  ~BB_PCI20000();

  //overloading of the virtual functions

  void CreateConfig();
  void ReadConfig();
  long ReadCounter(int i);
  void ReadMultiCounter(int i,unsigned long& data);
  float ReadAI(int i);
  void WriteAO(int i,float f);
  void Wait(int clock,int counter,long timems);
  void StartCounter(int i, int mode, long preload, bool reset);
  void StopCounter(int i);
  void StartMultiCounter(int i, int mode, long preload, bool reset);
  void StopMultiCounter(int i);
  void StartClock(int i,int mant,short esp);
  void StopClock(int i);
  // these types of modules aren't included in PCI_20000 serie boards
  void StartOsc(int i,int type,float freq,float phase,float amp);
  void StopOsc(int i);
};



#endif
