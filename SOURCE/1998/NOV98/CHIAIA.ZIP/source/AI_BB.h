// In questo header sono contenute le classi relative alle schede/moduli
// di input analogico della Burr_Brown

#include "vmod.h"

class AI_PCI20002M : public VAI
{
	public:
   AI_PCI20002M(int slotVal,int posVal,int chnVal);
   AI_PCI20002M();
   ~AI_PCI20002M();
   float Read();
   void SetRange(float low,float high);
   void GetRange(float *low,float *high);
   void SetResolution(float res);
   float GetResolution();

   private:
   int range_BB;
};
