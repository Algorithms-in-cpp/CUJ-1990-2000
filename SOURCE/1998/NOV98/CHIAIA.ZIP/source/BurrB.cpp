#include "BurrB.h"
#include "pciw.h"
#include "AO_BB.h"
#include "AI_BB.h"
#include "CLK_BB.h"
#include "CNT_BB.h"
#include "booldef.h"
#include <stdio.h>
#include <math.h>




// Burr-Brown cards

#define PRELOAD 0xffff
#define START_ADDR 16

BB_PCI20000::BB_PCI20000():VCard()
{
 sprintf(card_ID,"Burr-Brown PCI20000");

}

BB_PCI20000::~BB_PCI20000()
{

  int i;
  for(i=0;i<nAO;i++)
     {
      AnalogOutput[i]->Write(0);
      delete AnalogOutput[i];
     }
  for(i=0;i<nAI;i++)
      delete AnalogInput[i];
  for(i=0;i<nclock;i++)
      delete Clock[i];
  for(i=0;i<ncounter;i++)
      delete Counter[i];
  for(i=0;i<multiCounter;i++)
      delete MultiCounter[i];

  SWReset();
}

void BB_PCI20000::ReadConfig()
{
    //not yet implemented
}



void BB_PCI20000::CreateConfig()
{
 int nBoards;
 int c; // channal number
 ISASearchBoardTypeArray Boardpt;

 if (SWInit())
    throw (CardError("I can not load the software drivers for BB cars"));

 //we place here the Include for all the modules on the boards
 Include1C();
 Include2M();
 Include7M();
 Include6M();

 //find the number of boards and carriers
 if (SlotSearchISA(&nBoards,&Boardpt))
       throw (CardError("I can not find a BB board"));

 for (int i=0;i<nBoards;i++)
  {

     //assign the slot number to the carriers
     if (SlotAssign(i+START_ADDR,Boardpt[i].segment))
            throw (CardError("I encountered problems with some slot"));
  }

 if(HWInit()) throw(CardError("Hardware problems"));

 for (int i=0;i<nBoards;i++)
  {
     ModInfoTypeArray moduli; //Array of information on each module
     //retrieve info from the slot
    if( SlotInquire(i+START_ADDR,&moduli))
         throw(CardError("Hardware problems"));
     for(int j=0;j<4;j++)
     {
     		if (moduli[j].present) //there is one module in this position!
        { 	switch(moduli[j].id)
            {
             case 255:    // PCI-20002M-1 12Bit A/D Single-ended
                for(c=0;c<16;c++)
                {
                  VAI* aip=new AI_PCI20002M(i+START_ADDR,j,c);
                  AnalogInput.push_back(aip);
                  AnalogInput[nAI]->SetRange(-10,10);
                	nAI++;
                }
            	 break;
            case 254:    // PCI-20002M-1 12Bit A/D Differetial
                for(c=0;c<8;c++)
                {
                  VAI* aip=new AI_PCI20002M(i+START_ADDR,j,c);
                	AnalogInput.push_back(aip);
                	AnalogInput[nAI]->SetRange(-10,10);
                	nAI++;
                }
            	 break;
            case 226:    //PCI-20006M-1 16bit Analog output 1 Chn
                {
                 VAO* aop=new AO_PCI20006M(i+START_ADDR,j,c);
                 AnalogOutput.push_back(aop);
                 AnalogOutput[nAO]->SetRange(-10,10);
                 nAO++;
                }
                 break;

            case 227:    //PCI-20006M-2 16bit Analog output 2 Chn
                for(c=0;c<2;c++)
                {
                   VAO* aop=new AO_PCI20006M(i+START_ADDR,j,c);
                   AnalogOutput.push_back(aop);
                   AnalogOutput[nAO]->SetRange(-10,10);
                   nAO++;
                }
                 break;
				case 234: // contatori
               {
                for(c=0;c<4;c++)
                {
                   VCNT* cntp=new CNT_PCI20007M(i+START_ADDR,j,c);
						 Counter.push_back(cntp);
                   Counter[ncounter]->Set(2);  //2=countdown mode
                   ncounter++;
                }
                VCLK* clkp=new CLK_PCI20007M(i+START_ADDR,j,0);
                Clock.push_back(clkp);
                nclock++;
                VMCNT* mcntp=new MCNT_PCI20007M(i+START_ADDR,j,0);
                MultiCounter.push_back(mcntp);
                MultiCounter[multiCounter]->Set(2); //2=countdown mode
                multiCounter++;
               }
                break;
            }//end of switch
        }// end of 'if module is present'
     }// end of 'for' over the modules of a board
 }//end of 'for' over the boards
ison=true; // Cards all right
}


long BB_PCI20000::ReadCounter(int i)
{
  if ((i<0)||(i>=ncounter))
    throw  (CardError("You are exceding the number of available devices"));
 return Counter[i]->Read();
}

void BB_PCI20000::ReadMultiCounter(int i,unsigned long &data)
{
  if ((i<0)||(i>multiCounter))
    throw  (CardError("You are exceding the number of available devices"));
  MultiCounter[i]->MultiRead(&data);
}

float BB_PCI20000::ReadAI(int i)
{
 if ((i<0)||(i>=nAI))
   throw  (CardError("You are exceding the number of available devices"));
 return AnalogInput[i]->Read();
}

void BB_PCI20000::WriteAO(int i,float f)
{
 if ((i<0)||(i>=nAO))
   throw  (CardError("You are exceding the number of available devices"));
 AnalogOutput[i]->Write(f);
}

void BB_PCI20000::Wait(int clock,int counter,long timems)
{  //see the article for more details on this function
  if ((clock<0)||(clock>=nclock)||(counter<0)||(counter>=ncounter))
    throw  (CardError("You are exceding the number of available devices"));
  Clock[clock]->Set(1,3,1); //  set 1kHz (1e3)
  Clock[clock]->Start();
  int seconds=floor(timems/1000);
  int remainder=timems%1000;   //fraction of one second
  for(int j=0;j<=seconds;++j)
  {
  		long ms;
      // At the last second use the fraction
      (j==seconds)? ms=remainder:ms=1000;
      Counter[counter]->Set(2,PRELOAD,false);  //no reset on read
      Counter[counter]->Start();
//now I must wait as long as the counter is ready to count
      while (Counter[counter]->Read()==Counter[counter]->RetPreload());
//now it's ready
      while (Counter[counter]->Read()<=ms);
      Counter[counter]->Stop();
  }
}

void BB_PCI20000::StartCounter(int i, int mode, long preload, bool reset)
{
  if ((i<0)||(i>=ncounter))
     throw  (CardError("You are exceding the number of available devices"));
  Counter[i]->Set(mode,preload,reset);
  Counter[i]->Start();
}

void BB_PCI20000::StopCounter(int i)
{
  if ((i<0)||(i>=ncounter))
     throw  (CardError("You are exceding the number of available devices"));
  Counter[i]->Stop();
}

void BB_PCI20000::StartMultiCounter(int i, int mode, long preload, bool reset)
{
  if ((i<0)||(i>=multiCounter))
    throw  (CardError("You are exceding the number of available devices"));
  MultiCounter[i]->Set(mode,preload,reset);
  MultiCounter[i]->Start();
}

void BB_PCI20000::StopMultiCounter(int i)
{
  if ((i<0)||(i>=multiCounter))
     throw  (CardError("You are exceding the number of available devices"));
  MultiCounter[i]->Stop();
}

void BB_PCI20000::StartClock(int i,int mant,short esp)
{
  if ((i<0)||(i>=nclock))
     throw  (CardError("You are exceding the number of available devices"));
  Clock[i]->Set(mant,esp,1);  //sets the duty-cycle to 1
  Clock[i]->Start();
}

void BB_PCI20000::StopClock(int i)
{
 if ((i<0)||(i>=nclock))
     throw  (CardError("You are exceding the number of available devices"));
 Clock[i]->Stop();
}

void BB_PCI20000::StartOsc(int,int,float,float,float)
{
   throw (CardError("No oscillator is present"));
}

void BB_PCI20000::StopOsc(int)
{
   throw (CardError("No oscillator is present"));
}

