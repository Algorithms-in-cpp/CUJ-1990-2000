// In questo header sono contenute le classi relative alle uscite
// analogiche delle schede audio

#include "vmod.h"

class AO_WV : public VAO
{
	public:
   AO_WV(int slotVal,int posVal, int chnVal);
   AO_WV();
   ~AO_WV();
   void Write(float val);
   void SetRange(float low,float high){};
   void GetRange(float *low,float *high);
   void SetResolution(float res){};
   float GetResolution();

};
