// In questo header sono contenute le classi relative alle schede/moduli
// di clock della Burr_Brown
#include "vmod.h"

class CLK_PCI20007M : public VCLK
{
	public:
   CLK_PCI20007M(int slotVal,int posVal,int chnVal);
   CLK_PCI20007M();
   ~CLK_PCI20007M();
   void Start();
   void Stop();
   void Set(int mant,short esp, float duty_cycle);

};
