#include "vmod.h"

class CNT_PCI20007M : public VCNT
{
	public:
   CNT_PCI20007M(int slotVal,int posVal,int chnVal);
   CNT_PCI20007M();
   ~CNT_PCI20007M();
   long Read();
   void Start();
   void Stop();
   void Set(unsigned int mode,long preload,bool reset);

   private:
   unsigned int mode;
   bool reset;
};

class MCNT_PCI20007M : public VMCNT
{
	public:
   MCNT_PCI20007M(int slotVal,int posVal,int chnVal);
   MCNT_PCI20007M();
   ~MCNT_PCI20007M();
   void MultiRead(unsigned long *data);
   void Start();
   void Stop();
   void Set(unsigned int mode,long preload,bool reset);

   private:
   unsigned int mode;
   bool reset;
};

