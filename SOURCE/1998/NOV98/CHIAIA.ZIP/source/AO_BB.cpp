// Implementation of analog output  classes of Burr_Brown
#include "AO_BB.h"
#include "pciw.h"


// module PCI 20006M
void AO_PCI20006M::Write(float val)
{
	val +=RetOffset();          //adds the offset
	val *=0x7fff*RetConvFact()/10; //converts to an integer
   if ((val>32767)||(val<-32768))
      throw (CardError("this value is out of range"));
   AOWrite(RetSlot(),RetPos(),RetChn(),(int)val)
   ;
}

void AO_PCI20006M::SetRange(float low,float high)
{ if (low>0)
   {  lowHwd=0;
      highHwd=10;
      AOConfigure(RetSlot(),RetPos(),RetChn(),UNIPOLAR_10);
   }
  else
    { if ((low<-5)||(high>5))
         {lowHwd=-10;
          highHwd=10;
          AOConfigure(RetSlot(),RetPos(),RetChn(),BIPOLAR_20);
         }
      else
         { lowHwd=-5;
           highHwd=5;
           AOConfigure(RetSlot(),RetPos(),RetChn(),BIPOLAR_10);
         }
    }
}
void AO_PCI20006M::GetRange(float *low,float *high)
{
   *low=lowHwd;
   *high=highHwd;
}

void AO_PCI20006M::SetResolution(float)
{
// we can't set resolution with this board because it's fixed from hardware
// configuration
}

float AO_PCI20006M::GetResolution()
{
  //resolution is assigned by the Hardware  depending from the range
  //with the following function (where 0xffff means a 16 bit subdivision)
  resHwd=(highHwd-lowHwd)/(float)0xffff;
  return resHwd;
}

AO_PCI20006M::AO_PCI20006M() : VAO()
{
   SetOffset(0); //inizializes the offset and the conversion factor
   SetConvFact(1);
}

AO_PCI20006M::AO_PCI20006M(int slotVal,int posVal,int chnVal) :
          VAO(slotVal,posVal,chnVal)
{
   SetOffset(0); //inizializes the offset and the conversion factor
   SetConvFact(1);
}


AO_PCI20006M::~AO_PCI20006M()
{
  // turns all the outpts off to avoid short-circuits
   AOWrite(RetSlot(),RetPos(),RetChn(),0);
}

// end of PCI 20006M module