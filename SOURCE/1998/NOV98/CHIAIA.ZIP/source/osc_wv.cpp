// Implementation of the Oscillators for sound cards

#include <math.h>
#include "OSC_WV.h"
#include <windows.h>
#include <mmsystem.h>

#define FILE_LENGTH 0x0002B13C  //this is the lenght of the audio file
#define SOUND_BYTES 176400   //44100 words per channel (two channels)
#define SAMPLES_PER_SECOND 44100

char wave[FILE_LENGTH];
void OSC_WV::Start()
  {
    sndPlaySound(wave,SND_MEMORY | SND_ASYNC | SND_LOOP);
  }
void OSC_WV::Stop()
  {
    Set(0,0,0,0);// turns the sound cards off
  }

void OSC_WV::Set(int type, float freq,float phase, float amp)
{
  // type is not yet implemented and only a sine wave can be produced
   int data,c;

  if ((freq<0)||(freq>SAMPLES_PER_SECOND/2))
    //accordingly to Shannon's theorem your maximum frequency is half of your
    //sample rate.
     throw CardError("You are exceding available device capabilities");
  if ((amp<0)||(amp>.75))
     throw CardError("You are exceding available device capabilities");
  amp *=0x7fff*RetConvFact()/.75; //converts the voltage in a 16 bit number
  if (RetChn()==0)  //left channel
   {
     for (c=0;c<SOUND_BYTES-3;c+=4)
     {
      data=(int)(amp*(sin(2*M_PI*freq*c/SAMPLES_PER_SECOND+phase)));
      wave[44+c]=(char)data;         //this is the less significant byte
      wave[45+c]=(char)(data>>8);    //this is the most significant byte
     }
   }
  if (RetChn()==1)  //right channel.
   {
       for (c=0;c<SOUND_BYTES-1;c+=4)
     {
      data=(int)(amp*(sin(2*M_PI*freq*c/SAMPLES_PER_SECOND+phase)));
      wave[46+c]=(char)data;        //this is the less significant byte
      wave[47+c]=(char)(data>>8);    //this is the most significant byte
     }
   }
}


void OSC_WV::GetRange(float *low,float *high)
{
 *low=0;
 *high=.75; // max. amplitude is .75V
}

float OSC_WV::GetResolution()
{
   return .75/0x7fff;   // .75V are divided by 2^15 (15 bit resolution)
                        //(the 16th bit is used for sign)
}

OSC_WV::OSC_WV() : VOSC()
{
   SetConvFact(1);
}

OSC_WV::OSC_WV(int slotVal,int posVal,int chnVal) :
          VOSC(slotVal,posVal,chnVal)
{
   SetConvFact(1);
}


OSC_WV::~OSC_WV()
{
}

// end of sound card oscillator module