//check the version, if less than 5 use BOOL
#if __BORLANDC__<0x500
  #define bool BOOL
  #define true TRUE
  #define false FALSE
#endif
