// In this header are contained the classes for the oscillators of
// the sound cards

#include "vmod.h"

class OSC_WV : public VOSC
{
	public:
   OSC_WV(int slotVal,int posVal, int chnVal);
   OSC_WV();
   ~OSC_WV();
   void Start();
   void Set(int type,float freq,float phase,float amp);
   void Stop();
   void SetRange(float low,float high){};
   void GetRange(float *low,float *high);
   void SetResolution(float res){};
   float GetResolution();

};
