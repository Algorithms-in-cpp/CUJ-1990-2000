#include "wave.h"
#include "OSC_WV.h"
#include <windows.h>
#include <mmsystem.h>
#include <stdio.h>


#define FILE_LENGTH 0x0002B13C  // lenght of one second of a 44.1KHz 16 bit stereo
                               // wave file

 extern char wave[FILE_LENGTH]; //array that will be filled
 										  //with the samples

Wave_device::Wave_device():VCard()
{
 int i;
 FILE  *WaveFile = fopen("silence.wav", "rb");
 sprintf(card_ID,"Multimedia standard wave device");
 if (!WaveFile)
      throw CardError("I couldn't find: silence.wav");
 for (i=0;i<FILE_LENGTH;i++)  // reads the file
    wave[i]=(char)fgetc(WaveFile);
 fclose(WaveFile);
}

Wave_device::~Wave_device()
{
  for (int i=0;i<nOSC;i++)
   {
     Oscillator[i]->Set(0,0,0,0);// turn them off
     delete Oscillator[i];
   }
}

void Wave_device::ReadConfig()
{
// to be implemented
}

void Wave_device::CreateConfig()   // create the 2 oscillators
{
 VOSC* left=new OSC_WV(0,0,0);
 Oscillator.push_back(left);
 VOSC* right=new OSC_WV(0,0,1);
 Oscillator.push_back(right);
 nOSC+=2;
 sndPlaySound(wave,SND_MEMORY | SND_ASYNC | SND_LOOP);
}

void Wave_device::StartOsc(int i,int type,float freq,float phase,float amp)
{
  if ((i<0)||(i>=nOSC))
     throw CardError("You are exceding available devices");
  Oscillator[i]->Set(type,freq,phase,amp);
  Oscillator[i]->Start();

}
void Wave_device::StopOsc(int i)
{
  if ((i<0)||(i>=nOSC))
     throw CardError("You are exceding available devices");
  Oscillator[i]->Stop();
}

long Wave_device::ReadCounter(int)
{
 throw CardError("I don't have counter channels!");
}

void Wave_device::ReadMultiCounter(int,unsigned long& )
{
 throw CardError("I don't have multi-counter channels!");
}

float Wave_device::ReadAI(int)
{
  throw CardError("I don't have analog input channels!");

}

void Wave_device::WriteAO(int,float)
{
 throw CardError("I don't have analog output channels!");
}

void Wave_device::Wait(int,int,long)
{
 throw CardError("I don't have any wait device!");
}

void Wave_device::StartCounter(int,int,long,bool)
{
 throw CardError("I don't have conuter channels!");
}

void Wave_device::StopCounter(int)
{
 throw CardError("I don't have conuter channels!");
}

void Wave_device::StartMultiCounter(int,int,long,bool)
{
 throw CardError("I don't have multi-conuter channels!");
}

void Wave_device::StopMultiCounter(int)
{
 throw CardError("I don't have multi-conuter channels!");
}

void Wave_device::StartClock(int,int,short)
{
 throw CardError("I don't have clock channels!");
}

void Wave_device::StopClock(int)
{
 throw CardError("I don't have clock channels!");
}








