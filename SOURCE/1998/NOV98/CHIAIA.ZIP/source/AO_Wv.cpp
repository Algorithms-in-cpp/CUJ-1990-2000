// Implementazione delle classi di output analogico relativo a dispositivi
// audio
#include "pciw.h"
#include "OSC_WV.h"
#include <windows.h>
#include <mmsystem.h>

extern char* wave;

void OSC_WV::Start()
  {
    sndPlaySound(wave,SND_MEMORY | SND_ASYNC | SND_LOOP);
  }
void OSC_WV::Stop()
  {
    sndPlaySound(wave,SND_MEMORY | SND_ASYNC | SND_LOOP);
  }

void OSC_WV::Set(int type; float freq, float amp)
{
   int datap,datan;
   char LSBp,MSBp,LSBn,MSBn;
	amp +=RetOffset();          //ci somma l'offset
	val *=0x7fff*RetConvFact()/.75; //lo converte in intero
   datap=(int)val;
   LSBp=(char)datap;
   MSBp=(char)(datap>>8);
   datan=(int)-val;
   LSBn=(char)datan;
   MSBn=(char)(datan>>8);
   if (RetChn()==0)
   {
      wave[44]=LSBp;
      wave[45]=MSBp;
      wave[48]=LSBn;
      wave[49]=MSBn;
   }
   if (RetChn()==1)
   {
      wave[46]=LSBp;
      wave[47]=MSBp;
      wave[50]=LSBn;
      wave[51]=MSBn;
   }
   // se il canale e' diverso non esaegue nulla!

}


void OSC_WV::GetRange(float *low,float *high)
{
   // da implementare
}

float OSC_WV::GetResolution()
{
  // da implementare
}

OSC_WV::OSC_WV() : VOSC()
{
   SetOffset(0); //inizializza l'offset ed il fattore di conversione
   SetConvFact(1);
}

OSC_WV::OSC_WV(int slotVal,int posVal,int chnVal) :
          VOSC(slotVal,posVal,chnVal)
{
   SetOffset(0); //inizializza l'offset ed il fattore di conversione
   SetConvFact(1);
}


OSC_WV::~OSC_WV()
{
}

// fine modulo wave device