// In questo header sono contenute le classi relative alle schede/moduli
// di output analogico della Burr_Brown
#include "vmod.h"

class AO_PCI20006M : public VAO
{
	public:
   AO_PCI20006M(int slotVal,int posVal, int chnVal);
   AO_PCI20006M();
   ~AO_PCI20006M();
   void Write(float val);
   void SetRange(float low,float high);
   void GetRange(float *low,float *high);
   void SetResolution(float res);
   float GetResolution();

};
