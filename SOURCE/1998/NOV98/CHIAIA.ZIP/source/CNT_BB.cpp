#include "CNT_BB.h"
#include "pciw.h"

long CNT_PCI20007M::Read()
{
 unsigned long data;
 unsigned status;
 CTR8254Read(RetSlot(),RetPos(),RetChn(),reset,&data,&status);
 return preload-data;

}

void CNT_PCI20007M::Start()
{
 CTR8254Enable(RetSlot(),RetPos(),RetChn());
}

void CNT_PCI20007M::Stop()
{
 CTR8254Disable(RetSlot(),RetPos(),RetChn());
}

void CNT_PCI20007M::Set(unsigned int mode_type,long preloadVal=0xffff,
                        bool resetVal=true)
{
	mode=mode_type;     // operating mode
   preload=preloadVal; // this is the value that is loaded into the counter
                       // before its start. We preset it to 0xffff because
                       // its usefull for count-down operating mode
   reset=resetVal;     // reset on read
   if (mode_type>5)
      throw (CardError("Unrecognized operating mode for this counter"));
   if ((preloadVal<0)||(preloadVal>0xffff))
      throw (CardError("this preload value is out of range"));
	CTR8254Configure(RetSlot(),RetPos(),RetChn(),preload,mode);
}

CNT_PCI20007M::CNT_PCI20007M(int slotVal,int posVal,int chnVal) :
           VCNT(slotVal,posVal,chnVal)
{
  mode=2;              // rate-generator is the default mode
  preload=0xffff;      // the counter is loaded with the maximum value
  reset=true;          // reset on read
}


CNT_PCI20007M::CNT_PCI20007M() : VCNT()
{
  mode=2;             // rate-generator is the default mode
  preload=0xffff;     // the counter is loaded with the maximum value
  reset=true;         // reset on read
}

CNT_PCI20007M::~CNT_PCI20007M()
{
}

void MCNT_PCI20007M::MultiRead(unsigned long *data)
{
 unsigned* status=new unsigned[4];
 CTR8254ReadGroup(RetSlot(),RetPos(),reset,data,status);
 delete [] status;
 for (int i=0;i<4;i++)
   data[i]=preload-data[i];
}

void MCNT_PCI20007M::Start()
{
 for (int i=0;i<4;i++)
   CTR8254Enable(RetSlot(),RetPos(),i);

}

void MCNT_PCI20007M::Stop()
{
 for (int i=0;i<4;i++)
   CTR8254Disable(RetSlot(),RetPos(),i);
}

void MCNT_PCI20007M::Set(unsigned int mode_type,long preloadVal=0xffff,
 								 bool resetVal=true)
{
   mode=mode_type;     // rate-generator is the default mode
   preload=preloadVal; // this is the value that is loaded into the counter
                       // before its start. We preset it to 0xffff because
                       // its usefull for count-down operating mode
   reset=resetVal;     // reset on read
   if (mode_type>5)
      throw (CardError("Unrecognized operating mode for this counter"));
   if ((preloadVal<0)||(preloadVal>0xffff))
      throw (CardError("this preload value is out of range"));
   for (int i=0;i<4;i++)
	  CTR8254Configure(RetSlot(),RetPos(),i,preload,mode);
}

MCNT_PCI20007M::MCNT_PCI20007M(int slotVal,int posVal,int chnVal) :
           VMCNT(slotVal,posVal,chnVal)
{
  mode=2;              // rate-generator is the default mode
  preload=0xffff;      // the counter is loaded with the maximum value
  reset=true;          // reset on read
}


MCNT_PCI20007M::MCNT_PCI20007M() : VMCNT()
{
  mode=2;              // rate-generator is the default mode
  preload=0xffff;      // the counter is loaded with the maximum value
  reset=true;          // reset on read
}

MCNT_PCI20007M::~MCNT_PCI20007M()
{
}

