#if !defined VCARD_H
# define VCARD_H
#include "vmod.h"
#pragma warn -csu
#pragma warn -pch
#include <vector>

using namespace std;

class VCard        //abstract class for generic card
{
 protected:
 int ncounter,nAI,nAO,nclock;  //number of counters, inputs, outputs,clocks
 int multiCounter;             //number of multicounters (syncronous counters)
 int nOSC;                     //number of independent oscillators
 char* card_ID;
 bool ison;    //false off, true on
 vector<VAO*> 	 AnalogOutput;
 vector<VAI*>	 AnalogInput;
 vector<VCNT*>  Counter;
 vector<VMCNT*> MultiCounter;
 vector<VCLK*>  Clock;
 vector<VOSC*>  Oscillator;

 public:
 VCard();
 virtual ~VCard();  //virtual because of polymorphic destruction

 char* IdCard(){return card_ID;};    		//return the card type
 int RetCNTNumber() {return ncounter;};
 int RetCLKNumber() {return nclock;};
 int RetAINumber()  {return nAI;};
 int RetAONumber()  {return nAO;};
 int RetMCNTNumber(){return multiCounter;};
 int RetOSCNumber() {return nOSC;};

 int IsOn(){return ison;};   //the card is on

 VAO* RetVAOPt(int i)    { return AnalogOutput[i];};
 VAI* RetVAIPt(int i)    { return AnalogInput[i];};
 VCNT* RetVCNTPt(int i)  {return Counter[i];};
 VMCNT* RetVMCNTPt(int i){return MultiCounter[i];};
 VCLK* RetVCLKPt(int i)  {return Clock[i];};
 VOSC* RetVOSCPt(int i)  {return Oscillator[i];};

 virtual void  CreateConfig()=0;
 virtual void  ReadConfig()=0;
 virtual long  ReadCounter(int i)=0;
 virtual void  ReadMultiCounter(int i,unsigned long& data)=0;
 virtual float ReadAI(int i)=0;
 virtual void  WriteAO(int i, float f)=0;
 virtual void  Wait(int clock,int counter,long timems)=0;//time in milliseconds
 virtual void  StartCounter(int i,int mode, long preload, bool reset)=0;
 virtual void  StopCounter(int i)=0;
 virtual void  StartMultiCounter(int i,int mode, long preload, bool reset)=0;
 virtual void  StopMultiCounter(int i)=0;
 virtual void  StartClock(int i,int mant,short esp)=0;
               // mant and esp indicate the frequency of the clock
 virtual void  StopClock(int i)=0;
 virtual void  StartOsc(int i,int type,float freq,float phase,float amp)=0;
               //type is the waveform of the output
 virtual void  StopOsc(int i)=0;

};
#endif

