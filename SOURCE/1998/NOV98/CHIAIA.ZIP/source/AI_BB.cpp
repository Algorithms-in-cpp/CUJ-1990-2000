#include "AI_BB.h"
#include "pciw.h"

float AI_PCI20002M::Read()
{
  int  data;
  float df;
  AIRead(RetSlot(),RetPos(),RetChn(),AI_NO_ZERO,1,range_BB,0,&data);
  df=data*10./0x7fff;  //0x7fff is 2^15-1 which indicate the resolution
                      // of the input; the 16th bit is used for sign.
  return df*RetConvFact()+RetOffset();
}

void AI_PCI20002M::SetRange(float low,float high)
// the range will be forced to be one of the types available with the hardware
{ if (low>0)
   {  lowHwd=0;highHwd=10;
      range_BB=UNIPOLAR_10;
   }
  else
    { if ((low<-5)||(high>5))
         {lowHwd=-10;highHwd=10;
          range_BB=BIPOLAR_20;
         }
      else
         { lowHwd=-5;highHwd=5;
           range_BB=BIPOLAR_10;
         }
    }
}
void AI_PCI20002M::GetRange(float *low,float *high)
{
 *low=lowHwd;
 *high=highHwd;
}

void AI_PCI20002M::SetResolution(float)
{
// we can't set resolution with this board because it's fixed from hardware
// configuration
}
float AI_PCI20002M::GetResolution()
{
  //resolution is assigned by the Hardware  depending from the range
  //with the following function (where 0xffff means a 16 bit subdivision)
  resHwd=(highHwd-lowHwd)/(float)0xffff;
  return resHwd;
}


AI_PCI20002M::AI_PCI20002M(int slotVal,int posVal,int chnVal) :
            VAI(slotVal,posVal,chnVal)
{ SetOffset(0);  //initializes the offset and the conversion factor
  SetConvFact(1);
}


AI_PCI20002M::AI_PCI20002M() : VAI ()
{ SetOffset(0);  //initializes the offset and the conversion factor
  SetConvFact(1);
}

AI_PCI20002M::~AI_PCI20002M()
{
}
