#if !defined WAVE_H
#define WAVE_H

#include "vcard.h"

class Wave_device :public VCard //class for a standard wave device card
{
  public:
  Wave_device();
  ~Wave_device();

  //overloading of the virtual functions

  void CreateConfig();
  void ReadConfig();
  long ReadCounter(int);
  void ReadMultiCounter(int,unsigned long&);
  float ReadAI(int);
  void WriteAO(int,float);
  void Wait(int,int,long);
  void StartCounter(int,int,long,bool);
  void StopCounter(int);
  void StartMultiCounter(int,int,long,bool);
  void StopMultiCounter(int);
  void StartClock(int,int,short);
  void StopClock(int);
  void StartOsc(int i,int type,float freq,float phase,float amp);
  void StopOsc(int i);

};



#endif
