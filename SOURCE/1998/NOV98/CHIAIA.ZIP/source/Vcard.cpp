#include "vcard.h"

VCard::VCard()
{  //initializes all data
  card_ID=new char[40];
  multiCounter=0;
  ncounter=0;
  nclock=0;
  nAI=0;
  nAO=0;
  nOSC=0;
  ison=false; //the card is still off
}

VCard::~VCard()
{
  delete [] card_ID;
}

