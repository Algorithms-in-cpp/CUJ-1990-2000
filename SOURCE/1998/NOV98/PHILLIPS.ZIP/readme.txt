
The programs presented in the article use the following source
code files.

The program that hides a watermark on an image uses
   bhidet.c  - the main program shown in the article
   cips.h    - defines
   bwrtiff.c - tiff file I/O
   tiff.c    - tiff file I/O

The program that subtracts one image from another uses
   bsub.c    - the main program shown in the article
   cips.h    - defines
   bwrtiff.c - tiff file I/O
   tiff.c    - tiff file I/O

The program that hides a message image in a cover image
and then uncovers it uses
   bstega.c  - the main program (not shown in article)
               and the routines shown in the article
   cips.h    - defines
   bwrtiff.c - tiff file I/O
   tiff.c    - tiff file I/O

