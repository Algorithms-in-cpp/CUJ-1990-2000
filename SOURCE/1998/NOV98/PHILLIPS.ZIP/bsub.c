

    /***********************************************
    *
    *  file d:\cips\bsub.c
    *
    *  Functions: This file contains
    *     main
    *
    *  Purpose:
    *     This file contains the code to subtract
    *     one image from another.
    *
    *  External Calls:
    *     tiff.c - read_tiff_header
    *     brwtiff.c - bread_tiff_image
    *                 bwrite_tiff_image
    *
    *  Modifications:
    *     16 February 1998 - created
    *
    *************************************************/

#include "cips.h"

main(argc, argv)
   int argc;
   char *argv[];
{

   char  min_name[80], sub_name[80];
   int   i, j;
   short **the_image;
   short **out_image;

   struct   tiff_header_struct image_header1;
   struct   tiff_header_struct image_header2;

      /*************************************
      *
      *  Ensure the command line is correct.
      *
      *************************************/

   if(argc < 3){
    printf("\n\nNot enough parameters:");
    printf("\n");
    printf("\n   usage: hidet minuend-file subtrahend-file ");
    exit(0);
   }

   strcpy(min_name, argv[1]);
   strcpy(sub_name, argv[2]);

      /*************************************
      *
      *  Ensure the two images are the 
      *  same size.
      *
      *************************************/

   read_tiff_header(min_name, &image_header1);
   read_tiff_header(sub_name, &image_header2);

   if(image_header1.image_length != 
      image_header2.image_length){
      printf("\nImage lengths do not match, quitting");
      exit(1);
   }
   if(image_header1.image_width != 
      image_header2.image_width){
      printf("\nImage widths do not match, quitting");
      exit(1);
   }

      /*************************************
      *
      *  Allocate the two image arrays.
      *
      *************************************/

   the_image = malloc(image_header1.image_length * sizeof(short  *));
   for(i=0; i<image_header1.image_length; i++){
      the_image[i] = malloc(image_header1.image_width * sizeof(short ));
      if(the_image[i] == '\0'){
         printf("\n\tmalloc of the_image[%d] failed", i);
         exit(0);
      }  /* ends if */
   }  /* ends loop over i */

   out_image = malloc(image_header2.image_length * sizeof(short  *));
   for(i=0; i<image_header2.image_length; i++){
      out_image[i] = malloc(image_header2.image_width * sizeof(short ));
      if(out_image[i] == '\0'){
         printf("\n\tmalloc of out_image[%d] failed", i);
         exit(0);
      }  /* ends if */
   }  /* ends loop over i */

      /*************************************
      *
      *  Read the images,
      *  subtract one image from the other,
      *  and write the resulting image.
      *
      *************************************/

   bread_tiff_image(min_name, the_image);
   bread_tiff_image(sub_name, out_image);

   for(i=0; i<image_header1.image_length; i++){
      for(j=0; j<image_header1.image_width; j++){
         the_image[i][j] = the_image[i][j] - out_image[i][j];
         if(the_image[i][j] < 0)
            the_image[i][j] = 0;
      } /* ends loop over j */
   }  /* ends loop over i */

   bwrite_tiff_image(min_name, the_image);

   free_image_array(the_image, 
      image_header1.image_length);
   free_image_array(out_image, 
      image_header2.image_length);

}  /* ends main  */

