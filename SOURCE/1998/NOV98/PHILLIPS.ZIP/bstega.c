
    /***********************************************
    *
    *  file c:\src\stega.c
    *
    *  Functions: This file contains
    *     main
    *     hide_image
    *     hide_pixels
    *     uncover_image
    *     uncover_pixels
    *
    *  Purpose:
    *     This file contains the main calling
    *     routine and other routines that
    *     use steganography to hide one image
    *     inside another and then recover the
    *     hidden image.
    *
    *  External Calls:
    *     gpcips.c - my_clear_text_screen
    *     tiff.c - read_tiff_header
    *     rtiff.c - read_tiff_image
    *     wtiff.c - write_array_into_tiff_image
    *     hist.c - calculate_histogram
    *              zero_histogram
    *              perform_histogram_equalization
    *
    *  Modifications:
    *     5 April 1998 - created
    *
    *************************************************/

#include "cips.h"
#define EIGHT 8



main(argc, argv)
   int argc;
   char *argv[];
{

   char  cover_image_name[80], 
         message_image_name[80];
   int   count, 
         hide    = 0,
         i, 
         ie      = 1, 
         il      = 1,
         j, 
         le      = COLS + 1, 
         lsb,
         n,
         ll      = ROWS + 1, 
         uncover = 0;

   long  clength, 
         mlength, 
         cwidth,
         mwidth;

   short **the_image;
   short **out_image;

   struct   tiff_header_struct c_image_header;
   struct   tiff_header_struct m_image_header;


      /******************************************
      *
      *   Ensure the command line is correct.
      *
      ******************************************/

   if(argc < 5){
    printf("\n\nNot enough parameters:");
    printf("\n");
    printf("\n   usage: -h stega cover-image-name message-image-name n");
    printf("\n          to hide the message image in the cover image");
    printf("\n    or");
    printf("\n   usage: -u stega cover-image-name message-image-name n");
    printf("\n          to uncover the cover image from the message image");
    exit(0);
   }

   if(strcmp(argv[1], "-h") == 0){
      hide    = 1;
      uncover = 0;
   }
   if(strcmp(argv[1], "-u") == 0){
      hide    = 0;
      uncover = 1;
   }
   if(  (hide    == 0)   &&
        (uncover == 0)  ){
      printf("\nNiether hiding nor uncovering");
      printf("\nSo, quitting");
      exit(1);
   }  /* ends if */

   strcpy(cover_image_name, argv[2]);
   strcpy(message_image_name, argv[3]);
   n = atoi(argv[4]);

      /******************************************
      *
      *   Ensure both images have the same height
      *   and the cover image is eight times as
      *   wide as the message image.
      *   Also determine if the bit order is lsb
      *   first or not.
      *
      ******************************************/

      /***********************************************
      *
      *   Hide the cover image in the message image.
      *
      ***********************************************/


   if(hide){
printf("\nMAIN> Hide");
      if(does_not_exist(cover_image_name)){
         printf("\n%s does not exist, quitting", 
         cover_image_name);
      }
      if(does_not_exist(message_image_name)){
         printf("\n%s does not exist, quitting", 
         message_image_name);
      }

      read_tiff_header(cover_image_name, &c_image_header);
      read_tiff_header(message_image_name, &m_image_header);
      
      clength = c_image_header.image_length;
      cwidth  = c_image_header.image_width;
      mlength = m_image_header.image_length;
      mwidth  = m_image_header.image_width;

      if(mlength != clength){
         printf("\n\nmlength=%d NOT EQUAL TO clength=%d",
                mlength, clength);
         printf("\nQUITING");
         exit(2);
      }  /* ends if length not equal */

      if(cwidth != (n*mwidth)){
         printf("\n\nmwidth=%d cwidth=%d", mwidth, cwidth);
         printf("\nCover image not wide enough");
         printf("\nQUITING");
         exit(3);
      }  /* ends if cover image not wide enough */

      if(c_image_header.lsb == 1)
         lsb = 1;
      else
         lsb = 0;

      the_image = malloc(c_image_header.image_length * sizeof(short  *));
      for(i=0; i<c_image_header.image_length; i++){
         the_image[i] = malloc(c_image_header.image_width * sizeof(short ));
         if(the_image[i] == '\0'){
            printf("\n\tmalloc of the_image[%d] failed", i);
            exit(0);
         }  /* ends if */
      }  /* ends loop over i */

      out_image = malloc(m_image_header.image_length * sizeof(short  *));
      for(i=0; i<m_image_header.image_length; i++){
         out_image[i] = malloc(m_image_header.image_width * sizeof(short ));
         if(out_image[i] == '\0'){
            printf("\n\tmalloc of out_image[%d] failed", i);
            exit(0);
         }  /* ends if */
      }  /* ends loop over i */

      hide_image(cover_image_name,
                 message_image_name,
                 the_image, out_image,
                 mlength, mwidth,
                 clength, cwidth,
                 lsb, n);
   }  /* ends if hide */



      /******************************************
      *
      *   Uncover the cover image from the 
      *   message image.
      *
      ******************************************/

   if(uncover){
printf("\nMAIN> Uncover");

      if(does_not_exist(cover_image_name)){
         printf("\n%s does not exist, quitting", 
         cover_image_name);
      }  /* ends if does_not_exist */

      if(does_not_exist(message_image_name)){
         printf("\n message file does not exist %s",
                  message_image_name);
         printf("\nSo, creating it");
         read_tiff_header(cover_image_name, &c_image_header);
         m_image_header.image_length   = 
            c_image_header.image_length;
         m_image_header.image_width    = 
            c_image_header.image_width/n;
         m_image_header.lsb            = 
            c_image_header.lsb;
         m_image_header.bits_per_pixel = 
            c_image_header.bits_per_pixel;
         bcreate_allocate_tiff_file(message_image_name, 
                                    &c_image_header);
      }  /* ends if does_not_exist */

      read_tiff_header(message_image_name, &m_image_header);
      read_tiff_header(cover_image_name, &c_image_header);

      clength = c_image_header.image_length;
      cwidth  = c_image_header.image_width;
      mlength = m_image_header.image_length;
      mwidth  = m_image_header.image_width;

      if(mlength != clength){
         printf("\n\nmlength=%d NOT EQUAL TO clength=%d",
                mlength, clength);
         printf("\nQUITING");
         exit(2);
      }  /* ends if length not equal */

      if(cwidth != (n*mwidth)){
         printf("\n\nmwidth=%d cwidth=%d", mwidth, cwidth);
         printf("\nCover image not wide enough");
         printf("\nQUITING");
         exit(3);
      }  /* ends if cover image not wide enough */

      if(c_image_header.lsb == 1)
         lsb = 1;
      else
         lsb = 0;

      the_image = malloc(c_image_header.image_length * sizeof(short  *));
      for(i=0; i<c_image_header.image_length; i++){
         the_image[i] = malloc(c_image_header.image_width * sizeof(short ));
         if(the_image[i] == '\0'){
            printf("\n\tmalloc of the_image[%d] failed", i);
            exit(0);
         }  /* ends if */
      }  /* ends loop over i */

      out_image = malloc(m_image_header.image_length * sizeof(short  *));
      for(i=0; i<m_image_header.image_length; i++){
         out_image[i] = malloc(m_image_header.image_width * sizeof(short ));
         if(out_image[i] == '\0'){
            printf("\n\tmalloc of out_image[%d] failed", i);
            exit(0);
         }  /* ends if */
      }  /* ends loop over i */

      uncover_image(cover_image_name,
                    message_image_name,
                    the_image, out_image,
                    mlength, mwidth,
                    clength, cwidth,
                    lsb, n);

   }  /* ends if uncover */


   free_image_array(the_image, 
      c_image_header.image_length);
   free_image_array(out_image, 
      m_image_header.image_length);

}  /* ends main  */



   /*********************************************
   *
   *
   *
   *********************************************/

/***********************************************/
/*
   subroutine hide_image(...

   For every pixel processed in the message image,
   n pixels are processed in the cover image.
   There are COLS/n sections of the cover image
   processed before needing to read a block of
   the cover image.
*/

int hide_image(cover_image_name,
               message_image_name,
               cover_image,
               message_image,
               mlength,
               mwidth,
               clength,
               cwidth,
               lsb,
               n)
   char  cover_image_name[],
         message_image_name[];
   int   lsb, n;
   long  clength, cwidth, mlength, mwidth;
   short **cover_image, 
         **message_image;
{
   char response[80];
   int ie               = 1,
       il               = 1,
       horizontal       = 1,
       h_counter        = 0,
       le               = COLS+1,
       ll               = ROWS+1,
       pixel_count      = 0,
       s_counter        = 0,
       sections         = 0,
       this_pixel_count = 0,
       w_counter        = 0;

   bread_tiff_image(cover_image_name, cover_image);
   bread_tiff_image(message_image_name, message_image);

   for(h_counter=0; h_counter<mwidth; h_counter++){
      hide_pixels(cover_image,
                  message_image,
                  h_counter,
                  h_counter*n,
                  lsb,
                  n,
                  mlength);
   }  /* ends loop over h_counter */

   bwrite_tiff_image(cover_image_name, cover_image);


}  /* ends hide_image */




   /*********************************************
   *
   *
   *
   *********************************************/


/***********************************************/
/*
   subroutine hide_pixels(...
*/

int hide_pixels(cover_image, 
                message_image,
                mie, 
                cie,
                lsb,
                n,
                mlength)
   int   cie, lsb, mie, n;
   long  mlength;
   short **cover_image, 
         **message_image;
{
   char result,
        new_message,
        response[80],
        sample;

   char mask1[EIGHT] =  {0x01,  /* 0000 0001 */
                         0x02,  /* 0000 0010 */
                         0x04,  /* 0000 0100 */
                         0x08,  /* 0000 1000 */
                         0x10,  /* 0001 0000 */
                         0x20,  /* 0010 0000 */
                         0x40,  /* 0100 0000 */
                         0x80}; /* 1000 0000 */


   char mask2[EIGHT] = {0xFE,  /* 1111 1110 */
                        0xFD,  /* 1111 1101 */
                        0xFB,  /* 1111 1011 */
                        0xF7,  /* 1111 0111 */
                        0xEF,  /* 1110 1111 */
                        0xDF,  /* 1101 1111 */
                        0xBF,  /* 1011 1111 */
                        0x7F}; /* 0111 1111 */


   int c_counter,
       i, j;


printf("\nHP> mie=%d   cie=%d   lsb=%d", mie, cie, lsb);

   for(i=0; i<mlength; i++){
      c_counter = 0;
      sample    = message_image[i][mie];

      for(j=n-1; j>-1; j--){
         new_message = cover_image[i][cie+c_counter];
         result      = sample & mask1[j];

         if(result != 0x00){ /* set pixel */
            if(lsb)
               new_message = new_message | mask1[0];
            else
               new_message = new_message | mask1[EIGHT];
         } /* ends if set pixel */

         else{ /* clear pixel */
            if(lsb)
               new_message = new_message & mask2[0];
            else
               new_message = new_message & mask2[EIGHT];
         }  /* ends if clear pixel */

         cover_image[i][cie+c_counter] = new_message;
         c_counter++;

      }  /* ends loop over j */
   }  /* ends loop over i ROWS */

}  /* ends hide_pixels */



   /*********************************************
   *
   *
   *
   *********************************************/




/***********************************************/
/*
   subroutine uncover_image(...

   For every pixel processed in the message image,
   n pixels are processed in the cover image.
   There are COLS/n sections of the cover image
   processed before needing to read a block of
   the cover image.
*/

int uncover_image(cover_image_name,
                  message_image_name,
                  cover_image,
                  message_image,
                  mlength,
                  mwidth,
                  clength,
                  cwidth,
                  lsb,
                  n)
   char  cover_image_name[],
         message_image_name[];
   int   lsb, n;
   long  clength, cwidth, mlength, mwidth;
   short **cover_image, 
         **message_image;
{
   char response[80];
   int ie               = 1,
       il               = 1,
       horizontal       = 1,
       h_counter        = 0,
       le               = COLS+1,
       ll               = ROWS+1,
       pixel_count      = 0,
       s_counter        = 0,
       sections         = 0,
       this_pixel_count = 0,
       w_counter        = 0;

   bread_tiff_image(cover_image_name, cover_image);


   for(h_counter=0; h_counter<mwidth; h_counter++){

      uncover_pixels(cover_image, 
                     message_image,
                     h_counter,
                     h_counter*n,
                     lsb,
                     n,
                     mlength);

   }  /* ends loop over h_counter */

   bwrite_tiff_image(message_image_name, message_image);

}  /* ends uncover_image */



   /*********************************************
   *
   *
   *
   *********************************************/



/***********************************************/
/*
   subroutine uncover_pixels(...
*/

int uncover_pixels(cover_image, 
                message_image,
                mie, 
                cie,
                lsb,
                n,
                mlength)
   int   cie, lsb, mie, n;
   long  mlength;
   short **cover_image, 
         **message_image;
{
   char result,
        new_message,
        response[80],
        sample;

   char mask1[EIGHT] =  
                        {0x80,  /* 1000 0000 */
                         0x40,  /* 0100 0000 */
                         0x20,  /* 0010 0000 */
                         0x10,  /* 0001 0000 */
                         0x08,  /* 0000 1000 */
                         0x04,  /* 0000 0100 */
                         0x02,  /* 0000 0010 */
                         0x01}; /* 0000 0001 */
   char mask2[EIGHT] = 
                       {0x7F,  /* 0111 1111 */
                        0xBF,  /* 1011 1111 */
                        0xDF,  /* 1101 1111 */
                        0xEF,  /* 1110 1111 */
                        0xF7,  /* 1111 0111 */
                        0xFB,  /* 1111 1011 */
                        0xFD,  /* 1111 1101 */
                        0xFE}; /* 1111 1110 */

   int c, c_counter, i, j;
printf("\nUP> mie=%d   cie=%d   lsb=%d", 
mie, cie, lsb);

   for(i=0; i<mlength; i++){
      c = n-1;
      new_message = 0x00;
      for(j=0; j<n; j++){
         if(is_odd(cover_image[i][cie+j])){
            /* set pixel c */
            if(lsb)
               new_message = new_message | mask1[j];
            else
               new_message = new_message | mask1[c];
         }  /* ends if is_odd */
         c--;
      }  /* ends loop over j */
      message_image[i][mie] = new_message;
   }  /* ends loop over i ROWS */
}  /* ends uncover_pixels */



   /*********************************************
   *
   *
   *
   *********************************************/

int is_odd(number)
   short number;
{
   int result = 0;
   result     = number % 2;
   return(result);
}  /* ends is_odd */

