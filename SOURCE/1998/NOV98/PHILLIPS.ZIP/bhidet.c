

    /***********************************************
    *
    *  file d:\cips\bhidet.c
    *
    *  Functions: This file contains
    *     main
    *
    *  Purpose:
    *     This file contains the main calling
    *     routine and subroutines to overlay  
    *     text on top of an image.  
    *
    *  External Calls:
    *     tiff.c - read_tiff_header
    *     brwtiff.c - bread_tiff_image
    *                 bwrite_tiff_image
    *
    *  Modifications:
    *     16 February 1998 - created
    *
    *************************************************/

#include "cips.h"

main(argc, argv)
   int argc;
   char *argv[];
{

   char  image_name[80], water_name[80];
   int   i, j;
   short factor;
   short **the_image;
   short **out_image;

   struct   tiff_header_struct image_header1;
   struct   tiff_header_struct image_header2;

      /*************************************
      *
      *  Ensure the command line is correct.
      *
      *************************************/

   if(argc < 4){
    printf("\n\nNot enough parameters:");
    printf("\n");
    printf("\n   usage: hidet image-file watermark-file factor  ");
    exit(0);
   }

   strcpy(image_name, argv[1]);
   strcpy(water_name, argv[2]);
   factor = atoi(argv[3]);

      /*************************************
      *
      *  Ensure the two images are the 
      *  same size.
      *
      *************************************/

   read_tiff_header(image_name, &image_header1);
   read_tiff_header(water_name, &image_header2);

   if(image_header1.image_length != 
      image_header2.image_length){
      printf("\nImage lengths do not match, quitting");
      printf("\nimage-file length=%d",
             image_header1.image_length);
      printf("\nwatermark-file length=%d",
             image_header2.image_length);
      exit(1);
   }
   if(image_header1.image_width != 
      image_header2.image_width){
      printf("\nImage widths do not match, quitting");
      printf("\nimage-file width=%d",
             image_header1.image_width);
      printf("\nwatermark-file width=%d",
             image_header2.image_width);
      exit(1);
   }

      /*************************************
      *
      *  Allocate the two image arrays.
      *
      *************************************/

   the_image = malloc(image_header1.image_length * sizeof(short  *));
   for(i=0; i<image_header1.image_length; i++){
      the_image[i] = malloc(image_header1.image_width * sizeof(short ));
      if(the_image[i] == '\0'){
         printf("\n\tmalloc of the_image[%d] failed", i);
         exit(0);
      }  /* ends if */
   }  /* ends loop over i */

   out_image = malloc(image_header2.image_length * sizeof(short  *));
   for(i=0; i<image_header2.image_length; i++){
      out_image[i] = malloc(image_header2.image_width * sizeof(short ));
      if(out_image[i] == '\0'){
         printf("\n\tmalloc of out_image[%d] failed", i);
         exit(0);
      }  /* ends if */
   }  /* ends loop over i */

      /*************************************
      *
      *  Read the images,
      *  Add the factor to the image per 
      *  the watermark image,
      *  write the resulting image.
      *
      *************************************/

   bread_tiff_image(image_name, the_image);
   bread_tiff_image(water_name, out_image);

   for(i=0; i<image_header1.image_length; i++){
      for(j=0; j<image_header1.image_width; j++){
         if(out_image[i][j] != 0){
            the_image[i][j] = the_image[i][j] + factor;
            if(the_image[i][j] > GRAY_LEVELS)
               the_image[i][j] = GRAY_LEVELS;
         }  /* ends if */

      } /* ends loop over j */
   }  /* ends loop over i */

   bwrite_tiff_image(image_name, the_image);

   free_image_array(the_image, 
      image_header1.image_length);
   free_image_array(out_image, 
      image_header2.image_length);

}  /* ends main  */
