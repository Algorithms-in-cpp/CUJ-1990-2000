// digest.h : main header file for the DIGEST application
//

// NOTE: This source code makes use of the RSA Data Security, Inc. MD5
// Message-Digest Algorithm. RSA grants license to copy and use its
// software provided that it is identified as the "RSA Data Security, Inc.
// MD5 Message-Digest Algorithm" in all material mentioning or referencing
// its software or function. 


#if !defined(AFX_DIGEST_H__D25C1D94_1939_11D2_BF26_00207813C2D0__INCLUDED_)
#define AFX_DIGEST_H__D25C1D94_1939_11D2_BF26_00207813C2D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDigestApp:
// See digest.cpp for the implementation of this class
//

class CDigestApp : public CWinApp
{
public:
	CDigestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDigestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDigestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIGEST_H__D25C1D94_1939_11D2_BF26_00207813C2D0__INCLUDED_)
