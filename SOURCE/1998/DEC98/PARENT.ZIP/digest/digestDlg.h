// digestDlg.h : header file
//

// NOTE: This source code makes use of the RSA Data Security, Inc. MD5
// Message-Digest Algorithm. RSA grants license to copy and use its
// software provided that it is identified as the "RSA Data Security, Inc.
// MD5 Message-Digest Algorithm" in all material mentioning or referencing
// its software or function. 

#if !defined(AFX_DIGESTDLG_H__D25C1D96_1939_11D2_BF26_00207813C2D0__INCLUDED_)
#define AFX_DIGESTDLG_H__D25C1D96_1939_11D2_BF26_00207813C2D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "MD5Encrypt.h"

/////////////////////////////////////////////////////////////////////////////
// CDigestDlg dialog

class CDigestDlg : public CDialog
{
// Construction
public:
	CDigestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDigestDlg)
	enum { IDD = IDD_DIGEST_DIALOG };
	CEdit	m_Input;
	CEdit	m_Digest;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDigestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDigestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIGESTDLG_H__D25C1D96_1939_11D2_BF26_00207813C2D0__INCLUDED_)
