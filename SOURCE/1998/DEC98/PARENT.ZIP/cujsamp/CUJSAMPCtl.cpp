// CUJSAMPCtl.cpp : Implementation of the CCUJSAMPCtrl ActiveX Control class.

// NOTE: This source code makes use of the RSA Data Security, Inc. MD5
// Message-Digest Algorithm. RSA grants license to copy and use its
// software provided that it is identified as the "RSA Data Security, Inc.
// MD5 Message-Digest Algorithm" in all material mentioning or referencing
// its software or function. 


#include "stdafx.h"
#include "CUJSAMP.h"
#include "CUJSAMPCtl.h"
#include "CUJSAMPPpg.h"


#include <AFXPRIV.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CCUJSAMPCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CCUJSAMPCtrl, COleControl)
	//{{AFX_MSG_MAP(CCUJSAMPCtrl)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CCUJSAMPCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CCUJSAMPCtrl)
	// NOTE - ClassWizard will add and remove dispatch map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CCUJSAMPCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CCUJSAMPCtrl, COleControl)
	//{{AFX_EVENT_MAP(CCUJSAMPCtrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CCUJSAMPCtrl, 1)
	PROPPAGEID(CCUJSAMPPropPage::guid)
END_PROPPAGEIDS(CCUJSAMPCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CCUJSAMPCtrl, "CUJSAMP.CUJSAMPCtrl.1",
	0xe35bbf95, 0x12e8, 0x11d2, 0xbf, 0x21, 0, 0x20, 0x78, 0x13, 0xc2, 0xd0)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CCUJSAMPCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DCUJSAMP =
		{ 0xe35bbf93, 0x12e8, 0x11d2, { 0xbf, 0x21, 0, 0x20, 0x78, 0x13, 0xc2, 0xd0 } };
const IID BASED_CODE IID_DCUJSAMPEvents =
		{ 0xe35bbf94, 0x12e8, 0x11d2, { 0xbf, 0x21, 0, 0x20, 0x78, 0x13, 0xc2, 0xd0 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwCUJSAMPOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CCUJSAMPCtrl, IDS_CUJSAMP, _dwCUJSAMPOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl::CCUJSAMPCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CCUJSAMPCtrl

BOOL CCUJSAMPCtrl::CCUJSAMPCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_CUJSAMP,
			IDB_CUJSAMP,
			afxRegApartmentThreading,
			_dwCUJSAMPOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}

/////////////////////////////////////////////////////////////////////////////
// Licensing strings
USES_CONVERSION;

static char SecretString[] = _T("TESTMD5");

static const TCHAR BASED_CODE _szLicFileName[] = _T("CUJSAMP.lic");

LPOLESTR  _szLicString = NULL;

/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl::CCUJSAMPCtrlFactory::VerifyUserLicense -
// Checks for existence of a user license

BOOL CCUJSAMPCtrl::CCUJSAMPCtrlFactory::VerifyUserLicense()
{
	CMD5Encrypt md5;
	char* digest = md5.MD5String(SecretString);

	_szLicString = A2OLE (digest);

	if ( !AfxVerifyLicFile(AfxGetInstanceHandle(), _szLicFileName,  _szLicString) )
	{
		// put up Nag Message to get user to pay for the control....
		AfxMessageBox("NAG NAG NAG!!!");
	}
    return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl::CCUJSAMPCtrlFactory::GetLicenseKey -
// Returns a runtime licensing key

BOOL CCUJSAMPCtrl::CCUJSAMPCtrlFactory::GetLicenseKey(DWORD dwReserved,
	BSTR FAR* pbstrKey)
{
	if (pbstrKey == NULL)
		return FALSE;

	CMD5Encrypt md5;
	char* digest = md5.MD5String(SecretString);

	_szLicString = A2OLE (digest);

	*pbstrKey = SysAllocString(_szLicString);

	return (*pbstrKey != NULL);
}

/*BOOL CCUJSAMPCtrl::CCUJSAMPCtrlFactory::VerifyLicenseKey(BSTR bstrKey)
{
	AfxMessageBox("in VerifyLicenseKey");

	BOOL bVerified = FALSE;

	CMD5Encrypt md5;
	char* digest = md5.MD5String(SecretString);
	//AfxMessageBox(digest);

	CString keyTemp = bstrKey;

	if (_tcscmp(keyTemp, digest) == 0)
	{
        bVerified = TRUE;
	}

    return bVerified;
}*/

/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl::CCUJSAMPCtrl - Constructor

CCUJSAMPCtrl::CCUJSAMPCtrl()
{
	InitializeIIDs(&IID_DCUJSAMP, &IID_DCUJSAMPEvents);

	// TODO: Initialize your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl::~CCUJSAMPCtrl - Destructor

CCUJSAMPCtrl::~CCUJSAMPCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl::OnDraw - Drawing function

void CCUJSAMPCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->Ellipse(rcBounds);
}


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl::DoPropExchange - Persistence support

void CCUJSAMPCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl::OnResetState - Reset control to default state

void CCUJSAMPCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl::AboutBox - Display an "About" box to the user

void CCUJSAMPCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_CUJSAMP);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl message handlers
