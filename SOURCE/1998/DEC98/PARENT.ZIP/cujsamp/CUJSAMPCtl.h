// NOTE: This source code makes use of the RSA Data Security, Inc. MD5
// Message-Digest Algorithm. RSA grants license to copy and use its
// software provided that it is identified as the "RSA Data Security, Inc.
// MD5 Message-Digest Algorithm" in all material mentioning or referencing
// its software or function. 

#if !defined(AFX_CUJSAMPCTL_H__E35BBFA3_12E8_11D2_BF21_00207813C2D0__INCLUDED_)
#define AFX_CUJSAMPCTL_H__E35BBFA3_12E8_11D2_BF21_00207813C2D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// CUJSAMPCtl.h : Declaration of the CCUJSAMPCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPCtrl : See CUJSAMPCtl.cpp for implementation.

#include "md5encrypt.h"

class CCUJSAMPCtrl : public COleControl
{
	DECLARE_DYNCREATE(CCUJSAMPCtrl)

// Constructor
public:
	CCUJSAMPCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCUJSAMPCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CCUJSAMPCtrl();

	BEGIN_OLEFACTORY(CCUJSAMPCtrl)        // Class factory and guid
		virtual BOOL VerifyUserLicense();
		virtual BOOL GetLicenseKey(DWORD, BSTR FAR*);
	END_OLEFACTORY(CCUJSAMPCtrl)
	//	virtual BOOL VerifyLicenseKey(BSTR bstrKey);

	DECLARE_OLETYPELIB(CCUJSAMPCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CCUJSAMPCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CCUJSAMPCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CCUJSAMPCtrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CCUJSAMPCtrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CCUJSAMPCtrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CCUJSAMPCtrl)
		// NOTE: ClassWizard will add and remove enumeration elements here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CUJSAMPCTL_H__E35BBFA3_12E8_11D2_BF21_00207813C2D0__INCLUDED)
