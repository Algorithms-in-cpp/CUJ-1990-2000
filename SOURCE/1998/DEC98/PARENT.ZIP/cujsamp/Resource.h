// NOTE: This source code makes use of the RSA Data Security, Inc. MD5
// Message-Digest Algorithm. RSA grants license to copy and use its
// software provided that it is identified as the "RSA Data Security, Inc.
// MD5 Message-Digest Algorithm" in all material mentioning or referencing
// its software or function. 

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CUJSAMP.rc
//

#define IDS_CUJSAMP               1
#define IDS_CUJSAMP_PPG           2

#define IDS_CUJSAMP_PPG_CAPTION   200

#define IDD_PROPPAGE_CUJSAMP      200

#define IDD_ABOUTBOX_CUJSAMP      1

#define IDB_CUJSAMP               1

#define IDI_ABOUTDLL				1

#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#define _APS_NEXT_COMMAND_VALUE         32768
