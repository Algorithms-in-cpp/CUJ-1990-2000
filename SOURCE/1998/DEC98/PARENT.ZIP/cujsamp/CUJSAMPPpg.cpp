// CUJSAMPPpg.cpp : Implementation of the CCUJSAMPPropPage property page class.

// NOTE: This source code makes use of the RSA Data Security, Inc. MD5
// Message-Digest Algorithm. RSA grants license to copy and use its
// software provided that it is identified as the "RSA Data Security, Inc.
// MD5 Message-Digest Algorithm" in all material mentioning or referencing
// its software or function. 

#include "stdafx.h"
#include "CUJSAMP.h"
#include "CUJSAMPPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CCUJSAMPPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CCUJSAMPPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CCUJSAMPPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CCUJSAMPPropPage, "CUJSAMP.CUJSAMPPropPage.1",
	0xe35bbf96, 0x12e8, 0x11d2, 0xbf, 0x21, 0, 0x20, 0x78, 0x13, 0xc2, 0xd0)


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPPropPage::CCUJSAMPPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CCUJSAMPPropPage

BOOL CCUJSAMPPropPage::CCUJSAMPPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_CUJSAMP_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPPropPage::CCUJSAMPPropPage - Constructor

CCUJSAMPPropPage::CCUJSAMPPropPage() :
	COlePropertyPage(IDD, IDS_CUJSAMP_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CCUJSAMPPropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPPropPage::DoDataExchange - Moves data between page and properties

void CCUJSAMPPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CCUJSAMPPropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CCUJSAMPPropPage message handlers
