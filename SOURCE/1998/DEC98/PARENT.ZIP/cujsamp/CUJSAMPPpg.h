// NOTE: This source code makes use of the RSA Data Security, Inc. MD5
// Message-Digest Algorithm. RSA grants license to copy and use its
// software provided that it is identified as the "RSA Data Security, Inc.
// MD5 Message-Digest Algorithm" in all material mentioning or referencing
// its software or function. 

#if !defined(AFX_CUJSAMPPPG_H__E35BBFA5_12E8_11D2_BF21_00207813C2D0__INCLUDED_)
#define AFX_CUJSAMPPPG_H__E35BBFA5_12E8_11D2_BF21_00207813C2D0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// CUJSAMPPpg.h : Declaration of the CCUJSAMPPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CCUJSAMPPropPage : See CUJSAMPPpg.cpp.cpp for implementation.

class CCUJSAMPPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CCUJSAMPPropPage)
	DECLARE_OLECREATE_EX(CCUJSAMPPropPage)

// Constructor
public:
	CCUJSAMPPropPage();

// Dialog Data
	//{{AFX_DATA(CCUJSAMPPropPage)
	enum { IDD = IDD_PROPPAGE_CUJSAMP };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CCUJSAMPPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CUJSAMPPPG_H__E35BBFA5_12E8_11D2_BF21_00207813C2D0__INCLUDED)
