// **********************************************************
//   File: graphic_interface.h
//   Description: Prototypes for display functions
//
//   Author: Carlos Moreno
// **********************************************************

void draw_point (int x, int y, int radius = 0);
void draw_line (int x1, int y1, int x2, int y2);
