// **********************************************************
//   File: graphic_interface.cpp
//   Description: Simplified implementation of the display 
//                operations (for a Win32 platform)
//
//   Author: Carlos Moreno
// **********************************************************

#include <windows.h>

extern HWND h_wnd;
extern HDC memdc;

extern HPEN hblack_pen;
extern int maxX, maxY;


void draw_point (int X, int Y, int radius)
{
    HDC hdc;
    POINT dummy;    // POINT refers to the Windows definition

    int x = X + maxX / 2;
    int y = -Y + maxY / 2;

    hdc = GetDC (h_wnd);

    SelectObject (hdc, hblack_pen);
    SelectObject (memdc, hblack_pen);

    if (radius == 0)
    {
        SetPixel (hdc, x, y, 0);
        SetPixel (memdc, x, y, 0);
    }
    else
    {
        MoveToEx (hdc, x, y + radius, &dummy);
        LineTo (hdc, x + radius, y);
        LineTo (hdc, x, y - radius);
        LineTo (hdc, x - radius, y);
        LineTo (hdc, x, y + radius);

        MoveToEx (memdc, x, y + radius, &dummy);
        LineTo (memdc, x + radius, y);
        LineTo (memdc, x, y - radius);
        LineTo (memdc, x - radius, y);
        LineTo (memdc, x, y + radius);
    }

    ReleaseDC (h_wnd, hdc);
}


void draw_line (int X1, int Y1, int X2, int Y2)
{
    HDC hdc;
    POINT dummy;    // POINT refers to the Windows definition

    int x1 = X1 + maxX / 2,
        x2 = X2 + maxX / 2,
        y1 = -Y1 + maxY / 2,
        y2 = -Y2 + maxY / 2;

    hdc = GetDC (h_wnd);

    SelectObject (hdc, hblack_pen);
    MoveToEx (hdc, x1, y1, &dummy);
    LineTo (hdc, x2, y2);

    SelectObject (memdc, hblack_pen);
    MoveToEx (memdc, x1, y1, &dummy);
    LineTo (memdc, x2, y2);
    
    ReleaseDC (h_wnd, hdc);
}
