
To compile and run this demo:

Create a Win32 GUI application that includes the following files:

geometry_main.cpp
graphic_interface.cpp
graphic_interface.h
Jarvi.cpp
menu.aps
menu.h
menu.rc
Point.cpp
Point.h
Polygon.cpp
Polygon.h
Segment.cpp
Segment.h
Triangle.cpp
Triangle.h
triangulation.cpp
triangulation.h
WinMain.cpp


Example of the procedure using Visual C++ 6:

- Copy all of the above files in a directory (e.g., c:\geometry_demo)

- Launch Visual C++ 6 and select the menu item File/New...

- In the Dialog Box, select "Win32 Application", select the location 
  (the same where you put the files - e.g. c:\geometry_demo), and 
  enter a name for the project (e.g., demo)

- Click Ok and Select "Empty application" and "Finish" when 
  prompted in the dialog boxes

- Select the menu item: Project/Add to Project/Files...

- In the File Open Dialog box, select all of the files listed 
  above, and click ok

- Run the application

