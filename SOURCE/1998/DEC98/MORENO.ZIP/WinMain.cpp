/********************************************************************************

    File: WinMain.cpp
    Author: Carlos Moreno  
            (modified from Herbert Schildt's "Windows NT 4 Programming from 
             the Ground Up")

    Description:
        WinMain function, Application initialization and WindowFunct Loop

*********************************************************************************/

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "menu.h"

LRESULT CALLBACK WindowFunc (HWND, UINT, WPARAM, LPARAM);

void geometry_test ();


HWND h_wnd;

HINSTANCE hinst;
HDC memdc;
HBITMAP hbit;

HPEN hgray_pen;
HPEN hblack_pen;

int maxX, maxY;
HBRUSH hbrush;
char * win_name = "MyWin";

int WINAPI WinMain (HINSTANCE h_this_inst, HINSTANCE h_prev_inst, LPSTR lpsz_args, int n_win_mode)
{

    MSG msg;
    WNDCLASSEX wcl;

    hinst = h_this_inst;

    wcl.cbSize = sizeof (WNDCLASSEX);
    wcl.hInstance = h_this_inst;
    wcl.lpszClassName = win_name;
    wcl.lpfnWndProc = WindowFunc;
    wcl.style = CS_DBLCLKS;

    wcl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wcl.hIconSm = LoadIcon (NULL, IDI_WINLOGO);
    wcl.hCursor = LoadCursor (NULL, IDC_ARROW);

    wcl.lpszMenuName = "MyMenu";
    wcl.cbClsExtra = 0;
    wcl.cbWndExtra = 0;

    wcl.hbrBackground = (HBRUSH) GetStockObject (LTGRAY_BRUSH);

    if (!RegisterClassEx (&wcl))
    {
        return 0;
    }

    // Now, create a window 

    h_wnd = CreateWindow (win_name, "Efficient 2-D Geometric Operations - demo",
                          WS_OVERLAPPEDWINDOW, CW_USEDEFAULT,
                          CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
                          HWND_DESKTOP, NULL, h_this_inst, NULL);


    // Display the window

    ShowWindow (h_wnd, SW_MAXIMIZE);
    UpdateWindow (h_wnd);

    srand (time(NULL));     // randomize

    while (GetMessage (&msg, NULL, 0, 0))
    {

            TranslateMessage (&msg);
            DispatchMessage (&msg);
    }

    return msg.wParam;
}


LRESULT CALLBACK WindowFunc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    void draw_rnd_polygon (double Max_X, double Max_Y, bool draw_vertices);
    void draw_convex_hull ();
    void draw_triangulation ();
    void jarvi_demo (double max_x, double max_y);
    void point_inclusion_demo (int max_x, int max_y);

    void clear_window ();

    HDC hdc;
    PAINTSTRUCT paintstruct;

    switch (message)
    {
        case WM_CREATE:
            maxX = GetSystemMetrics (SM_CXSCREEN);
            maxY = GetSystemMetrics (SM_CYSCREEN);
            hdc = GetDC (hwnd);
            memdc = CreateCompatibleDC (hdc);
            hbit = CreateCompatibleBitmap (hdc, maxX, maxY);
            SelectObject (memdc, hbit);
            hbrush = (HBRUSH)GetStockObject (LTGRAY_BRUSH);
            SelectObject (memdc, hbrush);
            PatBlt (memdc, 0, 0, maxX, maxY, PATCOPY);
            SetBkMode (memdc, OPAQUE);
            ReleaseDC (hwnd, hdc);

            hgray_pen = CreatePen (PS_SOLID, maxY, RGB (0xC0, 0xC0, 0xC0));
            hblack_pen = CreatePen (PS_SOLID, 1, RGB(0,0,0));

            break;


        case WM_PAINT:
            hdc = BeginPaint (hwnd, &paintstruct);
            BitBlt (hdc, 0, 0, maxX, maxY, memdc, 0, 0, SRCCOPY);
            EndPaint (hwnd, &paintstruct);
            break;


        case WM_COMMAND:
            switch (LOWORD(wParam))
            {
                case IDM_DRAW_RND_POLYGON:

                    clear_window ();
                    draw_rnd_polygon (0.8 * maxX, 0.7 * maxY, false);   // no draw vertices
                    break;

                case IDM_DRAW_VERTICES:
                    clear_window ();
                    draw_rnd_polygon (0.8* maxX, 0.7 * maxY, true);    // draw vertices
                    break;

                case IDM_DRAW_CONVEX_HULL:
                    draw_convex_hull ();
                    break;

                case IDM_TRIANGULATE:
                    draw_triangulation ();
                    break;

                case IDM_JARVI:
                    clear_window ();
                    jarvi_demo (0.8 * maxX, 0.7 * maxY);
                    break;

                case IDM_POINT_INCLUSION:
                    if (MessageBox (hwnd, "This test checks all the pixels in the "
                                          "screen for inclusion in the selected "
                                          "polygon.  Depending on the speed of your "
                                          "PC and the speed of your video card, it " 
                                          "may take long to run it.  Click Ok if "
                                          "you want to run this demo, or Cancel to " 
                                          "go back", "Confirm", 
                                          MB_OKCANCEL | MB_ICONEXCLAMATION) == IDOK)
                    {
                        point_inclusion_demo (maxX, maxY);
                    }
                    break;

                case IDM_EXIT:
                    if (MessageBox (hwnd, "Quit this demo?", "Confirm quit", MB_YESNO | MB_ICONQUESTION) == IDYES)
                    {
                        PostQuitMessage (0);
                    }
                    break;
            }
            break;

        case WM_DESTROY:
            PostQuitMessage (0);
            break;

        default:
            return DefWindowProc (hwnd, message, wParam, lParam);
    }

    return 0;
}


void clear_window ()
{
    POINT dummy;

    int maxX = GetSystemMetrics (SM_CXSCREEN);
    int maxY = GetSystemMetrics (SM_CYSCREEN);
    HDC hdc = GetDC (h_wnd);

    SelectObject (hdc, hgray_pen);
    MoveToEx (hdc, 0, maxY/2, &dummy);
    LineTo (hdc, maxX, maxY/2);

    SelectObject (memdc, hgray_pen);
    MoveToEx (memdc, 0, maxY/2, &dummy);
    LineTo (memdc, maxX, maxY/2);

    ReleaseDC (h_wnd, hdc);
}
