
#define IDM_DRAW_RND_POLYGON 100
#define IDM_DRAW_VERTICES    101
#define IDM_DRAW_CONVEX_HULL 102
#define IDM_TRIANGULATE      103
#define IDM_POINT_INCLUSION  104
#define IDM_JARVI            105
#define IDM_EXIT             106

