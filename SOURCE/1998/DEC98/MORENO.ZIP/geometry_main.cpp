/*********************************************************************************

    File: geometry_main.cpp
    Author: Carlos Moreno

    Description:
        Demo routines to test the various geometric operations.        

*********************************************************************************/

#include "Point.h"
#include "Segment.h"
#include "Triangle.h"
#include "Polygon.h"

#include <fstream>
#include <assert.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

using namespace std;


#include "triangulation.h"

const int NUM_VERTICES = 10;  
const int NUM_POINTS = 50;  

Polygon generate_random_polygon (int num_vertices, double MAX_X, double MAX_Y);
Polygon convex_hull_set_points (const list<Point> &);

static Polygon test_polygon = generate_random_polygon (NUM_VERTICES, 100, 100);




Point random_Point (double MAX_X, double MAX_Y)
{
    return Point (MAX_X * rand() / RAND_MAX - MAX_X / 2, 
                  MAX_Y * rand() / RAND_MAX - MAX_Y / 2);
}


Polygon generate_random_polygon (int num_vertices, double MAX_X, double MAX_Y)
{
    Polygon P;

        // Start generating a random triangle, then append 
        // one more points (inside the triangle)

    Point p1 = random_Point (MAX_X, MAX_Y);
    Point p2 = random_Point (MAX_X, MAX_Y);
    Point p3 = random_Point (MAX_X, MAX_Y);

    P.push_back (p1);
    P.push_back (p2);
    P.push_back (p3);

    P.push_back ((p1 + p2 + p3) / 3);

        // Now pick random points and choose where in 
        // the polygon it can be inserted without causing 
        // intersection

    Polygon::iterator current_pos = P.begin(), 
                      current = P.begin();
    Point p;

    int n = 4;
    while (n < num_vertices)
    {
        if (current == current_pos)
        {
            p = random_Point (MAX_X, MAX_Y);
        }

        Segment s1 (p, *current),  s2 (p, *(current+1));
        bool point_ok = true;

        if (turn (p, *(current+1), *(current+2)) == collinear || 
            turn (p, *current, *(current-1)) == collinear || 
            s1.intersects (Segment (*(current+1), *(current+2))) || 
            s2.intersects (Segment (*current, *(current-1))))
        {
            point_ok = false;
        }

        for (Polygon::iterator i = current + 2; i != current - 1; i++)
        {
            Segment edge (*i, *(i+1));

            if (edge.intersects (s1) || edge.intersects (s2))
            {
                point_ok = false;
                break;
            }
        }

        current++;

        if (point_ok)
        {
            P.insert (current, p);

            current_pos = current;
            n++;
        }
    }

    return P;
}

void draw_rnd_polygon (double max_x, double max_y, bool draw_vertices)
{
    do
    {
        test_polygon = generate_random_polygon (NUM_VERTICES, max_x, max_y);
    }
    while (test_polygon.orientation() == clockwise);

    test_polygon.draw (draw_vertices);
}


void draw_convex_hull ()
{
    Polygon P = test_polygon.convex_hull();

    test_polygon.draw();
    P.draw();
}


void draw_triangulation ()
{
    list<Triangle> triangulation;

    test_polygon.draw (draw_vertices);      // Make sure polygon shows vertices
    triangulate (test_polygon, triangulation);

    list<Triangle>::const_iterator i;
    for (i = triangulation.begin(); i != triangulation.end(); i++)
    {
        (*i).draw();
    }
}


void jarvi_demo (double max_x, double max_y)
{
    list<Point> points;

    for (int i = 0; i < NUM_POINTS; i++)
    {
        Point p = random_Point (max_x, max_y);
        points.push_back (p);
        p.draw(2);
    }

    for (int dummy = 0; dummy < 1000000; dummy++)
    {
        int a = dummy+1;
    }

    Polygon P = convex_hull_set_points (points);
    P.draw ();
}


void point_inclusion_demo (int maxX, int maxY)
{
    test_polygon.draw();
    for (int y = maxY / 2; y > -maxY / 2; y--)
    {
        for (int x = -maxX / 2; x < maxX / 2; x++)
        {
            Point p (x,y);
            if (p.is_inside (test_polygon))
            {
                p.draw();
            }
        }
    }
}