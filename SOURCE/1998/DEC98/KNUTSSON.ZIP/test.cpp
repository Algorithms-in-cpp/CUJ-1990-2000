// This is very simple program demonstrating how to use the
// usage:
// run test.exe dib gif
// for example: 
// test.exe template.bmp template.gif
#include "CImage.h"
#include <iostream.h>

void main(int argc, char *argv[]) 
    {
    CImage im;
    if (!im.LoadImage(argv[1])) 
        cout << "Could not load "<< argv[1] << endl;
    im.OptimizeForSize();
    if (!im.SaveAsGif(argv[2],false,1,-1))
        cout << "Could not save as GIF file " << argv[2] << endl;
    }
