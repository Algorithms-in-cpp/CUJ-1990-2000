// lukas@spray.se 1998

#if !defined(_CIMAGE_H)
#define _CIMAGE_H

#include <windows.h>

#ifdef _DEBUG
#include <crtdbg.h>
#endif 

class CImageColorTable;
class CCriticalSection;

class CImage {
	public:

		CImage() {init();}
		~CImage() {clear();}

		bool LoadImage(LPCTSTR pszFileName);
		bool Create(int width, int height, int bpp);
        bool SaveImage(LPCTSTR pszFileName);
		bool SaveAsGif(LPCTSTR pszFileName,
					   bool _bInterlace, 
					   int background, 
					   int transparent = -1);

        int Width() const    {_ASSERT(m_hImage);return ds.dsBm.bmWidth;}
        int Height() const   {_ASSERT(m_hImage);return ds.dsBm.bmHeight;}
		int BPP() const		 {_ASSERT(m_hImage);return ds.dsBmih.biBitCount;}
		bool Inside(int x, int y) const	{_ASSERT(m_hImage);return ((0 <= x) && (x < Width()) && (0 <= y) && (y < Height()));}
		unsigned int NumColorEntries() const;
		void SetNumColorEntries(unsigned int numColors);
        UINT GetDIBColorTable(UINT uStartIndex, UINT cEntries, RGBQUAD* pColors) const;
		UINT GetColorTable(CImageColorTable& clrTbl) const;
		bool SetColorTable(const CImageColorTable& clrTbl, bool bRemap = false);
        void* GetPixelAddress(int x, int y) const;

		operator HBITMAP() {return m_hImage;}

		// the methods below are only possible if exception handling
		// is enabled as they use STL container classes
		#ifdef _CPPUNWIND 
		void OptimizeForSize();
		#endif // _CPPUNWIND

	private:

		// cannot copy or assign
		CImage(const CImage& ) {;}
		CImage& operator = (const CImage& ) {return *this;}

		void clear();
        void init() {m_hImage = 0;}
        bool SetDIBSection()
			{_ASSERT(m_hImage);return GetObject((HGDIOBJ)m_hImage, sizeof(DIBSECTION), &ds)?true:false;}
        int StorageWidth() const 
			{_ASSERT(m_hImage);return (ds.dsBmih.biWidth + 3) & ~3;}
        void* GetBits() const 
			{_ASSERT(m_hImage);return ds.dsBm.bmBits;}

        HBITMAP m_hImage;
        DIBSECTION ds;

	};

////////////////////////////////////////////////////////////////////
class CImageColorTable {
	public:

		CImageColorTable(int size = 0) {init(size);}
		~CImageColorTable(){clear();}

		int size() const {return m_size;}
		void resize(int newsize);
		RGBQUAD& operator[](int pos) {return m_prgb[pos];}
		const RGBQUAD& operator[](int pos) const {return m_prgb[pos];}
		COLORREF color(int pos) const 
			{RGBQUAD& rgb = m_prgb[pos];return RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue);}

		#ifdef _DEBUG
		void DebugOutput();
		#endif _DEBUG

	protected:

		RGBQUAD* m_prgb;
		void init(int size) {m_prgb = (size? new RGBQUAD[size]:NULL);m_size = size;}
		void clear(){if (m_prgb) delete[] m_prgb;m_prgb = 0;}
		int m_size;

		friend class CImage;
	};

////////////////////////////////////////////////////////////////////
class CNetscapeColorTable : public CImageColorTable {
	public:

		CNetscapeColorTable();
	};

////////////////////////////////////////////////////////////////////
class CImagePalette {
	public:

		CImagePalette() {init();}
		~CImagePalette() {clear();}

		bool CreatePalette(const CImage& dib);
		bool CreatePalette(const CImageColorTable& clrTbl);

		operator HPALETTE () {return m_hPal;}

		UINT GetNearestPaletteIndex(COLORREF crColor)
			{_ASSERT(m_hPal);return ::GetNearestPaletteIndex(m_hPal, crColor);}

		#ifdef _DEBUG
		void DebugOutput();
		#endif _DEBUG

	private:

		HPALETTE m_hPal;

		void init() {m_hPal = 0;}
		void clear();
	};

////////////////////////////////////////////////////////////////////
class CImageDC {
	public:

		CImageDC() {init();}
		~CImageDC(){clear();}

		bool CreateCompatibleDC(HDC hdc = NULL)
			{m_hdc = ::CreateCompatibleDC(hdc);return m_hdc?true:false;}

		operator HDC() {return m_hdc;}

		HBITMAP SelectBitmap(HBITMAP hBitmap)
			{HBITMAP tmp = (HBITMAP)::SelectObject(m_hdc, hBitmap);
			 if (!m_hOldBmp) m_hOldBmp = tmp;
			 return tmp;}

		HBITMAP DeSelectBitmap() {return (HBITMAP)::SelectObject(m_hdc, m_hOldBmp);}
		HPEN DeSelectPen() {return (HPEN)::SelectObject(m_hdc, m_hOldPen);}
		HBRUSH DeSelectBrush() {return (HBRUSH)::SelectObject(m_hdc, m_hOldBrush);}
		HFONT DeSelectFont() {return (HFONT)::SelectObject(m_hdc, m_hOldFont);}
		HPALETTE DeSelectPalette() {return (HPALETTE)::SelectPalette(m_hdc, m_hOldPal, false);}

		HPEN SelectPen(HPEN hPen)
			{HPEN tmp = (HPEN)::SelectObject(m_hdc, hPen);
			 if (!m_hOldPen) m_hOldPen = tmp;
			 return tmp;}

		HBRUSH SelectBrush(HBRUSH hBrush)
			{HBRUSH tmp = (HBRUSH)::SelectObject(m_hdc, hBrush);
			 if (!m_hOldBrush) m_hOldBrush = tmp;
			 return tmp;}

		HFONT SelectFont(HFONT hFont)
			{HFONT tmp = (HFONT)::SelectObject(m_hdc, hFont);
			 if (!m_hOldFont) m_hOldFont = tmp;
			 return tmp;}

		HPALETTE SelectPalette(HPALETTE hPal, bool bForceBackground)
			{HPALETTE tmp = (HPALETTE)::SelectPalette(m_hdc, hPal, bForceBackground);
			 if (!m_hOldPal) m_hOldPal = tmp;
			 return tmp;}

	private:

		HDC m_hdc;
		HBITMAP m_hOldBmp;
		HPEN m_hOldPen;
		HBRUSH m_hOldBrush;
		HFONT m_hOldFont;
		HPALETTE m_hOldPal;

		void init();
		void clear();
	};

////////////////////////////////////////////////////////////////////
class CImageSelector {
	public:
		CImageSelector(HDC hdc, CImage& im)
			{m_hdc = hdc;
			m_hOldBmp = (HBITMAP)::SelectObject(m_hdc,im);
			m_state = m_hOldBmp?true:false;
			}
		~CImageSelector()
			{if (m_state) ::SelectObject(m_hdc,m_hOldBmp);}
		operator bool() {return m_state;}
	private:
		bool m_state;
		HDC m_hdc;
		HBITMAP m_hOldBmp;
	};

////////////////////////////////////////////////////////////////////
inline void* CImage::GetPixelAddress(int x, int y) const
    {
    // This version deals only with 8-bpp DIBs.
    _ASSERT(BPP() == 8);
    _ASSERT(Inside(x,y));

    return (LPSTR)GetBits() + ((Height() - y -1) * StorageWidth()) + x;
    }

inline void CImage::SetNumColorEntries(unsigned int num)
	{
    _ASSERT(m_hImage);
	ds.dsBmih.biClrUsed = num;
	ds.dsBmih.biClrImportant = num;
	}


#endif // _CIMAGE_H