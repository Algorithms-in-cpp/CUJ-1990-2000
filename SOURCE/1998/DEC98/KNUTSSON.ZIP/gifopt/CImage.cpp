// lukas@spray.se 1998
#include "stdafx.h"
#include "cimage.h"
#include "cimagegif.h"
#include <malloc.h> // for alloca definition
#include <map>
#include <set>

////////////////////////////////////////////////////////////////////
void CImage::clear() 
    {
    if (m_hImage)
        {
        ::DeleteObject(m_hImage);
        m_hImage = 0;
        }
    }

////////////////////////////////////////////////////////////////////
bool CImage::LoadImage(LPCTSTR pszFileName)
    {
	HBITMAP hBitmap;
    hBitmap = (HBITMAP)::LoadImage(0,
                                    pszFileName,
                                    IMAGE_BITMAP,
                                    0,0,
                                    LR_CREATEDIBSECTION|LR_LOADFROMFILE);

    if (hBitmap)
		{
		clear();
		m_hImage = hBitmap;
		return m_hImage ? SetDIBSection(): false;
		}
	else
		{
        _RPT1(_CRT_WARN, "Could not LoadImage %s !\n", pszFileName);
		return false;
		}

    return m_hImage ? SetDIBSection(): false;
    }

////////////////////////////////////////////////////////////////////
bool CImage::Create(int width, int height, int bpp/*, CDC* pdc*/)
    {
	// we only support 8 bits per pixel at the moment
	_ASSERT(bpp == 8);
    
    BITMAPINFO bmpInfo;
	HBITMAP hBitmap;
	HDC hdc;
	VOID* pBits;

    // prepare BITMAPINFO structure
    ::ZeroMemory(&bmpInfo,sizeof(BITMAPINFO));
    bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmpInfo.bmiHeader.biWidth = width;
    bmpInfo.bmiHeader.biHeight = height;
    bmpInfo.bmiHeader.biPlanes = 1;
    bmpInfo.bmiHeader.biBitCount = static_cast<unsigned short>(bpp);
    bmpInfo.bmiHeader.biCompression = BI_RGB;

	hdc = ::GetDC(NULL);
	if (hdc == NULL)
		return false;

    hBitmap = ::CreateDIBSection(hdc, 
								&bmpInfo,
								bpp == 8? DIB_PAL_COLORS : DIB_RGB_COLORS,
								&pBits, NULL, NULL);

	if (::ReleaseDC(NULL, hdc) == 0)
		{
		if (hBitmap)
			::DeleteObject(hBitmap);
		return false;
		}
	if (hBitmap == NULL)
		return false;
	clear();
	m_hImage = hBitmap;
	return SetDIBSection();
	}

////////////////////////////////////////////////////////////////////
bool CImage::SaveImage(LPCTSTR pszFileName)
	{
	if (NULL == m_hImage)
		{
		return false;
		}

	DWORD dwBytesWritten;
	HANDLE hFile = ::CreateFile(pszFileName, // pointer to name of the file 
						GENERIC_WRITE , // access (read-write) mode 
						0, // share mode 
						NULL, // pointer to security attributes 
						CREATE_ALWAYS , // how to create 
						FILE_ATTRIBUTE_NORMAL , // file attributes 
						NULL // handle to file with attributes to copy 
						); 

	if (hFile == INVALID_HANDLE_VALUE)
		{
		return false;
		}
 
    BITMAPFILEHEADER bfh;
	int numColors = NumColorEntries();
	_RPT1(_CRT_WARN, "Number of colors in bitmap being saved is %i\n", numColors);

    // Construct the file header.
    bfh.bfType = 0x4D42; // 'BM'
    bfh.bfSize = 
        sizeof(BITMAPFILEHEADER) +
        sizeof(BITMAPINFOHEADER) +
        numColors * sizeof(RGBQUAD) +
        StorageWidth() * Height();
    bfh.bfReserved1 = 0;
    bfh.bfReserved2 = 0;
    bfh.bfOffBits =
        sizeof(BITMAPFILEHEADER) +
        sizeof(BITMAPINFOHEADER) +
        numColors * sizeof(RGBQUAD);

	if (!::WriteFile(hFile, &bfh, sizeof(bfh), &dwBytesWritten, NULL))
		{
		::CloseHandle(hFile);
		return false;
		}

    // Write the BITMAPINFO structure.
	_ASSERT(ds.dsBmih.biSize == sizeof(BITMAPINFOHEADER));
	if (!::WriteFile(hFile, &(ds.dsBmih), sizeof(BITMAPINFOHEADER), &dwBytesWritten, NULL))
		{
        _RPT0(_CRT_WARN, "Failed to write BITMAPINFOHEADER");
		::CloseHandle(hFile);
		return false;
		}

		{
		RGBQUAD colors[256];
		GetDIBColorTable(0, numColors, (RGBQUAD*)colors);
		if (!::WriteFile(hFile, &colors, numColors * sizeof(RGBQUAD), &dwBytesWritten, NULL))
			{
			_RPT0(_CRT_WARN, "Failed to write color table");
			::CloseHandle(hFile);
			return false;
			}
		}

    // Write the bits.
    //iSize = StorageWidth() * Height();
	if (!::WriteFile(hFile, ds.dsBm.bmBits, StorageWidth() * Height(), &dwBytesWritten, NULL))
		{
        _RPT0(_CRT_WARN, "Failed to write bits");
		::CloseHandle(hFile);
		return false;
		}

	::CloseHandle(hFile);

#ifdef _DEBUG
	// load bitmap again and test data is the same
	CImage debugBmp;
	if (!debugBmp.LoadImage(pszFileName))
		{
		_RPT1(_CRT_WARN, "Could not load bmp %s after saving it in debug mode !",pszFileName);
		return false;
		}
#endif // _DEBUG

    return true;	
	}

////////////////////////////////////////////////////////////////////
bool CImage::SaveAsGif(LPCTSTR pszFileName,
						bool bInterlace, 
						int background, 
						int transparent)
	{
	_RPT4(_CRT_WARN,"Saving gif %s,interlace=%s,background=%i,transparent=%i\n",
		  pszFileName,bInterlace?"true":"false",background,transparent);

	if (NULL == m_hImage)
		{
		return false;
		}

	CImageGif gif;
	RGBQUAD rgbquad[256];
	int colors[256];
	int numColors = NumColorEntries();

	if (!gif.CreateLogicalWidth(Width(), Height()))
		return false;

	gif.SetImageLeft(0);
	gif.SetImageTop(0);
	gif.SetImageWidth(Width());
	gif.SetImageHeight(Height());

	GetDIBColorTable(0, numColors, (RGBQUAD*)&rgbquad);
	colors[background] = gif.GlobalColorAllocate(rgbquad[background].rgbRed, 
											  rgbquad[background].rgbGreen, 
											  rgbquad[background].rgbBlue);

	for (int i = 0;i < numColors;i++)
		{
		if (i != background)
			{
			colors[i] = gif.GlobalColorAllocate(rgbquad[i].rgbRed, 
												rgbquad[i].rgbGreen, 
												rgbquad[i].rgbBlue);
			}
		}

	BYTE* pPixel;
	for (int y = 0;y < Height();y++)
		{
		pPixel = (BYTE*)GetPixelAddress(0,y);
		for (int x = 0;x < Width();x++,pPixel++)
			{
			_ASSERT(0 <= (*pPixel) && (*pPixel) < numColors);
			gif.SetPixel(x, y, colors[*pPixel]);
			}
		}

	gif.SetInterlace(bInterlace);
	gif.SetTransparent(transparent);
	return gif.Save(pszFileName);
	}
////////////////////////////////////////////////////////////////////
unsigned int CImage::NumColorEntries() const
    {
    _ASSERT(m_hImage);
	unsigned int numColors;

    if (ds.dsBmih.biClrUsed != 0)
		{
        numColors = ds.dsBmih.biClrUsed;
		}
	else
		{
		switch(ds.dsBmih.biBitCount)
			{
			case 1:
				numColors = 2;
				break;
			case 4:
				numColors = 16;
				break;
			case 8:
				numColors = 256;
			};
		}

	return numColors;
    }

////////////////////////////////////////////////////////////////////
UINT CImage::GetDIBColorTable(UINT uStartIndex, UINT cEntries, RGBQUAD* pColors) const
    {
    _ASSERT(m_hImage);

	CImageDC memdc;
	memdc.CreateCompatibleDC();
	memdc.SelectBitmap(m_hImage);
    return ::GetDIBColorTable(memdc, uStartIndex, cEntries, pColors);
    }

////////////////////////////////////////////////////////////////////
UINT CImage::GetColorTable(CImageColorTable& clrTbl) const
	{
    _ASSERT(m_hImage);

	CImageDC memdc;
	memdc.CreateCompatibleDC();
	memdc.SelectBitmap(m_hImage);
    return ::GetDIBColorTable(memdc, 0, clrTbl.size(), clrTbl.m_prgb);
	}

////////////////////////////////////////////////////////////////////
struct MapIndex {
	bool bMapped;
	unsigned char newIndex;
	};

class MapIndexArray {
	public:

		MapIndexArray(int n) : m_p(new MapIndex[n]) 
			{::ZeroMemory(m_p, sizeof(MapIndex)*n);
			_ASSERT(false == m_p[0].bMapped);
			#ifdef _DEBUG
			m_size=n;
			#endif //_DEBUG
			}
		~MapIndexArray() {delete[] m_p;}
		MapIndex& operator[] (int n) {_ASSERT((n>=0)&&(n<m_size));return m_p[n];}

	private:
		MapIndex* m_p;
		#ifdef _DEBUG
		int m_size;
		#endif // _DEBUG
	};


////////////////////////////////////////////////////////////////////
bool CImage::SetColorTable(const CImageColorTable& clrTbl, bool bRemap)
	{
    _ASSERT(m_hImage);
	_ASSERT(BPP() == 8);

	if (bRemap)
		{
		// go through all pixels and map to new or nearest color
		unsigned int numColors = NumColorEntries();
		// create palette of new color table, so we can use GetNearestPaletteIndex
		CImagePalette newPal;
		if (!newPal.CreatePalette(clrTbl))
			return false;
		// get the current color table
		CImageColorTable oldClrTbl(numColors);
		GetColorTable(oldClrTbl);
		unsigned char* pPixel;
		UINT newIndex;
		// allocate as many structures as there are current colors
		// MapIndex are used for quick lookup for color table entries that
		// have already been converted to new ones by GetNearestPaletteIndex
		MapIndexArray mp_array(numColors);
		for (int y = 0;y < Height();y++)
			{
			pPixel = static_cast<unsigned char*>(GetPixelAddress(0,y));
			for (int x = 0;x < Width();x++,pPixel++)
				{
				_ASSERT(0 <= (*pPixel) && (*pPixel) < numColors);
				if (false == mp_array[*pPixel].bMapped)
					{
					// color not mapped to new color table
					mp_array[*pPixel].bMapped = true;
					newIndex = newPal.GetNearestPaletteIndex(oldClrTbl.color(*pPixel));
					if (CLR_INVALID == newIndex)
						return false;
					mp_array[*pPixel].newIndex = static_cast<unsigned char>(newIndex);
					}
				// set pixel to new color
				*pPixel = mp_array[*pPixel].newIndex;
				}
			}
		}

	// now all pixels are remapped to new colors, insert new color table
	CImageDC memdc;
	if (!memdc.CreateCompatibleDC())
		return false;
	memdc.SelectBitmap(m_hImage);
    UINT result = ::SetDIBColorTable(memdc, 0, clrTbl.size(), clrTbl.m_prgb);
	SetNumColorEntries(clrTbl.size());

    return result? true:false;
	}

////////////////////////////////////////////////////////////////////
#ifdef _CPPUNWIND 
#pragma warning(disable : 4786)  
void CImage::OptimizeForSize()
	{
    _ASSERT(m_hImage);
	_ASSERT(BPP() == 8);
	std::set<unsigned char> colorset;
	std::set<COLORREF> rgbcolorset;

	unsigned char* pPixel;
	unsigned char lastColor;
	int height = Height();
	int width = Width();

	CImageColorTable clrTbl(NumColorEntries());
	GetColorTable(clrTbl);

	// lastcolor is a quick lookup value. We need to
	// initialise it before we use it though. We make it
	// equal to something that is not the same as the first
	// pixel so that the test is guaranteed to fail the first time
	lastColor = static_cast<unsigned char>(~(*(static_cast<unsigned char*>(GetPixelAddress(0,0)))));

	// go through each pixel and determine which colors 
	// are actually used.
	for (int y = 0;y < height;y++)
		{
		pPixel = static_cast<unsigned char*>(GetPixelAddress(0,y));
		for (int x = 0;x < width;x++,pPixel++)
			{
			// does the color set contain this palette index ?
			// first check lastColor as colors are usually
			// in consecutive runs of pixels
			if (*pPixel != lastColor)
				{
				// was not last color used. Update this variable.
				lastColor = *pPixel;

				//Check the colorset for this color
				if (colorset.find(lastColor) == colorset.end())
					{
					// add to color set
					colorset.insert(lastColor);
					RGBQUAD& rgb = clrTbl[lastColor];
					rgbcolorset.insert(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
					}
				}
			}
		}

	_RPT1(_CRT_WARN,"Number of different indices in image = %i\n",colorset.size());
	_RPT1(_CRT_WARN,"Number of different RGB colors = %i\n",rgbcolorset.size());

	// if number of colors in color set is less than NumColorEntries, or if
	// we are using duplicate RGB values in separate color
	// indices, then we can optimize !
	if ((colorset.size() < NumColorEntries()) || (rgbcolorset.size() < colorset.size()))
		{
		CImageColorTable newTbl(rgbcolorset.size());
		std::set<COLORREF>::iterator rgbIter;
		int n = 0;
		for (rgbIter = rgbcolorset.begin();rgbIter != rgbcolorset.end();rgbIter++,n++)
			{
			RGBQUAD& rgb = newTbl[n];
			rgb.rgbRed = GetRValue(*rgbIter);
			rgb.rgbGreen = GetGValue(*rgbIter);
			rgb.rgbBlue = GetBValue(*rgbIter);
			rgb.rgbReserved = 0;
			}

		// go through entire bitmap 
		// remapping all pixels to new palette
		SetColorTable(newTbl, true);
		}
	}
#endif //  _CPPUNWIND 

////////////////////////////////////////////////////////////////////
void CImageColorTable::resize(int newsize)
	{
	RGBQUAD* pnewrgb = new RGBQUAD[newsize];

	// copy over the old colortable
	memcpy(pnewrgb, m_prgb,(sizeof(RGBQUAD)*m_size));
	m_size = newsize;
	delete[] m_prgb;
	m_prgb = pnewrgb;
	}

////////////////////////////////////////////////////////////////////
bool CImagePalette::CreatePalette(const CImage& dib) 
    {
	CImageColorTable clrTbl(dib.NumColorEntries());

	dib.GetColorTable(clrTbl);
	return CreatePalette(clrTbl);
    }

////////////////////////////////////////////////////////////////////
bool CImagePalette::CreatePalette(const CImageColorTable& clrTbl)
	{
	clear();

	LOGPALETTE* pPal = (LOGPALETTE*)alloca(sizeof(LOGPALETTE)+clrTbl.size()*sizeof(PALETTEENTRY));
    for(int i=0; i < clrTbl.size(); i++)
        {
        pPal->palPalEntry[i].peRed   = clrTbl[i].rgbRed;
        pPal->palPalEntry[i].peGreen = clrTbl[i].rgbGreen;
        pPal->palPalEntry[i].peBlue  = clrTbl[i].rgbBlue;
        pPal->palPalEntry[i].peFlags = 0;
        }   
	pPal->palVersion = 0x300; 
    pPal->palNumEntries = (WORD)clrTbl.size(); 
    m_hPal = ::CreatePalette(pPal);

    return m_hPal ? true:false;
	}

////////////////////////////////////////////////////////////////////
void CImagePalette::clear()
	{
	if (m_hPal)
		{
		::DeleteObject(m_hPal);
		init();
		}
	}

////////////////////////////////////////////////////////////////////
#ifdef _DEBUG
void CImagePalette::DebugOutput()
	{
	_ASSERT(m_hPal);
	PALETTEENTRY pal[256];
	int num = ::GetPaletteEntries(m_hPal, 0, 256, (LPPALETTEENTRY)(&pal)); 

	if (num != 0)
		{
		for (int i = 0;i < num;i++)
			{
			_RPT4(_CRT_WARN,"[%i]=(%i,%i,%i)\n",i,pal[i].peRed,pal[i].peGreen, pal[i].peBlue);
			}
		}
	else
		{
		_RPT0(_CRT_WARN,"::GetPaletteEntries API failed\n");
		}
	}
#endif // _DEBUG

////////////////////////////////////////////////////////////////////
CNetscapeColorTable::CNetscapeColorTable():CImageColorTable(216)
	{
	// fill with the common browser palette colors
	for (int red = 0;red < 6;red++)
		{
		for (int green = 0;green < 6;green++)
			{
			for (int blue = 0;blue < 6;blue++)
				{
				RGBQUAD& rgb	= m_prgb[red*36 + green*6 + blue];
				rgb.rgbRed		= static_cast<unsigned char>(red * 0x33);
				rgb.rgbGreen	= static_cast<unsigned char>(green * 0x33);
				rgb.rgbBlue		= static_cast<unsigned char>(blue * 0x33);
				rgb.rgbReserved = 0;
				}
			}
		}
	}

////////////////////////////////////////////////////////////////////
#ifdef _DEBUG
void CImageColorTable::DebugOutput()
	{
	for (int i = 0;i < m_size;i++)
		{
		_RPT4(_CRT_WARN,"[%i]=%i,%i,%i\n",i,m_prgb[i].rgbRed,m_prgb[i].rgbGreen,m_prgb[i].rgbBlue);
		}
	}

#endif // _DEBUG

////////////////////////////////////////////////////////////////////
void CImageDC::init()
	{
	m_hdc = 0;
	m_hOldBmp = 0;
	m_hOldPen = 0;
	m_hOldBrush = 0;
	m_hOldFont = 0;
	m_hOldPal = 0;
	}

////////////////////////////////////////////////////////////////////
void CImageDC::clear()
	{
	if (m_hdc)
		{
		// select all old gdi objects back in
		if (m_hOldBmp)
			::SelectObject(m_hdc, m_hOldBmp);
		if (m_hOldPen)
			::SelectObject(m_hdc, m_hOldPen);
		if (m_hOldBrush)
			::SelectObject(m_hdc, m_hOldBrush);
		if (m_hOldFont)
			::SelectObject(m_hdc, m_hOldFont);
		if (m_hOldPal)
			::SelectObject(m_hdc, m_hOldPal);

		// now delete the dc itself
		::DeleteDC(m_hdc);
		}
	}

