// lukas@spray.se 1998

#if !defined(_CIMAGEGIF_H)
#define _CIMAGEGIF_H 

#include <crtdbg.h>
#include "iostream.h"
#include <string>

#define HSIZE 5003

////////////////////////////////////////////////////////////////////
struct Color {
	unsigned char m_red;
	unsigned char m_green;
	unsigned char m_blue;
	bool m_bOpen;
	};

inline ostream& operator << (ostream& os, const Color& clr)
	{os << clr.m_red << clr.m_green << clr.m_blue;return os;}

////////////////////////////////////////////////////////////////////
class ColorTable {
	public:

		ColorTable() {init();}

		int ColorAllocate(int r, int g, int b);
		int bpp() const;

	private:

		void init();

		Color m_colors[256];
		int m_colorstotal;

		friend ostream& operator << (ostream& os, const ColorTable& tbl);
	};

////////////////////////////////////////////////////////////////////
class LogicalScreenDescriptor {
	public:

		LogicalScreenDescriptor() {init();}

		void SetLogicalWidth(int w) {m_width = w;}
		void SetLogicalHeight(int h){m_height= h;}

		int GetLogicalWidth() {return m_width;}
		int GetLogicalHeight(){return m_height;}

		void SetGlobalColorTable(const ColorTable& tbl)
			{m_pClrTbl = &tbl;}

		void SetBackgroundColorIndex(int index)
			{m_bgcolor = index;}

		friend ostream& operator << (ostream& os, const LogicalScreenDescriptor&);

	private:

		void init() {m_bgcolor = 0;m_pClrTbl = NULL;}

		int m_width;
		int m_height;
		const ColorTable* m_pClrTbl;
		int m_bgcolor;

	};

////////////////////////////////////////////////////////////////////
class GraphicControlExt {
	public:

		GraphicControlExt() {init();}

		void SetTransparent(int transparent) {m_transparent = transparent;}
		int GetTransparent() const {return m_transparent;}
		bool IsTransparent() const {return m_transparent < 0? false:true;}

		friend ostream& operator << (ostream& os, const GraphicControlExt&);

	private:

		void init() {m_transparent = -1;}

		int m_transparent;
	};

////////////////////////////////////////////////////////////////////
class CommentExt {
	public:

		CommentExt() {init();}

		void SetComment(const std::string& s) {m_strComment = s;}

		friend ostream& operator << (ostream& os, const CommentExt&);

	private:

		void init();
		std::string m_strComment;

	};

////////////////////////////////////////////////////////////////////
class ImageDescriptor {
	public:

		ImageDescriptor() {init();}

		void SetLeft(int left)		{m_left = left;}
		void SetTop(int top)		{m_top = top;}
		void SetWidth(int width)	{m_width = width;}
		int GetWidth() const		{return m_width;}
		int GetHeight() const		{return m_height;}
		void SetHeight(int height)	{m_height = height;}
		void SetInterlace(bool b)	{m_bInterlace = b;}
		bool IsInterlace() const	{return m_bInterlace;}

		friend ostream& operator << (ostream& os, const ImageDescriptor&);

	private:

		void init() {m_left=0;m_top=0;m_width=0;m_height=0;
					m_bLocalColorTable=false;m_bInterlace=false;}

		int m_left;
		int m_top;
		int m_width;
		int m_height;
		bool m_bLocalColorTable;
		bool m_bInterlace;

	};

////////////////////////////////////////////////////////////////////
class ImagePixels {
	public:

		ImagePixels() {init();}
		~ImagePixels() {clear();}

		bool Create(int width, int height);
		int GetPixel(int x, int y) const;
		void SetPixel(int x, int y, int val);

		void Write(ostream& os, int initcodesize, bool _bInterlace);

	private:

		void BumpPixel();
		int GIFNextPixel();
		void GIFEncode(ostream& os);

		void compress(int init_bits, ostream& os);
		void output(int code);
		void cl_block(void);           
		void cl_hash(register int hsize);                      
		void char_init(void);
		void char_out(int c);
		void flush_char(void);

		int curx;
		int cury;
		int Pass;
		long CountDown;	
		bool bInterlace;
		
		int n_bits; 
		int maxbits;
		int maxcode; 
		int maxmaxcode;
		
		int htab [HSIZE];
		unsigned short codetab [HSIZE];
		int hsize;
		int free_ent;     
		int clear_flg;
		int offset;
		long int in_count;           
		long int out_count; 
		int g_init_bits;
		ostream* g_outfile;
		int ClearCode;
		int EOFCode;
		unsigned long cur_accum;
		int cur_bits;
		static const unsigned long masks[];
		int a_count;
		char accum[256];

		void init_statics();

		void init() {pixels = 0;}
		void clear();

		int m_width;
		int m_height;
		unsigned char** pixels;
	};

////////////////////////////////////////////////////////////////////

class CImageGif {
	public:

		CImageGif() {init();}
		~CImageGif(){clear();}

		bool CreateLogicalWidth(int width, int height); 

		bool Save(const char* pszFileName);
		int GetPixel(int x, int y);
		void SetPixel(int x, int y, int val);
		int GlobalColorAllocate(int r, int g, int b)
			{return m_globalColorTable.ColorAllocate(r,g,b);}

		void SetInterlace(bool bInterlace) {imd.SetInterlace(bInterlace);}
		void SetTransparent(int transparent) {m_gct.SetTransparent(transparent);}

		void SetImageLeft(int left)		{imd.SetLeft(left);}
		void SetImageTop(int top)		{imd.SetTop(top);}
		void SetImageWidth(int width)	{imd.SetWidth(width);}
		void SetImageHeight(int height)	{imd.SetHeight(height);}

	private:

		ColorTable m_globalColorTable;
		LogicalScreenDescriptor m_log_scr_desc;
		GraphicControlExt m_gct;
		ImageDescriptor imd;
		ImagePixels img;

		void GIFEncode(ostream& os);

		void clear();
		void init();

	};

#endif //_CIMAGEGIF_H