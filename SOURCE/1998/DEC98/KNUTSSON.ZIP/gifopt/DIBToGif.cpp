// lukas@spray.se 1998
// DIBToGif.cpp : Implementation of CDIBToGif
#include "stdafx.h"
#include "gifoptimise.h"
#include "DIBToGif.h"
#include "CImage.h"

#pragma warning(disable:4310) // prevents awkward warning on VARIANT_BOOL
/////////////////////////////////////////////////////////////////////////////
// CDIBToGif

STDMETHODIMP CDIBToGif::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IDIBToGif,
	};
	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CDIBToGif::OptimiseAndSaveAsGif(BSTR dibfile, BSTR outgiffile,
		VARIANT_BOOL bInterlace,int backgroundIndex,int transparentIndex)
	{	
	try
		{
		USES_CONVERSION;
		LPCTSTR pszFilename = OLE2CT(dibfile);
		CImage im;
		if (!im.LoadImage(pszFilename))
			return E_FAIL;
		
		im.OptimizeForSize();
		pszFilename = OLE2CT(outgiffile);

		bool _interlace = (bInterlace == VARIANT_TRUE)? true:false;
		
		if (!im.SaveAsGif(pszFilename,_interlace,
			backgroundIndex,transparentIndex))
			return E_FAIL;
		
		return S_OK;
		}
	catch(...)
		{
		return E_FAIL;
		}
	}
