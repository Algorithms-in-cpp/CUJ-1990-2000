// lukas@spray.se 1998
// DIBToGif.h : Declaration of the CDIBToGif

#ifndef __DIBTOGIF_H_
#define __DIBTOGIF_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDIBToGif
class ATL_NO_VTABLE CDIBToGif : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDIBToGif, &CLSID_DIBToGif>,
	public ISupportErrorInfo,
	public IDispatchImpl<IDIBToGif, &IID_IDIBToGif, &LIBID_GIFOPTIMISELib>
{
public:
	CDIBToGif()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DIBTOGIF)
DECLARE_NOT_AGGREGATABLE(CDIBToGif)

BEGIN_COM_MAP(CDIBToGif)
	COM_INTERFACE_ENTRY(IDIBToGif)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IDIBToGif
public:
	STDMETHOD(OptimiseAndSaveAsGif)(/*[in]*/BSTR dibfile,/*[in]*/ BSTR outgiffile,/*[in]*/VARIANT_BOOL interlace,/*[in]*/int backgroundIndex,/*[in]*/int transparentIndex);
};

#endif //__DIBTOGIF_H_
