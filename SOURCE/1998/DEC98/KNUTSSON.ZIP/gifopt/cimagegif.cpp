// lukas@spray.se 1998
#include "stdafx.h"
#include "cimagegif.h"
#include "fstream.h"

void Putword(int w, ostream& os);

////////////////////////////////////////////////////////////////////
void ColorTable::init()
	{
	m_colorstotal = 0;
	for (int i = 0;i < 256;i++)
		m_colors[i].m_bOpen = true;
	}

////////////////////////////////////////////////////////////////////
int ColorTable::ColorAllocate(int r, int g, int b)
	{
	int index = -1;
	for (int i = 0;i < m_colorstotal;i++) 
		{
		if (m_colors[i].m_bOpen) 
			{
			index = i;
			break;
			}
		}
	
	if (index == (-1)) 
		{
		index = m_colorstotal;
		if (index == 256) 
			{
			return -1;
			}
		m_colorstotal++;
		}

	m_colors[index].m_red	= static_cast<char>(r);
	m_colors[index].m_green	= static_cast<char>(g);
	m_colors[index].m_blue	= static_cast<char>(b);
	m_colors[index].m_bOpen = false;

	return index;
	}

////////////////////////////////////////////////////////////////////
int ColorTable::bpp() const
	{
    if (m_colorstotal <= 2 )
		return 1;
    else if (m_colorstotal <= 4 )
        return 2;
    else if (m_colorstotal <= 8 )
        return 3;
    else if (m_colorstotal <= 16 )
        return 4;
    else if (m_colorstotal <= 32 )
        return 5;
    else if (m_colorstotal <= 64 )
        return 6;
    else if (m_colorstotal <= 128 )
        return 7;
    else if (m_colorstotal <= 256 )
        return 8;
    return 0;
    }

////////////////////////////////////////////////////////////////////
ostream& operator << (ostream& os, const ColorTable& tbl)
	{
	int colormapsize = 1 << tbl.bpp();
	for (int i = 0;i < colormapsize;i++)
		os << tbl.m_colors[i];

	return os;
	}

////////////////////////////////////////////////////////////////////
ostream& operator << (ostream& os, const LogicalScreenDescriptor& desc)
	{
	Putword(desc.m_width, os);
    Putword(desc.m_height, os);

	unsigned char b = 0;

	if (desc.m_pClrTbl)
		{
		b = 0x80; // there is a global color map
		b |= (desc.m_pClrTbl->bpp() - 1) << 5;// OR in resolution
		b |= (desc.m_pClrTbl->bpp() - 1);
		}

	os << b;

	//write out background color
	os << static_cast<char>(desc.m_bgcolor);

	// write out pixel aspect ratio.We assume this to be zero.
	os << static_cast<char>(0);

	return os;
	}

////////////////////////////////////////////////////////////////////
ostream& operator << (ostream& os, const GraphicControlExt& gct)
	{
	os << '!'; // Extension Introducer
	os << (static_cast<unsigned char>(/*char)*/0xf9)); //Graphic Control Label
	os << ((char)4); //Block Size

	unsigned char b = 0;
	if (gct.m_transparent >= 0)
		b |= 0x1;
	
	os << b;
	os << ((char)0); //Delay Time
	os << ((char)0);
	os << ((unsigned char)gct.m_transparent);//Transparent Color Index
	os << ((char)0);//Block Terminator  

	return os;
	}

////////////////////////////////////////////////////////////////////
ostream& operator << (ostream& os, const ImageDescriptor& imd)
	{	
	os << ',';

    //Write the Image header
    Putword(imd.m_left, os);
    Putword(imd.m_top, os);

    Putword(imd.m_width, os);
    Putword(imd.m_height, os);

    //Write out whether or not the image is interlaced
    if (imd.m_bInterlace)
		{
		os << ((char)0x40);
		}
    else
		{
		os << ((char)0x00);
		}
	return os;
	}

////////////////////////////////////////////////////////////////////
void ImagePixels::clear()
	{
	//if it exists, clear current pixel array
	if (pixels)
		{
		for (int i = 0;i < m_width;i++)
			{
			delete[] pixels[i];
			}
		delete[] pixels;
		pixels = NULL;
		}
	}

////////////////////////////////////////////////////////////////////
bool ImagePixels::Create(int width, int height)
	{
	_ASSERT(width > 0 && height > 0);
	m_width = width;
	m_height = height;
	pixels = new unsigned char* [width];
	for (int i = 0;i < width;i++)
		{
		pixels[i] = new unsigned char[height];
		}

	return true;
	}

////////////////////////////////////////////////////////////////////
int ImagePixels::GetPixel(int x, int y) const
	{
	_ASSERT((x>=0) && (x < m_width));
	_ASSERT((y>=0) && (y < m_height));

	return pixels[x][y];
	}

////////////////////////////////////////////////////////////////////
void ImagePixels::SetPixel(int x, int y, int val)
	{
	_ASSERT((x>=0) && (x < m_width));
	_ASSERT((y>=0) && (y < m_height));

	pixels[x][y] = static_cast<unsigned char>(val);
	}

////////////////////////////////////////////////////////////////////
void ImagePixels::Write(ostream& os, int initcodesize, bool _bInterlace)
	{
	init_statics();
    CountDown = m_width * m_height;

	bInterlace = _bInterlace;

	//Write out the initial code size
	os << ((char)(initcodesize));

	//Go and actually compress the data
    compress(initcodesize+1, os);
	}

////////////////////////////////////////////////////////////////////
void CImageGif::clear()
	{
	}

////////////////////////////////////////////////////////////////////
void CImageGif::init()
	{
	}

////////////////////////////////////////////////////////////////////
bool CImageGif::CreateLogicalWidth(int width, int height)
	{
	m_log_scr_desc.SetLogicalWidth(width);
	m_log_scr_desc.SetLogicalHeight(height);

	// connect up to global color table
	m_log_scr_desc.SetGlobalColorTable(m_globalColorTable);

	img.Create(width, height);

	return true;
	}

////////////////////////////////////////////////////////////////////
bool CImageGif::Save(const char* pszFileName)
	{
	//init_statics();
	ofstream os;
	os.open(pszFileName, ios::out | ios::binary | ios::trunc);
	if (!os)
		return false;
	GIFEncode(os);
	return true;
	}

////////////////////////////////////////////////////////////////////
int CImageGif::GetPixel(int x, int y)
	{
	return img.GetPixel(x,y);
	}

////////////////////////////////////////////////////////////////////
void CImageGif::SetPixel(int x, int y, int val)
	{
	img.SetPixel(x,y,val);
	}


/* Code drawn from ppmtogif.c, from the pbmplus package
**
** Based on GIFENCOD by David Rowley <mgardi@watdscu.waterloo.edu>. A
** Lempel-Zim compression based on "compress".
**
** Modified by Marcel Wijkstra <wijkstra@fwi.uva.nl>
**
** Copyright (C) 1989 by Jef Poskanzer.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
**
** The Graphics Interchange Format(c) is the Copyright property of
** CompuServe Incorporated.  GIF(sm) is a Service Mark property of
** CompuServe Incorporated.
*/


/*
 * Bump the 'curx' and 'cury' to point to the next pixel
 */

void ImagePixels::BumpPixel()
	{  
    // Bump the current X position  
    ++curx;
  
    /*If we are at the end of a scan line, set curx back to the beginning
    If we are interlaced, bump the cury to the appropriate spot,
    otherwise, just increment it.*/     
    if (curx == m_width) 
		{
        curx = 0;

        if (!bInterlace)
			++cury;
        else 
			{
			switch( Pass ) 
				{
				case 0:
					cury += 8;
					if (cury >= m_height) 
						{
                        ++Pass;
                        cury = 4;
						}
					break;

				case 1:
					cury += 8;
					if (cury >= m_height) 
						{
                        ++Pass;
                        cury = 2;
						}
					break;

				case 2:
					cury += 4;
					if (cury >= m_height) 
						{
						++Pass;
						cury = 1;
						}
					break;

				case 3:
					cury += 2;
					break;
                }
			}
		}
	}

/*
 * Return the next pixel from the image
 */

int ImagePixels::GIFNextPixel()
	{
    int r;

    if (CountDown == 0)
		return EOF;

    --CountDown;

    r = GetPixel(curx, cury);

    BumpPixel();

    return r;
	}


void CImageGif::GIFEncode(ostream& os)
	{
	int BitsPerPixel = m_globalColorTable.bpp();
    int InitCodeSize;
    
    //Calculate number of bits we are expecting
    //CountDown = m_log_scr_desc.GetLogicalHeight() * m_log_scr_desc.GetLogicalWidth();

    //The initial code size
    if (BitsPerPixel <= 1)
		InitCodeSize = 2;
    else
		InitCodeSize = BitsPerPixel;

    //Set up the current x and y position
    //curx = cury = 0;

    //Write the Magic header
	os << ( m_gct.IsTransparent()? "GIF89a":"GIF87a" );

	os << m_log_scr_desc;
	os << m_globalColorTable;
	os << m_gct;
	os << imd;

	img.Write(os,InitCodeSize,imd.IsInterlace());

    //Write out a Zero-length packet (to end the series)
	os << ((char)0);

    //Write the GIF file terminator
	os << ';';
	}

//Write out a word to the GIF file
void Putword(int w, ostream& os)
	{
	os << ((char)(w & 0xff));
	os << ((char)((w / 256) & 0xff));
	}

/***************************************************************************
 *
 *  GIFCOMPR.C       - GIF Image compression routines
 *
 *  Lempel-Ziv compression based on 'compress'.  GIF modifications by
 *  David Rowley (mgardi@watdcsu.waterloo.edu)
 *
 ***************************************************************************/

/*
 * General DEFINEs
 */

#define GIFBITS    12

#define HSIZE  5003            /* 80% occupancy */

typedef unsigned char char_type;

/*
 *
 * GIF Image compression - modified 'compress'
 *
 * Based on: compress.c - File compression ala IEEE Computer, June 1984.
 *
 * By Authors:  Spencer W. Thomas       (decvax!harpo!utah-cs!utah-gr!thomas)
 *              Jim McKie               (decvax!mcvax!jim)
 *              Steve Davies            (decvax!vax135!petsd!peora!srd)
 *              Ken Turkowski           (decvax!decwrl!turtlevax!ken)
 *              James A. Woods          (decvax!ihnp4!ames!jaw)
 *              Joe Orost               (decvax!vax135!petsd!joe)
 *
 */
#define MAXCODE(n_bits)        (((int) 1 << (n_bits)) - 1)
#define HashTabOf(i)       htab[i]
#define CodeTabOf(i)    codetab[i]

/*
 * To save much memory, we overlay the table used by compress() with those
 * used by decompress().  The tab_prefix table is the same size and type
 * as the codetab.  The tab_suffix table needs 2**GIFBITS characters.  We
 * get this from the beginning of htab.  The output stack uses the rest
 * of htab, and contains characters.  There is plenty of room for any
 * possible stack (stack used to be 8000 characters).
 */

#define tab_prefixof(i) CodeTabOf(i)
#define tab_suffixof(i) ((char_type*)(htab))[i]
#define de_stack        ((char_type*)&tab_suffixof((int)1<<GIFBITS))

/*
 * block compression parameters -- after all codes are used up,
 * and compression rate changes, start over.
 */

/*
 * compress stdin to stdout
 *
 * Algorithm:  use open addressing double hashing (no chaining) on the
 * prefix code / next character combination.  We do a variant of Knuth's
 * algorithm D (vol. 3, sec. 6.4) along with G. Knott's relatively-prime
 * secondary probe.  Here, the modular division first probe is gives way
 * to a faster exclusive-or manipulation.  Also do block compression with
 * an adaptive reset, whereby the code table is cleared when the compression
 * ratio decreases, but after the table fills.  The variable-length output
 * codes are re-sized at this point, and a special CLEAR code is generated
 * for the decompressor.  Late addition:  construct the table according to
 * file size for noticeable speed improvement on small files.  Please direct
 * questions about this implementation to ames!jaw.
 */

void ImagePixels::compress(int init_bits, ostream& os)
	{
    register long fcode;
    register int i /* = 0 */;
    register int c;
    register int ent;
    register int disp;
    register int hsize_reg;
    register int hshift;
	
    /*
	* Set up the globals:  g_init_bits - initial number of bits
	*                      g_outfile   - pointer to output file
	*/
    g_init_bits = init_bits;
    g_outfile = &os;
	
    /*
	* Set up the necessary values
	*/
    offset = 0;
    out_count = 0;
    clear_flg = 0;
    in_count = 1;
    maxcode = MAXCODE(n_bits = g_init_bits);
	
    ClearCode = (1 << (init_bits - 1));
    EOFCode = ClearCode + 1;
    free_ent = ClearCode + 2;
	
    char_init();
	
    ent = GIFNextPixel();
	
    hshift = 0;
    for ( fcode = (long) hsize;  fcode < 65536L; fcode *= 2L )
        ++hshift;
    hshift = 8 - hshift;                /* set hash code range bound */
	
    hsize_reg = hsize;
    cl_hash( (int) hsize_reg);            /* clear hash table */
	
    output( (int)ClearCode );
	
    while ((c = GIFNextPixel()) != EOF) 
		{  		
        ++in_count;
		
        fcode = (long) (((long) c << maxbits) + ent);
        i = (((int)c << hshift) ^ ent);    /* xor hashing */
		
        if ( HashTabOf (i) == fcode ) 
			{
            ent = CodeTabOf(i);
            continue;
			} 
		else if ((long)HashTabOf (i) < 0)      /* empty slot */
				goto nomatch;
			disp = hsize_reg - i;           /* secondary hash (after G. Knott) */
			if (i == 0)
				disp = 1;
probe:
			if ((i -= disp) < 0)
				i += hsize_reg;
			
			if (HashTabOf(i) == fcode) 
				{
				ent = CodeTabOf (i);
				continue;
				}
			if ((long)HashTabOf(i) > 0)
				goto probe;
nomatch:
			output((int) ent);
			++out_count;
			ent = c;
			if (free_ent < maxmaxcode) 
				{
				#pragma warning(disable:4244)
				CodeTabOf (i) = free_ent++; /* code -> hashtable */
				#pragma warning(default:4244)

				HashTabOf (i) = fcode;
				}
			else
				cl_block();
		}
		/*
		* Put out the final code.
	*/
    output((int)ent);
    ++out_count;
    output((int)EOFCode);
	}

/*****************************************************************
 * TAG( output )
 *
 * Output the given code.
 * Inputs:
 *      code:   A n_bits-bit integer.  If == -1, then EOF.  This assumes
 *              that n_bits =< (long)wordsize - 1.
 * Outputs:
 *      Outputs code to the file.
 * Assumptions:
 *      Chars are 8 bits long.
 * Algorithm:
 *      Maintain a GIFBITS character long buffer (so that 8 codes will
 * fit in it exactly).  Use the VAX insv instruction to insert each
 * code in turn.  When the buffer fills up empty it and start over.
 */

//unsigned long CImageGif::cur_accum = 0;
//int CImageGif::cur_bits = 0;

const unsigned long ImagePixels::masks[] = 
	{ 0x0000, 0x0001, 0x0003, 0x0007, 0x000F,
      0x001F, 0x003F, 0x007F, 0x00FF,
      0x01FF, 0x03FF, 0x07FF, 0x0FFF,
      0x1FFF, 0x3FFF, 0x7FFF, 0xFFFF };


void ImagePixels::output(int code)
	{
    cur_accum &= masks[cur_bits];
	
    if (cur_bits > 0)
        cur_accum |= ((long)code << cur_bits);
    else
        cur_accum = code;
	
    cur_bits += n_bits;
	
    while( cur_bits >= 8 ) 
		{
        char_out((unsigned int)(cur_accum & 0xff));
        cur_accum >>= 8;
        cur_bits -= 8;
		}
	
	/*
	* If the next entry is going to be too big for the code size,
	* then increase it, if possible.
	*/
	if (free_ent > maxcode || clear_flg) 
		{		
		if( clear_flg ) 
			{			
			maxcode = MAXCODE (n_bits = g_init_bits);
			clear_flg = 0;			
            } 
		else 
			{			
			++n_bits;
			if (n_bits == maxbits)
				maxcode = maxmaxcode;
			else
				maxcode = MAXCODE(n_bits);
			}
		}
	
    if( code == EOFCode ) 
		{
		/*
		* At EOF, write the rest of the buffer.
		*/
        while( cur_bits > 0 ) 
			{
			char_out( (unsigned int)(cur_accum & 0xff) );
			cur_accum >>= 8;
			cur_bits -= 8;
			}
		
        flush_char();		
        (*g_outfile).flush();		
        /*if (ferror(g_outfile))
			return;*/
		}
	}


/*
 * Clear out the hash table
 */ 
/* table clear for block compress */
void ImagePixels::cl_block (void)            
	{	
	cl_hash ( (int) hsize );
	free_ent = ClearCode + 2;
	clear_flg = 1;
	
	output( (int)ClearCode );
	}

void ImagePixels::cl_hash(register int hsize)          /* reset code table */                        
	{
	
	register int *htab_p = htab+hsize;
	
	register long i;
	register long m1 = -1;
	
	i = hsize - 16;
	do {                            /* might use Sys V memset(3) here */
		*(htab_p-16) = m1;
		*(htab_p-15) = m1;
		*(htab_p-14) = m1;
		*(htab_p-13) = m1;
		*(htab_p-12) = m1;
		*(htab_p-11) = m1;
		*(htab_p-10) = m1;
		*(htab_p-9) = m1;
		*(htab_p-8) = m1;
		*(htab_p-7) = m1;
		*(htab_p-6) = m1;
		*(htab_p-5) = m1;
		*(htab_p-4) = m1;
		*(htab_p-3) = m1;
		*(htab_p-2) = m1;
		*(htab_p-1) = m1;
		htab_p -= 16;
        } while ((i -= 16) >= 0);
	
	for ( i += 16; i > 0; --i )
		*--htab_p = m1;
	}



/******************************************************************************
 *
 * GIF Specific routines
 *
 ******************************************************************************/

/*
 * Number of characters so far in this 'packet'
 */

/*
 * Set up the 'byte output' routine
 */
void ImagePixels::char_init(void)
	{
    a_count = 0;
	}

/*
 * Define the storage for the packet accumulator
 */
//char CImageGif::accum[256];

/*
 * Add a character to the end of the current packet, and if it is 254
 * characters, flush the packet to disk.
 */
void ImagePixels::char_out(int c)
	{
#pragma warning(disable:4244)
    accum[a_count++] = c;
#pragma warning(default:4244)
    if (a_count >= 254)
		flush_char();
	}


/*
 * Flush the packet to disk, and reset the accumulator
 */
void ImagePixels::flush_char(void)
	{
    if (a_count > 0) 
		{
        //fputc(a_count, g_outfile );
		(*g_outfile) << ((char)a_count);
        //fwrite(accum, 1, a_count, g_outfile );
		(*g_outfile).write(accum, a_count);
        a_count = 0;
		}
	}

void ImagePixels::init_statics(void) 
	{
	/* Some of these are properly initialized later. What I'm doing
		here is making sure code that depends on C's initialization
		of statics doesn't break when the code gets called more
		than once. */
	curx = 0;
	cury = 0;
	CountDown = 0;
	Pass = 0;
	a_count = 0;
	cur_accum = 0;
	cur_bits = 0;
	g_init_bits = 0;
	g_outfile = NULL;
	ClearCode = 0;
	EOFCode = 0;
	free_ent = 0;
	clear_flg = 0;
	offset = 0;
	in_count = 1;
	out_count = 0;	
	hsize = HSIZE;
	n_bits = 0;
	maxbits = GIFBITS;
	maxcode = 0;
	maxmaxcode = (int)1 << GIFBITS;
	}



