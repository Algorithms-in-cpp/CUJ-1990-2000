// tcoffee4.cpp

#include "coffee4.h"

main()
{
    CoffeeMachine m;
    while (m.oneAction())
        ;
}
