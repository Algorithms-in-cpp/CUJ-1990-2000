// SwitchBoard Implementation ///////////////////////////////////////////////////
////

#include <stdlib.h>  // to define NULL

#include "SwitchBoard.h"
#include "SubscriberHookup.h"



// class members
SwitchBoard* SwitchBoard::_self = NULL;





// Protected instantiation //////////////////////////////////////////////////////
////
// SwitchBoard
//   the constructor is protected to insure that only one instance of this class
// can exist.  the class is constructed by calling the static instance() method.
SwitchBoard::SwitchBoard()
  : _hookups(NULL)
  , _thookups(0)
{
  // save the handle of the singleton
  _self = this;
}

// -- hookup management -----------------------------------------------------
////
// _subscribe
//   adds the hookup to the array of _hookups.  the array dynamically grows
// to accommodate the new hookup.  note:  the array is always is one
// larger than the _thookups specifies b/c it is NULL terminated.
void SwitchBoard::_subscribe(SubscriberHookup* hookup)
{
  // allocate a new array with enough room for the hookup
  SubscriberHookup** new_list = new SubscriberHookup*[_thookups + 2]; // +2 b/c NULL terminated
 
  // copy the old hookups
  for (int i = 0; i < _thookups; i++)
    new_list[i] = _hookups[i];
 
  // install the new array and add the new item to it
  if (_thookups)
    delete [] _hookups;
  _hookups = new_list;
  _hookups[_thookups] = hookup;
  _hookups[_thookups + 1] = NULL;
  _thookups++;
}

////
// _unsubscribe
//   removes the hookup from the _thookups array preserving the NULL
// terminator.
void SwitchBoard::_unsubscribe(SubscriberHookup* hookup)
{
  if (hookup)
  {
    // create / copy the new array (except the one being removed)
    // NOTE - a NULL terminator is located in _thookups + 1
    SubscriberHookup** new_list = (_thookups > 1) ? new SubscriberHookup*[_thookups]
                                                  : (SubscriberHookup **)NULL;
    if (new_list)
      for (int i = 0, index = 0; i <= _thookups; i++)   // <= catches the NULL terminator
        if (_hookups[i] != hookup)
          new_list[index++] = _hookups[i];
    
    // install the new list
    if (_hookups)
      delete [] _hookups;
    _hookups = new_list;
    _thookups--;
  }
}

// -- message dispatching -------------------------------------------------------
////
// post
//   iterates through the hookups and for each one that has a subscription asks
// the hookup to deliver the message.  true is returned if the message is delivered
// to at least one subscriber. 
bool SwitchBoard::_post(const char* subscription, const char* msg = NULL)
{
  bool delivered = false;
  if (_hookups)
    for (SubscriberHookup** ptr = _hookups; *ptr != NULL; ptr++)
      if ((*ptr)->getSubscription() == subscription)
      {
        (*ptr)->deliver(msg);
        if (!delivered)
          delivered = true;
      }

  return(delivered);
}

// Public methods ///////////////////////////////////////////////////////////////
////
// instance
//   is the access method to the singleton object and is responsible for
// instantiating the SwitchBoard.  instance always returns the reference to the
// instance.
SwitchBoard& SwitchBoard::instance()
{
  if (!_self)
    new SwitchBoard();

  return(*_self);
}
