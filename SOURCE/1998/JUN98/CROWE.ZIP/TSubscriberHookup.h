template<class Subscriber>
class TSubscriberHookup : public SubscriberHookup
{
public:
  typedef void (Subscriber::*DeliveryMethod)();   // prototype

protected:
  Subscriber*    _subscriber; // handle to the object that has
                              // the subscription
  DeliveryMethod _method;     // the subscriber's method to deliver
                              // messages to

  // call the bound method in the subscribing object
  void deliver() {
    (_subscriber->*_method)();
  }

public:
  TSubscriberHookup
    (const char* subscription, Subscriber* subscriber,
      DeliveryMethod method)
    : SubscriberHookup(subscription) {
    _subscriber = subscriber;
    _method = method;
  }
};
