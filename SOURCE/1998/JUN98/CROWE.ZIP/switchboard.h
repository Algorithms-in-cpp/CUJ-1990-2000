// SwitchBoard Class ////////////////////////////////////////////////////////////
////
// to subscribe to the SwitchBoard include the SubscriberHookup header and call
// the newSwitchBoardSubscribtion() template function.  to post a message to all
// the subscribers call SwitchBoard::post() with the subscription name and the
// appropriate message.  to unsubscribe a SubscriberHookup from a subscription
// simple delete the SubscriberHookup returned by the newSwitchBoardSubscription()
// template function.
////

#ifndef _SwitchBoard_h
#define _SwitchBoard_h

// forward declares
class SubscriberHookup;




class SwitchBoard
{
  friend class SubscriberHookup;

private:
  static SwitchBoard* _self;     // handle to the singleton instance
  SubscriberHookup**  _hookups;  // array of subscribing object hookups (NULL terminated)
  int                 _thookups; // total number of subscriber hookups

protected:
  // singleton constructor
  SwitchBoard();

  // api implementation
  void _subscribe(SubscriberHookup* hookup);
  void _unsubscribe(SubscriberHookup* hookup);

  bool _post(const char* subscription, const char* msg = NULL);

public:
  // singleton access
  static SwitchBoard& instance();

  // message dispatching
  static bool post(const char* subscription, const char* msg = NULL) {
    return(instance()._post(subscription, msg));
  }
};



#endif // _SwitchBoard_h
