// SubscriberHookup Class ///////////////////////////////////////////////////////
////
// to subscribe to the SwitchBoard include the SubscriberHookup header and call
// the newSwitchBoardSubscribtion() template function.  the template function
// instantiates a new TSubscriberHookup template class which binds an objects
// method to a subscription.
////

#ifndef _SubscriberHookup_h
#define _SubscriberHookup_h

#include "SwitchBoard.h"

#include <String.h>







// -- SubscriberHookup abstract base class --------------------------------------
////
class SubscriberHookup
{
private:
  String _subscription;       // name of the subscription used in SwitchBoard::call()

public:
  SubscriberHookup(const char* subscription) : _subscription(subscription) {
    SwitchBoard::instance()._subscribe(this);
  }
  ~SubscriberHookup() {
     SwitchBoard::instance()._unsubscribe(this);
  }

  // accessors
  const String& getSubscription() {
    return(_subscription);
  }

  // dispatching (is written by the template subclass)
  virtual void deliver(const char* msg = NULL) = 0;
};



// -- SubscriberHookup template class -------------------------------------------
////
template<class Subscriber>
class TSubscriberHookup : public SubscriberHookup
{
public:
  typedef void (Subscriber::*DeliveryMethod)(const char* msg);   // prototype

protected:
  Subscriber*    _subscriber; // handle to the object that has the subscription
  DeliveryMethod _method;     // the subscriber's method to deliver messages to

  // call the bound method in the subscribing object
  void deliver(const char* msg) {
    (_subscriber->*_method)(msg);
  }

public:
  TSubscriberHookup(const char* subscription, Subscriber* subscriber, DeliveryMethod method)
    : SubscriberHookup(subscription) {
    _subscriber = subscriber;
    _method = method;
  }
};

template<class Subscriber>
class TSimpleSubscriberHookup : public SubscriberHookup
{
public:
  typedef void (Subscriber::*DeliveryMethod)();   // prototype

protected:
  Subscriber*    _subscriber; // handle to the object that has the subscription
  DeliveryMethod _method;     // the subscriber's method to deliver messages to

  // call the bound method in the subscribing object
  void deliver(const char* msg) {
    (_subscriber->*_method)();
  }

public:
  TSimpleSubscriberHookup(const char* subscription, Subscriber* subscriber, DeliveryMethod method)
    : SubscriberHookup(subscription) {
    _subscriber = subscriber;
    _method = method;
  }
};


// -- Instantiation template functor --------------------------------------------
////
template<class Subscriber>
TSubscriberHookup<Subscriber>* newSwitchBoardSubscribtion(
const char* subscription,
Subscriber* subscriber,
void (Subscriber::*method)(const char* msg))
{
  return(new TSubscriberHookup<Subscriber>(subscription, subscriber, method));
}

template<class Subscriber>
TSimpleSubscriberHookup<Subscriber>* newSwitchBoardSubscribtion(
const char* subscription,
Subscriber* subscriber,
void (Subscriber::*method)())
{
  return(new TSimpleSubscriberHookup<Subscriber>(subscription, subscriber, method));
}




#endif // _SubscriberHookup_h
