class PersonnelList
{
private:
  SubscriberHookup* _swsub;

public:
  PersonnelList();
  ~PersonnelList();

  // PersonnelList code here

  // persistent store and SwitchBoard
  // saveYourself message handler
  void store();
};


// -- implementation ------------------------
////
PersonnelList::PersonnelList()
{
  _swsub = newSwitchBoardSubscribtion
    ("saveYourself", this, store);
  // rest of the constructor code here
}

PersonnelList::~PersonnelList()
{
  delete _swsub;
  // rest of destructor code here
}

void PersonnelList::store()
{
  // persistent store
  cerr << "saving..." << endl;
}
