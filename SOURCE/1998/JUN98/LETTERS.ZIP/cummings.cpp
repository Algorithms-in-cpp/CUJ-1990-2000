#include <iostream.h>
     
class mystery{
public:
 mystery::mystery();
 mystery::~mystery();
     
private:
 char * message;
};
     
//Implementation
     
 mystery::mystery()
 {
  message = new char[50];
  message = "Constructor message goes here"; 
  cout << message << endl;
 }
     
 mystery::~mystery()
 {
  message = "Destructor message goes here"; 
  cout << message;
  delete [] message;// Return memory to free store
 }
     
 void f()
 {
  mystery source;
 }
     
int main()
{
 f();
 return 0;
}
   