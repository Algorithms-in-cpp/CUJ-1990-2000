template<class T, ptrdiff_t N>
class Array
    {
public:
    ~Array()
        {
        }
    Array()
        {
        }
    Array(Array const &that)
        {
        for (ptrdiff_t i(0); i < N; ++i)
            array_[i] = that.array_[i];
        }
    Array &operator=(Array const &that)
        {
        if (this != &that)
            for (ptrdiff_t i(0); i < N; ++i)
                array_[i] = that.array_[i];
        return *this;
        }
    T &operator[](ptrdiff_t const i)
        {
        return array_[i];
        }
    T const &operator[](ptrdiff_t const i) const
        {
        return array_[i];
        }
private:
    T array_[N];
    };
