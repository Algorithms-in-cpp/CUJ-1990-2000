/*---------------------------------------------------------------------------
Copyright (c) 1998 by On Target Software. Permission is granted to use this
source code only if this copyright notice and the web address
http://www.targetsoft.com both appear at the beginning of all source files
that contain excerpts or complete copies of the code herein.

Dave Pomerantz, March 1998.  Updates available at http://www.targetsoft.com
-----------------------------------------------------------------------------
 sample_exception.h  Sample classes representing exceptions.
-----------------------------------------------------------------------------
 CBaseException      The base class for application-generated exceptions
 CDatabaseException  Throw this when database access fails
 CDeviceException    Throw this when real-time hardware fails
---------------------------------------------------------------------------*/
#ifndef SAMPLE_EXCEPTION_H
#define SAMPLE_EXCEPTION_H

#define DATABASE_ERROR (-1)

//---------------------------------------------------------------------------
class CBaseException 
{
public:
   // Constructors and destructors
   CBaseException(void)
   {
      m_pDescription = 0;
   }

   CBaseException(const char *pDescription)
   {
      m_pDescription = pDescription;
   }

   CBaseException(const CBaseException &src)
   {
      *this = src;
   }

   virtual ~CBaseException(void) {}

   CBaseException &operator=(const CBaseException &src)
   {
      m_pDescription = src.m_pDescription;
      return *this;
   }

   virtual const char * GetErrorMsg(void)
   {
      return m_pDescription;
   }

protected:
   const char *m_pDescription;
};

//---------------------------------------------------------------------------
class CDatabaseException : public CBaseException
{
public:
   // Constructors and destructors
   CDatabaseException(void) 
      : CBaseException("Database Exception")
   {
   }

   CDatabaseException(const CDatabaseException &src)
   {
      *this = src;
   }

   virtual ~CDatabaseException(void) {}

   CDatabaseException &operator=(const CDatabaseException &src)
   {
      CBaseException::operator=(src);
      return *this;
   }
};

//---------------------------------------------------------------------------
class CDeviceException : public CBaseException
{
public:
   // Constructors and destructors
   CDeviceException(void) 
      : CBaseException("Real-time Device Exception")
   {
   }

   CDeviceException(const CDeviceException &src)
   {
      *this = src;
   }

   virtual ~CDeviceException(void) { printf("CDeviceException terminating\n"); }

   CDeviceException &operator=(const CDeviceException &src)
   {
      CBaseException::operator=(src);
      return *this;
   }
};


#endif //SAMPLE_EXCEPTION_H