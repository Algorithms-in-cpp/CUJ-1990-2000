/*---------------------------------------------------------------------------
         Copyright 1997    On Target Software    All Rights Reserved

 Dave Pomerantz, Nov 1997.  Updates available at http://www.targetsoft.com
-----------------------------------------------------------------------------
samperr.h  Customized error simulation for the sample program

The error simulator DLL has to be initialized with print functions and error 
types that are specific to each application.

This is the specific information for the sample program.
---------------------------------------------------------------------------*/
#ifndef SIMCUST_H
#define SIMCUST_H

#include "simdef.h"  // data definitions used in the function prototypes
#include "simerr.h"  // error simulation functions

// These are the different types of errors that you can test.
// If you change this enum, please change the g_errorInfo
// static table in simcust.cpp.
enum ERROR_TYPE
{  // IMPORTANT: The first two entries must always be 
   //            SIMERR_RESULT_ERROR and SIMERR_MEMORY_ERROR
   SIMERR_RESULT_ERROR,        // failing function returns an error code
   SIMERR_MEMORY_ERROR,        // failed allocation returns zero
   SIMERR_DEVICE_EXCEPTION,    // application-specific exception
   SIMERR_DATABASE_EXCEPTION,  // application-specific exception
   NUM_SIMERR_TYPES
};

#define SIMERR_MSGLEN   256
/****************************************************************************
****** NOTE: YOU SHOULD NOT NEED TO CHANGE ANYTHING BELOW THIS COMMENT ******
****************************************************************************/

//==================== DEFINE IF SIMULATING ERRORS ====================
#ifdef SIMERR 

bool SimErrCustomInit(int nSeed, SIMERR_TEST_TYPE testType); 

//================= DEFINE IF NOT SIMULATING ERRORS ====================
#else

inline bool SimErrCustomInit(int , SIMERR_TEST_TYPE )
{ return true; }

#endif // SIMERR

#endif // SIMCUST_H

