/*---------------------------------------------------------------------------
Copyright (c) 1998 by On Target Software. Permission is granted to use this
source code only if this copyright notice and the web address
http://www.targetsoft.com both appear at the beginning of all source files
that contain excerpts or complete copies of the code herein.

Dave Pomerantz, March 1998.  Updates available at http://www.targetsoft.com
-----------------------------------------------------------------------------
 sample.cpp  Sample C++ program that shows how to test error and
             exception handling.
---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include "simcust.h"
#include "sampxcpt.h"

// Class definition for sample C++ allocation
class CSampleObject
{
public:
   CSampleObject(void) {}
   virtual ~CSampleObject(void) {}
};

// Function prototypes
int  main(int argc, char **argv);
bool AdjustValve(void);
int  UpdateDatabase(void);

/****************************************************************************
Main Program   Perform typical operations like getting real-time data or
               querying a database.  Handle exceptions.  Check for errors.    
****************************************************************************/
int main(int argc, char **argv)
{
   bool           bOK = true;  // continue as long as this is true
   int            nResult;
   CSampleObject *pObject;
   char          *pArray;

   SimErrCustomInit(SIMERR_TIME_SEED, SIMERR_SYSTEMATIC);
 
   // Instantiate object with C++ allocation
   pObject = new CSampleObject;
   pObject = SimErrNew(SIMLINE, pObject, SIMERR_FOREVER, .4);
   if (pObject==0)
   {
      printf("C++ allocation error.\n");
      bOK = false;
   }
   else
   {
      delete pObject;
   }

   // Allocate char array with malloc
   if (bOK)
   {
      pArray = (char *) malloc(100);
      pArray = SimErrMalloc(SIMLINE, pArray);
      if (pArray==0)
      {
         printf("C allocation error.\n");
         bOK = false;
      }
      else
      {
         delete pArray;
      }
   }

   try
   {
      if (bOK)
      {  // Adjust real-time device
         //   note: AdjustValve can throw a CDeviceException
         bOK = AdjustValve();                  
         SimErrException(SIMLINE, SIMERR_DEVICE_EXCEPTION, 4, 0.33);
         bOK = SimErrZero(SIMLINE, bOK, SIMERR_FOREVER, 0.2);            
         if (!bOK)
         {
            printf("The valve stuck.\n");
         }
      }
      if (bOK)
      {  // Update remote-server database
         //   note: UpdateDatabase can throw a CDatabaseException
         nResult = UpdateDatabase();          
         SimErrException(SIMLINE, SIMERR_DATABASE_EXCEPTION); 
         nResult = SimErrResult(SIMLINE, nResult, DATABASE_ERROR);                
         if (nResult == DATABASE_ERROR)        
         {
            printf("Database update failed.\n");
            bOK = false;
         }
      }
   }
   catch(CBaseException &baseException)
   {
      printf("%s\n", baseException.GetErrorMsg());
      bOK = false;
   }
   catch(...)
   {
      printf("Unknown exception.\n");
      bOK = false;
   }

   nResult = (bOK) ? 0 : -1;
   printf("Sample program exiting with return code = %d.\n", nResult);

   SimErrExit(true);
   return nResult;
}

/****************************************************************************
AdjustValve       Return true on success
                  Return false on failure or may throw an exception.
****************************************************************************/
bool AdjustValve(void)
{
   return true;   // those valves almost never fail
}
   
/****************************************************************************
UpdateDatabase    Return zero on success, non-zero on failure
                  Return non-zero on failure or may throw an exception.
****************************************************************************/
int UpdateDatabase(void)
{
   return 0;   // no need for backups
}
   



