int main(int argc, char **argv)
{
   bool           bOK = true;  // keep going if true
   int            nResult;
   CSampleObject *pObject;
   char          *pArray;

   // Instantiate object with C++ allocation
   pObject = new CSampleObject;
   if (pObject==0)
   {
      printf("C++ allocation error.\n");
      bOK = false;
   }
   else
   {
      delete pObject;
   }
   // Allocate char array with malloc
   if (bOK)
   {
      pArray = (char *) malloc(100);
      if (pArray==0)
      {
         printf("C allocation error.\n");
         bOK = false;
      }
      else
      {
         delete pArray;
      }
   }

   try
   {
      if (bOK)
      {  // Adjust real-time device
         //   note: AdjustValve can throw a CDeviceException
         bOK = AdjustValve();                  
         if (!bOK)
         {
            printf("The valve stuck.\n");
         }
      }
      if (bOK)
      {  // Update remote-server database
         //   note: UpdateDatabase can throw a CDatabaseException
         nResult = UpdateDatabase();          
         if (nResult == DATABASE_ERROR)        
         {
            printf("Database update failed.\n");
            bOK = false;
         }
      }
   }
   catch(CDeviceException *pDeviceException)
   {
      printf("Unrecoverable device error.\n");
      delete pDeviceException;
      bOK = false;
   }
   catch(CDatabaseException *pDBException)
   {
      printf("Unrecoverable database error.\n");
      delete pDBException;
      bOK = false;
   }
   catch(...)
   {
      printf("Unknown exception.\n");
      bOK = false;
   }

   nResult = (bOK) ? 0 : -1;
   printf("Sample program exiting with return code = %d.\n", nResult);
   return nResult;
}
