// Custom header file for application-specific error simulation
enum ERROR_TYPE
{  
   SIMERR_RESULT_ERROR,        // failing function returns an error code
   SIMERR_MEMORY_ERROR,        // failed allocation returns zero
   SIMERR_DEVICE_EXCEPTION,    // application-specific exception
   SIMERR_DATABASE_EXCEPTION,  // application-specific exception
   NUM_SIMERR_TYPES
};

#define SIMERR_MSGLEN   256

//==================== DEFINE IF SIMULATING ERRORS ====================
#ifdef SIMERR 

bool SimErrCustomInit(int nSeed, SIMERR_TEST_TYPE testType); 

//================= DEFINE IF NOT SIMULATING ERRORS ====================
#else

inline bool SimErrCustomInit(int , SIMERR_TEST_TYPE )
{ return true; }

#endif // SIMERR
