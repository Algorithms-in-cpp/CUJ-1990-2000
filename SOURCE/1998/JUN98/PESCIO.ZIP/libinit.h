extern "C" DLLEXPORT void
InitStackTraceLibrary() ;

#ifndef DISABLE_EXCEPTION_TRACE
static class StackTraceInitializer
  {
  public :
    StackTraceInitializer()
      { 
      InitStackTraceLibrary() ;
      }
  } stackTraceInitializer ;
#endif
