// StackDump.H

// Author: Dr. Carlo Pescio
// Eptacom Consulting
// Via Bernardo Forte 2-3
// 17100 Savona - ITALY
// Fax +39-19-854761
// email pescio@programmers.net


#ifndef STACKDUMP_


#define STACKDUMP_


class DumpBuffer ;


void StackDump( DumpBuffer& dumpBuffer, DWORD EBP, DWORD EIP = 0 ) ;


#endif // #ifndef STACKDUMP_
