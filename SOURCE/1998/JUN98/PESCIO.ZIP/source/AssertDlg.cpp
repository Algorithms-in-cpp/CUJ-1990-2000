// AssertDlg.CPP

// Author: Dr. Carlo Pescio
// Eptacom Consulting
// Via Bernardo Forte 2-3
// 17100 Savona - ITALY
// Fax +39-19-854761
// email pescio@programmers.net


#include <windows.h>
#include "AssertDlg.h"
#include "resource.h"
#include "Common.h"


AssertDialog :: AssertDialog( const DumpBuffer& buf )
  {
  userChoice = (Choice)DialogBoxParam( dllInstance, MAKEINTRESOURCE( IDD_ASSERTDIALOG ), NULL, (DLGPROC)AssertDlgProc, (LPARAM)&buf ) ;
  }


AssertDialog :: Choice AssertDialog :: userChoice ;


AssertDialog :: Choice AssertDialog :: GetUserChoice()
  {
  return( userChoice ) ;
  }


BOOL CALLBACK AssertDialog :: AssertDlgProc( HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
  {
  switch( uMsg )
    {
    case WM_COMMAND :
      {
      switch( LOWORD( wParam ) )
        {
        case IDC_ABORT :
          EndDialog( hwndDlg, abort ) ;
          return( TRUE ) ;
        case IDC_IGNORE :
          EndDialog( hwndDlg, ignore ) ;
          return( TRUE ) ;
        case IDC_DEBUG :
          EndDialog( hwndDlg, debug ) ;
          return( TRUE ) ;
        default :
          return( FALSE ) ;
        }
      }
    case WM_INITDIALOG :
      {
      CenterWindow( hwndDlg ) ;
      // Change to monospaced font
      SendDlgItemMessage( hwndDlg, IDC_MESSAGE, WM_SETFONT, (WPARAM)GetStockObject( ANSI_FIXED_FONT ), 0 ) ;
      // Set text
      const DumpBuffer* db = (const DumpBuffer*)lParam ;
      db->SetWindowText( GetDlgItem( hwndDlg, IDC_MESSAGE ) ) ;
      return( TRUE ) ;
      }
    default :
      return( FALSE ) ;
    }
  }
