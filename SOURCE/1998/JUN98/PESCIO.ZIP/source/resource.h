#define IDD_ASSERTDIALOG                101
#define IDC_MESSAGE                     1000
#define IDC_ABORT                       1001
#define IDC_IGNORE                      1002
#define IDC_DEBUG                       1003
#define IDD_EXCEPTDIALOG                102
