// ExceptDlg.H

// Author: Dr. Carlo Pescio
// Eptacom Consulting
// Via Bernardo Forte 2-3
// 17100 Savona - ITALY
// Fax +39-19-854761
// email pescio@programmers.net


#ifndef EXCEPT_DIALOG_


#define EXCEPT_DIALOG_


class DumpBuffer ;

class ExceptionDialog
  {
  public :
    enum Choice { abort, debug } ;
    ExceptionDialog( const DumpBuffer& buf ) ;
    Choice GetUserChoice() ;
  private :
    static BOOL CALLBACK ExceptionDlgProc( HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
    static Choice userChoice ;
  } ;


#endif // #ifndef EXCEPT_DIALOG_
