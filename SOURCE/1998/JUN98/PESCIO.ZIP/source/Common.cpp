// Common.CPP

// Author: Dr. Carlo Pescio
// Eptacom Consulting
// Via Bernardo Forte 2-3
// 17100 Savona - ITALY
// Fax +39-19-854761
// email pescio@programmers.net


#include "Common.h"
#include "StackTrace.h"

// Shared between AssertDialog and ExceptionDialog
DumpBuffer dumpBuffer ;

// Necessary to load dialog resource
HINSTANCE dllInstance = 0 ;

// Needed for thread-safe access to DumpBuffer and
// other static stuff in other parts of the code
CRITICAL_SECTION cs ;
CRITICAL_SECTION* stackTraceSync = &cs ;

// implemented in VerbExcept.CPP
LONG __stdcall StackTraceExceptionFilter( LPEXCEPTION_POINTERS e ) ;


BOOL APIENTRY DllMain( HANDLE hModule, DWORD fdwReason, LPVOID lpvReserved )
  {
  if( fdwReason == DLL_PROCESS_ATTACH )
    {
    dllInstance = (HINSTANCE)hModule ;
    InitializeCriticalSection( stackTraceSync ) ;
    }
  else if( fdwReason == DLL_PROCESS_DETACH )
    {
    DeleteCriticalSection( stackTraceSync ) ;
    }
  return( TRUE ) ;
  }


void InitStackTraceLibrary()
  {
  // this can be safely done multiple times
  SetUnhandledExceptionFilter( StackTraceExceptionFilter ) ;
  }


void CenterWindow( HWND hWnd )
  {
  RECT r ;
  GetWindowRect( hWnd, &r ) ;
  int x = ( GetSystemMetrics( SM_CXSCREEN ) - ( r.right - r.left ) ) / 2 ;
  int y = ( GetSystemMetrics( SM_CYSCREEN ) - ( r.bottom - r.top ) ) / 2 ;
  SetWindowPos( hWnd, HWND_TOPMOST, x, y, 0, 0, SWP_NOSIZE ) ;
  SetForegroundWindow( hWnd ) ; // needed for working threads
  }

