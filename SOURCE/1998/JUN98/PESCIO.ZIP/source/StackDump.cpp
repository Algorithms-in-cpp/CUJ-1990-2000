// StackDump.CPP

// Author: Dr. Carlo Pescio
// Eptacom Consulting
// Via Bernardo Forte 2-3
// 17100 Savona - ITALY
// Fax +39-19-854761
// email pescio@programmers.net


#include <windows.h>
#include "PE_Debug.h"


void StackDump( DumpBuffer& dumpBuffer, DWORD EBP, DWORD EIP )
  {
  // The structure of the stack frames is the following:
  // EBP -> parent stack frame EBP
  //        return address for this call ( = caller )
  // The chain can be navigated iteratively; the
  // initial value of EBP is given by the parameter.
  // If EIP != 0, then before we dump the call stack, we
  // dump the same information for EIP. Basically, we
  // consider EIP as the first element of the call stack.
  static PE_Debug PE_debug ;
  BOOL EBP_OK = TRUE ;
  do
    {
    // Check if EBP is a good address
    // I'm expecting a standard stack frame, so
    // EPB must be aligned on a DWORD address
    // and it should be possible to read 8 bytes
    // starting at it (next EBP, caller).
    if( (DWORD)EBP & 3 )
      EBP_OK = FALSE ;
    if( EBP_OK && IsBadReadPtr( (void*)EBP, 8 ) )
      EBP_OK = FALSE ;
    if( EBP_OK )
      {
      BYTE* caller = EIP ? (BYTE*)EIP : *((BYTE**)EBP + 1) ;
      EBP = EIP ? EBP : *(DWORD*)EBP ;
      if( EIP )
        EIP = 0 ; // So it is considered just once
      // Get the instance handle of the module where caller belongs to
      MEMORY_BASIC_INFORMATION mbi ;
      VirtualQuery( caller, &mbi, sizeof( mbi ) ) ;
      // The instance handle is equal to the allocation base in Win32
      HINSTANCE hInstance = (HINSTANCE)mbi.AllocationBase ;
      // If EBP is valid, hInstance is not 0
      if( hInstance == 0 )
        EBP_OK = FALSE ;
      else
        PE_debug.DumpDebugInfo( dumpBuffer, caller, hInstance ) ;
      }
    else
      break ; // End of the call chain
    }
  while( TRUE ) ;
  PE_debug.ClearReport() ;  // Prepare for future calls
  }
