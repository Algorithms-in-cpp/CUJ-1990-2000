// VerbExcept.CPP

// Author: Dr. Carlo Pescio
// Eptacom Consulting
// Via Bernardo Forte 2-3
// 17100 Savona - ITALY
// Fax +39-19-854761
// email pescio@programmers.net


#include <windows.h>
#include <eh.h>
#include <process.h>
#include "Common.h"
#include "ExceptDlg.h"
#include "StackDump.h"
#include "StackTrace.h"


void DumpExceptCallsStack( DumpBuffer& dumpBuffer, DWORD EBP, DWORD EIP )
  {
  const char* separator = "------------------------------------------------------------------\r\n" ;
  dumpBuffer.Printf( "\r\nCall stack:\r\n" ) ;
  dumpBuffer.Printf( separator ) ;
  StackDump( dumpBuffer, EBP, EIP ) ;
  dumpBuffer.Printf( separator ) ;
  }


struct ExceptionCodeDescr
  {
  DWORD code ;
  const char* descr ;
  } ;

#define CODE_DESCR( c ) { c, #c }

static ExceptionCodeDescr exceptionTable[] =
    {   
    CODE_DESCR( EXCEPTION_ACCESS_VIOLATION ),
    CODE_DESCR( EXCEPTION_ARRAY_BOUNDS_EXCEEDED ),
    CODE_DESCR( EXCEPTION_BREAKPOINT ),
    CODE_DESCR( EXCEPTION_DATATYPE_MISALIGNMENT ),
    CODE_DESCR( EXCEPTION_FLT_DENORMAL_OPERAND ),
    CODE_DESCR( EXCEPTION_FLT_DIVIDE_BY_ZERO ),
    CODE_DESCR( EXCEPTION_FLT_INEXACT_RESULT ),
    CODE_DESCR( EXCEPTION_FLT_INVALID_OPERATION ),
    CODE_DESCR( EXCEPTION_FLT_OVERFLOW ),
    CODE_DESCR( EXCEPTION_FLT_STACK_CHECK ),
    CODE_DESCR( EXCEPTION_FLT_UNDERFLOW ),
    CODE_DESCR( EXCEPTION_GUARD_PAGE ),
    CODE_DESCR( EXCEPTION_ILLEGAL_INSTRUCTION ),
    CODE_DESCR( EXCEPTION_IN_PAGE_ERROR ),
    CODE_DESCR( EXCEPTION_INT_DIVIDE_BY_ZERO ),
    CODE_DESCR( EXCEPTION_INT_OVERFLOW ),
    CODE_DESCR( EXCEPTION_INVALID_DISPOSITION ),
    CODE_DESCR( EXCEPTION_NONCONTINUABLE_EXCEPTION ),
    CODE_DESCR( EXCEPTION_PRIV_INSTRUCTION ),
    CODE_DESCR( EXCEPTION_SINGLE_STEP ),
    CODE_DESCR( EXCEPTION_STACK_OVERFLOW )
    // might be extended with compiler-specific knowledge of
    // "C++ Exception" code[s]
    } ;

void DumpExceptionDescr( DumpBuffer& dumpBuffer, DWORD code )
  {
  const char* descr = NULL ;
  int n = sizeof( exceptionTable ) / sizeof( ExceptionCodeDescr ) ;
  for( int i = 0; i < n; i++ )
    if( exceptionTable[ i ].code == code )
      {
      descr = exceptionTable[ i ].descr ;
      break ;
      }
  if( descr )
    dumpBuffer.Printf( "  Description: %s\r\n", descr ) ;
  else
    dumpBuffer.Printf( "  Description unavailable\r\n" ) ;
  }


LONG __stdcall StackTraceExceptionFilter( LPEXCEPTION_POINTERS e )
  {
  EnterCriticalSection( stackTraceSync ) ;
  LONG res = 0 ;
  dumpBuffer.Clear() ;
  DWORD exceptionCode = e->ExceptionRecord->ExceptionCode ;
  dumpBuffer.Printf( "Unhandled Exception\r\n  Code: %x\r\n", exceptionCode ) ;
  DumpExceptionDescr( dumpBuffer, exceptionCode ) ;
  DumpExceptCallsStack( dumpBuffer, e->ContextRecord->Ebp, 
                        e->ContextRecord->Eip ) ;  
  ExceptionDialog dlg( dumpBuffer ) ;
  ExceptionDialog :: Choice choice = dlg.GetUserChoice() ;
  switch( choice )
    {
    case ExceptionDialog :: abort :
      res = EXCEPTION_EXECUTE_HANDLER ;
      break ;
    case ExceptionDialog :: debug :
      res = EXCEPTION_CONTINUE_SEARCH ;
      break ;
    default :
      // Not reached, cannot use assert!
      MessageBeep( 0 ) ;
    }
  LeaveCriticalSection( stackTraceSync ) ;
  return( res ) ;
  }
