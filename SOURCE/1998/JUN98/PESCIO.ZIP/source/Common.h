// Common.H

// Author: Dr. Carlo Pescio
// Eptacom Consulting
// Via Bernardo Forte 2-3
// 17100 Savona - ITALY
// Fax +39-19-854761
// email pescio@programmers.net


#ifndef COMMON_


#define COMMON_


#include <windows.h>
#include "DumpBuffer.h"


extern DumpBuffer dumpBuffer ;
extern HINSTANCE dllInstance ;
extern CRITICAL_SECTION* stackTraceSync ;

void CenterWindow( HWND hWnd ) ;


#endif  // #ifndef COMMON_
