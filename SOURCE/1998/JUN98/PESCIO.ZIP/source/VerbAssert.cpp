// VerbAssert.CPP

// Author: Dr. Carlo Pescio
// Eptacom Consulting
// Via Bernardo Forte 2-3
// 17100 Savona - ITALY
// Fax +39-19-854761
// email pescio@programmers.net


#include <windows.h>
#include "StackTrace.h"
#include "Common.h"
#include "AssertDlg.h"
#include "StackDump.h"


void DumpAssertCallsStack( DumpBuffer& dumpBuffer )
  {
  const char* separator = "------------------------------------------------------------------\r\n" ;
  dumpBuffer.Printf( "Call stack:\r\n" ) ;
  dumpBuffer.Printf( separator ) ;
  DWORD parentEBP ;
  __asm MOV parentEBP, EBP
  // Now parentEBP -> parent stack frame EBP
  // Skip the first EBP as it points to AssertionFailed, 
  // which is uninteresting for the user
  parentEBP = *(DWORD*)parentEBP ;
  StackDump( dumpBuffer, parentEBP ) ;
  dumpBuffer.Printf( separator ) ;
  }


void VerboseAssert( const char* file, LONG line )
  {
  EnterCriticalSection( stackTraceSync ) ;
  dumpBuffer.Clear() ;
  dumpBuffer.Printf( "ASSERTION FAILED\r\n  File: %s\r\n  Line: %ld\r\n\r\n", file, line ) ;
  DumpAssertCallsStack( dumpBuffer ) ;  
  AssertDialog dlg( dumpBuffer ) ;
  AssertDialog :: Choice res = dlg.GetUserChoice() ;
  switch( res )
    {
    case AssertDialog :: abort :
      exit( 1 ) ;
      break ;
    case AssertDialog :: ignore :
      break ;
    case AssertDialog :: debug :
      // DebugBreak would be more portable, but leaves a kernel call on stack
      __asm int 3
      break ;
    default :
      // Not reached, cannot use assert!
      MessageBeep( 0 ) ;
    }
  LeaveCriticalSection( stackTraceSync ) ;
  }
