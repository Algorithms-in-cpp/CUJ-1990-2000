// StackTrace.H

// Author: Dr. Carlo Pescio
// Eptacom Consulting
// Via Bernardo Forte 2-3
// 17100 Savona - ITALY
// Fax +39-19-854761
// email pescio@programmers.net

#ifndef STACKTRACE_

#define STACKTRACE_


#include <windows.h>


#ifdef __BCPLUSPLUS__
  #define DLLEXPORT _export
#else
  #define DLLEXPORT __declspec( dllexport )
#endif


extern "C" DLLEXPORT void InitStackTraceLibrary() ;


#ifndef DISABLE_EXCEPTION_TRACE
// uses a static object to guarantee that
// InitStackTraceLibrary is called at the
// beginning of the program, but after the
// RTL has installed its own filter
static class StackTraceInitializer
  {
  public :
    StackTraceInitializer()
      { 
      InitStackTraceLibrary() ;
      }
  } stackTraceInitializer ;
#endif


extern "C" DLLEXPORT void VerboseAssert( const char* file, LONG line ) ;

#ifdef _DEBUG
  #define VASSERT( c )                     \
    if( !(c) )                             \
      VerboseAssert( __FILE__, __LINE__ )
#else
  #define VASSERT( c ) NULL
#endif


#endif // #ifndef STACKTRACE_
