// cross_reference.h - cross-reference interface
// with tree_node as an incomplete type

namespace cross_reference
    {

    struct tree_node;

    extern tree_node *xr;

    tree_node *
    add_tree(tree_node *t, char const *w, unsigned n);

    void put_tree(tree_node const *t);

    inline
    void add(char const *w, unsigned n);
        {
        xr = add_tree(xr, w, n);
        }

    inline
    void put()
        {
        put_tree(xr);
        }

    }
