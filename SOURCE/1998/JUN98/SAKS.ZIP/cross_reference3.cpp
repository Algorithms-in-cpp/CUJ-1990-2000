// cross_reference.cpp - cross-reference implementation
// which defines list_node in a global unnamed namespace

#include <stdio.h>
#include <string.h>

#include "cross_reference.h"

namespace
    {
    struct list_node
        {
        unsigned number;
        list_node *next;
        };
    }

namespace cross_reference
    {

    struct tree_node
        {
        char *word;
        list_node *first, *last;
        tree_node *left, *right;
        };

    tree_node *xr = NULL;

    tree_node *
    add_tree(tree_node *t, char const *w, unsigned n)
        {
        ...
        }

    void put_tree(tree_node const *t)
        {
        ...
        }

    }
