template<class T> class Array1D {
public:
  Array1D(size_t d1);
  T& operator[](size_t ix);
  ...
private:
  T* data;
};
     
template<class T> class Array2D {
public:
  Array2D(size_t d1, size_t d2);
  Array1D<T>&operator[](size_t ix);
  ...
private:
  Array1D<T>* data;
};
     
template<class T> class Array3D {
public:
  Array3D(size_t d1, size_t d2,
    size_t d3);
  Array2D<T>&operator[](size_t ix);
  ...
private:
  Array2D<T>* data;
};
