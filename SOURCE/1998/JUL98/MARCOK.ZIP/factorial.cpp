template<int N> class Factorial {
public:
  enum {f = N * Factorial<N-1>::f};
};
     
class Factorial<1> {
public:
  enum { f = 1 };
};
     
int main(){
  int f = Factorial<5>::f;
  return 0;
}
