#include <iostream.h>
template<class E> class Expr {
public:
  Expr(const E& e): _e(e) {}
  void operator()(void) const
  { _e();}
private:
  E _e;
};
     
class IntExpr {
public:
  IntExpr(int x):_value(x) {}
  void operator()(void) const
  {
    cout << "IntExpr "
      << _value << endl;
  }
private:
  int _value;
};
     
template <class A, class B> class
ToupleExpr {
public:
  ToupleExpr(const A& a,
    const B& b):_a(a), _b(b) {}
  void operator()(void) const
  {  _a(); _b();}
private:
  A _a;  B _b;
};
     
Expr<ToupleExpr<IntExpr, IntExpr> >
operator<<(const IntExpr& lhs,
  const IntExpr& rhs)
{
  typedef
    ToupleExpr<IntExpr,IntExpr>
    ExT;
  return Expr<ExT>(ExT(lhs, rhs));
}
     
template <class Expr>
void foo(Expr expr){
  expr();
}
     
int main()
{
  foo(IntExpr(10) << 20);
  return 0;
}
