template<class T, int SPACE> class
Array  {
public:
  Array(size_t *pdimensions);
  ~Array();
  Array<T, SPACE-1>&
    operator[](size_t ix);
  ...
private:
  Array<T, SPACE-1>* data;
};
     
template<class T>class Array<T, 1>{
public:
  Array(size_t *pdimensions);
  Array(size_t dim);
  ~Array()
  T& operator[](size_t ix)
 ...
private:
  T* data;
     
}
