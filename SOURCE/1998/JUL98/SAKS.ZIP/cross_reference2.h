namespace cross_reference
    {
     
    struct tree_node;
    typedef tree_node *table;
     
    tree_node *
    add_tree(tree_node *t, char const *w, unsigned n);
     
    void put_tree(tree_node const *t);
     
    inline
    table add(table t, char const *w, unsigned n)
        {
        return add_tree(t, w, n);
        }
     
    inline
    void put(table t)
        {
        put_tree(t);
        }
     
    }
