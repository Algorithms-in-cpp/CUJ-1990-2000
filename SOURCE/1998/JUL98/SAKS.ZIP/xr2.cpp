// xr.cpp - generate a cross-reference of words 
// using a cross-reference table implementation 
// that allows for more than one table
     
#include <ctype.h>
#include <stdio.h>
     
#include "cross_reference2.h"
     
int get_token(char *s, size_t n);
     
#define MAX_TOKEN 256
     
int main()
    {
    char token[MAX_TOKEN];
    unsigned ln = 1;
    cross_reference::table t;
    t = NULL;
    while (get_token(token, MAX_TOKEN) != EOF)
        if (isalpha(token[0]) || token[0] == '_')
            t = cross_reference::add(t, token, ln);
        else if (token[0] == '\n')
            ++ln;
    cross_reference::put(t);
    return 0;
    }
     
int get_token(char *s, size_t n)
    {
    ... same as Listing 2 ...
    }
