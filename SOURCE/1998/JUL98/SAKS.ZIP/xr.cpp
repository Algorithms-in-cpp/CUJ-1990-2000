#include <ctype.h>
#include <stdio.h>
     
#include "cross_reference.h"
     
int get_token(char *s, size_t n);
     
#define MAX_TOKEN 256
     
int main()
    {
    char token[MAX_TOKEN];
    unsigned ln = 1;
    while (get_token(token, MAX_TOKEN) != EOF)
        if (isalpha(token[0]) || token[0] == '_')
            cross_reference::add(token, ln);
        else if (token[0] == '\n')
            ++ln;
    cross_reference::put();
    return 0;
    }
     
int get_token(char *s, size_t n)
    {
    int c;
    while ((c = fgetc(stdin)) != EOF)
        if (isalpha(c) || c == '_' || c == '\n')
            break;
    if (c == EOF)
        {
        *s = '\0';
        return EOF;
        }
    *s++ = c;
    n -= 2;
    if (c != '\n')
        {
        while (isalnum(c = fgetc(stdin)) || c == '_')
            if (n > 0)
                {
                *s++ = c;
                --n;
                }
        ungetc(c, stdin);
        }
    *s = '\0';
    return 1;
    }
