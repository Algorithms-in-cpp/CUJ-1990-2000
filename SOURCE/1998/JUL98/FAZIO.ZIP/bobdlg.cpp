// listing 4

void CBobDlg::OnSendMessage()
{
      CsendSMTP m_MailMsg;

      BOOL IsOK;

      IsOK=m_MailMsg.OpenConnection("ftp.danet.com");  // open a connection to a mail server

      const char *Lines[]={
            "HELO",
            "MAIL FROM: <fazio@danet.com>",
            "RCPT TO: <root@danet.com>",
            "RCPT TO: <fazio@danet.com>",
            "DATA",
            "To: root@danet.com\n\
From: fazio@danet.com\n\
Subject: Just an example message\n\
This is just an example message that I thought would be\n\
good to show what an email message should look like.\n\
.",
            "QUIT",
            NULL
      };

      for(int x=0;Lines[x] != NULL;x++)
      {
            if(!m_MailMsg.SendLine(Lines[x]))
                continue;
      }

      // check for an error
      if(m_MailMsg.GetLastResponse()[0] != '2')
      {
            // have an error
      }
}
