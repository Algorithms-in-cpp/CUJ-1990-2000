// listing 2

#if !defined(AFX_SENDSMTP_H__1BB24553_B9A7_11D1_8A04_FA371DB30444__INCLUDED_)
#define AFX_SENDSMTP_H__1BB24553_B9A7_11D1_8A04_FA371DB30444__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// sendSMTP.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CsendSMTP command target

class CsendSMTP : protected CSocket
{
// Attributes
public:

// Operations
public:
    CsendSMTP();
    virtual ~CsendSMTP();

// Overrides
public:
    BOOL OpenConnection(const char *szMailServerIPAddress);
    const char * GetLastResponse();
    BOOL SendLine(const char *szMessage);
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CsendSMTP)
    public:
    //}}AFX_VIRTUAL

    // Generated message map functions
    //{{AFX_MSG(CsendSMTP)
        // NOTE - the ClassWizard will add and remove member functions here.
    //}}AFX_MSG

// Implementation
protected:
    BOOL ReceiveResponse();
    char szResponse[1024];
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SENDSMTP_H__1BB24553_B9A7_11D1_8A04_FA371DB30444__INCLUDED_)
