// listing 3
// sendSMTP.cpp : implementation file
//

#include "stdafx.h"
#include "bob.h"
#include "sendSMTP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CsendSMTP

CsendSMTP::CsendSMTP()
{
}

CsendSMTP::~CsendSMTP()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CsendSMTP, CSocket)
    //{{AFX_MSG_MAP(CsendSMTP)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif  // 0

/////////////////////////////////////////////////////////////////////////////
// CsendSMTP member functions


BOOL CsendSMTP::SendLine(const char * szMessage)
{
    BOOL Status;
    char *buffer;

    // allocate enough space for the command plus enough to add a \n char
    buffer=new char[strlen(szMessage)+3];

    sprintf(buffer,"%s\n",szMessage);

    // Send the message
    if(Send(buffer,strlen(buffer)) != SOCKET_ERROR)
    {
        // if there wasn't an error get the response;
        Status=ReceiveResponse();
    }
    else
    {
        Status=false;
    }

    return Status;
}

BOOL CsendSMTP::ReceiveResponse()
{
    // I only care about the numeric value
    int numReceived=Receive(szResponse,sizeof(szResponse));
    if(numReceived == sizeof(szResponse))
    {
        // I have more data to get,  I will want to flush the rest,
        // but I don't really need it.
    }
    else
    {
        // null terminate the string.
        szResponse[numReceived]='\0';
    }

    BOOL Status=false;

    switch(szResponse[0])
    {
    case '1':       // not possible, but code for anyways
    case '2':       // positive response
    case '3':       // intermediate response, but go ahead and continue
        Status=true;
        break;
    case '4':
    case '5':
        Status=false;
        break;
    default:
        // if anything other than the above happen, assume a failure
        Status=false;
    }

    return Status;
}

const char * CsendSMTP::GetLastResponse()
{
    return szResponse;
}

BOOL CsendSMTP::OpenConnection(const char * szMailServerIPAddress)
{
    BOOL Status;
    // Create a socket
    Status=Create();

    if(Status)
    {
        // connect to the SMTP Service
        Status=Connect(szMailServerIPAddress,25);

        if(Status){
            // Check response from the SMTP Service
            Status=ReceiveResponse();
        }
    }

    return Status;
}
