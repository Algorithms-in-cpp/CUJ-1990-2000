// clrspace.h

#if !defined(CLRSPACE_H)
#define CLRSPACE_H

#include <math.h> // for sqrt(), atan2(), and M_PI

// Some color spaces in current use including transformations between them.
// Type T is assumed to be a floating point type (float, double, or long
// double). This library can be extended to integer types by writing class
// specializations.

namespace clrspace {

//  color spaces:              Color1<T>
//                                 |
//           -----------------------
//           |          |          |
//         CIE_Y<T>  CIE_L<T>  Color2<T>
//                                 |
//           -----------------------
//           |                     |
//   ChromaticitySpace<T>      Color3<T>
//           |                     |
//     -------------               -------------------------------
//     |           |               |                             |
//   xy<T>     uvPrime<T>          |                         Color4<T>
//                                 |                             |
//                 --------------------------------------    CMYKBase<T>
//                 |         |            |             |
//               Lxx<T>    XYZ<T>  YCbCr<T,GAM,PAIR> RGBBase<T>
//                 |                      |             |
//        --------------------        YCC709<T>   RGBConv<T,CONV>
//        |                  |                          |
//    LxxRect<T>        LxxPolar<T>              -----------------
//        |                  |                   |               |
//   ----------        --------------     RGBLinear<T,CONV>  RGBGamma<T,CONV>
//   |        |        |            |            |               |
// Luv<T>   Lab<T> LuvPolar<T>  LabPolar<T>  RGB709Linear<T>  RGB709<T>
//
//
//	support classes:
//
//   Mat3<T>           XFormPair<T>   GammaCorrect<T>
//      |                  |                |
// ColorXForm<T>           ------------------         GAM==RGBGamma<T,CONV>
//                                 |                 PAIR==XFormPair<T>
//                            ConvertRGB<T>          CONV==ConvertRGB<T>

template <class T>
class Color1 // base class for 1-D color spaces
{
protected:
	T
	_zeta1; // coordinate value

public:
	Color1() {}

	Color1 (T izeta1) : _zeta1(izeta1) {}

	T // generic coordinate name (mostly for internal use)
	zeta1() const {return _zeta1;}
};

template <class T>
class Color2 : public Color1<T> // base class for 2-D color spaces
{
protected:
	T
	_zeta2; // second coordinate

public:
	Color2() {}

	Color2 (T izeta1, T izeta2) : Color1<T>(izeta1), _zeta2(izeta2) {}

	T // generic coordinate name (mostly for internal use)
	zeta2() const {return _zeta2;}
};

template <class T>
class Color3 : public Color2<T> // base class for 3-D color spaces
{
protected:
	T
	_zeta3; // third coordinate

public:
	Color3() {}

	Color3 (T izeta1, T izeta2, T izeta3) :
   	Color2<T>(izeta1,izeta2), _zeta3(izeta3) {}

	T // generic coordinate name (mostly for internal use)
	zeta3() const {return _zeta3;}
};

template <class T>
class Color4 : public Color3<T> // base class for 4-D color spaces
{
protected:
	T
	_zeta4; // fourth coordinate

public:
	Color4() {}

	Color4 (T izeta1, T izeta2, T izeta3, T izeta4) :
   	Color3<T>(izeta1,izeta2,izeta3), _zeta4(izeta4) {}

	T // generic coordinate name (mostly for internal use)
	zeta4() const {return _zeta4;}
};

// by definition, all "colorimetric" color spaces can be transformed to XYZ
template <class T>
class XYZ : public Color3<T> // CIE (X,Y,Z) space
{
public:
	XYZ() {}

	XYZ (T ix, T iy, T iz) : Color3<T>(ix,iy,iz) {}

	T
	X() const {return _zeta1;}

	T
	Y() const {return _zeta2;}

	T
	Z() const {return _zeta3;}
};

// ~~~~~Brightness and Lightness Spaces~~~~~

template <class T>
class CIE_L; // forward reference

// two colors with equal Y values appear equally bright
template <class T>
class CIE_Y : public Color1<T> // same as Y() from XYZ
{
public:
	CIE_Y() {}

	CIE_Y (T iY) : Color1<T>(iY) {}

	CIE_Y (const CIE_L<T> &L, const CIE_Y<T> &Yn); // Yn == white ref.

	T  // read access to CIE Y coordinate
	Y() const {return _zeta1;}
};

// lightness is brightness judged in comparison to a white reference
template <class T>
class CIE_L : public Color1<T> // CIE L* lightness metric
{
public:
	CIE_L() {}

	CIE_L (T iL) : Color1<T>(iL) {} 

	CIE_L (const CIE_Y<T> &Y, const CIE_Y<T> &Yn); // Yn == white ref.

	T // read access to CIE L* coordinate
	L() const {return _zeta1;}
};

template <class T> // needs to be changed if T is an integer type
CIE_Y<T>::CIE_Y (const CIE_L<T> &L, const CIE_Y<T> &Yn) 
{
	T yyn; // Y/Yn
	if (L.L() > 0.206893) 
	{
		yyn = (L.L()+16.0)/116.0;
		yyn = yyn * yyn * yyn;
	} 
	else
		yyn = L.L() / 903.3;
	_zeta1 = yyn * Yn.Y();
}

template <class T> // needs to be changed if T is an integer type
CIE_L<T>::CIE_L (const CIE_Y<T> &Y, const CIE_Y<T> &Yn) 
{
	T yyn = Y.Y()/Yn.Y(); // Y/Yn
	_zeta1 = (yyn > 0.008856) ? 116.0*pow(yyn,1.0/3.0)-16.0 : 903.3*yyn;
}

//~~~~~chromaticity coordinates~~~~~

// a chromaticity space is normalized so that the three coordinates add to 1
template <class T>
class ChromaticitySpace : public Color2<T> // only two coordinates are stored
{
protected:
	T // compute the redundant third coordinate
	zeta3() const;

public:
	ChromaticitySpace() {}

	ChromaticitySpace (T izeta1, T izeta2) : Color2<T>(izeta1,izeta2) {}
};

template <class T>
inline T // needs to be changed if T is an integer type
ChromaticitySpace<T>::zeta3() const
{
	return 1.0 - _zeta1 - _zeta2;
}

template <class T>
class uvPrime; // forward reference

// normalized XYZ space
template <class T>
class xy : public ChromaticitySpace<T> // CIE xyz color space
{
public:
	xy() {}

	xy (T ix, T iy) : ChromaticitySpace<T>(ix,iy) {}

	xy (const uvPrime<T> &); // convert from CIE u'v'w'

	xy (const XYZ<T> &xyz); // convert from CIE XYZ

	XYZ<T> // convert to CIE XYZ
	toXYZ (const CIE_Y<T> &Y) const; // argument means no operator XYZ<T>

	T // read access to x
	x() const {return _zeta1;}

	T // read access to y
	y() const {return _zeta2;}

	T // compute 1-x-y
	z() const {return zeta3();}
};

// more perceptually flat than xy<T>
template <class T>
class uvPrime : public ChromaticitySpace<T> // CIE u'v'w' color space
{
public:
	uvPrime() {}

	uvPrime (T iuPrime, T ivPrime) : 
		ChromaticitySpace<T>(iuPrime,ivPrime) {}

	uvPrime (const xy<T> &); // convert from CIE xyz

	uvPrime (const XYZ<T> &xyz); // convert from CIE XYZ

	XYZ<T> // convert to CIE XYZ
	toXYZ (const CIE_Y<T> &Y) const {return xy<T>(*this).toXYZ(Y);}

	T // read access to uPrime
	uPrime() const {return _zeta1;}

	T // read access to vPrime
	vPrime() const {return _zeta2;}

	T // compute 1-uPrime-vPrime
	wPrime() const {return zeta3();}
};

template <class T> // needs to be changed if T is an integer type
inline
xy<T>::xy (const uvPrime<T> &uv)
{
	T denom = 6*uv.uPrime() - 16*uv.vPrime() + 12;
	if (denom == 0) 
	{
		_zeta1 = 0;
		_zeta2 = 0;
	} 
	else 
	{
		_zeta1 = 9*uv.uPrime()/denom;
		_zeta2 = 4*uv.vPrime()/denom;
	}
}

template <class T> // needs to be changed if T is an integer type
inline
xy<T>::xy (const XYZ<T> &xyz) // convert from CIE XYZ
{
	T total = xyz.X() + xyz.Y() + xyz.Z();
	if (total == 0) 
	{
		_zeta1 = 0;
		_zeta2 = 0;
	} 
	else 
	{
		_zeta1 = xyz.X() / total;
		_zeta2 = xyz.Y() / total;
	}
}

template <class T> // needs to be changed if T is an integer type
inline XYZ<T> // convert to CIE XYZ
xy<T>::toXYZ (const CIE_Y<T> &Y) const
{
	if (y() == 0)
		return XYZ<T>(0,0,0);
	T factor = Y.Y()/y();
	return XYZ<T> (factor*x(), Y.Y(), factor*z());
}

template <class T> // needs to be changed if T is an integer type
inline
uvPrime<T>::uvPrime (const xy<T> &ixy)
{
	T denom = -2*ixy.x()+ 12*ixy.y() + 3;
	if (denom == 0) 
	{
		_zeta1 = 0;
		_zeta2 = 0;
	} 
	else 
	{
		_zeta1 = 4*ixy.x()/denom;
		_zeta2 = 9*ixy.y()/denom;
	}
}

template <class T> // needs to be changed if T is an integer type
inline
uvPrime<T>::uvPrime (const XYZ<T> &xyz)
{
	T denom = xyz.X() + 15*xyz.Y() + 3*xyz.Z();
	if (denom == 0)
	{
		_zeta1 = 0;
		_zeta2 = 0;
	} 
	else 
	{
		_zeta1 = 4*xyz.X() / denom;
		_zeta2 = 9*xyz.Y() / denom;
	}
}

// ~~~~~Illuminant Chromaticities (T must be a floating point type)~~~~~

template <class T>
class SA : public xy<T> 
{
public:
	SA() : xy<T>(0.4476,0.4074) {}
};

template <class T>
class K3250 : public xy<T> 
{
public:
	K3250() : xy<T>(0.4201,0.3976) {}
};

template <class T>
class SB : public xy<T> 
{
public:
	SB() : xy<T>(0.3484,0.3516) {}
};

template <class T>
class SC : public xy<T> 
{
public:
	SC() : xy<T>(0.3101,0.3162) {}
};

template <class T>
class D50 : public xy<T> 
{
public:
	D50() : xy<T>(0.3457,0.3585) {}
};

template <class T>
class D55 : public xy<T> 
{
public:
	D55() : xy<T>(0.3324,0.3474) {}
};

template <class T>
class D65 : public xy<T> 
{
public:
	D65() : xy<T>(0.3127,0.3290) {}
};

template <class T>
class D75 : public xy<T> 
{
public:
	D75() : xy<T>(0.2990,0.3149) {}
};

template <class T>
class SE : public xy<T> 
{
public:
	SE() : xy<T>(0.3333,0.3333) {}
};

template <class T>
class K9300 : public xy<T> 
{
public:
	K9300() : xy<T>(0.2848,0.2932) {}
};

// ~~~~~Lxx family of color spaces~~~~~

// base class for Luv<T>, LuvPolar<T>, Lab<T>, and LabPolar<T>
template <class T>
class Lxx : public Color3<T> 
{
public:
	Lxx() {}

	Lxx (const CIE_L<T> &iL, T ix1, T ix2) :
   	Color3<T>(iL.L(),ix1,ix2) {}

	T // read access to CIE L*
	L() const {return _zeta1;}
};

template <class T>
class LxxPolar; // forward reference

template <class T>
class LxxRect : public Lxx<T> // Luv or Lab coordinates
{
protected:
	double // delta
  	deltaE (const LxxRect<T> &, double) const;

public:
	LxxRect() {}

	LxxRect (const CIE_L<T> &iL, T ix1, T ix2) :
   	Lxx<T>(iL,ix1,ix2) {}

	LxxRect (const LxxPolar<T> &); // polar to rectangular conversion
};

template <class T>
class LxxPolar : public Lxx<T> // LuvPolar or LabPolar coordinates
{
protected:
	T
	rss (T x, T y);

	T
	arctan (T y, T x);

public:
	LxxPolar() {}

	LxxPolar (const CIE_L<T> &iL, T ix1, T ix2) :
   	Lxx<T>(iL,ix1,ix2) {}

	LxxPolar (const LxxRect<T> &); // rectangular to polar conversion
};

template <class T> // needs to be changed if T is an integer type
double
LxxRect<T>::deltaE (const LxxRect<T> &lxx, double k) const
{
	T dL = k * (zeta1() - lxx.zeta1());
	T dx1 = zeta2() - lxx.zeta2();
	T dx2 = zeta3() - lxx.zeta3();
	return sqrt (dL*dL + dx1*dx1 + dx2*dx2);
}

template <class T> // needs to be changed if T is an integer type
inline
LxxRect<T>::LxxRect (const LxxPolar<T> &polar) :
	Lxx<T>
	(
		polar.L(),
		polar.zeta2()*cos(polar.zeta3()), // r*cos(theta)
		polar.zeta2()*sin(polar.zeta3())  // r*sin(theta)
	)
{
}

template <class T> // needs to be changed if T is an integer type
inline T
LxxPolar<T>::rss (T x, T y)
{
	return sqrt(x*x + y*y);
}

template <class T> // needs to be changed if T is an integer type
inline T
LxxPolar<T>::arctan (T y, T x)
{
	if (x == 0 && y == 0)
		return 0;
	T answer = atan2(y,x);
	if (answer < 0)
		answer += 2*M_PI;
	return answer;
}

template <class T> // OK for any type T
inline
LxxPolar<T>::LxxPolar (const LxxRect<T> &rect) :
	Lxx<T>
	(
 		rect.zeta1(),
		rss (rect.zeta2(), rect.zeta3()),   // sqrt(x^2+y^2)
		arctan (rect.zeta3(), rect.zeta2()) // arctan(y/x)
	)
{
}

template <class T>
class LuvPolar; // forward reference

// Luv judges brightness and colorfulness relative to a white reference.
// u() and v() are related to but not equal to coordinates of uvPrime<T>.
template <class T>
class Luv : public LxxRect<T> // (L*,u*,v*) space
{
public:
	Luv() {}

	Luv (const CIE_L<T> &iL, T iu, T iv) : LxxRect<T>(iL,iu,iv) {}

	Luv (const LuvPolar<T> &); // convert polar form

	Luv (const XYZ<T> &XYZcolor, const XYZ<T> &XYZwhite);

	Luv (const XYZ<T> &XYZcolor, const xy<T> xyWhite,
		const CIE_Y<T> &Yn = CIE_Y<T>(100)) :
		LxxRect<T>(Luv<T>(XYZcolor, xyWhite.toXYZ(Yn))) {}

	XYZ<T> // convert to XYZ
	toXYZ (const XYZ<T> &XYZwhite) const;

	double
	deltaEuv (const Luv<T> &luv, double k = 1.0) {return deltaE(luv,k);}

	T // read access to CIE u*
	u() const {return _zeta2;}

	T // read access to CIE v*
	v() const {return _zeta3;}
};

// Polar version of Luv<T>
template <class T>
class LuvPolar : public LxxPolar<T> // (L*, C*(uv), h(uv)) space
{
public:
	LuvPolar() {}

	LuvPolar (const CIE_L<T> &iL, T ic, T ih) : LxxPolar<T>(iL,ic,ih) {}

	LuvPolar (const Luv<T> &); // convert rectangular form

	LuvPolar (const XYZ<T> &XYZcolor, const XYZ<T> &XYZwhite)
	{
		Luv<T> luv(XYZcolor,XYZwhite); // XYZ to rectangular
		*this = LuvPolar<T>(luv);      // rectangular to polar
	}

	LuvPolar (const XYZ<T> &XYZcolor, const xy<T> xyWhite,
		const CIE_Y<T> &Yn = CIE_Y<T>(100)) :
		LxxPolar<T>(LuvPolar<T>(XYZcolor, xyWhite.toXYZ(Yn))) {}

	XYZ<T> // convert to XYZ
	toXYZ (const XYZ<T> &XYZwhite) const
	{
		Luv<T> luv(*this);             // polar to rectangular
		return luv.toXYZ(XYZwhite);   // rectangular to XYZ
	}

	T // read access to CIE C*(uv)
	Cuv() const {return _zeta2;} // length of (u(),v()) vector

	T // read access to CIE h(uv)
	huv() const {return _zeta3;} // angle of (u(),v()) vector
};

template <class T> // OK for any type T
Luv<T>::Luv (const LuvPolar<T> &luvPolar)
{
	LxxRect<T> rect(luvPolar);
	*this = Luv<T>(rect.zeta1(),rect.zeta2(),rect.zeta3());
}

template <class T> // OK for any type T
LuvPolar<T>::LuvPolar (const Luv<T> &luv)
{
	LxxPolar<T> polar(luv);
	*this = LuvPolar<T>(polar.zeta1(),polar.zeta2(),polar.zeta3());
}

template <class T> // needs to be changed if T is an integer type
inline
Luv<T>::Luv (const XYZ<T> &XYZcolor, const XYZ<T> &XYZwhite)
{
	uvPrime<T> uvColor(XYZcolor);
	uvPrime<T> uvWhite(XYZwhite);
	_zeta1 = CIE_L<T>(XYZcolor.Y(),XYZwhite.Y()).L();
	T factor = 13*_zeta1;
	_zeta2 = factor * (uvColor.uPrime() - uvWhite.uPrime());
	_zeta3 = factor * (uvColor.vPrime() - uvWhite.vPrime());
}

template <class T> // needs to be changed if T is an integer type
XYZ<T> // convert to XYZ
Luv<T>::toXYZ (const XYZ<T> &XYZwhite) const
{
	uvPrime<T> uvWhite = uvPrime<T>(XYZwhite);
	T denom = 13*L();
	uvPrime<T> uvColor 
		(
			uvWhite.uPrime()+u()/denom, 
			uvWhite.vPrime()+v()/denom
		);
	return uvColor.toXYZ( CIE_Y<T> (L(), XYZwhite.Y()) );
}

template <class T>
class LabPolar; // forward reference

// Lab judges brightness and colorfulness relative to a white reference.
template <class T>
class Lab : public LxxRect<T> // (L*,a*,b*) space
{
protected:
	T
	f(T t) const; // cube root with linear section

	T
	t(T f) const; // inverse of f

public:
	Lab() {}

	Lab (const CIE_L<T> &iL, T ia, T ib) : LxxRect<T>(iL,ia,ib) {}

	Lab (const LabPolar<T> &);

	Lab (const XYZ<T> &XYZcolor, const XYZ<T> &XYZwhite);

	Lab (const XYZ<T> &XYZcolor, const xy<T> xyWhite,
		const CIE_Y<T> &Yn = CIE_Y<T>(100)) :
		LxxRect<T>(Lab<T>(XYZcolor, xyWhite.toXYZ(Yn))) {}

	XYZ<T>
	toXYZ (const XYZ<T> &XYZwhite) const; 

	double
	deltaEab (const Lab<T> &lab, double k = 1.0) {return deltaE(lab,k);}

	T  // read access to CIE a*
	a() const {return _zeta2;} // +ve for reddish, -ve for greenish

	T  // read access to CIE b*
	b() const {return _zeta3;} // +ve for yellowish, -ve for bluish
};

// Polar version of Lab
template <class T>
class LabPolar : public LxxPolar<T> // (L*,C*(ab),h(ab)) space
{
public:
	LabPolar() {}

 	LabPolar (const CIE_L<T> &iL, T iCab, T ihab) :
   	LxxPolar<T>(iL,iCab,ihab) {}

	LabPolar (const Lab<T> &);

	LabPolar (const XYZ<T> &XYZcolor, const XYZ<T> &XYZwhite)
	{
		Lab<T> lab(XYZcolor,XYZwhite); // XYZ to rectangular
		*this = LabPolar<T>(lab); // rectangular to polar
	}

	LabPolar (const XYZ<T> &XYZcolor, const xy<T> xyWhite,
		const CIE_Y<T> &Yn = CIE_Y<T>(100)) :
		LxxPolar<T>(LabPolar<T>(XYZcolor, xyWhite.toXYZ(Yn))) {}

	XYZ<T>
	toXYZ (const XYZ<T> &XYZwhite) const
	{
		Lab<T> lab(*this); // polar to rectangular
		return lab.toXYZ(XYZwhite); // rectangular to XYZ
	}

	T // read access to CIE C*(ab)
	Cab() const {return _zeta2;} // length of (a(),b()) vector

	T // read access to CIE h(ab)
	hab() const {return _zeta3;} // angle of (a(),b()) vector
};

template <class T> // needs to be changed if T is an integer type
inline T
Lab<T>::f(T t) const // cube root with linear section
{
	return (t > 0.008856) ? pow(t,1.0/3.0) : 7.787*t + 16.0/116.0;
}

template <class T> // needs to be changed if T is an integer type
inline T
Lab<T>::t(T f) const // inverse of f
{
	return (f > 0.206893) ? f*f*f : (f - 16.0/116.0) / 7.787;
}

template <class T> // OK for any type T
Lab<T>::Lab (const LabPolar<T> &labPolar)
{
	LxxRect<T> rect(labPolar);
	*this = Lab<T>(rect.zeta1(),rect.zeta2(),rect.zeta3());
}

template <class T> // OK for any type T
LabPolar<T>::LabPolar (const Lab<T> &lab)
{
	LxxPolar<T> polar(lab);
	*this = LabPolar<T>(polar.zeta1(),polar.zeta2(),polar.zeta3());
}

template <class T> // needs to be changed if T is an integer type
inline
Lab<T>::Lab (const XYZ<T> &XYZcolor, const XYZ<T> &XYZwhite)
{
	T xxn = XYZcolor.X() / XYZwhite.X(); // normalized X
	T yyn = XYZcolor.Y() / XYZwhite.Y(); // normalized Y
	T zzn = XYZcolor.Z() / XYZwhite.Z(); // normalized Z
	T fyyn = f(yyn); // precomputed for efficiency

	_zeta1 = CIE_L<T>(XYZcolor.Y(),XYZwhite.Y()).L(); // L*
	_zeta2 = 500.0 * (f(xxn) - fyyn); // a*
	_zeta3 = 200.0 * (fyyn - f(zzn)); // b*
}

template <class T> // needs to be changed if T is an integer type
XYZ<T> // convert to XYZ
Lab<T>::toXYZ (const XYZ<T> &XYZwhite) const
{
	T Yn = XYZwhite.Y();
	T Y = CIE_Y<T>(L(),Yn).Y();
	T fyyn = f(Y/Yn);
	T X = XYZwhite.X() * t(fyyn + a()/500.0);
	T Z = XYZwhite.Z() * t(fyyn - b()/200.0);
	return XYZ<T>(X,Y,Z);
}

// ~~~~~RGB family of color spaces~~~~~

// note: I would have called this RGB except that Windows defines
// RGB as a macro, thus defeating my namespace approach.
template <class T>
class RGBBase : public Color3<T> // uncalibrated (R,G,B) space
{
public:
	RGBBase() {}

	RGBBase (T ir, T ig, T ib) : Color3<T>(ir,ig,ib) {}

	T
	R() const {return _zeta1;} // red component

	T
	G() const {return _zeta2;} // green component

	T
	B() const {return _zeta3;} // blue component
};

// RGBBase<T> and YCbCr<T> color spaces require 3x3 matrix transforms.
// Mat3<T> is a fast but limited way to compute the inverse of a 3x3 matrix.
// T must be a floating point or complex type.
template <class T>
class Mat3 // some simple 3x3 matrix algebra
{
protected:
	// matrix elements
	T _a11, _a12, _a13;
	T _a21, _a22, _a23;
	T _a31, _a32, _a33;

public:
	Mat3() {}

	Mat3
	(
		T ia11, T ia12, T ia13,
		T ia21, T ia22, T ia23,
		T ia31, T ia32, T ia33
	) :
		_a11(ia11), _a12(ia12), _a13(ia13),
		_a21(ia21), _a22(ia22), _a23(ia23),
		_a31(ia31), _a32(ia32), _a33(ia33)
	{}

	T a11() const {return _a11;}

	T a12() const {return _a12;}

	T a13() const {return _a13;}

	T a21() const {return _a21;}

	T a22() const {return _a22;}

	T a23() const {return _a23;}

	T a31() const {return _a31;}

	T a32() const {return _a32;}

	T a33() const {return _a33;}

	T
	det() const // return the determinate of this matrix
	{
		return _a11*_a22*_a33 + _a12*_a23*_a31 + _a13*_a21*_a32
			- (_a13*_a22*_a31 + _a12*_a21*_a33 + _a11*_a23*_a32);
	}

	Mat3<T>
	adj() const; // return the adjoint of this matrix

	void // invert this matrix
	invert();
};

template <class T> // may require modification with integer types
inline Mat3<T>
Mat3<T>::adj() const // return the adjoint of this matrix
{
	return Mat3<T>
       (
               _a22*_a33-_a23*_a32, _a13*_a32-_a12*_a33, _a12*_a23-_a13*_a22,
               _a23*_a31-_a21*_a33, _a11*_a33-_a13*_a31, _a13*_a21-_a11*_a23,
               _a21*_a32-_a22*_a31, _a12*_a31-_a11*_a32, _a11*_a22-_a12*_a21
       );
}

template <class T> // needs to be changed if T is an integer type
void
Mat3<T>::invert()
{
	T d = det();
	Mat3<T> M = adj();
	_a11 = M.a11()/d; _a12 = M.a12()/d; _a13 = M.a13()/d;
	_a21 = M.a21()/d; _a22 = M.a22()/d; _a23 = M.a23()/d;
	_a31 = M.a31()/d; _a32 = M.a32()/d; _a33 = M.a33()/d;
}

// A ColorXForm<T> is a Mat3<T> that knows how to multiply by a Color3<T>.
template <class T>
class ColorXForm : public Mat3<T> 
{
public:
	ColorXForm() {}

	ColorXForm
	(
		T ia11, T ia12, T ia13,
		T ia21, T ia22, T ia23,
		T ia31, T ia32, T ia33
	) :
		Mat3<T>
               (
			ia11, ia12, ia13,
			ia21, ia22, ia23,
			ia31, ia32, ia33
               ) 
	{}

	Color3<T> // multiply the input color by the transform matrix
	operator* (const Color3<T> &c) const
	{
		return Color3<T>
		(
			_a11*c.zeta1() + _a12*c.zeta2() + _a13*c.zeta3(),
			_a21*c.zeta1() + _a22*c.zeta2() + _a23*c.zeta3(),
			_a31*c.zeta1() + _a32*c.zeta2() + _a33*c.zeta3()
		);
	}
};

// a XFormPair supports a 3x3 transform and its inverse transform
template <class T>
class XFormPair // here we derive using "has a" rather than "is a"
{
protected:
	ColorXForm<T>
	_to; // a transform matrix

	ColorXForm<T>
	_from; // the inverse of _to

public:
	XFormPair() {}

	XFormPair (const ColorXForm<T> &ito) : _to(ito), _from(ito)
	{
		_from.invert();
	}

	const ColorXForm<T> & // read access to transform matrix
	to() const {return _to;}

	const ColorXForm<T> & // read access to inverse transform matrix
	from() const {return _from;}
};

// GammaCorrect defines how to apply and remove a gamma correction
template <class T>
class GammaCorrect 
{
protected:
	T
	_gamma; // coefficient for power law

	T
	_epsilon; // function is linear between 0 and _epsilon

	T
	_beta; // multiplicative coefficient in power law

	T
	_slope; // slope of linear section

public:
	GammaCorrect() {}

	GammaCorrect (T igamma, T iepsilon);

	T
	gamma() const {return _gamma;}

	T
	epsilon() const {return _epsilon;}

	T
	beta() const {return _beta;}

	T
	slope() const {return _slope;}

	T
	apply (T RGorB) const // apply gamma transformation to coordinate
	{
		return (RGorB <= _epsilon) ?
			_slope * RGorB : 
			1.0 - _beta *(1.0 - pow(RGorB, 1.0/_gamma)); 
	}

	T
	remove (T RGorB) const // remove gamma transformation from coordinate
	{
		return (RGorB <= _slope*_epsilon) ?
			RGorB / _slope : 
			pow ((RGorB+_beta-1.0)/_beta, _gamma); 
	}
};

template <class T> // needs to be changed if T is an integer type
GammaCorrect<T>::GammaCorrect (T igamma, T iepsilon)
{
	_gamma = igamma;
	T rgamma = 1.0/_gamma;
	_epsilon = iepsilon;
	T temp = pow(_epsilon,rgamma);
	_beta = 1 / (1 - temp*(1-rgamma));
	_slope = _beta*rgamma*temp/_epsilon;
}

// A ConvertRGB<T> is a XFormPair<T> and a GammaCorrect<T>
template <class T>
class ConvertRGB : public XFormPair<T>, public GammaCorrect<T> 
{
public:
	ConvertRGB (const xy<T> &rc, const xy<T> &gc, const xy<T> &bc,
		const xy<T> &wc, T igamma, T iepsilon);

	ConvertRGB (const ColorXForm<T> &itoXYZ, T igamma, T iepsilon) :
		XFormPair<T>(itoXYZ), GammaCorrect<T>(igamma,iepsilon) {}

	XYZ<T> // convert from RGBLinear to XYZ
	toXYZ (const RGBBase<T> &linear) const
	{
		Color3<T> c = to()*linear; // apply matrix to input vector
		return XYZ<T>(c.zeta1(),c.zeta2(),c.zeta3());
	}

	RGBBase<T> // convert from XYZ to RGBLinear
	fromXYZ (const XYZ<T> &xyz) const
	{
		Color3<T> c = from()*xyz; // apply inverse matrix to input
		return RGBBase<T>(c.zeta1(),c.zeta2(),c.zeta3());
	}

	RGBBase<T> // convert from RGBLinear to RGBGamma
	toGamma (const RGBBase<T> &gamma) const
	{
		return RGBBase<T> 
			(
				apply(gamma.R()), 
				apply(gamma.G()), 
				apply(gamma.B())
			);
	}

	RGBBase<T> // convert from RGBGamma to RGBLinear
	fromGamma (const RGBBase<T> &gamma) const
	{
		return RGBBase<T> 
			(
				remove(gamma.R()), 
				remove(gamma.G()), 
				remove(gamma.B())
			);
	}
};

template <class T> // needs to be changed if T is an integer type
ConvertRGB<T>::ConvertRGB (const xy<T> &rc, const xy<T> &gc,
	const xy<T> &bc, const xy<T> &wc, T igamma, T iepsilon)
{
	// compute XYZ transform matrix from primary chromaticities
	ColorXForm<T> B
	(
		rc.x(), gc.x(), bc.x(),
		rc.y(), gc.y(), bc.y(),
		rc.z(), gc.z(), bc.z()
	);
	Color3<T> W (100*wc.x()/wc.y(), 100, 100*wc.z()/wc.y());
	ColorXForm<T> Binv = B;
	Binv.invert();
	Color3<T> V = Binv * W;
	ColorXForm<T> xform
	(
		V.zeta1()*B.a11(), V.zeta2()*B.a12(), V.zeta3()*B.a13(),
		V.zeta1()*B.a21(), V.zeta2()*B.a22(), V.zeta3()*B.a23(),
		V.zeta1()*B.a31(), V.zeta2()*B.a32(), V.zeta3()*B.a33()
	);
	*this = ConvertRGB<T>(xform,igamma,iepsilon);
}

// An RGBConv<T,CONV> is an RGBBase<T> having a static CONV
template <class T, class CONV> // CONV derived from ConvertRGB<T>
class RGBConv : public RGBBase<T> // base class for RGBLinear and RGBGamma
{
protected:
	static const CONV // XYZ and Gamma conversions
	_conv;

public:
	RGBConv() {}

	RGBConv (T ir, T ig, T ib) : RGBBase<T>(ir,ig,ib) {}

	RGBConv (const RGBBase<T> &rgb) : RGBBase<T>(rgb) {}
};

template <class T, class CONV>
const CONV
RGBConv<T,CONV>::_conv;

template <class T, class CONV>
class RGBGamma; // forward reference

// RGBLinear<T,CONV> is a base class for a linear-light RGBBase space
template <class T, class CONV>
class RGBLinear : public RGBConv<T,CONV> 
{
protected:
	RGBLinear (const RGBBase<T> &rgb) : // for internal use only
   	RGBConv<T,CONV>(rgb.R(),rgb.G(),rgb.B()) {}

public:
	RGBLinear() {}

	RGBLinear (T ir, T ig, T ib) : RGBConv<T,CONV>(ir,ig,ib) {}

	RGBLinear (const RGBGamma<T,CONV> &rgbgam) :
		RGBConv<T,CONV>(_conv.fromGamma(rgbgam)) {}

	RGBLinear (const XYZ<T> &xyz) :
		RGBConv<T,CONV>(_conv.fromXYZ(xyz)) {}

	XYZ<T> // explicit conversion to XYZ
	toXYZ() const {return _conv.toXYZ(*this);}

	operator // implicit converstion to XYZ
	XYZ<T> () const {return toXYZ();}
};

// RGBLinear<T,CONV> is a base class for a gamma-corrected RGBBase space
template <class T, class CONV>
class RGBGamma : public RGBConv<T,CONV> // gamma corrected (R,G,B) space
{
protected:
	RGBGamma (const RGBBase<T> &rgb) :
   	RGBConv<T,CONV>(rgb.R(),rgb.G(),rgb.B()) {}

public:
	RGBGamma() {}

	RGBGamma (T ir, T ig, T ib) : RGBConv<T,CONV>(ir,ig,ib) {}

	RGBGamma (const RGBLinear<T,CONV> &rgblin) :
		RGBConv<T,CONV>(_conv.toGamma(rgblin)) {}

	RGBGamma (const XYZ<T> &xyz) :
		RGBConv<T,CONV>(_conv.toGamma(_conv.fromXYZ(xyz))) {}

	XYZ<T> // explicit conversion to XYZ
	toXYZ() const {return _conv.toXYZ(_conv.fromGamma(*this));}

	operator // implicit conversion to XYZ
	XYZ<T> () const {return toXYZ();}
};

//~~~~~RGB709<T>: an example use of RGBLinear<T> and RGBGamma<T>~~~~~

// step 1: derive a conversion class with a default constructor
template <class T> // needs to be changed if T is an integer type
class Convert_RGB709 : public ConvertRGB<T> 
{
public:
	// RGB709 is from a proposed HDTV standard (ITU.BT-709)
	Convert_RGB709() : ConvertRGB<T>
	(
		xy<T>(0.64,0.33), // red chromaticity
		xy<T>(0.30,0.60), // green chromaticity
		xy<T>(0.15,0.06), // blue chromaticity
		D65<T>(),         // white point chromaticity
		1.0/0.45,         // gamma
		0.018             // epsilon
	) {}
};

template <class T>
class RGB709; // forward reference

// step 2: derive a new linear-light RGBBase space
// using the converter from step 1
template <class T>
class RGB709Linear : public RGBLinear<T,Convert_RGB709<T> > 
{
public:
	RGB709Linear() {}

	RGB709Linear (T ir, T ig, T ib) :
		RGBLinear<T,Convert_RGB709<T> >(ir,ig,ib) {}

	RGB709Linear (const RGB709<T> &gamma) :
		RGBLinear<T,Convert_RGB709<T> >(gamma) {}

	RGB709Linear (const XYZ<T> &xyz) :
		RGBLinear<T,Convert_RGB709<T> >(xyz) {}
};

// step 3: derive an associated gamma-corrected RGBBase space
template <class T>
class RGB709 : public RGBGamma<T,Convert_RGB709<T> > 
{
public:
	RGB709() {}

	RGB709 (T ir, T ig, T ib) :
		RGBGamma<T,Convert_RGB709<T> >(ir,ig,ib) {}

	RGB709 (const RGB709Linear<T> &linear) :
		RGBGamma<T,Convert_RGB709<T> >(linear) {}

	RGB709 (const XYZ<T> &xyz) :
		RGBGamma<T,Convert_RGB709<T> >(xyz) {}
};

// ~~~~~YCbCr space~~~~~

// a YCbCr<T,GAM,PAIR> is a 3x3 matrix transform of a gamma-corrected RGBBase.
// GAM is the associated RGBGamma<T> and PAIR defines the 3x3 matrices.
template <class T, class GAM, class PAIR>
class YCbCr : public Color3<T> 
{
protected:
	static PAIR // derived from XFormPair<T>
	_xformPair; // to() = matrix transform to YCbCr from GAM

public:
	YCbCr() {}

	YCbCr (T iYPrime, T iCb, T iCr) : Color3<T>(iYPrime,iCb,iCr) {}

	YCbCr (const GAM &rgb) : Color3<T>(_xformPair.to()*rgb) {}

	YCbCr (const XYZ<T> &xyz) :
   	Color3<T>(YCbCr<T,GAM,PAIR>(GAM(xyz))) {}

	XYZ<T>
	toXYZ() const {return toRGB().toXYZ();}

	operator
	XYZ<T> () const {return toXYZ();}

	GAM
	toRGB() const
	{
		Color3<T> c = _xformPair.from()*(*this);
		return GAM(c.zeta1(),c.zeta2(),c.zeta3());
	}

	operator
	GAM () const {return toRGB();}

	T
	YPrime() const {return _zeta1;}

	T
	Cb() const {return _zeta2;}

	T
	Cr() const {return _zeta3;}
};

// declaration of the static variable contained in YCbCr<T,GAM,PAIR>
template <class T, class GAM, class PAIR>
PAIR
YCbCr<T,GAM,PAIR>::_xformPair;

// ~~~~~YCC709<T>: an example use of YCbCr<T,GAM,PAIR>~~~~~

// step 1: derive a transform pair class with a default constructor
template <class T>
class YCC709Pair : public XFormPair<T> 
{
public:
	// YCC709 is from a proposed HDTV standard (ITU.BT-709)
	YCC709Pair() :
		XFormPair<T>
		(
   			ColorXForm<T> // transfrom from RGB709 to YCC709
			(
				 0.2215,  0.7154,  0.0721,
				-0.1145, -0.3855,  0.5000,
			 	 0.5016, -0.4556, -0.0459
			)
		) {}
};

// step 2: define your YCbCr<T> using an RGBGamma<T> and the results of step 1
template <class T> // ITU.BT-709 Y'CbCr
class YCC709 : public YCbCr<T,RGB709<T>,YCC709Pair<T> > 
{
public:
	YCC709() {}

	YCC709 (T iYPrime, T iCb, T iCr) :
		YCbCr<T,RGB709<T>,YCC709Pair<T> >(iYPrime,iCb,iCr) {}

	YCC709 (const RGB709<T> &rgb) :
		YCbCr<T,RGB709<T>,YCC709Pair<T> >(rgb) {}

	YCC709 (const XYZ<T> &xyz) :
		YCbCr<T,RGB709<T>,YCC709Pair<T> >(xyz) {}

	XYZ<T>
	toXYZ() const {return toRGB().toXYZ();}
};

// ~~~~~CMYKBase space~~~~~

// uncalibrated Cyan, Magenta, Yellow, blacK
// I originally called this CMYK but that conflicted with
// Windows' definition of CMYK using a macro -- ugh.
template <class T>
class CMYKBase : public Color4<T>
{
public:
	CMYKBase() {}

	CMYKBase (T iC, T iM, T iY, T iK) : Color4<T>(iC,iM,iY,iK) {}

	T
	C() const {return _zeta1;}

	T
	M() const {return _zeta2;}

	T
	Y() const {return _zeta3;}

	T
	K() const {return _zeta4;}
};

// ~~~~~Function Objects (for use with standard library algorithms)~~~~~

// Note: these function objects facilitate a color space transformations by
// providing the white point. If you don't see the conversion you want below, 
// your conversion presumably doesn't need a white point.
//
//                 BaseFunctionObject
//                         |
//        -----------------------------------
//        |                |                |
//      ToXYZ           FromXYZ          Y_to_L
//        |                |             L_to_Y
//   xy_to_XYZ         XYZ_to_Luv
// uvPrime_to_XYZ    XYZ_to_LuvPolar
//   Luv_to_XYZ        XYZ_to_Lab
// LuvPolar_to_XYZ   XYZ_to_LabPolar
//   Lab_to_XYZ
// LabPolar_to_XYZ

template <class WHITE>
class BaseFunctionObject // base class for ToXYZ and FromXYZ
{
protected:
	WHITE
        _white; // white point (generally CIE_Y<T> or XYZ<T>)

public:
	BaseFunctionObject (const WHITE &iwhite) : _white(iwhite) {}
};

// converts FROM to XYZ<T> using WHITE
template <class FROM, class WHITE, class T>
class ToXYZ : public BaseFunctionObject<WHITE>
{
public:
	ToXYZ (const WHITE &iwhite) : BaseFunctionObject<WHITE>(iwhite) {}

	XYZ<T>
	operator () (const FROM &from)
	{
		return from.toXYZ(_white);
	}
};

// converts XYZ<T> to TO using WHITE
template <class TO, class WHITE, class T>
class FromXYZ : public BaseFunctionObject<WHITE>
{
public:
	FromXYZ (const WHITE &iwhite) : BaseFunctionObject<WHITE>(iwhite) {}

	TO
	operator () (const XYZ<T> &xyz)
	{
		return TO(xyz,_white);
	}
};

// ~~~~~WHITE == CIE_Y<T>~~~~~

// converts CIE_Y<T> to CIE_L<T>
template <class T>
class Y_to_L : public BaseFunctionObject<CIE_Y<T> >
{
public:
	Y_to_L (const CIE_Y<T> &iwhite) :
		BaseFunctionObject<CIE_Y<T> >(iwhite) {}

	CIE_L<T>
	operator () (const CIE_Y<T> &y)
	{
		return CIE_L<T>(y,_white);
	}
};

// converts CIE_L<T> to CIE_Y<T>
template <class T>
class L_to_Y : public BaseFunctionObject<CIE_Y<T> >
{
public:
	L_to_Y (const CIE_Y<T> &iwhite) :
		BaseFunctionObject<CIE_Y<T> >(iwhite) {}

	CIE_Y<T>
	operator () (const CIE_L<T> &LStar)
	{
		return CIE_Y<T>(LStar,_white);
	}
};

// converts xy<T> to XYZ<T>
template <class T>
class xy_to_XYZ : public ToXYZ<xy<T>,CIE_Y<T>,T>
{
public:
	xy_to_XYZ (const CIE_Y<T> &iwhite) :
		ToXYZ<xy<T>,CIE_Y<T>,T>(iwhite) {}
};

// converts uvPrime<T> to XYZ<T>
template <class T>
class uvPrime_to_XYZ : public ToXYZ<uvPrime<T>,CIE_Y<T>,T>
{
public:
	uvPrime_to_XYZ (const CIE_Y<T> &iwhite) :
        	ToXYZ<uvPrime<T>,CIE_Y<T>,T>(iwhite) {}
};

// ~~~~~WHITE == XYZ<T>~~~~~

// converts Luv<T> to XYZ<T>
template <class T>
class Luv_to_XYZ : public ToXYZ<Luv<T>,XYZ<T>,T>
{
public:
	Luv_to_XYZ (const XYZ<T> &iwhite) :
        	ToXYZ<Luv<T>,XYZ<T>,T>(iwhite) {}
};

// converts XYZ<T> to Luv<T>
template <class T>
class XYZ_to_Luv : public FromXYZ<Luv<T>,XYZ<T>,T>
{
public:
	XYZ_to_Luv (const XYZ<T> &iwhite) :
        	FromXYZ<Luv<T>,XYZ<T>,T>(iwhite) {}
};

// converts LuvPolar<T> to XYZ<T>
template <class T>
class LuvPolar_to_XYZ : public ToXYZ<LuvPolar<T>,XYZ<T>,T>
{
public:
	LuvPolar_to_XYZ (const XYZ<T> &iwhite) :
        	ToXYZ<LuvPolar<T>,XYZ<T>,T>(iwhite) {}
};

// converts XYZ<T> to LuvPolar<T>
template <class T>
class XYZ_to_LuvPolar : public FromXYZ<LuvPolar<T>,XYZ<T>,T>
{
public:
	XYZ_to_LuvPolar (const XYZ<T> &iwhite) :
        	FromXYZ<LuvPolar<T>,XYZ<T>,T>(iwhite) {}
};

// converts Lab<T> to XYZ<T>
template <class T>
class Lab_to_XYZ : public ToXYZ<Lab<T>,XYZ<T>,T>
{
public:
	Lab_to_XYZ (const XYZ<T> &iwhite) :
        	ToXYZ<Lab<T>,XYZ<T>,T>(iwhite) {}
};

// converts XYZ<T> to Lab<T>
template <class T>
class XYZ_to_Lab : public FromXYZ<Lab<T>,XYZ<T>,T>
{
public:
	XYZ_to_Lab (const XYZ<T> &iwhite) :
        	FromXYZ<Lab<T>,XYZ<T>,T>(iwhite) {}
};

// converts LabPolar<T> to XYZ<T>
template <class T>
class LabPolar_to_XYZ : public ToXYZ<LabPolar<T>,XYZ<T>,T>
{
public:
	LabPolar_to_XYZ (const XYZ<T> &iwhite) :
        	ToXYZ<LabPolar<T>,XYZ<T>,T>(iwhite) {}
};

// converts XYZ<T> to LabPolar<T>
template <class T>
class XYZ_to_LabPolar : public FromXYZ<LabPolar<T>,XYZ<T>,T>
{
public:
	XYZ_to_LabPolar (const XYZ<T> &iwhite) :
        	FromXYZ<LabPolar<T>,XYZ<T>,T>(iwhite) {}
};

} // end namespace clrspace

#endif

