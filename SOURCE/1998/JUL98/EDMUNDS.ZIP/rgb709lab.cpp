#include <iostream.h>
#include "clrspace.h"

void Gamut() // display sRGB gamut in terms of Lab
{
	using namespace clrspace;

       // precompute white XYZ (D65 with Y = 100)
       XYZ<float> XnYnZn = D65<float>().toXYZ(100);

       // sample sRGB space and convert to Lab
       for (int i = 0; i < 6; i++)
		for (int j = 0; j < 6; j++)
			for (int k = 0; k < 6; k++)
			{
				sRGB<float> rgb (0.2*i, 0.2*j, 0.2*k);
				XYZ<float> xyz = rgb;
				Lab<float> lab(xyz,XnYnZn);
				cout << lab.L() << ' ';
				cout << lab.a() << ' ';
				cout << lab.b() << endl;
			}
}
