// binary tree operations
template <class DataType>
void
BinaryTree<DataType>::insert(const DataType &data)
{
    // insert new data
    insert(root, data);

#ifdef MUTABLE_ITERATOR
    // check if any iterators are traversing this tree
    if ( ! iterList.isEmpty())
    {
        // now update any iterators
        ListIterator<AbstractIterator<DataType> * > *piter = 
        new ListIterator<AbstractIterator<DataType> * >(iterList);
        MustBeTrue(piter != NULL);
        for ( ; ! (*piter).done(); (*piter)++)
        {
            // save current iterator
            AbstractIterator<DataType> *paiter = (*piter)();

            // get current value
            DataType current = (*paiter)();

            // update iterator
            (*paiter).resetByValue(current);
        }
        delete piter;
    }
#endif
    return;
}

template <class DataType>
int
BinaryTree<DataType>::remove(DataType &data)
{
#ifdef MUTABLE_ITERATOR
    // check if any iterators are traversing this tree
    int status;
    if (iterList.isEmpty())
        return(remove(root, data));
    else
    {
        ListIterator<AbstractIterator<DataType> * > *piter = 
        new ListIterator<AbstractIterator<DataType> * >(iterList);
        for ( ; ! (*piter).done(); (*piter)++)
        {
            // save current iterator
            AbstractIterator<DataType> *paiter = (*piter)();

            // check of iterator is done
            if ((*paiter).done()) continue;

            // check if iterator is pointing to deleted node
            if (data == (*paiter)()) (*paiter)++;
        }

        // delete element
        int status = remove(root, data);
        if (status != OK) return(status);

        // reset all iterators
        for ((*piter).reset(); ! (*piter).done(); (*piter)++)
        {
            // save current iterator
            AbstractIterator<DataType> *paiter = (*piter)();

            // get current value
            DataType current = (*paiter)();

            // check if iterator is done
            if ( ! (*paiter).done())
                (*paiter).resetByValue(current);
        }
        delete piter;
        return(OK);
    }
#else
    return(remove(root, data));
#endif
}

template <class DataType>
void
BinaryTree<DataType>::clear()
{
    // clear binary tree
    clear(root);

#ifdef MUTABLE_ITERATOR
    // reset all iterators
    ListIterator<AbstractIterator<DataType> * > *piter = 
    new ListIterator<AbstractIterator<DataType> * >(iterList);
    for ( ; ! (*piter).done(); (*piter)++)
    {
        // current iterator
        AbstractIterator<DataType> *paiter = (*piter)();

        // reset iterator
        (*paiter).reset();
    }
#endif
    return;
}




