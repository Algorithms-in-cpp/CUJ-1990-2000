// preorder iterator constructors and destructor
template <class DataType>
BinaryTreeIterator_PreOrder<DataType>::BinaryTreeIterator_PreOrder(
    const BinaryTreeIterator_PreOrder<DataType> &iter): 
    tree(iter.tree), stack(iter.stack)
{
}

BinaryTreeIterator_PreOrder<DataType>::BinaryTreeIterator_PreOrder(
    const BinaryTree<DataType> &bt): 
    tree(&bt), stack()
{
    reset();
}


template <class DataType>
BinaryTreeIterator_PreOrder<DataType>::
    ~BinaryTreeIterator_PreOrder()
{
}

// reset iterator to beginning
template <class DataType>
void BinaryTreeIterator_PreOrder<DataType>::reset()
{
    stack.clear();
    stack.push(tree->root);
    return;
}

// is list empty
template <class DataType>
int BinaryTreeIterator_PreOrder<DataType>::done() const
{
    return(stack.isEmpty());
}

// return current data
template <class DataType>
DataType BinaryTreeIterator_PreOrder<DataType>::operator()()
{
    BinaryTreeNode<DataType> *btn;
    MustBeTrue(stack.top(btn) == OK);
    return(btn->data);
}

// increment to next data item in list
template <class DataType>
int BinaryTreeIterator_PreOrder<DataType>::operator++(int)
{
    // is iterator done
    if (stack.isEmpty()) return(NOTOK);

    // get next node from stack
    BinaryTreeNode<DataType> *btn;
    MustBeTrue(stack.pop(btn) == OK);

    // stack left and right nodes, if any.
    if (btn->right != NULL)
        stack.push(btn->right);
    if (btn->left != NULL)
        stack.push(btn->left);
    return(OK);
}
