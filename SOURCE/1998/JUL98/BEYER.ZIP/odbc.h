/* odbc.h */
/* Copyright (c) 1998, Malcolm Keller Beyer III. All rights reserved. */
/* Permission is granted to use this code as long as this notice appears in all copies. */
#if !defined(ODBC_H)
#define ODBC_H

typedef struct odbc_tag	odbc_t;
typedef void (*odbc_handler_t)(const char *format, ...);

odbc_t	*odbc_administer(odbc_t *odbc, const string_t *section, const string_t *key, const string_t *value);
odbc_t	*odbc_connect(odbc_t *odbc, const string_t *data_source_name, const string_t *user_id, const string_t *password);
odbc_t	*odbc_construct(const odbc_handler_t failure_handler, const odbc_handler_t warning_handler);
void	odbc_destruct(odbc_t *odbc);
odbc_t	*odbc_disconnect(odbc_t *odbc);
odbc_t	*odbc_execute(odbc_t *odbc, const string_t *command);
odbc_t	*odbc_fetch_record(odbc_t *odbc);
odbc_t	*odbc_get_field(odbc_t *odbc, unsigned short int i, string_t *field, size_t size);
odbc_t	*odbc_get_field_count(odbc_t *odbc, short int *n);
odbc_handler_t	odbc_set_failure_handler(odbc_t *odbc, odbc_handler_t failure_handler);
odbc_handler_t	odbc_set_warning_handler(odbc_t *odbc, odbc_handler_t warning_handler);

#endif
