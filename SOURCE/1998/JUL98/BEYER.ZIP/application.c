/* application.cpp */
/* Copyright (c) 1998, Malcolm Keller Beyer III. All rights reserved. */
/* Permission is granted to use this code as long as this notice appears in all copies. */
#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "string.h"
#include "odbc.h"
#include "application.h"

#define APPLICATION_BUFSIZ	FILENAME_MAX + 0xF000

struct application_tag
{
	string_t	*database;
	string_t	*directory;
	string_t	*description;
	string_t	*driver;
	string_t	*driver_32;
	string_t	*driver_id;
	string_t	*dsn;
	string_t	*exclusive;
	string_t	*fil;
	string_t	*password;
	string_t	*read_only;
	string_t	*trace;
	string_t	*trace_file;
	string_t	*uid;
	string_t	input[APPLICATION_BUFSIZ];
	string_t	output[APPLICATION_BUFSIZ];
	odbc_t	*odbc;
	application_handler_t	err;
};

static application_t	*application_administer(application_t *application);
static void	application_err(const string_t *format, ...);
static string_t	*application_prompt(application_t *application, const string_t *prompt, char_t delimiter);

application_t	*application_construct(const application_handler_t error_handler)
{
	char	function[] = "application_construct";
	application_t	*application = (application_t *) malloc(sizeof(application_t));

	if (application == (application_t *) NULL)
	{
		if (error_handler != (application_handler_t) NULL)
		{
			error_handler("%s: %s", function, "out of memory");
		}
		else
		{
			application_err("%s: %s", function, "out of memory");
		}

		return (application_t *) NULL;
	}

	application_set_handler(application, error_handler);

	application->database = string_construct(application_prompt(application, "Database: ", '\n'));
	application->directory = string_construct(application_prompt(application, "Directory: ", '\n'));
	application->description = string_construct(application_prompt(application, "Description: ", '\n')); 
	application->driver = string_construct(application_prompt(application, "Driver: ", '\n'));
	application->driver_32 = string_construct(application_prompt(application, "Driver32: ", '\n'));
	application->driver_id = string_construct(application_prompt(application, "DriverID: ", '\n'));
	application->dsn = string_construct(application_prompt(application, "DSN: ", '\n'));
	application->exclusive = string_construct(application_prompt(application, "Exclusive (0/1): ", '\n'));
	application->fil = string_construct(application_prompt(application, "FIL: ", '\n'));
	application->password = string_construct(application_prompt(application, "Password: ", '\n'));
	application->trace = string_construct(application_prompt(application, "Trace: ", '\n'));
	application->trace_file = string_construct(application_prompt(application, "Trace File: ", '\n'));
	application->read_only = string_construct(application_prompt(application, "Read Only (0/1): ", '\n'));
	application->uid = string_construct(application_prompt(application, "UID : ", '\n'));

	if ((application->odbc = odbc_construct(NULL, NULL)) == (odbc_t *) NULL)
	{
		application->err("%s: %s", function, "odbc construction error");
		application_destruct(application);
		return (application_t *) NULL;
	}

	return application_administer(application);
}

application_t	*application_construct_ini(const application_handler_t error_handler, const string_t *ini)
{
	char	function[] = "application_construct_ini";
	application_t	*application = (application_t *) malloc(sizeof(application_t));
	const char	*section = "SQL Interpreter";
	char	*input;

	if (application == (application_t *) NULL)
	{
		if (error_handler != (application_handler_t) NULL)
		{
			error_handler("%s: %s", function, "out of memory");
		}
		else
		{
			application_err("%s: %s", function, "out of memory");
		}

		return (application_t *) NULL;
	}

	application_set_handler(application, error_handler);

	input = (char *) application->input;

	GetPrivateProfileString(section, "Database", "", input, APPLICATION_BUFSIZ, ini);
	application->database = string_construct(input);
	GetPrivateProfileString(section, "Description", "", input, APPLICATION_BUFSIZ, ini);
	application->description = string_construct(input);
	GetPrivateProfileString(section, "Directory", "", input, APPLICATION_BUFSIZ, ini);
	application->directory = string_construct(input);
	GetPrivateProfileString(section, "Driver", "", input, APPLICATION_BUFSIZ, ini);
	application->driver = string_construct(input);
	GetPrivateProfileString(section, "Driver32", "", input, APPLICATION_BUFSIZ, ini);
	application->driver_32 = string_construct(input);
	GetPrivateProfileString(section, "DriverID", "", input, APPLICATION_BUFSIZ, ini);
	application->driver_id = string_construct(input);
	GetPrivateProfileString(section, "DSN", "", input, APPLICATION_BUFSIZ, ini);
	application->dsn = string_construct(input);
	GetPrivateProfileString(section, "Exclusive", "0", input, APPLICATION_BUFSIZ, ini);
	application->exclusive = string_construct(input);
	GetPrivateProfileString(section, "FIL", "", input, APPLICATION_BUFSIZ, ini);
	application->fil = string_construct(input);
	GetPrivateProfileString(section, "ReadOnly", "0", input, APPLICATION_BUFSIZ, ini);
	application->read_only = string_construct(input);
	GetPrivateProfileString(section, "Password", "", input, APPLICATION_BUFSIZ, ini);
	application->password = string_construct(input);
	GetPrivateProfileString(section, "Trace", "", input, APPLICATION_BUFSIZ, ini);
	application->trace = string_construct(input);
	GetPrivateProfileString(section, "TraceFile", "", input, APPLICATION_BUFSIZ, ini);
	application->trace_file = string_construct(input);
	GetPrivateProfileString(section, "UID", "", input, APPLICATION_BUFSIZ, ini);
	application->uid = string_construct(input);

	if ((application->odbc = odbc_construct(NULL, NULL)) == (odbc_t *) NULL)
	{
		application->err("%s: %s", function, "odbc construction error");
		return (application_t *) NULL;
	}

	return application_administer(application);
}

int	application_execute(application_t *application)
{
	char	function[] = "application_execute";
	char	field_separator = '\t';
	char	record_separator = '\n';
	string_t	*query, *field = application->output;
	odbc_t	*odbc = application->odbc;
	short int	n;
	unsigned short int	i;

	if (!odbc_connect(odbc, application->dsn, application->uid, application->password))
	{
		application->err("%s: %s", function, "odbc connection error");
		return EXIT_FAILURE;
	}

	for ( ;; )
	{
		query = application_prompt(application, "SQL> ", ';');

		if (string_compare(query, "quit") == 0)
		{
			break;
		}

		odbc_execute(odbc, query);
		odbc_get_field_count(odbc, &n);

		if (n == 0)
		{
			continue;
		}

		while (odbc_fetch_record(odbc) != (odbc_t *) NULL)
		{
			for (i = 1; i <= n; i++)
			{
				odbc_get_field(odbc, i, field, APPLICATION_BUFSIZ);
				fprintf(stdout, "%s%c", (char *) field, i == n ? record_separator : field_separator);
			}
		}

		fputc('\n', stdout);
		fflush(stdout);
	}

	if (!odbc_disconnect(odbc))
	{
		application->err("%s: %s", function, "odbc disconnect error");
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}

void	application_destruct(application_t *application)
{
	string_destruct(application->database);
	string_destruct(application->description);
	string_destruct(application->directory);
	string_destruct(application->driver);
	string_destruct(application->driver_32);
	string_destruct(application->driver_id);
	string_destruct(application->dsn);
	string_destruct(application->exclusive);
	string_destruct(application->fil);
	string_destruct(application->read_only);
	string_destruct(application->password);
	string_destruct(application->trace);
	string_destruct(application->trace_file);
	string_destruct(application->uid);

	odbc_destruct(application->odbc);

	free(memset(application, 0x0, sizeof(application_t)));

	return;
}

application_handler_t	application_set_handler(application_t *application, const application_handler_t error_handler)
{
	application_handler_t	previous = application->err;

	application->err = (error_handler == (application_handler_t) NULL) ? application_err : error_handler;

	return previous;
}

static application_t	*application_administer(application_t *application)
{
	char	function[] = "application_administer";
	odbc_t	*odbc = application->odbc;

	if (!odbc_administer(odbc, "ODBC", "Trace", application->trace)
	|| !odbc_administer(odbc,  "ODBC", "TraceFile", application->trace_file)
	/* Create Data Source */
	|| !odbc_administer(odbc,  "ODBC Data Sources", application->dsn, "Microsoft Access Driver (*.mdb)")
	|| !odbc_administer(odbc,  "ODBC 32 bit Data Sources", application->dsn, "Microsoft Access Driver (*.mdb)")
	/* Remove any pre-existing Data Source information */
	|| !odbc_administer(odbc, application->dsn, NULL, NULL)
	/* Configure Data Source */
	|| !odbc_administer(odbc, application->dsn, "DBQ", application->database)
	|| !odbc_administer(odbc, application->dsn, "DefaultDir", application->directory)
	|| !odbc_administer(odbc, application->dsn, "Description", application->description)
	|| !odbc_administer(odbc, application->dsn, "Driver", application->driver)
	|| !odbc_administer(odbc, application->dsn, "Driver32", application->driver_32)
	|| !odbc_administer(odbc, application->dsn, "DriverID", application->driver_id)
	|| !odbc_administer(odbc, application->dsn, "Exclusive", application->exclusive)
	|| !odbc_administer(odbc, application->dsn, "FIL", application->fil)
	|| !odbc_administer(odbc, application->dsn, "ReadOnly", application->read_only)
	|| !odbc_administer(odbc, application->dsn, "UID", application->uid)
	/* Flush cached ODBC.INI file */
	|| odbc_administer(odbc, NULL, NULL, NULL)) /* returns null by design */
	{
		application->err("%s: %s\n", function, "odbc_administer() failure");
	}

	return application;
}

static void	application_err(const string_t *format, ...)
{
	va_list	arg;

	fprintf(stderr, "application:\n");
	va_start(arg, (char *) format);
	vfprintf(stderr, (char *) format, arg);
	va_end(arg);
	fprintf(stderr, "\n");
	fflush(stderr);
	exit(EXIT_FAILURE);

	return;
}

static char	*application_prompt(application_t *application, const string_t *prompt, char_t delimiter)
{
	char	function[] = "application_prompt";
	int	c;
	size_t	index;
	string_t	*input = application->input;

	fprintf(stdout, "%s", (char *) prompt);
	fflush(stdout);

	for(index = 0; index < APPLICATION_BUFSIZ; index++)
	{
		if ((c = fgetc(stdin)) == EOF || (c == (int) delimiter))
		{
			break;
		}

		input[index] = (char_t) c;
	}

	fprintf(stdout, "\n");
	fflush(stdout);
	input[index] = '\0';
	string_replace(input, '\n', ' ');
	string_trim(input);

	if (index == APPLICATION_BUFSIZ)
	{
		application->err("%s: %s", function, "input overflow");
	}

	return	input;
}
