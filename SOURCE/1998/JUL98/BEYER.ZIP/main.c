/* main.c */
/* Copyright (c) 1998, Malcolm Keller Beyer III. All rights reserved. */
/* Permission is granted to use this code as long as this notice appears in all copies. */
#define WIN32_LEAN_AND_MEAN
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "application.h"

static void	main_err(const string_t *format, ...);

int	main(int argc, char *argv[])
{
	char	function[] = "main";
	int	main;
	application_t	*application;

	if (argc == 2)
	{
		application = application_construct_ini(NULL, argv[1]);
	}
	else
	{
		application = application_construct(NULL);
	}

	if (application == (application_t *) NULL)
	{
		main_err("%s: %s", function, "application construction error");
	}

	main = application_execute(application);

	application_destruct(application);

	return main;
}

static void	main_err(const string_t *format, ...)
{
	va_list	arg;

	fprintf(stderr, "main:\n");
	va_start(arg, (char *) format);
	vfprintf(stderr, (char *) format, arg);
	va_end(arg);
	fprintf(stderr, "\n");
	fflush(stderr);
	exit(EXIT_FAILURE);

	return;
}

