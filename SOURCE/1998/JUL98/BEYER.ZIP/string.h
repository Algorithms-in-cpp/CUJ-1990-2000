/* string.h */
/* Copyright (c) 1998, Malcolm Keller Beyer III. All rights reserved. */
/* Permission is granted to use this code as long as this notice appears in all copies. */
#if !defined(STRING_H)
#define STRING_H

typedef char	char_t, string_t;
typedef void (*string_handler_t)(const char *format, ...);

int	string_compare(const string_t *string1, const string_t *string2);
string_t	*string_construct(const char_t *s);
string_t	*string_copy(string_t *string1, const string_t *string2);
void	string_destruct(string_t *string);
string_t	*string_filter(string_t *string, char_t c);
string_t	*string_left(string_t *string, int n);
size_t	string_length(const string_t *string);
string_t	*string_middle(string_t *string, int begin, int end);
int	string_put(const string_t *string);
string_t	*string_replace(string_t *string, char_t c1, char_t c2);
string_t	*string_right(string_t *string, int n);
string_handler_t	string_set_handler(string_handler_t error_handler);
size_t	string_size(const string_t *string);
string_t	*string_trim(string_t *string);
string_t	*string_trim_left(string_t *string);
string_t	*string_trim_right(string_t *string);

/* 
#if !defined(STRING_C) && !defined(NDEBUG)
#define strcpy	string_copy
#define strncpy	string_copy_count
#define strcat	string_concatenate
#define strncat	string_concatenate_count
#define strcmp	string_compare
#define strncmp	string_compare_count
#define strchr	string_character
#define strrchr	string_character_right
#define strspn	string_ _index
#define strcspn	string_ _index_not
#define strpbrk	string_
#define strstr	string_string
#define strlen	string_length
#define strerror	string_error
#define strtok	string_token
#endif
*/

#endif
