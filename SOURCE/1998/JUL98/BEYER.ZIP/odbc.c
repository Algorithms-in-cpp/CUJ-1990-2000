/* odbc.c */
/* Copyright (c) 1998, Malcolm Keller Beyer III. All rights reserved. */
/* Permission is granted to use this code as long as this notice appears in all copies. */
#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <odbcinst.h>
#include <sql.h>
#include <sqlext.h>
#include "string.h"
#include "odbc.h"

static void	odbc_err_format(odbc_t *odbc, const SQLCHAR *message, const SQLCHAR *state, SQLINTEGER error);
static void	odbc_fail(const string_t *format, ...);
static void	odbc_warn(const string_t *format, ...);
static odbc_t	*odbc_validate(odbc_t *odbc, SQLRETURN code);

struct	odbc_tag
{
	SQLHDBC	hdbc;
	SQLHENV	henv;
	SQLHSTMT	hstmt;
	odbc_handler_t	fail, warn;
};

static const char	*ODBC_ERROR_NO_MEMORY = "out of memory";

odbc_t	*odbc_administer(odbc_t *odbc, const string_t *section, const string_t *key, const string_t *value)
{
	if (SQLWritePrivateProfileString((char *) section, (char *) key, (char *) value, "odbc.ini") == FALSE)
	{
		return (odbc_t *) NULL;
	}

	return odbc;
}

odbc_t  *odbc_connect(odbc_t *odbc, const string_t *data_source_name, const 
string_t *user_id, const string_t *password)
{
        const char      *function = "odbc_connect"; 
        SQLUSMALLINT    conformance;
     
        if (odbc_validate(odbc, SQLAllocEnv(&odbc->henv)) == (odbc_t *) NULL 
        || odbc_validate(odbc, SQLAllocConnect(odbc->henv, &odbc->hdbc)) == (odbc_t *) NULL
        || odbc_validate(odbc, SQLConnect(odbc->hdbc, (SQLCHAR *) data_source_name, SQL_NTS, (SQLCHAR *) user_id, SQL_NTS, (SQLCHAR *) password, SQL_NTS)) == (odbc_t *) NULL
        || odbc_validate(odbc, SQLAllocStmt(odbc->hdbc, &odbc->hstmt)) == (odbc_t *) NULL
        || odbc_validate(odbc, SQLGetInfo(odbc->hdbc, SQL_ODBC_API_CONFORMANCE, &conformance, sizeof(conformance), NULL)) == (odbc_t *) NULL)
        {
                return (odbc_t *) NULL;
        }
     
        if (conformance < SQL_OAC_LEVEL1)
        {
                odbc->fail("%s: %s", function, "SQL ODBC API CONFORMANCE is less than SQL OAC LEVEL1");
                return (odbc_t *) NULL;
        }
     
        return odbc;
}

odbc_t	*odbc_construct(const odbc_handler_t failure_handler, const odbc_handler_t warning_handler)
{
	char	function[] = "odbc_construct";
	odbc_t	*odbc = (odbc_t *) malloc(sizeof(odbc_t));

	if (odbc == (odbc_t *) NULL)
	{
		if (failure_handler != (odbc_handler_t) NULL)
		{
			failure_handler("%s: %s", function, ODBC_ERROR_NO_MEMORY);
		}
		else
		{
			odbc_fail("%s: %s", function, ODBC_ERROR_NO_MEMORY);
		}

		return (odbc_t *) NULL;
	}

	odbc_set_failure_handler(odbc, failure_handler);
	odbc_set_warning_handler(odbc, warning_handler);
	odbc->hdbc = SQL_NULL_HDBC;
	odbc->henv = SQL_NULL_HENV;
	odbc->hstmt = SQL_NULL_HSTMT;

	return odbc;
}

void	odbc_destruct(odbc_t *odbc)
{
	free(memset(odbc, 0x0, sizeof(odbc_t)));

	return;
}

odbc_t	*odbc_disconnect(odbc_t *odbc)
{
	if (!odbc_validate(odbc, SQLFreeStmt(odbc->hstmt, SQL_DROP))
	|| !odbc_validate(odbc, SQLDisconnect(odbc->hdbc))
	|| !odbc_validate(odbc, SQLFreeConnect(odbc->hdbc))
	|| !odbc_validate(odbc, SQLFreeEnv(odbc->henv)))
	{
		return (odbc_t *) NULL;
	}

	odbc->hdbc = SQL_NULL_HDBC;
	odbc->henv = SQL_NULL_HENV;
	odbc->hstmt = SQL_NULL_HSTMT;

	return odbc;
}

odbc_t	*odbc_execute(odbc_t *odbc, const string_t *command)
{
	if (!odbc_validate(odbc, SQLFreeStmt(odbc->hstmt, SQL_CLOSE))
	|| !odbc_validate(odbc, SQLFreeStmt(odbc->hstmt, SQL_UNBIND))
	|| !odbc_validate(odbc, SQLExecDirect(odbc->hstmt, (SQLCHAR *) command, SQL_NTS))
	|| !odbc_validate(odbc, SQLTransact(odbc->henv, odbc->hdbc, SQL_COMMIT)))
	{
		return (odbc_t *) NULL;
	}

	return odbc;
}

odbc_t	*odbc_fetch_record(odbc_t *odbc)
{
	return	odbc_validate(odbc, SQLFetch(odbc->hstmt));
}

odbc_t	*odbc_get_field(odbc_t *odbc, unsigned short int i, string_t *field, size_t size)
{
	char	function[] = "odbc_fetch_field";
	SQLINTEGER	total;
		
	if (!odbc_validate(odbc, SQLGetData(odbc->hstmt, i, SQL_C_CHAR, (SQLCHAR *) field, size - sizeof(char_t), &total)))
	{
		return (odbc_t *) NULL;
	}

	if (total == SQL_NO_TOTAL)
	{
		odbc->warn("%s: %s", function, "SQL No Total result");
	}

	return odbc;
}

odbc_t	*odbc_get_field_count(odbc_t *odbc, short int *n)
{
	return	odbc_validate(odbc, SQLNumResultCols(odbc->hstmt, n));
}

odbc_handler_t	odbc_set_failure_handler(odbc_t *odbc, odbc_handler_t failure_handler)
{
	odbc_handler_t	previous = odbc->fail;

	odbc->fail = (failure_handler == (odbc_handler_t) NULL) ? odbc_fail : failure_handler;

	return previous;
}

odbc_handler_t	odbc_set_warning_handler(odbc_t *odbc, odbc_handler_t warning_handler)
{
	odbc_handler_t	previous = odbc->warn;

	odbc->warn = (warning_handler == (odbc_handler_t) NULL) ? odbc_warn : warning_handler;

	return previous;
}

static void	odbc_err_format(odbc_t *odbc, const SQLCHAR *message, const SQLCHAR *state, SQLINTEGER error)
{
	SQLCHAR diagnostic[SQL_MAX_MESSAGE_LENGTH + SQL_SQLSTATE_SIZE + 0xF];

	sprintf
	(
		(char *) diagnostic,
		"Message: %s\nState: %s\nError: %ld\n",
		(char *) message, (char *) state, (long) error
	);
	
	/* State "01000" correspondes to SQL_SUCCESS_WITH_INFO */
	if (string_compare((string_t *) state, "01000") == 0)
	{
		odbc->warn((string_t *) diagnostic);
	}
	else
	{
		odbc->fail((string_t *) diagnostic);
	}

	return;
}

static void	odbc_fail(const string_t *format, ...)
{
	va_list	arg;

	fprintf(stderr, "ODBC:\n");
	va_start(arg, (char *) format);
	vfprintf(stderr, (char *) format, arg);
	va_end(arg);
	fprintf(stderr, "\n");
	fflush(stderr);
	exit(EXIT_FAILURE);

	return;
}

static void	odbc_warn(const string_t *format, ...)
{
	va_list	arg;

	fprintf(stderr, "ODBC:\n");
	va_start(arg, (char *) format);
	vfprintf(stderr, (char *) format, arg);
	va_end(arg);
	fprintf(stderr, "\n");
	fflush(stderr);

	return;
}

static odbc_t	*odbc_validate(odbc_t *odbc, SQLRETURN code)
{
	odbc_t	*validate = (odbc_t *) NULL;
	SQLCHAR	state[SQL_SQLSTATE_SIZE + 1];
	SQLCHAR	message[SQL_MAX_MESSAGE_LENGTH]; /* SQL_MAX_MESSAGE_LENGTH takes into account NULL terminator */
	SQLSMALLINT	size = sizeof(message) - sizeof(char);
	SQLSMALLINT	count;
	SQLINTEGER	error;

	switch (code)
	{
	case SQL_SUCCESS:
		return odbc;
	case SQL_SUCCESS_WITH_INFO:
		validate = odbc;
		break;
	case SQL_NEED_DATA:
		odbc->warn("SQL Need Data");
		return (odbc_t *) NULL;
	case SQL_NO_DATA_FOUND:
		return (odbc_t *) NULL;
	case SQL_STILL_EXECUTING:
		odbc->warn("SQL Still Executing");
		return (odbc_t *) NULL;
	default:
		break;
	}

	if (odbc->henv == SQL_NULL_HENV)
	{
		return validate;
	}
	
	while ((code = SQLError(odbc->henv, SQL_NULL_HDBC, SQL_NULL_HSTMT, state, &error, message, size, &count)) != SQL_NO_DATA_FOUND)
	{
		odbc_err_format(odbc, message, state, error);
	}

	if (odbc->hdbc == SQL_NULL_HDBC)
	{
		return validate;
	}

	while ((code = SQLError(odbc->henv, odbc->hdbc, SQL_NULL_HSTMT, state, &error, message, size, &count)) != SQL_NO_DATA_FOUND)
	{
		odbc_err_format(odbc, message, state, error);
	}

	if (odbc->hstmt == SQL_NULL_HSTMT)
	{
		return validate;
	}

	while ((code = SQLError(odbc->henv, odbc->hdbc, odbc->hstmt, state, &error, message, size, &count)) != SQL_NO_DATA_FOUND)
	{
		odbc_err_format(odbc, message, state, error);
	}

	return validate;
}
