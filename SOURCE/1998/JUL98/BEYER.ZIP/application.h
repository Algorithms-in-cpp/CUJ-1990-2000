/* application.h */
/* Copyright (c) 1998, Malcolm Keller Beyer III. All rights reserved. */
/* Permission is granted to use this code as long as this notice appears in all copies. */
#if !defined(APPLICATION_H)
#define APPLICATION_H

typedef struct application_tag	application_t;
typedef void (*application_handler_t)(const char *format, ...);

application_t	*application_construct(const application_handler_t error_handler);
application_t	*application_construct_ini(const application_handler_t error_handler, const string_t *ini);
void	application_destruct(application_t *application);
int	application_execute(application_t *application);
application_handler_t	application_set_handler(application_t *application, const application_handler_t error_handler);

#endif
