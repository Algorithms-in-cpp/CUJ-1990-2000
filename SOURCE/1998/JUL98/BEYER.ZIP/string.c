/* string.c */
/* Copyright (c) 1998, Malcolm Keller Beyer III. All rights reserved. */
/* Permission is granted to use this code as long as this notice appears in all copies. */
#include <stdarg.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define STRING_C
#include "string.h"
#undef STRING_C

const char	*STRING_ERROR_NO_MEMORY = "out of memory";
const char	*STRING_ERROR_NULL_HANDLER = "handler is null";
const char	*STRING_ERROR_NULL_STRING = "string is null";
const char	*STRING_ERROR_NULL_STRING1 = "string1 is null";
const char	*STRING_ERROR_NULL_STRING2 = "string2 is null";

static void	string_err_default(const string_t *format, ...);
static string_handler_t	string_err = &string_err_default;

/* case insensitive string comparison */
int	string_compare(const string_t *string1, const string_t *string2)
{
	char	function[] = "string_compare";

	if (string1 == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING1);
	}

	if (string2 == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING2);
	}

	for ( ; toupper(*string1) == toupper(*string2); string1++, string2++)
	{
		if (*string1 == '\0')
		{
			return 0;
		}
		
		if (*string2 == '\0')
		{
			return +1;
		}
	}

	return (toupper(*string1) < toupper(*string2)) ? -1 : +1;
}

string_t	*string_copy(string_t *string1, const string_t *string2)
{
	char	function[] = "string_copy";

	if (string1 == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING1);
	}

	if (string2 == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING2);
	}

	return strcpy(string1, string2);
}

string_t	*string_construct(const char_t *s)
{
	char	function[] = "string_construct";
	string_t	*string;

	if (s == (const char_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	string = (string_t *) malloc(string_size((const string_t *) s));

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NO_MEMORY);
	}

	return strcpy(string, (const string_t *) s);
}

void	string_destruct(string_t *string)
{
	char	function[] = "string_destruct";
	string_t	*s = string;

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	for ( ; *s != '\0'; s++)
	{
		*s = '\0';
	}

	free(string);

	return;
}

string_t	*string_filter(string_t *string, char_t c)
{
	char	function[] = "string_filter";
	string_t	*string1, *string2;

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	for (string1 = string2 = string; *string2 != '\0'; string2++)
	{
		if (*string2 != c)
		{
			*string1++ = *string2;
		}
	}

	*string1 = '\0';
   
	return string;
}

string_t	*string_left(string_t *string, int n)
{
	char	function[] = "string_left";

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	return string_middle(string, 0, n);
}

size_t	string_length(const string_t *string)
{
	char	function[] = "string_length";
	string_t	*s = (string_t *) string;

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	while(*s++)
	{
		;
	}

	return s - string - sizeof(char_t);
}

string_t	*string_middle(string_t *string, int begin, int end)
{
	char	function[] = "string_middle";

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	if (begin > end)
	{
		return (string_t *) NULL;
	}

	memmove(string, string + begin, end - begin);
	string[end - begin] = '\0';

	return string;
}

int	string_put(const string_t *string)
{
	char	function[] = "string_put";

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	return puts(string);
}

string_t	*string_replace(string_t *string, char_t c1, char_t c2)
{
	char	function[] = "string_replace";
	string_t	*s;

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	for (s = string; *s != '\0'; s++)
	{
		if (*s == c1)
		{
			*s = c2;
		}
	}

	return string;
}

string_t	*string_right(string_t *string, int n)
{
	char	function[] = "string_right";
	int	length = string_length(string);

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	
	return string_middle(string, length - n, length);
}

string_handler_t	string_set_handler(string_handler_t error_handler)
{
	string_handler_t	previous = string_err;

	string_err = (error_handler == (string_handler_t) NULL) ? string_err_default : error_handler;

	return previous;
}

size_t	string_size(const string_t *string)
{
	char	function[] = "string_size";
	string_t	*s = (string_t *) string;

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	while(*s++)
	{
		;
	}

	return s - string;
}

string_t	*string_trim(string_t *string)
{
	char	function[] = "string_trim";

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	return string_trim_left(string_trim_right(string));
}

string_t	*string_trim_left(string_t *string)
{
	char	function[] = "string_trim_left";
	string_t  *string1, *string2;

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	for (string1 = string; *string1 && isspace(*string1); string1++)
	{
		;
	}

	if (string1 == string)
	{
		return string;
	}

	for (string2 = string; *string1 != '\0'; string1++, string2++)
	{
		*string2 = *string1;
	}

	*string2 = '\0';

	return string;
}

string_t	*string_trim_right(string_t *string)
{
	char	function[] = "string_trim_right";
	int	length = string_length(string);
	string_t	*s;

	if (string == (string_t *) NULL)
	{
		string_err("%s: %s", function, STRING_ERROR_NULL_STRING);
	}

	if (length == 0)
	{
		return string;
	}

	for (s = string + length - 1; s >= string && isspace(*s); s--)
	{
		;
	}

	*++s = '\0';

	return string;
}

static void	string_err_default(const string_t *format, ...)
{
	va_list	arg;

	fprintf(stderr, "string:\n");
	va_start(arg, (char *) format);
	vfprintf(stderr, (char *) format, arg);
	va_end(arg);
	fprintf(stderr, "\n");
	fflush(stderr);
	exit(EXIT_FAILURE);

	return;
}
