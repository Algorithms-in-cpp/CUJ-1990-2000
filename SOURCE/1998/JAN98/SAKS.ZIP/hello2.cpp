1)  #include <iostream>     // no .h suffix 
2)
3)  int main()
4)      {
5)      std::cout << "Hello, world\n"; 
6)      return 0;
7)  }
