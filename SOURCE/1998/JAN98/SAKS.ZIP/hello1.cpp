1)  #include <iostream.h>   // .h suffix 
2)
3)  int main()
4)      {
5)      cout << "Hello, world\n";
6)      return 0;
7)      }
