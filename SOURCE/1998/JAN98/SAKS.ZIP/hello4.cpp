1)  #include <iostream>
2)  using namespace std;
3)
4)  int main()
5)      {
6)      cout << "Hello, world\n";
7)      return 0;
8)      }
