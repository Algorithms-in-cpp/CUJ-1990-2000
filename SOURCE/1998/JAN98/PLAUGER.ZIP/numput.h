        // TEMPLATE CLASS num_put
template<class _E,
    class _OI = ostreambuf_iterator<_E, char_traits<_E> > >
    class num_put : public locale::facet {
public:
    typedef numpunct<_E> _Mypunct;
    typedef basic_string<_E, char_traits<_E>, allocator<_E> >
        _Mystr;
    static locale::id id;
protected:
    virtual ~num_put()
        {}
public:
    explicit num_put(size_t _R = 0);
    typedef _E char_type;
    typedef _OI iter_type;
    _OI put(_OI _F, ios_base& _X, _E _Fill,
        bool _V) const
        {return (do_put(_F, _X, _Fill, _V)); }
    _OI put(_OI _F, ios_base& _X, _E _Fill,
        long _V) const
        {return (do_put(_F, _X, _Fill, _V)); }
    _OI put(_OI _F, ios_base& _X, _E _Fill,
        unsigned long _V) const
        {return (do_put(_F, _X, _Fill, _V)); }
    _OI put(_OI _F, ios_base& _X, _E _Fill,
        double _V) const
        {return (do_put(_F, _X, _Fill, _V)); }
    _OI put(_OI _F, ios_base& _X, _E _Fill,
        long double _V) const
        {return (do_put(_F, _X, _Fill, _V)); }
    _OI put(_OI _F, ios_base& _X, _E _Fill,
        const void *_V) const
        {return (do_put(_F, _X, _Fill, _V)); }
protected:
    virtual _OI do_put(_OI _F, ios_base& _X, _E _Fill,
        bool _V) const
        {const _Mypunct& _Fac = _USE(_X.getloc(), _Mypunct);
        _Mystr _Str;
        if (!(_X.flags() & ios_base::boolalpha))
            _Str.append((typename _Mystr::size_type)1,
                _WIDEN(_E, _V ? '1' : '0'));
        else if (_V)
            _Str = _Fac.truename();
        else
            _Str = _Fac.falsename();
        size_t _M = _X.width() <= 0 || _X.width() <= _Str.size()
            ? 0 : _X.width() - _Str.size();
        ios_base::fmtflags _Afl =
            _X.flags() & ios_base::adjustfield;
        if (_Afl != ios_base::left)
            _F = _Rep(_F, _Fill, _M), _M = 0;
        _F = _Put(_F, _Str.c_str(), _Str.size());
        _X.width(0);
        return (_Rep(_F, _Fill, _M)); }
    virtual _OI do_put(_OI _F, ios_base& _X, _E _Fill,
        long _V) const
        {char _Buf[2 * _MAX_INT_DIG], _Fmt[6];
        return (_Iput(_F, _X, _Fill, _Buf,
            sprintf(_Buf, _Ifmt(_Fmt, 'd', _X.flags()), _V))); }
    virtual _OI do_put(_OI _F, ios_base& _X, _E _Fill,
        unsigned long _V) const
        {char _Buf[2 * _MAX_INT_DIG], _Fmt[6];
        return (_Iput(_F, _X, _Fill, _Buf,
            sprintf(_Buf, _Ifmt(_Fmt, 'u', _X.flags()), _V))); }
    virtual _OI do_put(_OI _F, ios_base& _X, _E _Fill,
        double _V) const
        {char _Buf[_MAX_EXP_DIG + _MAX_SIG_DIG + 16], _Fmt[8];
        streamsize _Prec = _X.precision() <= 0
            && !(_X.flags() & ios_base::fixed) ? 6
            : _X.precision();
        int _Mpr = _MAX_SIG_DIG < _Prec ? _MAX_SIG_DIG : _Prec;
        return (_Fput(_F, _X, _Fill, _Buf, _Prec - _Mpr,
            sprintf(_Buf, _Ffmt(_Fmt, 0, _X.flags()),
                _Mpr, _V))); }
    virtual _OI do_put(_OI _F, ios_base& _X, _E _Fill,
        long double _V) const
        {char _Buf[_MAX_EXP_DIG + _MAX_SIG_DIG + 16], _Fmt[8];
        streamsize _Prec = _X.precision() <= 0
            && !(_X.flags() & ios_base::fixed) ? 6
            : _X.precision();
        int _Mpr = _MAX_SIG_DIG < _Prec ? _MAX_SIG_DIG : _Prec;
        return (_Fput(_F, _X, _Fill, _Buf, _Prec - _Mpr,
            sprintf(_Buf, _Ffmt(_Fmt, 'L', _X.flags()),
                _Mpr, _V))); }
    virtual _OI do_put(_OI _F, ios_base& _X, _E _Fill,
        const void *_V) const
        {
        const int _NL = 1
            + (sizeof (void *) - 1) / sizeof (unsigned long);
        char _Buf[(_NL + 1) * (_MAX_INT_DIG + 1)];
        int _N = sprintf(_Buf, "%p", _V);
        size_t _M = _X.width() <= 0 || _X.width() <= _N
            ? 0 : _X.width() - _N;
        ios_base::fmtflags _Afl =
            _X.flags() & ios_base::adjustfield;
        if (_Afl != ios_base::left)
            _F = _Rep(_F, _Fill, _M), _M = 0;
        _F = _Putc(_F, _Buf, _N);
        _X.width(0);
        return (_Rep(_F, _Fill, _M)); }
    static char *_Ffmt(char *_Fmt, char _Spec,
        ios_base::fmtflags _Fl)
        {char *_S = _Fmt;
        *_S++ = '%';
        if (_Fl & ios_base::showpos)
            *_S++ = '+';
        if (_Fl & ios_base::showpoint)
            *_S++ = '#';
        *_S++ = '.';
        *_S++ = '*';
        if (_Spec != 0)
            *_S++ = _Spec;    // 'L' for long double only
        ios_base::fmtflags _Ffl = _Fl & ios_base::floatfield;
        *_S++ = _Ffl == ios_base::fixed ? 'f'
            : _Ffl == ios_base::scientific ? 'e' : 'g';
        *_S = '\0';
        return (_Fmt); }
    static _OI _Fput(_OI _F, ios_base& _X, _E _Fill,
        const char *_S, size_t _Nz, size_t _N)
        {size_t _M = _X.width() <= 0 || _X.width() <= _N  + _Nz
            ? 0 : _X.width() - _N - _Nz;
        ios_base::fmtflags _Afl =
            _X.flags() & ios_base::adjustfield;
        if (_Afl != ios_base::left && _Afl != ios_base::internal)
            _F = _Rep(_F, _Fill, _M), _M = 0;
        else if (_Afl == ios_base::internal)
            {if (0 < _N && (*_S == '+' || *_S == '-'))
                _F = _Putc(_F, _S, 1), ++_S, --_N;
            _F = _Rep(_F, _Fill, _M), _M = 0; }
        const char *_P = (const char *)memchr(_S,
            localeconv()->decimal_point[0], _N);
        if (_P != 0)
            {const _Mypunct& _Fac = _USE(_X.getloc(), _Mypunct);
            size_t _Nf = _P - _S + 1;
            _F = _Putc(_F, _S, _Nf - 1);
            _F = _Rep(_F, _Fac.decimal_point(), 1);
            _S += _Nf, _N -= _Nf; }
        if ((_P = (const char *)memchr(_S, 'e', _N)) != 0)
            {size_t _Nm = _P - _S + 1;
            _F = _Putc(_F, _S, _Nm - 1);
            _F = _Rep(_F, _WIDEN(_E, '0'), _Nz), _Nz = 0;
            _F = _Putc(_F, _X.flags() & ios_base::uppercase
                ? "E" : "e", 1);
            _S += _Nm, _N -= _Nm; }
        _F = _Putc(_F, _S, _N);
        _F = _Rep(_F, _WIDEN(_E, '0'), _Nz);
        _X.width(0);
        return (_Rep(_F, _Fill, _M)); }
    static char *_Ifmt(char *_Fmt, char _Spec,
        ios_base::fmtflags _Fl)
        {char *_S = _Fmt;
        *_S++ = '%';
        if (_Fl & ios_base::showpos)
            *_S++ = '+';
        if (_Fl & ios_base::showbase)
            *_S++ = '#';
        *_S++ = 'l';
        ios_base::fmtflags _Bfl = _Fl & ios_base::basefield;
        *_S++ = _Bfl == ios_base::oct ? 'o'
            : _Bfl != ios_base::hex ? _Spec    // 'd' or 'u'
            : _Fl & ios_base::uppercase ? 'X' : 'x';
        *_S = '\0';
        return (_Fmt); }
    static _OI _Iput(_OI _F, ios_base& _X, _E _Fill,
        char *_S, size_t _N)
        {const size_t _Np = *_S == '+' || *_S == '-' ? 1
            : *_S == '0' && (_S[1] == 'x' || _S[1] == 'X') ? 2
            : 0;
        const _Mypunct& _Fac = _USE(_X.getloc(), _Mypunct);
        const string _Gr = _Fac.grouping();
        const _E _Ks = _Fac.thousands_sep();
        bool _Grp = '\0' < *_Gr.c_str();
        if (_Grp)
            {const char *_Pg = _Gr.c_str();
            size_t _I = _N;
            for (_Grp = false; *_Pg != CHAR_MAX && '\0' < *_Pg
                && *_Pg < _I - _Np; _Grp = true)
                {_I -= *_Pg;
                memmove(&_S[_I + 1], &_S[_I], _N + 1 - _I);
                _S[_I] = ',', ++_N;
                if ('\0' < _Pg[1])
                    ++_Pg; }}
        size_t _M = _X.width() <= 0 || _X.width() <= _N
            ? 0 : _X.width() - _N;
        ios_base::fmtflags _Afl =
            _X.flags() & ios_base::adjustfield;
        if (_Afl != ios_base::left && _Afl != ios_base::internal)
            _F = _Rep(_F, _Fill, _M), _M = 0;
        else if (_Afl == ios_base::internal)
            {_F = _Putc(_F, _S, _Np), _S += _Np, _N -= _Np;
            _F = _Rep(_F, _Fill, _M), _M = 0; }
        if (!_Grp)
            _F = _Putc(_F, _S, _N);
        else
            for (; ; ++_S, --_N)
                {size_t _Nd = strcspn(_S, ",");
                _F = _Putc(_F, _S, _Nd);
                _S += _Nd, _N -= _Nd;
                if (_N == 0)
                    break;
                if (_Ks != (_E)0)
                    _F = _Rep(_F, _Ks, 1); }
        _X.width(0);
        return (_Rep(_F, _Fill, _M)); }
    static _OI _Put(_OI _F, const _E *_S, size_t _N)
        {for (; 0 < _N; --_N, ++_F, ++_S)
            *_F = *_S;
        return (_F); }
    static _OI _Putc(_OI _F, const char *_S, size_t _N)
        {for (; 0 < _N; --_N, ++_F, ++_S)
            *_F = _WIDEN(_E, *_S);
        return (_F); }
    static _OI _Rep(_OI _F, _E _C, size_t _N)
        {for (; 0 < _N; --_N, ++_F)
            *_F = _C;
        return (_F); }
    };

template<class _E, class _OI>
    locale::id num_put<_E, _OI>::id;
