#include <jni.h>

__declspec(dllimport) volatile bool done;

int main() {
    JDK1_1InitArgs vm_args;
    JNIEnv* env;
    JavaVM* jvm;

    vm_args.version = 0x00010001;
    JNI_GetDefaultJavaVMInitArgs(&vm_args);
    /* change for your system */
    vm_args.classpath = ".;g:/java/jdk1.1.3/lib/classes.zip;";

    JNI_CreateJavaVM(&jvm, &env, &vm_args);

    jclass cls = env->FindClass("guessGui");
    jmethodID cons = env->GetMethodID(cls, "<init>", "()V");
    jobject obj = env->NewObject(cls, cons);

    jmethodID show = env->GetMethodID(cls, "showWindow", "()V");
    env->CallVoidMethod(obj, show);

    while (!done) {}

    return 1;
    }


