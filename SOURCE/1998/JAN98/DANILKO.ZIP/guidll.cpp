#include <stdlib.h>

#include <jni.h>
extern "C" {
JNIEXPORT void JNICALL
    Java_GuessGui_submitGuess(JNIEnv *, jobject, jint);
JNIEXPORT void JNICALL Java_GuessGui_done(JNIEnv *, jobject);
}

__declspec(dllexport) volatile bool done = false;


JNIEXPORT void JNICALL
  Java_GuessGui_submitGuess(JNIEnv* env, jobject obj, jint guiNum) {
    int randomNum = (rand() % 6) + 1;

    jclass cls = env->GetObjectClass(obj);
    jmethodID method =
        env->GetMethodID(cls, "results", "(Ljava/lang/String;)V");
    jstring response;

    if (guiNum == randomNum) {
        response = env->NewStringUTF("You win! Another go?");
        }
    else {
        response = env->NewStringUTF("You lose! Try again.");
        }

    env->CallVoidMethod(obj, method, response);
    }

JNIEXPORT void JNICALL Java_GuessGui_done(JNIEnv *, jobject) {
    done = true;
    }

