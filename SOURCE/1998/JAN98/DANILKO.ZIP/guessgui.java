import java.awt.*;

public class GuessGui extends Frame {

    Button bored;
    Button submit;
    Label instruction;
    Label    result;
    Choice    guess;

    public native void submitGuess(int number);
    public native void done();

    static {
        System.loadLibrary("guidll");
        }

    GuessGui() {
        setTitle("Guess");
        init();
        pack();
        setSize(200, 200);
        }

    public void showWindow() {
        show();
        }


    public void results(String s) {
        result.setText(s);
        repaint();
        }


    public void init() {
        bored = new Button("Bored!");
        submit = new Button("Guess");

        instruction = new Label("  Choose a number from 1 to 6");
        result = new Label("            Try your luck            ");
        guess = new Choice();
        guess.add("1"); guess.add("2"); guess.add("3");
        guess.add("4"); guess.add("5"); guess.add("6");

        setLayout(new FlowLayout());
        add(instruction);
        add(guess);
        add(result);
        add(submit);
        add(bored);

        setBackground(Color.orange);

        validate();
        }

    /* This is the JDK 1.0 method for handling events */
    public boolean handleEvent(Event event) {
        if (event.id == Event.ACTION_EVENT) {
            if (event.target == submit) {
                submitGuess(guess.getSelectedIndex()+1);
                }
            else if (event.target == bored) {
                done();
                }
            }

        return super.handleEvent(event);
        }

    }
