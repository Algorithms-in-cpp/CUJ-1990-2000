   /*** file sprivate2.h ***/
#define STACKFILE "stack.xxx"
#define TEMPFILE  "temp.xxx"
#define EMPTY     "empty"
#define L         100

int     priv_initialize_stack();
int     priv_is_empty();
int     priv_plunge();
element priv_pop();
int     priv_push(element);
