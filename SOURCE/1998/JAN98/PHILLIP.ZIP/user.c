   /*** file user.c ***/

#include "spublic.h"

void a_user_function()
{
 element this_data;
 int     status = -1;

 status = initialize_stack();
 status = push(33);
 status = push(66);
 status = push(99);
 status = plunge();

 if(is_empty() == 0){
  this_data = pop();
  printf("\nPopped %d", 
         this_data);
 }
}  /* ends a_user_function */
