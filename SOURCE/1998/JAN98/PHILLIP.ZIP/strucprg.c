#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

typedef int element;

struct stack_struct{
   element              data;
   struct stack_struct *next;

void   a_user_function();
struct stack_struct * initialize_stack();
int    is_empty(struct stack_struct *);
int    plunge(struct stack_struct *);
struct stack_struct * pop(
       struct stack_struct *, 
       element *);
int    push(struct stack_struct *, 
            element);
....

void a_user_function()
{
 element new_data;
 int     status;
 struct  stack_struct *top, *temp;

 top = initialize_stack();
 push(top, 33);
 push(top, 66);
 push(top, 99);
 status = plunge(top);

 if(is_empty(top) == 0){
    top = pop(top, &new_data);
    status = plunge(top);
 }
}  /* ends a_user_function */

....

struct stack_struct * pop(
   struct stack_struct *top, 
   element *result)
{
 struct  stack_struct *temp;

 temp    = top;
 *result = top->data;
 top     = top->next;

 free(temp);
 return(top);
}  /* ends pop */

....

int push(struct stack_struct *top, 
         element new_data)
{
 int    result = 1;
 struct stack_struct *new_one;

 new_one = (struct stack_struct *) 
  calloc(1, sizeof(struct stack_struct));
  
 new_one->data = top->data;
 top->data     = new_data;
 new_one->next = top->next;
 top->next     = new_one;
 return(result);
}  /* ends push */
