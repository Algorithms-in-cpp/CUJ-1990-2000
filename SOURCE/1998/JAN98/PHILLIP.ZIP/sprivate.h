   /*** file sprivate.h ***/
struct stack_struct{
   element              data;
   struct stack_struct *next;
};

static struct stack_struct *top;

struct  stack_struct *priv_initialize_stack();
int     priv_is_empty();
int     priv_plunge();
element priv_pop();
int     priv_push(element);
