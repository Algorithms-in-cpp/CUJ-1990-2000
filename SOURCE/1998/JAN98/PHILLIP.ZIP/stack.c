   /*** file stack.c ***/

#include "spublic.h"
#include "sprivate.h"

int  push(element the_data)
{
   int status = -1;
   status = priv_push(the_data);
   return(status);
}  /* ends push */



int priv_push(element new_data)
{
 int    result = 1;
 struct stack_struct *new_one;

 new_one = (struct stack_struct *) 
  calloc(1, sizeof(struct stack_struct));
  
 new_one->data = top->data;
 top->data     = new_data;
 new_one->next = top->next;
 top->next     = new_one;
 return(result);
}  /* ends priv_push */


element pop()
{
   element result = -1;
   result = priv_pop();
   return(result);
}  /* ends pop */

element priv_pop()
{
   element result;
   struct  stack_struct *temp;

   temp    = top;
   result  = top->data;
   top     = top->next;
   free(temp);
   return(result);
}  /* ends priv_pop */


