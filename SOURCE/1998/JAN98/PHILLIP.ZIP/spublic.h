   /*** file spublic.h ***/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

typedef int element;

void a_user_function();
int  push(element);
element pop();
int is_empty();
int plunge();
int initialize_stack();
