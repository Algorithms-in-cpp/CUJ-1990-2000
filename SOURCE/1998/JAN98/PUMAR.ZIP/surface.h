//...................................................................
// Surface.h
//
// Surface class for rendering irregular surfaces using lambert 
// shading. Class contains surface dimensions (m_Nx, m_Ny) 
// (assumed regularly spaced), intensity scale factor (m_Smax), 
// elevation histogram number (m_Nz), and pointer to memory holding 
// the elevation histogram, elevations, and bitmap of the rendered 
// image. Member functions include constructor, destructor, read and 
// draw functions, and functions for lambert shading the surface. 
//
//...................................................................

#define _HUGE huge                 // For 16-bit windows
typedef unsigned short byte;       // For bitmap data type 
typedef short          data;       // For elevations; short for DTED
typedef short**       _HANDLE;     // For surface draw parameter
typedef short*        _POINTER;    // passing.

class CSurface {
      private: 
       byte _HUGE  *m_Image;       // LS image of surface for display
       double       m_Smax;        // Intensity Scale Factor
       double       m_GridSize;    // Elevation spacing
       long         m_Nx;          // X-Dimension Of Surface
       long         m_Ny;          // Y-Dimension Of Surface
       long         m_Nz;          // Elevation Histogram number
       long         m_Nb;          // Bitmap edge buffer
       data        *m_Hz;          // Elevation difference Histogram
       data _HUGE  *m_Elevations;  // Surface Elevations
      public:
       CSurface(void);             // constructor
      ~CSurface(void);             // destructor
virtual short surfaceRead(char*);  // read surface elevations
virtual short surfaceDraw(_HANDLE, // display surface
                          _POINTER,
                          _POINTER);       
      private:
short surfaceHistogram(void);      // compute elevation histogram                    
short surfaceFindSmax(void);       // compute intensity scale factor
short surfaceLSRender(void);       // lambert shade surface
               };
