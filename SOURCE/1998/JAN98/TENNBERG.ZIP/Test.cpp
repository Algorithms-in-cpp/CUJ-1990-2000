// File: test.cpp

#include <windows.h>
#include <stdio.h>
#include "ActiveQueue.h"
#include <string>

using namespace std;

#if _MSC_VER
// VC can only handle symbols up to 255 character, STL can easily
// produce symbols longer then that. So we turn this warning off.
#pragma warning(disable:4786)
#endif

class MyActiveQueue : public ActiveQueue<string>
{
protected:
	virtual bool HandleData(string &data);
};

bool MyActiveQueue :: HandleData(string &data)
{
	if (data == "end")
        return false;
    printf("%s\n",data.c_str());
	return true;
}

int main(void)
{
	char buffer[10];

	try
	{
		MyActiveQueue qt;

		for (int i = 0;i < 50;i++)
		{
			sprintf(buffer,"%d",i);
			qt.Add(string(buffer));
		}
		qt.Add(string("end"));
		WaitForSingleObject(qt,INFINITE);
	}
	catch (FailedToCreateThread&)
	{
		printf("Failed to create thread\n");
	}
	catch (FailedToCreateSemaphore&)
	{
		printf("Failed to instansiate MyQueueThread\n");
	}
	return 0;
}
