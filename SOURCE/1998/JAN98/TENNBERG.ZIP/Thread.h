// File: thread.h

#if !defined(__THREAD_H)
#define __THREAD_H

class Thread
{
public:
    Thread();
    virtual ~Thread();
    bool Create(DWORD dwParam = 0,DWORD dwCreationFlags = 0);
    operator HANDLE();

protected:
    HANDLE  hThread;
    DWORD   dwParam;
    virtual UINT ThreadFunction(DWORD) = 0;
#if __BORLANDC__
    DWORD dwThreadId;
    friend void ThreadFunction(LPVOID param);
#else
    UINT  dwThreadId;
    friend UINT _stdcall ThreadFunction(LPVOID param);
#endif
};

inline Thread :: operator HANDLE()
{
	return hThread;
}

#endif
