// File: thread.cpp

#define STRICT
#include <windows.h>
#include <windowsx.h>
#pragma hdrstop
#include <process.h>
#include "thread.h"

#if __BORLANDC__
#pragma warn -aus
void ThreadFunction(LPVOID param)
#else
UINT _stdcall ThreadFunction(LPVOID param)
#endif
{
	LONG retCode = 0;
	Thread *thread = static_cast<Thread *>(param);

	if (thread != 0)
	{
		retCode = thread->ThreadFunction(thread->dwParam);
		// _endthread(ex) will close the thread handle, so
		// at this stage we prevent our destructor from closing
		// it twice.
        thread->hThread = 0;
    }
#if !defined(__BORLANDC__)
	return retCode;
#endif
}

Thread :: Thread() : hThread(0)
{
}

Thread :: ~Thread()
{
	if (hThread != 0)
        CloseHandle(hThread);
}

bool Thread :: Create(DWORD dwParam,DWORD dwCreationFlags)
{
	Thread::dwParam = dwParam;
#if __BORLANDC__
    hThread = reinterpret_cast<HANDLE>(_beginthreadNT(::ThreadFunction,0,this,0,dwCreationFlags,&dwThreadId));
#else
	hThread = reinterpret_cast<HANDLE>(_beginthreadex(NULL,0,::ThreadFunction,this,dwCreationFlags,&dwThreadId));
#endif
	return (hThread != 0);
}


