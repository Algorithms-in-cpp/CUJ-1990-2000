# if !defined(JAVA_PERFECT_HASH_H)
# define JAVA_PERFECT_HASH_H
//
// Source Code End User License
//
// Digital Equipment Corporation is making the below source code available to
// End Users without charge and under the terms below.
//
// Grant:
//
// Digital Equipment Corporation grants, and End User accepts a non-exclusive,
// non-transferable, royalty-free, perpetual license to display, perform, and
// otherwise use the source code for non-commercial research.
//
// Disclaimer of Warranty:
//
// THE SOURCE CODE IS PROVIDED AS IS WITHOUT ANY WARRANTY, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
// PARTICULAR PURPOSE.  Digital Equipment Corporation makes no representation
// that the source code does not infringe third party patent, copyright,
// trademark or other proprietary rights.  Digital Equipment Corporation does
// not warrant that the source code is fit for any use or is error free.
//
// Limitation of Liability:
//
// As a condition of use, the End User agrees that Digital Equipment
// Corporation shall not be liable for any costs, damages, fees, or other
// liability, nor for any  direct, indirect, special, incidental, or
// consequential damages with respect to any claim by an End User or any third
// party on account or arising from use of the source code.

# define PERFECT_HASH(ch1, ch2, chn, len) (rww[ch1^ch2]+rww[chn]+len-2)
# define RW_LENGTHS \
      4,  4,  4,  4,  6,  7,  5,  3,  5,  4,  6,  6,  9,  9,  4,  9,  5, 10,\
      4,  4,  5,  6,  6,  5,  4,  8,  2,  5,  5,  3,  2,  8,  5,  4,  6,  8,\
      3,  7,  7, 10,  3,  7,  7,  4, 12,  5,  5,  6,  5,  7,  6
# define RW_TEXTS\
    "long",\
    "goto",\
    "case",\
    "cast",\
    "native",\
    "private",\
    "class",\
    "int",\
    "false",\
    "true",\
    "double",\
    "import",\
    "interface",\
    "protected",\
    "char",\
    "transient",\
    "super",\
    "implements",\
    "byte",\
    "this",\
    "short",\
    "throws",\
    "static",\
    "const",\
    "else",\
    "continue",\
    "if",\
    "catch",\
    "final",\
    "for",\
    "do",\
    "volatile",\
    "float",\
    "void",\
    "switch",\
    "abstract",\
    "new",\
    "finally",\
    "default",\
    "instanceof",\
    "try",\
    "boolean",\
    "extends",\
    "null",\
    "synchronized",\
    "while",\
    "throw",\
    "public",\
    "break",\
    "package",\
    "return"
# define RW_CODES\
    LONG,\
    GOTO,\
    CASE,\
    CAST,\
    NATIVE,\
    PRIVATE,\
    CLASS,\
    INT,\
    FALSE_,\
    TRUE_,\
    DOUBLE,\
    IMPORT,\
    INTERFACE,\
    PROTECTED,\
    CHAR,\
    TRANSIENT,\
    SUPER,\
    IMPLEMENTS,\
    BYTE,\
    THIS,\
    SHORT,\
    THROWS,\
    STATIC,\
    CONST,\
    ELSE,\
    CONTINUE,\
    IF,\
    CATCH,\
    FINAL,\
    FOR,\
    DO,\
    VOLATILE,\
    FLOAT,\
    VOID,\
    SWITCH,\
    ABSTRACT,\
    NEW,\
    FINALLY,\
    DEFAULT,\
    INSTANCEOF,\
    TRY,\
    BOOLEAN,\
    EXTENDS,\
    NULL_,\
    SYNCHRONIZED,\
    WHILE,\
    THROW,\
    PUBLIC,\
    BREAK,\
    PACKAGE,\
    RETURN
# define RW_WEIGHTS \
    -999,  32,   0,  28,   6,  30,   7,   5, -25,  22,  28,   6,  19,  36,\
    -999,   0,  45,  44,-999,-999,-999,-999,-999,  46,-999,  25,-999,  16,\
      14,  34,-999,  42,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,\
    -999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,\
    -999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,\
    -999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,\
    -999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,-999,\
    -999,  13,   6,   0,  26, -30,  24,-999,-999,   0,  25,-999,   0,  24,\
    -999,-999,   6,   3,   1,-999,-999,  29,-999,  32,-999,-999,-999,-999,\
    -999,
    
# endif                         // JAVA_PERFECT_HASH_H
