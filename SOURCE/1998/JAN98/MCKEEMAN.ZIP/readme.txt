FILE:     READ.ME
PURPOSE:  get around JavaLex distribution

Unpack the distribution as directed with the Bourne shell.
If you are on Unix, make tests.  It will fail because my bevy
of Java test files in subdirectory java are not distributed.
That's OK.  Make up your own.  Then try again.

If you cannot depend on a unix-style make, you will have to
to the testing by hand.   Compile -c javalex.cpp and javascan.cpp.
That should get you useful .o files.  Then try each of the compile
and run steps in the makefile.  Each is a unit test of some kind.


