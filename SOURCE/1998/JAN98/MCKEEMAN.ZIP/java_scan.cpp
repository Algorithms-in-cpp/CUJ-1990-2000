// FILE:     java_scan.cpp
// PURPOSE:  "pull" scanner based on "push" lexer
// METHOD:   The lexer reports lexemes one at a time.  This scanner saves
//           the information needed by a parser in two arrays, one for the
//           token code and one for the token text.
// MODS:     mckeeman@digital -- 97.06.07 -- original
//
// Source Code End User License
//
// Digital Equipment Corporation is making the below source code available to
// End Users without charge and under the terms below.
//
// Grant:
//
// Digital Equipment Corporation grants, and End User accepts a non-exclusive,
// non-transferable, royalty-free, perpetual license to display, perform, and
// otherwise use the source code for non-commercial research.
//
// Disclaimer of Warranty:
//
// THE SOURCE CODE IS PROVIDED AS IS WITHOUT ANY WARRANTY, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
// PARTICULAR PURPOSE.  Digital Equipment Corporation makes no representation
// that the source code does not infringe third party patent, copyright,
// trademark or other proprietary rights.  Digital Equipment Corporation does
// not warrant that the source code is fit for any use or is error free.
//
// Limitation of Liability:
//
// As a condition of use, the End User agrees that Digital Equipment
// Corporation shall not be liable for any costs, damages, fees, or other
// liability, nor for any  direct, indirect, special, incidental, or
// consequential damages with respect to any claim by an End User or any third
// party on account or arising from use of the source code.

extern "C" {
# include <limits.h>
# include <stdlib.h>
# include <string.h>
# include <ctype.h>
}
# include <iostream.h>

# include "java_scan.h"

# define SIZE(a) (sizeof(a)/sizeof(a[0]))

# if !(defined SCAN_TRACE)                        // turn trace off
#     define scan_trace(msg)
#     define token_trace(slot)
# else 
#     define scan_trace(msg) cout << msg
#     define token_trace(slot) (                                \
        cout << "length=" << texts[slot].len                    \
             << ", code=" << codes[slot] << ", txt=",           \
        cout.write(texts[slot].inSrc, texts[slot].len),         \
        cout << "\n")
# endif


void JavaScan::
ctor(int len) {                                   // common ctor code
    nextavail    = 0;                             // start at beginning
    tokens_alloc = len/2;                         // generous allocation
    codes        = new int[tokens_alloc];
    texts        = new JavaText[tokens_alloc];
    lex();                                        // get the tokens
    cleanup();                                    // exact allocations
}

JavaScan::
JavaScan(char *srcText) : JavaLex(srcText) {
    ctor(strlen(srcText));                        // set up internal state
}

JavaScan::
JavaScan(char *srcText, int srcLength) : JavaLex(srcText, srcLength) {
    ctor(srcLength);                              // set up internal state
}

void JavaScan::
token(int code, JavaText txt, JavaLocator loc) {  // implement JavaLex method
    if (nextavail >= tokens_alloc) {
        resize(tokens_alloc*2);
    }
    texts[nextavail] = txt;                       // save texts
    codes[nextavail] = code;                      // save codes
    token_trace(nextavail);
    nextavail++;
}

void JavaScan::
error(int code, JavaText txt, JavaLocator loc) {  // implement JavaLex method
    token(code, txt, loc);                        // save error tokens
}

JavaScan::
~JavaScan() {
    delete[] texts;
    delete[] codes;
}

void JavaScan::
resize(int newsize) {
    int *tmp1 = new int[newsize];                 // exact storage
    memcpy((void *)tmp1, (void *)codes, nextavail*sizeof(int));
    delete[] codes;                               // free generous buffer
    codes = tmp1;                                 // ready to go

    JavaText *tmp2 = new JavaText[newsize];       // exact storage
    memcpy((void *)tmp2, (void *)texts, newsize*sizeof(JavaText));
    delete[] texts;                               // free wasted space
    texts = tmp2;                                 // ready to go
}

void JavaScan::
cleanup() {                                       // after lex pass
    resize(nextavail);
    tokens_alloc = nextavail;
    nextavail = 0;
}

JavaLocator JavaScan::
getLocator() {                                    // locator of current token
    char *t = texts[nextavail].inSrc;
    JavaLocator j = {line(t), col(t)};
    return j;
}

void JavaScan::
dump() {
    cout << "begin scan dump: tokens_alloc=" << tokens_alloc 
         << " nextavail=" << nextavail << "\n";

    for (int i=0; i<tokens_alloc; i++) {
        cout << "dump: " << i << ": code " << codes[i] << " ";
        cout.write(texts[i].inSrc, texts[i].len);
    }
    cout << "end scan dump\n";
}

//                       U N I T    T E S T I N G

# if defined SCAN_SMOKE_TEST

# include "java_tokens.h"

int
main(int argc, char **argv) {
    cerr << "JavaScan: begin standalone smoke test\n";
    char *src = "class Test extends Object {\n}\n";
    
    JavaScan scanned(src);                        // scan object
    cout << "JavaScan: scanning is finished, report results\n";

    cout << "JavaScan: tokens in order\n";
    for (int i=0; i<=scanned.last(); i++) {
        int s = scanned.getCode();
        JavaText t = scanned.getText();
        cout << "code = " << s << " spelling=";
        if (s == EOF_TOKEN) {
            cout << "eof";
        } else {
            cout.write(t.inSrc, t.len);
        }
        cout << "\n";
        scanned.step();                           // move on
    }
    cout << "JavaScan: first & last tokens\n";
    scanned.goTo(0);
    cout.write(scanned.getText().inSrc, scanned.getText().len);
    scanned.goTo(scanned.last()-1);               // before eof
    cout << " ";
    cout.write(scanned.getText().inSrc, scanned.getText().len);
    cout << "\n";
    
    cerr << "JavaScan: end   standalone smoke test\n";
    return 0;                                     // make os happy
}


# elif defined SCAN_UNIT_TEST
# include <fstream.h>
# include "java_tokens.h"
# define TEST_LIM 30000
int
main(int argc, char **argv) {
    cerr << "JavaLex: begin scan unit test\n";
    char k, src[TEST_LIM];                        // for source code
    int testno, j;

    for (testno=1; testno<argc; testno++) {
        char *fn = argv[testno];
        cout << "JavaScan: " << testno << " scanning file " << fn << "\n";        
        ifstream java(fn);
        j=0;
        while (java.get(k)) {
            src[j++] = k;                         // place the input char
            if (j >= TEST_LIM) break;
        }
        java.close();
        JavaScan scanned(src, j);                 // lex it

        for (;;) {
            int s      = scanned.getCode();
            JavaText t = scanned.getText();
            cout << "code =" << s
                 << ", spelling=";
            cout.write(t.inSrc, t.len); 
            cout << "\n";
            if (s == EOF_TOKEN) break;
            scanned.step();                       // move on
        }
    }
    cerr << "JavaScan: end   scan unit test\n";
    return 0;                                     // make os happy
}

# endif
