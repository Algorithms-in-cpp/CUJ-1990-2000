// FILE:    java_tokens.h
// PURPOSE: define unique codes for tokens
//
// Source Code End User License
//
// Digital Equipment Corporation is making the below source code available to
// End Users without charge and under the terms below.
//
// Grant:
//
// Digital Equipment Corporation grants, and End User accepts a non-exclusive,
// non-transferable, royalty-free, perpetual license to display, perform, and
// otherwise use the source code for non-commercial research.
//
// Disclaimer of Warranty:
//
// THE SOURCE CODE IS PROVIDED AS IS WITHOUT ANY WARRANTY, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
// PARTICULAR PURPOSE.  Digital Equipment Corporation makes no representation
// that the source code does not infringe third party patent, copyright,
// trademark or other proprietary rights.  Digital Equipment Corporation does
// not warrant that the source code is fit for any use or is error free.
//
// Limitation of Liability:
//
// As a condition of use, the End User agrees that Digital Equipment
// Corporation shall not be liable for any costs, damages, fees, or other
// liability, nor for any  direct, indirect, special, incidental, or
// consequential damages with respect to any claim by an End User or any third
// party on account or arising from use of the source code.


enum Tokens{
    EOF_TOKEN   = 0,                              // end of source text

    ERROR_CHAR_1,                                 // lexer-discovered errors
    ERROR_CHAR_2,
    ERROR_STRING_1,
    ERROR_STRING_2,
    ERROR_UTF8,                                   // not allowed in Java
    ERROR_C_COMMENT,                              // unterminated comments
    ERROR_DOC_COMMENT,
    ERROR_CXX_COMMENT,
        
    IDENTIFIER,                                   // fat tokens
    INTEGER_LITERAL,
    FLOATINGPOINT_LITERAL,
    STRING_LITERAL,
    CHARACTER_LITERAL,
    
    C_COMMENT,                                    // whitespace
    DOC_COMMENT,
    CXX_COMMENT,
    WHITESPACE,

    RW_CODES,                                     // reserved words (macro)
    
    ADD,                                          // +
    ADDADD,                                       // ++
    ADDEQ,                                        // +=
    AND,                                          // &
    ANDAND,                                       // &&
    ANDEQ,                                        // &=
    COLON,                                        // :
    COMMA,                                        // ,
    DIV,                                          // /
    DIVEQ,                                        // /=
    DOT,                                          // .
    EQ,                                           // =
    EQEQ,                                         // ==
    GT,                                           // >
    GTEQ,                                         // >=
    GTGT,                                         // >>
    GTGTEQ,                                       // >>=
    GTGTGT,                                       // >>>
    GTGTGTEQ,                                     // >>>=
    HAT,                                          // ^
    HATEQ,                                        // ^=
    LCB,                                          // {
    LRB,                                          // (
    LSB,                                          // [
    LT,                                           // <
    LTEQ,                                         // <=
    LTLT,                                         // <<
    LTLTEQ,                                       // <<=
    MOD,                                          // %
    MODEQ,                                        // &=
    MUL,                                          // *
    MULEQ,                                        // *=
    NOT,                                          // !
    NOTEQ,                                        // !=
    OR,                                           // |
    OREQ,                                         // |=
    OROR,                                         // ||
    QMARK,                                        // ?
    RCB,                                          // }
    RRB,                                          // )
    RSB,                                          // ]
    SEMI,                                         // ;
    SUB,                                          // -
    SUBEQ,                                        // -=
    SUBSUB,                                       // --
    TILDE                                         // ~
};
# endif     // JAVA_TOKENS_H
