// FILE:     java_scan.h
// PURPOSE:  interface to java source code scanner
// MODS:     mckeeman@digital -- 97.06.06 -- original
//           who@where -- yy.mm.dd -- what
// METHOD:   JavaLex calls methods token, white, error and error_msg
//           while iterating over the entire source text.  Method token
//           implemented in JavaScan queues up the tokens in internal arrays.
//           The public token navigation methods give the token consumer
//           random access to the stored tokens.  Lookahead is implemented
//           by the user via a sequence step(); c = getCode(); step(-1);
//           See file java-lex.h for types JavaText and JavaLocator.
//
// Source Code End User License
//
// Digital Equipment Corporation is making the below source code available to
// End Users without charge and under the terms below.
//
// Grant:
//
// Digital Equipment Corporation grants, and End User accepts a non-exclusive,
// non-transferable, royalty-free, perpetual license to display, perform, and
// otherwise use the source code for non-commercial research.
//
// Disclaimer of Warranty:
//
// THE SOURCE CODE IS PROVIDED AS IS WITHOUT ANY WARRANTY, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
// PARTICULAR PURPOSE.  Digital Equipment Corporation makes no representation
// that the source code does not infringe third party patent, copyright,
// trademark or other proprietary rights.  Digital Equipment Corporation does
// not warrant that the source code is fit for any use or is error free.
//
// Limitation of Liability:
//
// As a condition of use, the End User agrees that Digital Equipment
// Corporation shall not be liable for any costs, damages, fees, or other
// liability, nor for any  direct, indirect, special, incidental, or
// consequential damages with respect to any claim by an End User or any third
// party on account or arising from use of the source code.

# include "java_lex.h"

class JavaScan : protected JavaLex {               // JavaScan

public:
    // the public interface

    JavaScan(char *srcText, int srcLength);        // ctor
    JavaScan(char *srcText);                       // ctor for asciiz
    ~JavaScan();                                   // dtor
    
    void step() {nextavail++;}                     // move to next token
    void step(int n) {nextavail+=n;}               // move +- n tokens
    void goTo(int n) {nextavail=n;}                // move to token n
    int last() {return tokens_alloc-1;}            // last token position
    int getPosit() {return nextavail;}             // current token position
    
    int getCode() {return codes[nextavail];}       // code of current token
    JavaText getText() {return texts[nextavail];}  // text of current token
    JavaLocator getLocator();                      // locator of current token
    
private:
    // lex output functions (implementation promise)
    void token(int code, JavaText txt, JavaLocator where); 
    void white(int code, JavaText txt, JavaLocator where){} 
    void error(int code, JavaText txt, JavaLocator where); 
    void error_msg(char *msg){}                    // error message

    JavaScan(const JavaLex &);                     // forbid copy
    void operator = (const JavaScan &);            // forbid assign

    // scanner state variables and local methods
    int nextavail;                                 // where to put token
    int tokens_alloc;                              // end of storage
    int *codes;                                    // token codes
    JavaText *texts;                               // token texts
    void ctor(int len);                            // common ctor code
    void resize(int newlen);                       // fix generous first guess
    void cleanup();                                // after lexing
    void dump();                                   // all the tokens
};

#endif    // JAVA_SCAN_H
