// FILE:    java_unicode.h
// PURPOSE: implement UTF8
// MODS:    mckeeman@zko.dec.com -- 96.01.29 -- original
//
// Source Code End User License
//
// Digital Equipment Corporation is making the below source code available to
// End Users without charge and under the terms below.
//
// Grant:
//
// Digital Equipment Corporation grants, and End User accepts a non-exclusive,
// non-transferable, royalty-free, perpetual license to display, perform, and
// otherwise use the source code for non-commercial research.
//
// Disclaimer of Warranty:
//
// THE SOURCE CODE IS PROVIDED AS IS WITHOUT ANY WARRANTY, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
// PARTICULAR PURPOSE.  Digital Equipment Corporation makes no representation
// that the source code does not infringe third party patent, copyright,
// trademark or other proprietary rights.  Digital Equipment Corporation does
// not warrant that the source code is fit for any use or is error free.
//
// Limitation of Liability:
//
// As a condition of use, the End User agrees that Digital Equipment
// Corporation shall not be liable for any costs, damages, fees, or other
// liability, nor for any  direct, indirect, special, incidental, or
// consequential damages with respect to any claim by an End User or any third
// party on account or arising from use of the source code.


// 0xxxxxxx ascii
// 10000000 0x80
// 11000000 0xC0
// 11100000 0xE0
// 11110000 0xF0

// detect 1,2 and 3 byte UTF8 encodings
# define IS_UTF8_1(xx) (!((xx)&0x80))
# define IS_UTF8_n(xx) (((xx)&0xC0)==0x80)
# define IS_UTF8_2(xx) (((xx)&0xE0)==0xC0)
# define IS_UTF8_3(xx) (((xx)&0xF0)==0xE0)
# define UTF8_LENGTH(xxxx) ((xxxx)<0x80 ? 1 : (xxxx)<0x800 ? 2 : 3)

// UTF8 encodings for xxxx values
# define UTF8_1of1(xxxx) (xxxx)
# define UTF8_1of2(xxxx) (0xC0|(xxxx)>>6)
# define UTF8_2of2(xxxx) (0x80|(xxxx)&0x3F)
# define UTF8_1of3(xxxx) (0xE0|(xxxx)>>12)
# define UTF8_2of3(xxxx) (0x80|(xxxx)>>6&0x3F)
# define UTF8_3of3(xxxx) (0x80|(xxxx)&0x3F)

// convert 2 and 3 byte UTF8 to 16 bit int
# define UNICODE_2(xx1, xx2) (((xx1&0x1F)<<6) | xx2&0x3F)
# define UNICODE_3(xx1, xx2, xx3) (((xx1&0xF)<<12) | (xx2&0x3F)<<6 | xx3&0x3F)

// ASCII tests
# define IS_ASCII(xxxx) (0<=(xxxx) && (xxxx)<0x80)

# define IS_ASCII_DIGIT(xx)                           \
    ( '0' <= (xx) && (xx) <= '9' )
# define IS_ASCII_LETTER(xx)                          \
    (  'a' <= (xx) && (xx) <= 'z'                     \
    || 'A' <= (xx) && (xx) <= 'Z'                     \
    )
# define IS_ASCII_WHITE(xx)                           \
    (  (xx) == ' '                                    \
    || (xx) == '\t'                                   \
    || (xx) == '\n'                                   \
    || (xx) == '\r'                                   \
    || (xx) == '\f'                                   \
    )
// Unicode tests
# define IS_UNICODE_DIGIT(xxxx) (                     \
        (xxxx) <= 0xFF19                              \
        ? (xxxx) <= 0x0B6F                            \
          ? (xxxx) <= 0x09EF                          \
            ? (xxxx) <= 0x06F9                        \
              ? (xxxx) <= 0x0669                      \
                ? 0x0660 <= (xxxx)                    \
                : 0X06F0 <= (xxxx)                    \
              : (xxxx) <= 0x096F                      \
                ? 0x0966 <= (xxxx)                    \
                : 0x09E6 <= (xxxx)                    \
            : (xxxx) <= 0x0AEF                        \
              ? (xxxx) <= 0x0A6F                      \
                ? 0x0A66 <= (xxxx)                    \
                : 0x0AE6 <= (xxxx)                    \
              : 0x0B66 <= (xxxx)                      \
          : (xxxx) <= 0x0D6F                          \
            ? (xxxx) <= 0x0C6F                        \
              ? (xxxx) <= 0x0BEF                      \
                ? 0x0BE7 <= (xxxx)                    \
                : 0x0C66 <= (xxxx)                    \
              : (xxxx) <= 0xCEF                       \
                ? 0x0CE6 <= (xxxx)                    \
                : 0x0D66 <= (xxxx)                    \
            : (xxxx) <= 0x0ED9                        \
              ? (xxxx) <= 0x0E59                      \
                ? 0x0E50 <= (xxxx)                    \
                : 0x0ED0 <= (xxxx)                    \
              : 0x0FF10 <= (xxxx)                     \
        : 0                                           \
    )
    
# define IS_UNICODE_LETTER_OR_DIGIT(xxxx)             \
    (                                                 \
    (xxxx) <= 0xFFDC                                  \
    ? (xxxx) <= 0x0BB9                                \
      ? (xxxx) <= 0x09B9                              \
        ? (xxxx) <= 0x04F5                            \
          ? (xxxx) <= 0x03CE                          \
            ? (xxxx) <= 0x0361                        \
              ? (xxxx) <= 0x02A8                      \
                ? (xxxx) <= 0x01F5                    \
                  ? (xxxx) <= 0x00F6                  \
                    ? (xxxx) <= 0x00D6                \
                      ? 0x00C0 <= (xxxx)              \
                      : 0x00D8 <= (xxxx)              \
                    : 0x00F8 <= (xxxx)                \
                  : (xxxx) <= 0x0217                  \
                    ? 0x01FA <= (xxxx)                \
                    : 0x0250 <= (xxxx)                \
                : (xxxx) <= 0x02E9                    \
                  ? (xxxx) <= 0x02DE                  \
                    ? 0x02B0 <= (xxxx)                \
                    : 0x02E0 <= (xxxx)                \
                  : (xxxx) <= 0x0345                  \
                    ? 0x0300 <= (xxxx)                \
                    : 0x0360 <= (xxxx)                \
              : (xxxx) <= 0x038A                      \
                ? (xxxx) <= 0x037A                    \
                  ? (xxxx) <= 0x0375                  \
                    ? 0x0374 <= (xxxx)                \
                    : 0x037A <= (xxxx)                \
                  : (xxxx) <= 0x037E                  \
                    ? 0x037E <= (xxxx)                \
                    : 0x0384 <= (xxxx)                \
                : (xxxx) <= 0x038E                    \
                  ? (xxxx) <= 0x038C                  \
                    ? 0x038C <= (xxxx)                \
                    : 0x038E <= (xxxx)                \
                  : (xxxx) <= 0x03A1                  \
                    ? 0x038F <= (xxxx)                \
                    : 0x03A3 <= (xxxx)                \
            : (xxxx) <= 0x040C                        \
              ? (xxxx) <= 0x03DC                      \
                ? (xxxx) <= 0x03E2                    \
                  ? (xxxx) <= 0x03D6                  \
                    ? 0x03D0 <= (xxxx)                \
                    : 0x03DA <= (xxxx)                \
                  : (xxxx) <= 0x03DA                  \
                    ? 0x03DA <= (xxxx)                \
                    : 0x03DC <= (xxxx)                \
                : (xxxx) <= 0x03E0                    \
                  ? (xxxx) <= 0x03DE                  \
                    ? 0x03DE <= (xxxx)                \
                    : 0x03E0 <= (xxxx)                \
                  : (xxxx) <= 0x03F3                  \
                    ? 0x03E2 <= (xxxx)                \
                    : 0x0401 <= (xxxx)                \
              : (xxxx) <= 0x04C4                      \
                ? (xxxx) <= 0x045C                    \
                  ? (xxxx) <= 0x044F                  \
                    ? 0x040E <= (xxxx)                \
                    : 0x0451 <= (xxxx)                \
                  : (xxxx) <= 0x0486                  \
                    ? 0x045E <= (xxxx)                \
                    : 0x0490 <= (xxxx)                \
                : (xxxx) <= 0x04CC                    \
                  ? (xxxx) <= 0x04C8                  \
                    ? 0x04C7 <= (xxxx)                \
                    : 0x04CB <= (xxxx)                \
                  : (xxxx) <= 0x04EB                  \
                    ? 0x04D0 <= (xxxx)                \
                    : 0x04EE <= (xxxx)                \
          : (xxxx) <= 0x06B7                          \
            ? (xxxx) <= 0x05F4                        \
              ? (xxxx) <= 0x0589                      \
                ? (xxxx) <= 0x055F                    \
                  ? (xxxx) <= 0x0556                  \
                    ? (xxxx) <= 0x04F9                \
                      ? 0x04F8 <= (xxxx)              \
                      : 0x0531 <= (xxxx)              \
                    : 0x0559 <= (xxxx)                \
                  : (xxxx) <= 0x0587                  \
                    ? 0x0561 <= (xxxx)                \
                    : 0x0589 <= (xxxx)                \
                : (xxxx) <= 0x05C3                    \
                  ? (xxxx) <= 0x05B9                  \
                    ? 0x05B0 <= (xxxx)                \
                    : 0x05BB <= (xxxx)                \
                  : (xxxx) <= 0x05EA                  \
                    ? 0x05D0 <= (xxxx)                \
                    : 0x05F0 <= (xxxx)                \
              : (xxxx) <= 0x0621                      \
                ? (xxxx) <= 0x061B                    \
                  ? (xxxx) <= 0x060C                  \
                    ? 0x060C <= (xxxx)                \
                    : 0x061B <= (xxxx)                \
                  : (xxxx) <= 0x061F                  \
                    ? 0x061F <= (xxxx)                \
                    : 0x0621 <= (xxxx)                \
                : (xxxx) <= 0x0652                    \
                  ? (xxxx) <= 0x063A                  \
                    ? 0x0622 <= (xxxx)                \
                    : 0x0640 <= (xxxx)                \
                  : (xxxx) <= 0x066D                  \
                    ? 0x0660 <= (xxxx)                \
                    : 0x0670 <= (xxxx)                \
            : (xxxx) <= 0x0954                        \
              ? (xxxx) <= 0x06F9                      \
                ? (xxxx) <= 0x06CE                    \
                  ? (xxxx) <= 0x06BE                  \
                    ? 0x06BA <= (xxxx)                \
                    : 0x06C0 <= (xxxx)                \
                  : (xxxx) <= 0x06ED                  \
                    ? 0x06D0 <= (xxxx)                \
                    : 0x06F0 <= (xxxx)                \
                : (xxxx) <= 0x0939                    \
                  ? (xxxx) <= 0x0903                  \
                    ? 0x0901 <= (xxxx)                \
                    : 0x0905 <= (xxxx)                \
                  : (xxxx) <= 0x094D                  \
                    ? 0x093C <= (xxxx)                \
                    : 0x0950 <= (xxxx)                \
              : (xxxx) <= 0x0990                      \
                ? (xxxx) <= 0x0983                    \
                  ? (xxxx) <= 0x0970                  \
                    ? 0x0958 <= (xxxx)                \
                    : 0x0981 <= (xxxx)                \
                  : (xxxx) <= 0x098C                  \
                    ? 0x0985 <= (xxxx)                \
                    : 0x098F <= (xxxx)                \
                : (xxxx) <= 0x09B0                    \
                  ? (xxxx) <= 0x09A8                  \
                    ? 0x0993 <= (xxxx)                \
                    : 0x09AA <= (xxxx)                \
                  : (xxxx) <= 0x09B2                  \
                    ? 0x09B2 <= (xxxx)                \
                    : 0x09B6 <= (xxxx)                \
        : (xxxx) <= 0x0AB3                            \
          ? (xxxx) <= 0x0A39                          \
            ? (xxxx) <= 0x09FA                        \
              ? (xxxx) <= 0x09CD                      \
                ? (xxxx) <= 0x09C4                    \
                  ? (xxxx) <= 0x09BE                  \
                    ? (xxxx) <= 0x09BC                \
                      ? 0x09BC <= (xxxx)              \
                      : 0x09BE <= (xxxx)              \
                    : 0x09BF <= (xxxx)                \
                  : (xxxx) <= 0x09C8                  \
                    ? 0x09C7 <= (xxxx)                \
                    : 0x09CB <= (xxxx)                \
                : (xxxx) <= 0x09DD                    \
                  ? (xxxx) <= 0x09D7                  \
                    ? 0x09D7 <= (xxxx)                \
                    : 0x09DC <= (xxxx)                \
                  : (xxxx) <= 0x09E3                  \
                    ? 0x09DF <= (xxxx)                \
                    : 0x09E6 <= (xxxx)                \
              : (xxxx) <= 0x0A28                      \
                ? (xxxx) <= 0x0A0A                    \
                  ? (xxxx) <= 0x0A02                  \
                    ? 0x0A02 <= (xxxx)                \
                    : 0x0A05 <= (xxxx)                \
                  : (xxxx) <= 0x0A10                  \
                    ? 0x0A0F <= (xxxx)                \
                    : 0x0A13 <= (xxxx)                \
                : (xxxx) <= 0x0A33                    \
                  ? (xxxx) <= 0x0A30                  \
                    ? 0x0A2A <= (xxxx)                \
                    : 0x0A32 <= (xxxx)                \
                  : (xxxx) <= 0x0A36                  \
                    ? 0x0A35 <= (xxxx)                \
                    : 0x0A38 <= (xxxx)                \
            : (xxxx) <= 0x0A74                        \
              ? (xxxx) <= 0x0A48                      \
                ? (xxxx) <= 0x0A3E                    \
                  ? (xxxx) <= 0x0A3C                  \
                    ? 0x0A3C <= (xxxx)                \
                    : 0x0A3E <= (xxxx)                \
                  : (xxxx) <= 0x0A42                  \
                    ? 0x0A3F <= (xxxx)                \
                    : 0x0A47 <= (xxxx)                \
                : (xxxx) <= 0x0A5C                    \
                  ? (xxxx) <= 0x0A4D                  \
                    ? 0x0A4B <= (xxxx)                \
                    : 0x0A59 <= (xxxx)                \
                  : (xxxx) <= 0x0A5E                  \
                    ? 0x0A5E <= (xxxx)                \
                    : 0x0A66 <= (xxxx)                \
              : (xxxx) <= 0x0A8F                      \
                ? (xxxx) <= 0x0A8B                    \
                  ? (xxxx) <= 0x0A83                  \
                    ? 0x0A81 <= (xxxx)                \
                    : 0x0A85 <= (xxxx)                \
                  : (xxxx) <= 0x0A8D                  \
                    ? 0x0A8D <= (xxxx)                \
                    : 0x0A8F <= (xxxx)                \
                : (xxxx) <= 0x0AA8                    \
                  ? (xxxx) <= 0x0A91                  \
                    ? 0x0A90 <= (xxxx)                \
                    : 0x0A93 <= (xxxx)                \
                  : (xxxx) <= 0x0AB0                  \
                    ? 0x0AAA <= (xxxx)                \
                    : 0x0AB2 <= (xxxx)                \
          : (xxxx) <= 0x0B4D                          \
            ? (xxxx) <= 0x0B0C                        \
              ? (xxxx) <= 0x0AD0                      \
                ? (xxxx) <= 0x0AC9                    \
                  ? (xxxx) <= 0x0AC5                  \
                    ? (xxxx) <= 0x0AB9                \
                      ? 0x0AB5 <= (xxxx)              \
                      : 0x0ABC <= (xxxx)              \
                    : 0x0AC7 <= (xxxx)                \
                  : (xxxx) <= 0x0ACD                  \
                    ? 0x0ACB <= (xxxx)                \
                    : 0x0AD0 <= (xxxx)                \
                : (xxxx) <= 0x0AEF                    \
                  ? (xxxx) <= 0x0AE0                  \
                    ? 0x0AE0 <= (xxxx)                \
                    : 0x0AE6 <= (xxxx)                \
                  : (xxxx) <= 0x0B03                  \
                    ? 0x0B01 <= (xxxx)                \
                    : 0x0B05 <= (xxxx)                \
              : (xxxx) <= 0x0B33                      \
                ? (xxxx) <= 0x0B28                    \
                  ? (xxxx) <= 0x0B10                  \
                    ? 0x0B0F <= (xxxx)                \
                    : 0x0B13 <= (xxxx)                \
                  : (xxxx) <= 0x0B30                  \
                    ? 0x0B2A <= (xxxx)                \
                    : 0x0B32 <= (xxxx)                \
                : (xxxx) <= 0x0B43                    \
                  ? (xxxx) <= 0x0B39                  \
                    ? 0x0B36 <= (xxxx)                \
                    : 0x0B3C <= (xxxx)                \
                  : (xxxx) <= 0x0B48                  \
                    ? 0x0B47 <= (xxxx)                \
                    : 0x0B4B <= (xxxx)                \
            : (xxxx) <= 0x0B95                        \
              ? (xxxx) <= 0x0B70                      \
                ? (xxxx) <= 0x0B5D                    \
                  ? (xxxx) <= 0x0B57                  \
                    ? 0x0B56 <= (xxxx)                \
                    : 0x0B5C <= (xxxx)                \
                  : (xxxx) <= 0x0B61                  \
                    ? 0x0B5F <= (xxxx)                \
                    : 0x0B66 <= (xxxx)                \
                : (xxxx) <= 0x0B8A                    \
                  ? (xxxx) <= 0x0B83                  \
                    ? 0x0B82 <= (xxxx)                \
                    : 0x0B85 <= (xxxx)                \
                  : (xxxx) <= 0x0B90                  \
                    ? 0x0B8E <= (xxxx)                \
                    : 0x0B92 <= (xxxx)                \
              : (xxxx) <= 0x0B9F                      \
                ? (xxxx) <= 0x0B9C                    \
                  ? (xxxx) <= 0x0B9A                  \
                    ? 0x0B99 <= (xxxx)                \
                    : 0x0B9C <= (xxxx)                \
                  : (xxxx) <= 0x0B9E                  \
                    ? 0x0B9E <= (xxxx)                \
                    : 0x0B9F <= (xxxx)                \
                : (xxxx) <= 0x0BAA                    \
                  ? (xxxx) <= 0x0BA4                  \
                    ? 0x0BA3 <= (xxxx)                \
                    : 0x0BA8 <= (xxxx)                \
                  : (xxxx) <= 0x0BB5                  \
                    ? 0x0BAE <= (xxxx)                \
                    : 0x0BB7 <= (xxxx)                \
      : (xxxx) <= 0x10FB                              \
        ? (xxxx) <= 0x0D0C                            \
          ? (xxxx) <= 0x0C6F                          \
            ? (xxxx) <= 0x0C28                        \
              ? (xxxx) <= 0x0BF2                      \
                ? (xxxx) <= 0x0BCD                    \
                  ? (xxxx) <= 0x0BC8                  \
                    ? (xxxx) <= 0x0BC2                \
                      ? 0x0BBE <= (xxxx)              \
                      : 0x0BC6 <= (xxxx)              \
                    : 0x0BCA <= (xxxx)                \
                  : (xxxx) <= 0x0BD7                  \
                    ? 0x0BD7 <= (xxxx)                \
                    : 0x0BE7 <= (xxxx)                \
                : (xxxx) <= 0x0C0C                    \
                  ? (xxxx) <= 0x0C03                  \
                    ? 0x0C01 <= (xxxx)                \
                    : 0x0C05 <= (xxxx)                \
                  : (xxxx) <= 0x0C10                  \
                    ? 0x0C0E <= (xxxx)                \
                    : 0x0C12 <= (xxxx)                \
              : (xxxx) <= 0x0C48                      \
                ? (xxxx) <= 0x0C39                    \
                  ? (xxxx) <= 0x0C33                  \
                    ? 0x0C2A <= (xxxx)                \
                    : 0x0C35 <= (xxxx)                \
                  : (xxxx) <= 0x0C44                  \
                    ? 0x0C3E <= (xxxx)                \
                    : 0x0C46 <= (xxxx)                \
                : (xxxx) <= 0x0C56                    \
                  ? (xxxx) <= 0x0C4D                  \
                    ? 0x0C4A <= (xxxx)                \
                    : 0x0C55 <= (xxxx)                \
                  : (xxxx) <= 0x0C61                  \
                    ? 0x0C60 <= (xxxx)                \
                    : 0x0C66 <= (xxxx)                \
            : (xxxx) <= 0x0CC8                        \
              ? (xxxx) <= 0x0CA8                      \
                ? (xxxx) <= 0x0C8C                    \
                  ? (xxxx) <= 0x0C83                  \
                    ? 0x0C82 <= (xxxx)                \
                    : 0x0C85 <= (xxxx)                \
                  : (xxxx) <= 0x0C90                  \
                    ? 0x0C8E <= (xxxx)                \
                    : 0x0C92 <= (xxxx)                \
                : (xxxx) <= 0x0CB9                    \
                  ? (xxxx) <= 0x0CB3                  \
                    ? 0x0CAA <= (xxxx)                \
                    : 0x0CB5 <= (xxxx)                \
                  : (xxxx) <= 0x0CC4                  \
                    ? 0x0CBE <= (xxxx)                \
                    : 0x0CC6 <= (xxxx)                \
              : (xxxx) <= 0x0CE0                      \
                ? (xxxx) <= 0x0CD6                    \
                  ? (xxxx) <= 0x0CCD                  \
                    ? 0x0CCA <= (xxxx)                \
                    : 0x0CD5 <= (xxxx)                \
                  : (xxxx) <= 0x0CDE                  \
                    ? 0x0CDE <= (xxxx)                \
                    : 0x0CE0 <= (xxxx)                \
                : (xxxx) <= 0x0CEF                    \
                  ? (xxxx) <= 0x0CE1                  \
                    ? 0x0CE1 <= (xxxx)                \
                    : 0x0CE6 <= (xxxx)                \
                  : (xxxx) <= 0x0D03                  \
                    ? 0x0D02 <= (xxxx)                \
                    : 0x0D05 <= (xxxx)                \
          : (xxxx) <= 0x0E97                          \
            ? (xxxx) <= 0x0D6F                        \
              ? (xxxx) <= 0x0D48                      \
                ? (xxxx) <= 0x0D39                    \
                  ? (xxxx) <= 0x0D28                  \
                    ? (xxxx) <= 0x0D10                \
                      ? 0x0D0E <= (xxxx)              \
                      : 0x0D12 <= (xxxx)              \
                    : 0x0D2A <= (xxxx)                \
                  : (xxxx) <= 0x0D43                  \
                    ? 0x0D3E <= (xxxx)                \
                    : 0x0D46 <= (xxxx)                \
                : (xxxx) <= 0x0D57                    \
                  ? (xxxx) <= 0x0D4D                  \
                    ? 0x0D4A <= (xxxx)                \
                    : 0x0D57 <= (xxxx)                \
                  : (xxxx) <= 0x0D61                  \
                    ? 0x0D60 <= (xxxx)                \
                    : 0x0D66 <= (xxxx)                \
              : (xxxx) <= 0x0E84                      \
                ? (xxxx) <= 0x0E5B                    \
                  ? (xxxx) <= 0x0E3A                  \
                    ? 0x0E01 <= (xxxx)                \
                    : 0x0E3F <= (xxxx)                \
                  : (xxxx) <= 0x0E82                  \
                    ? 0x0E81 <= (xxxx)                \
                    : 0x0E84 <= (xxxx)                \
                : (xxxx) <= 0x0E8A                    \
                  ? (xxxx) <= 0x0E88                  \
                    ? 0x0E87 <= (xxxx)                \
                    : 0x0E8A <= (xxxx)                \
                  : (xxxx) <= 0x0E8D                  \
                    ? 0x0E8D <= (xxxx)                \
                    : 0x0E94 <= (xxxx)                \
            : (xxxx) <= 0x0EC4                        \
              ? (xxxx) <= 0x0EA7                      \
                ? (xxxx) <= 0x0EA3                    \
                  ? (xxxx) <= 0x0E9F                  \
                    ? 0x0E99 <= (xxxx)                \
                    : 0x0EA1 <= (xxxx)                \
                  : (xxxx) <= 0x0EA5                  \
                    ? 0x0EA5 <= (xxxx)                \
                    : 0x0EA7 <= (xxxx)                \
                : (xxxx) <= 0x0EB9                    \
                  ? (xxxx) <= 0x0EAB                  \
                    ? 0x0EAA <= (xxxx)                \
                    : 0x0EAD <= (xxxx)                \
                  : (xxxx) <= 0x0EBD                  \
                    ? 0x0EBB <= (xxxx)                \
                    : 0x0EC0 <= (xxxx)                \
              : (xxxx) <= 0x0ED9                      \
                ? (xxxx) <= 0x0EC8                    \
                  ? (xxxx) <= 0x0EC6                  \
                    ? 0x0EC6 <= (xxxx)                \
                    : 0x0EC8 <= (xxxx)                \
                  : (xxxx) <= 0x0ECD                  \
                    ? 0x0EC9 <= (xxxx)                \
                    : 0x0ED0 <= (xxxx)                \
                : (xxxx) <= 0x10C5                    \
                  ? (xxxx) <= 0x0EDD                  \
                    ? 0x0EDC <= (xxxx)                \
                    : 0x10A0 <= (xxxx)                \
                  : (xxxx) <= 0x10F6                  \
                    ? 0x10D0 <= (xxxx)                \
                    : 0x10FB <= (xxxx)                \
        : (xxxx) <= 0x32FE                            \
          ? (xxxx) <= 0x1FD3                          \
            ? (xxxx) <= 0x1F4D                        \
              ? (xxxx) <= 0x1EF9                      \
                ? (xxxx) <= 0x11F9                    \
                  ? (xxxx) <= 0x11A2                  \
                    ? (xxxx) <= 0x1159                \
                      ? 0x1100 <= (xxxx)              \
                      : 0x115F <= (xxxx)              \
                    : 0x11A8 <= (xxxx)                \
                  : (xxxx) <= 0x1E9A                  \
                    ? 0x1E00 <= (xxxx)                \
                    : 0x1EA0 <= (xxxx)                \
                : (xxxx) <= 0x1F1D                    \
                  ? (xxxx) <= 0x1F15                  \
                    ? 0x1F00 <= (xxxx)                \
                    : 0x1F18 <= (xxxx)                \
                  : (xxxx) <= 0x1F45                  \
                    ? 0x1F20 <= (xxxx)                \
                    : 0x1F48 <= (xxxx)                \
              : (xxxx) <= 0x1F5D                      \
                ? (xxxx) <= 0x1F59                    \
                  ? (xxxx) <= 0x1F57                  \
                    ? 0x1F50 <= (xxxx)                \
                    : 0x1F59 <= (xxxx)                \
                  : (xxxx) <= 0x1F5B                  \
                    ? 0x1F5B <= (xxxx)                \
                    : 0x1F5D <= (xxxx)                \
                : (xxxx) <= 0x1FB4                    \
                  ? (xxxx) <= 0x1F7D                  \
                    ? 0x1F5F <= (xxxx)                \
                    : 0x1F80 <= (xxxx)                \
                  : (xxxx) <= 0x1FC4                  \
                    ? 0x1FB6 <= (xxxx)                \
                    : 0x1FC6 <= (xxxx)                \
            : (xxxx) <= 0x312C                        \
              ? (xxxx) <= 0x1FFE                      \
                ? (xxxx) <= 0x1FEF                    \
                  ? (xxxx) <= 0x1FDB                  \
                    ? 0x1FD6 <= (xxxx)                \
                    : 0x1FDD <= (xxxx)                \
                  : (xxxx) <= 0x1FF4                  \
                    ? 0x1FF2 <= (xxxx)                \
                    : 0x1FF6 <= (xxxx)                \
                : (xxxx) <= 0x309E                    \
                  ? (xxxx) <= 0x3094                  \
                    ? 0x3041 <= (xxxx)                \
                    : 0x3099 <= (xxxx)                \
                  : (xxxx) <= 0x30FE                  \
                    ? 0x30A1 <= (xxxx)                \
                    : 0x3105 <= (xxxx)                \
              : (xxxx) <= 0x3243                      \
                ? (xxxx) <= 0x319F                    \
                  ? (xxxx) <= 0x318E                  \
                    ? 0x3131 <= (xxxx)                \
                    : 0x3190 <= (xxxx)                \
                  : (xxxx) <= 0x321C                  \
                    ? 0x3200 <= (xxxx)                \
                    : 0x3220 <= (xxxx)                \
                : (xxxx) <= 0x32B0                    \
                  ? (xxxx) <= 0x327B                  \
                    ? 0x3260 <= (xxxx)                \
                    : 0x327F <= (xxxx)                \
                  : (xxxx) <= 0x32CB                  \
                    ? 0x32C0 <= (xxxx)                \
                    : 0x32D0 <= (xxxx)                \
          : (xxxx) <= 0xFBB1                          \
            ? (xxxx) <= 0xFB36                        \
              ? (xxxx) <= 0x9FA5                      \
                ? (xxxx) <= 0x33DD                    \
                  ? (xxxx) <= 0x3376                  \
                    ? 0x3300 <= (xxxx)                \
                    : 0x337B <= (xxxx)                \
                  : (xxxx) <= 0x33FE                  \
                    ? 0x33E0 <= (xxxx)                \
                    : 0x3400 <= (xxxx)                \
                : (xxxx) <= 0xFB06                    \
                  ? (xxxx) <= 0xFA2D                  \
                    ? 0xF900 <= (xxxx)                \
                    : 0xFB00 <= (xxxx)                \
                  : (xxxx) <= 0xFB17                  \
                    ? 0xFB13 <= (xxxx)                \
                    : 0xFB1E <= (xxxx)                \
              : (xxxx) <= 0xFB41                      \
                ? (xxxx) <= 0xFB3E                    \
                  ? (xxxx) <= 0xFB3C                  \
                    ? 0xFB38 <= (xxxx)                \
                    : 0xFB3E <= (xxxx)                \
                  : (xxxx) <= 0xFB40                  \
                    ? 0xFB40 <= (xxxx)                \
                    : 0xFB41 <= (xxxx)                \
                : (xxxx) <= 0xFB44                    \
                  ? (xxxx) <= 0xFB43                  \
                    ? 0xFB43 <= (xxxx)                \
                    : 0xFB44 <= (xxxx)                \
                  : (xxxx) <= 0xFB46                  \
                    ? 0xFB46 <= (xxxx)                \
                    : 0xFB47 <= (xxxx)                \
            : (xxxx) <= 0xFEFC                        \
              ? (xxxx) <= 0xFDFB                      \
                ? (xxxx) <= 0xFD8F                    \
                  ? (xxxx) <= 0xFD3F                  \
                    ? 0xFBD3 <= (xxxx)                \
                    : 0xFD50 <= (xxxx)                \
                  : (xxxx) <= 0xFDC7                  \
                    ? 0xFD92 <= (xxxx)                \
                    : 0xFDF0 <= (xxxx)                \
                : (xxxx) <= 0xFE74                    \
                  ? (xxxx) <= 0xFE72                  \
                    ? 0xFE70 <= (xxxx)                \
                    : 0xFE74 <= (xxxx)                \
                  : (xxxx) <= 0xFE76                  \
                    ? 0xFE76 <= (xxxx)                \
                    : 0xFE77 <= (xxxx)                \
              : (xxxx) <= 0xFFBE                      \
                ? (xxxx) <= 0xFF3A                    \
                  ? (xxxx) <= 0xFF19                  \
                    ? 0xFF10 <= (xxxx)                \
                    : 0xFF21 <= (xxxx)                \
                  : (xxxx) <= 0xFF5A                  \
                    ? 0xFF41 <= (xxxx)                \
                    : 0xFF66 <= (xxxx)                \
                : (xxxx) <= 0xFFCF                    \
                  ? (xxxx) <= 0xFFC7                  \
                    ? 0xFFC2 <= (xxxx)                \
                    : 0xFFCA <= (xxxx)                \
                  : (xxxx) <= 0xFFD7                  \
                    ? 0xFFD2 <= (xxxx)                \
                    : 0xFFDA <= (xxxx)                \
    : 0                                               \
    )
    
# define IS_UNICODE_LETTER(xxxx)                      \
     ( !IS_UNICODE_DIGIT(xxxx)                        \
     && IS_UNICODE_LETTER_OR_DIGIT(xxxx)              \
     )

# define IS_IGNORABLE(xxxx)                           \
     (   xxxx <= 0x0008 || xxxx == 0xFEFF             \
     || (0x000E <= xxxx && xxxx <= 0x001B)            \
     || (0x007F <= xxxx && xxxx <= 0x009F)            \
     || (0x200C <= xxxx && xxxx <= 0x200F)            \
     || (0x200A <= xxxx && xxxx <= 0x200E)            \
     || (0x206A <= xxxx && xxxx <= 0x206F)            \
     )

# define IS_DIGIT(xxxx)                               \
    (  IS_ASCII_DIGIT(xxxx)                           \
    )

# define IS_LETTER(xxxx)                              \
    (  IS_ASCII_LETTER(xxxx) || (xxxx > 0x7F && IS_UNICODE_LETTER(xxxx))        
                \
    )

# define HEX_VAL(xx)                                  \
    ( '0' <= (xx) && (xx) <= '9' ? (xx) - '0'         \
    : 'a' <= (xx) && (xx) <= 'f' ? (xx) - 'a' + 10    \
    :                              (xx) - 'A' + 10    \
    )

# define IS_HEX(xx)                                   \
    (  'a' <= (xx) && (xx) <= 'f'                     \
    || '0' <= (xx) && (xx) <= '9'                     \
    || 'A' <= (xx) && (xx) <= 'F'                     \
    )

# define TO_HEX(xx)                                   \
    0 <= (xx) && (xx) <= 9 ? (xx) + '0' : (xx) + 'A'

// convert the (xxxx) portion of Unicode escape \uxxxx to 16 bit value
# define UNICODE_ESCAPE(x0, x1, x2, x3)               \
      ( HEX_VAL(x0)<<12                               \
      | HEX_VAL(x1)<<8                                \
      | HEX_VAL(x2)<<4                                \
      | HEX_VAL(x3)                                   \
      )

# if defined UNICODE_UNIT_TEST

# include <iostream.h>
extern "C" {
# include <stdlib.h>
}

int dummy() {
    int ch;
    for (ch=0; ch<0x80; ch++) {
        if (!IS_UTF8_1(ch)) cout << "IS_UTF8_1(" << ch << ") wrong\n";
        if (IS_UTF8_2(ch)) cout << "IS_UTF8_2(" << ch << ") wrong\n";
        if (IS_UTF8_3(ch)) cout << "IS_UTF8_3(" << ch << ") wrong\n";
    }
    for (ch=0x80; ch<0xC0; ch++) {
        if (IS_UTF8_1(ch)) cout << "IS_UTF8_1(" << ch << ") wrong\n";
        if (IS_UTF8_2(ch)) cout << "IS_UTF8_2(" << ch << ") wrong\n";
        if (IS_UTF8_3(ch)) cout << "IS_UTF8_3(" << ch << ") wrong\n";
    }
    for (ch=0xC0; ch<0xD0; ch++) {
        if (IS_UTF8_1(ch)) cout << "IS_UTF8_1(" << ch << ") wrong\n";
        if (!IS_UTF8_2(ch)) cout << "IS_UTF8_2(" << ch << ") wrong\n";
        if (IS_UTF8_3(ch)) cout << "IS_UTF8_3(" << ch << ") wrong\n";
    }
    for (ch=0xD0; ch<0xF0; ch++) {
        if (IS_UTF8_1(ch)) cout << "IS_UTF8_1(" << ch << ") wrong\n";
        if (IS_UTF8_2(ch)) cout << "IS_UTF8_2(" << ch << ") wrong\n";
        if (!IS_UTF8_3(ch)) cout << "IS_UTF8_3(" << ch << ") wrong\n";
    }
    
    for (ch=0x0; ch<0x80; ch++) {
        if (UTF8_1of1(ch) != ch) cout << "UTF8_1of1(" << ch << ") wrong\n";
    }
    for (ch=0x80; ch<0x800; ch++) {
        if (UNICODE_2(UTF8_1of2(ch), UTF8_2of2(ch)) != ch) {
            cout << hex << "UNICODE_2(" << ch << ") wrong\n";
        }
    }
    for (ch=0x800; ch<0x10000; ch++) {
        if (UNICODE_3(UTF8_1of3(ch), UTF8_2of3(ch), UTF8_3of3(ch)) != ch) {
            cout << hex << "UNICODE_3(" << ch << ") wrong\n";
        }
    }
    
    int dig[4];
    for (int tno=0; tno<1000; tno++) {
         long res = 0;
         for (int d=0; d<4; d++) {
             dig[d] = rand()*16/RAND_MAX;
             res <<= dig[d];
         }
         if (UNICODE_ESCAPE(
             HEX_VAL(TO_HEX(dig[0])),
             HEX_VAL(TO_HEX(dig[1])),
             HEX_VAL(TO_HEX(dig[2])),
             HEX_VAL(TO_HEX(dig[3]))
         ) != res) cout << "trouble in UNICODE_ESCAPE(" << res << ")\n";
         
    }
    return 0;
}

# define TEST IS_UNICODE_LETTER
int
main() {
    unsigned int ch, utf8, yes, next, utf16, state;
    next = 0x80 | 3;
    for (ch = 0; ch < 260; ch++) {
        if (IS_UTF8_2(ch)) {
             cout << "UTF2(" << ch << "," << next << ")="
             << hex << UNICODE_2(ch, next) << "\n";
        }
        if (IS_UTF8_3(ch)) {
             cout << "UTF3(" << ch << "," << next << "," << next << ")="
             << hex << UNICODE_3(ch, next, next) << "\n";
        }

    }
    state = 0;
    for (utf16 = 0x80; utf16 < 0x10000; utf16++) {
        if (state != TEST(utf16)) {
            state = !state;
            cout << "IS_UNICODE_LETTER(" 
                 << hex << utf16-1 << ")=" << TEST(utf16-1) << "\n";
            cout << "IS_UNICODE_LETTER(" 
                 << hex << utf16 << ")=" << TEST(utf16) << "\n";
        }
    }
    return 0;
}
# endif   // UNICODE_UNIT_TEST
# endif   // JAVA_UNICODE_H
