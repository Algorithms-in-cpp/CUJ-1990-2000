#if !defined JAVA_LEX_H
#define JAVA_LEX_H

// FILE:     java_lex.h
// PURPOSE:  interface to java source code lexer
//
// Source Code End User License
//
// Digital Equipment Corporation is making the below source code available to
// End Users without charge and under the terms below.
//
// Grant:
//
// Digital Equipment Corporation grants, and End User accepts a non-exclusive,
// non-transferable, royalty-free, perpetual license to display, perform, and
// otherwise use the source code for non-commercial research.
//
// Disclaimer of Warranty:
//
// THE SOURCE CODE IS PROVIDED AS IS WITHOUT ANY WARRANTY, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
// PARTICULAR PURPOSE.  Digital Equipment Corporation makes no representation
// that the source code does not infringe third party patent, copyright,
// trademark or other proprietary rights.  Digital Equipment Corporation does
// not warrant that the source code is fit for any use or is error free.
//
// Limitation of Liability:
//
// As a condition of use, the End User agrees that Digital Equipment
// Corporation shall not be liable for any costs, damages, fees, or other
// liability, nor for any  direct, indirect, special, incidental, or
// consequential damages with respect to any claim by an End User or any third
// party on account or arising from use of the source code.


# include <string.h>
# include <String.h>

struct JavaLocator {                              // JavaLocator
    int onLine;                                   // line/col pair
    int atCol;
};

struct JavaText {                                 // JavaText
    char *inSrc;                                  // in source
    int   len;                                    // bytes
    int   isClean;                                // no \uxxxx
};

class JavaLex {                                   // JavaLex

public:
    // the public interface
    JavaLex(char *srcText, int srcLength);        // ctor
    JavaLex(char *srcText);                       // ctor for asciiz
    void lex();                                   // action
    int  line(char *inSrc);                       // line number
    int  col(char *inSrc);                        // column number
    
    char *line_text(int lineno);                  // start of line
    int   line_length(char *line);                // length of line
    
protected:
    // output functions (to be overridden)
    virtual void token(int code, JavaText txt, JavaLocator where)=0; 
    virtual void white(int code, JavaText txt, JavaLocator where)=0; 
    virtual void error(int code, JavaText txt, JavaLocator where)=0; 
    virtual void error_msg(char *msg)=0;          // error message

private:
    JavaLex(const JavaLex &);                     // forbid copy
    void operator = (const JavaLex &);            // forbid =
    // lexer state variables and local methods
    char *sourceText, *sourceEnd;                 // the source
    int   sourceLength;                           // byte count
    char *chptr, *optr;                           // source points
    int isEof;                                    // no more chrs
    int lineCt, fakeLine;                         // for line number
    char *lineStart;                              // for col number
    int startLine, startCol;                      // remember for report
    int passLine, passCol;                        // remember for start
    unsigned uni, ascii;                          // unicode character
    int  eligible;                                // even/odd \-s
    void getuchar();                              // next unicode chr
    int containsUnicodeEscape, sawUnicodeEscape;  // flag appearance of \uxxxx 
    int dirtyCmp(char *raw, const char *rsv);     // dirty compare w/ \uxxxx

    inline void
    getByte() {                                   // a single ASCII chr
         if (chptr >= sourceEnd) {                // off the end -- pad
             isEof++;
             chptr++;
             ascii = ' ';                         // harmless fill character
         } else {
             ascii = *chptr++;                    // new byte
         }
    }
};

#endif    // JAVA_LEX_H
