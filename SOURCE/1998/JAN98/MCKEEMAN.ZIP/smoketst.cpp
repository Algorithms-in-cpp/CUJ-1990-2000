int main(int argc, char **argv) {
    cout << "JavaLex: begin standalone smoke test\n";
    cout << "Test output annotation: [token] (white) {error}.\n";
    char *test_input =
        "// FILE     smoke.java\n"               // fake Java program
        "// PURPOSE: test java lexer\n"
        "/** a documentation comment */\n"
        "/* a C-style comment */\n"
        "p\\u0075blic class LexTest \\u007b\n"
        "    \\u0073tatic final int i = 0x1FL+077*17;\n"
        "    float f = 1.0E-7F;\n"
        "    private cha\\u0072 c = \'\\007\';\n"
        "    String s = \"abc\\\"d\\\\u007xef\";\n"
        "    public\n"
        "    Lex\1Test(){}\n"
        "}\n";
    // construct lex object
    JavaLex lexer(test_input, strlen(test_input));
    lexer.lex();                                  // lex smoke test
    cout << "\nJavaLex: end   standalone smoke test\n";
    return 0;                                     // make os happy
}
