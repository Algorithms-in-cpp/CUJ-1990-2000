// FILE:     java_lex.cpp
// PURPOSE:  lex java source code
// METHOD:   java input is scanned, token boundaries are marked,
//           reserved tokens are identified.
//           Token contents are not closely examined: conversion
//           algorithms must check for internal syntax and semantics.
// NOTE:     The lookup for reserved words uses a perfect hash. 
// NOTE:     The design focus on speed leads to some dishonorable C++
//           -- a goto and some cases fall through.
//
// Source Code End User License
//
// Digital Equipment Corporation is making the below source code available to
// End Users without charge and under the terms below.
//
// Grant:
//
// Digital Equipment Corporation grants, and End User accepts a non-exclusive,
// non-transferable, royalty-free, perpetual license to display, perform, and
// otherwise use the source code for non-commercial research.
//
// Disclaimer of Warranty:
//
// THE SOURCE CODE IS PROVIDED AS IS WITHOUT ANY WARRANTY, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
// PARTICULAR PURPOSE.  Digital Equipment Corporation makes no representation
// that the source code does not infringe third party patent, copyright,
// trademark or other proprietary rights.  Digital Equipment Corporation does
// not warrant that the source code is fit for any use or is error free.
//
// Limitation of Liability:
//
// As a condition of use, the End User agrees that Digital Equipment
// Corporation shall not be liable for any costs, damages, fees, or other
// liability, nor for any  direct, indirect, special, incidental, or
// consequential damages with respect to any claim by an End User or any third
// party on account or arising from use of the source code.

# include <iostream.h>

# include "java_perfect_hash.h"
# include "java_lex.h"
# include "java_unicode.h"
# include "java_tokens.h"

# define SIZE(a) (sizeof(a)/sizeof(a[0]))

# if !(defined LEX_TRACE)                         // turn trace off
#     define lex_trace(msg)
# else 
#     define lex_trace(msg) cout << "\n" << msg << "\n"
# endif

// see Java class java.lang.isIdentifierIgnorable
// macro is based on assumptions about character frequency
# define IS_IDCHAR(xxxx)                                   \
     (  IS_ASCII_LETTER(xxxx)                              \
     || IS_ASCII_DIGIT(xxxx)                               \
     || xxxx == '$' || xxxx == '_'                         \
     || IS_IGNORABLE(xxxx)                                 \
     || (xxxx>0x7F && IS_UNICODE_LETTER_OR_DIGIT(xxxx) )   \
     )

// perfect hash mechanism for reserved words, see java_perfect_hash.h
static const char* rwtexts[]   = {RW_TEXTS};      // token spellings
static const int   rwlengths[] = {RW_LENGTHS};    // token lengths
static const int   rwtokens[]  = {RW_CODES};          // codes for reserved words
static const int   rww[]       = {RW_WEIGHTS};    // weights

JavaLex::
JavaLex(char *srcText) {                          // ctor (null terminated)
    sourceText   = srcText;                       // whole file
    sourceLength = strlen(srcText);               // byte count
    sourceEnd    = sourceText + sourceLength;     // just beyond end of input
}

JavaLex::
JavaLex(char *srcText, int srcLength) {           // ctor w/len
    sourceText   = srcText;                       // whole file
    sourceLength = srcLength;                     // byte count
    sourceEnd    = sourceText + sourceLength;     // just beyond end of input
}

void JavaLex::
lex() {                                           // lex
    lex_trace("entering lex");

    int code;                                     // code of current token
    char *start;                                  // start of current token
    chptr = sourceText;                           // running char ptr
    uni = 1;                                      // unicode of current ch
    ascii = '\n';                                 // fake newline
    eligible = 1;                                 // even number of \-s
    lineCt = 1;                                   // none yet
    fakeLine = 0;                                 // none yet
    lineStart = sourceText;                       // start of first line
    isEof = 0;                                    // not yet
    sawUnicodeEscape = 0;                         // none yet
    getByte();                                    // first raw ascii
    getuchar();                                   // first unicode in source

    for (;;) {                                    // until end of input
        start     = optr;                         // current char position
        startLine = passLine;                     // starting line
        startCol  = passCol;                      // starting column
        containsUnicodeEscape = sawUnicodeEscape; // reset to first char

        switch (uni) {                            // leading character
        // identifier; maybe reserved
        case 'a': case 'b': case 'c': case 'd': case 'e': case 'f':
        case 'g': case 'i': case 'l': case 'n': case 'p': case 'r': 
        case 's': case 't': case 'v': case 'w': 
            unsigned ch1, ch2, chn, len;          // 1rst, 2nd and last char
            ch1 = uni;                            // save for perfect hash
            len = 1;                              // one char for sure
            getuchar();                           // step ahead on unicode
            ch2 = uni;                            // save for perfect hash
            while ('a' <= uni && uni <= 'z') {    // assume no ignorable UTF-8
                len++;                            // count lower case letters
                chn = uni;                        // save for perfect hash
                getuchar();                       // pass over letter
            }
            if (!IS_IDCHAR(uni)) {                // end of identifier
                code = IDENTIFIER;                // default
                if (len < 2 || len > 12) break;   // cannot be reserved
                unsigned rwindex = PERFECT_HASH(ch1, ch2, chn, len);
                if (rwindex < SIZE(rwlengths)     // no overrun
                && len == rwlengths[rwindex]) {   // possible match
                    const char *rsv = rwtexts[rwindex];
                    if (containsUnicodeEscape && dirtyCmp(start, rsv)
                    ||  memcmp(start, rsv, len) == 0) {
                        code = rwtokens[rwindex]; // is reserved
                    }
                }
                break;                            // out of switch
            }                                     // fall through, finish id

        // ASCII identifier so far, but not reserved
        case 'h': case 'j': case 'k': case 'm': case 'o': case 'q': 
        case 'u': case 'x': case 'y': case 'z':
        
        case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': 
        case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': 
        case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': 
        case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': 
        case 'Y': case 'Z': case '_': case '$':
            code = IDENTIFIER;
            getuchar();                           // pass over letter or _ or $
            while (IS_IDCHAR(uni)) {
                getuchar();                       // pass over id chars
            }
            break;                                // out of switch

        case '.':
            getuchar();                           // pass over dot
            if (IS_ASCII_DIGIT(uni)) goto after_the_dot;
            code = DOT;                           // member dot
            break;

        case '0':
            getuchar();                           // pass over 0
            if (uni == 'x' || uni == 'X') {       // hex
                getuchar();                       // pass over x or X
                while (IS_HEX(uni)) {
                    getuchar();                   // pass over digits
                }
                if (uni == 'l' || uni == 'L') {
                    getuchar();                   // pass over suffix
                }
                code = INTEGER_LITERAL;           // 0xhhhL
                break;                            // out of switch
            }                                     // fall through

        case '1': case '2': case '3': case '4': case '5': 
        case '6': case '7': case '8': case '9':
            while (IS_ASCII_DIGIT(uni)) {
                getuchar();                       // pass over digits
            }
            if (uni == 'l' | uni == 'L') {
                getuchar();                       // pass over suffix
                code = INTEGER_LITERAL;
                break;                            // out of switch
            }
            if (uni != '.') {                     // integer constant
                code = INTEGER_LITERAL;
                break;                            // out of switch
            }
            getuchar();                           // pass over dot
after_the_dot:                                    // shame on me
            while (IS_ASCII_DIGIT(uni)) {
                getuchar();                       // pass over digits
            }
            if (uni == 'e' || uni == 'E') {       // exponent
                getuchar();                       // pass over e or E
                if (uni == '+' || uni == '-') {   // signed exponent
                    getuchar();                   // pass over + or -
                }
                while (IS_ASCII_DIGIT(uni)) {
                    getuchar();                   // pass over exponent
                }
            }
 
            if (uni == 'd' || uni == 'D'
             || uni == 'f' || uni == 'F') {
                getuchar();                       // pass over suffix
            }
            code = FLOATINGPOINT_LITERAL;
            break;                                // out of switch

        case ' ': case '\t': case '\n': case '\r':
            while (IS_ASCII_WHITE(uni)) {
                if (uni == '\n') {
                    lineCt++;                     // for line number
                    lineStart = optr+1;           // for column number
                }
                getuchar();                       // pass over whitespace
                if (isEof>1) break;               // out of loop
            }
            code = WHITESPACE;
            break;                                // out of switch

        case '\'':
            code = CHARACTER_LITERAL;             // optimisitc
            getuchar();                           // pass over first '
            if (uni == '\\') {                    // escape (not \uxxxx)
                getuchar();                       // pass over \ chr
                getuchar();                       // pass over escapee
                if ('0' <= uni && uni <= '7') getuchar();
                if ('0' <= uni && uni <= '7') getuchar();
            } else if (uni == '\n') {
                error_msg("unexpected linebreak in char constant");
                code = ERROR_CHAR_1;
            } else {
                getuchar();                       // pass over char itself
            }
            if (uni == '\'') {                    // normal ending
                getuchar();                       // pass over last '
            } else {
                error_msg("expected \' to end char constant");
                code = ERROR_CHAR_2;
            }
            break;                                // out of switch

        case '"':
            code = STRING_LITERAL;                // optimistic
            getuchar();                           // pass over first "
            for(;;) {                             // string body
                if (uni == '\\') {                // escape
                    getuchar();                   // pass over \ chr
                    getuchar();                   // pass over escapee
                    if ('0' <= uni && uni <= '7') getuchar();
                    if ('0' <= uni && uni <= '7') getuchar();
                } else if (uni == '"') {
                    getuchar();                   // pass over second "
                    break;                        // (normal) out of loop
                } else if (uni == '\n') {
                    error_msg("unexpected linebreak in string");
                    code = ERROR_STRING_1;        // report error
                    break;                        // out of lool
                } else if (isEof>1) {
                    error_msg("unexpected end of input in string");
                    code = ERROR_STRING_2;        // report error
                    break;                        // out of loop
                } else {
                    getuchar();                   // pass over normal character
                }
            }
            break;

        case '(':
            code = LRB;                           // report (
            getuchar();                           // pass over (
            break;

        case ')':
            code = RRB;                           // report )
            getuchar();                           // pass over )
            break;

        case '{':
            code = LCB;                           // report {
            getuchar();                           // pass over {
            break;

        case '}':
            code = RCB;                           // report }
            getuchar();                           // pass over }
            break;

        case '[':
            code = LSB;                           // report [
            getuchar();                           // pass over [
            break;

        case ']':
            code = RSB;                           // report ]
            getuchar();                           // pass over ]
            break;

        case ';':
            code = SEMI;                          // report ;
            getuchar();                           // pass over ;
            break;

        case ':':
            code = COLON;                         // report :
            getuchar();                           // pass over :
            break;

        case ',':
            code = COMMA;                         // report ,
            getuchar();                           // pass over ,
            break;

        case '=':
            getuchar();                           // pass over =
            if (uni == '=') {
                getuchar();                       // pass over =
                code = EQEQ;                      // report ==
            } else {
                code = EQ;                        // report =
            }
            break;

        case '<':
            getuchar();                           // pass over <
            if (uni == '=') {                     //  <=
                getuchar();                       // pass over =
                code = LTEQ;                      // report <=
            } else if (uni == '<') {              // <<
                getuchar();                       // pass over <
                if (uni == '=') {                 // <<=
                    getuchar();                   // pass over =
                    code = LTLTEQ;                // report <<=
                } else {
                    code = LTLT;                  // report <<
                }
            } else {
                code = LT;                        // report <
            }
            break;

        case '>':
            getuchar();                           // pass over first >
            if (uni == '=') {                     //  >=
                code = GTEQ;                      // report >=
                getuchar();                       // pass over =
            } else if (uni == '>') {              // >>
                getuchar();                       // pass over second >
                if (uni == '=') {                 // >>=
                    code = GTGTEQ;                // report >>=
                    getuchar();                   // pass over =
                } else if (uni == '>') {          // >>>
                    getuchar();                   // pass over third >
                    if (uni == '=') {             // >>>=
                        code = GTGTGTEQ;          // report >>>>
                        getuchar();               // pass over =
                    } else {
                        code = GTGTGT;            // report >>>
                    }
                } else {
                    code = GTGT;                  // report >>
                }
            } else {
                code = GT;                        // report >
            }
            break;

        case '!':
            getuchar();                           // pass over !
            if (uni == '=') {                     //  !=
                code = NOTEQ;                     // report !=
                getuchar();                       // pass over =
            } else {
                code = NOT;                       // report !
            }
            break;

        case '~':
            code = TILDE;                         // report ~
            getuchar();                           // pass over ~
            break;

        case '?':
            code = QMARK;                         // report ?
            getuchar();                           // pass over ?
            break;

        case '&':
            getuchar();                           // pass over &
            if (uni == '=') {                     //  &=
                code = ANDEQ;                     // report &=
                getuchar();                       // pass over =
            } else if (uni == '&')  {             // &&
                getuchar();                       // pass over second &
                code = ANDAND;                    // report &&
            } else {
                code = AND;                       // report &
            }
            break;

        case '|':
            getuchar();                           // pass over |
            if (uni == '=') {                     //  |=
                code = OREQ;                      // report |=
                getuchar();                       // pass over =
            } else if (uni == '|') {              // ||
                code = OROR;                      // report ||
                getuchar();                       // pass over second |
            } else {
                code = OR;                        // report |
            }
            break;

        case '+':
            getuchar();                           // pass over +
            if (uni == '=') {                     //  +=
                code = ADDEQ;                     // report +=
                getuchar();                       // pass over =
            } else if (uni == '+') {              // ++
                code = ADDADD;                    // report ++
                getuchar();                       // pass over second +
            } else {
                code = ADD;                       // report +
            }
            break;

        case '-':
            getuchar();                           // pass over -
            if (uni == '=') {                     //  -=
                code = SUBEQ;                     // report -=
                getuchar();                       // pass over =
            } else if (uni == '-') {              // --
                code = SUBSUB;                    // report --
                getuchar();                       // pass over second -
            } else {
                code = SUB;                       // report -
            }
            break;

        case '*':
            getuchar();                           // pass over *
            if (uni == '=') {                     //  *=
                code = MULEQ;                     // report *=
                getuchar();                       // pass over =
            } else {
                code = MUL;                       // report *
            }
            break;

        case '/':
            getuchar();                           // pass over /
            if (uni == '=') {                     //  /=
                code = DIVEQ;                     // report /=
                getuchar();                       // pass over =
            } else if (uni == '*') {              // C style comment
                getuchar();                       // pass over first *
                if (uni == '*') code = DOC_COMMENT; else code = C_COMMENT;
                for(;;) {                         // C comment body
                    if (uni == '\n') {
                        lineCt++;
                        lineStart = optr+1;       // for column number
                    }
                    if (uni == '*') {
                        getuchar();               // pass over second *
                        if (uni == '/') {
                            getuchar();           // pass over second /
                            break;                // out of inner loop
                        }
                    } else if (isEof>1) {         // early eof
                        code = code == C_COMMENT
                             ? ERROR_C_COMMENT
                             : ERROR_DOC_COMMENT;
                        break;
                    } else {
                        getuchar();               // pass over body
                    }
                }
            } else if (uni == '/') {              // C++ style comment
                getuchar();                       // pass over second /
                for(;;) {                         // C++ comment body
                    if (uni == '\n') {
                        code = CXX_COMMENT;
                        break;                    // out of inner loop
                    } else if (isEof>1) {         // early eof
                        code = ERROR_CXX_COMMENT;
                        break;                    // out of inner loop
                    } else {
                        getuchar();               // pass over body
                    }
                }
            } else {                              // must be division
                code = DIV;                       // report /
            }
            break;

        case '^':
            getuchar();                           // pass over ^
            if (uni == '=') {                     //  ^=
                code = HATEQ;                     // report ^=
                getuchar();                       // pass over =
            } else {
                code = HAT;                       // report ^
            }
            break;

        case '%':
            getuchar();                           // pass over %
            if (uni == '=') {                     //  %=
                code = MODEQ;                     // report %=
                getuchar();                       // pass over =
            } else {
                code = MOD;                       // report %
            }
            break;

        default:                                  // xxxx
            if (IS_UNICODE_LETTER(uni)) {
                for (;IS_IDCHAR(uni);) getuchar();
                code = IDENTIFIER;                // non ASCII idenifier
            } else {
                error_msg("unexpected character");
                getuchar();                       // skip over trouble
                code = ERROR_UTF8;
            }
            break;
        }                                         // end switch

        JavaLocator where = {startLine-fakeLine, startCol};
        JavaText txt = {start, optr-start, !containsUnicodeEscape};
        
        switch (code) {
        case ERROR_CHAR_1:                        // report ' ' error
        case ERROR_CHAR_2:
        case ERROR_STRING_1:                      // report " " error
        case ERROR_STRING_2:
        case ERROR_UTF8:                          // report utf8 error
            error(code, txt, where);
            break;                                // out of switch
        case WHITESPACE:                          // report whitespace
        case C_COMMENT:
        case CXX_COMMENT:
        case DOC_COMMENT:
            white(code, txt, where);
            break;                                // out of switch
        default:                                  // report token
            token(code, txt, where);
            break;                                // out of switch
        }
        if (isEof>1) {                            // all done
            JavaText t = {sourceEnd, 0, 1};       // 0 length token
            JavaLocator s = {passLine, 1};        // beyond text
            token(EOF_TOKEN, t, s);               // report eof
            break;                                // exit main loop
        }
    }                                             // end loop

    lex_trace("leaving lex");
    return;
}

void JavaLex::
getuchar() {                                      // getuchar
    int c1, c2, c3, c4;
    optr     = chptr-1;                           // for lexeme start
    passLine = lineCt;                            // starting line
    passCol  = chptr-lineStart;                   // starting column
    containsUnicodeEscape |= sawUnicodeEscape;    // stay one behind
    sawUnicodeEscape = 0;                         // optimistic
    if (ascii=='\\' && eligible) {                // maybe \uxxxx
        char *saveptr = chptr;                    // for backup
        int saveline = lineCt;                    
        getByte();                                // pass \ 
        if (ascii == 'u') {                       // good start
            do getByte(); while (ascii == 'u');   // \uuuu
            c1 = ascii; getByte();                //       x
            c2 = ascii; getByte();                //        x
            c3 = ascii; getByte();                //         x
            c4 = ascii; getByte();                //          x
            if (IS_HEX(c1) && IS_HEX(c2) && IS_HEX(c3) && IS_HEX(c4)) {
                uni = UNICODE_ESCAPE(c1,c2,c3,c4);// 16 bit value
                sawUnicodeEscape = 1;             // for heavy-duty compare
                eligible = 1;                     // even \ for escape
                if (uni == '\n') fakeLine++;      // not visible in editor
                return;                           // done with this one
            }
        }
        chptr  = saveptr;                         // as if never here
        lineCt = saveline;
        ascii  = '\\';
    }
    if (IS_UTF8_1(ascii)) {                       // ASCII, all done
        uni = ascii;
        if (ascii == '\\') eligible = !eligible; else eligible = 1;
        getByte();
    } else if (IS_UTF8_2(ascii)) {                // 2 byte encoding
        c1 = ascii; getByte();
        if (IS_UTF8_n(ascii)) {                   // valid 2nd byte
            c2 = ascii; getByte();                // pass by byte 2
            uni = UNICODE_2(c1, c2);
        } else {
            chptr--;                              // back up one
            ascii = c1;
            uni = ascii;                          // will cause diagnostic
        }
        eligible = 1;                             // even \ for escape
    } else {                                      // 3 byte encoding
        c1 = ascii; getByte(); 
        if (IS_UTF8_n(ascii)) {                   // valid 2nd byte
            c2 = ascii; getByte();                // pass by byte 2
            if (IS_UTF8_n(ascii)) {               // valid 3rd byte
                c3 = ascii; getByte();            // pass by byte 3
                uni = UNICODE_3(c1, c2, c3);
            } else {
                chptr-=2;                         // back up two
                ascii = c1;
                uni = ascii;                      // will cause diagnostic
            }
        } else {
            chptr--;                              // back up one
            ascii = c1;
            uni = ascii;                          // will cause diagnostic
        }
        eligible = 1;                             // even \ for escape
    }
}

int JavaLex::
dirtyCmp(char *raw, const char *rsv) {            // ch by ch compare
     int j = 0;
     for (int i=0; rsv[i] != 0; i++) {            // assume equal length
         char ch = raw[j++];
         if (ch == '\\') {
              while (raw[j++] == 'u');            // points at first x
              j+=3;                               // points past xxxx
              ch = UNICODE_ESCAPE(0, 0, raw[j-2], raw[j-1]);
         }
         if (rsv[i] != ch) return 0;              // difference found
     }
     return 1;                                    // reached end, all OK
}

int JavaLex::
line(char *inSrc) {                               // compute line number
    int ln = 1;                                   // first line
    char *cptr = inSrc;
    char *p = sourceText;                         // reset to beginning
    while (p < cptr) {
        if (*p++ == '\n') ln++;                   // count new lines
    }
    return ln;
}

int JavaLex:: 
col(char *inSrc) {                                // compute column
    int c = 1;                                    // left margin
    char *p = inSrc;                              // token begin
    while (p > sourceText) {                      // stop before bof
        if (*--p == '\n') break;                  // stop at new line
        c++;                                      // count columns
   }
   return c;
}

char *JavaLex:: 
line_text(int lineno) {                           // pointer to text of line
    int line = 1;
    for (char *t=sourceText; line<lineno; t++) {
        if (*t == '\n') line++;
    }
    return t;
}

int JavaLex:: 
line_length(char *line) {                         // length of line
    int len = 0;
    for (char *t=line; *t != '\n'; t++) {
        len++;
    }
    return len;
}

//                       U N I T    T E S T I N G

# if defined LEX_SMOKE_TEST
class Smoke : public JavaLex {
public:
    Smoke(char *src) : JavaLex(src, strlen(src)) { }
    Smoke(char *src, int len) : JavaLex(src, len) { }

    void 
    token(int code, JavaText txt, JavaLocator where) {
        cout << "[" << code << " ";
        cout.write(txt.inSrc, txt.len);
        cout << "]";
    }

    void
    white(int code, JavaText txt, JavaLocator where) {
        cout << "(";
        cout.write(txt.inSrc, txt.len);
        cout << ")";
    }

    void
    error(int code, JavaText txt, JavaLocator where) {
        cout << "{";
        cout.write(txt.inSrc, txt.len);
        cout << "}";
    }

    void
    error_msg(char *msg) {
        cout << "JavaLex error:" << msg << "\n";
    }
};

int
main(int argc, char **argv) {
    cout << "JavaLex: begin standalone smoke test\n";
    cout << "Test output annotation: [token] (white) {error}.\n";
    char *test_input =
        "// FILE     smoke.java\n"                // fake Java program
        "// PURPOSE: test java lexer\n"
        "/** a documentation comment */\n"
        "/* a C-style comment */\n"
        "p\\u0075bli\\uuu0063 class LexTest \\u007b\n" 
        "    \\u0073tatic final int i = 0x1FL+077*17;\\u000A"
        "    float f = 1.0E-7F;\n"
        "    private cha\\u0072 c = \'\\007\';\n"
        "    String s = \"abc\\\"d\\\\u007xef\";\n"
        "    public\n"
        "    Lex\1Test(){}\n"
        "}\n";
    Smoke lexer(test_input, strlen(test_input));  // construct lex object
    lexer.lex();                                  // lex smoke test
    cout << "\nJavaLex: end   standalone smoke test\n";
    // make all errr diagnostics appear
    cout << "JavaLex: begin standalone error test\n";
    cout << "Test output annotation: [token] (white) {error}.\n";
    test_input =
        "// FILE     error.java\n"                // every error once
        "// PURPOSE: test java lexer error behavior\n"
        "\"unterminated string literal\n"
        "\"unterminated string literal\\\n"
        "\"unterminated string literal\\0\n"
        "\'\n"                                    // unterminated ' '
        "\'u\n"                                   // unterminated ' '
        "\'\\1\n"                                 // unterminated ' '
        "\\u \\ua \\uab \\uabc \n"                // malformed unicode escapes
        "1e 1e+ 1e- \n"                           // malformed double 
        "\1 \2 \3 \4 \5 \6 \7 \10 \16 \17 @`\\#"  // unexpected ascii 
        "}\n";
    Smoke errs(test_input, strlen(test_input));  // construct lex object
    errs.lex();                                  // lex smoke test
    cout << "\nJavaLex: end   standalone error test\n";

    return 0;                                     // make os happy
}

# elif defined LEX_UNIT_TEST

class JavaUnit : public JavaLex {
public:
    JavaUnit(char *src) : JavaLex(src, strlen(src)) { }
    JavaUnit(char *src, int len) : JavaLex(src, len) { }
    
    void
    testout(int code, JavaText txt, JavaLocator where) {
        cout.write(txt.inSrc, txt.len);
        cout << "= code = " << code;
        if (line(txt.inSrc) != where.onLine) {
            cout << " locator line error " 
                 << line(txt.inSrc) << " "
                 << where.onLine;
        }
        if (col(txt.inSrc) != where.atCol) {
            cout << " locator offset error " 
                 << col(txt.inSrc) << " "
                 << where.atCol;
        }
        cout << "\n";
    }
    
    void
    token(int code, JavaText txt, JavaLocator where) {
        cout << "token=";
        testout(code, txt, where);
    }

    void
    white(int code, JavaText txt, JavaLocator where) {
        cout << "white=";
        testout(code, txt, where);
   }

    void
    error(int code, JavaText txt, JavaLocator where) { 
        cout << "error=";
        testout(code, txt, where);
    }

    void
    error_msg(char *msg) {
        cout << "JavaLex error:" << msg << "\n";
    }
};

# define TEST_LIM 30000
int
main(int argc, char **argv) {
    cout << "JavaLex: begin standalone unit test\n";
    char src[TEST_LIM];                           // for source code
    FILE *input;
    int i, j;

    for (i=1; i<argc; i++) {
        cout << "lexing file " << argv[i] << "\n";
        input = fopen(argv[i], "r");
        for (j=0;;) {                             // read file
            int k = fgetc(input);
            if (k == EOF) break;
            src[j++] = k;                         // place the input char
            if (j >= TEST_LIM) break;
        }
        fclose(input);
        JavaUnit unit(src, j);                    // lex object
        unit.lex();
    }
    cout << "JavaLex: end   standalone unit test\n";
    return 0;                                     // make os happy
}

# elif defined LEX_SPEED_TEST
// cxx -M compiles 10471 tokens in 0.04 sec, 261775 tokens/sec on alpha 500
// JavaLex processes                        1617590 tokens/sec on alpha 500
extern "C" {
# include <time.h>
}
# include <fstream.h>

class JavaSpeed : public JavaLex {
public:
    int tokenCt;
    
    JavaSpeed(char *src, int len) : JavaLex(src, len) { 
        tokenCt = 0;
    }
    
    void
    token(int code, JavaText txt, JavaLocator where) {
        tokenCt++;
    }

    void white(int code, JavaText txt, JavaLocator where) { }
    void error(int code, JavaText txt, JavaLocator where) { }
    void error_msg(char *msg) { }
};

# define TEST_LIM 30000
int
main(int argc, char **argv) {
    cout << "JavaLex: begin standalone speed test\n";
    char k, src[TEST_LIM+1];                      // for source code
    int i,j;
    int tokens = 0;
    clock();                                      // start cpu clock
    
    for (i=1; i<argc; i++) {
        cout << "lexing file " << argv[i] << "\n";
        ifstream input(argv[i]);
        j = 0;
        while (input.get(k)) {                    // read file
            src[j++] = k;                         // place the input char
            if (j >= TEST_LIM) break;
        }
        input.close();
        JavaSpeed speed(src, j);                  // lex object
        for (j=0; j<50; j++) {                    // lex 50 times each
            speed.lex();
        }
        tokens += speed.tokenCt;
    }
    double elapsed = clock();                     // time in usec
    elapsed = elapsed/CLOCKS_PER_SEC;             // time in sec
    cout << "JavaLex: end   standalone speed test\n" ;
    // breaks  the  regression to put time in output file
    cerr << tokens/elapsed << " tokens/sec\n";
    return 0;                                     // make os happy
}

# endif

