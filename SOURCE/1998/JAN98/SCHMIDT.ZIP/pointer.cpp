Listing 1: Class  pointer.h implementation
 
template<class t>
inline pointer::~pointer()
    {
    pointer_ = NULL; // debugging aid
    }
 
template<class t>
inline pointer::pointer(t * const pointer)
        :
        pointer_(pointer)
    {
    }
 
template<class t>
inline pointer::pointer(pointer<t> const &that)
        :
        pointer_(that.pointer_)
    {
    }
 
template <class t>
inline pointer<t>::pointer(class nil const &)
        :
        pointer_(NULL)
    {
    }
 
template<class t>
inline pointer<t> &pointer<t>::operator=
        (pointer<t> const &that)
    {
    if ((void const *) this != (void const *) &that)
        pointer_ = that.pointer_;
    return *this;
    }
 
template<class t>
inline pointer<t>::operator t *() const
    {
    return pointer_;
    }
 
template<class t>
inline t **pointer<t>::operator&() const
    {
    if (pointer_ == NULL)
        {
        cerr << "address-of NULL pointer" << endl;
        throw invalid_argument;
        }
    return &pointer_;
    }
 
template<class t>
inline t * const *pointer<t>::operator&() const
    {
    if (pointer_ == NULL)
        {
        cerr << "address-of NULL pointer" << endl;
        throw invalid_argument;
        }
    return &pointer_;
    }
 
template<class t>
inline t &pointer<t>::operator*() const
    {
    if (pointer_ == NULL)
        {
        cerr << "dereference NULL pointer" << endl;
        throw invalid_argument;
        }
    }
 
template<class t>
inline t *pointer<t>::operator->() const
    {
    if (pointer_ == NULL)
        {
        cerr << "dereference NULL pointer" << endl;
        throw invalid_argument;
        }
    }
 
template <class t>
inline bool pointer<t>::operator==
        (pointer<t> const &that) const
    {
    return pointer_ == that.pointer_;
    }
 
template <class t>
inline bool pointer<t>::operator!=
        (pointer<t> const &that) const
    {
    return !(*this == that);
    }
 
template <class t>
inline pointer<t> &pointer<t>::operator+=
        (size_t const increment)
    {
    pointer_ += increment;
    return *this;
    }
 
template <class t>
inline pointer<t> &pointer<t>::operator-=
        (size_t const decrement)
    {
    return *this += -decrement;
    }
 
//End of File
 
 
 
