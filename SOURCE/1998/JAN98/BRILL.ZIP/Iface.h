//
// Iface.h - 
//    Declarations of interfaces, IIDs, and CLSID
//    shared by the client and the component.
//
interface IAddSub : IUnknown
{
//	virtual void pascal Fx() = 0 ;
	virtual int pascal Add(int x, int y)=0;
	virtual int pascal Subtract(int x, int y)=0;
};


interface IMulDiv : IUnknown
{
	virtual int pascal Multiply(int x, int y)=0;
	virtual int pascal Divide(int x, int y)=0;

//	virtual void pascal Fy() = 0 ;
};


interface ITrigonometry : IUnknown
{
	//virtual void pascal Fz() = 0 ;
};

//
// Declaration of GUIDs for interfaces and component.
//   These constants are defined in GUIDs.cpp.
//
extern "C" const IID IID_IAddSub ;
extern "C" const IID IID_IMulDiv ;
extern "C" const IID IID_ITrigonometry ;

extern "C" const CLSID CLSID_Component1 ;
