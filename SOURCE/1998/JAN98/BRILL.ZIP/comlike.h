enum InterfaceTypes { IGROUP1, IGROUP2,
    IGROUP3, INTERFACE_NOT_IMPLEMENTED,
    ALLS_WELL };


//Note that the syntax and function names
//are only approximations of COM and serve
//only as an example of how COM might appear
//in a C++ Class. We will see "real COM" later

class InterfaceToGroupOne
{
public:
  InterfaceToGroupOne(){};
  void GroupOneFunc1()
    {cout<<"Group 1 func1"<<endl;}
  void GroupOneFunc2()
    {cout<<"Group 1 func2"<<endl;}
};

class InterfaceToGroupTwo
{
public:
  InterfaceToGroupTwo(){};
  void GroupTwoFunc1()
    {cout<<"Group 2 func1"<<endl;}
  void GroupTwoFunc2()
    {cout<<"Group 2 func2"<<endl;}
};

class COMObject
{
private:
  InterfaceToGroupOne m_I1;
  InterfaceToGroupTwo m_I2;

public:
  int GetInterface(enum InterfaceTypes type,
                   void *p)
  {
    if(type==IGROUP1)
    { p=&m_I1;
      return ALLS_WELL;
    }
    else
    {
      if (type==IGROUP2)
      {
        p=&m_I2;
        return ALLS_WELL;
      }
      else
      {
        p=NULL;
        return INTERFACE_NOT_IMPLEMENTED;
      }
    }
  };

void main()
{
  COMObject k;
  InterfaceToGroupTwo * i2;
  InterfaceToGroupOne *i1;

  k.GetInterface(IGROUP2, i2);
  k.GetInterface(IGROUP1, i1);

  i2->GroupTwoFunc1();
  i1->GroupOneFunc1();
}

OUTPUT:

Group 2 func1
Group 1 func1

