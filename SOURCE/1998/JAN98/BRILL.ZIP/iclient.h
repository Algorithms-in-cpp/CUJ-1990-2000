// iclient.h
//	Interface definitions for all the interfaces this a client may use.
//Note that they are all derived from IUnknown, and that all their function
//prototypes are virtual. Also note that there are NO member variables declared
//in the client side headers since COM clients may not directly reference member 
//variables of a COM interface.

interface IAddSub : IUnknown
{

	virtual int _stdcall Add(int x, int y)=0;
	virtual int _stdcall Subtract(int x, int y)=0;
};


interface IMulDiv : IUnknown
{
	virtual int _stdcall Multiply(int x, int y)=0;
	virtual int _stdcall Divide(int x, int y)=0;

 
};


interface ITrigonometry : IUnknown
{
	
};


