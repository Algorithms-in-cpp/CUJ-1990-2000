//
// Iserver.h 


interface IAddSub : IUnknown
{
	int IAddSub_last_result;
	virtual int pascal Add(int x, int y)=0;
	virtual int pascal Subtract(int x, int y)=0;
};


interface IMulDiv : IUnknown
{
	int IMulDiv_last_result;
	virtual int pascal Multiply(int x, int y)=0;
	virtual int pascal Divide(int x, int y)=0;


};


interface ITrigonometry : IUnknown
{

};


extern "C" const IID IID_IAddSub ;
extern "C" const IID IID_IMulDiv ;
extern "C" const IID IID_ITrigonometry ;
extern "C" const CLSID CLSID_ClassFactory ;
