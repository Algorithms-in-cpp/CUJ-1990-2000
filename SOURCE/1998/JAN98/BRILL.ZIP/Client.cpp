//
// Client.cpp - client implementation
//
#include <iostream.h>
#include <objbase.h>

#include "Iclient.h"

void trace(const char* msg) { cout << "Client: \t\t" << msg << endl ;}

//  All these GUIDS where generated using GUIDGEN.EXE and are globally unique
//  for each interface.  

// {59FA0200-13FF-11d1-883A-3C8B00C10000}
extern "C" const IID IID_IAddSub = 
{0x59fa0200, 0x13ff, 0x11d1, {0x88, 0x3a, 0x3c, 0x8b, 0x0, 0xc1, 0x0, 0x0}};

// {59FA0201-13FF-11d1-883A-3C8B00C10000}
extern "C" const IID IID_IMulDiv = 
{0x59fa0201, 0x13ff, 0x11d1,{ 0x88, 0x3a, 0x3c, 0x8b, 0x0, 0xc1, 0x0, 0x0}};


// {59FA0202-13FF-11d1-883A-3C8B00C10000}
extern "C" const IID IID_ITrigonometry = 
{0x59fa0202, 0x13ff, 0x11d1,{ 0x88, 0x3a, 0x3c, 0x8b, 0x0, 0xc1, 0x0, 0x0}};

// {59FA0203-13FF-11d1-883A-3C8B00C10000}
extern "C" const CLSID CLSID_ClassFactory =
{ 0x59fa0203, 0x13ff, 0x11d1, { 0x88, 0x3a, 0x3c, 0x8b, 0x0, 0xc1, 0x0, 0x0 } };



class client_out
{
public:
	void operator<<(char*c)
	{
		cout<<"COMCalc Client:\t\t"<<c;
	}


};

client_out out;


int main()
{
	// Initialize COM Library
	CoInitialize(NULL) ;

	cout<<"The client calls CoCreateInstance to create a comCalc object\n"<<endl ;
	cout<<"  and get interface IAddSub.\n" <<endl;
	
	IAddSub* pIAddSub = NULL ; 
	HRESULT hr = ::CoCreateInstance(CLSID_ClassFactory,
	                                NULL,  
	                                CLSCTX_INPROC_SERVER,
	                                IID_IAddSub, 
	                                (void**)&pIAddSub) ;
	if (SUCCEEDED(hr))
	{
		out<<"Succeeded getting IAddSub. Now we can reference its member functions\n" ;
	
	      // Use interface IAddSub.
		cout<<"3+3="<<pIAddSub->Add(3,3)<<endl;
		cout<<"3-3="<<pIAddSub->Subtract(3,3)<<endl;
		
		out<<"Ask for interface IMulDiv.\n" ;
		IMulDiv* pIMulDiv = NULL ;
	
		hr = pIAddSub->QueryInterface(IID_IMulDiv, (void**)&pIMulDiv) ;
		
		if (SUCCEEDED(hr))
		{
			out<<"Got IMulDiv.\n" ;
	       // Use interface IMulDiv.

		cout<<"3*3="<<pIMulDiv->Multiply(3,3)<<endl;
		cout<<"3/3="<<pIMulDiv->Divide(3,3)<<endl;

			pIMulDiv->Release() ;
			out<<"Release IMulDiv interface.\n" ;
		}
		else
		{
			out<<"Could not get interface IMulDiv.\n" ;
		}

		out<<"Ask for interface ITrigonometry.\n" ;

		ITrigonometry* pITrigonometry = NULL ;

		hr = pIAddSub->QueryInterface(IID_ITrigonometry, (void**)&pITrigonometry) ;
		if (SUCCEEDED(hr))
		{
			out<<"Got interface ITrigonometry.\n" ;
//			pITrigonometry->Fz() ;
			pITrigonometry->Release() ;
			out<<"Release ITrigonometry interface.\n" ;
		}
		else
		{
			out<<"Could not get interface ITrigonometry.\n" ;
			out<<"Perhaps a later version of comCalc will support it.\n" ;
		}

		out<<"Release IAddSub interface.\n" ;
		pIAddSub->Release() ;
	}
	else
	{
		cout << "Could not create component. hr = "
		     << hex << hr << endl ;    
	}

	// Uninitialize COM Library
	CoUninitialize() ;

	return 0 ;
}
