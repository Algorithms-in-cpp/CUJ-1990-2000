//
// Cmpnt.cpp
//
#include <iostream.h>
#include <objbase.h>

#include "Iserver.h"      // Interface declarations
#include "Registry.h"   // Registry helper functions

// Trace function


///////////////////////////////////////////////////////////
//
// Global variables
//
static HMODULE g_hModule = NULL ;   // DLL module handle
static long g_cComponents = 0 ;     // Count of active components
static long g_cServerLocks = 0 ;    // Count of locks

// Friendly name of component
const char g_szFriendlyName[] = "COMCalc Server" ;
// Version-independent ProgID
const char g_szVerIndProgID[] = "Example.COMCalc" ;
// ProgID
const char g_szProgID[] = "Example.COMCalc.1" ;




// {59FA0200-13FF-11d1-883A-3C8B00C10000}
extern "C" const IID IID_IAddSub = 
{0x59fa0200, 0x13ff, 0x11d1, {0x88, 0x3a, 0x3c, 0x8b, 0x0, 0xc1, 0x0, 0x0}};

// {59FA0201-13FF-11d1-883A-3C8B00C10000}
extern "C" const IID IID_IMulDiv = 
{0x59fa0201, 0x13ff, 0x11d1,{ 0x88, 0x3a, 0x3c, 0x8b, 0x0, 0xc1, 0x0, 0x0}};

// {59FA0202-13FF-11d1-883A-3C8B00C10000}
extern "C" const IID IID_ITrigonometry = 
{0x59fa0202, 0x13ff, 0x11d1,{ 0x88, 0x3a, 0x3c, 0x8b, 0x0, 0xc1, 0x0, 0x0}};

// {59FA0203-13FF-11d1-883A-3C8B00C10000}
extern "C" const CLSID CLSID_ClassFactory =
{ 0x59fa0203, 0x13ff, 0x11d1, { 0x88, 0x3a, 0x3c, 0x8b, 0x0, 0xc1, 0x0, 0x0 } };




///////////////////////////////////////////////////////////
//
// Component 
//
class CA : public IAddSub,
           public IMulDiv 
{
public:
	// IUnknown
	virtual HRESULT __stdcall QueryInterface(const IID& iid, void** ppv) ;
	virtual ULONG __stdcall AddRef() ;
	virtual ULONG __stdcall Release() ;

	// Interface IAddSub
//	virtual void __stdcall Fx() { cout << "Fx" << endl ;}
	virtual int __stdcall Add(int x,int y){ IAddSub_last_result=x+y; return IAddSub_last_result; }
	virtual int __stdcall Subtract(int x,int y){ IAddSub_last_result=x-y; return IAddSub_last_result; }
	virtual int __stdcall Multiply(int x,int y){ IMulDiv_last_result=x*y; return IMulDiv_last_result; }
	virtual int __stdcall Divide(int x,int y){ IMulDiv_last_result=x/y; return IMulDiv_last_result; }

	// Interface IMulDiv
//	virtual void __stdcall Fy() { cout << "Fy" << endl ;} 

	// Constructor
	CA() ;

	// Destructor
	~CA() ;

private:
	// Reference count
	long m_cRef ;
} ;


//
// Constructor
//
CA::CA() : m_cRef(1)
{ 
	InterlockedIncrement(&g_cComponents) ; 
}

//
// Destructor
//
CA::~CA() 
{ 
	InterlockedDecrement(&g_cComponents) ; 
	cout<<"COMCalc:\t\tDestroy self."<<endl ;
}

//
// IUnknown implementation
//
HRESULT __stdcall CA::QueryInterface(const IID& iid, void** ppv)
{    
	if (iid == IID_IUnknown)
	{
		*ppv = static_cast<IAddSub*>(this) ; 
	}
	else if (iid == IID_IAddSub)
	{
		*ppv = static_cast<IAddSub*>(this) ;
		cout<<"COMCalc:\t\tReturn pointer to IAddSub.\n" ; 
	}
	else if (iid == IID_IMulDiv)
	{
		*ppv = static_cast<IMulDiv*>(this) ; 
		cout<<"COMCalc:\t\tReturn pointer to IMulDiv.\n" ; 
	}
	else
	{
		*ppv = NULL ;
		return E_NOINTERFACE ;
	}
	reinterpret_cast<IUnknown*>(*ppv)->AddRef() ;
	return S_OK ;
}

ULONG __stdcall CA::AddRef()
{
	return InterlockedIncrement(&m_cRef) ;
}

ULONG __stdcall CA::Release() 
{
	if (InterlockedDecrement(&m_cRef) == 0)
	{
		delete this ;
		return 0 ;
	}
	return m_cRef ;
}


///////////////////////////////////////////////////////////
//
// Class factory
//
class CFactory : public IClassFactory
{
public:
	// IUnknown
	virtual HRESULT __stdcall QueryInterface(const IID& iid, void** ppv) ;         
	virtual ULONG   __stdcall AddRef() ;
	virtual ULONG   __stdcall Release() ;

	// Interface IClassFactory
	virtual HRESULT __stdcall CreateInstance(IUnknown* pUnknownOuter,
	                                         const IID& iid,
	                                         void** ppv) ;
	virtual HRESULT __stdcall LockServer(BOOL bLock) ; 

	// Constructor
	CFactory() : m_cRef(1) {}

	// Destructor
	~CFactory() { cout<<"Class factory:\t\tDestroy self.\n" ;}

private:
	long m_cRef ;
} ;

//
// Class factory IUnknown implementation
//
HRESULT __stdcall CFactory::QueryInterface(const IID& iid, void** ppv)
{    
	if ((iid == IID_IUnknown) || (iid == IID_IClassFactory))
	{
		*ppv = static_cast<IClassFactory*>(this) ; 
	}
	else
	{
		*ppv = NULL ;
		return E_NOINTERFACE ;
	}
	reinterpret_cast<IUnknown*>(*ppv)->AddRef() ;
	return S_OK ;
}

ULONG __stdcall CFactory::AddRef()
{
	return InterlockedIncrement(&m_cRef) ;
}

ULONG __stdcall CFactory::Release() 
{
	if (InterlockedDecrement(&m_cRef) == 0)
	{
		delete this ;
		return 0 ;
	}
	return m_cRef ;
}

//
// IClassFactory implementation
//
HRESULT __stdcall CFactory::CreateInstance(IUnknown* pUnknownOuter,
                                           const IID& iid,
                                           void** ppv) 
{
	cout<<"Class factory:\t\tCreate COMCalc object.\n" ;

	// Can't aggregate.  Don't worry about this for now
	if (pUnknownOuter != NULL)
	{
		return CLASS_E_NOAGGREGATION ;
	}

	// Create component.
	CA* pA = new CA ;
	if (pA == NULL)
	{
		return E_OUTOFMEMORY ;
	}

	// Get the requested interface.
	HRESULT hr = pA->QueryInterface(iid, ppv) ;

	// Release the IUnknown pointer.
	// (If QueryInterface failed, component will delete itself.)
	pA->Release() ;
	return hr ;
}

// LockServer
HRESULT __stdcall CFactory::LockServer(BOOL bLock) 
{
	if (bLock)
	{
		InterlockedIncrement(&g_cServerLocks) ; 
	}
	else
	{
		InterlockedDecrement(&g_cServerLocks) ;
	}
	return S_OK ;
}


///////////////////////////////////////////////////////////
//
// Exported functions
//

//
// Can DLL unload now?
//
STDAPI DllCanUnloadNow()
{
	if ((g_cComponents == 0) && (g_cServerLocks == 0))
	{
		return S_OK ;
	}
	else
	{
		return S_FALSE ;
	}
}

//
// Get class factory
//
STDAPI DllGetClassObject(const CLSID& clsid,
                         const IID& iid,
                         void** ppv)
{
	cout<<"DllGetClassObject:\tCreate class factory.\n" ;

	// Can we create this component?
	if (clsid != CLSID_ClassFactory)
	{
		return CLASS_E_CLASSNOTAVAILABLE ;
	}

	// Create class factory.
	CFactory* pFactory = new CFactory ;  // No AddRef in constructor
	if (pFactory == NULL)
	{
		return E_OUTOFMEMORY ;
	}

	// Get requested interface.
	HRESULT hr = pFactory->QueryInterface(iid, ppv) ;
	pFactory->Release() ;

	return hr ;
}

//
// Server registration
//
STDAPI DllRegisterServer()
{
	return RegisterServer(g_hModule, 
	                      CLSID_ClassFactory,
	                      g_szFriendlyName,
	                      g_szVerIndProgID,
	                      g_szProgID) ;
}


//
// Server unregistration
//
STDAPI DllUnregisterServer()
{
	return UnregisterServer(CLSID_ClassFactory,
	                        g_szVerIndProgID,
	                        g_szProgID) ;
}

///////////////////////////////////////////////////////////
//
// DLL module information
//
BOOL APIENTRY DllMain(HANDLE hModule,
                      DWORD dwReason,
                      void* lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		g_hModule = hModule ;
	}
	return TRUE ;
}
