// Derive a class from CWinApp and override the constructor to
// call SetCurrentHandles(), which sets up various things (like
// the global instance handle) so that the CWinApp derived object
// is properly constructed.
// Then, create a single instance of this CWinApp-derived object.
// Failure to do this causes, among other things, MFC ASSERT()
// failures when trying to use the MFC socket classes, MFC thread
// creation and management routines, or the resource loading
// capabilities of certain MFC classes.
     
class CNTServiceApp : public CWinApp
  {
  public:
    CNTServiceApp(void)
      {
      m_hInstance = (HINSTANCE) ::GetModuleHandle(NULL);
      CWinApp::SetCurrentHandles();
      }
  };
     
CNTServiceApp theApp;

