
#include "calcsdk.h"
#include "fstream.h"
 

#define msg(X) MessageBox(0, "!",X, MB_OK|MB_SYSTEMMODAL)
extern void LockModule(void);

extern void UnlockModule(void);

ofstream out("c:\\out.txt" , ios::out, filebuf::sh_read||filebuf::sh_write );

void DebugPrint(char *c)
{
	out<<c;
} 



STDMETHODIMP 
CalcSDKClassObject::QueryInterface(REFIID riid, void **ppv)
{

    
	if (riid == IID_IClassFactory)
        *ppv = static_cast<IClassFactory*>(this);
    else if (riid == IID_IUnknown)
        *ppv = static_cast<IClassFactory*>(this);
    else if (riid == IID_IOleItemContainer)
        *ppv = static_cast<IOleItemContainer*>(this); 
    else if (riid == IID_IOleContainer)
        *ppv = static_cast<IOleItemContainer*>(this);
    else if (riid == IID_IParseDisplayName)
        *ppv = static_cast<IParseDisplayName*>(this);
    else 
        return (*ppv = 0), E_NOINTERFACE;
    
	reinterpret_cast<IUnknown*>(this)->AddRef();
    return S_OK;
}

STDMETHODIMP_(ULONG) 
CalcSDKClassObject::AddRef(void)
{
#ifndef EXESVC
    LockModule();
#endif
    return 2;
}

STDMETHODIMP_(ULONG) 
CalcSDKClassObject::Release(void)
{
#ifndef EXESVC
    UnlockModule();
#endif
    return 1;
}


COMCalc::COMCalc()
{
m_cRef=0;
out<<"COMCalc Multiple Inherited object (IFinancial and ICalc) created.\n";

ITypeLib *ptl = 0;


	HRESULT hr = LoadRegTypeLib(LIBID_COMCALCLib, 1, 0, 0, &ptl);
    if (SUCCEEDED(hr))
    {
		out<<"Succeeded in loading type library\n";
//		Get the type description for this class's dual interface
//      and store the interface pointer in the m_pTypeInfo data member
        hr=ptl->GetTypeInfoOfGuid(IID_ICalc, &m_pTypeInfo);
		if(FAILED(hr))
		{
			out<<"GetTypeInfoOfGUId failed\n";
		}

        ptl->Release();

    }else
		out<<"Failed in loading type library\n";



}

COMCalc::COMCalc(LPOLESTR lastvalue)
{
char temp[255];

wcstombs(temp,lastvalue, 255);
out<<"Created via moniker, last value is "<<temp<<endl;



}



// IClassFactory methods
STDMETHODIMP 
CalcSDKClassObject::CreateInstance(IUnknown *pUnkOuter, REFIID riid, void **ppv)
{
    if (ppv == 0)
        return E_POINTER;
    *ppv = 0;
    if (pUnkOuter)
        return CLASS_E_NOAGGREGATION;
    COMCalc *pObj = new COMCalc;
    if (!pObj)
        return E_OUTOFMEMORY;
    pObj->AddRef();
    HRESULT hr = pObj->QueryInterface(riid, ppv);
    pObj->Release();
    return hr;
}

STDMETHODIMP 
CalcSDKClassObject::LockServer(BOOL bLock)
{
    if (bLock)
        LockModule();
    else
        UnlockModule();
    return S_OK;
}



// IParseDisplayName methods
// Has to do with Monikers, don't worry about this stuff
// its a whole other article.
STDMETHODIMP 
CalcSDKClassObject::ParseDisplayName(IBindCtx *pbc,
                              LPOLESTR pszDisplayName,
                              ULONG *pchEaten,
                              IMoniker **ppmkOut)
{
	out<<"ParseDisplayName"<<endl;
	cout<<"ParseDislplayName"<<endl;

    *pchEaten = 0;
    if (*pszDisplayName != '!')
        return MK_E_SYNTAX;

    *pchEaten += wcslen(pszDisplayName);

    return CreateItemMoniker(OLESTR("!"), pszDisplayName + 1, ppmkOut);
}


STDMETHODIMP 
CalcSDKClassObject::EnumObjects(DWORD grfFlags, IEnumUnknown **ppenum)
{

    *ppenum = 0;
    return E_NOTIMPL;
}

STDMETHODIMP  
CalcSDKClassObject::LockContainer(BOOL fLock)
{

    return E_NOTIMPL;
}

// IOleItemContainer methods
// Don't worry about this stuff
STDMETHODIMP 
CalcSDKClassObject::GetObject(LPOLESTR pszItem, DWORD dwSpeedNeeded,
                       IBindCtx *pbc,
                       REFIID riid, void **ppv)
{

	
		out<<"getobject"<<endl;
		out<<"calling getobject"<<endl;

		COMCalc *c=new COMCalc(pszItem);
		return c->QueryInterface(riid, ppv);





} 

STDMETHODIMP 
CalcSDKClassObject::GetObjectStorage(LPOLESTR pszItem,
                              IBindCtx *pbc,
                              REFIID riid, void **ppvStorage)
{
    *ppvStorage = 0;
    return MK_E_NOSTORAGE;
}

STDMETHODIMP 
CalcSDKClassObject::IsRunning(LPOLESTR pszItem)
{
	out<<"isrunning() called"<<endl;
	return MK_E_NOOBJECT;
}


STDMETHODIMP 
COMCalc::QueryInterface(REFIID riid, void **ppv)
{
    if (riid == IID_ICalc)
	{
		*ppv = static_cast<ICalc*>(this);
		out<<"QueryInterface: Asked for ICalc: ";
	}
    else if (riid == IID_IFinancial)
	{
        *ppv = static_cast<IFinancial*>(this);
		out<<"QueryInterface: Asked for IFinancial :";
	}
    else if (riid == IID_IUnknown)
	{
        *ppv = static_cast<ICalc*>(this);
		out<<"QueryInterface: Asked for IUnknown :";
	}
	else if (riid == IID_IDispatch && m_pTypeInfo != 0)
	{
		out<<"asked for IDispatch\n";
        *ppv = static_cast<IDispatch*>(this);
	}

	else
	{	
		out<<"QueryInterface: Asked for interface we don't support\n";
		out<<"typeinfo is "<<m_pTypeInfo<<endl;
        return (*ppv = 0), E_NOINTERFACE;
	}

    reinterpret_cast<IUnknown*>(*ppv)->AddRef();
    return S_OK;
}

STDMETHODIMP_(ULONG) 
COMCalc::AddRef(void)
{
	
    if (m_cRef == 0)
        LockModule();

	out<<"COMCALC add ref\n";
    return InterlockedIncrement(&m_cRef);
}

STDMETHODIMP_(ULONG) 
COMCalc::Release(void)
{
    LONG res = InterlockedDecrement(&m_cRef);
    if (res == 0)
    {
		out<<"COMCALC has destroyed itself, ref is 0: ";
		    if (m_pTypeInfo)
			    m_pTypeInfo->Release();
        delete this;
        UnlockModule();
    }
	out<<"COMCALC release\n";
    return res;
}

STDMETHODIMP COMCalc::MortgagePayment(float amount, float percent, int period, float * payment)
{

	float temp_prod=1;
	for(int i=0; i<period; i++)
	{
		temp_prod *= (1+(percent/100));
	}

	*payment =(amount*percent/100)/(1-(1/temp_prod));


	return S_OK;
}

STDMETHODIMP COMCalc::Add(int x, int y, int *r)
{

	*r=x+y;

	return S_OK;
}

STDMETHODIMP COMCalc::Divide(int x, int y, int *r)
{

	*r=x/y;

	return S_OK;
}



// IDispatch methods
STDMETHODIMP 
COMCalc::GetTypeInfoCount(UINT *pcti)
{
    if (pcti == 0)
        return E_POINTER;
    *pcti = 1;
    return S_OK;
}

STDMETHODIMP 
COMCalc::GetTypeInfo(UINT cti, LCID, ITypeInfo **ppti)
{
    if (ppti == 0)
        return E_POINTER;
    if (cti != 0)
        return (*ppti = 0), DISP_E_BADINDEX;
    (*ppti = m_pTypeInfo)->AddRef();
    return S_OK;
}

STDMETHODIMP 
COMCalc::GetIDsOfNames(REFIID riid, OLECHAR **prgpsz, UINT cNames, LCID lcid, DISPID *prgids)
{
//  Forward the call to the m_pTypeInfo that you got
    return m_pTypeInfo->GetIDsOfNames(prgpsz, cNames, prgids);
}

STDMETHODIMP 
COMCalc::Invoke(DISPID id, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS *params, VARIANT *pVarResult, EXCEPINFO *pei, UINT *puArgErr)
{
    return m_pTypeInfo->Invoke(static_cast<IDispatch*>(this),
                               id, wFlags, params, pVarResult, pei, puArgErr);
}


