#include "windows.h"
#include "unknwn.h"
#include "calcsdk.h"
#include "iostream.h"
#include "comcalc_i.c"


#include "MFCStringImpl.h"
#include "windows.h"
using NotMFC::CString;
#include "regkey.h"






LONG g_cLocks = 0;
TCHAR   g_szFileName[MAX_PATH];
OLECHAR g_wszFileName[MAX_PATH];


HRESULT WINAPI CreateObject(REFIID riid, void **ppv)
{

    *ppv = 0;

    COMCalc *pObj = new COMCalc;

    if (!pObj)
        return E_OUTOFMEMORY;

    pObj->AddRef();


    HRESULT hr = pObj->QueryInterface(riid, ppv);
    pObj->Release();

    return hr;
}

void LockModule(void)
{
    InterlockedIncrement(&g_cLocks);
}

void UnlockModule(void)
{
    InterlockedDecrement(&g_cLocks);
}



CalcSDKClassObject g_classfactory;

BOOL WINAPI DllMain(HINSTANCE h, DWORD dwReason, void *)
{

	DebugPrint("COMCAlCSDK in DLL Main.\n");
    if (dwReason == DLL_PROCESS_ATTACH)
    {

		DebugPrint("COMCAlCSDK DLL has just loaded.\n");
        GetModuleFileName(h, g_szFileName, MAX_PATH);
#ifdef UNICODE
        lstrcpy(g_wszFileName, g_szFileName);
#else
        mbstowcs(g_wszFileName, g_szFileName, MAX_PATH);
#endif
    }
    else if (dwReason == DLL_PROCESS_DETACH)
	{

		DebugPrint("COMCAlCSDK DLL has just unloaded.\n");
		  
	}
    return TRUE;
}


STDAPI DllGetClassObject(REFCLSID rclsid,
                         REFIID riid,
                         void **ppv)
{

	DebugPrint("GetCLassobject called.\n");
#if 1
    if (rclsid == CLSID_CalcSDK)
	{
     	DebugPrint("CLSID_CalcSDK asked for.\n");
		return g_classfactory.QueryInterface(riid, ppv);
	}
    else
	{
		DebugPrint("Unrecognized IID asked for.\n");
        return (*ppv = 0), CLASS_E_CLASSNOTAVAILABLE;

	}
#endif

	return 0;

}

STDAPI DllCanUnloadNow(void)
{
    return g_cLocks ? S_FALSE : S_OK;
}


STDAPI DllRegisterServer(void)
{
	CRegKey r;
	
	r.Open(HKEY_CLASSES_ROOT, "CalcSDK.Calc.1");
	r.Write("", "Calc");

	r.Open(HKEY_CLASSES_ROOT, "CalcSDK.Calc.1\\CLSID");
	r.Write("", "{638094E0-758F-11d1-8366-0000E83B6EF3}");
		
		
	r.Open(HKEY_CLASSES_ROOT, "CalcSDK.Calc");
	r.Write("", "Calc");

	r.Open(HKEY_CLASSES_ROOT, "CalcSDK.Calc\\CLSID");
	r.Write("", "{638094E0-758F-11d1-8366-0000E83B6EF3}");

	r.Open(HKEY_CLASSES_ROOT, "CalcSDK.Calc\\CurVer");
	r.Write("", "CalcSDK.Calc.1");


	r.Open(HKEY_CLASSES_ROOT, "CLSID\\{638094E0-758F-11d1-8366-0000E83B6EF3}");
	r.Write("", "CalcSDK Class");

	r.Open(HKEY_CLASSES_ROOT, "CLSID\\{638094E0-758F-11d1-8366-0000E83B6EF3}\\InprocServer32");
	r.Write("", g_szFileName);
	r.Write("ThreadingModel", "Apartment");

	r.Open(HKEY_CLASSES_ROOT, "CLSID\\{638094E0-758F-11d1-8366-0000E83B6EF3}\\ProgID");
	r.Write("", "CalcSDK.Calc.1");

	r.Open(HKEY_CLASSES_ROOT, "CLSID\\{638094E0-758F-11d1-8366-0000E83B6EF3}\\VersionIndependentProgID");
	r.Write("", "CalcSDK.Calc");


	r.Close();

 
	  ITypeLib *ptl = 0;
    HRESULT hr = LoadTypeLib(g_wszFileName, &ptl);
    if (SUCCEEDED(hr))
    {
        hr = RegisterTypeLib(ptl, g_wszFileName, 0);
        ptl->Release();
    }
    return hr;

}

// NOTE:DllUnregisterServer should simply use the helper function
//      Unregister to insert the requisite registry keys.
STDAPI DllUnregisterServer(void)
{

	RegDeleteKey(HKEY_CLASSES_ROOT, "CalcSDK.Calc.1\\CLSID");
	RegDeleteKey(HKEY_CLASSES_ROOT, "CalcSDK.Calc.1");
	RegDeleteKey(HKEY_CLASSES_ROOT, "CalcSDK.Calc\\CLSID");
	RegDeleteKey(HKEY_CLASSES_ROOT, "CalcSDK.Calc\\CurVer");
	RegDeleteKey(HKEY_CLASSES_ROOT, "CalcSDK.Calc");
	RegDeleteKey(HKEY_CLASSES_ROOT, "CLSID\\{638094E0-758F-11d1-8366-0000E83B6EF3}\\InprocServer32");
	RegDeleteKey(HKEY_CLASSES_ROOT, "CLSID\\{638094E0-758F-11d1-8366-0000E83B6EF3}\\VersionIndependentProgID");
	RegDeleteKey(HKEY_CLASSES_ROOT, "CLSID\\{638094E0-758F-11d1-8366-0000E83B6EF3}\\ProgID");
	RegDeleteKey(HKEY_CLASSES_ROOT, "CLSID\\{638094E0-758F-11d1-8366-0000E83B6EF3}");

	    HRESULT hr = UnRegisterTypeLib(LIBID_COMCALCLib, 
                                   1, 
                                   0, 
                                   0, 
                                   SYS_WIN32);
    return hr; 
} 


