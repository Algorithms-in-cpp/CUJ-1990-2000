/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Aug 31 15:02:34 1998
 */
/* Compiler settings for comcalc.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ICalc = {0x638094E5,0x758F,0x11d1,{0x83,0x66,0x00,0x00,0xE8,0x3B,0x6E,0xF3}};


const IID IID_IFinancial = {0x638094E4,0x758F,0x11d1,{0x83,0x66,0x00,0x00,0xE8,0x3B,0x6E,0xF3}};


const IID LIBID_COMCALCLib = {0x638094E1,0x758F,0x11d1,{0x83,0x66,0x00,0x00,0xE8,0x3B,0x6E,0xF3}};


const CLSID CLSID_CalcSDK = {0x638094E0,0x758F,0x11d1,{0x83,0x66,0x00,0x00,0xE8,0x3B,0x6E,0xF3}};


#ifdef __cplusplus
}
#endif

