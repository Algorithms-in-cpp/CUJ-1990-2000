// IUnknown methods

#include "comcalc.h"



class CalcSDKClassObject : public IClassFactory, public IOleItemContainer
{
public:
// IUnknown methods
    STDMETHODIMP QueryInterface(REFIID riid, void **ppv);
    STDMETHODIMP_(ULONG) AddRef(void);
    STDMETHODIMP_(ULONG) Release(void);

// IClassFactory methods
    STDMETHODIMP CreateInstance(IUnknown *pUnkOuter, REFIID riid, void **ppv);
    STDMETHODIMP LockServer(BOOL bLock);

   

// IParseDisplayName methods
    STDMETHODIMP ParseDisplayName(IBindCtx *pbc,
                                  LPOLESTR pszDisplayName,
                                  ULONG *pchEaten,
                                  IMoniker **ppmkOut);
// IOleContainer methods
    STDMETHODIMP EnumObjects(DWORD grfFlags, IEnumUnknown **ppenum);
    
    STDMETHODIMP LockContainer(BOOL fLock);
// IOleItemContainer methods
    STDMETHODIMP GetObject(LPOLESTR pszItem, DWORD dwSpeedNeeded,
                           IBindCtx *pbc, REFIID riid, void **ppv);
    STDMETHODIMP GetObjectStorage(LPOLESTR pszItem, IBindCtx *pbc,
                                  REFIID riid, void **ppvStorage);
    STDMETHODIMP IsRunning(LPOLESTR pszItem);

};
 

class COMCalc: public ICalc, public IFinancial/*, public DICalc*/
{

public:
	LONG        m_cRef;
	ITypeInfo  *m_pTypeInfo;
// IUnknown methods
    STDMETHODIMP QueryInterface(REFIID riid, void **ppv);
    STDMETHODIMP_(ULONG) AddRef(void);
    STDMETHODIMP_(ULONG) Release(void);


	STDMETHOD(MortgagePayment)(float amount, float percent, int period, float * payment);
	STDMETHOD(Add)(int x, int y, int*r);
	STDMETHOD(Divide)(int x, int y, int*r);
	COMCalc();
	COMCalc(LPOLESTR lastvalue);
    

// IDispatch methods
    STDMETHODIMP GetTypeInfoCount(UINT *pcti);
    STDMETHODIMP GetTypeInfo(UINT cti, LCID, ITypeInfo **ppti);
    STDMETHODIMP GetIDsOfNames(REFIID riid, OLECHAR **prgpsz, UINT cNames, LCID lcid, DISPID *prgids);
    STDMETHODIMP Invoke(DISPID id, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS *params, VARIANT *pVarResult, EXCEPINFO *pei, UINT *puArgErr);


};

extern void DebugPrint(char *c);