// Main.cpp
#include "MFCStringImpl.h"
#include "windows.h"

#include <iostream>

using NotMFC::CString;
using std::cout;
const TCHAR* Test(const TCHAR* psz);


#include "regkey.h"
// This test only works in ANSI (not UNICODE) builds
// due to lack of _T() and stream insertion operator

CRegKey r;

/*
REGEDIT4

[HKEY_CLASSES_ROOT\CLSID\{638094E0-758F-11d1-8366-0000E83B6EF3}]
@="CalcSDK Class"

[HKEY_CLASSES_ROOT\CLSID\{638094E0-758F-11d1-8366-0000E83B6EF3}\InprocServer32]
@="C:\\dcom\\comcalc\\calcsdk\\debug\\calcsdk.dll"

[HKEY_CLASSES_ROOT\CLSID\{638094E0-758F-11d1-8366-0000E83B6EF3}\ProgID]
@="CalcSDK.Calc.1"

[HKEY_CLASSES_ROOT\CLSID\{638094E0-758F-11d1-8366-0000E83B6EF3}\VersionIndependentProgID]
@="CalcSDK.Calc"

  ThreadingModel

REGEDIT4

[HKEY_CLASSES_ROOT\CalcSDK.Calc]
@="Calc"

[HKEY_CLASSES_ROOT\CalcSDK.Calc\CLSID]
@="{638094E0-758F-11d1-8366-0000E83B6EF3}"

[HKEY_CLASSES_ROOT\CalcSDK.Calc\CurVer]
@="CalcSDK.Calc.1"

  REGEDIT4

[HKEY_CLASSES_ROOT\CalcSDK.Calc.1]
@="Calc"

[HKEY_CLASSES_ROOT\CalcSDK.Calc.1\CLSID]
@="{638094E0-758F-11d1-8366-0000E83B6EF3}"



*/

int main()
{

r.Open(HKEY_CLASSES_ROOT, "AAAA\\CalcSDK.Calc.1");
r.Write("", "Calc");

r.Open(HKEY_CLASSES_ROOT, "AAAA\\CalcSDK.Calc.1\\CLSID");
r.Write("", "{638094E0-758F-11d1-8366-0000E83B6EF3}");
	
	
r.Open(HKEY_CLASSES_ROOT, "AAAA\\CalcSDK.Calc");
r.Write("", "Calc");

r.Open(HKEY_CLASSES_ROOT, "AAAA\\CalcSDK.Calc\\CLSID");
r.Write("", "{638094E0-758F-11d1-8366-0000E83B6EF3}");

r.Open(HKEY_CLASSES_ROOT, "AAAA\\CalcSDK.Calc\\CurVer");
r.Write("", "CalcSDK.Calc.1");


r.Open(HKEY_CLASSES_ROOT, "AAAA\\{638094E0-758F-11d1-8366-0000E83B6EF3}");
r.Write("", "CalcSDK Class");

r.Open(HKEY_CLASSES_ROOT, "AAAA\\{638094E0-758F-11d1-8366-0000E83B6EF3}");
r.Write("", "CalcSDK Class");

r.Open(HKEY_CLASSES_ROOT, "AAAA\\{638094E0-758F-11d1-8366-0000E83B6EF3}\\InprocServer32");
r.Write("", "C:\\dcom\\comcalc\\calcsdk\\debug\\calcsdk.dll");
r.Write("ThreadingModel", "Apartment");

r.Open(HKEY_CLASSES_ROOT, "AAAA\\{638094E0-758F-11d1-8366-0000E83B6EF3}\\ProgID");
r.Write("", "CalcSDK.Calc.1");

r.Open(HKEY_CLASSES_ROOT, "AAAA\\{638094E0-758F-11d1-8366-0000E83B6EF3}\\VersionIndependentProgID");
r.Write("", "CalcSDK.Calc");


r.Close();








return 1;
   CString str("twenty");
   Test(str);
   CString str2(str);
   CString str3('X', 20);

   cout << str << "\n";
   cout << str2 << "\n";
   cout << str3 << "\n";

   str.Format("sder %d %s", 1, "ss");
   cout << str << "\n";

   CString s("abcdef");
   cout << s.GetLength() << "\n"; // == 6 

   CString s2;
   cout << s2.IsEmpty() << "\n"; // == true

   CString s3("abc");
   s3.Empty();
   cout << s3.GetLength() << "\n"; // == 0

   CString s4("abcdef");
   cout << s4.GetAt(2) << "\n"; //  == 'c'

   CString s5("abc");
   cout << s5[1] << "\n"; // == 'b'
   s5.SetAt(1, 'X');
   cout << s5[1] << "\n"; // == 'X'

   CString s6, s7;        // Empty CString objects
   s6 = "cat";            // s6 == "cat"
   cout << s6 << "\n";
   s7 = s6;               // s6 and s7 each == "cat"
   cout << s7 << "\n";
   s6 = "the " + s6;      // Or expressions
   cout << s6 << "\n";
   s6 = 'x';              // Or just individual characters
   cout << s6 << "\n";

   // example for CString::operator +
   CString s8("abc");
   CString s9("def");
   cout << (s8 + s9 ) << "\n"; // == "abcdef"
   CString s10;
   s10 = CString("abc") + "def" ; // == "abcdef"
   cout << s10 << "\n";

   // example for CString::operator +=
   CString s11("abc");
   cout << ( s11 += "def") << "\n"; // == "abcdef"

   // example for CString Comparison Operators
   CString s12("abc");
   CString s13("abd");
   if (s12 < s13)
      cout << "s12 < 13" << "\n"; // == true Operator is overloaded for both.
   if ("ABC" < s12)
      cout << "ABC < s12" << "\n"; // == true CString and char*
   if (s13 > "abe")
      cout << "s13 > abe" << "\n"; // == false 
   if (s13 == "abd")
      cout << "s13 == abd" << "\n"; // == true

   // example for CString::Compare
   CString s14( "abc" );
   CString s15( "abd" );
   cout << s14.Compare(s15) << "\n"; // == -1 // Compare with another CString.
   cout << s14.Compare("abe") << "\n"; // == -1 // Compare with LPTSTR string.

   // example for CString::CompareNoCase
   CString s16( "abc" );
   CString s17( "ABD" );
   cout << s16.CompareNoCase( s17 ) << "\n"; // == -1 // Compare with a CString.
   cout << s16.Compare( "ABE" )  << "\n"; // == 1 // Compare with LPTSTR string.

   // example for CString::Mid
   CString s18("abcdef");
   cout << s18.Mid(2, 3) << "\n"; //  == _T("cde")

   // example for CString::Left
   CString s19( _T("abcdef") );
   cout << s19.Left(2) << "\n"; //  == _T("ab")

   // example for CString::Right
   CString s20( _T("abcdef") );
   cout << s20.Right(2) << "\n"; //  == _T("ef")

   // example for CString::SpanIncluding
   CString s21( "cabbage" );
   CString s22 = s21.SpanIncluding( "abc" );
   cout << s22 << "\n"; //  == "cabba"
   s22 = s21.SpanIncluding( "xyz" );
   cout << s22.IsEmpty( ) << "\n"; // == true

   // example for CString::MakeUpper
   CString s23( "abc" );
   s23.MakeUpper();
   cout << s23 << "\n"; //  == "ABC"

   // example for CString::MakeLower
   CString s24( "ABC" );
   s24.MakeLower();
   cout << s24 << "\n"; //  == "abc"

   // example for CString::MakeReverse
   CString s25( "abc" );
   s25.MakeReverse();
   cout << s25 << "\n"; //  == "cba"

   // example for CString::Find
   CString s26( "abcdef" );
   cout << s26.Find( 'c' ) << "\n"; //  == 2
   cout << s26.Find( "de" ) << "\n"; //  == 3

   // example for CString::ReverseFind
   CString s27( "abcabc" );
   cout << s27.ReverseFind( 'b' ) << "\n"; //  == 4

   // example for CString::FindOneOf
   CString s28( "abcdef" );
   cout << s28.FindOneOf( "xd" ) << "\n"; //  == 3 // 'd' is first match

   return 0;
}