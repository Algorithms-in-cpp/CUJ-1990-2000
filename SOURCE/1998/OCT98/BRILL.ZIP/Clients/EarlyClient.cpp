#include "windows.h"
#include "iostream.h"

//change path to where your compiled DLL is
#import "..\debug\calcsdk.dll" no_namespace named_guids


main()
{
ICalc * pIc;
int result;

CoInitialize(0);


HRESULT hr=CoCreateInstance(CLSID_CalcSDK,0,CLSCTX_ALL,IID_ICalc,(void**)&pIc);

if(FAILED(hr))
{

	cout<<"Could not create object.  Did you run regsvr32.exe on it?"<<endl;
	CoUninitialize();
	return 0;
}




cout<<"Addition is:"<<pIc->Add(1,2)<<endl;

//this also works

pIc->raw_Add(1,2,&result);
cout<<"Raw Addition is:"<<result<<endl;



CoUninitialize();

return 0;
}