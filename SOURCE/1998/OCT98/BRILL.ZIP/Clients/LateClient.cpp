// LateClient.cpp : Defines the entry point for the console application.
//

#include "windows.h"
#include "iostream.h"

int main(int argc, char* argv[])
{
	
IDispatch * idsp;

CLSID pclsid;
DISPID dispid;
DISPPARAMS dp={NULL,NULL,0,0};
VARIANTARG vargs[2];
VARIANT arg1,arg2,result;

CoInitialize(0); //must have this



//'L' in front of a string constant means UNICODE string.  COM only deals with UNICODE strings
//which have 2 bytes per character instead of one.

CLSIDFromProgID(L"calcsdk.calc", &pclsid);


HRESULT hr = CoCreateInstance(pclsid , NULL, CLSCTX_ALL,
                              IID_IDispatch, (void **)&idsp);


if(FAILED(hr))
{
	cout<<"Failed to create object.  Did you run regsvr32.exe on it?"<<endl;
	CoUninitialize();
	return 0;

}


arg1.vt= VT_BSTR;
arg1.bstrVal = L"1"; //note, I am using strings instead of numbers
					//to demonstrate how the server will convert to
					//the appropriate type automatically.

arg2.vt= VT_BSTR;
arg2.bstrVal = L"2";


#if 0
//here I am passing the appropriate types
//ie. longs.  This works more efficiently
//since the server won't have to convert
//from BSTR's to longs.

arg1.vt= VT_I4;
arg1.lVal = 1; 

arg2.vt= VT_I4;
arg2.lVal = 2;



#endif

vargs[0]=arg1;
vargs[1]=arg2;

dp.rgvarg=vargs;
dp.cArgs = 2;

OLECHAR * name=L"add";
idsp->GetIDsOfNames(IID_NULL, &name, 1, GetUserDefaultLCID(), &dispid);

idsp->Invoke(dispid, IID_NULL, GetUserDefaultLCID(), DISPATCH_METHOD,
             &dp, &result,0,0);


cout<<"Addition is:"<<result.lVal<<endl;


idsp->Release();


CoUninitialize();

return 0;
}

