int CRemoteConnect::telephonyOpen(HWND hWnd, HINSTANCE hInst)
{
    LONG lrc;

    // open the line device and specify this object as callback
    //instance data
    lrc = lineOpen(m_TapiStruct.hTAPI, m_TapiStruct.dwLine,
              &m_TapiStruct.hLine, m_TapiStruct.dwVersionToUse, 0,
              (DWORD)this, LINECALLPRIVILEGE_OWNER,
              LINEMEDIAMODE_DATAMODEM,NULL);
    if (lrc)
        return lrc;

    // bool indicates lineOpen called successfully
    m_TapiStruct.bLineopen = TRUE;

    // get the telephony icon and make it ours
    myDrawTAPIIcon(hWnd);

    // get other telephony configuration info
    lrc = telephonyCaps();
    if (lrc)
        return lrc;

    // receive all possible status messages for the line device
    // and address
    lineSetStatusMessages(m_TapiStruct.hLine, 
        m_TapiStruct.pLinedevcaps->dwLineStates, 
        m_TapiStruct.pLineaddresscaps->dwAddressStates);

    // get modem capabilities            
    lrc = telephonyGetModemCaps();
    if (lrc)
        return lrc;

    // get current modem settings
    lrc = telephonyGetModemSettings();
    if (lrc)
        return lrc;

    // success
    return 0;
} // end procedure (telephony initialize)

