class AFX_EXT_CLASS CRemoteConnect : public CLocalConnect
{
// public interface
public:
    enum MODEM_CONNECTTYPE {MAKECALL,ANSWERCALL,DEFERCALL};
    CRemoteConnect(MODEM_CONNECTTYPE,
        BOOL spawnThreadOnConnect=TRUE, BOOL enableEcho=FALSE);
    virtual ~CRemoteConnect();
    BOOL isModemConnected() { return m_ModemConnected; };
    HANDLE& GetConnectEventHandle() { return m_ConnectEvent; };
    HANDLE& GetDisconnectEventHandle()
    { return m_DisconnectEventHandle; };

// server prepares for next call
    BOOL ReAnswerModem();

// some redefined members
public:
    virtual BOOL PortInitOk() { return m_ModemConnected; }

// TAPI private helper functions <not shown for brevity>
};


