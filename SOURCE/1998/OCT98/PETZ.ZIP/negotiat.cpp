int
CRemoteConnect::telephonyInitialize(HWND hWnd, HINSTANCE hInst)
{
    LONG lrc;
    int i;
    LINEEXTENSIONID extensions;

    // record telephony initialization as commenced
    m_TapiStruct.bInitialized = TRUE;

    // record every logical line for those that support modem data
    for (i=0; (unsigned)i<m_TapiStruct.dwNumLines; i++)
    {

        // negotiate version of TAPI to use
        lrc = lineNegotiateAPIVersion(m_TapiStruct.hTAPI, i, 
                  WIN95TAPIVERSION, WIN95TAPIVERSION, 
                  &m_TapiStruct.dwVersionToUse, &extensions);
        if (lrc)
            continue;

        // record the device to be interrogated
        m_TapiStruct.dwLine = i;

        // get line device caps - on error,
        // terminate initialization
        lrc = mylineGetDevCaps();
        if (lrc)
            return lrc;

        // add this Modem to version compatibility list if it
        // supports data transfers -- get Modem name and Icon for
        // subsequent user display and selection
        if (m_TapiStruct.pLinedevcaps->dwMediaModes &
            LINEMEDIAMODE_DATAMODEM)
            getModemNameandIcon(i);
    } // endfor        
    // <remainder of function not shown for brevity>
}

