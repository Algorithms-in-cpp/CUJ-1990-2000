BOOL CRemoteConnect::installCallback()
{
    // install TAPI callback handler
    // - inform user of re-init error to allow infinite retry
    //   (5sec between attempts)
    // - IF user cancels retry, record cancel (install fails)
    // = IF no modem devices installed, record error
    //   (install fails)
    // Return install pass/fail
    while (lineInitialize(&m_TapiStruct.hTAPI, ghInst,
            m_TapiStruct.CallbackProc =
               (LINECALLBACK) MakeProcInstance(
                  (FARPROC)CRemoteConnect::StaticLineCallBackProc,
                  hInst),
            "TAPIProcess",
            &m_TapiStruct.dwNumLines) == LINEERR_REINIT)
   {
       Sleep (5);
       if (MessageBox(hWnd, "Telephony system is reinitializing \
              - Click Cancel to abort", "Error",
              MB_RETRYCANCEL) ==IDCANCEL)
       {
           displayTapiErrorMessage(
               "User cancelled telephony initialization retry");
           return m_InstallOk=FALSE;
       }
   } // end while (TAPI reinitializing)

   if (m_TapiStruct.dwNumLines == 0)
   {
       displayTapiErrorMessage("No Modem Devices Installed");
       return m_InstallOk=FALSE;
   }
   return m_InstallOk=TRUE;
}

