void FAR PASCAL
CRemoteConnect::StaticLineCallBackProc(DWORD dwDevice,
    DWORD dwMessage, DWORD dwInstance, DWORD dwParam1,
    DWORD dwParam2,DWORD dwParam3)
{
    // invoke member callback from specified user
    // instance parameter
    ((CRemoteConnect*)dwInstance)->
        LineCallBackProc(dwDevice, dwMessage, dwInstance,
            dwParam1, dwParam2, dwParam3);
}

