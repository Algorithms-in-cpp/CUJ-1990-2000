#define MAX_IO_BYTES 4096 // max #bytes for Win32 overlapped I/O

class AFX_EXT_CLASS CLocalConnect
{
// public interface
public:
    CLocalConnect(uint16 portID, BOOL OpenRequested=TRUE,
        BOOL useDefaultThread=TRUE, BOOL echoEnabled=FALSE);
    virtual  ~CLocalConnect();

    enum TTYCommand {DisplayData,ClearScreen};

// default I/O thread function
    static UINT ThreadProc(LPVOID pParam);

// some redefinable functions
    virtual HANDLE SpawnPortThread();
    virtual void StopPortThread();
    virtual BOOL PortInitOk() {  return m_portInitOk; };

// port handle
    HANDLE getPortHandle() { return m_hPort; };

// some async I/O methods
    void putMessage(const CString&);
    void putMessage(const CByteArray& Msg);
    void putMessage(const char*, DWORD len);
    void getMessage(CByteArray& Msg);
  
// sync I/O
    BOOL SyncRead(CByteArray& Msg, DWORD timeout=INFINITE);

// private/protected members <not shown for brevity>
};

