
__QUERYF.HPP    - declaration of type constants
__QUERY.HPP     - main header for Query class
__QUERY.CPP     - implementation of generic Query

SYBASE.HPP      - declaration of Query class for SyBase - SyQuery
                  and other related declarations
SYQUERY.CPP     - implementation of Query for SyBase.

DUMP.HPP        - header of Dump class

SYBASE.CPP      - SyBase specific code, used from SYQUERY.CPP.

Several headers included are not provided. They contained declaration of the 
general purpose class library used in that project. Here is a brief description
what was in that headers.

membuf.h   - class MemBuf - dynamically growing byte array.

list.h     - class LstLink0 - basic class for elements of the list
             class LstList - generic double linked list

dynarray.h - class DynArrayItem - basic class for the elements of the hashed table
             class DynArray - hashed table

error.h    - class ErrorClass - class for error handling

codepg.h   - character string conversion functions (actually project used only
             english and russian languages and it doesn't contain generic
             internationalization).

date.h     - class Date - date

applic.h   - class Application - basic class for the generic application

fstring.h  - template for the FString<size> classes - C string with some common methods

timer.h    - a set of class and functions to measure timing

ctpublic.h - Sybase Client library header.


