#define MAXSTR  128

void printSalesDept()  {
    char name[MAXSTR];
    char birthDay[MAXSTR];
    char phone[MAXSTR];
    Query query("selectPersData");
    Bool fetch;

    query.prepare("SELECT NAME, BIRTHDAY," 
       "PHONE FROM PERSON WHERE DEPT = %s");

    query.open(NULL,"Sales");

    while (fetch = query.fetch())  {
        query.read("%s(NAME)%s(BIRTHDAY)"
        "%s(PHONE)", name, birthDay, phone);
    printf("%s\n%s\n%s\n\n");
    }

    query.close();
}

void updateSmith()  {
    char birthDay[MAXSTR];
    char phone[MAXSTR];
    Query query("updatePerson");

    strcpy(birthDay,"1/1/1970");
    strcpy(phone,"(123)4567890");

    query.prepare("UPDATE PERSON" 
        "SET BIRTHDAY=%s, PHONE=%s"
        "WHERE NAME=%s");
      
    query.execute(NULL,birthDay, phone, 
        "Smith");
}

