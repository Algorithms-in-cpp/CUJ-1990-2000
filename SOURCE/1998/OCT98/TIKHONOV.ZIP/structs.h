struct SQLVAR	{
    short sqltype;
    unsigned short sqllen;
    char* sqldata;
    short* sqlind;
    short sqlname_length;
    char sqlname [30];
};

struct SQLDA	{
    char sqldaid[8];
    long sqldabc;
    short sqln;
    short sqld;       // number of fields
    SQLVAR sqlvar[1];
};

#define SQLDA_LENGTH(n) \
    (sizeof (SQLDA) + (n-1) * sizeof (SQLVAR))

