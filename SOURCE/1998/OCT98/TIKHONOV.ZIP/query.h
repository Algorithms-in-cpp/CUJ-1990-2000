class Query {
public :
    Query(const char* name = 0);
    virtual ~Query() {};

    virtual Result prepare(char* queryText, Bool useAsIs = FALSE);
    virtual Result open(char* queryText, ...);
    virtual Result execute(char* queryText, ...);
    virtual Result read(char* format, ...);
    virtual Bool fetch();
    virtual Bool fetch(char* format, ...);
    virtual Result close();
};

