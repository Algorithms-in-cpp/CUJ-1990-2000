class DbSQLDA {
public :
    Bool hasRecord;
    Dump sqlda;
    DbRecord record;
    DbSQLDA() { hasRecord = TRUE; }

    SQLDA* getSQLDA() { return (SQLDA*)sqlda.data; }
    operator SQLDA*() { return (SQLDA*)sqlda.data; }
    SQLVAR& operator[](int i) { return getSQLDA()->sqlvar[i]; }
    void create(SQLDA* s, Bool withData = FALSE);

    // Creates copy of SQLDA <s> with record buffer if desired
    DbSQLDA& operator<<(SQLVAR* var);

    // Adds SQLVAR <var> (and data in record buffer too)
    void synchronize();
    void clear();
    void extend(int delta);
};

void DbSQLDA::extend(int delta) {
    int used;
    if (sqlda.size > 0)
        used = SQLDA_LENGTH(getSQLDA()->sqld) + 
               delta*sizeof(SQLVAR);
    else
        used = SQLDA_LENGTH(delta);
    if (used > sqlda.size)
        if (sqlda.size > 0) {
            Dump swap(sqlda);
            sqlda.create(used + FIELD_GRAN*sizeof(SQLVAR));
            memcpy(sqlda.data, swap.data, swap.size);
            getSQLDA()->sqln += delta;
        }
        else {
            sqlda.create(used + FIELD_GRAN*sizeof(SQLVAR));
            getSQLDA()->sqln = delta;
        }
    else
        getSQLDA()->sqln += delta;
}

DbSQLDA& DbSQLDA::operator<<(SQLVAR* var) {
    extend(1);
    if (hasRecord)
        record << var;
    (*this)[getSQLDA()->sqld++] = *var;
    return *this;
}

void DbSQLDA::synchronize() {
    if (!hasRecord)
        return;

    SQLDA* s = getSQLDA();
    for (int i = 0; i < s->sqld; i++) {
        DbRecordField* field = record.get(i);
        s->sqlvar[i].sqldata = field->text;
        s->sqlvar[i].sqlind = &field->nullind;
    }
}

void DbSQLDA::create(SQLDA* s, Bool withData) {
    sqlda.create(SQLDA_LENGTH(s->sqld));
    memcpy(sqlda.data,s,sqlda.size);
    getSQLDA()->sqln = s->sqld;
    if (withData) {
        hasRecord = TRUE;
        record.create(s);
        synchronize();
    }
    else
        hasRecord = FALSE;
}

void DbSQLDA::clear() {
    sqlda.destroy();
    record.clear();
    hasRecord = TRUE;
}

