#ifndef __TREE_H__
#define __TREE_H__

#include <rw/cstring.h>
#include <rw/tstack.h>
#include <rw/tvslist.h>

template<class T>
class TValTreeNode {

  public:

    TValTreeNode();
    TValTreeNode(TValTreeNode *left, TValTreeNode *right, const T& data);
    ~TValTreeNode();

    TValTreeNode  *left();
    TValTreeNode  *right();

    T             data() const;

    TValTreeNode    *left_, *right_;
    T               data_;

  protected:

  private:

};

template<class T>
class TValTree {

  public:

    TValTree();
    ~TValTree();

    void insert(const T& t);
//    void remove(const T& t);

    TValTreeNode<T>   *root()
    { return root_; }

  protected:

  private:

    TValTreeNode<T>    *root_;

};

template<class T>
class TValTreeIteratorNode {

  public:

    TValTreeIteratorNode(TValTreeNode<T> *node, int stateIndex)
      : node_(node), stateIndex_(stateIndex) { }

    TValTreeNode<T>    *node_;
    int             stateIndex_;

};

template<class T>
class TValTreeIterator {

  public:

    enum IteratorOrder {
      InOrder           = 1,
      PreOrder          = 2,
      PostOrder         = 3,
      ReverseInorder    = 4,
      ReversePreOrder   = 5,
      ReversePostOrder  = 6
    };

    TValTreeIterator(const TValTree<T>& tree,
                     const RWCString& iterOrder);
    ~TValTreeIterator();

    int   operator++();
    T     key() const;

    void  reset(const TValTree<T>& tree,
                const RWCString& iterOrder);

  protected:

  private:

    RWTStack<TValTreeIteratorNode<T> *, RWTValSlist<TValTreeIteratorNode<T> *> > stack_;
    RWCString       iterOrder_;

};

template<class T>
TValTreeNode<T>::TValTreeNode()
: left_(0)
, right_(0)
, data_(T())
{

}

template<class T>
TValTreeNode<T>::TValTreeNode(TValTreeNode<T> *left, TValTreeNode<T> *right,
                              const T& data)
: left_(left)
, right_(right)
, data_(data)
{

}

template<class T>
TValTreeNode<T>::~TValTreeNode()
{
  left_ = right_ = 0;
}

template<class T>
TValTreeNode<T> *
TValTreeNode<T>::left()
{
  return left_;
}

template<class T>
TValTreeNode<T> *
TValTreeNode<T>::right()
{
  return right_;
}

template<class T>
T
TValTreeNode<T>::data() const
{
  return data_;
}

/*
 * class TValTree
 */

template<class T>
TValTree<T>::TValTree()
: root_(0)
{

}

template<class T>
TValTree<T>::~TValTree()
{
  root_ = 0;
}

template<class T>
void
TValTree<T>::insert(const T& t)
{
  if(root_ == 0) {
    root_ = new TValTreeNode<T>(0, 0, t);
    return;
  }

  TValTreeNode<T>  *curr = root_;

  while(1) {
    if(t < curr->data_) {
      if(curr->left_) {
        curr = curr->left_;
        continue;
      }
      curr->left_ = new TValTreeNode<T>(0, 0, t);
      break;
    }
    if(curr->right_) {
      curr = curr->right_;
      continue;
    }
    curr->right_ = new TValTreeNode<T>(0, 0, t);
    break;
  }
}

/*
 * class TValTreeIterator
 */

template<class T>
TValTreeIterator<T>::TValTreeIterator(const TValTree<T>& tree, const RWCString& iterOrder)
: iterOrder_(iterOrder)
{
  TValTreeNode<T>    *root = ((TValTree<T> *)&tree)->root();

  if(root != 0) {
    stack_.push(new TValTreeIteratorNode<T>(root, 0));
  }
}

template<class T>
TValTreeIterator<T>::~TValTreeIterator()
{

}

template<class T>
void
TValTreeIterator<T>::reset(const TValTree<T>& tree, const RWCString& iterOrder)
{
  iterOrder_ = iterOrder;

  stack_.clear();

  TValTreeNode<T>    *root = ((TValTree<T> *)&tree)->root();

  if(root != 0) {
    stack_.push(new TValTreeIteratorNode<T>(root, 0));
  }
}

template<class T>
int
TValTreeIterator<T>::operator++()
{
  if(stack_.isEmpty())
    return 0;

  RWBoolean    done = FALSE;

  while(!stack_.isEmpty()) {
    TValTreeIteratorNode<T>  *tmp = stack_.top();

    switch(iterOrder_[(unsigned)tmp->stateIndex_++]) {
      case '1' :  // go left
        if(tmp->node_->left())
          stack_.push(new TValTreeIteratorNode<T>(tmp->node_->left(), 0));
        break;
      case '2' : // visit
        return 1;
      case '3' : // go right
        if(tmp->node_->right())
          stack_.push(new TValTreeIteratorNode<T>(tmp->node_->right(), 0));
        break;
      case '4' : // finished
        TValTreeIteratorNode<T> *top = stack_.pop();
        delete top;
        break;
    }
  }

  return 0;
}

template<class T>
T
TValTreeIterator<T>::key() const
{
  if(!stack_.isEmpty())
    return stack_.top()->node_->data();

  return T();
}




#endif

