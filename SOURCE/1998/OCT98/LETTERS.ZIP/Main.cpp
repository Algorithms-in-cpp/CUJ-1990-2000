
#include "tree.h"

RWCString   inOrder("1234");
RWCString   preOrder("2134");
RWCString   postOrder("1324");
RWCString   revInOrder("3214");
RWCString   revPreOrder("2314");
RWCString   revPostOrder("3124");

int
main(void)
{
  TValTree<int>     tree;

  tree.insert(3);
  tree.insert(1);
  tree.insert(2);
  tree.insert(6);
  tree.insert(4);
  tree.insert(5);

  TValTreeIterator<int>   iter(tree, inOrder);

  cout << "InOrder" << endl;
  while(++iter) {
    cout << iter.key() << " ";
  }

  cout << endl << endl;

  cout << "PreOrder" << endl;
  iter.reset(tree, preOrder);
  while(++iter) {
    cout << iter.key() << " ";
  }

  cout << endl << endl;

  cout << "PostOrder" << endl;
  iter.reset(tree, postOrder);
  while(++iter) {
    cout << iter.key() << " ";
  }

  cout << endl << endl;

  cout << "RevInOrder" << endl;
  iter.reset(tree, revInOrder);
  while(++iter) {
    cout << iter.key() << " ";
  }

  cout << endl << endl;

  cout << "revPreOrder" << endl;
  iter.reset(tree, revPreOrder);
  while(++iter) {
    cout << iter.key() << " ";
  }

  cout << endl << endl;

  cout << "revPostOrder" << endl;
  iter.reset(tree, revPostOrder);
  while(++iter) {
    cout << iter.key() << " ";
  }

  cout << endl << endl;

  cout << "revPostOrder" << endl;
  iter.reset(tree, "21334");
  while(++iter) {
    cout << iter.key() << " ";
  }

  cout << endl;

  return 0;
}

