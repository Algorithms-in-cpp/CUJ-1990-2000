#if !defined(MULTICAST_H)
#define MULTICAST_H
#include <windows.h>
#include <vector>
#include <strstream>
#include <set>
#include <assert.h>

template <unsigned> class NumType {};
typedef NumType<0> Args0;// Use to overload on values 0, 1, 2, etc.
typedef NumType<1> Args1;// typedef'ed for readability and to
typedef NumType<2> Args2;// appease VC 5.0
typedef NumType<3> Args3;
typedef NumType<4> Args4;
typedef NumType<5> Args5;
typedef NumType<6> Args6;
typedef NumType<7> Args7;

class DefType{};// Minimal default type
// ArgC<T>::Count is 1 for all types except DefType.
template <typename T> struct ArgC{enum {Count=1};};
template <> struct ArgC<DefType>{enum {Count=0};};

// The interface to the Event class
template <class IObserver> class AbstractEvent
{
   public:
	  typedef AbstractEvent<IObserver> Self;
      virtual ~AbstractEvent(){}

      // Call the observer's event function
      virtual void Invoke(IObserver * p) const = 0;

	  // Compare two events, events are equal if they invoke the same function.
	  //   It is reasonably safe to make this a member function because there is no
	  //   easy way to accidentally construct an object of this class.
	  bool operator==(const Self & rhs) const
	  {
		  return Value()== rhs.Value();
	  }
   protected:
      typedef void (DefType:: * ValueType)();
      virtual ValueType Value() const = 0;
};

// Event class holding zero to n parameters, for brevity n = 2;
template <class IObserver, typename ObserverFunc,
          typename P1 = DefType, typename P2 = DefType,
          typename P3 = DefType, typename P4 = DefType,
          typename P5 = DefType, typename P6 = DefType,
          typename P7 = DefType> class Event :
   public AbstractEvent<IObserver>
{
   public:
      // Construct an event with any number of parameters
      explicit Event(ObserverFunc Func,
                     const P1& v1 = P1(), const P2& v2 = P2(),
                     const P3& v3 = P3(), const P4& v4 = P4(),
                     const P5& v5 = P5(), const P6& v6 = P6(),
                     const P7& v7 = P7()):
         // Take a copy of the parameters for the event
         pFunc(Func), p1(v1), p2(v2), p3(v3), p4(v4), p5(v5), p6(v6), p7(v7){}

      // Call an observer, by delegating to the correct implementation
      virtual void Invoke(IObserver * pObserver) const
      {
         const size_t ArgCount = ArgC<P1>::Count + ArgC<P2>::Count +
								 ArgC<P3>::Count + ArgC<P4>::Count +
								 ArgC<P5>::Count + ArgC<P6>::Count +
								 ArgC<P7>::Count;
         if (pObserver != NULL)
         {
            InvokeImpl(pObserver, NumType<ArgCount>());
         }
      }
   protected:
      // Provides a means of comparing events
      virtual ValueType Value() const
      {  
         return reinterpret_cast<ValueType>(pFunc);
      }

      // These functions will pass the parameters to the observer.
      // Only one function is instantiated, and only it is legal.
      // We are effectively overloading on the value of the ArgCount.
      template <class T> void InvokeImpl(T * pObserver, Args0) const
      {
         (void)(pObserver->*pFunc)();// Call with 0 parameters
      }
      template <class T> void InvokeImpl(T * pObserver, Args1) const
      {
         (void)(pObserver->*pFunc)(p1);// Call with 1 parameter
      }
      template <class T> void InvokeImpl(T * pObserver, Args2) const
      {
         (void)(pObserver->*pFunc)(p1, p2);// Call with 2 parameters
      }
      template <class T> void InvokeImpl(T * pObserver, Args3) const
      {
          (void)(pObserver->*pFunc)(p1, p2, p3);// Call with 3 parameters
      }
      template <class T> void InvokeImpl(T * pObserver, Args4) const
      {
          (void)(pObserver->*pFunc)(p1, p2, p3, p4);// Call with 4 parameters
      }
      template <class T> void InvokeImpl(T * pObserver, Args5) const
      {
          (void)(pObserver->*pFunc)(p1, p2, p3, p4, p5);// Call with 5 parameters
      }
      template <class T> void InvokeImpl(T * pObserver, Args6) const
      {
          (void)(pObserver->*pFunc)(p1, p2, p3, p4, p5, p6);// Call with 6 parameters
      }
      template <class T> void InvokeImpl(T * pObserver, Args7) const
      {
          (void)(pObserver->*pFunc)(p1, p2, p3, p4, p5, p6, p7);// Call with 7 parameters
      }
   private:// The member function to call and the parameters to pass.
      const ObserverFunc pFunc; const P1 p1; const P2 p2;
      const P3 p3; const P4 p4; const P5 p5; const P6 p6; const P7 p7;
};

// For thread safety, this automatically locks and unlocks an object.
template <class Lockable> class AutoLock
{
   public:
      AutoLock(Lockable & obj) :
         m_obj(obj) {m_obj.Lock();}
      ~AutoLock()   {m_obj.Unlock();}
   private:
      AutoLock(); // Stop default construction
      Lockable & m_obj;
};

// The class provides a smart critical section for providing thread safety. 
class CritSec
{
	public:
		void Lock(){EnterCriticalSection(&m_sec);}
		void Unlock(){LeaveCriticalSection(&m_sec);}

		CritSec() {InitializeCriticalSection(&m_sec);}
		~CritSec() {DeleteCriticalSection(&m_sec);}
		CRITICAL_SECTION m_sec;
};

typedef AutoLock<CritSec> TSLock; // Thread safe lock

template <class IObserver> class Multicast
{
   typedef Multicast<IObserver> Self;
   typedef std::multiset<IObserver*,std::less<IObserver*> > Observers;
   typedef std::vector<AbstractEvent<IObserver> *> Events;

   public:
      virtual bool OnActive(){return true;} // 1st observer registered
      virtual void OnInactive(){} // Last observer deregistered

      // Called by observers to register
      bool Advise(IObserver * pObserver) 
      {  
         TSLock write_lock(m_Lock);
         m_Observers.insert(pObserver);
         if (m_Observers.size() == 1)// Tell the subject that the 1st
         {                           // observer wants to register.
             if (!OnActive())        // The subject can refuse to
             {                       // accept the registration.
                m_Observers.clear(); 
                return false;        
             }
         }
         return true;
      }

      // Called by observers to deregister
      void Unadvise(IObserver * pObserver)
      {  
         TSLock write_lock(m_Lock);
         m_Observers.erase(pObserver);
         if (m_Observers.empty()) // Tell the subject that the last
         {                        // observer has deregistered
             OnInactive();
         }
      }

      // A window per object is inefficient but it works.
      Multicast() : m_hWnd(UniqueWindow()) {}

      // Facilitate copying of derived objects
      Multicast(const Self &) : m_hWnd(UniqueWindow()) {}
      Self & operator =(const Self &) {return *this;};

      virtual ~Multicast()
      {
         for (size_t i = 0; i < m_Events.size(); ++i)
         {
            delete m_Events[i];
         }
         (void) DestroyWindow(m_hWnd);
      }

      // Called by the subject to fire events to the observers.
      // The repetition gives the appearance of two template functions
      // FireEvent(Func, [P1 .. Pn])
      // FireSingleEvent(Func, [P1 .. Pn])
      //
      // Func: member function pointer - the observers' function.
      // P1 .. Pn: between 0 & n parameters to pass to the observers.
      template <typename FuncType>
         void FireEvent(FuncType Func)
      {
         typedef Event<IObserver, FuncType> EventType;
         DoEvent(new EventType(Func));
      }

	  template <typename FuncType, typename P1>
         void FireEvent(FuncType Func, const P1& p1)
      {
         typedef Event<IObserver, FuncType, P1> EventType;
         DoEvent(new EventType(Func, p1));
      }

	  template <typename FuncType, typename P1, typename P2>
              void FireEvent(FuncType Func, const P1& p1, const P2& p2)
      {
          typedef Event<IObserver, FuncType, P1, P2> EventType;
          DoEvent(new EventType(Func, p1, p2));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3>
              void FireEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3> EventType;
          DoEvent(new EventType(Func, p1, p2, p3));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3, typename P4>
              void FireEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3, const P4& p4)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3, P4> EventType;
          DoEvent(new EventType(Func, p1, p2, p3, p4));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3, typename P4, typename P5>
              void FireEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3, const P4& p4, const P5& p5)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3, P4, P5> EventType;
          DoEvent(new EventType(Func, p1, p2, p3, p4, p5));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3, typename P4, typename P5, typename P6>
              void FireEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3, const P4& p4, const P5& p5, const P6& p6)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3, P4, P5, P6> EventType;
          DoEvent(new EventType(Func, p1, p2, p3, p4, p5, p6));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3, typename P4, typename P5, typename P6, typename P7>
              void FireEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3, const P4& p4, const P5& p5, const P6& p6, const P7& p7)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3, P4, P5, P6, P7> EventType;
          DoEvent(new EventType(Func, p1, p2, p3, p4, p5, p6, p7));
      }

      // FireSingleEvent will attempt to collapse multiple events into a single event.
      template <typename FuncType>
         void FireSingleEvent(FuncType Func)
      {
         typedef Event<IObserver, FuncType> EventType;
         DoSingleEvent(new EventType(Func));
      }

	  template <typename FuncType, typename P1>
         void FireSingleEvent(FuncType Func, const P1& p1)
      {
         typedef Event<IObserver, FuncType, P1> EventType;
         DoSingleEvent(new EventType(Func, p1));
      }

	  template <typename FuncType, typename P1, typename P2>
              void FireSingleEvent(FuncType Func, const P1& p1, const P2& p2)
      {
          typedef Event<IObserver, FuncType, P1, P2> EventType;
          DoSingleEvent(new EventType(Func, p1, p2));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3>
              void FireSingleEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3> EventType;
          DoSingleEvent(new EventType(Func, p1, p2, p3));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3, typename P4>
              void FireSingleEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3, const P4& p4)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3, P4> EventType;
          DoSingleEvent(new EventType(Func, p1, p2, p3, p4));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3, typename P4, typename P5>
              void FireSingleEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3, const P4& p4, const P5& p5)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3, P4, P5> EventType;
          DoSingleEvent(new EventType(Func, p1, p2, p3, p4, p5));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3, typename P4, typename P5, typename P6>
              void FireSingleEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3, const P4& p4, const P5& p5, const P6& p6)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3, P4, P5, P6> EventType;
          DoSingleEvent(new EventType(Func, p1, p2, p3, p4, p5, p6));
      }

	  template <typename FuncType, typename P1, typename P2, typename P3, typename P4, typename P5, typename P6, typename P7>
              void FireSingleEvent(FuncType Func, const P1& p1, const P2& p2, const P3& p3, const P4& p4, const P5& p5, const P6& p6, const P7& p7)
      {
          typedef Event<IObserver, FuncType, P1, P2, P3, P4, P5, P6, P7> EventType;
          DoSingleEvent(new EventType(Func, p1, p2, p3, p4, p5, p6, p7));
      }
      
   protected:
      // Create a new window based on a unique window class. 
      HWND UniqueWindow() const
      {  
          std::ostrstream Name;
          Name << "Multicast" << this << '\0'; // Unique class name
          WNDCLASSA wc = {0,WndProc,0,0,GetModuleHandle(NULL),0,0,0,0,Name.str()};
          (void) RegisterClassA(&wc);
          HWND hWnd = CreateWindowA(wc.lpszClassName,0,0,0,0,0,0,0,0,wc.hInstance,0);
          assert(hWnd != NULL);
          return hWnd;
      }

      // The bulk of the work is deligated to DoEvent and DoSingleEvent
      void DoEvent(AbstractEvent<IObserver> * pEvent)
      {
         TSLock write_lock(m_Lock);

         if (m_Events.empty())
         {
            // PostMessage is a Windows specific mechansim to call us back asynchronously.
            PostMessage(m_hWnd, WM_USER+100, 0, (DWORD)this);
         }
         m_Events.push_back(pEvent);
      }

      void DoSingleEvent(AbstractEvent<IObserver> * pEvent)
      {
          TSLock write_lock(m_Lock);
          Events::iterator i;

          // Search for a pre-existing event
          for (i = m_Events.begin(); i != m_Events.end(); ++i)
          {
              if (**i == *pEvent)  // If event is already scheduled.
              {
                  const AbstractEvent<IObserver> * pOldEvent = *i;
                  *i = pEvent;  // Replace old event with latest event
                  delete pOldEvent;
                  break;
              }
          }
          if (i == m_Events.end())
          {
              DoEvent(pEvent);
          }
      }

      // This function is called by the operating system asynchronously.
      static LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
      {
         if (msg != WM_USER+100)
         {
            return DefWindowProc(hWnd, msg, wParam, lParam);
         }
         ((Self*)lParam)->AsyncCall();
         return 0;
      }

      // This will invoke all outstanding events.
      // It is called asynchronously and only from one place - so inline is appropriate.
      inline void AsyncCall()
      {
         TSLock write_lock(m_Lock);

         // Invoke each event for each observer, then delete it.
         for (size_t i = 0; i < m_Events.size(); ++i)
         {
            const AbstractEvent<IObserver> * pEvent = m_Events[i];

            for (Observers::iterator ppObserver = m_Observers.begin(); ppObserver != m_Observers.end(); ++ppObserver)
            {
               pEvent->Invoke(*ppObserver);
            }
            delete pEvent;
         }
         m_Events.clear();
      }
      
   private:
      HWND       m_hWnd;     // Window handle to enable an async call.
      CritSec    m_Lock;     // Thread safe protection for:
      Events     m_Events;   // A collection of events to invoke.
      Observers  m_Observers;// A collection of registered observers.
};
#endif // MULTICAST_H
