#if !defined(STDAFX_H)
#define STDAFX_H

// The following is required by ATL
#include <atlbase.h>
extern CComModule _Module;
#include <atlcom.h>


// The following would normally be generated automatically
// from an interface description written in IDL.
EXTERN_C const IID IID_IExampleEvents;
class IExampleEvents : public IUnknown
{
    public:
        STDMETHOD(OnChange)() = 0;
};

EXTERN_C const IID IID_IExample;
EXTERN_C const CLSID CLSID_Example;
class IExample : public IUnknown
{
    public:
        STDMETHOD(get_Something)(/*[out, retval]*/ long *pVal) = 0;
        STDMETHOD(put_Something)(/*[in]*/ long newVal) = 0;
};


#endif // STDAFX_H

