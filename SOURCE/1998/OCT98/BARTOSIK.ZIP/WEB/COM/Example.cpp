// This code is incomplete and is provided for illustrative purposes.
// 
// There are two interfaces:
//    IExample which has a 'Something' property.
//    IExampleEvents which has a function 'OnChange' that takes no parameters.
//

#include "stdafx.h" // Declares IExample and IExampleEvents
#include "ATLCpEx.h"
#include "Example.h"

#include <atlimpl.cpp>

BEGIN_OBJECT_MAP(ObjectMap)
   OBJECT_ENTRY(CLSID_Example, CExample)
END_OBJECT_MAP()

CComModule _Module;



CExample::CExample() :
   m_Something(0)
{}

STDMETHODIMP CExample::get_Something(long * pVal)
{
    *pVal = m_Something; 
    
	return S_OK;
}

STDMETHODIMP CExample::put_Something(long newVal)
{
    m_Something = newVal;

    // Inform the observers of the change.
    FireSingleEvent(IExampleEvents::OnChange); //DIFFERENT

    // An alternative
    // -- if we wanted to pass the new value as a parameter to an event function
    //
    // FireSingleEvent(IExampleEvents::OnNewValue, m_Something);
    
	return S_OK;
}


