#ifndef __EXAMPLE_H_
#define __EXAMPLE_H_

#include "resource.h"

// Include ATLCpEx to support type safe events
#include "ATLCpEx.h" //DIFFERENT

class ATL_NO_VTABLE CExample : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CExample, &CLSID_Example>,
	public IConnectionPointContainerImpl<CExample>,
// Derive from IConnectionPointImplEx instead of IConnectionPointImpl
// The normal ATL method is to derive from IConnectionPointImpl<CExample, &IID_IExampleEvents>
	public IConnectionPointImplEx<CExample, IExampleEvents, &IID_IExampleEvents>, //DIFFERENT
	public IExample
{
    BEGIN_COM_MAP(CExample)
       COM_INTERFACE_ENTRY(IExample)
       COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
    END_COM_MAP()

    BEGIN_CONNECTION_POINT_MAP(CExample)
       CONNECTION_POINT_ENTRY((IID_IExampleEvents))
    END_CONNECTION_POINT_MAP()

    public:
        DECLARE_REGISTRY_RESOURCEID(IDR_EXAMPLE)

        CExample();

        // IExample:
        STDMETHOD(get_Something)(/*[out, retval]*/ long *pVal);
        STDMETHOD(put_Something)(/*[in]*/ long newVal);

    private:
        long m_Something;
};

#endif //__EXAMPLE_H_
