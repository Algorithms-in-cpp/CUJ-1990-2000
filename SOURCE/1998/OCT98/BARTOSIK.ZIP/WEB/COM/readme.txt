The following files are provided:

ATLCpEx.h       -- An implementation of IConnectionPointImplEx which is heavily based on the muiltcast class
                   this can be used as a replacement for IConnectionPointImpl
                   it is much easier to use, is type safe and does not require
                   a wizard to generate code for it.


The following files contain only a 3 lines of code that 
differ from the "normal" ATL based implementations.
Those lines are marked with a comment "//DIFFERENT".

Example.cpp     -- Typical ATL implementation file, but with code to fire (collapsed) events.

Example.h       -- Typical ATL header file for a class which fires events.

resource.h      -- Included for completeness

stdafx.h        -- Included for completeness
