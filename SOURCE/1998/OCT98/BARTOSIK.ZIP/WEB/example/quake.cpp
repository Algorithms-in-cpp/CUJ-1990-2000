#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <iostream>
#include <assert.h>
#include "Multicast.h"


// The interface supported by all earth quake monitors. 
struct IQuake
{
    virtual void Warning(double Magnitude) {};
    virtual void Malfunction() {};
};

// An example Earth Quake Monitor class.
class QuakeMonitor : public Multicast<IQuake>
{
   public:
      bool Process()
      {
         std::cout << std::endl << std::endl;
         std::cout << "Enter magnitude of earth quake (0.0 to 7.0)." << std::endl;
         std::cout << "(Q to quit, -1 for malfunction)" << std::endl;

         double Magnitude;
         std::cin >> Magnitude;

         if (std::cin.fail() || std::cin.eof())
         {
            return false;
         }

         if (Magnitude < 0.0)
         {
            // These events will be coalsced.
            std::cout << "The sensor is repeated triggering," << std::endl
                      << "  but Multicast can collapse equalivant events into a single event." << std::endl;  

             
            FireSingleEvent(IQuake::Malfunction);
            FireSingleEvent(IQuake::Malfunction);
            FireSingleEvent(IQuake::Malfunction);
            FireSingleEvent(IQuake::Malfunction);
         }
         else
         {
            FireEvent(IQuake::Warning, Magnitude);
         }

         return true;
      }
         
   protected:
      virtual bool OnActive()
      {
         std::cout << ">Quake monitor: modem connected." << std::endl;  
         // If modem does not connect return false.
         return true;
      }

      virtual void OnInactive()
      {
         std::cout << ">Quake monitor: modem disconnected." << std::endl;  
      }
};


class FireService : public IQuake
{
   public:
      FireService(Multicast<IQuake> & rQuake) :
         m_rQuake(rQuake)
      {
         // Monitor the quake advisory service.
         assert(m_rQuake.Advise(this));
      }

      ~FireService()
      {
         // Disconnect from the quake advisory service.
         m_rQuake.Unadvise(this);
      }

      // Process an earth quake warning.
      virtual void Warning(double Magnitude)
      {
         if (Magnitude >= 2.0 && Magnitude < 3.0)
         {
            std::cout << ">Fire service is on alert." << std::endl;
         }
         else
         {
            if (Magnitude >= 3.0)
            {
               std::cout << ">Fire service is on the streets." << std::endl;
            }
         }
      }
    private:
       Multicast<IQuake> & m_rQuake;
};


class PoliceService : public IQuake
{
   public:
      PoliceService(Multicast<IQuake> & rQuake) :
         m_rQuake(rQuake)
      {
         assert(m_rQuake.Advise(this));
      }

      ~PoliceService()
      {
         m_rQuake.Unadvise(this);
      }

      // Process an earth quake warning.
      virtual void Warning(double Magnitude)
      {
         if (Magnitude > 2.5 && Magnitude < 4.0)
         {
            std::cout << ">Police are on alert." << std::endl;
         }
         else
         {
            if (Magnitude >= 4.0)
            {
               std::cout << ">Police are on the streets." << std::endl;
            }
         }
      }
   private:
      Multicast<IQuake> & m_rQuake;
};


class Government : public IQuake
{
   public:
      Government(Multicast<IQuake> & rQuake) :
            m_rQuake(rQuake)
      {
         assert(m_rQuake.Advise(this));
      }

      ~Government()
      {
         m_rQuake.Unadvise(this);
      }

      // Process an earth quake warning.
      virtual void Warning(double Magnitude)
      {
         if (Magnitude > 5.0)
         {
            std::cout << ">Government calls out national guard." << std::endl;
         }
      }
   private:
      Multicast<IQuake> & m_rQuake;
};

class ResearchInstitute : public IQuake
{
   public:
      ResearchInstitute(Multicast<IQuake> & rQuake) :
         m_rQuake(rQuake)
      {
         assert(m_rQuake.Advise(this));
      }

      ~ResearchInstitute()
      {
         m_rQuake.Unadvise(this);
      }

      // Process an earth quake warning.
      virtual void Warning(double Magnitude)
      {
         std::cout << ">Earth quake of magnitude " << Magnitude << " recorded." << std::endl;
      }

      virtual void Malfunction()
      {
         std::cout << ">Repair sensors." << std::endl;
      }

   private:
      Multicast<IQuake> & m_rQuake;
};

static void ProcessMessages()
{
   // Process outstanding Asynchronous Procedure Calls.
   SleepEx(0, TRUE);
   
   // Process outstanding messages.
   MSG msg;
   while(PeekMessage(&msg,NULL,NULL,NULL,PM_REMOVE))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   } 
}

void main()
{
   std::cout
     << "Author: Mark Bartosik" << std::endl
     << "        mbartosik@yahoo.com" << std::endl
     << std::endl
     << "Demonstration of the 'observer' pattern, also called" << std::endl
     << "'publish-subscribe' or 'multicast'." << std::endl
     << std::endl
     << "This program simulates how unrelated observers" << std::endl
     << "react to events generated by the a single subject." << std::endl
     << "The subject is an earth quake monitoring station," << std::endl
     << "the observers are various Californian authorities." << std::endl
     << "None of the observers know of the existance of the others." << std::endl
     << "Each of the observers will react differently depending on" << std::endl
     << "the magnitude of the earth quake and the event fired." << std::endl
     << std::endl;

    // The Subject
    // The subject will pass events its observers.
    QuakeMonitor  LosAnglesQMStation;

    // The Observers
    // Each observer will be observing the LosAngles Quake Monitoring Station.
    // None of the observers know of the existance of the others.
    // Each observer
    FireService         LosAnglesFireService(LosAnglesQMStation);
    PoliceService       LAPD(LosAnglesQMStation);
    ResearchInstitute   Berkly(LosAnglesQMStation);
    Government          CaliforniaGovernment(LosAnglesQMStation);

    // The message / event loop
    while (LosAnglesQMStation.Process())
    {
       ProcessMessages();
    }
}
