template<class T, ptrdiff_t N>
class Array
    {
public:
    ~Array()
        {
        delete [] array_;
        }
    Array()
            :
            array_(new T[N]),
            length_(N)
        {
        }
    Array(Array const &that)
            :
            array_(new T[N]),
            length_(N)
        {
        for (ptrdiff_t i(0); i < N; ++i)
            array_[i] = that.array_[i];
        }
    Array &operator=(Array const &that)
        {
        if (this != &that)
            {
            length_ = that.length_;
            for (ptrdiff_t i(0); i < N; ++i)
                array_[i] = that.array_[i];
            }
        return *this;
        }
    T &operator[](ptrdiff_t i)
        {
        if (i >= length_)
            {
            ptrdiff_t const new_length(i + 1);
            T *new_array(new T[new_length]);
            for (i = 0; i < length_; ++i)
                new_array[i] = array_[i];
            length_ = new_length;
            delete [] array_;
            array_ = new_array;
            }
        return array_[i];
        }
    T const &operator[](ptrdiff_t const i) const
        {
        return array_[i];
        }
    T *begin()
        {
        return array_;
        }
    T const *begin() const
        {
        return array_;
        }
private:
    T *array_;
    ptrdiff_t length_;
    };
     
     
