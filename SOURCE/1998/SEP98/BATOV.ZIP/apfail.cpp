void foo(Object* obj)
{
   Object* tmp = obj;
   tmp->something();
}
void func()
{
   Object* obj = new Object;
   foo(obj);
   obj->something();
}

void foo(auto_ptr<Object> obj)
{
   auto_ptr<Object> tmp = obj;
   tmp->something();

   // tmp owns the Object data
   // and deletes them when goes
   // out of visibility scope.
}
void func()
{
   auto_ptr<Object> obj = new Object;
   foo(obj);

   // Object data has been deleted
   // within foo().
   // obj points nowhere!

   obj->something(); // A problem.
}
