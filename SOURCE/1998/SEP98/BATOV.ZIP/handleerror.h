#include "include/handle.h"

HandleError HandleError::no_error(0);

// max of 16 bits
HandleError HandleError:: unknown(65535); 

uint
HandleError::_allocate()
{
   static uint next = 0;
   return ++next;
}
