//*********************************************************
// Copyright (c) 1998 by Warren Ward. Permission is granted
// to use this source code as long as this copyright notice
// appears in all source files that now include it.
//*********************************************************

void Cryptor::Weak_Transform_Char( unsigned char & Target )
    {
    int                 Counter = 0;
    unsigned char       Crypto  = '\0';
    unsigned long int   Out_A   = 0x00000000;

    // Cycle the LFSR eight times to get eight pseudo-
    // random bits. Assemble these into a single random 
    // character (Crypto).
    for ( Counter = 0; Counter < 8; Counter++ )
        {
        if ( m_LFSR_A & 0x00000001 )
            {
            // The least-significant bit of LFSR A is 
            // "1". XOR LFSR A with its feedback mask.
            m_LFSR_A = 
                ( 
                ( m_LFSR_A ^ ( m_Mask_A >> 1 ) ) | 
                m_Rot1_A 
                );
            Out_A = 0x00000001;
            
            }   // end if ( m_LFSR_A . . .
        else
            {
            // The LSB of LFSR A is "0". 
            // Rotate the LFSR contents once.
            m_LFSR_A = 
                ( 
                ( m_LFSR_A >> 1 ) & 
                m_Rot0_A 
                );
            Out_A = 0x00000000;
            
            }   // end else

        // Rotate the output bit into Crypto.
        //
        Crypto = ( ( Crypto << 1 ) | ( Out_A ) );

        }   // end for ( Counter . . .

    // XOR the resulting character with the 
    // input character to encrypt/decrypt it.
    Target = ( Target ^ Crypto );

    return;
    }

