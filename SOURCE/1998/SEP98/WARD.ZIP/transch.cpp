//**************************************************************
// Copyright (c) 1998 by Warren Ward. Permission is granted to
// use this source code as long as this copyright notice appears
// in all source files that now include it.
//**************************************************************

void Cryptor::Transform_Char( unsigned char & Target )
    {
    int                     Counter = 0;
    unsigned char           Crypto  = '\0';
    unsigned long int       Out_B   = ( m_LFSR_B & 0x00000001 );
    unsigned long int       Out_C   = ( m_LFSR_C & 0x00000001 );

    // Cycle the LFSRs eight times to get eight pseudo-
    // random bits. Assemble these into a single random 
    // character (Crypto).
    for ( Counter = 0; Counter < 8; Counter++ )
        {
        if ( m_LFSR_A & 0x00000001 )
            {
            // The least-significant bit of LFSR A is 
            // "1". XOR LFSR A with its feedback mask.
            m_LFSR_A = 
                ( 
                ( m_LFSR_A ^ ( m_Mask_A >> 1 ) ) | 
                m_Rot1_A 
                );
            
            // Clock shift register B once.
            if ( m_LFSR_B & 0x00000001 )
                {
                // The LSB of LFSR B is "1". 
                // XOR LFSR B with its feedback mask.
                m_LFSR_B = 
                    ( 
                    ( m_LFSR_B ^ ( m_Mask_B >> 1 ) ) | 
                    m_Rot1_B 
                    );
                Out_B = 0x00000001;
                }
            else
                {
                // The LSB of LFSR B is "0". Rotate 
                // the LFSR contents once.
                m_LFSR_B = 
                    ( 
                    ( m_LFSR_B >> 1) & 
                    m_Rot0_B 
                    );
                Out_B = 0x00000000;
                }
        }   // end if
        else
            {
            // The LSB of LFSR A is "0". 
            // Rotate the LFSR contents once.
            m_LFSR_A = ( ( m_LFSR_A >> 1 ) & m_Rot0_A );

            // Clock shift register C once.
            if ( m_LFSR_C & 0x00000001 )
                {
                // The LSB of LFSR C is "1". 
                // XOR LFSR C with its feedback mask.
                m_LFSR_C = 
                    ( 
                    ( m_LFSR_C ^ ( m_Mask_C >> 1 ) ) | 
                    m_Rot1_C 
                    );
                Out_C = 0x00000001;
                }   // end if
            else
                {
                // The LSB of LFSR C is "0". Rotate 
                // the LFSR contents once.
                m_LFSR_C = 
                    ( ( m_LFSR_C >> 1 ) & m_Rot0_C );
                Out_C = 0x00000000;
                }   // end else
            
            }   // end else

        // XOR the output from LFSRs B and C and rotate it 
        // into the right bit of Crypto.
        Crypto = ( ( Crypto << 1 ) | ( Out_B ^ Out_C ) );

        }   // end for ( Counter . . .

    // XOR the resulting character with the 
    // input character to encrypt/decrypt it.
    Target = ( Target ^ Crypto );

    return;
    }

