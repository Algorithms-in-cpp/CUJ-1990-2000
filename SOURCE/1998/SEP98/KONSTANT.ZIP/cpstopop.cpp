void CPort::StopOp(){
    if (IsConn()){
        _pData->_bGoOn = FALSE ;
        SetCommMask(_pData->_hPort,0);
        DoneReading();                 //avoid event deadlock
        WaitForSingleObject(_pThr->m_hThread, INFINITE);
        _pThr = 0 ;                //_pThr = flag, if thread runs
        PurgeComm(_pData->_hPort, PURGE_TXABORT|PURGE_RXABORT|
                  PURGE_TXCLEAR|PURGE_RXCLEAR);
        EscapeCommFunction(_pData->_hPort,CLRDTR);
    };
};
