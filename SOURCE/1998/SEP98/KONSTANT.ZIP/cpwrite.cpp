BOOL CPort::Write(const char* p, int nLen){
    DWORD dwWritten;    
    if (!IsConn()) return FALSE;
    if (!WriteFile(_pData->_hPort, p, (DWORD)nLen, &dwWritten,
                   &_pData->_olWrite) &&
            ERROR_IO_PENDING == GetLastError()) {
        if (WaitForSingleObject(_pData->_olWrite.hEvent,1000))
            dwWritten =  0;
        else{
            GetOverlappedResult(_pData->_hPort,&_pData->_olWrite,
                                &dwWritten,FALSE);
            _pData->_olWrite.Offset += dwWritten ;
        };
    };
    return TRUE;
};

