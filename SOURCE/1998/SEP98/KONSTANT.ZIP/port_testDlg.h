// port_testDlg.h : header file
//
#include "cport.h"
/////////////////////////////////////////////////////////////////////////////
// CPortTestDlg dialog

class CPortTestDlg : public CDialog
{
// Construction
public:
	CPortTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPortTestDlg)
	enum { IDD = IDD_PORT_TEST_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPortTestDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL


// Implementation
protected:
	LRESULT OnPortMsg(WPARAM w, LPARAM l);
	void OnClear(void);
	void OnSend(void);
	HICON m_hIcon;
	CEdit		m_edit;
	CListBox	m_list;
	CPort*		m_pPort;


	// Generated message map functions
	//{{AFX_MSG(CPortTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void ProcessPortData(char*);
};
