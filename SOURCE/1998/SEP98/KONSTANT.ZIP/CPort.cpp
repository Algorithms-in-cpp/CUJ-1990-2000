#include "stdafx.h"
#include "cport.h"

#define ASCII_XON	0x11
#define ASCII_XOFF	0x13

int const CErr::nNameLen = 30  ;

void CErr::SetCName(char* szSrc,char* szDest){
int i ;
	if ( ! szDest) szDest = szCName ;
	if ( !  szSrc)  szSrc = "CErr";
	memcpy(szDest,szSrc,i = min(nNameLen-1,strlen(szSrc)+1));
	szDest[i] = (char)0;
};


CErr::CErr(char* szInitIn ){
	bIsOk = TRUE ;
	SetCName(szInitIn);
};

void CErr::ShowErr(char * szMsg, char * szFile, int nLine, int nCode){
char* sz = new char[512],szWinErr[200];
char szFname[_MAX_FNAME];
char szExt[_MAX_EXT];

	if (! szFile) szFile = __FILE__;//THIS_FILE ;
	bIsOk = FALSE ;
	_splitpath(szFile,0,0,szFname,szExt);

	if (nCode)
			FormatMessage(	FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
							0, nCode, LANG_NEUTRAL, szWinErr, 0, 0);
		else 
			strcpy(szWinErr,"None");
		
																			
	sprintf(sz,"User:\t%s\nWin:\t%s\nClass:\t%s\nFile:\t%s%s\nLine:\t%i\nTime:\t%i",
			szMsg,szWinErr,szCName,szFname,szExt,nLine,GetTickCount());
	MessageBox(NULL,sz,"Error !",MB_OK|MB_ICONSTOP);
	delete[] sz;
};


CPortData::CPortData(CWnd* pWnd, UINT uMsg) : CErr("CPortData"),_pWnd(pWnd), _uMsg(uMsg) {
	_hPort = 0 ;
	_bGoOn = FALSE ;
	memset(&_olWrite,0,sizeof(OVERLAPPED));
	memset(&_olRead,0,sizeof(OVERLAPPED));
	if (	(!(int)(_hEvNot = CreateEvent(0, TRUE, TRUE, 0)))			||
			(!(int)(_olWrite.hEvent = CreateEvent(0, TRUE, FALSE, 0)))	||
			(!(int)(_olRead.hEvent = CreateEvent(0, TRUE, FALSE, 0))) )
		Err("Event Creation");
};

CPortData::~CPortData(){
	if (	!(CloseHandle(_hEvNot))			||
			!(CloseHandle(_olWrite.hEvent))	||
			!(CloseHandle(_olRead.hEvent)))
		Err("Event Destruction");
};	



BOOL	CPort::SetDCB(){
CWinApp* pApp = AfxGetApp();
DCB dcb;
BOOL bDTRDSR,bRTSCTS,bXONXOFF ;
int nParity,nStopBits;

	dcb.DCBlength = sizeof(DCB);
	if (!GetCommState(_pData->_hPort,&dcb)){
		Err("GetCommState");
		return FALSE;
	};

	dcb.DCBlength = sizeof(DCB);
	dcb.XonChar = ASCII_XON;
	dcb.XoffChar = ASCII_XOFF;
	dcb.XonLim = 100;
	dcb.XoffLim = 100;
	dcb.fBinary = TRUE;
	dcb.fParity = TRUE;
	dcb.BaudRate	= pApp->GetProfileInt("Communication","Baud",19200); 
	dcb.ByteSize	= pApp->GetProfileInt("Communication","DataBits",7);  

	bDTRDSR		= (BOOL)(LPCTSTR)pApp->GetProfileInt("Communication","DTRDSR",0);  
	dcb.fOutxDsrFlow = bDTRDSR;
	dcb.fDtrControl = bDTRDSR ? DTR_CONTROL_HANDSHAKE : DTR_CONTROL_ENABLE;
	
	bRTSCTS		= (BOOL)(LPCTSTR)pApp->GetProfileInt("Communication","RTSCTS",0);  
	dcb.fOutxCtsFlow = bRTSCTS;
	dcb.fRtsControl = bRTSCTS ? RTS_CONTROL_HANDSHAKE : RTS_CONTROL_ENABLE;

	bXONXOFF	= (BOOL)(LPCTSTR)pApp->GetProfileInt("Communication","XONXOFF",1);    
	dcb.fInX	= dcb.fOutX = bXONXOFF;

	nParity		= pApp->GetProfileInt("Communication","Parity",1); 
	switch (nParity)	{
		case 0: dcb.Parity = NOPARITY; break;
		case 1: dcb.Parity = EVENPARITY; break;
		case 2: dcb.Parity = ODDPARITY; break;
		case 3: dcb.Parity = MARKPARITY; break;
		case 4: dcb.Parity = SPACEPARITY; break;
		default: ASSERT(FALSE);
	}

	nStopBits	= pApp->GetProfileInt("Communication","StopBits",0);   
	switch (nStopBits)	{
		case 0: dcb.StopBits = ONESTOPBIT; break;
		case 1: dcb.StopBits = ONE5STOPBITS; break;
		case 2: dcb.StopBits = TWOSTOPBITS; break;
		default: ASSERT(FALSE);
	}

	if (!SetCommState(_pData->_hPort,&dcb)){
		Err("SetCommState");
		return FALSE;
	};

	return TRUE;
};

BOOL	CPort::InitPort(const char* szPort){
COMMTIMEOUTS	cto = {0,0,0,0,0};
	cto.ReadIntervalTimeout = 0xFFFFFFFF ;
	cto.WriteTotalTimeoutConstant = 5000 ;

	if ((_pData->_hPort = CreateFile(szPort, GENERIC_READ|GENERIC_WRITE,0,0,
						OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED
						,0)) == (HANDLE) -1 ){
		Err("CreateFile");
		return FALSE ;
	}

	if (!SetCommMask(_pData->_hPort, EV_RXCHAR) ||
		!SetupComm(_pData->_hPort, 4096, 4096)	||
		!SetCommTimeouts(_pData->_hPort, &cto)) {
			Err("Port config");
			return FALSE;
	}

	if (! SetDCB() ){
		Err("SetDCB");
		return FALSE;
	};

	return  TRUE	;
};


CPort::CPort(const char* szPort, CWnd* pWnd, UINT uMsg) : CErr("CPort"),
			_pData(new CPortData(pWnd, uMsg)), _pThr (0) {
	InitPort(szPort);
};

CPort::~CPort(){
	StopOp();
	CloseHandle(_pData->_hPort);
	delete _pData;
};


int		CPort::Read(char* p,int nMax){
DWORD	dwErr,dwLen ;
COMSTAT	comstat;	

	if (!IsConn()) 	return 0;
	if (!ClearCommError(_pData->_hPort,&dwErr,&comstat)) {
		Err("ClearCommError");
		return 0;
	};
	
	if (dwLen = min((DWORD)nMax,comstat.cbInQue)){
		if (!ReadFile(_pData->_hPort,p,dwLen,&dwLen, &_pData->_olRead))
			if (ERROR_IO_PENDING == GetLastError()) {
				if (WaitForSingleObject(_pData->_olRead.hEvent,1000)){
						dwLen =  0;
				}	else{
						
						GetOverlappedResult(_pData->_hPort,&_pData->_olRead,
											&dwLen,FALSE);
						_pData->_olRead.Offset += dwLen  ;
					};
			} else 
				dwLen = 0 ;
	};
	if (!dwLen) DoneReading();
	return dwLen;
};


BOOL	CPort::Write(const char* p,int nLen){
DWORD dwWritten;	
	if (!IsConn()) 	return FALSE;
	if (!WriteFile(_pData->_hPort,p,(DWORD)nLen, &dwWritten, &_pData->_olWrite) &&
		ERROR_IO_PENDING == GetLastError()) {
		if (WaitForSingleObject(_pData->_olWrite.hEvent,1000))
				dwWritten =  0;
			else{
				GetOverlappedResult(_pData->_hPort,&_pData->_olWrite,
									&dwWritten,FALSE);
				_pData->_olWrite.Offset += dwWritten ;
		};
	};
	return TRUE;
};

void	CPort::DoneReading(){
	if (!SetEvent(_pData->_hEvNot)) Err("SetEvent");
};

void	CPort::StartOp(){
	if (!IsConn()){
		if (!SetCommMask(_pData->_hPort, EV_RXCHAR)) {
			Err("Port config");
			return;
		}
		_pData->_bGoOn = TRUE ;
		PurgeComm(_pData->_hPort,	PURGE_TXABORT|PURGE_RXABORT|
									PURGE_TXCLEAR|PURGE_RXCLEAR);
		if ((_pThr = AfxBeginThread(PortFunc,this,
									THREAD_PRIORITY_BELOW_NORMAL))==NULL)
				Err("AfxBeginThread, port error !");
		EscapeCommFunction(_pData->_hPort,SETDTR);
	};
};

void	CPort::StopOp(){
	if (IsConn()){
		_pData->_bGoOn = FALSE ;
		SetCommMask(_pData->_hPort,0);
		DoneReading();						//avoid event deadlock
		WaitForSingleObject(_pThr->m_hThread,INFINITE);
		_pThr = 0 ;							//_pThr = flag, if thread runs 
		PurgeComm(_pData->_hPort,	PURGE_TXABORT|PURGE_RXABORT|
									PURGE_TXCLEAR|PURGE_RXCLEAR);
		EscapeCommFunction(_pData->_hPort,CLRDTR);
	};
};


void CPort::Flush(){
	if (IsConn()){
		if (!FlushFileBuffers(_pData->_hPort))
			Err("Flush");
	};
};



UINT	CPort::PortFunc(PVOID pv){
CPort*		pPort = (CPort*) pv;
OVERLAPPED	ol ;
DWORD		dwMask, dwTransfer;

	memset(&ol,0,sizeof(OVERLAPPED));
	if ((ol.hEvent = CreateEvent(0,TRUE,FALSE,0)) == NULL){
		pPort->Err("CreateEvent");
		return 1;
	}

	while (pPort->_pData->_bGoOn){

		dwMask = 0 ;
		if (!WaitCommEvent(pPort->_pData->_hPort,&dwMask,&ol) &&
				ERROR_IO_PENDING == GetLastError()){
			GetOverlappedResult(pPort->_pData->_hPort, &ol, &dwTransfer, TRUE);
			ol.Offset += dwTransfer ;
		};

		if ((dwMask & EV_RXCHAR) == EV_RXCHAR ){
			ResetEvent(pPort->_pData->_hEvNot);
			((CWnd*)pPort->_pData->_pWnd)->PostMessage(	WM_SERIAL_PORT,
														(WPARAM)pPort,
														(LPARAM)EV_RXCHAR);
			WaitForSingleObject(pPort->_pData->_hEvNot,INFINITE);
		};

	};
	
	CloseHandle(ol.hEvent);
	
	return 0;
};







