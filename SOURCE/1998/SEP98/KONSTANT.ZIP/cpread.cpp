int CPort::Read(char* p,int nMax){
    DWORD    dwErr, dwLen;
    COMSTAT  comstat;    

    if (!IsConn()) return 0;
    if (!ClearCommError(_pData->_hPort,&dwErr,&comstat)) {
        Err("ClearCommError");
        return 0;
    };
    
    if (dwLen = min((DWORD)nMax,comstat.cbInQue)){
        if (!ReadFile(_pData->_hPort, p, dwLen, &dwLen,
                      &_pData->_olRead))
            if (ERROR_IO_PENDING == GetLastError()) {
                if (WaitForSingleObject(_pData->_olRead.hEvent,
                                        1000)){
                    dwLen =  0;
                }
                else{
                    GetOverlappedResult(_pData->_hPort,
                                        &_pData->_olRead,
                                        &dwLen,FALSE);
                    _pData->_olRead.Offset += dwLen  ;
                };
            }
            else 
                dwLen = 0 ;
    };
    if (!dwLen) DoneReading();
    return dwLen;
};
