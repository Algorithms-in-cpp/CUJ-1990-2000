void CPort::StartOp(){
    if (!IsConn()){
        if (!SetCommMask(_pData->_hPort, EV_RXCHAR)){
            Err("Port config");
            return;
        }
        _pData->_bGoOn = TRUE ;
        PurgeComm(_pData->_hPort, PURGE_TXABORT|PURGE_RXABORT|
                  PURGE_TXCLEAR|PURGE_RXCLEAR);
        if ((_pThr = AfxBeginThread(PortFunc, this,
                         THREAD_PRIORITY_BELOW_NORMAL))==NULL)
            Err("AfxBeginThread, port error !");
        EscapeCommFunction(_pData->_hPort,SETDTR);
    };
};

