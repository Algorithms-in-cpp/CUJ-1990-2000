BOOL    CPort::InitPort(const char* szPort){

    COMMTIMEOUTS cto =              {0,0,0,0,0};
    cto.ReadIntervalTimeout =       0xFFFFFFFF ;
    cto.WriteTotalTimeoutConstant = 5000 ;

    if ((_pData->_hPort =
           CreateFile(szPort, GENERIC_READ | GENERIC_WRITE, 0, 0,
               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL |
                   FILE_FLAG_OVERLAPPED,0)) == (HANDLE) -1 ){
        Err("CreateFile");
        return FALSE ;
    }

    if (!SetCommMask(_pData->_hPort, EV_RXCHAR) ||
        !SetupComm(_pData->_hPort, 4096, 4096)  ||
        !SetCommTimeouts(_pData->_hPort, &cto)) {
            Err("Port config");
            return FALSE;
    }

    if (! SetDCB() ){
        Err("SetDCB");
        return FALSE;
    };

    return  TRUE;
};


