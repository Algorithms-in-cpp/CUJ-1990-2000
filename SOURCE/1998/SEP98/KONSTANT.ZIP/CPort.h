#if !defined(_CPort_)
#define _CPort_

#define WM_SERIAL_PORT (WM_USER+3)


class CErr {         //base error handling class
protected :
	BOOL	bIsOk;       // safe state ?
	char	szCName[30]; // name of the derived class

	static int const nNameLen  ;

	void SetCName(char* = 0,char* = 0 );
	CErr(char*);
	void ShowErr(char*,char* = NULL ,int = 0, int = 0 );       //report error

	CErr()						{SetCName();ShowErr("Default-Constuctor");};
	CErr& operator=(CErr& bad)	{SetCName();ShowErr("operator =");return *this;};
	virtual ~CErr()				{};

public :
					char*	GetCName()		{return szCName;};
					operator BOOL()			{return IsOk();};  //bool conversion
	virtual void	Reset()					{bIsOk = TRUE;};   //reset from error
	virtual BOOL	IsOk()					{return bIsOk;};   // check state

};

#define Err(sz) ShowErr(sz,__FILE__,__LINE__)



class CPort ;

class	CPortData : public CErr {

	volatile HANDLE	_hPort;
	volatile CWnd*	_pWnd;
	volatile HANDLE	_hEvNot;
	volatile BOOL	_bGoOn;

	OVERLAPPED		_olWrite,_olRead;
	UINT			_uMsg;

	CPortData(CWnd* pWnd, UINT uMsg);
	~CPortData();	

	friend class CPort;
};



class CPort : public CErr {
	CPortData*	_pData;
	CWinThread*	_pThr;

	BOOL	SetDCB();
	BOOL	InitPort(const char*);
	void	DoneReading();

	static UINT PortFunc(PVOID); //thread function, must be static 
	
public:
	CPort(const char* szPort, CWnd* pWnd, UINT uMsg);
	~CPort();

	int		Read(char*,int);
	BOOL	Write(const char*,int);
	void	Flush();

	BOOL	IsConn()				{return (BOOL)_pThr;};
	void	StartOp();
	void	StopOp();
};

#endif