========================================================================
       MICROSOFT FOUNDATION CLASS LIBRARY : port_test
========================================================================



The acccompanying project is a simple MFC application, that can read and write to the serial port, and it is provided as an example for the use of the CPort class.
To use it start hyperterminal (windows accesories) on one machine and set the  connection profile : 
from the menu item FIle | properties choose a port, then select

bits per second  = 19200 
DataBits = 7  
Flow Control = XONXOFF       
Parity   = Even 
StopBits = 1   

On the other machine run port_test.exe. 
In port_test.exe there are two data windows named "Received" and "For transmission". The first one shows every line that is sent from the other computer. The "For transmission" edit box can contain multiple lines (Control+enter, to start a new one). When all the data you wane to send is input in that edit box press the "Send" button. When you want to clear the two data windows press the "Clear" button.
The code for the dialog is in port_testDlg.cpp and port_testDlg.h 

The included files are the standard ones that visual studio will create.

Port data reading is in CPortTestDlg::OnPortMsg(...) and the data writing on CPortTestDlg::OnSend(). The processing (in our case just displaying) of incoming data is in CPortTestDlg::ProcessPortData(...).
The file port_test.ini should be placed in the win95 dir, and it contains configuration data for the port, (parity, data bits e.t.c.). It is an easy way to change the configuration of the port although configuration changes can be made to CPort::SetDCB(). 





