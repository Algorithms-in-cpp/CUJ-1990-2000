template <class T, int SPACE>
{
    //...
    Array(int FirstDimension...);
};
     
template <class T, int SPACE>
Array<T, SPACE>::Array(int FirstDimension...)
{
    va_list Args;
    va_start(Args, FirstDimension);
    size_t LowerOrderDims[SPACE - 1];
    for (int i = 0; 
         i != SPACE - 1 && 
             (LowerOrderDims[i] = 
                 va_arg(Args, int)) > 0;
         ++i)
        ;       // do nothing (all job done 
                // in the loop)
    bool Ok = i == SPACE - 1 && 
              va_arg(Args, int) == -1; 
    va_end(Args);
    if (!Ok) 
    {
        // error handling goes here
    }
    data = new Array<T, SPACE-1>[
               dim = FirstDimension]; 
    for (i = 0; i < dim; ++i)
        data[i].init(LowerOrderDims);
}

