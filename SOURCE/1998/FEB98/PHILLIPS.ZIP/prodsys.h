#include <stdio.h>
#include <stdlib.h>
#include <string.h>
     
#define L 200
#define LIMIT 10000
#define RULES_FILE "rulebase.sch"
#define CONTEXT    "whatever you want"
     
int fire_rule(char *, int);
int get_next_word(char *, char *, int *); 
int is_a_duplicate(char *, char *);
int is_a_hit(char *, char *);
int lowest_number(int *);
int production_system(char *);
int read_a_rule(int, char *);
