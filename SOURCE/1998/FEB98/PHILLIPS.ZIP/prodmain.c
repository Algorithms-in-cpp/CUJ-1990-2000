#include "prodsys.h"
void a_user_function();
     
int main()
{
   a_user_function();
   return(1);
}  /* ends main */
     
void a_user_function()
{
 char context[L];
     
 strcpy(context, CONTEXT);
     
 production_system(context);
     
 printf("\n\nTHE END");
 printf("\nThe context is \n%s",
        context);
}
