// Define a hash map with an integer as a key
// and a pointer to an integer as the value.
hash_map<int,int*,int_hash_function> hashIPtrMap;

// Insert the test data into the map.
hashIPtrMap[0] = new int(4);
hashIPtrMap[1] = new int(3);
hashIPtrMap[2] = new int(2);
hashIPtrMap[3] = new int(1);
hashIPtrMap[4] = new int(0);

// Define an iterator and find a few of the values.
// hash_map<int,int*,int_hash_function>::iterator iptrItr;

if ( (iptrItr = hashIPtrMap.find(2)) != hashIPtrMap.end() )
    cout << "hashIPtrMap[2]=" << *(iptrItr->second) << endl;
else
    cout << "hashIPtrMap[2] not found!!" << endl;

if ( (iptrItr = hashIPtrMap.find(9)) != hashIPtrMap.end() )
    cout << "hashIPtrMap[9]=" << *(iptrItr->second) << endl;
else
    cout << "hashIPtrMap[9] not found!!" << endl;

// Iterate over all elements in the map and delete the memory
for ( iptrItr = hashIPtrMap.begin();
    iptrItr != hashIPtrMap.end(); iptrItr++ )
    delete iptrItr->second;
