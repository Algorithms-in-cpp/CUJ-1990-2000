hash_multiset<int, int_hash_function> hashMultiSet;

hashMultiSet.insert(115);
hashMultiSet.insert(116);
hashMultiSet.insert(116);
hashMultiSet.insert(116);
hashMultiSet.insert(117);

cout << "  Count of 116 should be 3" << endl;
cout << "    count(116)="
    << hashMultiSet.count(116) << endl;
cout << endl;
