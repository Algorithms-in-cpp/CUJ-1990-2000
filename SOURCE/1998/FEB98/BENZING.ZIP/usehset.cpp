// Define a hash set and insert a few items.
hash_set<int, int_hash_function, equal_to<int> > hashSet;

hashSet.insert(11);
hashSet.insert(12);
hashSet.insert(13);
hashSet.insert(14);
hashSet.insert(14);
hashSet.insert(15);

cout << "Count of items=" << hashSet.count()
	<< endl;
