// Define a hash multimap and an iterator.
hash_multimap<int, int, int_hash_function> hashMultiMap;

pair<hash_multimap<int, int,
    int_hash_function>::iterator, bool> mposItr;

// Insert several items into the map.
mposItr = hashMultiMap.insert(pair<int,int>(5, 22));
mposItr = hashMultiMap.insert(pair<int,int>(6, 29));
mposItr = hashMultiMap.insert(pair<int,int>(6, 30));
mposItr = hashMultiMap.insert(pair<int,int>(6, 31));
mposItr = hashMultiMap.insert(pair<int,int>(6, 32));
mposItr = hashMultiMap.insert(pair<int,int>(6, 34));
mposItr = hashMultiMap.insert(pair<int,int>(7, 35));

// Output the counts of the given values.
cout << "  Count of 5 should be 1 and"
    " count of 6 should be 5: " << endl;
cout << "    count(5)=" << hashMultiMap.count(5) << endl;
cout << "    count(6)=" << hashMultiMap.count(6) << endl;

