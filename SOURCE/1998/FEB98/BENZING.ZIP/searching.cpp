// Define a hash map with an integer as a key
// and a pointer to an integer as the value.
hash_map<int,int,int_hash_function> hashIPtrMap;

// Insert the test data into the map.
hashIPtrMap[0] = 4;
hashIPtrMap[1] = 3;
hashIPtrMap[2] = 2;
hashIPtrMap[3] = 1;
hashIPtrMap[4] = 0;

// Test the STL search functions.
// Start with the search function that requires two
// sets of iterators. One for the hash map to be
// searched and another subsequence
// that is to be sought.
hash_map<int, int, int_hash_function>::iterator firstIntItr;
hash_map<int, int, int_hash_function>::iterator lastIntItr;

firstStrItr = hashIntMap.find(3);
lastStrItr  = firstIntItr;

lastStrItr++;

strItr = search(hashStrMap.begin(), hashStrMap.end(),
    firstStrItr, lastStrItr);

if ( strItr != hashStrMap.end() )
    cout << "search(): pair<3,1>={" << strItr->first << ","
         << strItr->second << "}" << endl;
else
    cout << "Search(): pair<3,1>={}  Function failed!!!" << endl;

// Test search_n to find a given value.
strItr = search_n(hashStrMap.begin(), hashStrMap.end(),
    1, pair<int,int>(0,4));

if ( strItr != hashStrMap.end() )
    cout << "search_n(): pair<0,4>={" << strItr->first << ","
         << strItr->second << "}" << endl;
else
    cout << "search_n(): pair<0,4>={}  Function failed!!!" << endl;

