/**********************************************************
 *
 *      MODULE      :  ABSEventHandler.h
 *
 **********************************************************/

#ifndef _ABS_EVENTHANDLER_H
#define _ABS_EVENTHANDLER_H


#define INTERNAL_ERROR		0		// Internal error event
#define FALSE				0
#define TRUE				1

typedef int Bool;

class ABSEventHandler;

// A typedef for a pointer to an event handler function
typedef Bool (ABSEventHandler::*FuncABSTransition )( void* );


class ABSEventHandler
{
 friend class FSM;

 public :
	ABSEventHandler( int inNumberTransitions ) 
	       { functions = new FuncABSTransition[inNumberTransitions]; }		 
	virtual ~ABSEventHandler( void ) {};

 protected:
	// A pointer to an array of event handler pointers
	FuncABSTransition* functions;

	// Pure virtual function to redefine in derived application specific class
	virtual void FillHandlersArray( void ) = 0;
};

#endif
