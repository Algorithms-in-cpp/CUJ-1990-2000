/******************************************************************************

   MODULE      : Filter_eventhandler.h

******************************************************************************/

#ifndef _FILTER_EVENTHANDLER_H
#define _FILTER_EVENTHANDLER_H

#include "ABS_eventhandler.h"
#include <stdio.h>


// Define list of possible states
enum Filter_states 
{
	VALID = 0, 
	WAIT_COMMENT,
	GARBAGE1, 
	GARBAGE2,
	WAIT_END_COMMENT
};

// Define list of possible events
enum Filter_events 
{
	SLASH ='/',
	ASTERISK ='*',
	NEWLINE ='\n',
	OTHER
};

// Event handlers indexes
enum Handler_indexes
{
	Ind_InternalError,			
	Ind_ignoreChar,		
	Ind_writeChar,
	Ind_writeSlash
};


// A class derived from an abstract event handler class
class Filter_EventHandler : public ABSEventHandler
{
 public :
    // Constructor
	Filter_EventHandler( int inNumberTransitions, char* inputFile, char* outputFile );

	// Destructor
	~Filter_EventHandler( void );

	int		getCharacter();				// Get a character from the input file

 private :
	FILE*	fi;							// Input file handle
	FILE*	fo;							// Output file handle

	 // Redefinition of the abstract base class's pure virtual function
	void	FillHandlersArray( void );

	// Event handlers - make some actions associated with a transition
	Bool	handleInternalError( void* );
	Bool	ignoreChar( void* );
	Bool	writeChar( void* );
	Bool	writeSlash( void* );
};


#endif
