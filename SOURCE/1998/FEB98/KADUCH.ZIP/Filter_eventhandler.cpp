/*****************************************************************************

   MODULE      : Filter_eventhandler.cpp

******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include "Filter_eventhandler.h"


Filter_EventHandler::Filter_EventHandler( int inNumberTransitions, 
										  char* inputFile,
										  char* outputFile )
				: ABSEventHandler(inNumberTransitions)
{
 // Call this function from the constructor
 FillHandlersArray();

  // Open input and output file 
 if ( (fi = fopen(inputFile, "r")) == NULL )
 {
	cout << "Error opening an input file." << endl;
    return;
 }
 if ( (fo = fopen(outputFile, "w")) == NULL )
 {
    fclose(fi);
 }
}


Filter_EventHandler::getCharacter()
{
 // read a character from the input file and return it
 return fgetc(fi);
}


Filter_EventHandler::~Filter_EventHandler( void )
{
 // Close the files
 fclose(fi);
 fclose(fo);
}


void Filter_EventHandler::FillHandlersArray( void )
{
 functions[Ind_InternalError] 	
		= (FuncABSTransition)&Filter_EventHandler::handleInternalError;
 functions[Ind_ignoreChar] 	
		= (FuncABSTransition)&Filter_EventHandler::ignoreChar;
 functions[Ind_writeChar]	
		= (FuncABSTransition)&Filter_EventHandler::writeChar;
 functions[Ind_writeSlash]	
		= (FuncABSTransition)&Filter_EventHandler::writeSlash;
}


Bool Filter_EventHandler::handleInternalError( void* )
{
 cout << "Handle internal error." << endl;
 return FALSE;
}


Bool Filter_EventHandler::ignoreChar( void* )
{
  // do nothing 
  return TRUE;
}


Bool Filter_EventHandler::writeChar( void* inChar )
{
 // Print a character into the output file
 fputc(*(int *) inChar, fo);
   
 return TRUE;
}


Bool Filter_EventHandler::writeSlash( void* inChar )
{
 // Print a slash and a character into the output file
 fputc(SLASH, fo);
 fputc(*(int *) inChar, fo);
   
 return TRUE;
}
