/*************************************************************************
 *
 *      MODULE      :  FSM.CPP
 *
 *************************************************************************/

#include <memory.h>
#include <stdlib.h>
#include "FSM.h"


FSM::FSM( ABSEventHandler *inTrans, int inMaxNumTransitions, int inInitialState )
{
 myptrHandler = inTrans;

 // Initialize the maximal number of transitions
 myMaxNumTransitions = inMaxNumTransitions;

 // Initialize the current state
 myCurrentState = inInitialState;

 // Initialize the array of transitions
 myptrArrayTrans = 0;
 myptrArrayTrans = new TransitionType[ myMaxNumTransitions ];
 memset(myptrArrayTrans, -1, myMaxNumTransitions * sizeof(TransitionType));
}


FSM::~FSM()
{
 if ( myptrArrayTrans )
    delete []myptrArrayTrans;
}


void FSM::insertInQueue( int inEvent, void *inParametros )
{
 StructEvent*	anEvent = NULL;

 if ( ( anEvent = new StructEvent() ) != NULL )
 {
    anEvent->Id = inEvent;
    if ( inParametros )
       anEvent->parameters = inParametros;
      	
    // Append the event to the end of list
    myList.append(anEvent);
 }
}


int FSM::hash( int inSourceState, int inEvent )
{
 int  i=0;
 int  where = ( ( inEvent << 8 ) + inSourceState) % myMaxNumTransitions;

 // Look for the first available position
 while( (myptrArrayTrans[ (where + i ) % myMaxNumTransitions].index != -1)
			 && (i < myMaxNumTransitions) )
		i++;

 // Return negative value if the table is full
 if ( i >= myMaxNumTransitions )
    return -1;
 else  // Return free position�s index
    return ((where + i)%myMaxNumTransitions) ;
}


int FSM::hash( int inEvent )
{
 int  i = 0;
 int  where = ( ( inEvent << 8 ) + myCurrentState) % myMaxNumTransitions;

 // Look for the first available position
 while( (myptrArrayTrans[(where+i) % myMaxNumTransitions].source_state !=
			  myCurrentState  ||
           myptrArrayTrans[(where+i) % myMaxNumTransitions].event != inEvent)  					&& i < myMaxNumTransitions )
   	i++;

 // Return negative value if event not found
 if ( i >= myMaxNumTransitions )
    return -1;
 else  // Return free position�s index
    return ((where + i) % myMaxNumTransitions) ;
}


int FSM::defineTransition( int inSourceState, int inDestinationState,
		   		           int inEvent, int inIndice )
{
 int index;

 // Search free position in the table of transitions
 index = hash(inSourceState, inEvent);
 if ( index != -1 )
 {
    myptrArrayTrans[index].source_state			= inSourceState;
    myptrArrayTrans[index].destination_state	= inDestinationState;
    myptrArrayTrans[index].event				= inEvent;
    myptrArrayTrans[index].index				= inIndice;
 }

 return index;
}


int FSM::control( int inEvent, void *inParametros )
{
 int			result = FALSE;
 int			transition_num;
 StructEvent*	anEvent = NULL;

 // Insert the received event in the insertInQueue
 insertInQueue(inEvent, inParametros);

 anEvent = myList.first();
 while ( anEvent )
 {
	// check if it is valid transition
    if ( (transition_num = hash(anEvent->Id)) >= 0 )
    {
       if ( myptrArrayTrans[transition_num].index == -1 )
       {
          // Missing transition - generate an internal error event
          generateEvent(INTERNAL_ERROR);
	   }
	   else
	   {
		  // Execute an event handler
		  result = (myptrHandler->*myptrHandler->functions[
						myptrArrayTrans[transition_num].index])(anEvent->parameters);

		  // Change the FSM's state
          myCurrentState = myptrArrayTrans[transition_num].destination_state;
       }
    }

    // Missing transition - generate an internal error event
    else
    {
	   generateEvent(INTERNAL_ERROR);
    }

	// Remove the processed event
	myList.remove(anEvent);
	// pull the next event from the queue
	anEvent = myList.next();
 } 

 return result;
}


void FSM::generateEvent( int inEvent, void *inParametros )
{
 insertInQueue(inEvent, inParametros);
}
