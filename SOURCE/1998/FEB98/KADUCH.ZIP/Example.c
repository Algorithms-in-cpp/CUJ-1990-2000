/* Example of the simple text filtering FSM  */
#include <stdio.h>
#include "automata.h"
#define control controlAutomata
#define defineTransition definirTransicion
FILE * fi,*fo;


enum events {GOOD, WAIT_COMMENT,GARBAGE1, GARBAGE2,WAIT_END_COMMENT};
enum states {SLASH='/',ASTERISK='*',NEWLINE='\n',OTHER};

int ignoreChar(void * a)
{
    /* do nothing */
   return(ok);
}
int writeChar (int *a)
{
   int salida = *a;
   fputc(salida,fo);
   return(ok);
}



main(argc,argv)
int argc;
char ** argv;
{
   int a, event;

   if ( argc != 3 )
   {
     printf("usage: %s <input_file> <output_file>\n",argv[0]);
     exit(0);
   }   
   
   /* Open input and output files */

   if ((fi = fopen(argv[1],"r"))==NULL)
       exit(1);
   if ((fo = fopen(argv[2],"w"))==NULL)
   {
       fclose(fi);
       exit(1);
   }
 
   /* Define FSM's transitions */
   defineTransition(GOOD,GOOD,OTHER,writeChar);
   defineTransition(GOOD,WAIT_COMMENT,SLASH,ignoreChar);
   defineTransition(WAIT_COMMENT,GOOD,OTHER,writeChar);
   defineTransition(WAIT_COMMENT,GARBAGE1,SLASH,ignoreChar);
   defineTransition(WAIT_COMMENT,GARBAGE2,ASTERISK,ignoreChar);
   defineTransition(GARBAGE1,GOOD,NEWLINE,writeChar);
   defineTransition(GARBAGE1,GARBAGE1,OTHER,ignoreChar);
   defineTransition(GARBAGE2,GARBAGE2,OTHER,ignoreChar);
   defineTransition(GARBAGE2,GARBAGE2,NEWLINE,ignoreChar);
   defineTransition(GARBAGE2,WAIT_END_COMMENT,ASTERISK,ignoreChar);
   defineTransition(WAIT_END_COMMENT,GARBAGE2,OTHER,ignoreChar);
   defineTransition(WAIT_END_COMMENT,GOOD,SLASH,writeChar);
   miEstadoActual = GOOD; 
   while (! feof(fi))
   {
      a =  fgetc(fi);
      switch(a)
      {
           case '/':
           case '*':
           case '\n':
                event = a;
                break;
           default:
                event = OTHER;
      }
      control(event,(void *)&a);
   }
   fclose(fi);
   fclose(fo);
}
