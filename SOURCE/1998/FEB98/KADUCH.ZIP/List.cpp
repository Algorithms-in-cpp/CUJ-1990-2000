/*----------------------------------------------------------------------
 *
 * 	MODULO	:	lista.C
 *		AUTOR	:	F. Wiersma.
 *
 * 	RCS	:	$Header: lista.c,v 1.14 92/12/12 16:47:50 fwiersma Exp $
 *
 *----------------------------------------------------------------------
 *
 * 	DESCRIPCION: 	Esto modulo es un clase de una lista generica.
 *
 *
 *--------------------------------------------------------------------*/

#include <stdio.h>
#include "list.h"

/*----------------------------------------------------------------------
 *
 * FUNCION		:	lista::~lista()
 *
 * PARAMETROS	:	Ninguno.
 *
 * DEVUELVE		:	Nada.
 *
 * DESCRIPCION	:	Destructor de la lista.
 *
 * LLAMADA POR	:
 *
 *--------------------------------------------------------------------*/
lista::~lista()
{
  // .MIENTRAS hay mas elementos.

  while (_first)
  {
    ilink *p = _first;
    _first = _first->_next;

    // .Borrar elemento.
    delete p;
  }
}


/*----------------------------------------------------------------------
 *
 * FUNCION		:	void *lista::first()
 *
 * PARAMETROS	:	Ninguno.
 *
 * DEVUELVE		:	Puntero a primero elemento.
 *
 * DESCRIPCION	:	Pone puntero a primero elemento y devuelve elemento.
 *
 * LLAMADA POR	:
 *
 *--------------------------------------------------------------------*/
void *lista::first()
{
  // .SI no hay un primero elemento.
  if (_first == 0)
  {
    _current = 0;
    // .Devuelve zero.
    return (0);
  }
  // .SINO
  else
  {
    _current = _first;
    // .Devuelve elemento.
    return (_first->_item);
  }
}


/*----------------------------------------------------------------------
 *
 * FUNCION		:	void *lista::next()
 *
 * PARAMETROS	:	Ninguno.
 *
 * DEVUELVE		:	Puntero a proximo elemento.
 *
 * DESCRIPCION	:	Pone puntero a proximo elemento y devuelve elemento.
 *
 * LLAMADA POR	:
 *
 *--------------------------------------------------------------------*/
void *lista::next()
{
  // .SI primero elemento estaba borrado.
  if (_skip_next)
  {
    _skip_next = 0;

    // .SI hay mas elementos.
    if (_current)
    {
      // .Devuelve elemento.
      return (_current->_item);
    }
  }

  // .SI puntero no esta fuera de la lista.
  if (_current == 0)
  {
    // .Devuelve zero.
    return (0);
  }
  // .SINO
  else
  {
    // .Pone puntero a proximo elemento.
    _current = _current->_next;

    // .SI no hay un elemento mas.
    if (_current == 0)
    {
      // .Devuelve zero.
      return (0);
    }

    // .Devuelve elemento.
    return (_current->_item);
  }
}


/*----------------------------------------------------------------------
 *
 * FUNCION		:	void *lista::current()
 *
 * PARAMETROS	:	Ninguno.
 *
 * DEVUELVE		:	Puntero a actual elemento.
 *
 * DESCRIPCION	:	Devuelve puntero a actual elemento o zero si
 *						esta fuera de la lista.
 *
 * LLAMADA POR	:
 *
 *--------------------------------------------------------------------*/
void *lista::current()
{
  // .SI puntero esta fuera de la lista.
  if (_current == 0)
  {
    // .Devuelve zero.
    return (0);
  }
  // .SINO
  else
  {
    // .Devuelve elemento.
    return (_current->_item);
  }
}


/*----------------------------------------------------------------------
 *
 * FUNCION		:	void *lista::last()
 *
 * PARAMETROS	:	Ninguno.
 *
 * DEVUELVE		:	Puntero a ultimo elemento.
 *
 * DESCRIPCION	:	Pone puntero a ultimo elemento y devuelve elemento.
 *
 * DESCRIPCION	:
 *
 * LLAMADA POR	:
 *
 *--------------------------------------------------------------------*/
void *lista::last()
{
  // .SI no hay un elemento en la lista.
  if (_last == 0)
  {
    _current = 0;
    // .Devuelve zero.
    return (0);
  }
  // .SINO
  else
  {
    _current = _last;
    // .Devuelve elemento.
    return (_last->_item);
  }
}


/*----------------------------------------------------------------------
 *
 * FUNCION		:	void *lista::previous()
 *
 * PARAMETROS	:	Ninguno.
 *
 * DEVUELVE		:	Puntero a elemento anterior.
 *
 * DESCRIPCION	:	Pone puntero a elemento anterior y devuelve elemento.
 *
 * DESCRIPCION	:
 *
 * LLAMADA POR	:
 *
 *--------------------------------------------------------------------*/
void *lista::previous()
{
  // .SI puntero esta fuera de la lista.
  if (_current == 0)
  {
    // .Devuelve zero.
    return (0);
  }
  // .SINO
  else
  {
    // .Pone puntero a elemento anterior.
    _current = _current->_previous;

    // .SI no hey elemento anterior.
    if (_current == 0)
    {
      _current = _first;
      // .Devuelve zero.
      return (0);
    }

    // .Devuelve elemento.
    return (_current->_item);
  }
}


/*----------------------------------------------------------------------
 *
 * FUNCION		:	int lista::append()
 *
 * PARAMETROS	:	Ninguno.
 *
 * DEVUELVE		:
 *	0  -> ok.
 *	-1 -> fallo de memoria.
 *
 * DESCRIPCION	:	A�adir elemento.
 *
 * LLAMADA POR	:
 *
 *--------------------------------------------------------------------*/
int lista::append(void *p)
{
  ilink *l = new ilink(p);

  if (l == 0)
  {
    // new failed
    return (-1);
  }

  // .SI hay ya un elemento.
  if (_last)
  {
    // .A�adir elemento en fin de la lista.
    _last->_next = l;
    l->_previous = _last;
  }
  // .SINO
  else
  {
    // .A�adir primero elemento.
    _first = l;
  }

  _last = l;

  _current = _first;

  return (0);
}


/*----------------------------------------------------------------------
 *
 * FUNCION		:	int lista::remove()
 *
 * PARAMETROS	:	Ninguno.
 *
 * DEVUELVE		:
 *	0 -> elemento no encontrado.
 *	1 -> elemento borrado.
 *
 * DESCRIPCION	:	Borrar elemento.
 *
 * LLAMADA POR	:
 *
 *--------------------------------------------------------------------*/
int lista::remove(void *p)
{
  ilink *l = _first;

  // .SI elemento esta el primero.
  if (p == _first->_item)
  {
    // .SI puntero esta puesto en el primero elemento.
    if (_current == _first)
    {
      // .Pone puntero a proximo elemento.
      _current = _current->_next; 
      // .Primero elemto esta borrado.
      _skip_next = 1;
    }

    l = _first;
    // .Pone primero elemento de la lista a proximo elemento.
    _first = _first->_next;

    // .SI hay un proximo elemento.
    if (_first)
    {
      // .Pone anterior elemento a zero.
      _first->_previous = NULL;
    }
    // .SINO 
    else // No more items on list. First and only element deleted.
    {
      // .Vacio lista.
      _last = NULL;
    }

    // .Borrar primero elemento.
    delete l;

    // .Deuelvo uno
    return (1);
  }

  // .SI elemento esta el ultimo.
  if (p == _last->_item)
  {
    // .SI puntero esta puesto en el ultimo elemento.
    if (_current == _last)
    {
      // .Pone puntero a elemento anterior.
      _current = _current->_previous; 
    }

    l = _last;
    // .Pone ultimo elemento de la lista a elemento enterior.
    _last = _last->_previous;

    // .SI hay un elemento anterior.
    if (_last)
    {
      // .Pone proximo elemento a zero.
      _last->_next = NULL;
    }

    // .Borrar primero elemento.
    delete l;

    // .Deuelvo uno
    return (1);
  }

  // .MIENTRAS hay mas elemento en la lista.
  while (l)
  {
    // .SI elemento encontrado.
    if (l->_item == p)
    {
      // .SI elemento esta actual elemento.
      if (_current == l)
      {
	// .Pone actual elemento a elemento anterior.
        _current = _current->_previous; 
      }

      // .Borrar elemento.
      l->_next->_previous = l->_previous;
      l->_previous->_next = l->_next;
      delete l;

      // .Devuelve uno.
      return (1);
    }

    l = l->_next;
  }

  // .Devuelve zero.
  return (0);
}


/*----------------------------------------------------------------------
 *
 * FUNCION		:	void *lista::find()
 *
 * PARAMETROS	:
 *   void *p	:	elemento
 *   int (*compare)(void *a void *b): funcion para comprobar elementos.
 *   int begin	:	1: empeza en el principio de la lista o
 *			0: empeza en actual elemento.
 *
 * DEVUELVE		:
 *	> 0 -> elemento.
 *	0   -> elemento no encontrado.
 *
 * DESCRIPCION	:	Buscar elemento en la lista.
 *
 * LLAMADA POR	:
 *
 *--------------------------------------------------------------------*/
void *lista::find(void *p, int (*compare)(void *a, void *b), int begin)
{
  ilink *l;

  // .SI quieres empezar en el principio de la lista.
  if (begin)
  {
    // .Pone actual elemento a primero elemento.
    l = _first;
    _current = l;
  }
  // .SINO
  else
  {
    // .Empeza en actual elemento.
    l = _current;
  }

  // .MIENTRAS hay elementos en la lista.
  while (l)
  {
    // .SI no hay funcion de comprobar.
    if (compare == NULL)
    {
      // .SI comprobar directamente es cierto.
      if (l->_item == p)
      {
	// .Pone elemento actual a elemento proximo.
        _current = l->_next;

	// .Devuelve elemento.
        return (l->_item);
      }
    }
    // .SINO
    else
    {
      // .SI funcion de comprobar deveulve cierto.
      if ((*compare)(l->_item, p))
      {
	// .Pone elemento actual a elemento proximo.
        _current = l->_next;

	// .Devuelve elemento.
        return (l->_item);
      }
    }

    l = l->_next;
  }

  // .Devuelve zero.
  return (0);
}
//#define TESTLIST
#ifdef TESTLIST

#include <stdio.h>
#include <string.h>

main ()
{
  char *s;
  char *s1 = new char[10];
  char *s2 = new char[10];
  char *s3 = new char[10];
  char *s4 = new char[10];

  strcpy(s1, "string1");
  strcpy(s2, "string2");
  strcpy(s3, "string3");
  strcpy(s4, "string4");

  Makelista(char);
  charlista L;

  // L.append(s1);
  // L.append(s2);
  // L.append(s3);
  // L.append(s4);

  s = L.first();
  while (s)
  {
    printf("%s\n", s);
    s = L.next();
  }
  printf("\n");

  L.remove(s1);
  //L.remove(s2);
  //L.remove(s3);
  //L.remove(s4);

  L.append(s1);

  s = L.first();
  while (s)
  {
    printf("%s\n", s);
    s = L.next();
  }
  printf("\n");
}
#endif
