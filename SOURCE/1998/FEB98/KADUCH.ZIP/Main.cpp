//
// Example of the simple C/C++ source code comment filtering FSM 
//
// Usage: fsm example.c example.out
//

#include <stdio.h>
#include <iostream.h>
#include "FSM.h"
#include "Filter_eventhandler.h"


const int MaxNumTransitions = 20;	// Maximal number of transitions


int main( int argc, char *argv[] )
{
 if ( argc != 3 )					// Check the input arguments
 {
    printf("Usage: %s <input_file> <output_file>\n", argv[0]);
    return (-1);
 }   

 // Create an instance of a filter events handler (without error handling)
 Filter_EventHandler *ptrHandler = 0;    
 ptrHandler = new Filter_EventHandler(MaxNumTransitions, argv[1], argv[2]);

 // Create an instance of the FSM
 FSM myFSM(ptrHandler, MaxNumTransitions, VALID);

 // Define the FSM's transitions
 myFSM.defineTransition(VALID, VALID, OTHER, Ind_writeChar);
 myFSM.defineTransition(VALID, VALID, NEWLINE, Ind_writeChar);
 myFSM.defineTransition(VALID, VALID, ASTERISK, Ind_writeChar);
 myFSM.defineTransition(VALID, WAIT_COMMENT, SLASH, Ind_ignoreChar);
 myFSM.defineTransition(WAIT_COMMENT, VALID, OTHER, Ind_writeSlash);
 myFSM.defineTransition(WAIT_COMMENT, GARBAGE1, SLASH, Ind_ignoreChar);
 myFSM.defineTransition(WAIT_COMMENT, GARBAGE2, ASTERISK, Ind_ignoreChar);
 myFSM.defineTransition(GARBAGE1, VALID, NEWLINE, Ind_writeChar);
 myFSM.defineTransition(GARBAGE1, GARBAGE1, OTHER, Ind_ignoreChar);
 myFSM.defineTransition(GARBAGE1, GARBAGE1, SLASH, Ind_ignoreChar);
 myFSM.defineTransition(GARBAGE1, GARBAGE1, ASTERISK, Ind_ignoreChar);
 myFSM.defineTransition(GARBAGE1, VALID, INTERNAL_ERROR, Ind_InternalError);
 myFSM.defineTransition(GARBAGE2, GARBAGE2, OTHER, Ind_ignoreChar);
 myFSM.defineTransition(GARBAGE2, GARBAGE2, NEWLINE, Ind_ignoreChar);
 myFSM.defineTransition(GARBAGE2, GARBAGE2, SLASH, Ind_ignoreChar);
 myFSM.defineTransition(GARBAGE2, WAIT_END_COMMENT, ASTERISK, Ind_ignoreChar);
 myFSM.defineTransition(WAIT_END_COMMENT, GARBAGE2, OTHER, Ind_ignoreChar);
 myFSM.defineTransition(WAIT_END_COMMENT, GARBAGE2, ASTERISK, Ind_ignoreChar);
 myFSM.defineTransition(WAIT_END_COMMENT, VALID, SLASH, Ind_ignoreChar);

 int	char_read, event;

 char_read = ptrHandler->getCharacter();
 while ( char_read != EOF )
 {
	// Convert a read character into an event
	switch ( char_read )
	{
			case SLASH:
			case ASTERISK:
			case NEWLINE:
				event = char_read;
                break;
			default:
			    event = OTHER;
	}
	// execute transition and associated actions
	if ( myFSM.control(event,(void *)&char_read) == FALSE )
		break;

	// Read a character from an input file
	char_read = ptrHandler->getCharacter();
 }

 // Clean up ...
 if ( ptrHandler )
    delete ptrHandler;

 cout << "Done ..." << endl;
 return(0);
}
