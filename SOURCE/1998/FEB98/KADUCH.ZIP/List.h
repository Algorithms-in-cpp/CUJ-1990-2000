#ifndef LISTA_H
#define LISTA_H

#include "generic.h"


class ilink
{
  private:

    friend class lista;

  protected:

    ilink *_next;
    ilink *_previous;
    void *_item;

  public:

    ilink(void *i) { _item = i; _next = NULL; _previous = NULL; };
};

class lista
{
  private:

    ilink *_first;
    ilink *_last;
    ilink *_current;

    int   _skip_next;

  public:

	 lista() { _first = _last = _current = 0; _skip_next = 0; };
	 ~lista();
	 void *first();
	 void *next();
	 void *current();
	 void *last();
	 void *previous();
	 void *find(void *p, int (*compare)(void *a, void *b) = NULL, int begin = 1);
	 int  remove(void *p);
	 int  append(void *p);
};


//  Note : Don't put white spaces in the name2 argument list, will not
//         work on SUN.

#define Makelista(TYPE)							\
class name2(TYPE,lista) : public lista					\
									\
{									\
  public:								\
									\
    name2(TYPE,lista)() : lista() {};					\
    ~name2(TYPE,lista)() {  };				\
    TYPE *first()           { return (TYPE *) lista::first(); };		\
    TYPE *next()            { return (TYPE *) lista::next(); };		\
    TYPE *current()         { return (TYPE *) lista::current(); };	\
    TYPE *last()            { return (TYPE *) lista::last(); };		\
    TYPE *previous()        { return (TYPE *) lista::previous(); };	\
    TYPE *find(TYPE *p, int (*compare)(TYPE *a, TYPE *b) = NULL,        \
	       int begin = 1)						\
    { return (TYPE *) 							\
      lista::find((void *) p, (int (*)(void *, void *)) compare, begin); };\
    int  remove(TYPE *p)    { return lista::remove((void *) p); };	\
    int  append(TYPE *p)    { return lista::append((void *) p); };	\
									\
}

#endif
