/***********************************************************************
 *
 *      MODULE      :  FSM.h
 *
 ***********************************************************************/

#if !defined (_FSM_H)
#define _FSM_H

#include "ABS_eventhandler.h"
#include "list.h"


typedef struct StructEvent
{
	int  	Id;						// event identifier
	void	*parameters;			// event parameters
} STRUCT_EVENT;

Makelista(STRUCT_EVENT);

class FSM	
{
 private :
	typedef struct
	{
		int	source_state;
		int	destination_state;
		int	event;
	   	int	index;
	} TransitionType;


	TransitionType*		myptrArrayTrans;// a pointer to the 
										// array of transitions
	int					myMaxNumTransitions;// max transitions supported 
	int					myCurrentState;	// current state of the FSM
	
	// an event queue

	STRUCT_EVENTlista	myList;			// an event queue
	
	
	ABSEventHandler*	myptrHandler;	// a pointer to the abstract
										// server class
	void	insertInQueue( int inEvent, void *inParameters );

	// Search using hash functions
	int		hash( int inSourceState, int inEvent );
	int		hash( int inEvent );

 public :
	// Constructor
	FSM( ABSEventHandler *inTrans, int inMaxNumTransitions, int inInitialState );
	// Destructor
	~FSM( void );
	int		defineTransition( int inSourceState, int inDestinationState,
						      int inEvent, int inIndice );
	int		control( int inEvent, void *inParameters = NULL );
	void	generateEvent( int inEvent, void *inParameters = NULL );
};	

#endif
