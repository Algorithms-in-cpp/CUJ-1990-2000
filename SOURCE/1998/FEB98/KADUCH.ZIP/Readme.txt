Included are the following files:
1) Source code (*.cpp and *.h) files
2) Microsoft Visual C++ workspace file
3) Unix generic makefile

