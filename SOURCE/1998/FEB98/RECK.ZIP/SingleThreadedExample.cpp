// Copyright (c) 1997 by Bill Reck <breck@magna.com.au>
// This code may be used royalty-free as long as
// this notice appears in the product.

#include <windows.h>
#include "Handle.h"
#include "AddressRep.h"

class Rep {
public:
    Rep() : counter_(0) {}
    virtual ~Rep()      {}
    void incrRefCount() { ++counter_; }
    void decrRefCount() { if ( --counter_ <= 0 ) delete this; }
private:
    int counter_;
};

void main(int argc, char *argv[]) {
    for (int i = 1; i < argc; ++i) {
        // Create a new representation and handle
        Handle<AddressRep<Rep> > addr = new AddressRep<Rep>;
        // Reference members of the representation
        addr->firstName(argv[i]);
        addr->fax();
        // Don't need to explicitly call delete on the
        // representation.  The Handle takes care of this.
    }
}
