// Copyright (c) 1997 by Bill Reck <breck@magna.com.au>
// This code may be used royalty-free as long as
// this notice appears in the product.

#include <string>
template <class SUPER>
class AddressRep : public SUPER {
    // This is a *very* simple/silly address record class
public:
    AddressRep() : firstName_(), faxedCount_(0) {}
    std::string firstName() const { return(firstName_.c_str()); }
    void firstName(const std::string &n) { firstName_ = n.c_str(); }
    void fax() {       // FAX Simulator
        ::Sleep(100);  // Faxing takes time ;-)
        ::printf("%d) Sending a FAX to %s...\n",
                 ++faxedCount_, firstName_.c_str());
    }
private:
    std::string firstName_;
    int faxedCount_;
};
