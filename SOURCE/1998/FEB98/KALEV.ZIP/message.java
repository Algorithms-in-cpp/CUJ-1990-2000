package mgr;
import java.util.*;
import java.io.*;

class Message extends Object implements Codes
{
protected Header  header;
protected Vector items; 
protected int itemsRead;

public Message()        //create an empty Messasge to be filled later
{
  items = new Vector();
  header = new Header();
}// Message()

public Message(int msgCode, int error, int flags)  //used by server
{
  items = new Vector();
  header = new Header();
  header.msgCode(msgCode);
  header.errCode(error);
  header.headerFlags(flags);
}// Message(int msgCode, int error, int flags)

//reconstituting constructor
public Message( DataInputStream buf) throws IOException     
{
  items =  new Vector();
  header = new Header(buf); //reconstitute header
  try
  {
    for (;;) //until EOF exception is thrown
    {
      Item temp = new Item(buf); //reconstitute next Item
      items.addElement(temp);
    }// for
  }//try
  catch (IOException exception)
  {
    if (exception instanceof EOFException) //OK; stream end reached
      return;
    throw exception; //an unexpected exception 
  }//catch
}// Message( DataInputStream buf) throws IOException

public void addItem(int itemCode) //pseudo default argument
{ 
  addItem(itemCode, TYPE_NONE, null);
}//addItem(int itemCode)

public void addItem( int itemCode, int itemType, Object data)
{
  addItem(new Item(itemCode, itemType, data);
}addItem( int itemCode, int itemType, Object data)
//...more overloaded addItem() versions
public void addItem(Item dataItem)  //actual insertion done here
{
  items.addElement(dataItem);
  int currDataSize = header.dataSize();
  header.dataSize(currDataSize + dataItem.itemSize() );
}//addItem(Item dataItem)

public Item readNextItem()
{
  if (items.size() < itemsRead)
  {
    itemRead = 0;  //rewind
    return null;  
  }//if
  return (Item) items.elementAt(itemsRead++);  
}//readNextItem

public void compose (int msgCode, byte [] senderContext, 
              int timeout, int flags, int errCode, int format)
{...}

public byte [] serialize ()
{
  //create required output streams
  ByteArrayOutputStream outbuf = new ByteArrayOutputStream();
  DataOutputStream  out = new DataOutputStream(outbuf);
//Header 
  header.setCrc();
  header.serialize(out);
//Items
  Enumeration i  = items.elements();
  while (i.hasMoreElements())
  {
   Item dataItem = (Item) i.nextElement();
    dataItem.serilalize(out);
  }//while
  return  outbuf.toByteArray();
}//serialize

boolean isHeaderValid()
{...}
}//Message
