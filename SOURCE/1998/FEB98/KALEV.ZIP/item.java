package mgr;
import java.io.*;

class Item extends Object implements Codes
{
  private int itemCode;
  private int itemSize;
  private Object itemData;

  Item()
  {
    itemData = new Object();
  }//item()

 Item (int code, int type, Object src)
 {
    itemCode = code;
    itemData  = src;
    if (src instanceof String)
    {
      itemSize = ((String) itemData).length();
      return;
    }//end if
    switch (itemType())
    {
      case TYPE_BYTE:
    itemSize = 1;
    break;
      case TYPE_SHORT:
    itemSize = 2;
    break;
     case TYPE_INT:
    itemSize = 4;
    break;
      ...//other types
      case TYPE_NONE: 
      default:
    itemSize = 0;
    break;
   }//switch
}// Item (int code, int type, Object src)

Item (DataInputStream inbuf) throws IOException //reconstitute
{
  try
  {
    itemCode = inbuf.readInt();
    itemSize = inbuf.readInt();
    switch (itemType())
    {
      case TYPE_BYTE:
    itemData = (Object) new Integer( (int) inbuf.readByte());
    break;
      case TYPE_SHORT:
    {
      int temp = inbuf.readShort();
      itemData = (Object) new Integer(temp);  //convert to an object
    }
      ...
      case TYPE_STR:
    {
          byte temp [] = new byte [20]; //any size will do
      for (int i =0; i < itemSize; i++) temp[i] = inbuf.readByte();
      String s = new String (temp, 0 /* hibyte val */);
      itemData = s;
      temp = s = null;
    }
    break;
    ...
    }//switch
  }//try
  catch(IOException exception)
  {...}
}// Item (DataInputStream inbuf) throws IOException //reconstitute

//accessors + mutators 
...
  void serialize(DataOutputStream out)
  {
    try
    {
       out.writeInt(itemCode);
       out.writeInt(itemSize);
       Integer n = new Integer(0);
       switch (itemType())
       {
         case TYPE_BYTE:
    n =(Integer) itemData;
    out.writeByte( (byte) n.intValue() ); 
    break;
         case TYPE_SHORT:
    ...
       }//switch
    }//try

    catch (IOException exception)
    {...}

  }//serialize

}//Item
