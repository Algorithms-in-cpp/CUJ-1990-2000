///////////////////////////////////////////////////////////////////////////////
//
//  File Name 
//      SESSION.H      
//
//  Description
//      The page cache  and MAPI session class declarations.
//
//  Author
//      Les Thaler
//      NetMessaging, Inc.
//  Revision: 1.00
//
// Copyright (c) 1997 Les Thaler. All rights reserved.
//

#ifndef _SESSION_H_
#define _SESSION_H_
#include "vlistvu.h"
#define LOGON_FLAGS              MAPI_ALLOW_OTHERS     | MAPI_NEW_SESSION |\
                                 MAPI_EXPLICIT_PROFILE | MAPI_LOGON_UI

#define MinPages(r,n) (((r) + (n) - 1) / (r))
#define PAGE_SIZE       40                          // in rows
#define CACHE_SIZE      3                           // in pages
#define DEF_START_SIZE  (CACHE_SIZE * PAGE_SIZE)    // in rows
#define WM_LV_INIT      (WM_USER + 1)
#define WM_LV_RESORT    (WM_USER + 2)

enum    {_TO_,_SUBJ_,_TIME_,_EID_,_TYPE_,NUM_PROPS};

typedef class CSession * PCSession;
typedef class CContext * PContext;
typedef SizedSPropTagArray(NUM_PROPS, CTableCols);
extern CTableCols g_sptCols;

extern WNDPROC g_pfnOldLVProc;

#define LISTVU_STYLE    (WS_TABSTOP      |\
                         WS_CHILD        |\
                         WS_BORDER       |\
                         WS_VISIBLE      |\
                         LVS_AUTOARRANGE |\
                         LVS_REPORT      |\
                         LVS_OWNERDATA)

LRESULT CALLBACK ListViewWndProc(HWND   hWndLV,
                                 UINT   message,
                                 WPARAM wParam,
                                 LPARAM lParam);
STDMETHODIMP CreateLV(HINSTANCE hInst, HWND hwndParent, HWND & hWndLV);

class CPageCache
{
    friend class CSession;
    public:
        enum {PT_IDX, AGE};

        CPageCache()
        {
            m_iPageTblEntries = 0;
            m_pPageTable = NULL;
            m_pCTbl      = NULL;

            for (int i = 0; i < CACHE_SIZE; i++)
            {
                // [PT_IDX] is idx into page table,
                m_iCachedPages[i][PT_IDX] = -1;
                m_iCachedPages[i][AGE]    = -1;
            }
        };
        virtual ~CPageCache()
        {
            if (m_pPageTable)
            {
                EmptyCache();
                delete [] m_pPageTable;
            }
        };

        void         PageOut(int iPage);
        STDMETHODIMP InitCache(LPMAPITABLE pCTbl, ULONG ulEntries);
        STDMETHODIMP GetPage(LPSRowSet * pprsPage);
        BOOL         PageLocked(int iPage);
        STDMETHODIMP PageIn(int iFaultIdx);
        LPSRow       IsPageFault(int idx);
        LPSTR        GetTableString(int iRow, int iCol,TCHAR szCol[]);

    private:
        int          m_iPageTblEntries;
        ULONG        m_ulVTblRows;
        LPSRowSet *  m_pPageTable;
        LPMAPITABLE  m_pCTbl;
        int          m_iCachedPages[CACHE_SIZE][2];
        void         UpdateCache(int iPageTblIdx);
        void         AgeCache(int iHit);
        void         EmptyCache();

};

class CSession
{
    friend LRESULT LVOnNotify(PCSession pCSess,HWND hWnd, LPARAM lParam);

    public:  
        CSession(LPMAPISESSION pSess, HINSTANCE hInst)
        {
            m_pSess          = pSess;    
            m_pSentCTbl      = NULL;
            m_hInst          = hInst;
            m_hWndLV         = NULL;
            m_ptSort         = 0;
            m_ulTotalEntries = 0;
        }
        ~CSession()
        {
            if (m_pSentCTbl)
                m_pSentCTbl -> Release();

            if (m_pSess)
            {
                m_pSess -> Logoff(NULL,0,0);
                m_pSess -> Release();
            }
        }
        STDMETHODIMP NewListView(HWND hwndParent)
        {
            HRESULT hRes = ::CreateLV(m_hInst, hwndParent,m_hWndLV);
            MoveLV(hwndParent);
            return hRes;
        }
        void MoveLV(HWND hwndParent)
        {
            RECT  rc;
            GetClientRect(hwndParent, &rc);
            MoveWindow(m_hWndLV, rc.left, rc.top,
                       rc.right - rc.left, rc.bottom - rc.top,
                       TRUE);
        }
        STDMETHODIMP    InitSentmailTbl();
        STDMETHODIMP    GetSentmailTbl(HWND hWnd);
        STDMETHODIMP    InitLV()
        {
            LV_COLUMN lvColumn;
            LPSTR     szCols[] = {_T("To - PR_DISPLAY_TO"),
                                  _T("Subject - PR_NORMALIZED_SUBJECT"),
                                  _T("Sent - PR_CLIENT_SUBMIT_TIME")};
            
            ListView_DeleteAllItems(m_hWndLV);
            
            //initialize the columns
            lvColumn.mask = LVCF_FMT | LVCF_WIDTH |
                            LVCF_TEXT| LVCF_SUBITEM;
            lvColumn.fmt = LVCFMT_LEFT;
            lvColumn.cx = 160;
            
            for (int i = _TO_; i < _EID_; i++)
            {
                lvColumn.pszText = szCols[i];
                ListView_InsertColumn(m_hWndLV, i, &lvColumn);
            }
            
            //set the number of items in the list
            ListView_SetItemCount(m_hWndLV, m_ulTotalEntries);
            SubclassLV();
            SendMessage(m_hWndLV,WM_LV_INIT,0,0);
            
            return S_OK;
        }

        STDMETHODIMP    InitPageCache()
        {
            return m_PageCache.InitCache(m_pSentCTbl,m_ulTotalEntries);
        }
        STDMETHODIMP    SortOnColumn(NM_LISTVIEW * pColInfo);
  
    private:
        TCHAR           m_szTitle[MAX_PATH];
        ULONG           m_ulTotalEntries,
                        m_ptSort;
        HINSTANCE       m_hInst;
        LPMAPISESSION   m_pSess;
        LPMAPITABLE     m_pSentCTbl;
        HWND            m_hWndLV;
        CPageCache      m_PageCache;
        STDMETHODIMP    SubclassLV()
        {
            g_pfnOldLVProc = (WNDPROC)SetWindowLong(m_hWndLV, GWL_WNDPROC,
                                                    (LONG)ListViewWndProc);

	        if (!g_pfnOldLVProc)
		        return HRESULT_FROM_WIN32(GetLastError());

	        return S_OK;
        }
};

STDMETHODIMP InitSession(HWND hWnd,HINSTANCE hInst,PCSession * ppCSess);
LRESULT      LVOnNotify(PCSession pCSess,HWND hWnd, LPARAM lParam);

#endif //_SESSION_H_