////////////////////////////////////////////////////////////////
//
//      Session.CPP      
//
//      The virtual listbox and MAPI table code. This code is
//      designed for Win32 ONLY and requires the InetSDK version of
//      the common controls (COMCTL32.DLL)
//
//      Created by Les Thaler   
//      lest@NetMessaging.com
//  
//      Copyright (c) 1997 Les Thaler. All rights reserved.
//

#include "vlistvu.h"

////////////////////////////////////////////////////////////////
//
//    LVOnNotify()--Listview notification message handler. 
//
//         LVN_GETDISPINFO--control needs to display strings.
//         Given index of requested row,look in our cache and
//         see if that page is resident, paging in row's page if
//         necessary, and returning requested strings from
//         the cached SRowSet. GetTableString does this work.
//
//         LVN_ODCACHEHINT--user has scrolled past last visible row,
//         control is telling us to preload our cache,it will need
//         those rows shortly.
//
//         LVN_COLUMNCLICK--resort table on the clicked column
//         property and start over.
//
LRESULT LVOnNotify(PCSession pCSess, HWND hWnd, LPARAM lParam)
{
    LPNMHDR  pnmh = (LPNMHDR) lParam;

    switch(pnmh -> code)
    {
         case LVN_GETDISPINFO:
         {
            // we get here when listview needs more data
            LV_DISPINFO *lpdi = (LV_DISPINFO *)lParam;
            TCHAR       szCol[MAX_PATH];

            int iRow = lpdi -> item.iItem,
                iCol = lpdi -> item.iSubItem;

            // set small icon
            if (!lpdi -> item.iSubItem && 
                lpdi -> item.mask & LVIF_IMAGE)
            {
                 lpdi -> item.iImage = 0;
            }

            // Listview needs a string, return if from cache
            // paging in, if necessary
            if (lpdi->item.mask & LVIF_TEXT)
                lstrcpy(lpdi -> item.pszText,  
                        pCSess -> m_PageCache.GetTableString(
                                        iRow,
                                        iCol,
                                        szCol));
            return 0;
        }
        case LVN_ODCACHEHINT:
        {
            // we get here to preload our cache
            LPNMLVCACHEHINT pHint = (LPNMLVCACHEHINT)lParam;
            int             iIdx;
            LPSRow          pRow; 

            // get low and hi index, page in needed pages
            for (iIdx =  pHint -> iFrom; 
                 iIdx <= pHint -> iTo; 
                 iIdx += PAGE_SIZE)
            {
                pRow = pCSess -> m_PageCache.IsPageFault(iIdx);

                if (!pRow)      // a page fault
                    pCSess -> m_PageCache.PageIn(iIdx);
            }
            return 0;
        }
        case LVN_COLUMNCLICK:
            // user clicked column heading, sort on that column
            OnError(hWnd,
                    pCSess->SortOnColumn((NM_LISTVIEW *) lParam));
            return 0;
    }    
    return 0;
}

////////////////////////////////////////////////////////////////
//
//    InitSentmailTbl()
//
//         Get the table size, select the columns we want, sort
//         it on the default column (PR_DISPLAY_TO), set the 
//         cursor to the first row.
// 
STDMETHODIMP CSession :: InitSentmailTbl()
{
	HRESULT		   hRes  = S_OK;
    SSortOrderSet  sSort = {1,0,0, {PR_DISPLAY_TO,
                                    TABLE_SORT_ASCEND}};

    hRes = m_pSentCTbl -> GetRowCount(0, &m_ulTotalEntries);

    if (FAILED(hRes))
		goto Quit;

	if (m_ulTotalEntries)
	{
        sSort.aSort[0].ulPropTag = PR_DISPLAY_TO;

		if (FAILED(hRes = m_pSentCTbl -> SetColumns((LPSPropTagArray) &g_sptCols,
                                                    TBL_BATCH)))
			goto Quit;

		if (FAILED(hRes = m_pSentCTbl -> SortTable(&sSort,
                                                   TBL_BATCH)))
			goto Quit;

        m_ptSort = PR_DISPLAY_TO;
		hRes = m_pSentCTbl -> SeekRow(BOOKMARK_BEGINNING,0,NULL);
	}
Quit:
    return hRes;
}

////////////////////////////////////////////////////////////////
//
//    GetSentmailTbl()
//
//         Get the message stores table and Restrict to default 
//         store's row. Get the default's entry ID column. Use
//         this entry ID to open the default store.
//
//         Get sentmail folder's entry ID and open the folder.
//         Get the contents table and cache the interface, then
//         set up the table (SetColumns,SortTable,SeekRow) via
//         InitSentmailTbl for later use.
// 
STDMETHODIMP CSession :: GetSentmailTbl(HWND hWnd)
{
    LPMDB               pMDB       = NULL;
    LPMAPIFOLDER        pFldr      = NULL;
    LPMAPITABLE         pStoresTbl = NULL;
    LPSRowSet           pRow       = NULL;
    SBinary             sbEID      = {0,NULL};
    static SRestriction sres;
    SPropValue          spv, 
                      * pspvEID    = NULL;
    HRESULT             hRes; 
    ULONG               ulObjType;
    
    static SizedSPropTagArray(2,sptCols) = {2,
                                            PR_ENTRYID,
                                            PR_DEFAULT_STORE};
    
    if (FAILED(hRes = m_pSess -> GetMsgStoresTable(0,
                                                   &pStoresTbl)))
        goto Quit;

    // set a restriction for row where PR_DEFAULT_STORE == TRUE
    sres.rt = RES_PROPERTY;
    sres.res.resProperty.relop = RELOP_EQ;
    sres.res.resProperty.ulPropTag = PR_DEFAULT_STORE;
    sres.res.resProperty.lpProp = &spv;

    spv.ulPropTag = PR_DEFAULT_STORE;
    spv.Value.b   = TRUE;

    // this API does the Restrict, SetColumns,QueryRows for us
    if (FAILED(hRes = HrQueryAllRows(pStoresTbl,
                                     (LPSPropTagArray) &sptCols,
                                     &sres,
                                     NULL,
                                     0,
                                     &pRow)))
        goto Quit;

    // Verify we got what we expected, the entry ID
    if (pRow                    &&
        pRow -> cRows           && 
        pRow -> aRow[0].cValues &&
        PR_ENTRYID == pRow -> aRow[0].lpProps[0].ulPropTag)
    {
        sbEID  = pRow -> aRow[0].lpProps[0].Value.bin;
    }
    else
        goto Quit;

    // Open an IMsgStore interface given the entry ID
    if (FAILED(hRes = m_pSess -> OpenMsgStore((ULONG)hWnd,
                                              sbEID.cb,
                                              (LPENTRYID)sbEID.lpb,
                                              NULL,
                                              MDB_WRITE,
                                              &pMDB)))
        goto Quit;

    // This API calls IMAPIProp::GetProps for a single property
    if (FAILED(hRes = HrGetOneProp(pMDB, 
                                   PR_IPM_SENTMAIL_ENTRYID,
                                   &pspvEID)))
        goto Quit;

    // With folder's entry ID, get IMAPIFolder interface
    if (FAILED(hRes = pMDB -> OpenEntry(pspvEID -> Value.bin.cb,
                                        (LPENTRYID) pspvEID -> Value.bin.lpb,
                                        &IID_IMAPIFolder,
                                        MAPI_BEST_ACCESS,
                                        &ulObjType,
                                        (LPUNKNOWN*) &pFldr)))
        goto Quit;

    // From IMAPIFolder, cache sentmail folder's contents table
    if (FAILED(hRes = pFldr -> GetContentsTable(0, 
                                                &m_pSentCTbl)))
        goto Quit;

    hRes = InitSentmailTbl();
Quit:
    FreeProws(pRow);
    MAPIFreeBuffer(pspvEID);

    if (pFldr)
        pFldr -> Release();

    if (pMDB)
    {
        ULONG ul = LOGOFF_ORDERLY;
        pMDB -> StoreLogoff(&ul);
        pMDB -> Release();
    }
  
    if (pStoresTbl)
        pStoresTbl -> Release();

    return hRes;
}

////////////////////////////////////////////////////////////////
//
//    SortOnColumn()
//
//         Resorts table when user clicks a column heading.
//         The key property is known by column number, if table
//         isn't already sorted on this key, resort it on the
//         server, throw out row cache and start over. The 
//         listview will call us back when it needs rows.
// 
STDMETHODIMP CSession :: SortOnColumn(NM_LISTVIEW * pColInfo)
{
    HRESULT hRes = S_OK, hr   = S_OK; 
    ULONG   i, j;

    // table is already sorted on this key, do nothing
    if (m_ptSort == g_sptCols.aulPropTag[pColInfo -> iSubItem])
        return hRes;

    SizedSSortOrderSet(1,so) = 
        {1,0,0,{g_sptCols.aulPropTag[pColInfo -> iSubItem],
                TABLE_SORT_ASCEND}};

    // sort the table on the server
    hRes = m_pSentCTbl -> SortTable((LPSSortOrderSet)&so,
                                    TBL_BATCH);

    if (S_OK != hRes)
        return hRes;

    // save new sort key
    m_ptSort = g_sptCols.aulPropTag[pColInfo -> iSubItem];
    hr = hRes;

    if (FAILED(hRes = m_pSentCTbl -> SeekRow(BOOKMARK_BEGINNING,
                                             0,
                                             NULL)))
	    goto Quit;

    m_PageCache.EmptyCache();
    i = min(DEF_START_SIZE, m_ulTotalEntries / PAGE_SIZE);

    // preload cache with a reasonable number of rows
    for (j = 0; j < i; j+= PAGE_SIZE)
    {
        if (FAILED(hRes = m_PageCache.PageIn(j)))
            goto Quit;
    }

    ListView_DeleteAllItems(m_hWndLV);
    ListView_SetItemCount(m_hWndLV, m_ulTotalEntries);

    // reset our thumb position counter
    SendMessage(m_hWndLV,WM_LV_RESORT,0,0);
Quit:
    return (hRes == S_OK ? hr : hRes);
}

////////////////////////////////////////////////////////////////
//
//    PageOut()
//
//         Page out one of our cache pages. FreeProws frees the
//         SRowSet, set the table entry to NULL.
// 
void CPageCache :: PageOut(int iPage)
{
    assert((iPage >= 0) && (iPage < m_iPageTblEntries));

    if (! m_pPageTable[iPage])
        return;

    FreeProws(m_pPageTable[iPage]);
    m_pPageTable[iPage] = NULL;
}

////////////////////////////////////////////////////////////////
//
//    InitCache()
//
//         Create and initialize the page table, then page in
//         a few pages to preload the cache.
// 
STDMETHODIMP CPageCache :: InitCache(LPMAPITABLE pCTbl,
                                     ULONG       ulEntries)
{
	HRESULT		hRes = S_OK;
    int			i,j;

    m_pCTbl           = pCTbl;
    m_ulVTblRows      = ulEntries;
    m_iPageTblEntries = MinPages(PAGE_SIZE, ulEntries);
    m_pPageTable      = new LPSRowSet[m_iPageTblEntries];
    
    if (!m_pPageTable)
    {
        hRes = MAPI_E_NOT_ENOUGH_MEMORY;
        goto Quit;
    }
    ZeroMemory(m_pPageTable, 
               m_iPageTblEntries * sizeof LPSRowSet);
    
    i = (int) min(DEF_START_SIZE, ulEntries);

    // preload cache with a reasonable number or rows
    // may have to tweak cache size, 
    for (j = 0; j < i; j+= PAGE_SIZE)
        if (FAILED(hRes = PageIn(j)))
            goto Quit;
Quit:
    return hRes;
}

////////////////////////////////////////////////////////////////
//
//    GetPage()
//
//         QueryRows from the IMAPTable to get one page's worth
//         of rows.Assumes table cursor is positioned correctly.
//
STDMETHODIMP CPageCache :: GetPage(LPSRowSet * pprsPage)
{
    *pprsPage  = NULL;
    assert(m_ulVTblRows);
    return RealMansQueryRows(m_pCTbl,PAGE_SIZE,pprsPage);
}

////////////////////////////////////////////////////////////////
//
//    PageIn()
//
//         Queries the table for the SRowSet containing the
//         faulting row. Adds that page to the cache,evicting
//         the oldest page, if there's no room in the cache.
// 
STDMETHODIMP CPageCache :: PageIn(int iFaultIdx)
{
    HRESULT   hRes        = S_OK;
    LPSRowSet prs         = NULL;
    int       iPageTblIdx = iFaultIdx / PAGE_SIZE;

    // should never be called to page in a resident page
    assert(NULL == m_pPageTable[iPageTblIdx]);

    // Faults can occur in middle of a page if user scrolls
    // quickly. Get table idx of first row in page
    int iVPageIdx = (iFaultIdx / PAGE_SIZE) * PAGE_SIZE;

    // Position cursor on first row in this page
    if (FAILED(hRes = m_pCTbl -> SeekRowApprox(iVPageIdx,
                                               m_ulVTblRows)))
        goto Quit;

    // Get one page's worth of rows
    if (FAILED(hRes = GetPage(&prs)))
        goto Quit;

    assert(prs);
    m_pPageTable[iPageTblIdx] = prs;
    UpdateCache(iPageTblIdx);
Quit:
    return hRes;
}

////////////////////////////////////////////////////////////////
//
//    IsPageFault()
//
//         Check the page table for this row, return it if it's
//         in the cache, return NULL if not.
// 
LPSRow CPageCache :: IsPageFault(int idx)
{
    int i = idx / PAGE_SIZE;
    
    assert(i < m_iPageTblEntries);
    
    if (m_pPageTable[i])
        return &(m_pPageTable[i] -> aRow[idx % PAGE_SIZE]);

    return NULL;
}

////////////////////////////////////////////////////////////////
//
//    UpdateCache()
//
//         Adds an index into the page table to the table of
//         cached pages. We cache iNewPageIdx, which points
//         at the page table entry, and the page table entry
//         points at the SRowSet.
// 
//         We look for an empty spot first, then evict the old-
//         est page if we can't find one.
//
void CPageCache :: UpdateCache(int iNewPageIdx)
{
    int iOld = 0;

    for (int i = 0; i < CACHE_SIZE; i++)
    {
        // if there's room in cache,grab first space
        if (m_iCachedPages[i][PT_IDX] < 0)
        {
            iOld = i;
            break;
        }
        // search for oldest page
        if (m_iCachedPages[i][AGE] > m_iCachedPages[iOld][AGE])
            iOld = i;
    }

    if (m_iCachedPages[iOld][PT_IDX] >= 0)
        PageOut(m_iCachedPages[iOld][PT_IDX]);    

    m_iCachedPages[iOld][PT_IDX] = iNewPageIdx;
    m_iCachedPages[iOld][AGE]    = 0;
}

////////////////////////////////////////////////////////////////
//
//    AgeCache()
//
//          This is called on every page access. Incremenent
//          all pages' age count, except the page this row lives
//          in, make it youngest (MRU)
//          
void CPageCache :: AgeCache(int iHit)
{
    for (int i = 0; i < CACHE_SIZE; i++)
        if (m_iCachedPages[i][PT_IDX] == iHit)
        {
            // make younger
            m_iCachedPages[i][AGE] = 0;
        }
        else
            m_iCachedPages[i][AGE]++;
}

////////////////////////////////////////////////////////////////
//
//    EmptyCache()
//
//          Page out every page in the cache.
//          
void CPageCache :: EmptyCache()
{
    for (int i = 0; i < CACHE_SIZE; i++)
        if (m_iCachedPages[i][PT_IDX] >= 0)
        {
            PageOut(m_iCachedPages[i][PT_IDX]);
            m_iCachedPages[i][PT_IDX] = -1;
            m_iCachedPages[i][AGE]    = -1;
        }
}

////////////////////////////////////////////////////////////////
//
//    GetTableString()
//
//         Given a virtual table row and column,returns a string
//         for that field's data. Pages row's page in,if not 
//         already in cache. Returns a null string if requested
//         field can't be found.
//         Also, since this method is called on every accesss,
//         make the hit's cached page younger and age the rest.
//         Caller doens't own returned string--don't free it!!
//
LPSTR CPageCache :: GetTableString(int   iRow, 
                                   int   iCol,
                                   TCHAR szTime[])
{
    LPSRow  pRow;
    ULONG   ulPropTag;
    int     iPage    = iRow / PAGE_SIZE,
            iSRowIdx = iRow % PAGE_SIZE;

    // on every hit, age each page in the cache except hit page
    AgeCache(iPage);
    pRow = IsPageFault(iRow);

    if (!pRow)
    {
        if (FAILED(PageIn(iRow)))
            goto Quit;

        pRow = IsPageFault(iRow);
    }

    assert(pRow);
    ulPropTag = pRow -> lpProps[iCol].ulPropTag;
    
    // Verify cached column is what we think it is.
    // Tag's type could be PT_ERROR if it's not in table
    if (g_sptCols.aulPropTag[iCol] == ulPropTag)
    {
        if (PT_SYSTIME == PROP_TYPE(ulPropTag))
            return :: FormatTimeString(pRow->lpProps[iCol].Value.ft,
                                       szTime);

        return pRow -> lpProps[iCol].Value.LPSZ;
    }
Quit:
    return TEXT("");
}