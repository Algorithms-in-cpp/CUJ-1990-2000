LPMAPISESSION pSession = NULL;
LPMDB         pMDB     = NULL;
HRESULT       hRes     = MAPIInitialize(NULL);
        
if (FAILED(hRes))
	Error();

hRes = MAPILogonEx(...,&pSession);
...
hRes = pSession -> OpenMsgStore(..., &pMDB);
...
// call IMsgStore methods through pMDB
...
pMDB -> Release();


