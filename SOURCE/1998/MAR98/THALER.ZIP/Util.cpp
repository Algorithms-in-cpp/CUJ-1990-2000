///////////////////////////////////////////////////////////////////////////////
//
//  File Name 
//      UTIL.CPP      
//
//  Description
//      Some handy utility functions.
//
//  Author
//      Les Thaler
//      NetMessaging, Inc.
//  Revision: 1.00
//
// Copyright (c) 1997 Les Thaler. All rights reserved.
//

#include <mapidefs.h>
#include <mapix.h>
#include <mapiutil.h>
#include <tchar.h>
#include "util.h"

///////////////////////////////////////////////////////////////////////////////
//
//    CopySRow()
//
//    Parameters                        
//         psrDest  [in/out]   pointer to an SRow to copy to
//         psrSrc   [in]       pointer to an SRow to copy from
//    Purpose
//          Copy an SRow. The caller should allocate and free the
//          destination SRowfree. The lpProps member of the 
//          destination row should be freed with a single call to 
//          MAPIFreeBuffer when done.         
//      
//    Return Value
//          S_OK on success, a MAPI error code otherwise
// 
STDMETHODIMP    CopySRow(LPSRow psrDest, LPSRow psrSrc)
{
    HRESULT     hRes = S_OK;
    LPSRow      psrTemp = NULL;

    if (FAILED(hRes = MAPIAllocateBuffer((sizeof SPropValue) * (psrSrc -> cValues), 
                                 (LPVOID *) &psrDest ->lpProps)))
        goto Quit;

    psrDest -> cValues = psrSrc -> cValues;
    
    hRes = CopySProps(psrDest -> lpProps, 
                      psrSrc  -> lpProps, 
                      psrSrc   -> cValues);
Quit:
    if (FAILED(hRes))
    {
        MAPIFreeBuffer((LPVOID)psrDest -> lpProps);
        psrDest -> lpProps = NULL;
    }
                
    return hRes;

}

///////////////////////////////////////////////////////////////////////////////
//
//    CopySProps()
//
//    Parameters                        
//          pspvDest  [in/out]  destination SPropValue array 
//          pspvSrc   [in]      source SPropValue array
//          cSrcVals  [in]      count of source properties
//    Purpose
//          Copies an SRow from psrSrc to psrDest          
//          The caller should allocate the dest SRow       
//          with MAPIAllocateBuffer. The dest can be       
//          larger than the src. This fcn chases down      
//          the nested pointers, allocates memory for them 
//          with MAPIAllocateMore, linked to psrDest       
//
//    Return Value
//          S_OK on success, a MAPI error code otherwise
// 
STDMETHODIMP CopySProps(LPSPropValue pspvDest, 
                        LPSPropValue pspvSrc,
                        ULONG        cSrcVals)
{
    HRESULT     hRes = S_OK;
    ULONG       i,
                ulTag;

    for (i = 0; i < cSrcVals; i++)
    {
        ulTag = pspvDest[i].ulPropTag;

        if (FAILED(hRes = CopyProp(&pspvDest[i], &pspvSrc[i], pspvDest)))        
            pspvDest[i].ulPropTag = CHANGE_PROP_TYPE(ulTag,PT_ERROR);
    }
    return hRes;
}

///////////////////////////////////////////////////////////////////////////////
//
//    CopyProp()
//
//    Parameters                        
//          pspDest   [in/out]  pointer to SPropValue to copy to
//          pspSrc    [in]      pointer to SPropValue to copy from
//          pParent   [in]      parent block to link allocations to
//    Purpose
//          copy an SPropValue from pspSrc to spsDest, including any 
//          sub structures. The resulting SPropValue sub structures 
//          are linked to pParent so the whole mess can be freed by 
//          freeing pParent                              
//    Return Value
//          S_OK on success, a MAPI error code otherwise
// 
STDMETHODIMP CopyProp(LPSPropValue pspDest, LPSPropValue pspSrc, LPSPropValue pParent) 
{

    HRESULT         hRes = S_OK;
    ULONG           ulTag = pspSrc -> ulPropTag,
                    ulLen;
    LPBYTE          pbSrc = NULL,
                  * ppbDest = NULL;

    // in case we fail, FreeBuff won't cack on garbage        
    ZeroMemory(pspDest, sizeof SPropValue);
    pspDest -> ulPropTag = pspSrc -> ulPropTag;


    switch(PROP_TYPE(ulTag))
    {
        case PT_BINARY:
            pbSrc  = pspSrc -> Value.bin.lpb;
            ulLen  = pspSrc -> Value.bin.cb;
            ppbDest = &(pspDest -> Value.bin.lpb);
            pspDest -> Value.bin.cb = ulLen;
            break;

        case PT_TSTRING:
            ulLen = lstrlen(pspSrc -> Value.LPSZ) + 1;
            pbSrc  = (LPBYTE) pspSrc -> Value.LPSZ;
            ppbDest = (LPBYTE *) &(pspDest -> Value.LPSZ);
            break;

        case PT_CLSID:
            ulLen = sizeof GUID;
            pbSrc  = (LPBYTE) pspSrc -> Value.lpguid;
            ppbDest = (LPBYTE *) &(pspDest -> Value.lpguid);
            break;

        default:
            if (ISMV_TAG(ulTag))
                return MAPI_E_NO_SUPPORT;

            ulLen = 0;
            pbSrc = NULL;
            ppbDest = NULL;
            pspDest -> Value = pspSrc -> Value;
            break;
    }

    if (ulLen && pbSrc && ppbDest)
        if (SUCCEEDED(hRes = MAPIAllocateMore(ulLen,(LPVOID) pParent,(LPVOID *) ppbDest)))
            memcpy((LPVOID)*ppbDest, (LPVOID)pbSrc, ulLen);

    return hRes;
}

///////////////////////////////////////////////////////////////////////////////
//
//    HrPropNotFound()
//
//    Parameters                        
//          pspv      [in/out]  pointer to SPropValue to mark 'not found'
//          ulTag     [in]      property tag of missing property
//    Purpose
//          Marks a property value as NOT FOUND by changing the tag to
//          (ulTag | PT_ERROR) and the Value.err to MAPI_E_NOT_FOUND
//
//    Return Value
//          MAPI_W_ERRORS_RETURNED
// 

STDMETHODIMP HrPropNotFound(SPropValue & spv, ULONG ulTag)
{

    spv.ulPropTag = CHANGE_PROP_TYPE(ulTag,PT_ERROR);
    spv.Value.err = MAPI_E_NOT_FOUND;
    return MAPI_W_ERRORS_RETURNED;
}

///////////////////////////////////////////////////////////////////////////////
//
//    MergeRows()
//
//    Parameters                        
//         psr1         [in]   pointer to an SRow to merge
//         psr2         [in]   pointer to another SRow to merge
//         pprsMerged   [out]  merged rowset containing prs1 and prs2
//    Purpose
//         Merges 2 rowsets into a single rowset.    
//      
//    Return Value
//          S_OK on success, a MAPI error code otherwise
// 

STDMETHODIMP MergeRows(LPSRowSet prs1, LPSRowSet prs2, LPSRowSet * pprsMerged)
{
    HRESULT     hRes;
    LPSRowSet   prsTmp = NULL;
    int         i;

    assert(prs1);
    assert(prs2);

    if (FAILED(hRes = MAPIAllocateBuffer(CbNewSRowSet(prs1 -> cRows + prs2 -> cRows),
                                         (LPVOID *) &prsTmp)))
        goto Quit;

    prsTmp -> cRows = 0;

    for (i = 0; i < (int)prs1 -> cRows; i++)
    {
        if (FAILED(hRes = CopySRow(&(prsTmp -> aRow[i]), &(prs1 -> aRow[i]))))
            goto Quit;

        prsTmp -> cRows++;
    }

    for (i = 0; i < (int)prs2 -> cRows; i++)
    {
        if (FAILED(hRes = CopySRow(&(prsTmp -> aRow[i + prs1 -> cRows]), &(prs2 -> aRow[i]))))
            goto Quit;

        prsTmp -> cRows++;
    }
Quit:
    if (FAILED(hRes))
    {   
        if (prsTmp)
            FreeProws(prsTmp);

        prsTmp = NULL;
    }

    *pprsMerged = prsTmp;
    return hRes;
}

///////////////////////////////////////////////////////////////////////////////
//
//    RealMansQueryRows()
//
//    Parameters                        
//         pTbl     [in]   pointer to an SRow to copy to
//         ulCnt    [in]   pointer to an SRow to copy from
//         pprs     [out]  rowset returned from query 
//    Purpose
//          Wrapper for IMAPITable::QueryRows that returns 
//          the number of rows requested, or < number requested
//          if at end of table
//      
//    Return Value
//          S_OK on success, a MAPI error code otherwise
// 
STDMETHODIMP RealMansQueryRows(LPMAPITABLE pTbl,ULONG ulCnt, LPSRowSet * pprs)
{
    LPSRowSet   prsTmp,
                prsTmp2;
    HRESULT     hRes = pTbl -> QueryRows(ulCnt,0,pprs);    

    if (FAILED(hRes) || ((*pprs) -> cRows == ulCnt))
        return hRes;

    // we're either at end of table or implementation is lazy
    // find out which, keep getting rows and merge into 
    // correct sized SRowSet
    
    ulCnt -= (*pprs) -> cRows;

    while (ulCnt)
    {
        prsTmp  = NULL;
        prsTmp2 = NULL;

        if (FAILED(hRes = pTbl -> QueryRows(ulCnt,0,&prsTmp)))
            goto Quit;
        
        if (prsTmp -> cRows)
        {
            if (SUCCEEDED(hRes = MergeRows(*pprs,prsTmp,&prsTmp2)))
            {
                FreeProws(*pprs);
                *pprs = prsTmp2;
                ulCnt -= prsTmp -> cRows;
            }
            FreeProws(prsTmp);
            
            if (FAILED(hRes))
                goto Quit;
        }
        else
            break;        // yes,Gloria, we're really at the end of the table
    }

Quit:
    if (FAILED(hRes))
        *pprs = NULL;

    return hRes;
}

///////////////////////////////////////////////////////////////////////////////
//
//    VAssert()
//
//    Parameters                        
//         szFile     [in]   filename for error dialog
//         iLine      [in]   line where error occurred
//         szMessage  [in]   debug string
//    Purpose
//         assert helper function. Pops up a message box and
//         or breaks to debugger 
// 
void VAssert(const char * szFile,int iLine, const char * szMessage)
{
	static char szMsg[256];

	wsprintf(szMsg,
		     "Assertion failed in file %s at line %u: %s",
             szFile,
             iLine,
             szMessage);

    int id = ::MessageBoxA(NULL,
                           szMsg,
                           "MAPI Virtual Listbox",
                            (MB_SETFOREGROUND   | 
					         MB_TASKMODAL       |
                             MB_ICONEXCLAMATION | 
                             MB_OKCANCEL));

    if (id == IDCANCEL)
        DebugBreak();
}

////////////////////////////////////////////////////////////////
//
//    FormatTimeString()
//
//       Convert FILETIME to minute/hour/day/month/year string.
// 
LPSTR FormatTimeString(FILETIME & ft,
                       TCHAR      szTime[])
{
    WORD       hr;
    SYSTEMTIME st;
    FILETIME   ftTemp;
    enum {AM,PM};
    
    szTime[0] = _T('\0');

    if (FileTimeToLocalFileTime(&ft, &ftTemp))
        if (FileTimeToSystemTime(&ftTemp,&st))
            wsprintf(szTime,
                     "%02d/%02d/%d %2d:%02d %s",
                     st.wMonth,
                     st.wDay,
                     st.wYear,
                     (0 == (hr = st.wHour % 12) ? 12 : hr),
                     st.wMinute,
                     st.wHour < 12 ? _T("A.M.") : _T("P.M."));                     
    return szTime;
}

// End of file for UTIL.CPP
