//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VLISTVW.RC
//
#define IDS_APPTITLE                    1
#define IDD_ABOUT                       100
#define IDM_EXIT                        100
#define IDI_MAINICON                    101
#define IDM_ABOUT                       101
#define IDM_MAIN_MENU                   102
#define IDM_CONTEXT_MENU                103
#define IDI_NOTE                        104
#define IDM_LIST                        202
#define IDM_REPORT                      203

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         102
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
