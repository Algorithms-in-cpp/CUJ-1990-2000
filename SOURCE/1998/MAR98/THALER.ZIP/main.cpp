////////////////////////////////////////////////////////////////
//
//      MAIN.CPP      
//
//  Description
//      Windows and initialization code. This code is
//      designed for Win32 ONLY and requires the InetSDK common
//      controls (COMCTL32.DLL)
//
//  Author
//      Les Thaler   
//      lest@NetMessaging.com
//  
//  Revision: 1.00
//
//  Copyright (c) 1997 Les Thaler. All rights reserved.
//

#define STRICT

#include <windows.h>
#define USES_IID_IMAPITable
#define USES_IID_IMAPIFolder

#define INITGUID

#include <initguid.h>
#include <mapiguid.h>
#include <mapicode.h>
#include <mapidefs.h>
#include <mapitags.h>
#include <mapiutil.h>
#include <mapix.h>

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <tchar.h>
#include <assert.h>

#include "VListVu.h"
#include "session.h"
#include "util.h"


WNDPROC g_pfnOldLVProc = NULL;
TCHAR   g_szClassName[] = _T("MAPI Table Virtual Listbox");

CTableCols g_sptCols = {NUM_PROPS,PR_DISPLAY_TO,
               PR_NORMALIZED_SUBJECT,
               PR_CLIENT_SUBMIT_TIME,
               PR_ENTRYID,
               PR_OBJECT_TYPE};

////////////////////////////////////////////////////////////////
//
//    WinMain()
//
//    Purpose
//         Program entry point. 
// 
int PASCAL WinMain(HINSTANCE hInst, 
                   HINSTANCE hPrevInst, 
                   LPSTR     lpCmdLine,
                   int       nCmdShow)
{
    MSG  msg;

    if (!hPrevInst)
        if (!InitApplication(hInst))
            return FALSE;

    //required to use the common controls
    InitCommonControls();

    if (!InitInstance(hInst, nCmdShow))
        return FALSE;

    while(GetMessage(&msg, NULL, 0x00, 0x00))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

////////////////////////////////////////////////////////////////
//
//    InitApplication()
//
//    Purpose
//         Registers window class. 
// 
BOOL InitApplication(HINSTANCE hInst)
{
    WNDCLASSEX  wcex;
    ATOM        aReturn;

    wcex.cbSize        = sizeof(WNDCLASSEX);
    wcex.style         = 0;
    wcex.lpfnWndProc   = (WNDPROC)MainWndProc;
    wcex.cbClsExtra    = 0;
    wcex.cbWndExtra    = 0;
    wcex.hInstance     = hInst;
    wcex.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName  = MAKEINTRESOURCE(IDM_MAIN_MENU);
    wcex.lpszClassName = g_szClassName;
    wcex.hIcon         = LoadIcon(hInst, 
                                  MAKEINTRESOURCE(IDI_MAINICON));
    wcex.hIconSm  = (HICON) LoadImage(
                                hInst,
                                MAKEINTRESOURCE(IDI_MAINICON),
                                IMAGE_ICON,
                                16,
                                16,
                                0);
    aReturn = RegisterClassEx(&wcex);

    if (0 == aReturn)
    {
        WNDCLASS wc;

        wc.style         = 0;
        wc.lpfnWndProc   = (WNDPROC)MainWndProc;
        wc.cbClsExtra    = 0;
        wc.cbWndExtra    = 0;
        wc.hInstance     = hInst;
        wc.hIcon         = LoadIcon(hInst,
                                    MAKEINTRESOURCE(IDI_MAINICON));
        wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
        wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        wc.lpszMenuName  = MAKEINTRESOURCE(IDM_MAIN_MENU);
        wc.lpszClassName = g_szClassName;

        aReturn = RegisterClass(&wc);
    }

    return aReturn;
}

////////////////////////////////////////////////////////////////
//
//    InitInstance()
//
//    Purpose
//         Creates main window.
// 
BOOL InitInstance(HINSTANCE hInst, int nCmdShow)
{
    HWND     hWnd;
    TCHAR    szTitle[MAX_PATH] = "";

    LoadString(hInst, IDS_APPTITLE, szTitle, sizeof(szTitle));

    // Create main window
    hWnd = CreateWindowEx(0,
                          g_szClassName,
                          szTitle,
                          WS_OVERLAPPEDWINDOW,
                          CW_USEDEFAULT,
                          CW_USEDEFAULT,
                          500,
                          600,
                          NULL,
                          NULL,
                          hInst,
                          NULL);

    if (!hWnd)
        return FALSE;

    // Make window visible, update client area
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
    return TRUE;
}

////////////////////////////////////////////////////////////////
//
//    MainWndProc()
//
//    Purpose
//         Main window procedure.
// 
LRESULT CALLBACK MainWndProc(HWND   hWnd,
                             UINT   uMessage,
                             WPARAM wParam,
                             LPARAM lParam)
{
    static  HWND      hwndListView;
    static  PCSession pCSess = NULL;
    static  HINSTANCE hInst;
            HRESULT   hRes;
    switch (uMessage)
    {
        case WM_CREATE:
            hInst = (HINSTANCE) GetWindowLong(hWnd,
                                              GWL_HINSTANCE);
            hRes = InitSession(hWnd,
                               hInst,
                               &pCSess);
            if (MAPI_E_USER_CANCEL == hRes)
            {
                DestroyWindow(hWnd);
                break;
            }
            else
                OnError(hWnd, hRes);

            OnError(hWnd,pCSess -> InitLV());
            break;

       case WM_NOTIFY:
            // handle notification messages from VListbox
            return LVOnNotify(pCSess,hWnd, lParam);
   
        case WM_SIZE:
            if (pCSess)
                pCSess -> MoveLV(hWnd);
            break;
   
        case WM_COMMAND:
            switch (GET_WM_COMMAND_ID(wParam, lParam))
            {
                case IDM_EXIT:
                    DestroyWindow(hWnd);
                    break;
         
                case IDM_ABOUT:
                    DialogBox(hInst,
                              MAKEINTRESOURCE(IDD_ABOUT), 
                              hWnd,
                              AboutDlgProc);
                    break;   
            }
            break;

        case WM_DESTROY:
            PostQuitMessage(0);

            if (pCSess)             
            {                       
                delete pCSess;      
                pCSess = NULL;      
            }
            MAPIUninitialize();

            break;

        default:
            break;
    }
    return DefWindowProc(hWnd, uMessage, wParam, lParam);
}

////////////////////////////////////////////////////////////////
//
//    InitSession()
//
//    Purpose
//      Initializes MAPI,logs on, creates and initializes
//      the CSession object. Creates the listview, opens the
//      default store, gets the sentmail folder's contents table
//      and initializes the page cache.
//
STDMETHODIMP InitSession(HWND        hWnd,
                         HINSTANCE   hInst,
                         PCSession * ppCSess)
{
    LPMAPISESSION pSession = NULL;
    PCSession     pCSess   = NULL;
    HRESULT       hRes;
        
    if (FAILED(hRes = MAPIInitialize(NULL)))
        return hRes;

    if (FAILED(hRes = MAPILogonEx((ULONG)hWnd,
                                  NULL,
                                  NULL,
                                  LOGON_FLAGS,
                                  &pSession)))
        goto Quit;
    
    pCSess = new CSession(pSession,hInst);

    if (!pCSess)
    {
        hRes = MAPI_E_NOT_ENOUGH_MEMORY;
        goto Quit;
    }

    if (FAILED(hRes = pCSess -> NewListView(hWnd)))
        goto Quit;

    if (FAILED(hRes = pCSess -> GetSentmailTbl(hWnd)))
        goto Quit;

    if (FAILED(hRes = pCSess -> InitPageCache()))
        goto Quit;
Quit:
    if (FAILED(hRes))
    {
        // destructor releases session and uninitializes
        if (pCSess)
            delete pCSess;
        else
        {
            if (pSession)
                pSession -> Release();        

            MAPIUninitialize();
        }
        return hRes;
    }

    *ppCSess = pCSess;
    return hRes;
}

////////////////////////////////////////////////////////////////
//
//    CreateLV()
//
//         Creates virtual listbox control.
// 
STDMETHODIMP CreateLV(HINSTANCE hInst, HWND hwndParent, HWND & hWndLV)
{
    HIMAGELIST  hSmallIcons;
            
    hWndLV = CreateWindowEx(WS_EX_CLIENTEDGE,  
                            WC_LISTVIEW,
                            "",                
                            LISTVU_STYLE,
                            0,0,0,0,                 
                            hwndParent,        
                            (HMENU)ID_LISTVIEW,
                            hInst,           
                            NULL);             

    if (!hWndLV)
        return MAPI_E_CALL_FAILED;

    //set the image lists
    hSmallIcons = ImageList_Create(16, 16,
                                   ILC_COLORDDB | ILC_MASK,
                                   1, 0);

    if (hSmallIcons)
    {
        HICON hIcon = (HICON) LoadImage(hInst,
                                        MAKEINTRESOURCE(IDI_NOTE),
                                        IMAGE_ICON,
                                        16, 16,
                                        LR_DEFAULTCOLOR);
        ImageList_AddIcon(hSmallIcons, hIcon);
        ListView_SetImageList(hWndLV, hSmallIcons, LVSIL_SMALL);
    }
    
    return S_OK;
}

////////////////////////////////////////////////////////////////
//
//    ListViewWndProc()
//
//        Listview window procedure. We've subclassed the list
//        view control to customize the thumb behavior. Now
//        the control only scrolls when the user drags then
//        releases the thumb, so we don't get lots of requests
//        to page in rows that user is scrolling over quickly.
//

LRESULT CALLBACK ListViewWndProc(HWND   hWndLV,
                                 UINT   message,
                                 WPARAM wParam,
                                 LPARAM lParam)
{
    static int        iOldThumb = 0;
    static int        iPageSize;           // in rows
    static int        iItemCount;
    static SCROLLINFO si;

    si.fMask  = SIF_ALL;
    si.cbSize = sizeof si;
    
	switch(message)
	{
        case WM_LV_INIT:
            iPageSize  = ListView_GetCountPerPage(hWndLV);
            iItemCount = ListView_GetItemCount(hWndLV);
            break;
        // need this since thumb is set to 0
        case WM_LV_RESORT:      
            iOldThumb = 0;
            break;
        case WM_SIZE:
            iPageSize = ListView_GetCountPerPage(hWndLV);
            break;
        case WM_KEYDOWN:
            switch(wParam)
            {
                case VK_PRIOR:
                    iOldThumb = max(0, iOldThumb - iPageSize);
                    break;
                case VK_NEXT:
                    iOldThumb = min(iItemCount, 
                                    iOldThumb + iPageSize);
                    break;
                case VK_HOME:
                    iOldThumb = 0;
                    break;
                case VK_END:
                    iOldThumb = iItemCount;
                    break;
            }
            break;
    	case WM_VSCROLL:
            switch (LOWORD(wParam))
            {
                case SB_ENDSCROLL:
                    return 0;
                case SB_THUMBPOSITION:
                {   
                    int iNewThumb = si.nTrackPos,
                        idx;
                    
                    // scrolling down--
                    // make sure rows from top of thumb idx to
                    // bottom of thumb idx are visible

                    // scrolling up--
                    // top of thumb is curr idx
                    idx = (iNewThumb >= iOldThumb             ? 
                               min(iItemCount - 1, 
                                   iNewThumb + iPageSize - 1) :
                               iNewThumb);
                    ListView_EnsureVisible(hWndLV,idx,FALSE); 
                    iOldThumb = idx;//iNewThumb;
                    return 0; 
                }

                // We need this to know the thumb position.
                // SB_THUMBPOSITION gives us this in
                // HIWORD(wParam), but that's only 16 bits
                // wide. This gives us 32 bit resolution.
                case SB_THUMBTRACK:
                    GetScrollInfo(hWndLV,SB_VERT,&si);
                    return 0;
                default:break;
            }
			break;
        default :;
	}
	
	return CallWindowProc(g_pfnOldLVProc, hWndLV, message,
                          wParam, lParam);
}


////////////////////////////////////////////////////////////////
//
//    AboutDlgProc()
//
//    Purpose
//         About dialog procedure.
// 
BOOL CALLBACK AboutDlgProc(HWND     hDlg, 
                           UINT     uMessage,
                           WPARAM   wParam,
                           LPARAM   lParam)
{
    switch (uMessage)
    {
        case WM_INITDIALOG:
            return TRUE;
      
        case WM_COMMAND:
            switch(wParam)
            {
                case IDOK:
                    EndDialog(hDlg, IDOK);
                    break;

                case IDCANCEL:
                    EndDialog(hDlg, IDOK);
                    break;
            }
            return TRUE;
    } 
    
    return FALSE;
}
