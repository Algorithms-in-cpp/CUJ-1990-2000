///////////////////////////////////////////////////////////////////////////////
//
//  File Name 
//      UTIL.H
//
//  Description
//
//  Author
//      Les Thaler
//      NetMessaging, Inc.
//
// Copyright (c) 1997 Les Thaler. All rights reserved.
//
#ifndef _UTIL_H_
#define _UTIL_H_


#define ISMV_TAG(ulTag)     !!(MV_FLAG & PROP_TYPE((ulTag))) 
#define OnError(hWnd, hRes)                                                             \
    {                                                                                   \
        HRESULT hr = (hRes);                                                            \
        if (S_OK != hr)                                                                 \
        {                                                                               \
            char szMsg[256];                                                            \
            int  ret;                                                                   \
            wsprintf(szMsg,"Error 0x%08X at %s line %d. Debug?",hr,__FILE__,__LINE__);  \
            ret = MessageBox((hWnd),                                                    \
                             szMsg,                                                     \
                             "MAPI Virtual Listbox.",                                   \
                             MB_YESNO| MB_SETFOREGROUND);                               \
            if (IDYES == ret)                                                           \
                DebugBreak();                                                           \
        }                                                                               \
    }

#endif

#undef  assert
#define assert(exp) (void)((exp) || (VAssert(__FILE__, __LINE__, #exp), 0))

STDMETHODIMP CopySRow(LPSRow psrDest, LPSRow psrSrc);
STDMETHODIMP CopySProps(LPSPropValue pspvDest, LPSPropValue pspvSrc,ULONG cSrcVals);
STDMETHODIMP CopyProp(LPSPropValue pspDest, LPSPropValue pspSrc, LPSPropValue pParent);
STDMETHODIMP HrPropNotFound(SPropValue & spv, ULONG ulTag);
STDMETHODIMP MergeRows(LPSRowSet prs1, LPSRowSet prs2, LPSRowSet * pprsMerged);
STDMETHODIMP RealMansQueryRows(LPMAPITABLE pTbl,ULONG ulCnt, LPSRowSet * pprs);
void VAssert(const char * szFile,int iLine, const char * szMessage);
LPSTR FormatTimeString(FILETIME & ft,TCHAR      szTime[]);


// End of file for UTIL.H
