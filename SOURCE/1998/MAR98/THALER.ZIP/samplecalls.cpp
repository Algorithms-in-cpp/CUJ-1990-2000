//-------- a) SetColumns example ------------- 

HRESULT 	hRes;

LPMAPITABLE  pTbl = .. //gotten from elsewhere

SizedSPropTagArray(5,sptCols) = 
  {5, PR_DISPLAY_TO, 
   PR_NORMALIZED_SUBJECT,
   PR_CLIENT_SUBMIT_TIME, 
   PR_ENTRYID, PR_OBJECT_TYPE};

hRes = pTbl->SetColumns(
   (LPSPropTagArray) &sptCols, TBL_BATCH);

//-------- b) SortTable example -------------- 

SizedSSortOrderSet(2, sSort) =
  {2, 0, 0,
   {{PR_DISPLAY_TO, TABLE_SORT_ASCEND},
    {PR_CLIENT_SUBMIT_TIME,
     TABLE_SORT_DESCEND}}};

hRes = pTbl->SortTable(
  (LPSSortOrderSet)&sSort, TBL_BATCH);

//-------- c) Restrict example --------------- 

SRestriction srRoot, srLevel1[2]; 
SPropValue   spvSubj;

spvSubj.ulPropTag = PR_NORMALIZED_SUBJECT;
spvSubj.Value.lpszA = "C/C++ User's Journal";

// Root &&
srRoot.rt = RES_AND;
srRoot.res.resAnd.cRes = 2;
srRoot.res.resAnd.lpRes = srLevel1;

// Subject contains "C/C++ User's Journal"
srLevel1[0].rt = RES_CONTENT;
srLevel1[0].res.resProperty.relop =
  FL_SUBSTRING;
srLevel1[0].res.resProperty.ulPropTag =
  PR_SUBJECT;
srLevel1[0].res.resProperty.lpProp = &spvSubj;

// Body > 100
srLevel1[1].rt = RES_SIZE;
srLevel1[1].res.resSize.relop = RELOP_GT;
srLevel1[1].res.resSize.ulPropTag = PR_BODY;
srLevel1[1].res.resSize.cb = 100;

hRes = pTbl -> Restrict(&srRoot, TBL_BATCH);

//-------- d) Subrestriction example  --------

SRestriction srRoot,srSub;
SpropValue   spvName;

spvName.ulPropTag   = PR_DISPLAY_NAME;
spvName.Value.lpszA = "Les Thaler";

srSub.rt =
  RES_CONTENT;
srSub.res.resContent.ulFuzzyLevel =
  FL_SUBSTRING;
srSub.res.resContent.ulPropTag =
  PR_DISPLAY_NAME;
srSub.res.resContent.lpProp = &spvName;
srRoot.rt = RES_SUBRESTRICTION;
srRoot.res.resSub.ulSubObject = 
  PR_MESSAGE_RECIPIENTS;			 
srRoot.res.resSub.lpRes  = &srSub;

hRes = pTbl -> Restrict(&srRoot,TBL_BATCH);

//-------- e) SeekRow and SeekRowApprox ------

// Seek to the first row in the view
hRes = pTbl -> SeekRow(
  BOOKMARK_BEGINNING, 0, NULL);

// Seek to the halfway point
hRes = pTbl -> SeekRowApprox(500, 1000);

//-------- f) QueryRows example --------------

STDMETHODIMP HrQueryRows(
  LPMAPITABLE pTbl, ULONG ulCnt,
  LPSRowSet * pprs)
{
  LPSRowSet  prsTmp, prsTmp2;
  HRESULT hRes =
    pTbl -> QueryRows(ulCnt,0,pprs);    

  if (FAILED(hRes) ||
     ((*pprs) -> cRows == ulCnt))
       return hRes;

  // we're either at end of table, or
  // implementation is lazy. Keep getting rows
  // and merge into correct sized SRowSet    
  ulCnt -= (*pprs) -> cRows;

  while (ulCnt)
  {
    prsTmp  = NULL;
    prsTmp2 = NULL;

    if (FAILED(hRes =
      pTbl -> QueryRows(ulCnt,0,&prsTmp)))
        goto Quit;
        
    if (prsTmp -> cRows)
    {
      if (SUCCEEDED(hRes =
        MergeRows(*pprs,prsTmp,&prsTmp2)))
          {
            FreeProws(*pprs);
            *pprs = prsTmp2;
            ulCnt -= prsTmp -> cRows;
          }
      FreeProws(prsTmp);
            
      if (FAILED(hRes)) goto Quit;
    }
    else
      break; // yes, Gloria, we're really
             // at the end
    }
Quit:
  if (FAILED(hRes)) *pprs = NULL;

  return hRes;
}

