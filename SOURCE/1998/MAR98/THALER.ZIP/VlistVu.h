#ifndef _VLISTVU_H_
#define _VLISTVU_H_

#define STRICT
#include <mapicode.h>
#include <mapidefs.h>
#include <mapitags.h>
#include <mapiutil.h>
#include <mapix.h>

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <tchar.h>
#include <assert.h>

#include "session.h"
#include "util.h"

#include "resource.h"

#ifndef WIN32

#define GET_WM_COMMAND_ID(wp, lp)               (wp)
#define GET_WM_COMMAND_HWND(wp, lp)             (HWND)(LOWORD(lp))
#define GET_WM_COMMAND_CMD(wp, lp)              HIWORD(lp)

#endif


int PASCAL WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
BOOL InitApplication(HINSTANCE);
BOOL InitInstance(HINSTANCE, int);
LRESULT CALLBACK MainWndProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK AboutDlgProc(HWND, UINT, WPARAM, LPARAM);
//HWND CreateListView(HINSTANCE, HWND);
void ResizeListView(HWND, HWND);
BOOL InitListView(HWND);
STDMETHODIMP CreateListView(HINSTANCE hInst, HWND hwndParent, HWND & hWndLV);
LRESULT CALLBACK ListViewWndProc(HWND   hWndLV,
                                 UINT   message,
                                 WPARAM wParam,
                                 LPARAM lParam);
#define ID_LISTVIEW  2000

#endif