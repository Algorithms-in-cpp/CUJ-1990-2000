Listing
// PseudoTerminal Implementation ////////////////////////////////////////////////
////


#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <termio.h>
#include <wait.h>

#include <iostream.h>


#include "PseudoTerminal.h"







// class members
char* PseudoTerminal::_pty_chars = "pqrs";             // available X characters
char* PseudoTerminal::_hexdigits = "012345678abcdef";  // Y characters are made up of








// Instantiation ////////////////////////////////////////////////////////////////
////
PseudoTerminal::PseudoTerminal(size_t buf_size /* 512 */)
  : _pty_name(strdup("/dev/ptyXY"))
  , _tty_name(NULL)
  , _pty_x(0)
  , _pty_y(0)
  , _master_fd(-1)
  , _slave_fd(-1)
  , _slave_pid(-1)
  , _buf(NULL)
  , _buf_size(buf_size)
{
  struct stat statbuff;
  char* tmp_tty_name = new char(strlen(getPtyName()) + 1);

  ////
  // open the master half of the pty "/dev/pty[pqrs][0-9a-f]"
  for (char* ptr = _getPtyChars(); (*ptr != 0) && (getFd() <= 0); ptr++)
  {
    _setPtyX(*ptr);
    _setPtyY('0');

    // if the file "/dev/ptyX0" doesn't exist this system uses a different pty scheme
    if (stat(getPtyName(), &statbuff) < 0)
      break;

    for (int i = 0; i < 16; i++)
    {
      _setPtyY(_getHexdigits()[i]);
      if ((_master_fd = open(getPtyName(), O_RDWR)) >= 0)
      {
        // see if the slave pty can be opened
        strcpy(tmp_tty_name, getPtyName());
        tmp_tty_name[5] = 't';  // change "/dev/ptyXY" to "/dev/ttyXY"
        if (access(tmp_tty_name, R_OK | W_OK) == 0)
          break;
        else
        {
          cerr << "pty::PseudoTerminal() - Warning:  unable to access slave " << tmp_tty_name << ".  Should be able to." << endl;
          cerr << "                        " << strerror(errno) << endl;
        }
      }
    }
  }

  delete tmp_tty_name;

  if (getFd() < 0)
    throw(errno);

  // allocate the internal buffer
  _buf = new char[getBufferSize()];
}

PseudoTerminal::~PseudoTerminal()
{
  // free up allocated memory and kill the slave process (if running)
  delete _pty_name;
  delete _tty_name;
  closeMaster();
  closeSlave();
  delete _buf;
}


// Protected methods ////////////////////////////////////////////////////////////
////
// _setPtyX/Y
//   sets the X or Y character of the pty name.
void PseudoTerminal::_setPtyX(char c)
{
  _pty_x = c;
  _pty_name[8] = _pty_x;
}

void PseudoTerminal::_setPtyY(char c)
{
  _pty_y = c;
  _pty_name[9] = _pty_y;
}


// Public methods ///////////////////////////////////////////////////////////////
////
// -- line discipline -----------------------------------------------------------
////
// g/setMode
//   are helper methods that interface with ioctl, so the caller doesn't have to.
bool PseudoTerminal::getMode(int fd, struct termio* mode)
{
  if (ioctl(fd, TCGETA, (char*)mode) < 0)
    return(false);
  return(true);
}

bool PseudoTerminal::setMode(int fd, struct termio* mode)
{
  if (ioctl(fd, TCSETA, (char*)mode) < 0)
    return(false);
  return(true);
}

////
// setRawMode
//   sets the pty, associated with fd, into raw mode.  if orig is supplied
// the original line discipline is stored here.
bool PseudoTerminal::setRawMode(int fd, struct termio* orig /* NULL */)
{
  struct termio temp_mode;
  if (ioctl(fd, TCGETA, (char*)&temp_mode) < 0)
    return(false);

  // save current setting
  if (orig)
    *orig = temp_mode;

  // set raw mode
  temp_mode.c_iflag = 0;                                // turn off all input control
  temp_mode.c_oflag &= ~OPOST;                          // disable output post-processing
  temp_mode.c_lflag &= ~(ISIG | ICANON | ECHO | XCASE); // disable signal generation, canonical input, echo, and upper/lower output
  temp_mode.c_cflag &= ~(CSIZE | PARENB);               // clear char size, disable parity
  temp_mode.c_cflag |= CS8;                             // 8-bit characters
  temp_mode.c_cc[VMIN] = 1;                             // min #chars to satisfy read
  temp_mode.c_cc[VTIME] = 1;                            // 10'ths of seconds between chars
  if (ioctl(fd, TCSETA, (char*)&temp_mode) < 0)
    return(false);

  return(true);
}

////
// copyMode
//   copies the line discipline mode of src_fd to the dest_fd.  if dest_orig is
// supplied the mode of dest is first copied into it.
bool PseudoTerminal::copyMode(int src_fd, int dest_fd, struct termio* dest_orig /* NULL */)
{
  struct termio temp_mode;
  // copy the source
  if (ioctl(src_fd, TCGETA, (char*)&temp_mode) < 0)
    return(false);

  // if requested save a copy of the dest before setting
  if (dest_orig)
    if (ioctl(dest_fd, TCGETA, (char*)dest_orig) < 0)
      return(false);

  // set dest
  if (ioctl(dest_fd, TCSETA, (char*)&temp_mode) < 0)
    return(false);
  return(true);
}

// -- slave pty and child process management ------------------------------------
////
// slave
//   opens the slave portion of the pty and sets the line discipline to raw
// mode.  if the slave can not be opened an exception is thrown.
int PseudoTerminal::slave()
{
  _tty_name = strdup(getPtyName());
  _tty_name[5] = 't';  // change "/dev/ptyXY" to "/dev/ttyXY"

  if ((_slave_fd = open(getTtyName(), O_RDWR)) < 0)
  {
    closeMaster(false);
    throw(errno);
  }

  setRawMode(getSlaveFd());

  return(getSlaveFd()); 
}

////
// forkvp
//   forks a new process, sets up the stdin/out/err of the new process to the slave
// pty, if control_terminal is true makes the pty a controlling terminal, and exec's
// the new command.  if the slave pty has not been created it is created in the new
// process.  this is usually the desired setup because when the slave exits a write
// error will occur on the master.
pid_t PseudoTerminal::forkvp(char* argv[], bool control_terminal /* false */, struct termio* mode /* NULL */)
{
  terminate(SIGKILL);  // the pty class can only handle one child process at a time

  if ((_slave_pid = fork()) < 0)
    cerr << "pty::forkvp() - fork error -" << strerror(errno) << endl;
  else if (_slave_pid == 0)
  {
    if (control_terminal)
      setpgrp();

    if (getSlaveFd() == -1)
      slave();
    
    if (mode)
      setMode(getSlaveFd(), mode);

    if (getSlaveFd() >= 0)
    {
      closeMaster(false);
      close(0);
      close(1);
      close(2);
      if ((dup(getSlaveFd()) != 0) || (dup(getSlaveFd()) != 1) || (dup(getSlaveFd()) != 2))
        cerr << "pty::forkvp() - unable to dup - " << strerror(errno) << endl;
      closeSlave();

      ::execvp(argv[0], argv);
      cerr << "pty::forkvp() - execvp error -" << strerror(errno) << endl;
      exit(-1);
    }
  }

  return(_slave_pid);
}

////
// isAlive
//   pings the slave process to see if it is still executing.
bool PseudoTerminal::isAlive()
{
  bool is_alive = false;
  if (_slave_pid > 0)
    if (kill(_slave_pid, 0) == 0)
      is_alive = true;
  return(is_alive);
}

////
// terminate
//   kills the slave process, if it is still running, and waits for it 
// to die.  the results of the wait are returned.
int PseudoTerminal::terminate(int signo /* SIGTERM */)
{
  // kill the running process - only if the slave_pid != 0 (which is the slave)
  int status = 0;
  if (_slave_pid > 0)
  {
    // alarms should be used for a timeout, just in case the process dosn't die
    kill(_slave_pid, signo);  // could be a zombie in which case wait will clean it up
    waitpid(_slave_pid, &status, 0);
    _slave_pid = -1;
    if (_slave_fd > 0)
      closeSlave();
  }

  return(status);
}

////
// closeMaster
//   closes the pty master and slave (will kill the child process if it is still
// running.
void PseudoTerminal::closeMaster(bool close_slave /* true */)
{
  if (_master_fd > 0)
  {
    close(_master_fd);
    _master_fd = -1;
    if (close_slave)
      closeSlave();
  }
}

////
// closeSlave
//   closes the slave portion of the pty and terminates the child process.
// the pty master is left open so it can be re-used.
void PseudoTerminal::closeSlave()
{
  if (_slave_fd > 0)
  {
    close(_slave_fd);
    _slave_fd = -1;
  }
  terminate(SIGKILL);
}

// -- IO ------------------------------------------------------------------------
////
// read
//   reads the data on the pty master into the internal buffer.  exception handling
// can be controlled by the throw_exception parameter so the insertion and extraction
// operators can be used.
ssize_t PseudoTerminal::read(bool throw_exception /* true */)
{
  _getBufferCount() = ::read(getFd(), _getBuffer(), getBufferSize() - 1);
  if ((_getBufferCount() < 0) && throw_exception)
    throw(errno);
  
  // nil terminate the string just read
  if (_getBufferCount() >= 0)
    _getBuffer()[_getBufferCount()] = '\0';

  return(_getBufferCount());
}

////
// write
//   writes the buffer to the pty master.  exception handling can be controlled
// by the throw_exception parameter.
ssize_t PseudoTerminal::write(const char* buf, size_t buf_size, bool throw_exception /* true */)
{
  ssize_t twrote = 0;
  ssize_t len;
  ssize_t tlen = buf_size;
  while (twrote < tlen)
  {
    len = ::write(getFd(), buf, buf_size);
    if ((len < 0) && throw_exception)
      throw(errno);

    twrote += len;
    if (len < buf_size)
    {
      buf += len;
      buf_size -= len;
    }
  }

  return(twrote);
}

PseudoTerminal& PseudoTerminal::operator<<(PseudoTerminal& pty)
{
  int nread = pty.read();
  if (nread > 0)
    write(pty.getBuffer(), nread);
    
  return(*this);
}

PseudoTerminal& PseudoTerminal::operator>>(PseudoTerminal& pty)
{
  int nread = read();
  if (nread > 0)
    pty.write(getBuffer(), nread);
    
  return(*this);
}
