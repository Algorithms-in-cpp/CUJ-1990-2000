/* ------- Listing one - Rcvr.h ------- */
#ifndef Rcvr_h_included
#define Rcvr_h_included
     
/*
 * The following enum defines a standard set 
 * of status codes. Any implementation of Rcvr
 * should map status codes returned by the 
 * receiver to one of the codes defined here. 
 * These should be the only status codes 
 * returned from invocation of the function 
 * pointers.
 */
enum RcvrStatusCodes 
    {Success, Fail /* other codes */};
     
enum RcvrCmdCodes
{
  SET_FREQ, GET_FREQ, GET_STATUS, 
  SET_SCAN_RANGE, START_SCAN, STOP_SCAN
};
     
typedef struct Rcvr
{
  void *data;
     
  int (*setFreq)
    (struct Rcvr *r, const char *args);

  int (*getFreq)(struct Rcvr *r);
  int (*getStatus)(struct Rcvr *r);
  int (*setScanRange)
    (struct Rcvr *r, const char *args);
  int (*startScan)(struct Rcvr *r);
  int (*stopScan)(struct Rcvr *r);
} Rcvr;
#endif
 