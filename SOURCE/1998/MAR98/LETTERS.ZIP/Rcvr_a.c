/* ------- Listing 3 - Rcvr_a.c ------- */
#include "Rcvr.h"
#include "Rcvr_a.h"
     
typedef struct
{
  /* arbitrarily complex data */
} Rcvr_a_data;
     
Rcvr *newRcvr_a(Rcvr *r)
{
  Rcvr_a_data *data;
     
  data = (Rcvr_a_data *) 
    calloc(sizeof (Rcvr_a_data));
     
  /* initialize data as needed */
     
  if(r == 0)
    r = (Rcvr *) calloc(sizeof (Rcvr));
     
  r->data         = data;
  r->setFreq      = Rcvr_a_setFreq;
  r->getFreq      = Rcvr_a_getFreq;
  r->getStatus    = Rcvr_a_getStatus;
  r->setScanRange = Rcvr_a_setScanRange;
  r->startScan    = Rcvr_a_startScan;
  r->stopScan     = Rcvr_a_stopScan;
     
  /* Do any setup needed by the receiver */
     
  return r;
}
     
void deleteRcvr_a(Rcvr *r)
{
  Rcvr_a_data *data = (Rcvr_a_data *) r->data;
     
  /* Shutdown the radio, etc */
     
  /* delete data struct, including any
     memory owned by the struct (I/O
     buffers, etc) */
     
  free(r);
}
     
int Rcvr_a_setFreq(
      struct Rcvr *r, const char *args)
{
  Rcvr_a_data *data = (Rcvr_a_data *) r->data;
     
  /* receiver A specific implementation */
}
     
int Rcvr_a_getFreq(struct Rcvr *r)
{
  Rcvr_a_data *data = (Rcvr_a_data *) r->data;
     
  /* receiver A specific implementation */
}
     
int Rcvr_a_getStatus(struct Rcvr *r)
{
  Rcvr_a_data *data = (Rcvr_a_data *) r->data;
     
  /* receiver A specific implementation */
}
     
int Rcvr_a_setScanRange(
      struct Rcvr *r, const char *args)
{
  Rcvr_a_data *data = (Rcvr_a_data *) r->data;
     
  /* receiver A specific implementation */
}
     
int Rcvr_a_startScan(struct Rcvr *r)
{
  Rcvr_a_data *data = (Rcvr_a_data *) r->data;
     
  /* receiver A specific implementation */
}
     
int Rcvr_a_stopScan(struct Rcvr *r)
{
  Rcvr_a_data *data = (Rcvr_a_data *) r->data;
     
  /* receiver A specific implementation */
}
