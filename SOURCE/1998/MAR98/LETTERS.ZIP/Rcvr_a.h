/* ------- Listing 2 - Rcvr_a.h ------- */
#ifndef Rcvr_a_h_included
#define Rcvr_a_h_included
     
Rcvr *newRcvr_a(Rcvr *r);
void  deleteRcvr_a(Rcvr *r);
int   Rcvr_a_setFreq(
        struct Rcvr *r, const char *args);
int   Rcvr_a_getFreq(struct Rcvr *r);
int   Rcvr_a_getStatus(struct Rcvr *r);
int   Rcvr_a_setScanRange(
        struct Rcvr *r, const char *args);
int   Rcvr_a_startScan(struct Rcvr *r);
int   Rcvr_a_stopScan(struct Rcvr *r);
#endif