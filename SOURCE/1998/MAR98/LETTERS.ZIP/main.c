/* ------- Listing 4 - main.c ------- */
#include <Rcvr.h>
#include <Rcvr_a.h>
#include <Rcvr_b.h>
#include <Rcvr_c.h>
     
/* This declares functions needed for getting 
   command input and returning responses */
#include <comm_funcs.h>
     
#define NUM_RCVRS 3
     
Rcvr *receiver[NUM_RCVRS];
     
int main()
{
  char *inBuf;
  int   rIndex;
  int   cmdCode;
  char *args;
  int   ret;
  float freq;
     
  receiver[0] = newRcvr_a(0);
  receiver[1] = newRcvr_b(0);
  receiver[2] = newRcvr_c(0);
     
  while(1)
  {
    inBuf = getCommandInput();
     
    /* parse inBuf to rIndex, cmdCode, args */
     
    switch(cmdCode)
    {
    case SET_FREQ:
      ret = receiver[rIndex]->
        setFreq(receiver[rIndex], args);
      sendResponse(ret);
      break;
     
    case GET_FREQ:
      freq = receiver[rIndex]->
        getFreq(receiver[rIndex]);
      sendFreq(freq);
      break;
     
    /* etc */
     
    }
     
    free(inBuf);
  }
}
