// DisplayDoc.cpp : implementation of the CDisplayDoc class
//

#include "stdafx.h"
#include "Display.h"

#include "DsplyDoc.h"
#include "dplyview.h"
#include "editlut.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDisplayDoc

IMPLEMENT_DYNCREATE(CDisplayDoc, CDocument)

BEGIN_MESSAGE_MAP(CDisplayDoc, CDocument)
	//{{AFX_MSG_MAP(CDisplayDoc)
	ON_UPDATE_COMMAND_UI(ID_VIEW_LOOKUPTABLES, OnUpdateViewLookuptables)
	ON_COMMAND(ID_LUT_GREYSCALE, OnLutGreyscale)
	ON_UPDATE_COMMAND_UI(ID_LUT_GREYSCALE, OnUpdateLutGreyscale)
	ON_COMMAND(ID_LUT_OPTOMISE, OnLutOptomise)
	ON_COMMAND(ID_LUT_PSCOLOUR, OnLutPscolour)
	ON_UPDATE_COMMAND_UI(ID_LUT_PSCOLOUR, OnUpdateLutPscolour)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDisplayDoc construction/destruction

CDisplayDoc::CDisplayDoc()
{
	m_bitmap = NULL;
	m_image = NULL;
	m_editlut_open = FALSE;
	m_colourmode = GREYSCALE;
}

CDisplayDoc::~CDisplayDoc()
{
}

BOOL CDisplayDoc::OnNewDocument()
{
		return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// CDisplayDoc serialization

void CDisplayDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDisplayDoc diagnostics

#ifdef _DEBUG
void CDisplayDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDisplayDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDisplayDoc commands

BOOL CDisplayDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	// TODO: Add your specialized creation code here
	
	// create an image object
	if(( m_image = new Image()) == NULL )
		return( FALSE );

	// open image file
	if( m_image->open( lpszPathName ) == FALSE )
	{
		delete m_image;	m_image = NULL;
		return FALSE;
	}

	// create a bitmap object
	if( (m_bitmap = new ImagePsColourDib(0)) == NULL )
	{
		delete m_image; m_image = NULL;
		return FALSE;
	}

	// create an image from our image
	if( m_bitmap->CreateDib(m_image) == FALSE )
	{
		// can't create dib
		delete m_image;  m_image = NULL;
		delete m_bitmap; m_bitmap = NULL;
		return FALSE;
	}

	// create a histogram of the image band 0
	m_histogram.histogram(m_image, 0 );

	m_bitmap->Optomise(m_histogram);

	// and repaint windows
	UpdateAllViews(NULL,UPDATE_BITMAP);

	return TRUE;
}

ImagePsColourDib* 
CDisplayDoc::getBitmap(void) const
{
	return m_bitmap;
}

Image* 
CDisplayDoc::getImage(void) const
{
	return m_image;
}

const ImageHist& 
CDisplayDoc::getHist( void ) const
{
	return m_histogram;
}


void CDisplayDoc::DeleteContents() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	// free up memory
	if(m_bitmap) delete m_bitmap;
	if(m_image ) delete m_image;

	// allow reuse
	m_bitmap = NULL;
	m_image = NULL;

	CDocument::DeleteContents();
}

BOOL 
CDisplayDoc::isGreyScale(void) const
{
	return ( m_colourmode == GREYSCALE );
}

BOOL CDisplayDoc::isPseudoCol(void) const
{
	return ( m_colourmode == PSEUDOCOL );
}

void CDisplayDoc::OnUpdateViewLookuptables(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( m_editlut_open == FALSE);	
}

void CDisplayDoc::OnChangedViewList() 
{
	// TODO: Add your specialized code here and/or call the base class
	POSITION pos = GetFirstViewPosition();

	m_editlut_open = FALSE;
	BOOL display_open = FALSE;

	while( pos != NULL )
	{
	 	CView* pView = GetNextView( pos );
		ASSERT_VALID( pView );

		if( pView == NULL ) continue; // skip NULL views

		if( pView->IsKindOf( RUNTIME_CLASS( EditLut )) ) 
		{
			m_editlut_open = TRUE;
			continue;
		}
		else

		if( pView->IsKindOf( RUNTIME_CLASS( CDisplayView )) ) 
		{
			display_open = TRUE;
			continue;
		}

	}

	// if the display is open defualt handling
	if( display_open ) 	
		CDocument::OnChangedViewList();
	else	
		OnCloseDocument(); // no display open close document 
	
	// default handler
	CDocument::OnChangedViewList();
}

// close from if display view is closed
BOOL CDisplayDoc::CanCloseFrame(CFrameWnd* pFrame) 
{
	// TODO: Add your specialized code here and/or call the base class
	ASSERT_VALID( pFrame );
	
	CView* pCurrView;
	
	if(( pCurrView = pFrame->GetActiveView() ) != NULL )
	{
		if( pCurrView->IsKindOf( RUNTIME_CLASS( CDisplayView ) ) )
		{
	 		return SaveModified();
		}	
		else	return TRUE;
	}

	return CDocument::CanCloseFrame(pFrame);
}

void
CDisplayDoc::UpdateBitmap(void)
{
	m_bitmap->UpdateDib(); // create a new palette
	UpdateAllViews(NULL,UPDATE_BITMAP); // tell people about it
}

void CDisplayDoc::OnLutGreyscale() 
{
	// TODO: Add your command handler code here
	if( isPseudoCol() )
	{	
		m_colourmode = GREYSCALE;
		m_bitmap->SetGrey(); // set	up defualt colour mode
		UpdateBitmap();		 // update bitmap
	}

}

void CDisplayDoc::OnUpdateLutGreyscale(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( !isGreyScale() );	
}

void CDisplayDoc::OnLutOptomise() 
{
	// TODO: Add your command handler code here

	if( isGreyScale() )
	{
	 	ImagePointLut newlut = m_bitmap->GetBandLut( 0 );
		newlut.Optimise( getHist() );
		m_bitmap->UpdateLut( newlut, ImagePsColourDib::GREY );
	}
	else
	{
		ImagePointLut newrlut = m_bitmap->GetBandLut( 0 );
		newrlut.Optimise( getHist(), ImagePointLut::RED );
		m_bitmap->UpdateLut( newrlut, ImagePsColourDib::RED);

	 	ImagePointLut newglut = m_bitmap->GetBandLut( 1 );
		newglut.Optimise( getHist(), ImagePointLut::GREEN );
		m_bitmap->UpdateLut( newglut, ImagePsColourDib::GREEN );
	
	 	ImagePointLut newblut = m_bitmap->GetBandLut( 2 );
		newblut.Optimise( getHist(), ImagePointLut::BLUE );
		m_bitmap->UpdateLut( newblut, ImagePsColourDib::BLUE );
	}

	UpdateBitmap();	
}

void CDisplayDoc::OnLutPscolour() 
{
	// TODO: Add your command handler code here
	if( isGreyScale() )
	{	
		m_colourmode = PSEUDOCOL;
		m_bitmap->SetColour(); // set	up defualt colour mode
		UpdateBitmap();		 // update bitmap
	}	
}

void CDisplayDoc::OnUpdateLutPscolour(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( !isPseudoCol() );	
	
}

void CDisplayDoc::SetColourMode( ColourMode mode )
{
	m_colourmode = mode;
}

