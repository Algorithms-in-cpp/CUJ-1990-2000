//	File: iinfo.hpp
//	Description: Image information class 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards   1997
//


#ifndef IMAGELIB_INFO
#define IMAGELIB_INFO

#include "isystem.hpp"
#include "iarea.hpp"

enum IFormat { F_NONE, TARGA, TARGA_RLE, TARGA_PAL };
enum IReadType { R_NONE, READ_ONLY };
enum IStore { S_NONE, BIP };

class ImageInfo
{
  	public:
	
  	ImageInfo();				  // defualt constructor every thing set to 0
  	ImageInfo( const ImageInfo& info );		// copy constructor
  	
  	~ImageInfo();				  // destructor

	BOOL isOpen() const;
	BOOL isEqual(const ImageInfo& info ) const;   // are equal
	void operator=( const ImageInfo& info );   // copy object

    // get information on image
    const int& getWidth( void ) const;		// width of image in pixels
		  int& getWidth( void );			// non constant version
	
	const int& getHeight( void ) const;		// height of image in pixels
		  int& getHeight( void );			// non constant version
	
	const int& getNoBand( void ) const;	// number of bands in image
		  int& getNoBand( void );			// non constant version

	const long& getHeaderSize( void ) const;	// size of header in bytes
		  long& getHeaderSize( void );			// non constant version

	const int& getBytesPerBand( void ) const;	// number of bytes for in a line of band x
		  int& getBytesPerBand( void );			// non constant version

	const int& getBytesPerLine( void ) const;	// number of bytes in a line of all bands
		  int& getBytesPerLine( void );			// non constant version

	const char* getFilename( void ) const;	   // get filename and path of image
		   void setFilename( const char* string );   // set filename
	
	const char* getClipFilename( void ) const; // get file name with the path removed 

	const ImageArea& getArea( void );		// create a area class of image 

    const IFormat& getFormat( void ) const;		  // return image format
          IFormat& getFormat( void );			  // non constant verwsion
    
   	const IReadType& getFileType ( void ) const;  // return read write flags
	      IReadType& getFileType ( void );		  // non constant version

   	const IStore& getStorage ( void ) const;    // return storage order
	      IStore& getStorage ( void );		  // non constant version

   	private:

  	int m_width;
  	int m_height;
  	int m_noband;
	int m_bytesperband;
	int m_bytesperline;

	long m_headersize;

	IFormat m_format;
	IReadType m_readtype;
	IStore m_storage;

	ImageArea m_area;

	char* m_filename;
};


// inline versions
BOOL inline operator==( const ImageInfo& first, const ImageInfo& second)
{
 	return first.isEqual( second );
}

BOOL inline operator!=( const ImageInfo& first, const ImageInfo& second)
{
 	return !first.isEqual( second );
}

inline BOOL ImageInfo::isOpen() const
{
	if(		// do a breif vailidity check
  	m_width > 0 &&
  	m_height > 0  &&
  	m_noband > 0  &&
	m_bytesperband > 0 &&
	m_bytesperline > 0 &&
	m_format != F_NONE	 &&
	m_readtype != R_NONE &&
	m_storage != S_NONE	 &&
	m_filename != NULL	 ) return TRUE;
	else return FALSE;

}

// get information on image
inline const int& ImageInfo::getWidth( void ) const		// width of image in pixels
{
	return m_width;
}
inline int& ImageInfo::getWidth( void )			// non constant version
{
	return m_width;
}
	
inline const int& ImageInfo::getHeight( void ) const		// height of image in pixels
{
	return m_height;
}
inline int& ImageInfo::getHeight( void )			// non constant version
{
	return m_height;
}
	
inline const int& ImageInfo::getNoBand( void ) const	// number of bands in image
{
	return m_noband;
}
inline int& ImageInfo::getNoBand( void )			// non constant version
{
	return m_noband;
}

inline const long& ImageInfo::getHeaderSize( void ) const		// width of image in pixels
{
	return m_headersize;
}

inline long& ImageInfo::getHeaderSize( void )			// non constant version
{
	return m_headersize;
}


inline const int& ImageInfo::getBytesPerBand( void ) const	// number of bytes for in a line of band x
{
 	return m_bytesperband;
}

inline int& ImageInfo::getBytesPerBand( void )			// non constant version
{
 	return m_bytesperband;
}

inline const int& ImageInfo::getBytesPerLine( void ) const	// number of bytes in a line of all bands
{
 	return m_bytesperline;
}
inline int& ImageInfo::getBytesPerLine( void )			// non constant version
{
 	return m_bytesperline;
}

// get filename  - may return NULL 
inline const char* ImageInfo::getFilename( void ) const	   // get filename and path of image
{
//	IASSERT( m_filename != NULL );
	return m_filename;
}
	
inline const ImageArea& ImageInfo::getArea( void )		  // return image area
{
	m_area = ImageArea(0,0,m_width,m_height);
	return m_area;
}

inline const IFormat& ImageInfo::getFormat( void ) const		  // return image format
{
	return m_format;
}

inline IFormat& ImageInfo::getFormat( void )			  // non constant verwsion
{
	return m_format;
}

inline const IReadType& ImageInfo::getFileType ( void ) const  // return read write flags
{
	return m_readtype;
}
inline IReadType& ImageInfo::getFileType ( void )		  // non constant version
{
	return m_readtype;
}

inline const IStore& ImageInfo::getStorage ( void ) const    // return storage order
{
	return m_storage;
}

inline IStore& ImageInfo::getStorage ( void )		  // non constant version
{
	return m_storage;
}
	
 

#endif
