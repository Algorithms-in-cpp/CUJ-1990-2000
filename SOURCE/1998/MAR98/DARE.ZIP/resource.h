//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Display.rc
//
#define IDD_ABOUTBOX                    100
#define IDS_STRING107                   107
#define CG_IDS_PROGRESS_CAPTION         108
#define IDS_STRING109                   109
#define IDS_STRING110                   110
#define IDS_STRING111                   111
#define IDS_STRING112                   112
#define IDS_STRING113                   113
#define IDS_STRING114                   114
#define IDS_STRING115                   115
#define IDS_STRING116                   116
#define IDS_STRING117                   117
#define IDS_STRING118                   118
#define IDS_STRING119                   119
#define IDS_STRING120                   120
#define IDS_STRING121                   121
#define IDS_STRING122                   122
#define IDS_STRING123                   123
#define IDS_STRING124                   124
#define IDS_STRING125                   125
#define IDS_STRING126                   126
#define IDR_MAINFRAME                   128
#define IDR_DISPLATYPE                  129
#define IDS_GREYCHANNEL                 130
#define IDS_ERROR_USERBREAK             131
#define IDS_ERROR_MEMALLOC              132
#define IDS_ERROR_FILEOPEN              133
#define IDS_ERROR_FILEREAD              134
#define IDS_ERROR_FILEWRITE             135
#define IDS_ERROR_FILESEEK              136
#define IDS_ERROR_OBJOPEN               137
#define IDS_ERROR_OBJINVALID            138
#define IDS_ERROR_UNHANDLEDTARGA        139
#define IDS_ERROR_UNKNOWNFORMAT         140
#define IDS_ERROR_FAILEDASSERTION       141
#define IDS_ERROR_UNKNOWN               142
#define IDD_EDITLUT                     142
#define IDS_ERROR_OBJARGS               143
#define IDC_EDLUT_XVAL                  1074
#define IDC_EDLUT_YVAL                  1075
#define IDC_EDLUT_COL                   1077
#define IDC_EDLUT_UPDATE                1078
#define IDC_EDLUT_LUT                   1089
#define IDC_EDLUT_NEXT                  1090
#define IDC_EDLUT_PREV                  1091
#define IDC_EDLUT_DELETE                1092
#define IDC_LBUT_UNDO                   1116
#define IDC_LBUT_DEFAULT                1117
#define IDC_LBUT_LOG                    1118
#define IDC_LBUT_EQUAL                  1119
#define IDC_LBUT_EXP                    1120
#define IDC_LBUT_MINMAX                 1121
#define IDC_LBUT_OPTO                   1122
#define IDC_LBUT_INVERT                 1123
#define ID_VIEW_LOOKUPTABLES            32771
#define ID_LUT_GREYSCALE                32772
#define ID_LUT_PSCOLOUR                 32773
#define ID_LUT_OPTOMISE                 32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
