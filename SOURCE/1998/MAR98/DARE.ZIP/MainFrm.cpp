// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Display.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_UPDATE_COMMAND_UI(ID_VIEW_LOOKUPTABLES, OnUpdateViewLookuptables)
	ON_COMMAND(ID_VIEW_LOOKUPTABLES, OnViewLookuptables)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	return CMDIFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::CreateChildWindow( CDocTemplate* pTemplate )
{
	ASSERT_VALID(pTemplate);

	CMDIChildWnd* pActiveChild = MDIGetActive();
	CDocument* pDocument;
	if (pActiveChild == NULL ||
	  (pDocument = pActiveChild->GetActiveDocument()) == NULL)
	{
		TRACE0("Warning: No active document for WindowNew command.\n");
		AfxMessageBox(AFX_IDP_COMMAND_FAILURE);
		return;     // command failed
	}

	// otherwise we have a new frame !
	CFrameWnd* pFrame = pTemplate->CreateNewFrame(pDocument, pActiveChild);
	if (pFrame == NULL)
	{
		TRACE0("Warning: failed to create new frame.\n");
		return;     // command failed
	}
	pTemplate->InitialUpdateFrame(pFrame, pDocument);
}


void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd) 
{
	CMDIFrameWnd::OnPaletteChanged(pFocusWnd);
	
	// TODO: Add your message handler code here

	// always realize the palette for the active view
	CMDIChildWnd* pMDIChildWnd = MDIGetActive();
	if (pMDIChildWnd == NULL)
		return; // no active MDI child frame
	CView* pView = pMDIChildWnd->GetActiveView();
	
	if( pView != NULL )
	{
		// notify all child windows that the palette has changed
		SendMessageToDescendants(WM_DOREALIZE, (WPARAM)pView->m_hWnd, 0L);
	}
}

BOOL CMainFrame::OnQueryNewPalette() 
{
	// TODO: Add your message handler code here and/or call default
	CMDIChildWnd* pMDIChildWnd = MDIGetActive();
	
	if (pMDIChildWnd == NULL)
		return FALSE; // no active MDI child frame (no new palette)
	
	CView* pView = pMDIChildWnd->GetActiveView();
	
	// if view - just notify the target view
	if( pView != NULL )
	{
		pView->SendMessage(WM_DOREALIZE, (WPARAM)pView->m_hWnd, 1L);
	}

	return TRUE;
}


// enable if a document avaliable
void CMainFrame::OnUpdateViewLookuptables(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable((GetActiveDocument() != NULL));
}

void CMainFrame::OnViewLookuptables() 
{
	// TODO: Add your command handler code here
	CreateChildWindow( ((CDisplayApp*)AfxGetApp())->m_pEditLutTemplate );
}
