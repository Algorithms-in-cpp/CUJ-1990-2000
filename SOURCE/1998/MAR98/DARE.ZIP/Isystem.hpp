//	File: isystem.hpp
//	Description: library wide definitions 
//
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//


#ifndef	IMAGELIB_IMAGESYSTEM
#define	IMAGELIB_IMAGESYSTEM

#ifndef	NULL
	#define	NULL 0L
#endif

#ifndef	TRUE
	#define TRUE 1L	
#endif

#ifndef	FALSE
	#define	FALSE 0L
#endif

typedef unsigned char BYTE;  
typedef unsigned short WORD;
typedef unsigned long DWORD;
typedef int BOOL;

#include "ierror.hpp"	 	// error handleing routines and definitions

#endif	// IMAGELIB_IMAGESYSTEM	
