//      File: iconline.hpp
//      Description: control line class for user defined lookuptable editor 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//

#ifndef IMAGELIB_IMAGECONTLINE
#define IMAGELIB_IMAGECONTLINE

#include "iplut.hpp"

#include "itlist.hpp"
#include "idragpnt.hpp"

class ImageControlLine : public ImageTList< ImageDragPoint >
{
    public:
    ImageControlLine( const CRect& area );
    ~ImageControlLine( void );

    ImageDragPoint* MouseClick( const CPoint& point );
    ImageDragPoint* MouseMove( const CPoint& point );
    ImageDragPoint* Shift( int xmove, int ymove );
    void Draw( CDC* pDC );
    
    ImageDragPoint* Delete( void ); // delete selected point 
	ImageDragPoint* SelectNextPoint( void );
	ImageDragPoint* SelectPrevPoint( void );

    void UpdateLut( ImagePointLut& lut );
    void UpdateLine( const ImagePointLut& lut );

	void ConvIP( CPoint& to, const ImagePoint& from	);
	void ConvCP( ImagePoint& to, const CPoint& from	);

	ILISTPOS AddPoint( const ImageDragPoint& point);
	ILISTPOS HitTest( const CPoint& point );
	ILISTPOS FindSelected( void );

	void Sort( void );
	void SetSelected( ILISTPOS pos );
	void ClearSelected( void );

    private:
    CRect FullArea;
	ILISTPOS selected_pos;

	double m_xscaletoip;	
	double m_yscaletoip;
	double m_xscaletocp;
	double m_yscaletocp;

};

#endif // end IMAGELIB_IMAGECONTLINE
