// DisplayDoc.h : interface of the CDisplayDoc class
//
/////////////////////////////////////////////////////////////////////////////

#include "image.hpp"
#include "ipcoldib.hpp"

class CDisplayDoc : public CDocument
{
protected: // create from serialization only
	CDisplayDoc();
	DECLARE_DYNCREATE(CDisplayDoc)

// Attributes
public:
	enum ColourMode {GREYSCALE, PSEUDOCOL};

	ColourMode m_colourmode;

	Image* m_image;
	ImagePsColourDib* m_bitmap;
	ImageHist m_histogram;

	BOOL m_editlut_open;

// Operations
public:

	ImagePsColourDib* getBitmap( void ) const;
	Image* getImage(void) const;
	const ImageHist& getHist( void ) const;
	BOOL isGreyScale(void) const;
	BOOL isPseudoCol(void) const;

	void UpdateBitmap(void);
	void SetColourMode( ColourMode mode );

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDisplayDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void DeleteContents();
	virtual void OnChangedViewList();
	virtual BOOL CanCloseFrame(CFrameWnd* pFrame);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDisplayDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDisplayDoc)
	afx_msg void OnUpdateViewLookuptables(CCmdUI* pCmdUI);
	afx_msg void OnLutGreyscale();
	afx_msg void OnUpdateLutGreyscale(CCmdUI* pCmdUI);
	afx_msg void OnLutOptomise();
	afx_msg void OnLutPscolour();
	afx_msg void OnUpdateLutPscolour(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
