//	File: idib.hpp
//	Description: windows device independant bitmp 
//
//	Rev: A
//	Created: Tues 6th Sept 1994
//	Author: C Dare-Edwards
//	

#ifndef IMAGELIB_IMAGEDIB
#define IMAGELIB_IMAGEDIB

class ImageDib 
{
private:
   // dib info header pointers 
    LPBITMAPFILEHEADER m_pBMFileHeader;
    LPBITMAPINFOHEADER m_pBMInfoHeader;
    LPBITMAPINFO       m_pBMInfo;
    LPSTR              m_pBMData; 

	// current palette
    CPalette*  m_palette;	   
	BOOL m_palettechanged;
	BOOL m_haspalette;

	// working varibles 
    char*    m_pBuffer;			  // DIB data buffer
    char*    m_pdata;		
    unsigned long      m_length;           // total buffer length
    int        m_bits;            // number of color bits per pixel
    int 	   m_paletteSize;     // palette size
    long 	   m_lineLength;      // width in bytes of a line  
 
public:
	// construction
    ImageDib( void );
    ImageDib( ImageDib& dib ); // do nothing copy constructor
    
	~ImageDib( void );
    
    // display routine
    BOOL Stretch(CDC*, CRect output, CRect intput );

    // palette routines
    void SetPalette( int color, int red, int green, int blue);  // set a palette entry
    void ClearPalette( void );   // set all to 0 

	BOOL PaletteChanged( void ) const; 	// has the palette changed 
	BOOL hasPalette( void ) const; 	// has this bimap got a palette 

    CPalette* GetPalette( void );	//create a new palette and return

    // general routines
    int  getPaletteSize( void );		// number of palette entries
    int  getColourBits( void );		 // bits per pixel
    long getLength( void );   	 // length of the bitmap in bytes
    long getWidth ( void );		 // width in pixels
    long getHeight( void );		 // height in pixels

protected:
    // creatation rountines
    BOOL CreateDib( int depth, int width , int height );
    
    // read and write routines
    BOOL SetBits( unsigned char* buffer,  int line, int numlines );
    BOOL GetBits( unsigned char* buffer,  int line, int numlines );

private:

    CPalette* CreatePalette( void ); 	// create a palette for the bitmap   
	BOOL Allocate( void );		//allocate bitmap memory
};


inline BOOL 
ImageDib::PaletteChanged( void ) const  
{ 
	return( m_palettechanged ); 
}

inline BOOL 
ImageDib::hasPalette( void ) const  
{ 
	return( m_haspalette ); 
}

inline int 
ImageDib::getPaletteSize ( void )
{
 	return( m_paletteSize );
} 

inline int 
ImageDib::getColourBits()
{
    return m_bits;
}

long inline 
ImageDib::getWidth( )
{
 	return  (long)m_pBMInfoHeader->biWidth;
}

inline long 
ImageDib::getHeight()
{
   return    (long) m_pBMInfoHeader->biHeight;
}

inline 
long ImageDib::getLength()
{
    return m_length;
}


#endif // IMAGELIB_IMAGEDIB
