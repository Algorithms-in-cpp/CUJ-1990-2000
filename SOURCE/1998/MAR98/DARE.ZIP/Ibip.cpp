//	File: ibip.cpp
//	Description: band interleave by line handleing routines
//
//	Author: C Dare-Edwards 1997
//	
//	
//  Copyright Conrad Dare-Edwards   
//


#include "stdafx.h"

#include "isystem.hpp"
#include "ibip.hpp"
#include "ifile.hpp"
#include <memory.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


ImageBIP::ImageBIP( void )
{
        isopen = FALSE;      // initialise important varibles
		linebuffer = NULL;
		cbuffer = NULL;
}

// ImageBIP::~ImageBIP ( void )
// 		disimp deconstrutor close up file and clean up  
 
ImageBIP::~ImageBIP ( void )
{
	if( linebuffer ) delete[] linebuffer;
	if( cbuffer )	delete[] cbuffer;
	isopen = FALSE;  
}

// setup internals
// check isopen to test
void
ImageBIP::Setup( void )
{
	IASSERT( !isOpen() );

	// setup internal varibles
	moveToLine( 0 );				 // shift line postion to first line
	
	/// free up anu allocated memory
	if( linebuffer ) delete[] linebuffer; 
	if( cbuffer )    delete[] cbuffer; 

	// allocate some new memory
  	linebuffer = new ( char[ getBytesPerLine() ] );	  // line read buffer
	cbuffer = 	 new ( char[ getBytesPerLine() ] );	  // mutlti band conversion buffer

	if( cbuffer == NULL || linebuffer == NULL )		 // test that we are all ok
  	{
  	 		isopen = FALSE;					// we are not ready
  	 		IPOSTERROR( ERR_MEM_ALLOC );	 // throw a wobbly
  	}
	else 
	{ 
		isopen = TRUE; // all ready to go 
	}	
}

/////////////////////////////////////////////////////////////////////////////
// int read( void* buffer, unsigned int startline, unsigned int numberoflines, unsigned int band);
// 		read a single band of imagery into buffer
//      
//		void* buffer	- buffer to read the data into
//		unsigned int startline - line to start reading
//		unsigned int numberoflines - number of lines from startline to read
//		unsigned int band -	band to read
//
//		Reads imagery into a allocated buffer coping over the band of data 
//		into buffer supplied for every line wanted 
int 
ImageBIP::read( void* buffer, int startline, int numberoflines, int band)
{
// test 
IASSERT( isOpen() );
IASSERT( buffer != NULL );
IASSERT( startline >= 0 && startline < getHeight() );
IASSERT( numberoflines > 0);
IASSERT( band < getNoBand() && band >= 0 );
 
 if( !isOpen() )	return( FALSE );

 while( numberoflines -- )
 {
		// shift to line
 		if( moveToLine( startline++ ) == 0 ) return( FALSE );  // line move failed
	
		// read line of imagery
		if(!ImageFile::read(linebuffer, getBytesPerLine()) )
		{
			moveToLine( 0 ); // in case we have moved the file position 
			return( FALSE ); // read failed
		}
	
		lineposition++;  // update line position
	
		// strip out the data we want
		ConBIPtoBIL( linebuffer, (char*)buffer, 1, band  );
} 
 
return( TRUE );
}

//////////////////////////////////////////////////////////////////////////////////////
// int ImageBIP::read( void* buffer, unsigned int startline, unsigned int numberoflines)
// 		read image data and put formated into buffer
//
// 		void* buffer -	pointer to buffer to put data
// 		unsigned int startline -	line to start at ( gets this line ) starts from 0
// 		unsigned int numberoflines - number of lines to put in buffer if 1 gets startline 
// 		returns - 	1 on success else 0
//
//		Moves file position to beginning of line reads lump of image then updates the line 
//		position else moving file position back to the beginning of the file on error
int 
ImageBIP::read( void* buffer, int startline, int numberoflines)
{
	// test arguments
	IASSERT( isOpen() );
	IASSERT( buffer != NULL );
	IASSERT( startline >= 0 && startline < getHeight() );
	IASSERT( numberoflines > 0);
	
	// shift filepostion if needed
	if( moveToLine( startline ) == 0 ) return( FALSE ); // line move failed
	
	// read it
	if( ImageFile::read(buffer,  (numberoflines * getBytesPerLine())) != 0 )
	{
		lineposition += numberoflines;  // update line position
		return( ConBIPtoBIL( (char*)buffer, numberoflines ) );
	} 
	else // read error
	{
		moveToLine( 0 ); // in case we have moved the file position 
		return( FALSE ); // read failed
	}
}	

int
ImageBIP::ConBIPtoBIL( char* buffer, int numberoflines )
{
	char* cbuffoffset;
	char* buffoff;
	
	if( getNoBand() == 1 ) return( TRUE );   // no need to convert
	
	while( numberoflines-- > 0 )
	{
		memcpy( cbuffer, buffer, getBytesPerLine() );	// move data across 		
						
	    for( int y =0; y < getNoBand(); y ++ )	 // for number of bands
	    {
	    	cbuffoffset = &cbuffer[y];		 // bip start pos 
	    	buffoff = &buffer[ ( y * getWidth() ) ];	 // bil line
	    	
			int x = getWidth();
	    	while(x--) 							  // for all strip out data
	        {
	         	*buffoff++ = *cbuffoffset;
	         	cbuffoffset = &cbuffoffset[getNoBand()];	
	     	}
		}
	
	    buffer = &buffer[ getBytesPerLine() ];
	} 
	return( TRUE );
}

//////////////////////////////////////////////////////////////////////////////
// strip a single band on imagery from a bip buffer
int
ImageBIP::ConBIPtoBIL( char* rbuffer, char* wbuffer, int numberoflines, int band )
{
	if( getNoBand() == 1 )	 // single band image
	{		
		memcpy( wbuffer, rbuffer, getWidth()*numberoflines );	// move data across 		
 		return( TRUE );   							// no need to convert
	}

	rbuffer = &rbuffer[band];		 // bip start pos 
	while( numberoflines-- > 0 )	// for all lines
	{
			int x = getWidth();
	    	while(x--) 							  // for all strip out data
	        {
	         	*wbuffer++ = *rbuffer;
	         	rbuffer = &rbuffer[getNoBand()];	
	     	}
	
	} 
	return( TRUE );
}

// int	ImageBIP :: moveToLine( unsigned int lineNumber )
// 		moves file position to the start of line linenumber
// 		After error or somthing that might have changed file postion
// 		move to line 0 else current positional move may be wrong
//
// 		unsigned int lineNumber -	new line to move to the start of
// 		returns -	1 on success else 0
//
//		If move to line 0 moves from beginning of file else will move from current
//		position. Works out line diference multiples this by line size and moves that
//		many bytes from current position 
int 
ImageBIP :: moveToLine( int lineNumber )
{
	
	if( lineNumber == 0 )	// test if line 0
	{ 
		ImageFile::seek( getHeaderSize(), ImageFile::BEGINNING );
		lineposition = 0;
		return( TRUE ); 	// return success
	}
	
	// compute line offset	
	long lineDiff = lineNumber - lineposition;
	
	// test if we have to move anywhere
	if(lineDiff == 0)
	{
		return(TRUE); // success
	}
	
	// jump to new position and test for error	
	if (! ImageFile::seek( (lineDiff * getBytesPerLine()), ImageFile::CURRENT ) )
	{
	 	// seek error
		moveToLine( 0 ); 	// move back to line 0 ( call ourselves 		
		return(FALSE);	 		// return error
	}
	else	// alls well update line position and return
	{
		lineposition = lineNumber;
		return(TRUE);	// success
	}
}


