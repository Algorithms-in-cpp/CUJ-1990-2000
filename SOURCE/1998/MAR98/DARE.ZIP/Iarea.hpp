//	File: iarea.hpp
//	Description: area points class 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//

#ifndef	IMAGELIB_IMAGEAREA
#define IMAGELIB_IMAGEAREA

////////////////////////////////////////////////////////////////////
// ImageArea..
// Derived from ImagePoint holds two points and defines and area
//

#include "isystem.hpp"
#include "ipoint.hpp"

class ImageShape; // pre defined

class ImageArea
{
 	public:
 	ImageArea( void );	// default constructor
 	ImageArea( int x, int y , int width, int height );
 	ImageArea( const ImagePoint& top, const ImagePoint& bottom );
 	ImageArea( const ImageArea& area );
    
    const ImagePoint& getTop( void ) const;
    const ImagePoint& getBot( void ) const;
    
    // the only non constant routine
    void Copy( const ImageArea& area );
    
	ImageArea& operator=( const ImageArea& copy );

    int getTopX( void ) const;
    int getTopY( void ) const;
    int getBotX( void ) const;
    int getBotY( void ) const;
    
    int getWidth( void ) const;
    int getHeight( void ) const;
    BOOL isContained( const ImageArea& area ) const;
    BOOL isContained( const ImagePoint& point ) const;
    
    private:
    ImagePoint top, bot;  // the points 
};

BOOL inline operator==( const ImageArea& first, const ImageArea& second)
{
 	return(( first.getTop() == second.getTop() && first.getBot() == second.getBot() ) ? TRUE: FALSE );
}

BOOL inline operator!=( const ImageArea& first, const ImageArea& second)
{
 	return(( first.getTop() != second.getTop() || first.getBot() != second.getBot() ) ? TRUE: FALSE );
}


////////////////////////////////////////////////////////////////////
// get top point's x value
inline int 
ImageArea::getTopX( void ) const
{
 	return top.getX();
}

////////////////////////////////////////////////////////////////////
// get top point's y value
inline int 
ImageArea::getTopY( void ) const
{
 	return top.getY();
}

////////////////////////////////////////////////////////////////////
// get bottom point's x value
inline int 
ImageArea::getBotX( void ) const
{
 	return bot.getX();
}

////////////////////////////////////////////////////////////////////
// get bottom point's y value
inline int 
ImageArea::getBotY( void ) const
{
 	return bot.getY();
}

////////////////////////////////////////////////////////////////////
// get top point
inline const ImagePoint&
ImageArea::getTop( void ) const
{
 	return( top );
}

////////////////////////////////////////////////////////////////////
// get bottom point
inline const ImagePoint&
ImageArea::getBot( void ) const
{
 	return( bot );
}

////////////////////////////////////////////////////////////////////
//  get width of area bottom x - top x
inline int 
ImageArea::getWidth( void )  const
{
	return( bot.x - top.x  + 1);
}

////////////////////////////////////////////////////////////////////
// get height of area bottom y - top y 
inline int 
ImageArea::getHeight( void ) const
{
	return( bot.y - top.y + 1 );
}

#endif	// IMAGELIB_IMAGEAREA	
