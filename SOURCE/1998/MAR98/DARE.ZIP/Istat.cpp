//	File: istat.cpp
//	Description: image histogram statistics base class 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards  1997 
//

#include "stdafx.h"

#include "isystem.hpp"
#include "istat.hpp"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// double getSum( void )
// add all the values  
double 
ImageHistStat::getSum( void ) const
{
	double sum =0;
    int i = getRange();

    while( i-- )
    {
    	sum = sum + (double)(getFrequency(i)* i);	 
    }
	
	return( sum );
}

// double getNumber( void )
// add the frequencies of all the histogram points

double 
ImageHistStat::getNumber( void ) const
{
	double number = 0.0;
    int i = getRange();
    
    while( i-- )
    {
        number += (double)getFrequency(i);	 
    }
	
	if( number == 0.0 ) number = 1.0;	// stop divide by 0 errors
	return( number );
}
