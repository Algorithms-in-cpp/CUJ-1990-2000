//	File: ilut.cpp
//	Description: base lookup table code
//
//	Author: C Dare-Edwards
//	
//	
//  Copyright Conrad Dare-Edwards 1997  
//

#include "stdafx.h"

#include "isystem.hpp"
#include "ilut.hpp"

#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//  defualt constructor - set up a defualt 0 255 scale
ImageLut::ImageLut( void )
{
 	ScaleTo( ImagePoint(0,0) , ImagePoint(255, 255) ); 	// defualt scaleing	
}	 

// copy constructor
ImageLut::ImageLut( const ImageLut& lut )
{
	// assert the ovious  
	IASSERT( lut.getRange() == getRange() );
	int x = getRange();
 	
	// and copy across
	while( x-- )  m_luttable[x] = lut[x];
}	

// copy operator
ImageLut& ImageLut::operator=( const ImageLut& copy )
{
	// assert the ovious  
	IASSERT( copy.getRange() == getRange() );
	int x = getRange();
 	
	// and copy across
	while( x-- )  m_luttable[x] = copy[x];
	
	return( *this );
}


// linear scale between two points
BOOL
ImageLut::ScaleTo(const ImagePoint& from, const ImagePoint& to)
{
 	int width  = to.x - from.x;
 	int height = to.y - from.y;
    
	// catch errors
 	if( from.y+ height >= getRange() || from.x+width >= getRange() || width <= 0 )
 	{
 	    	IASSERT( FALSE ); // alert we got problems	
		return ( FALSE );      // exit stage left
 	}
 	
	float addy = ((float)height / (float)width); 
 	
	// slope across to to.x to.y
	for( int i = 0; i <= abs(width);  i++ )
	{
	 	m_luttable [  i+from.x]  =  from.y + (int)(addy*i);
	}

	return TRUE;
}

