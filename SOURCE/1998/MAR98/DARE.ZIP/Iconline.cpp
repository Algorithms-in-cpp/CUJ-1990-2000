//      File: iconline.cpp
//      Description: control line class for user defined lookuptable editor 
//      Author: C Dare-Edwards
//      
//	
//      Copyright Conrad Dare-Edwards 1997 


#include "stdafx.h"
#include "iplut.hpp"

#include "idragpnt.hpp"
#include "itlist.hpp"
#include "iconline.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

///////////////////////////////////////////////////////////////////////
//	constructor
ImageControlLine::ImageControlLine( const CRect& area ): FullArea(area)
{
	IASSERT( area.Width() > 0 && area.Height() > 0 );
	selected_pos = NULL;	

	m_xscaletocp = (double) ((double)FullArea.Width() -1) / (double)255;
	m_yscaletocp = (double) ((double)FullArea.Height()-1) / (double)255;

	m_xscaletoip = (double) ((double)255 / ((double)FullArea.Width()-1)) ;
	m_yscaletoip = (double) ((double)255 / ((double)FullArea.Height()-1));
}

/////////////////////////////////////////////////////////
//	delete 
ImageControlLine::~ImageControlLine( void )
{
	// do nothing  
}

/////////////////////////////////////////////////////////
//	 mouse button down find and select point or create a new one
ImageDragPoint*
ImageControlLine::MouseClick( const CPoint& point )
{
  ILISTPOS pos = HitTest( point );
	  
   if( pos ) // hit a current point
   {
      if(	getData(pos).IsSelected() == FALSE )
  		SetSelected( pos );
      
	  getData(pos).MoveTo( point );   // move the point
      Sort();  // resort the list 
   }
   else  // create and add point to the list
   {
     ImageDragPoint apoint(point, FALSE, FALSE); 
     pos = AddPoint( apoint );
	 if(pos) SetSelected( pos );
   }

   if( (pos = FindSelected())!=NULL ) return( &getData(pos) );
   else  return( NULL );	 // error
	
}

/////////////////////////////////////////////////////////
//	 mouse move 
ImageDragPoint*
ImageControlLine::MouseMove( const CPoint& point )
{
   ILISTPOS pos = NULL;
   
   if( FullArea.PtInRect( point ) )
   {
		pos = FindSelected();
		if( pos != NULL )
		{
			getData(pos).MoveTo( point );
			Sort();      
		}
   }

   if( (pos = FindSelected())!=NULL ) return( &getData(pos) );
   else  return( NULL );	 // error

}

/////////////////////////////////////////////////////////
//	shift selected point by so many screen units
ImageDragPoint*
ImageControlLine::Shift( int x, int y )
{
   ILISTPOS pos = FindSelected();
   if( pos != NULL )
   {
		getData(pos).MoveBy(FullArea, x, y );
		Sort();      
   }

   if( (pos = FindSelected())!=NULL ) return( &getData(pos) );
   else  return( NULL );	 // error
}


/////////////////////////////////////////////////////////
//   Delete selected point
ImageDragPoint*
ImageControlLine::Delete( void )
{
   ILISTPOS pos = FindSelected();
   if( pos != NULL )
   {
		if( getData(pos).CanDelete() )
		{
			SelectNextPoint();
			Remove( pos );
   		}
   }
   if( (pos = FindSelected())!=NULL ) return( &getData(pos) );
   else  return( NULL );	 // error
}



/////////////////////////////////////////////////////////
//   selected next point
ImageDragPoint*
ImageControlLine::SelectNextPoint( void )
{
   ILISTPOS pos = FindSelected();
   if( pos != NULL )
   {
		if( pos == getTail() )
			pos = getHead();
		else
			pos = getNext(pos);
   
		SetSelected(pos);
   }

   if(pos) return( &getData(pos) );
   else return(NULL);
}
/////////////////////////////////////////////////////////
//   selected prev point
ImageDragPoint*
ImageControlLine::SelectPrevPoint( void )
{
   ILISTPOS pos = FindSelected();
   if( pos != NULL )
   {
		if( pos == getHead() )
			pos = getTail();
		else
			pos = getPrev(pos);
   
		SetSelected(pos);
   }
   
   if(pos) return( &getData(pos) );
   else return(NULL);
}

/////////////////////////////////////////////////////////
//	  draw the line on the screen
void
ImageControlLine::Draw( CDC* pDC )
{
    if(isEmpty()) return;
  
    ILISTPOS pos = getHead();
	pDC->MoveTo( getData(pos) );
	while((pos = getNext( pos )) != NULL )
	{
		pDC->LineTo( getData(pos) );
    }
    
	pos = NULL;
	while((pos = getNext( pos )) != NULL )
    {
		getData(pos).Draw(pDC );
    }
}

/////////////////////////////////////////////////////////
//	copy a lut table into a dragpoint list
void
ImageControlLine::UpdateLine( const ImagePointLut& lut )
{
  RemoveAll();						 // clear current list
  ImagePList plut = lut.getPointList();
  
  ILISTPOS pos = NULL;
  while( (pos = plut.getNext( pos )) != NULL )
  { 
     BOOL init_flag = FALSE;				// set default falgs

  	 if( pos == plut.getHead() || pos == plut.getTail())
  		 init_flag = TRUE; 	// change the flags if point is an end point
		
     ImageDragPoint dpoint( init_flag, init_flag); 	// create a new DragPoint

	 dpoint.getOriginalPnt() = plut.getData(pos);	// save the original position
 	 ConvIP( dpoint, plut.getData(pos));	 // convert an image point  to Cpoint
     
	 Append( dpoint );	   // append it to the list
 }
 
  SetSelected( getHead() );		   // select the first point in the list
}

/////////////////////////////////////////////////////////
//	convert current ppoint list into a lut table
void
ImageControlLine::UpdateLut( ImagePointLut& lut )
{
	ImagePList plut;
	ImagePoint ipoint;
	
	ILISTPOS pos = NULL;
	while( (pos = getNext(pos)) != NULL )
	{
		ImageDragPoint* dpoint = &(getData(pos));

		if( dpoint->HasMoved() )
				ConvCP( ipoint, getData(pos));	  // convert Cpoint to an image point
		else ipoint = dpoint->getOriginalPnt();   // else copy the original point and save the conversion
		
		plut.Append( ipoint );			  // add point to the lut
	}	 

	lut = ImagePointLut( plut );
}

////////////////////////////////////////////////////////////////////
// convert a ImagePoint ( 0,255 ) to a Cpoint window cords

void 
ImageControlLine::ConvIP( CPoint& to, const ImagePoint& from	)
{
	// invert the y scale
	int y_value	 = 255 - from.y;

	// compute the values
 	to.x = (long)((m_xscaletocp *(double)from.x)  + FullArea.left);
	to.y = (long)((m_yscaletocp *(double)y_value) + FullArea.top );

	// assert the truth
	IASSERT( to.x >= FullArea.left && to.y >= FullArea.top 
			&& to.x < FullArea.right && to.y < FullArea.bottom );

	// make sure
	if( to.x < FullArea.left ) to.x = FullArea.left;
	if( to.y < FullArea.top  ) to.y = FullArea.top;

	if( to.x >= FullArea.right )  to.x = FullArea.right-1;
	if( to.y >= FullArea.bottom ) to.y = FullArea.bottom-1;

}

////////////////////////////////////////////////////////////////////
// convert a Cppoint (window cords to an ImagePoint ( lut 0,255 )
void 
ImageControlLine::ConvCP( ImagePoint& to, const CPoint& from	)
{
 	to.x = (long)((double)(from.x - FullArea.left)/m_xscaletocp);
	to.y = (long)((double)(from.y - FullArea.top )/m_yscaletocp);

	// invert the y scale 
	to.y = 255 - to.y;

	// assert the truth
	IASSERT( to.x >= 0 && to.y >= 0 && to.x <= 255 && to.y <= 255 );

	// make sure
	if( to.x < 0 ) to.x = 0;
	if( to.y < 0 ) to.y = 0;

	if( to.x > 255 ) to.x = 255;
	if( to.y > 255 ) to.y = 255;

}

//////////////////////////////////////////////////////////////
ILISTPOS
ImageControlLine::HitTest( const CPoint& point )
{
	ILISTPOS pos = NULL;
	while( (pos = getNext(pos)) != NULL )
	{
		if( getData(pos).HitTest( point ) )
			return( pos );
	}
	return( NULL );  // not a hit 
}

//////////////////////////////////////////////////////////////
ILISTPOS
ImageControlLine::FindSelected( void )
{
	if( selected_pos != NULL )
		 return ( selected_pos );	 // quick find 

	ILISTPOS pos = NULL;
	while( (pos = getNext(pos)) != NULL )
	{
		if( getData(pos).IsSelected() )
		{
			selected_pos = pos;
			return( pos );
		}
	}
	return( NULL );  // not a hit 
}

//////////////////////////////////////////////////////////////
void
ImageControlLine::SetSelected( ILISTPOS pos )
{
	ClearSelected();        
	getData(pos).IsSelected( TRUE );
	selected_pos = pos;
}

///////////////////////////////////////////////////////////////
void
ImageControlLine::ClearSelected( void )
{
	ILISTPOS pos = NULL;
	while( (pos = getNext(pos)) != NULL )
	{
		getData(pos).IsSelected(FALSE);
	}
}

///////////////////////////////////////////////////////
ILISTPOS
ImageControlLine::AddPoint( const ImageDragPoint& point)
{
  ImageDragPoint dpoint( point );
	
  // convert position back to orginal postion and save
  ImagePoint ipoint;
  ConvCP( ipoint, dpoint);	  // convert Cpoint to an image point
  dpoint.getOriginalPnt() = ipoint; 	
 
  // scan list and see if there is a point further left that point
  ILISTPOS pos = NULL;
  while( (pos = getNext( pos )) != NULL)
  {
  	 	// if point is equal to the max and scrollable insert before
     	if(( getData(pos).x == 255 && !getData(pos).FullScroll()) || 
		   ( getData(pos).x > dpoint.x ) ) // find the point after x 
     	{	
			InsertBefore( dpoint, pos );  
			return( getPrev(pos) );  
		}
  }
  
  return( NULL );  // somthing strange invalid point ???
}
//////////////////////////////////////////////////////////
void
ImageControlLine::Sort( void )
{
	int changes;  // do untill list hasn't changed 
	do
	{
		changes = FALSE;
		
		// skip the first node
		ILISTPOS pos, last = getHead(); 
		while( (pos = getNext( last )) != NULL )
		{
			// if this is smaller swap them
			if(  getData(last).x  > getData(pos).x )
			{
				Swap(last, pos);
				changes = TRUE;
			}
			
			last = pos;
		} // end while in list
	
	}while( changes );
	
	// clear selection pointer may have changed position
	selected_pos = NULL;
}
