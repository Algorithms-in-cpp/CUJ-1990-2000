//	File: ilut.hpp
//	Description: base lookup table definition
//
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//


#ifndef	IMAGELIB_IMAGELUT
#define IMAGELIB_IMAGELUT

#include "isystem.hpp"
#include "ipoint.hpp"

typedef unsigned char BYTE;
#define BYTE_SIZE  256

class ImageLut
{
	public:
	ImageLut( void );        			// default constructor
	ImageLut( const ImageLut& lut );		// copy constructor
    
   	void Lookup( BYTE* buffer, int length ) const;     	// convert a buffer

	const BYTE& operator[] ( BYTE nIndex ) const; 
 	           BYTE& operator[] ( BYTE nIndex ); 
    
	int getRange( void ) const;	// return BYTE_SIZE
	ImageLut& operator=( const ImageLut& copy );
	
	BOOL  ScaleTo( const ImagePoint& from, const ImagePoint& to);
	void Clear( void );
		        
    	private:
    	BYTE m_luttable[BYTE_SIZE];
};

//////////////////////////////////////////////////////////////////////
// inline functions

// convert a byte stream through lookup table
inline void 
ImageLut::Lookup( BYTE* buffer, int length ) const
{
 	// pass buffer through lut 
 	while( length-- ) *buffer++ = m_luttable[ *buffer ];
}

//  convert a single byte through lookup table
inline BYTE&
ImageLut::operator[] ( BYTE nIndex )
{
	IASSERT( nIndex < BYTE_SIZE);
 	return( m_luttable[nIndex] );
}	

// constant version
inline const BYTE&
ImageLut::operator[] ( BYTE nIndex )  const
{
	IASSERT( nIndex < BYTE_SIZE);
 	return( m_luttable[nIndex] );
}	

// set luttable to 0
inline void
ImageLut::Clear( void )
{
	int x = BYTE_SIZE;
	while( x-- )  m_luttable[x] = 0;	
}

// return the maximum converted value it table on either axis
inline int 
ImageLut::getRange( void ) const
{
	return( BYTE_SIZE );
}

#endif // IMAGELIB_IMAGELUT
