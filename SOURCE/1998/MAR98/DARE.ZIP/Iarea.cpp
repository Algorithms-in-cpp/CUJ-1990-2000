//	File: iarea.cpp
//	Description: area points class 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997

#include "stdafx.h"


#include "isystem.hpp"
#include "ipoint.hpp"
#include "iarea.hpp"


////////////////////////////////////////////////////////////////////
//	default constructor - gives it a size of 1 by 1
ImageArea::ImageArea( void ) : top( 0,0 ), bot( 1,1 )
{
	// all done	
}

////////////////////////////////////////////////////////////////////
// standard constructor
ImageArea::ImageArea( int x, int y , int width, int height ) : top( x,y ) , bot( x+width-1, y+height-1 )
{
	// what about that simple
}

////////////////////////////////////////////////////////////////////
// copy constructor
ImageArea::ImageArea( const ImageArea& area ) : top( area.getTop() ) , bot( area.getBot() )
{
	// well trust that the area has its points around the right way
}


////////////////////////////////////////////////////////////////////
// point constructor
ImageArea::ImageArea( const ImagePoint& toppoint, const ImagePoint& botpoint ) 
	: top( toppoint ), bot( botpoint )
{
	// swap x values so that we have the logic around the right way later
	if( top.x > bot.x )   
	{
	 	int hold = bot.x;
	 	bot.x = top.x;
	 	top.x = hold;
	}
 	if( top.y > bot.y )
 	{
	 	int hold = bot.y;
	 	bot.y = top.y;
	 	top.y = hold;
 	}
}    

////////////////////////////////////////////////////////////////////
// copy area with out resorting to a constructor
void
ImageArea::Copy( const ImageArea& area )
{
 	top.Copy( area.getTop() );	
 	bot.Copy( area.getBot() );
}

////////////////////////////////////////////////////////////////////
// copy area with out resorting to a constructor
ImageArea&
ImageArea::operator=( const ImageArea& copy )
{
 	top =  copy.getTop();	
 	bot =  copy.getBot();
	return( *this );
}


////////////////////////////////////////////////////////////////////
// test if handed area is fully contained within this area
BOOL
ImageArea::isContained( const ImageArea& area ) const
{
	if( area.getTopX() >= top.x &&
		area.getTopY() >= top.y &&
		area.getBotX() <= bot.x &&
		area.getBotY() <= bot.y ) 	
    {
    	return( TRUE );
    }
    else 
    {
    return( FALSE );
    }
}

////////////////////////////////////////////////////////////////////
// does point lie within the box
BOOL
ImageArea::isContained( const ImagePoint& point ) const
{
	if( point.getX() >= top.x &&
		point.getY() >= top.y &&
		point.getX() <= bot.x &&
		point.getY() <= bot.y ) 	
    {
    	return( TRUE );
    }
    else 
    {
    return( FALSE );
    }
}
