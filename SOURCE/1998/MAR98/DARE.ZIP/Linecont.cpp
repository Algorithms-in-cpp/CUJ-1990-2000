// linecont.cpp : implementation file
//

#include "stdafx.h"
#include "Display.h"

#include "iconline.hpp"
#include "linecont.h"
#include "ihistplt.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// LineControl

LineControl::LineControl(UINT id, CWnd* Parent)
{
	// clear
	m_lineupdate      = FALSE;
	m_mousebuttondown = FALSE;
	m_isopen = FALSE;	// defualt
	m_line = NULL;

	// tell windows we are in charge of messages for this window
	if( !SubclassDlgItem( id, Parent) ) return;	
	
	// get areas
	GetClientRect( m_clientarea );	
	GetClientRect( m_fullclientarea );

	// give us a border 
	m_clientarea.InflateRect( -10, -10 );
	
	// create line control
	if( (m_line = new ImageControlLine( m_clientarea )) == NULL ) 
		return; // memory allocation error

	m_plothist = FALSE;	// intialy don't plot histogram	
	m_linecolour = (COLORREF) RGB( 0,0,0 );	// black

	// create back drop bitmap
	if(!CreateBackDrop() ) return;

	m_isopen = TRUE;	   // validate object
}

LineControl::~LineControl()
{
	// clean up
	if( m_line ) delete m_line;
}


BEGIN_MESSAGE_MAP(LineControl, CWnd)
	//{{AFX_MSG_MAP(LineControl)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// LineControl message handlers

// mouse button down
void LineControl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	// if that is within our air space
	if(PtOnClient( point ))
	{
		// adjust position for  our origin
	 	if( !m_clientarea.PtInRect( point ) )
	 	{	 
			//////////////// ajust point to nearest spot
			if( point.x < m_clientarea.left ) point.x = m_clientarea.left; 	
			else if( point.x > m_clientarea.right ) point.x = m_clientarea.right-1; 	

			if( point.y < m_clientarea.top ) point.y = m_clientarea.top; 	
			else if( point.y >= m_clientarea.bottom ) point.y = m_clientarea.bottom-1; 	
		}
	 	
		// create a new point or find a current one 
	 	ImageDragPoint* dpoint = m_line->MouseClick( point );	
		
		// if we have a selected point
		if( dpoint )
		{
			OnImediatePaint();	// repaint	

			m_mousebuttondown = TRUE;
			m_lineupdate  = TRUE;
			UpdateControls( dpoint );	// update x, y and delete

		    SetCapture();	 // get all mouse messages
		}
	}

}

// mouse buttom up
void LineControl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_mousebuttondown)
	{
 		ReleaseCapture();    // stop getting messages

		// adjust the point for our origin
	 	if( !m_clientarea.PtInRect( point ) )
	 	{	 
			//////////////// ajust point to nearest spot
			if( point.x < m_clientarea.left ) point.x = m_clientarea.left; 	
			else if( point.x > m_clientarea.right ) point.x = m_clientarea.right; 	

			if( point.y < m_clientarea.top ) point.y = m_clientarea.top; 	
			else if( point.y > m_clientarea.bottom ) point.y = m_clientarea.bottom; 	
		}

		// shift line postion
	 	ImageDragPoint* dpoint = m_line->MouseMove( point );	
		OnImediatePaint();	// paint it	
		UpdateControls( dpoint ); // update position x and y

	}
	
	m_mousebuttondown = FALSE;
}

// mouse has moved
void LineControl::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_mousebuttondown && PtOnClient( point ))
	{
	 	if( !m_clientarea.PtInRect( point ) )
	 	{	 
			//////////////// ajust point to nearest spot
			if( point.x < m_clientarea.left ) point.x = m_clientarea.left; 	
			else if( point.x > m_clientarea.right ) point.x = m_clientarea.right-1; 	

			if( point.y < m_clientarea.top ) point.y = m_clientarea.top; 	
			else if( point.y > m_clientarea.bottom ) point.y = m_clientarea.bottom; 	
		}

	 	ImageDragPoint* dpoint = m_line->MouseMove( point );	
		OnImediatePaint();		
		PointMove( dpoint );
	}
	
}

// is that with our boundries
BOOL LineControl::PtOnClient( CPoint& point )
{
	return( m_fullclientarea.PtInRect( point ) );
}

// update controls backdrop histogram
void LineControl::OnUpdate( const ImageHist& hist, BOOL plothist )
{
	if( !isOpen() ){  IASSERT(FALSE);   return; }

	m_hist = hist;
	m_plothist = plothist;
	
	PaintBackDrop();
	Invalidate();
} 

// update controls lookup table with a new one
void LineControl::OnUpdate( const ImagePointLut& lut )
{
	if( !isOpen() ){  IASSERT(FALSE);   return; }

	m_lut = lut;
	m_line->UpdateLine( m_lut );

	m_lineupdate  = FALSE;
	Invalidate();
} 

// get updated lookup table from control
const ImagePointLut& 
LineControl::GetUpdate( void )
{
	m_line->UpdateLut(m_lut); 

	m_lineupdate = FALSE;
	return m_lut;
} 

// create a backdrop bitmap to control
BOOL 
LineControl::CreateBackDrop( void )
{
   CRect rect(0,0,0,0);
   this->GetClientRect( rect );

   // create our background dc
   CDC pDC; // device context for painting
   if( pDC.CreateCompatibleDC(NULL) == 0 ) return FALSE; 
 
   // create a compatible dc for this screen
   CClientDC* dc = new CClientDC(this);	// create a dc for this view

   //CDC* dc = GetDC( );	// create a dc for this view
   if( dc == NULL ) return FALSE;	
   
   // create our bitmap
   if(m_bitmap.CreateCompatibleBitmap( dc, rect.Width(), rect.Height() ) == 0 ) return FALSE;	
   
   delete dc;

   pDC.DeleteTempMap();
   pDC.DeleteDC();
   return TRUE;
}


// paint histogram backdrop 
void LineControl::PaintBackDrop( void )
{
	if( !isOpen() ){  IASSERT(FALSE);   return; }

	// create our background dc
   CDC pDC; // device context for painting
   
   if( pDC.CreateCompatibleDC(NULL) == 0 ) 
		return; 
   
   // select our bitmap into the dc
    CBitmap* old_bitmap = (CBitmap*)pDC.SelectObject( &m_bitmap );

	// get background colour form our parent
   CBrush* back_brush;
   CWnd* parent = GetParent();
   HBRUSH brush = (HBRUSH)parent->SendMessage( WM_CTLCOLORSTATIC,(WPARAM)pDC.GetSafeHdc(), (LPARAM)this->GetSafeHwnd());

   IASSERT( brush != NULL );
   if( brush != 0 )
   {
	   back_brush = CBrush::FromHandle( brush );
	   pDC.FillRect( m_fullclientarea , back_brush ); 
   }

	// create a lookup table plot object
	ImageLutPlot lplot( m_clientarea );
	
	// plot out histogram
	if( m_plothist )
	{
		lplot.SetScaleing( m_hist );
	 	lplot.ClearPlot( &pDC );
	 	lplot.PlotBarGraph( &pDC, m_hist );
	}
	lplot.DrawScale( &pDC );

	// reselect old bitmap
   if(old_bitmap) pDC.SelectObject( old_bitmap );

   // clean up 
   pDC.DeleteTempMap();	
   pDC.DeleteDC();
 	
}

// paint control onto handed dc
void LineControl::PaintControl( CDC* dc ) 
{
	if( !isOpen() ){  IASSERT(FALSE);   return; }

	// create a background dc
   CDC pDC; 
   
   if( pDC.CreateCompatibleDC( dc ) == 0 ) return; 
   CBitmap* old_bitmap = (CBitmap*)pDC.SelectObject( &m_bitmap );

   // paste backdrop bitmap onto screen
	dc->BitBlt( 0,0, m_fullclientarea.Width(), m_fullclientarea.Height(), &pDC, 0,0,	SRCCOPY);
	
	// draw our control line
	m_line->Draw( dc );					   // draw line

	// reselect old bitmap
   if(old_bitmap) pDC.SelectObject( old_bitmap );
   
   // clean up
   pDC.DeleteTempMap();	
   pDC.DeleteDC();
}

// on message paint window
void LineControl::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	PaintControl( &dc);
}

// imediate repaint as control line shifts position
void LineControl::OnImediatePaint() 
{
	CClientDC* dc = new CClientDC(this);	// create a dc for this view
	
	// paint it
	if( dc != NULL )
	{
		PaintControl( dc);
		delete dc;
	}

	// tell windows that everything is ok
	ValidateRect( m_fullclientarea );	 // now valid
}

// next point
void LineControl::GetNextItem( void )
{
	UpdateControls( m_line->SelectNextPoint() );
	Invalidate();
}

// previous point
void LineControl::GetPrevItem( void )
{
	if( !isOpen() ){  IASSERT(FALSE);   return; }

	UpdateControls( m_line->SelectPrevPoint() );
	Invalidate();
}

// delete selected point
void LineControl::DeleteItem( void )
{
	if( !isOpen() ){  IASSERT(FALSE);   return; }

	UpdateControls( m_line->Delete() );
	Invalidate();
}

// our parent wants to shift current point
void LineControl::MoveItem( const ImagePoint& point )
{
	if( !isOpen() ){  IASSERT(FALSE);   return; }

	CPoint cpoint;
	m_line->ConvIP( cpoint, point );
	ImageDragPoint* dp = m_line->MouseMove( cpoint );
	if( dp != NULL )
	{
		dp->ClearMoved();
		dp->getOriginalPnt() = point;
	}
	

	UpdateControls( m_line->MouseMove( cpoint ) );
	Invalidate();
}

// point selection changes update the x and y edit controls of
// our parent
void LineControl::PointMove( ImageDragPoint* dpoint)
{
	if( !isOpen() ){  IASSERT(FALSE);   return; }

 	// get parent diaglog
	CWnd* parent = GetParent();

	// convert cpoint to a dragpoint
	ImagePoint point;
	if( dpoint->HasMoved() )
		m_line->ConvCP(	point, *dpoint );
	else point = dpoint->getOriginalPnt();

	// update control values
	// update x edit box 
	CEdit* xedit;
	if((xedit= (CEdit*)parent->GetDlgItem(IDC_EDLUT_XVAL )) != NULL)
	{
	 	CString string;
		string.Format("%d", point.x );
	 	xedit->SetWindowText( string);
	 	xedit->SetModify( FALSE );
	}
	
	// update y edit box
	CEdit* yedit;
	if((yedit= (CEdit*)parent->GetDlgItem(IDC_EDLUT_YVAL )) != NULL ) 
	{
	 	CString string;
		string.Format("%d", point.y );
	 	yedit->SetWindowText( string);
	 	yedit->SetModify( FALSE );
	}

}

// point selection changes update the x and y edit controls of
// our parent - should realy send a message to parent
void LineControl::UpdateControls( ImageDragPoint* dpoint)
{
	if( !isOpen() ){  IASSERT(FALSE);   return; }
	if( dpoint == NULL ){ IASSERT(FALSE); return;}	// bomb out errot
	
	// get parent diaglog
	CWnd* parent = GetParent();

	// convert cpoint to a dragpoint
	ImagePoint point;
	if( dpoint->HasMoved() )
		m_line->ConvCP(	point, *dpoint );
	else point = dpoint->getOriginalPnt();
	
	// update control values
	// update x edit box 
	CEdit* xedit;
	if((xedit= (CEdit*)parent->GetDlgItem(IDC_EDLUT_XVAL )) != NULL)
	{
	 	CString string;
		string.Format("%d", point.x );
	 	xedit->SetWindowText( string);
	 	xedit->SetModify( FALSE );
	    xedit->SetReadOnly(!dpoint->FullScroll()); // enable or diable 
		xedit->EnableWindow(dpoint->CanDelete());
	}
	
	// update y edit box
	CEdit* yedit;
	if((yedit= (CEdit*)parent->GetDlgItem(IDC_EDLUT_YVAL )) != NULL ) 
	{
	 	CString string;
		string.Format("%d", point.y );
	 	yedit->SetWindowText( string);
	 	yedit->SetModify( FALSE );
	}
	
	// enable or disable delete button
	CButton* button;
	if((button = (CButton *)parent->GetDlgItem(IDC_EDLUT_DELETE)) != NULL)
	{
		button->EnableWindow(dpoint->CanDelete()); 	 // enable or diable
  	}
}






