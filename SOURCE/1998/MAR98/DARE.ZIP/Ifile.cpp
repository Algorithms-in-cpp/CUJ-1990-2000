//	File: ifile.cpp  
//	Description: ImageFile class source 
//
//	Author: C Dare-Edwards
//	
//	
//  Copyright Conrad Dare-Edwards   1997
//

#include "stdafx.h"

#include "isystem.hpp" // system wide definitions
#include <io.h>
#include <fcntl.h>
#include <share.h>
#include <string.h>

#include "ifile.hpp" 

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif



//////////////////////////////////////////////////////////////////////
// ImageFile::ImageFile()
// defualt constructor
// a do nothing constructor that for ImageFile

ImageFile::ImageFile() : m_pathname( new CString )   
{
	m_openflag = FALSE;
	m_readonly = FALSE;
	m_tempory  = FALSE; 

	m_filehandle = -1;

}

//////////////////////////////////////////////////////////////////////
ImageFile::ImageFile( const ImageFile& filecopy )
{
	/* not implemented */
}


///////////////////////////////////////////////////////////////////////
// ImageFile::~ImageFile()
// destructor for ImageFile
// close up file (if open)

ImageFile::~ImageFile()
{
	if( isOpen() ) 
	{
	 	_close( m_filehandle );
	 	if( m_tempory ) remove( *m_pathname );	 // just incase
	}

	delete m_pathname;
}

///////////////////////////////////////////////////////////////////////
// int ImageFile::open( char* filename, openflags flags)
// open file with name filename and the flags  
//
// char* filename -	NULL terminated string with filename and path we will take a copy
// enum openflags - flags for opening
// returns int 1 if success else 0 on failure
int 
ImageFile::open(const char* filename, openflags flags)
{
    
    if( isOpen() )
    {
    	 // error we are already open
    	 IPOSTERROR( ERR_OBJ_ALREADYOPEN );
    	 return( FALSE );	
    }
    
	m_tempory = FALSE;  

	UINT opentype = 0;
	UINT pmode = _S_IWRITE | _S_IREAD;
  
	// setup flags
    switch( flags ){ 			// open file with apropiate flags
    	case READONLY:  
    		opentype = _O_BINARY | _O_RDONLY | _O_SEQUENTIAL;
    		m_readonly = TRUE;
    		break;
    	case WRITEONLY: 
    		opentype = _O_BINARY | _O_WRONLY | _O_SEQUENTIAL;
    		break;
    	case READWRITE: 
    		opentype = _O_BINARY | _O_RDWR | _O_SEQUENTIAL;
    		break;
		case NEWREADWRITE: 
			opentype = _O_CREAT | _O_BINARY | _O_RDWR | _O_SEQUENTIAL;
    		break;
    	case TEMPREADWRITE: 
    		opentype = _O_CREAT| _O_TEMPORARY | _O_BINARY | _O_RDWR | _O_SEQUENTIAL;
    		m_tempory = TRUE;  
    		break;
    	default: 
			IASSERT( FALSE );
    		return( 0 ); 
       	}
	
	// set up a tempory fielname 
    if( flags == TEMPREADWRITE )
    {
       	char temppathname[255];
	 	char tempfilename[500];

		if( GetTempPath( 255, temppathname ) == 0 )
		{ 
			IASSERT(FALSE); 
			strcpy( temppathname, "."); // defualt directory		
		}
		
		if( GetTempFileName( temppathname, "~Un", 0 , tempfilename) == 0 )
			  { IASSERT(FALSE); return(FALSE);	}

    	(*m_pathname) = tempfilename;	// insert it in buffer
    }
	else // setup default filename
	{
		// copy filename across to buffer
		(*m_pathname) = filename;			
	}


	// and open it
	if((m_filehandle = _sopen( (*m_pathname), opentype,_SH_DENYNO, pmode )) == -1)       // check if we are open or not
	{ 		 
			IPOSTERROR( ERR_FILE_OPEN );
			return( FALSE ); 	// error file not open
	}

	// copy filename across to buffer
	m_openflag = TRUE;
	return(TRUE);   		// return TRUE file open
} 

///////////////////////////////////////////////////////////////////////
// 	int ImageFile::read(void* buffer, unsigned int nobytes)
// 	read x number of bytes from a file
// 
//	void* buffer -	where to put the data (must be bif enoght
//	unsigned int nobytes -	number of bytes to read 
//	returns -	number of bytes read into buffer 0 on error
int
ImageFile::read(void* buffer,  int nobytes)
{
	IASSERT( isOpen() );

	 if( _read(m_filehandle, buffer, nobytes ) != nobytes)
	 {
	 	IPOSTERROR( ERR_FILE_READ);
	 	return(FALSE);
	 }   
     return( TRUE );
} 
///////////////////////////////////////////////////////////////////////
// int ImageFile::write(void* buffer, unsigned int nobytes)
// write data to disk file
//
// void* buffer -	where to write it from
// unsigned int -	number of bytes to write
// returns int -	number of bytes written or 0 on error
int
ImageFile::write(void* buffer, int nobytes)
{
	IASSERT( !isReadOnly() );
	IASSERT( isOpen() );
	
	if( _write(m_filehandle, buffer, nobytes ) != nobytes )
	{
		IPOSTERROR( ERR_FILE_WRITE );
		return FALSE ;
	}
	return TRUE;
} 

///////////////////////////////////////////////////////////////////////
//	int ImageFile::seek( unsigned long moveBytes, seekflags flags)
// 	change file position
//
// 	int moveBytes -	bytes to move
// 	enum seekflags flags -	flags to tell whence from defualt current position
// 	returns int -	1 if ok else 0 if problem occoured
int
ImageFile::seek( long moveBytes, seekflags flags)
{
	IASSERT( isOpen() );

	if( lseek(m_filehandle, moveBytes, flags) == -1L )
	{
		IPOSTERROR( ERR_FILE_SEEK );
		return FALSE ;
	}
    return( TRUE ); 	
}
///////////////////////////////////////////////////////////////////////
// long ImageFile::getFilePos( void )
// return current position in the file
long
ImageFile::getFilePos( void )
{
    IASSERT( isOpen() );
    return( _tell( m_filehandle ) );
}

///////////////////////////////////////////////////////////////////////
//	char* ImageFile::getFileName( void)
//	getfilename of open file
//
// 	returns char*	- copy of filename else  NULL

const char*
ImageFile::getFileName( void) const
{
 	IASSERT( isOpen() );
    return(*m_pathname);   
}	


