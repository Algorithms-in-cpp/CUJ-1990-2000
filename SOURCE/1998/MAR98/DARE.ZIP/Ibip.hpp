//	File: ibip.hpp
//	Description: band interleave by pixel handleing routines
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards   1997
//


#ifndef IMAGELIB_IMAGEBIP
#define IMAGELIB_IMAGEBIP


#include "iinfo.hpp"
#include "ifile.hpp"

class ImageBIP: public ImageInfo, protected ImageFile
{
    public:
  
    ImageBIP( void );
    ~ImageBIP( void );
     
	int read(  void* bufffer, int startline, int numberoflines );
	int read( void* buffer, int startline, int numberoflines, int band);
    
	BOOL isOpen( void ) const;

	protected:

	int moveToLine( int lineNumber );	
	void Setup( void );
	
	private:
    
    int ConBIPtoBIL( char* buffer, int numberoflines );
    int ConBIPtoBIL( char* rbuffer, char* wbuffer, int numberoflines, int band );
 
	int isopen;   				// flag set to 1 when weave been set up
	
	int lineposition;			// current line position
    char* linebuffer; 			// this may have a buffer allocated 
    char* cbuffer;				// conversion buffer
};  

///////////////////////////////////////////////////////
inline BOOL 
ImageBIP::isOpen( void ) const 
{ 
	return isopen; 
}

#endif 
