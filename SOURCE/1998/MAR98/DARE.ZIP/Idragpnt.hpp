//      File: idragpnt.hpp
//      Description: drag able point for control class 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//


#ifndef IMAGELIB_IMAGEDRAGPOINT
#define IMAGELIB_IMAGEDRAGPOINT

#include "ipoint.hpp"

class ImageDragPoint : public CPoint
{

public:
ImageDragPoint( const CPoint& point, BOOL no_scroll, BOOL no_delete);  // TRUE if ONLY MOVE UP ANd down
ImageDragPoint( BOOL no_scroll, BOOL no_delete);  
ImageDragPoint( const ImageDragPoint& point );
ImageDragPoint( void );
~ImageDragPoint( void );

ImageDragPoint& operator=( const ImageDragPoint& point);

BOOL HitTest( const CPoint& point ); 

void IsSelected( BOOL flag ) { selected = flag; };
BOOL IsSelected( void  ) const {  return(  selected  ); }; 
BOOL CanDelete( void )   const { return( !disabled_delete ); };
BOOL FullScroll( void )  const { return( !disabled_scroll ); };
BOOL HasMoved( void ) const { return( has_moved ); };
void ClearMoved( void ) { has_moved = FALSE; }

void MoveBy( const CRect& area, int x, int y );
void MoveTo( const CPoint& point );
void Draw( CDC* pDC );

ImagePoint& getOriginalPnt( void ){ return m_original; };
const ImagePoint& getOriginalPnt( void ) const { return m_original; };

private:
BOOL selected;
BOOL disabled_scroll;
BOOL disabled_delete;
BOOL has_moved;

ImagePoint m_original;
};

#endif   // IMAGELIB_IMAGEPOINT 
