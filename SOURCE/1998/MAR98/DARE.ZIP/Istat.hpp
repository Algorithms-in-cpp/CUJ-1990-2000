//	File: istat.hpp
//	Description: image histogram statistic base class 
//
//	Author: C Dare-Edwards
//	
//	
//  Copyright Conrad Dare-Edwards 1997  
//


#ifndef	IMAGELIB_IMAGEHISTSTAT
#define IMAGELIB_IMAGEHISTSTAT

#include "isystem.hpp"
#include <math.h>

/////////////////////////////////////////////////////////////
// ImageHistStat
// Image histogram based statistics routines

class ImageHistStat
{
	public:
	double getMean( void ) const;
  
 	double getSum( void ) const;
    double getNumber( void ) const;

	int getMinimum( void ) const;
	int getMaximum( void ) const;
    
	double getLargest( void ) const;

    virtual unsigned int getRange( void )const =0 ;
	virtual unsigned long getFrequency( unsigned int value )const =0 ;
};


inline double 
ImageHistStat:: getLargest( void ) const
{
	unsigned long large = 0;
	int i = getRange();
	
	while( i-- )
	{
		if( large < getFrequency(i) ) large = getFrequency(i);
	}

	return( (double) large);
}



// double getMean( void )	
// sum all points on the histogram and divide by the number
inline double 
ImageHistStat::getMean( void ) const
{
	return( getSum() / getNumber() );
}

// int getMinimum( void )
// find the minimum by scanning across from 0 untill we find a value
inline int 
ImageHistStat::getMinimum( void ) const
{
	unsigned int i = 0;
	
	while( getFrequency( i ) == 0 && i < getRange() )
	{
	 	i++;
	}
    
    return( i );
}

// int getMaximum( void )
// scan down from range untill we find a value

inline int 
ImageHistStat::getMaximum( void ) const
{
	int i = getRange();
	
	while( i-- )
	{
		if( getFrequency(i) ) break;
	}
	
	return( i );  
}


#endif  // IMAGELIB_IMAGEHISTSTAT
