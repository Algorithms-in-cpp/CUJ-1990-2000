//	File: ipColdib.hpp
//	Description: Pseudo colour dib handleing routines 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//

#ifndef IMAGELIB_IMAGEPSCOLOURDIB
#define IMAGELIB_IMAGEPSCOlOURDIB

#include "idib.hpp"

#include "image.hpp"
#include "iplut.hpp"

class ImagePsColourDib : public ImageDib
{
	public:
	enum LutMode    { PSEUDO_SCALE=3 , GREY_SCALE = 1 };
	enum UpdateBand { RED, GREEN, BLUE, GREY };
		
	ImagePsColourDib( int newband =0 );
	~ImagePsColourDib( void );
		 
    int CreateDib( Image* rimage );
    int UpdateDib( void );
    
    int GetNumBand( void ) const { return( 1 ); }
	int GetNumLut ( void ) const { return( lut_Mode ); };

    int GetBandNumber( int band ) const { return( band ); }
    const ImagePointLut& GetBandLut( int band ) const;
	
    int UpdateLut( const ImagePointLut& lut, int band );
    
    void Optomise( const ImageHist& hist );
    
	void SetGrey( void );
	void SetColour( void );

	private:
    LutMode lut_Mode;
    ImagePointLut rlut, glut, blut;
	int band;
    
	unsigned char m_opthist[256];
	ImageLut m_optlut;
};

#endif	// IMAGELIB_IMAGEPSCOLOURDIB
