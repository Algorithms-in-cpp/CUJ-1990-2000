 //	File: ierror.cpp
//	Description: error handleing function code windows version
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997
//

//////////////////////////////////////////////////////////////
// windows error.cpp code
#include "stdafx.h"
#include "display.h"

#include "isystem.hpp"
#include "ierror.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// Global error handleing defined
ImageError IErrorHandle;

ImageError::ImageError( void )
{
 	lasterror = ERR_NULL;   // clear varibles
}

ImageError::~ImageError( void )
{
 	return;	// ok nothing much
}

void 
ImageError::PostTrace( const char* message, const char* filename, int line )
{
 	TRACE( "ImageLib Posted Trace: Filename: %s Line: %d :: %s\n", filename, line, message);
}

void 
ImageError::PostError( const ImageErrorType error, const char* filename, int line )	
{

	UINT error_ids;
	if( error == lasterror ) return; 
	else lasterror = error;	// copy error
	
	switch( error )
	{
		case ERR_BREAK:              // user break dectected 
		    error_ids = IDS_ERROR_USERBREAK;
		    break;
		case ERR_MEM_ALLOC:			// failed to allocate memory
	    	error_ids = IDS_ERROR_MEMALLOC;
	    	break;
		case ERR_FILE_OPEN:			// can't open file 
	    	error_ids = IDS_ERROR_FILEOPEN;
	    	break;
		case ERR_FILE_READ:          // read failed
	    	error_ids = IDS_ERROR_FILEREAD;
	    	break;				  
	    case ERR_FILE_WRITE:         // write failed
	    	error_ids = IDS_ERROR_FILEWRITE;
	    	break;
		case ERR_FILE_SEEK:			// seek failed
	    	error_ids = IDS_ERROR_FILESEEK;
			break;
		case ERR_OBJ_ALREADYOPEN:  	// already open
		   error_ids = IDS_ERROR_OBJOPEN;
	       break;
		case ERR_OBJ_INVALIDARGS:    // invalid arguments
	    	error_ids = IDS_ERROR_OBJARGS;
	    	break;
		case ERR_OBJ_INVALID:		// object not intialised or not open
	    	error_ids = IDS_ERROR_OBJINVALID;
	    	break;
		case ERR_UNHANDLED_TARGA: 	// unhandled version of targa
	    	error_ids = IDS_ERROR_UNHANDLEDTARGA;
	    	break;
		case ERR_UNKNOWNFORMAT:  	// create image failed
	    	error_ids = IDS_ERROR_UNKNOWNFORMAT;
	    	break;
		case ERR_FAILED_ASSERT:
	    	error_ids = IDS_ERROR_FAILEDASSERTION;
	    	break;
	    default:  
	    	error_ids = IDS_ERROR_UNKNOWN;
	    	break;
	} 	

	// load error string
	CString error_string;
	if( error_string.LoadString( error_ids ) == 0  )
	{
		error_string = "Post error:";
	}

 	// setup debugging string
 	CString file;
 	file.Format("(%s:%d)", filename, line);
	
	error_string += file;

	// inform user..
	if( AfxMessageBox( error_string, MB_ABORTRETRYIGNORE, error_ids ) == IDABORT )
	{
	 	// abort program 
		AfxAbort();	// death 
	}	

}        

void
ImageError::PostError(  const ImageErrorType error  ) 
{
 	
 	UINT error_ids;
 	lasterror = error;	// copy error

	switch( error )
	{
		case ERR_BREAK:              // user break dectected 
		    error_ids = IDS_ERROR_USERBREAK;
		    break;
		case ERR_MEM_ALLOC:			// failed to allocate memory
	    	error_ids = IDS_ERROR_MEMALLOC;
	    	break;
		case ERR_FILE_OPEN:			// can't open file 
	    	error_ids = IDS_ERROR_FILEOPEN;
	    	break;
		case ERR_FILE_READ:          // read failed
	    	error_ids = IDS_ERROR_FILEREAD;
	    	break;				  
	    case ERR_FILE_WRITE:         // write failed
	    	error_ids = IDS_ERROR_FILEWRITE;
	    	break;
		case ERR_FILE_SEEK:			// seek failed
	    	error_ids = IDS_ERROR_FILESEEK;
			break;
		case ERR_OBJ_ALREADYOPEN:  	// already open
		   error_ids = IDS_ERROR_OBJOPEN;
	       break;
		case ERR_OBJ_INVALIDARGS:    // invalid arguments
	    	error_ids = IDS_ERROR_OBJARGS;
	    	break;
		case ERR_OBJ_INVALID:		// object not intialised or not open
	    	error_ids = IDS_ERROR_OBJINVALID;
	    	break;
		case ERR_UNHANDLED_TARGA: 	// unhandled version of targa
	    	error_ids = IDS_ERROR_UNHANDLEDTARGA;
	    	break;
		case ERR_UNKNOWNFORMAT:  	// create image failed
	    	error_ids = IDS_ERROR_UNKNOWNFORMAT;
	    	break;
		case ERR_FAILED_ASSERT:
	    	error_ids = IDS_ERROR_FAILEDASSERTION;
	    	break;
	    default:  
	    	error_ids = IDS_ERROR_UNKNOWN;
	    	break;
	} 	

	AfxMessageBox( error_ids, IDOK, error_ids );	
}

void 
ImageError::PostBreak( void )
{ 
	TRACE(" User Break detected");
	lasterror = ERR_BREAK;
}    

void 
ImageError::ClearErrors( void )
{
	lasterror = ERR_NULL;
}

