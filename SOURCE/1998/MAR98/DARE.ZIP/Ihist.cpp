//	File: ihist.cpp
//	Description: histogram class code 
//
//	Author: C Dare-Edwards
//	
//	
//  Copyright Conrad Dare-Edwards 1997  
//

#include "stdafx.h"

#include "isystem.hpp"
#include "ihist.hpp"
#include "image.hpp"

#include <stdlib.h>
#include <search.h>
#include <memory.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// int ImageHist::getRange( void )
// 		Get range maximum value of image and histogram
//
//	returns int -	maximum posible value in histogram 
unsigned int 
ImageHist::getRange( void )  const
{ 	
	return( range );  
}  

// long ImageHist::getFrequency( unsigned int value )
// 		Get the number of hits at value x in image
//
// 	int value -	position in histogram 
// 	returns long -	number of hits or -1 on error

unsigned long
ImageHist::getFrequency( unsigned int value ) const
{
 	return( (( value>=range )? 0L: hist[value]) );
}

//	ImageHist::ImageHist( long* histogram, int nopoints )
//		ImageHist construtor with an initial histogram produced somewhere else
//	
//	long* histogram -	pointer to an array of histogram points which is copied
//	int nopoints	-	number of points in the array histogram
//
//	
//
ImageHist::ImageHist( unsigned long* histogram, int nopoints ) : range(256)
{
	
	// copy data across
	for( int i =0; i < nopoints; i ++ )
	{
		hist[i] = histogram[i];
	}		
}

ImageHist::ImageHist( const ImageHist& ihist ) : range(256) 
{

	// copy data across
	for( unsigned int i =0; i < ihist.getRange(); i ++ )
	{
		hist[i] = ihist.getFrequency( i );
	}		
}

ImageHist::ImageHist( void ) : range(256)
{
	Clear();
}

ImageHist::~ImageHist( void )
{

}

///////////////////////////////////////////////////////////////
// convert a histogram through a lookup table
void 
ImageHist::Convert( const ImageLut& lut )
{
   unsigned long new_hist[256];

   // copy and clear hist
   int x = 256;
   while( x-- ){ new_hist[x] = hist[x]; hist[x] = 0L; }

   // copy back through lut
   x = 256;
   while( x-- ) { hist[ lut[x] ] += new_hist[x]; }

}


// int ImageHist::histogram( image* rimage, int band, ImageArea *area, HistType flags )
// 	collect histogram of band of image
//
// image* rimage -	image to histogram
// int band -	band to read from image
// ImageArea* area -	area or subset to histogram 
// HistType flags -	flag on weather to clear the histogram before histograming 
// returns -	1 if completed successfuly else 0 on file or memory error 
// 				unless returns 1 histogram will be invalid
int
ImageHist::histogram( Image* rimage, int band, ImageArea* area, HistType flags )
{
 	IASSERT( rimage != NULL && area != NULL ); // valid arguments
 	
 	unsigned char* buffer = new unsigned char [ rimage->getWidth() ] ;
 	 	
 	if(  buffer == NULL )   // error check memory allocation
 	{
 		IPOSTERROR( ERR_MEM_ALLOC );
 		return( FALSE );
 	}
 	
	if( flags == HIST_NOADD )
	{
		int z = range;
		while( z-- ) hist[z] = 0L;	  // clear histogram
	}

	unsigned char* sub_buffer = &buffer[ area->getTopX() ];
	int sub_width = area->getWidth();
	int sub_topy = area->getTopY();
	int sub_height = area->getHeight();

 	for( int y = 0; y < sub_height; y++ )
 	{
 	 	
		if( rimage->read(buffer, sub_topy +y, 1, band) == FALSE ) // read line
		{
   			delete [] buffer;
         	return( FALSE );
      	}

		int x = sub_width;
 	 	while( x-- )	 // loop through and hist
 	 	{
 	 	 	hist[ sub_buffer[ x ] ] ++;	// hist[ value at offset[x] ] ++ 
 	 	} 
        
    }
    
    delete [] buffer;		// clean up buffer
	return( TRUE );
}

// int ImageHist::histogram(  image* rimage, int band )
// 		collect stats ( histogram from image ) on whole image
// 
// image *rimage -	image to read from
// int band -	band of image to read from
// returns int -	1 on success else 0 on file or memory error
int
ImageHist::histogram( Image* rimage, int band, HistType flags )
{
 	ImageArea area( 0,0, rimage->getWidth(), rimage->getHeight() );
 	return( histogram( rimage, band, &area, flags));
}
 
int compare_type( const void* element_a,  const void* element_b );

// inverted compare for quick sort
int 
compare_type( const void* el_a,  const void* el_b )
{
 	unsigned long* a = (unsigned long*) el_a;
 	unsigned long* b = (unsigned long*) el_b;
	
	
	if( (*a) > (*b) ) return -1; 
 	else if( (*a) < (*b) ) return 1; 
	else return 0; 	
}

// sort frequency data into decending order and produce a lut on postion
ImageLut*
ImageHist::Sort( void ) const
{
	// create an array of frequency and postion
	unsigned long array[512];
	int pos =0;
	
	for( int x = 0; x < 256; x++ )
	{
	 	array[pos++] = hist[x];
	 	array[pos++] = x;
	}
	
	// sort frequency
    qsort( array, 256, sizeof( unsigned long)*2, compare_type );
    
    // copy out postiion into lut
    ImageLut* lut = new ImageLut();
    if( lut != NULL )
    {
        pos = 1;
		for( x = 0; x < 256; x++ )
		{	(*lut)[x]  = (unsigned char)array[ pos ];  pos += 2; }
	 }
     // return lut may be NULL
     return lut;
}	


