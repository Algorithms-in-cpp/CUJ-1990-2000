//	File: itypes.hpp
//	Description: defined library wide constants
//
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//



#ifndef IMAGELIB_IMAGETYPES
#define IMAGELIB_IMAGETYPES


#endif	   // IMAGELIB_IMAGETYPES