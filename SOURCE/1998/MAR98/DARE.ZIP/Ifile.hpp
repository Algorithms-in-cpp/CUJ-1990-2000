//	File: ifile.hpp
//	Description: file handle class, designed to hide file handeling deatils from library
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//



#ifndef IMAGELIB_IMAGEFILE
#define IMAGELIB_IMAGEFILE

#include <string.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>

class CString;

class ImageFile
{
    public:               	
    ImageFile( void ); 		// constructor
    ImageFile( const ImageFile& filecopy ); // copy constructor trys to re open file
    ~ImageFile( void );    	// destructor closes file and cleans up
    
    
    enum openflags  // open flags used to with open 
    	{
    	READONLY,		// open old file
    	WRITEONLY,  	// open new file for writing
    	READWRITE,  	// open oldfile for reading and writing
        NEWREADWRITE,  	// open a new file for reading and write
        TEMPREADWRITE  	// temporay new file
        };
    
    enum seekflags  // seek flags used with seek
    	{
    	CURRENT = SEEK_CUR, 	// seek from current position
    	BEGINNING = SEEK_SET,	// seek from beginning
    	END = SEEK_END	 		// seek from end
    	}; 
    
    // open file
	BOOL open(const char* filename, openflags flags );
	
	// file functions
	BOOL read( void* buffer, int nobytes );
	BOOL write( void* buffer, int nobytes );
	BOOL seek( long moveBytes, seekflags flags ); 
    
    // information routines   
    const char* getFileName( void ) const;
    
    BOOL isOpen( void ) const { return m_openflag; };
    BOOL isReadOnly( void ) const{ return m_readonly; };
    BOOL isTemp( void ) const { return m_tempory; };
    
    long getFilePos( void );
        
    private:                // the privy bits

	int m_filehandle;
    CString* m_pathname;		// file we have opened
    
    BOOL m_tempory;        // temp file flag
    BOOL m_readonly;			// readonly flag
    BOOL m_openflag;		// is object open and valid

}; // end ImageFile

#endif // end if IMAGELIB_ImageFile

 
