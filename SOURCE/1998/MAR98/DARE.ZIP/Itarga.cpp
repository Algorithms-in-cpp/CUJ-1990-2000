//	File: itarga.cpp
//	Description: targa format handleing routines 
//
//	Author: C Dare-Edwards
//
//  Copyright Conrad Dare-Edwards 1997  
//
#include "stdafx.h"

#include "isystem.hpp"
#include "itarga.hpp"

#include <memory.h>
#include "image.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
 
BOOL 
ImageTarga::isTarga( ImageFile& file, ImageInfo& info ) 
{
 	file_header fhead;

    file.seek( 0L, ImageFile::BEGINNING );	
	file.read( &fhead, 3);		 // read header off disk
	file.read( &fhead.ColourMap_FirstEntry, 5 );
    file.read( &fhead.XOrigin, 10 );
	
	if( fhead.Colour_Map_Type != 0 )	// we have a colour table
	{
	 	// compute the length of the colour map
	 	int colourmap_length = ((fhead.ColourMap_Length * fhead.ColourMap_Size) / 8 );
	 	// add them all together
	 	info.getHeaderSize() = 18 + fhead.ID_Length + colourmap_length; 
	}	
	else 	// we dont have a colour table
	{	
		// add up the standard size
		info.getHeaderSize() = 18 + fhead.ID_Length;
	}

	if( fhead.Width < 1 ||  fhead.Height < 1 || 	// test a few values
	( fhead.PixelDepth != 8 && fhead.PixelDepth != 24 ))
	{
		return( FALSE );  // not a targa image
	}

	info.getWidth() =  fhead.Width;		// set width and height
	info.getHeight() = fhead.Height;
    	
	switch(	fhead.Image_Type )
	{
 	
	 	case BLACK_N_WHITE:
			info.getFormat() = TARGA;
			info.getNoBand() = 1;
			break;	 			

        case TRUE_COLOUR:
			info.getFormat() = TARGA;
			info.getNoBand() = 3;
			break;	 			

		default:
			return( FALSE );    // not a targa image we don't handle all targa types
	}

	info.getStorage() = BIP;
	info.getFileType() = READ_ONLY;
	info.getBytesPerBand() = info.getWidth();
	info.getBytesPerLine() = info.getWidth() * info.getNoBand();
	return TRUE;
}

// read header check if its a targa format image and load info
// returns 1 if loaded of else 0 if error -1 if invalid format 
BOOL
ImageTarga::open( const char* filename )
{

    if( ImageFile::open( filename, ImageFile::READONLY) ==0) 
     	return( FALSE ); // can't open file or already open ImageFile will post error 

   	setFilename( filename ); // set filename in info

	if( isTarga( *this, *this ) != TRUE)
		return( FALSE );  // not a targa image 

	Setup( );	      // setup ImageBIP
    return( TRUE );  // success 
}

