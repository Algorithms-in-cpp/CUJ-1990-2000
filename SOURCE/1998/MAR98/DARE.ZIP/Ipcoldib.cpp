//	File: ipColdib.cpp
//	Description: Pseudo colour dib handleing routines 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards  1997 
//

#include "stdafx.h"

#include "ipcoldib.hpp"
#include "idib.hpp"

#include "image.hpp"
#include "iplut.hpp"

#ifdef _DEBUG                 // debugging 
#define new DEBUG_NEW
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////
// constructor 
ImagePsColourDib::ImagePsColourDib( int newband  )
	: rlut(), glut(), blut() 
{
 	band = newband;	         // set this to a defualt band 0
    lut_Mode = 	GREY_SCALE;	 // intialy setup grey scale

	// clear optomising histogram to 1 all colours active
	for( int x=0; x< 256; x++ )
	{
		m_opthist[x] = 1;	 // all on all active
	}
}

/////////////////////////////////////////////////////////////////
//
ImagePsColourDib::~ImagePsColourDib( void )
{
 	// do nothing
}

////////////////////////////////////////////////////////////////////////////
// create bitmap and copy in image data
int
ImagePsColourDib::CreateDib( Image* rimage )
{
 	// read in image and setup
	int width  = rimage->getWidth();
	int height = rimage->getHeight();

	// create the dib to copy into
	if( ImageDib::CreateDib( 8, width, height ) == FALSE )
	{		
		// falied to create an new image
		return( FALSE );
	}
	
	// allocate memory
	unsigned char* buffer = new unsigned char[ width];
	if( buffer == NULL )
	{
	 	// can't allocate memory
	 	IPOSTERROR( ERR_MEM_ALLOC ); return( FALSE );
	}
	
	// for height of image copy across image data
	for( int y =0; y < height; y++ )
	{
		rimage->read(buffer, y, 1, band );	 	
	 	SetBits( buffer, y, 1 );
  	}

	// clean up memory
	delete [] buffer;
	
	// and upadate palette
	return( UpdateDib() );
}

// set all lookup tables an equal 0 - 255
void ImagePsColourDib::SetGrey( void )
{
	ImagePointLut newlut;
	newlut.SetMinToMax( 0, 255 );
	UpdateLut( newlut, GREY );
}

// split the three channel lookup tables 
// into red green and blue components
void ImagePsColourDib::SetColour( void )
{
	ImagePointLut newrlut;
	newrlut.SetMinToMax( 0, 255, ImagePointLut::RED );
	UpdateLut( newrlut, 0 );

	ImagePointLut newglut;
	newglut.SetMinToMax( 0, 255, ImagePointLut::GREEN );
	UpdateLut( newglut, 1 );

	ImagePointLut newblut;
	newblut.SetMinToMax( 0, 255, ImagePointLut::BLUE );
	UpdateLut( newblut, 2 );
}

// optimise colour useage
// produce a histogram of all colours used
// and compress the range down to the fewest colours
void 
ImagePsColourDib::Optomise( const ImageHist& hist )
{
	int height = getHeight();
	int width  = getWidth();
	
	// take histogram sort it and produce a lookup table from it
	{ // new lut internaly defined can't be used else where
		ImageLut* new_lut = hist.Sort();
		if( new_lut != NULL )
		{
			m_optlut = *new_lut;
			delete new_lut;
		}
	}

	// allocate memory
	unsigned char* buffer = new unsigned char[ width];
	if( buffer == NULL )
	{
	 	// can't allocate memory
	 	IPOSTERROR( ERR_MEM_ALLOC ); return;
	}
	
	// for height of bitmap read compress and write each line
	for( int y =0; y < height; y++ )
	{
	 	GetBits( buffer, y, 1 );
	 	m_optlut.Lookup( buffer, width );
	 	SetBits( buffer, y, 1 );
	}
        
    // set null values to black
	for( int x=0; x< 256; x++ )
	{
		if( hist.getFrequency( x ) <= 0 ) m_opthist[x] = 0;	 // if nothing turn off
	}

	// clean up memory
	delete [] buffer;
	
	UpdateDib( );		// watch this if updatedib  is changed
}

// get lookup table for specified channel 
const ImagePointLut&
ImagePsColourDib::GetBandLut( int band ) const
{
 	switch( band )
 	{
 		case RED:		return( rlut );
        case GREEN:		return( glut );
 		case BLUE:		return( blut );
 		case GREY:		return( rlut );
 		default:	return( rlut  );
 	}	
}    

// update lookup table
// copy across lookup table to the channel specified
// you wil need to call update lut before any changes are apparent
int ImagePsColourDib::UpdateLut( const ImagePointLut& lut, int band )
{
 	switch( band )
 	{
 		case RED:			// update red lut of image		
 			rlut = lut;
        	lut_Mode = PSEUDO_SCALE;
			break;

        case GREEN:		   // update green lut of image
        	glut = lut;
			lut_Mode = PSEUDO_SCALE;
 			break;

 		case BLUE:		
 			blut = lut;
 			lut_Mode = PSEUDO_SCALE;
			break;

		case GREY:
			rlut= lut;	// update all lut of image
    		glut= lut;
    		blut= lut;
    		lut_Mode = GREY_SCALE;
			break;
			 		
 		default:				// error 
 			break;;
 	}	

	return( TRUE );		// default return
}


// update bitmap
// create a new palette with current lookup tables
// returns true on success
int
ImagePsColourDib::UpdateDib( void )
{
    for(int i = 0; i < 256; i ++ )
    {
  	    // find out where i is on the old range
		unsigned char x =  m_optlut[(unsigned char)i];
  	    
		if( m_opthist[i] == 0 )   // if no pixels set to black
 	 	{    
 	 		SetPalette ( x, 0,0,0);  
 	 	}
  	    else                   // else set colour
  	    {
 	    	// compute value at i and set it at x
			SetPalette ( x, 
 	    		rlut[ (unsigned char)i ],
       	   		glut[ (unsigned char)i ],
       	   		blut[ (unsigned char)i ]);
		}
	}

	return( TRUE );   // defualt success
}
