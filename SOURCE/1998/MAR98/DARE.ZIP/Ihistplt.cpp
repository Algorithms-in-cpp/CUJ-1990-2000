//	File: ihistplt.cpp
//	Description: plot histograms on a CDC object
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards   1997
//


#include "stdafx.h"
#include "ihistplt.hpp"
#include "igraph.hpp"

ImageLutPlot::ImageLutPlot( CRect& plotarea ): ImageHistPlot( plotarea ) 
{ 
	// nothing
}

ImageHistPlot::ImageHistPlot(CDC* pDC, CRect& plotarea): ImageGraph(pDC,plotarea,256,256) 
{
	scaleing_percent = (float)3.0; // set y max at 3 percent
	plot_percent = TRUE;
}

ImageHistPlot::ImageHistPlot(CRect& plotarea): ImageGraph( plotarea,256,256) 
{
	scaleing_percent = (float)3.0; // set y max at 3 percent
	plot_percent = TRUE;
}

//////////////////////////////////////////////////////////////
//	clean up
ImageHistPlot::~ImageHistPlot( void )
{
 	// exit stage left 	// hey so Ive used it before
}

////////////////////////////////////////////////////////////////////
//	plot a histogram as a bar graph in our plot area
void 
ImageHistPlot::PlotBarGraph( CDC* pDC, const ImageHist& histogram,COLORREF colour, BOOL xaxis )
{
    /////////////////////////////////////////////////////
    // select our bar graphing colour
    CPen* ScalePen = new CPen( PS_SOLID, 0, colour ); 
    CPen* OldPen   = pDC->SelectObject( ScalePen );

	//////////////////////////////////////////////////////
	// compute scaling factor
	float scale = ComputeScaleingFactor(histogram);

   	//////////////////////////////////////////////////////
	// for each frequency plot bar 
    for( unsigned int x =0; x < 256; x++ )
    {
        // get value
        long length = (long)((float)histogram.getFrequency(x)/ scale);        
		DrawBar( pDC, x ,length, xaxis );	 // easy hey
    }


	/////////////////////////////////////////////////////
	// reset the colour pen 
    pDC->SelectObject( OldPen );
   	delete ScalePen;	// delete ScalePen object

}

////////////////////////////////////////////////////////////////
// compute scaeling factor for histogram ploting
float
ImageHistPlot::ComputeScaleingFactor( const ImageHist& histogram )
{
	double percentage = ((double)histogram.getNumber()* (scaleing_percent/(double)100));
	
	float scale = (float)(percentage / (double)YRange);
	if( scale <= (float)0 ) scale = (float)0.1;	  // round up if we have a problems
	
	return( scale );
}


void ImageHistPlot::SetScaleing( const ImageHist& histogram )
{
  // find biggest block in histogram
  long largest = 0;
  for( int x =0; x < 256; x++)	  // find the largest 
  {
  	  long current = histogram.getFrequency( x );
	  if( current > largest ) largest = current ; 
  }

					 // compute what is the largest in percentage
  scaleing_percent = (float)(((double)largest/histogram.getNumber())*(double)100); 

  if( scaleing_percent <= (float)0)	scaleing_percent =(float) 1; // catch errors
}

BOOL
ImageHistPlot::YScaleToString( CString& string, long value )
{
	char buffer[20];

	if( plot_percent )
	{
		double plot_value = ((double)scaleing_percent / 256.0)* ( double) value; 
		if( sprintf(  buffer,"%.2f%%", plot_value ) > 5 )
		{
    		if( sprintf(  buffer,"%.1f%%", plot_value ) > 5 )
			sprintf(  buffer,"%.0f%%", plot_value );
		}
    	string = buffer;
	
		return TRUE;
	}
	else
	{
		return( ImageGraph::YScaleToString( string, value ) );
	}
}

BOOL
ImageHistPlot::XScaleToString( CString& string, long value )
{
	if( value >= 256 ) value = 255;
	string.Format("%d", value);
	return TRUE;
}
