//	File: ierror.hpp
//	Description: library error handleing definitions 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//

#ifndef	IMAGELIB_IMAGEERROR
#define IMAGELIB_IMAGEERROR

////////////////////////////////////////////////////////////////////////
// ImageError
// library wide error reporting object


////////////////////////////////////////////////////////////////////////
// error types and defintions 
enum ImageErrorType
{
	ERR_NULL =0,
	ERR_BREAK,              // user break dectected 
	ERR_MEM_ALLOC,			// failed to allocate memory
	ERR_FILE_OPEN,			// can't open file 
	ERR_FILE_READ,          // read failed
	ERR_FILE_WRITE,         // write failed
	ERR_FILE_SEEK,			// seek failed
	ERR_OBJ_ALREADYOPEN,  	// already open
	ERR_OBJ_INVALIDARGS,    // invalid arguments
	ERR_OBJ_INVALID,		// object not intialised or not open
	ERR_UNHANDLED_TARGA, 	// unhandled version of targa
	ERR_UNKNOWNFORMAT,  	// create image failed
	ERR_FAILED_ASSERT		// failed an assertion
};

/*
char* ImageError_TypeString[] =
"No Error",
"Break",
"Can't Allocate enought memory",
"Can't Open file",
"Can't Read file",
"Can't Write to file",
"Unepected end of file",
"Internal - object already open",
"Internal - invalid arguments",
"Internal - object invalid",
"Unhandled targa format",
"Unrecognised image format",
"Internal - Failed assertion";
*/


class ImageError
{
	public:
	ImageError( void );
	~ImageError( void );
	void PostTrace( const char* message, const char* filename, int line );
	void PostError(  const ImageErrorType error, const char* filename, int line );	
	void PostError(  const ImageErrorType error  );	
	void PostBreak( void );
    void ClearErrors( void );
	
	BOOL CheckBreak( void ) const;
	
	private:
	ImageErrorType lasterror;
};


inline BOOL ImageError::CheckBreak( void ) const
{
 	return ( (lasterror == ERR_NULL ) ? FALSE : TRUE ); 
}


/////////////////////////////////////////////////////////////////////////
// global error handler
extern ImageError IErrorHandle;		// global ImageError object defined in ierror.cpp

//////////////////////////////////////////////////////////////////////////
// object inspecific macros

/////////////////////////////////////////////////////////////////////////
// check break macros
#define ICHECKBRK	IErrorHandle.CheckBreak()
#define ICLEARBRK	IErrorHandle.ClearErrors();

////////////////////////////////////////////////////////////////////////////////
// debugging macro versions
// errror reporting and debugging macros
#ifdef _DEBUG
#define IASSERT( arg ) if( !(arg ) ) IErrorHandle.PostError( ERR_FAILED_ASSERT, __FILE__, __LINE__ ) 
#define IPOSTERROR( arg )  IErrorHandle.PostError( arg, __FILE__, __LINE__ )
#define ITRACE( arg )   IErrorHandle.PostTrace( arg,  __FILE__, __LINE__  )
///////////////////////////////////////////////////////////////////////////////
// no debugging versions
// assertions and traces removed 
#else	
#define IASSERT( arg ) 	   // nothing
#define IPOSTERROR( arg )  IErrorHandle.PostError( arg ) // no line and file info
#define ITRACE( arg )       // NULL definition
#endif  // else if _DEBUG
		    	
#endif	// IMAGELIB_IMAGEERROR
