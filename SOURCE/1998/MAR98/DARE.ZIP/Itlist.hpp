//	File: itlist.hpp
//	Description: Template list class 
//
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//


#ifndef  _IMAGELIB_TEMPLATELIST
#define _IMAGELIB_TEMPLATELIST

#include "isystem.hpp"
#include "itypes.hpp"

typedef void* ILISTPOS;

template<class TYPE>
class ImageTList 
{
	protected:
	struct IListNode
	{	
		IListNode* pNext;
		IListNode* pPrevious;
		TYPE data;
	};

	public:
	ImageTList(  void  );
	ImageTList(  const ImageTList<TYPE>& newlist );
	~ImageTList( void  );
	
	ImageTList<TYPE>& operator=(const ImageTList<TYPE>& copylist);
	
	// list information
	int getLength( void ) const;
	const BOOL  isEmpty( void ) const;
	
	// access data
	const TYPE& getData( ILISTPOS pPosition )  const;
	TYPE& getData( ILISTPOS pPosition  );

	const TYPE& operator [] ( int nIndex ) const; 
	           TYPE& operator [] ( int nIndex );      

	// access list 
	ILISTPOS getNext( ILISTPOS pPosition ) const;
	ILISTPOS getPrev( ILISTPOS pPosition ) const;
	ILISTPOS getHead( void ) const;
	ILISTPOS getTail( void ) const;

	ILISTPOS FindIndex( int nIndex ) const; 

	// add and remove elements
	BOOL InsertAfter( const TYPE& newType, ILISTPOS pPosition ); 
	BOOL InsertBefore( const TYPE& newType, ILISTPOS pPosition ); 
	BOOL Append(  const TYPE& newType );
	BOOL Remove(  ILISTPOS pPosition );
	BOOL Swap( ILISTPOS aPos, ILISTPOS bPos );

	void RemoveAll( void );

	private:
	
	IListNode* m_pListHead;
	IListNode* m_pListTail;
	int m_length;	

	// node creation and deletetion
	IListNode* CreateNode( IListNode* pAfter, IListNode* pBefore );
	void DeleteNode(  IListNode* pNode ); 

	
};	// end ImageTList

//////////////////////////////////////////////////

// ImageTList - default constructor
template<class TYPE>
inline ImageTList<TYPE>::ImageTList(  void  )
{
	// intalise pointers 
	m_pListHead = NULL;
	m_pListTail = NULL;
	m_length = 0;
}

// ImageTList - copy constrtuctor
template<class TYPE>
inline ImageTList<TYPE>::ImageTList(  const ImageTList<TYPE>& newlist )
{
	// intalise pointers 
	m_pListHead = NULL;
	m_pListTail = NULL;
	m_length = 0;

	// copy all objects from new list to our list
	ILISTPOS pPosition = NULL;
	while( (pPosition = newlist.getNext( pPosition )) !=  NULL )
		Append( newlist.getData( pPosition) );
}

// ~ImageTList - remove all nodes from the list and clean up
template<class TYPE>
inline ImageTList<TYPE>::~ImageTList( void  )
{
	if(  !isEmpty()  )
		RemoveAll();	// delete everything
}

// operator = - copy a simular TYPE list removing our contents
template<class TYPE>
inline ImageTList<TYPE>& ImageTList<TYPE>::operator=(const ImageTList<TYPE>& copylist)
{
	RemoveAll();	// clear our list	

	// copy all objects from new list to our list
	ILISTPOS pPosition = NULL;
	while( (pPosition = copylist.getNext( pPosition )) !=  NULL )
		Append( copylist.getData( pPosition) );
	
	return *this;
}

// getLength - return the number of nodes in the list
template<class TYPE>	
inline int ImageTList<TYPE>::getLength( void ) const
{
	return m_length;
}

// isEmpty - test if list contains all node at all
template<class TYPE>
inline const BOOL ImageTList<TYPE>::isEmpty( void ) const
{
	// if m_nLength then assert pointers != NULL else assert pointers == NULL 
	IASSERT( 
	     ( ( m_length > 0 ) 
	      ? (m_pListHead != NULL && m_pListTail != NULL ) 
	      : (m_pListHead == NULL && m_pListTail == NULL ))
	 ); 

	return ( m_length<= 0 );  // number of nodes is greater than 0
}

// operator [] - return a constant reference to node x in the list 
template<class TYPE>	
inline const TYPE& ImageTList<TYPE>::operator [] ( int nIndex ) const
{
	IASSERT( nIndex  < m_length );
	return getData(  FindIndex( nIndex ) );
}

// operator [] - return a reference to node x in the list 
template<class TYPE>
 inline  TYPE& ImageTList<TYPE>::operator [] ( int nIndex )      
{
	IASSERT( nIndex  < m_length );
	return getData(  FindIndex( nIndex ) );
}

// getNext - get the next node from indicated postion
// handed a NULL position returns head node
template<class TYPE>
inline ILISTPOS ImageTList<TYPE>::getNext( ILISTPOS pPosition ) const
{
	IASSERT( !isEmpty() );
	
	// if NULL pointer return head node
	if( pPosition == NULL )
		return ( ILISTPOS) m_pListHead;

	// else more normaly return next node NULL if end of list
	IListNode* pNode = (IListNode*) pPosition;
	return (ILISTPOS) pNode->pNext;
}

// getPrev - get the previous node of indicated position
// handed a NULL position returns tail node
template<class TYPE>
inline ILISTPOS ImageTList<TYPE>::getPrev( ILISTPOS pPosition ) const
{
	IASSERT( !isEmpty() );
	
	// if NULL pointer return head node
	if( pPosition == NULL )
		return ( ILISTPOS) m_pListTail;

	// else more normaly return next node NULL if end of list
	IListNode* pNode = (IListNode*) pPosition;
	return ( ILISTPOS) pNode->pPrevious;
}

// getHead - return the position of the first node
template<class TYPE>
inline ILISTPOS ImageTList<TYPE>::getHead( void ) const
{
	IASSERT( !isEmpty() );
	return ( ILISTPOS) m_pListHead;
}

// getTail - return the position of the last node 
template<class TYPE>
inline ILISTPOS ImageTList<TYPE>::getTail(  void ) const
{
	IASSERT( !isEmpty() );
	return ( ILISTPOS) m_pListTail;
}

// getData - return a constant reference to the TYPE at position 
template<class TYPE>	
inline const TYPE& ImageTList<TYPE>::getData( ILISTPOS pPosition )  const
{
	IASSERT( pPosition != NULL );
	IListNode* pNode = (IListNode*) pPosition;
	return( pNode->data );
}

// getData - return a reference to the TYPE at position 
template<class TYPE>
inline TYPE& ImageTList<TYPE>::getData( ILISTPOS pPosition  )
{
	IASSERT( pPosition != NULL );
	IListNode* pNode = (IListNode*) pPosition;
	return( pNode->data );
}

// InsertAfter - Insert a new node after the position given 
template<class TYPE>
inline BOOL ImageTList<TYPE>::InsertAfter( const TYPE& newType, ILISTPOS pPosition ) 
{
	IASSERT( !isEmpty() &&  pPosition != NULL );

	IListNode* pNode =  CreateNode(  ((IListNode*) pPosition), 
		((IListNode*) pPosition)->pNext ) ;
	
	if( pNode != NULL )
	{
		pNode->data = newType;	// copy data
		return TRUE;
	}
	else return FALSE;	// allocation error	
}

// InsertBefore - Insert a new node ahead of  the position given 
template<class TYPE>
inline BOOL ImageTList<TYPE>::InsertBefore( const TYPE& newType, ILISTPOS pPosition )
{
	IASSERT( !isEmpty() &&  pPosition != NULL );

	IListNode* pNode =  CreateNode(  ((IListNode*) pPosition)->pPrevious, 
		((IListNode*) pPosition)) ;

	if( pNode != NULL )
	{
		pNode->data = newType;	// copy data
		return TRUE;
	}
	else return FALSE;	// allocation error	
}

// Append - create a new node, copy data and add it to the end  
template<class TYPE>
inline BOOL ImageTList<TYPE>::Append( const TYPE& newType )
{
	IListNode* pNode  = CreateNode( m_pListTail, NULL);	
	if( pNode != NULL )
	{
		pNode->data = newType;	// copy data
		return TRUE;
	}
	else return FALSE;	// allocation error	
}

// Remove - remove a node from the list
template<class TYPE>
inline BOOL ImageTList<TYPE>::Remove(  ILISTPOS pPosition )
{
	if( !isEmpty() && pPosition != NULL )
	{
		IListNode* pNode = (IListNode*) pPosition;
		DeleteNode( pNode );
		return TRUE;
	}
	else return FALSE;	// error no nodes or invalid
}

// RemoveAll - remove al the nodes in the list
template<class TYPE>
inline void ImageTList<TYPE>::RemoveAll( void )
{
	if( !isEmpty() )
	{
		// while nodes delete nodes
		while( !isEmpty() ) DeleteNode( m_pListHead );  
	}
}

// CreateNode - allocate a new node and insert it between the two handed pointers
template<class TYPE>
inline ImageTList<TYPE>::IListNode* 
ImageTList<TYPE>::CreateNode( ImageTList::IListNode* pAfter, ImageTList::IListNode* pBefore)
{
	// create a new node
	IListNode* pNode = new  IListNode;
	if( pNode == NULL ) return NULL;
	
	// set links in the list
	pNode->pNext = pBefore;
	pNode->pPrevious = pAfter;
	
	// set pointers in nodes iether side 
	if( pAfter != NULL )  pAfter->pNext = pNode;
	else m_pListHead = pNode; 
	
	if( pBefore != NULL ) pBefore->pPrevious = pNode;
	else m_pListTail = pNode; 

	m_length++;	// one longer
	return pNode;
}

// DeleteNode - remove node from the list and delete the object
template<class TYPE>
inline void ImageTList<TYPE>::DeleteNode(  IListNode* pNode ) 
{
	IASSERT( !isEmpty() );
	
	// set previous node to look at next node else move list head down
	if( pNode->pPrevious != NULL )  pNode->pPrevious->pNext = pNode->pNext;
	else m_pListHead = pNode->pNext;

	// set next node to look a previous node else shift tail up
	if( pNode->pNext  != NULL )  pNode->pNext->pPrevious = pNode->pPrevious;
	else m_pListTail =  pNode->pPrevious;

	m_length--;	// one smaller	
	IASSERT( m_length >= 0  ); // warn us of problems
	
	pNode->pNext = pNode->pPrevious = NULL;	// catch errors
	delete pNode;	// and free up the memory
}

// Find Index - find node x in the list counting down from the top
template<class TYPE>
inline ILISTPOS ImageTList<TYPE>::FindIndex( int nIndex ) const 
{
	IASSERT( nIndex  < m_length  && nIndex >=  0 );

	ILISTPOS pPosition = NULL;
	while( (pPosition = getNext( pPosition ))!= NULL && nIndex-- > 0 ) 
		;
	return pPosition;
}

template<class TYPE>
inline BOOL ImageTList<TYPE>::Swap( ILISTPOS aPos, ILISTPOS bPos )
{
	IASSERT( aPos != NULL && bPos != NULL );
	IListNode* aNode = (IListNode*) aPos;
  	IListNode* bNode = (IListNode*) bPos;

	TYPE hold = aNode->data;
	aNode->data = bNode->data;
	bNode->data = hold;

	return TRUE;
}


#endif	// _IMAGELIB_TEMPLATELIST
