//	File: iplut.cpp
//	Description: image point lookup table routines 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997
//

#include "stdafx.h"

#include "isystem.hpp"
#include "iplut.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// defualt constructor
ImagePointLut::ImagePointLut( void ) 
{
 	Update();	// add default points	
}

// copy constructor
ImagePointLut::ImagePointLut( const ImagePointLut& newlut ) 
{
	m_PointList = newlut.getPointList(); 
	Update();  // maintain a valid list
} 

// Intailise with a m_PointList
ImagePointLut::ImagePointLut( const ImagePList& newpoints  )
{
	m_PointList = newpoints; 
	Update();  // maintain a valid list
} 


// produce a logorithmic curve between the 
// minimum and maximum points
void 
ImagePointLut::SetLog( const ImageHist& hist )
{
	int min, max;
	OptimiseMinMax( hist, min, max );
 	SetLog( min, max);
}

// produce a logrithmic curve between two points
void 
ImagePointLut::SetLog( int min, int max )
{
 	float step = (max - min) / (float)16.0;
  	float total = (float)0.0;
	
	m_PointList.RemoveAll();  // start a new list fresh

 	for(int x =0; x < 256; x+= 16 )
 	{
		double value = log10( (double)x+1 ) * 106.3017;

		// add it to the list
		m_PointList.
			Append(ImagePoint( min+(int) total,((int)value)));
 		total += step;
 	}

	Update( TRUE);
}

// create a exponential curve between the min and max
void 
ImagePointLut::SetExp( const ImageHist& hist )
{
	int min, max;
	OptimiseMinMax( hist, min, max );
 	SetExp( min, max );
}

// create an expontial curve between two points
void 
ImagePointLut::SetExp( int min, int max )
{
 	float step = (max - min) / (float)16.0;
  	float total = (float)0.0;

    m_PointList.RemoveAll();  // start a new fresh list

 	for( int x =0; x <= 16; x++ )
 	{
		int value;
		if( (value= (x*x)) > 255 ) value = 255; 
		m_PointList.Append(ImagePoint( min+(int)total, value));
 		total += step;
 	}
	Update( TRUE);
}

// histogram equalisation 
void
ImagePointLut::Equalise( const ImageHist& hist )
{
	double divider = hist.getSum() / 255.0;
	double total=0;
	
	// equalise and produce a table 
    	for(int i=0; i < 256; i++ )
    	{
		total += (double)hist.getFrequency(i) * (double)i;
		(*this)[i] = (int)(total /divider) ;
        }

// build some points from the table produced
	BuildPointList();
}

// do a defualt min max stretch using info from histogram
void
ImagePointLut:: SetMinToMax( const ImageHist& hist, colour type)
{
 	int min, max;
	OptimiseMinMax( hist, min, max );
	SetMinToMax( min, max, type );
}

// OptimiseMinMax - find the min and max 
// with a 5% chop at each end
void
ImagePointLut::OptimiseMinMax
	( const ImageHist& hist, int& min, int& max )
{
	// fnid out what 5% in total are
	long percentage = (long )( hist.getNumber() / 20);
	
	// find 5 percent from the bottom
	long total =0; 
	for(int x=hist.getMinimum();total<percentage && x<256; x++)
	{ 
	       total += hist.getFrequency( x);	
	}
	min = x; // and set minumum + 5%
	
	// find 5% from the top
	total =0; 
	for(x =hist.getMaximum(); total<percentage && x>=0; x--)
	{	
 		total += hist.getFrequency( x );	
	}
	max = x; // and set maximum - 5%

	// make sure these aren't inverted
	// min is not >= to max
	if( min >= max  ) 
	{
		// if so just set the default
		min = hist.getMinimum();	
		max = hist.getMaximum();	 	
	}
}

// setup a standard min to max stretch
void
ImagePointLut:: SetMinToMax( int min, int max, colour type)
{
	IASSERT( min >= 0 && min <= 255 );
	IASSERT( max >= 0 && max <= 255 );

    	m_PointList.RemoveAll();  // start a new list fresh
   	
	if( type == GREEN )
	{
 		m_PointList.Append( ImagePoint( min, 0 ));
 		m_PointList.Append( ImagePoint( (max - min)/2, 255 ));
 		m_PointList.Append( ImagePoint( max, 0 ));
		
		// max sure there is an end point at 0 
    	if( max != 255 ) 
			m_PointList.Append( ImagePoint( 255, 0 ));
	}
	else  
	{
 		 m_PointList.Append( ImagePoint( min, 0 ));
 		 m_PointList.Append( ImagePoint( max, 255 ));
	}

	Update();

    if( type == BLUE  ) Invert(FALSE, TRUE);	
}

// optimise a min max stretch by holding 
// to the mean from the mean
void 
ImagePointLut::Optimise( const ImageHist& hist,colour type )
{
	SetMinToMax( hist, type );	// defualt min to max	
   	
	if( type == GREEN )
	{
		// find central point or (first to equal 255 on thy axis) 
		// and move x to mean 
		ILISTPOS pos = NULL;
		while(  ( pos = m_PointList.getNext( pos )) != NULL )
		{
			if( (m_PointList.getData(pos)).y == 255 )
			{
			   (m_PointList.getData(pos)).x =(int)hist.getMean();
				break;
			}
		}
	}		
	else
	{
    		// add a new central mean
		m_PointList.Append(  ImagePoint( (int)hist.getMean(),
				getRange() / 2 ) );                                 
	}
	
	Update();	// resort list
}

// invert all points on iether axis
void 
ImagePointLut::Invert( BOOL xaxis, BOOL yaxis )
{
	// scan through all points and invert them on each y axis
	ILISTPOS pos = NULL;
	while(  ( pos = m_PointList.getNext( pos )) != NULL )
	{
		// copy poiint
		ImagePoint point =  m_PointList.getData( pos );
	
		// invert
		if( yaxis ) point. y  = 255 - point.y;  // y axis
		if( xaxis ) point. x  = 255 - point.x;    // x  axis
	
		// and put it back in the list
		m_PointList.getData( pos ) = point;
	}

     Update(); // resort list
}

// Update - sort tidy and recompute lookup table
void
ImagePointLut::Update( BOOL tidy )
{
	// make sure that the m_PointList is ok
	SortPointList();
	
	// remove un needed points if requestedi
	if( tidy)  TidyPointList();	

	// catch problems 
	if( !m_PointList.isEmpty() )
	{
		// compute lookup table 
		// scan through list and hand across to ScaleTo
		ILISTPOS pos  = m_PointList.getHead(); 
		ILISTPOS last = pos;	
		while(  ( pos = m_PointList.getNext( pos )) != NULL)
		{
			ImageLut::ScaleTo( m_PointList.getData( last ), 
					m_PointList.getData( pos ));
			last = pos; // save pos for next round		
		}
	}
}

// SortPointList
void
ImagePointLut::SortPointList( void )
{
	// set to 0 if we dont need a 0,0 point
	int zeropoint =1;  
    // set to 0 if we dont need a 255,255 point
	int maxpoint  =1;  

	// scan through all points and invert them on each y axis
	if( !m_PointList.isEmpty() )
	{
		ILISTPOS pos = NULL;
		while(  ( pos = m_PointList.getNext( pos )) != NULL )
		{
    		// test for end points
			if( m_PointList.getData( pos ).x ==  0 )
			{
				zeropoint = 0;	   
			}
			else if( m_PointList.getData( pos ).x ==255) 
			{	
				maxpoint = 0;
			}
		}	
	}
	// insert top and bottom as needed
	if( maxpoint )
	{
		m_PointList.Append( ImagePoint( 255,255 ) ); 
	}
	
	if( zeropoint )
	{
		m_PointList.InsertBefore( 
			ImagePoint(0,0), m_PointList.getHead() );
	}
	
	// and a very simple sort routine	
	int changes;  // do untill list hasn't changed 
	do
	{
		// no change as of yet
		changes = FALSE;
		
		// skip the first node
		ILISTPOS pos = m_PointList.getHead();  

		while(  ( pos = m_PointList.getNext( pos )) != NULL )
		{
			ILISTPOS last = m_PointList.getPrev( pos ); 

			// if this point is greater swap them
			if(  m_PointList.getData(  last  ).x  > 
						m_PointList.getData(  pos ).x )
			{
				ImagePoint hold( m_PointList.getData(last));
				m_PointList.getData(  last  ) = 
							m_PointList.getData(  pos );
				m_PointList.getData(  pos ) = hold;
				changes = TRUE;
			}// end if greater
		} // end while in list
	
	}while( changes );

}

// Tidy - delete any unnessary points from the list
void 
ImagePointLut::TidyPointList( )
{
 	// can't run unless there are 3 or more points
	if( m_PointList.getLength() < 3 ) return;  

	// second point in list
	ILISTPOS pos  =m_PointList.getNext( m_PointList.getHead()); 
	ILISTPOS next;
	while(  ( next = m_PointList.getNext( pos )) != NULL )
	{
		ILISTPOS last = m_PointList.getPrev( pos );
	
		// work out wheather pos is on the 
		// line between last and next
		// (pos.x-last.x)*(next.y-last.y) - 
		// (pos.y-last.y)*(next.x-last.x)  	
		int offLine =
			((m_PointList.getData(pos).x - 
					m_PointList.getData(last).x)*
			 (m_PointList.getData(next).y - 
					m_PointList.getData(last).y))
	      - ((m_PointList.getData(pos).y - 
					m_PointList.getData(last).y)*
		     (m_PointList.getData(next).x - 
					m_PointList.getData(last).x));

		// if  on line between last and next its not needed 
		if(  abs(offLine) <= 1  ) m_PointList.Remove( pos );
		else 
		{
			if( m_PointList.getData(pos).x > 255 || 
				m_PointList.getData(pos).x < 0   ||
				m_PointList.getData(pos).y > 255 ||
				m_PointList.getData(pos).y < 0 )
				m_PointList.Remove( pos );
		}


		pos = next; // and go around again 
	}

}

// create a point list from ImageLut 
void 
ImagePointLut::BuildPointList( )
{
	m_PointList.RemoveAll();	// start fresh
	ImageLut* lut = (ImageLut*)this;	

	// always have the first point
	m_PointList.Append( ImagePoint( 0, (*lut)[0]) );

	int last = 0;
	for ( int pos = 1; pos< 255; pos++ )
	{ 
		int next = pos + 1;
	
		// work out wheather pos is on 
		// the line between last and next
		int offLine =(( pos - last)*
					 ((*lut)[next] - (*lut)[last]))-
			         (((*lut)[pos] -(*lut)[last])*
					  (next - last));

		int ydist = abs(((*lut)[pos]) - ((*lut)[last]));
		int xdist = pos - last;
		int distance = (ydist * ydist) + (xdist * xdist);
		
		// if distinct from other points add it to the list 
		if(  !(abs(offLine) <= 1) && distance >= 16)
		{
			// add this new point to the list
			m_PointList.Append( ImagePoint( pos,(*lut)[pos]));
			last = pos;	// shift last across to x 
		} 
	}

	// always have the end point
	m_PointList.Append( ImagePoint( 255, (*lut)[255]) );
}


