//	File: itarga.hpp
//	Description: header and type info for handleing targa images 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//


#ifndef IMAGELIB_IMAGETARGA
#define IMAGELIB_IMAGETARGA

#include "ifile.hpp"
#include "ibip.hpp"
#include "ierror.hpp"


class ImageTarga : public ImageBIP	
{
	
	public:
	
	ImageTarga() {};
	~ImageTarga() {};
	

	struct file_header
		{
		char  ID_Length;					
		char  Colour_Map_Type;
		char  Image_Type;	
    	short ColourMap_FirstEntry;		
    	short ColourMap_Length;
    	char  ColourMap_Size;
    	short XOrigin;
    	short YOrigin;
    	short Width;
    	short Height;
    	char  PixelDepth;
    	char  ImageDescriptor;
    	};

    struct file_footer
    	{
    	long	extension_offset;
    	long	developer_offset;
    	char 	sig[16];
    	};
    
    enum targa_dataformats
    	{
         COLOUR_MAPPED = 1,			// colour mapped images		
         TRUE_COLOUR = 2,           // 16/24/32 bit true colour images
         BLACK_N_WHITE = 3,         // unmapped black and white image
         COLOUR_MAPPED_RLE = 9,     // run length encoded images
         TRUE_COLOUR_RLE = 10,
         BLACK_N_WHITE_RLE = 11
         };	
    
    enum orign
    	{
        TOP_LEFT	= ( 1 << 5 ), 		
        TOP_RIGHT	= ( 1 << 5 ) | ( 1 << 4 ),
        BOTTOM_LEFT	= ( 1 << 4 ),
        BOTTOM_RIGHT = 0 
        }; 
    

	BOOL open(const char* filename );
	static BOOL isTarga( ImageFile& file, ImageInfo& info ); 

};

#endif	// IMAGELIB_IMAGETARGA


