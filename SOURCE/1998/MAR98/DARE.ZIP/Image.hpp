//	File: image.hpp
//	Description: Image based class for reading and writing images 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//

#ifndef IMAGELIB_IMAGE
#define IMAGELIB_IMAGE

#include "isystem.hpp"
#include "itarga.hpp"

// declare a wrapper class to define an image
class Image : public ImageTarga
{
 public:
	// copy constructor
	Image( const Image& image) { };
	Image( ) { }; // default constructor

};	// end image
 
#endif // end if IMAGELIB_IMAGE
