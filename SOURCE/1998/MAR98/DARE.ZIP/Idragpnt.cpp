//      File: idragpnt.cpp
//      Description: drag able point for control class 
//
//      Author: C Dare-Edwards
//      
//      Copyright Conrad Dare-Edwards   1997
//


#include "stdafx.h"
#include "idragpnt.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define BLACK ((COLORREF)RGB(0,0,0))
#define WHITE ((COLORREF)RGB(255,255,255))
#define WIDTH 5
#define HEIGHT 5
#define hit_radius 15

//////////////////////////////////////////////////////
ImageDragPoint::ImageDragPoint( const CPoint& point, BOOL no_scroll, BOOL no_delete )
: CPoint( point )
{
   disabled_delete = no_delete;
   disabled_scroll = no_scroll;
   selected = FALSE;
   has_moved = FALSE;	
}
///////////////////////////////////////////////////////////////////////////////
ImageDragPoint::ImageDragPoint( BOOL no_scroll, BOOL no_delete )
{
   disabled_delete = no_delete;
   disabled_scroll = no_scroll;
   selected = FALSE;
   has_moved = FALSE;	
}

//////////////////////////////////////////////////////
ImageDragPoint::ImageDragPoint( void )
{
   disabled_delete = FALSE;
   disabled_scroll = FALSE;
   selected = FALSE;
   has_moved = FALSE;	
}

//////////////////////////////////////////////////////
ImageDragPoint::ImageDragPoint( const ImageDragPoint& point )
: CPoint( point )
{
   if( point.CanDelete() ) disabled_delete = FALSE;
   else disabled_delete = TRUE;

   if( point.FullScroll() ) disabled_scroll = FALSE;
   else disabled_scroll = TRUE;

   selected  = point.IsSelected();
   has_moved = point.HasMoved();	
   m_original = point.getOriginalPnt();
}

//////////////////////////////////////////////////////
ImageDragPoint& ImageDragPoint::operator=( const ImageDragPoint& point)
{
   if( point.CanDelete() ) disabled_delete = FALSE;
   else disabled_delete = TRUE;

   if( point.FullScroll() ) disabled_scroll = FALSE;
   else disabled_scroll = TRUE;

   selected  = point.IsSelected();
   has_moved = point.HasMoved();	
   m_original = point.getOriginalPnt();

   x= point.x;
   y= point.y;
   
   return( *this );
}

//////////////////////////////////////////////////////
ImageDragPoint::~ImageDragPoint( void )
{

}

//////////////////////////////////////////////////////
void
ImageDragPoint::MoveBy(const CRect& area, int x, int y )
{
	CPoint point( *this );
	
	if( !disabled_scroll ) point.x += x;
	point.y += y;
	if( area.PtInRect( point ) )  // test if we are within bounds
	{       
		x = point.x;  // copy point 
		y = point.y;
	}
	
	has_moved = TRUE;
} 
//////////////////////////////////////////////////////
BOOL
ImageDragPoint::HitTest( const CPoint& point )
{
     CSize dist     = point - *this;
     if( abs(dist.cx) < hit_radius && abs(dist.cy) < hit_radius )
     	  return( TRUE  ); // a hit 
	 else return( FALSE );
} 

//////////////////////////////////////////////////////
void
ImageDragPoint::MoveTo( const CPoint& point )
{
	if( FullScroll() )  x = point.x;
	y = point.y;            

	has_moved = TRUE;
}

//////////////////////////////////////////////////////
void 
ImageDragPoint::Draw( CDC* pDC )
{
     CRect rect( x -  WIDTH,  y  -  HEIGHT, x+ WIDTH, y + HEIGHT);
     
     if( IsSelected() ) // highlighted draw
     {
	CBrush fillbrush( BLACK ); 
	pDC->FillRect( rect, &fillbrush );
     }
     else // default draw
     {
	CBrush fillbrush( WHITE ); 
	pDC->FillRect( rect, &fillbrush );
	pDC->Rectangle( rect );
     }
}

