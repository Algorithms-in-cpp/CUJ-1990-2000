//	File: ipoint.hpp
//	Description: image point routines 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//


#ifndef	IMAGELIB_IMAGEPOINT
#define IMAGELIB_IMAGEPOINT

#include "isystem.hpp"
#include <math.h>

class ImagePoint
{
	public:
	int x, y;          
	
	ImagePoint( void );
	ImagePoint( const int mx, const int my);
	ImagePoint( const ImagePoint& point );

	ImagePoint& Copy( const ImagePoint& point );	 // old version use =
	ImagePoint& operator=( const ImagePoint& copy );  // copy point
	
	const int& getX( void )const;		 // constant get value
	           int& getX( void );			 // non constant verion

	const int& getY( void )const;		 // constant get value
	           int& getY( void );			 // non constant version
	
}; 

BOOL inline operator==( const ImagePoint& first, const ImagePoint& second)
{
 	return(( first.getX() == second.getX() && first.getY() == second.getY() ) ? TRUE: FALSE );
}

BOOL inline operator!=( const ImagePoint& first, const ImagePoint& second)
{
 	return(( first.getX() != second.getX() || first.getY() != second.getY() ) ? TRUE: FALSE );
}

// inline functions
inline
ImagePoint::ImagePoint( void ) 
	{ 
		x =0; 				 // set both to 0
		y =0; 
	}

inline
ImagePoint::ImagePoint( const int mx, const int my) 
	{ 
		x = mx; 			 // set intital values
		y = my; 
	}

inline
ImagePoint::ImagePoint( const ImagePoint& point ) 
	{ 
		x = point.x; 		// copy values
		y = point.y; 
	}


// old version user = now
inline ImagePoint& 
ImagePoint::Copy( const ImagePoint& point ) 
	{ 
		x = point.x; 		 // copy point
		y = point.y; 
		return( *this );
	}


inline ImagePoint& 
ImagePoint::operator=( const ImagePoint& copy )
	{ 
		x = copy.x; 		 // copy point
		y = copy.y; 
		return( *this );
	}

	
inline const int& 
ImagePoint::getX( void )const 
	{ 
	return( x ); 
	}

inline int& 
ImagePoint::getX( void ) 
	{
	return( x ); 
	}

inline const int& 
ImagePoint::getY( void )const 
	{
	return( y ); 
	}

inline int& 
ImagePoint::getY( void ) 
	{
	return( y ); 
	}

#endif	// IMAGELIB_IMAGEPOINT
