//	File: igraph.hpp
//	Description: plot histograms and lut tables on an CDC object 
//
//	Author: C Dare-Edwards
//	
//	
//  Copyright Conrad Dare-Edwards 1997  
//

#include "stdafx.h"
#include "igraph.hpp"


//////////////////////////////////////////////////////////////
//	clean up
ImageGraph::~ImageGraph()
{
 	// nothing to do 
}

// erase to single colour
void
ImageGraph::ClearPlot(CDC* pDC, COLORREF colour )
{
    CBrush back_brush(colour);
	int width  = area.right - Origin.x;
    int height = Origin.y   - area.top;
    CRect rect( Origin.x, Origin.y - height, Origin.x + width, Origin.y );

    pDC->FillRect( rect , &back_brush ); 
}



/////////////////////////////////////////////////////////////////
// 	Intialise the graphing functions
ImageGraph::ImageGraph( CDC* pDC, CRect& plotarea, long xrange, long yrange, char* text_size ): area( plotarea )
{
	XRange = xrange;  	
	YRange = yrange;

    // compute the offset of the origin
	CString String("XXXX");
    if( text_size != NULL ) String = text_size;
	
  	StringSize = pDC->GetTextExtent( (const char*)String ,String.GetLength() );
    
	// ajust area  with itital margin
	area.top    += StringSize.cy;
    area.bottom -= StringSize.cy;
    area.right  -= StringSize.cy;
    area.left   += StringSize.cy;

    // set the origin 
    Origin.y = area.bottom - StringSize.cy;
    Origin.x = area.left   + StringSize.cx;
    
    int width  = area.right - Origin.x +1;
    int height = Origin.y   - area.top +1;
    
	// compute some Scaleing factors for this range

    XScaleFactor = (double)XRange / (double)width;
    YScaleFactor = (double)YRange / (double)height;
	
	// setup default colours 
	plot_colour =  (COLORREF)RGB(0,0,128);
    scale_colour = (COLORREF)RGB(255,0,0);
	bar_colour  =  (COLORREF)RGB(128,128,128);
}

/////////////////////////////////////////////////////////////////
// 	Intialise the graphing functions to exact area 
ImageGraph::ImageGraph( CRect& plotarea, long xrange, long yrange, char* text_size ): area( plotarea )
{
  	CDC dc;
  	if( dc.CreateCompatibleDC( NULL ) )
	{
    // compute the offset of the origin
		CString String("XXXX");
		if( text_size != NULL ) String = text_size;
  		StringSize = dc.GetTextExtent( (const char*)String ,String.GetLength() );
		dc.DeleteDC(); // and delete dc
	}
	else
	{
	 	StringSize.cx =10;	// default
	 	StringSize.cy =10;
	}

	XRange = xrange;  	
	YRange = yrange;

    // set the origin 
    Origin.y = area.bottom;
    Origin.x = area.left;
    
    int width  = area.right - Origin.x +1;
    int height = Origin.y   - area.top +1;
    
	// compute some Scaleing factors for this range

    XScaleFactor = (double)XRange / (double)width;
    YScaleFactor = (double)YRange / (double)height;
	
	// setup default colours 
	plot_colour =  (COLORREF)RGB(0,0,128);
    scale_colour = (COLORREF)RGB(255,0,0);
	bar_colour  =  (COLORREF)RGB(128,128,128);
}

///////////////////////////////////////////////////////////////////
//
//	Draw scales both x and y on the edge of the plot area
void
ImageGraph::DrawScale( CDC* pDC )
{
   ///////////////////////////////////////////////////////////////
   // intialise width and height
   int width  = area.right - Origin.x +1;
   int height = Origin.y   - area.top +1;
   
   ///////////////////////////////////////////////////////////////
   // setup and select a new pen colour	 - yes green
   CPen* ScalePen = new CPen( PS_SOLID, 0, scale_colour ); 
   CPen* OldPen   = pDC->SelectObject( ScalePen );

   /////////////////////////////////////////////////////////////
   // test computed width and height
   if( width < 1 || height < 1 ) return;	// error plot area to small
    
   
   /////////////////////////////////////////////////////////////
   // draw x scale
  
   pDC->SetTextAlign( TA_TOP | TA_CENTER );  // set text postioining

   int xlabels = width / (StringSize.cx ); 
   if( xlabels < 1 ) xlabels = 1;
   if( xlabels > XRange ) xlabels = XRange;
   double xstep = ((double)XRange / (double)xlabels); 
  
    ///////////////////////////////////////////////////////////// 
    // draw in xlabels and vertical bars
    for(int x = 0; x <= xlabels; x++ )
    {
    	long value = (long) ((double)xstep *(double) x);
     	int position = XUnitToPlot( value ); 	    
        
		if( x == 0 ) position--;

        pDC->MoveTo( Origin.x +position, Origin.y + MARKER_LENGTH);
		pDC->LineTo( Origin.x +position, Origin.y - height );
        
		CString text;
        if( XScaleToString( text, value) )
		pDC->TextOut(Origin.x +position, Origin.y + MARKER_LENGTH + 1 , text);
    }
        
    //////////////////////////////////////////////////
	// draw y scale
    
    pDC->SetTextAlign( TA_RIGHT | TA_BASELINE );  

 	int ylabels = height / (StringSize.cy *2); 
    if( ylabels < 1 ) ylabels = 1;
    if( ylabels > YRange ) ylabels = YRange;
  	double ystep = ((double)YRange / (double)ylabels); 
    
    ////////////////////////////////////////////////////////////////
    // draw in ylabels and horizontal bars
    for( x = 0; x < (ylabels+1); x++ )
    {
    	long value =  (long)((double)ystep * (double) x);
    	int position = YUnitToPlot( value ); 	    
        
		if( x == 0 ) position--;

        pDC->MoveTo( Origin.x - MARKER_LENGTH, Origin.y - position);
		pDC->LineTo( Origin.x + width        , Origin.y - position);
        
		CString text;
        if( YScaleToString( text, value) )
		pDC->TextOut(Origin.x - MARKER_LENGTH -1 , Origin.y -position, text);
    }
   
   //////////////////////////////////////////////////
   // reset colour pen
    pDC->SelectObject( OldPen );
   	delete ScalePen;
}   


////////////////////////////////////////////////////////////////////
//	plot a histogram as a bar graph in our plot area
void 
ImageGraph::DrawBar( CDC* pDC, int xvalue, int yvalue, BOOL xaxis )
{
	// coinvert postion
    if( xaxis )
	{
    	int xpos = XUnitToPlot( xvalue );
    	int ypos = YUnitToPlot( yvalue );
    
		// for width of bar draw bar
    	do { 
       		pDC->MoveTo( Origin.x+ xpos, Origin.y );
    		pDC->LineTo( Origin.x+ xpos, Origin.y - ypos);
    	} while ( xvalue == (int)(XScaleFactor *(double)++xpos));
	}
	else	// plot on the y axis
	{
    	int xpos = XUnitToPlot( yvalue );
    	int ypos = YUnitToPlot( xvalue );
    
		// for width of bar draw bar
    	do { 
       		pDC->MoveTo( Origin.x, Origin.y - ypos );
    		pDC->LineTo( Origin.x+ xpos, Origin.y - ypos);
    	} while ( yvalue == (int)(YScaleFactor *(double)--ypos));
	}
}

void 
ImageGraph::DrawPoint( CDC* pDC, int xvalue, int yvalue, COLORREF colour )
{
    int xpos = Origin.x + XUnitToPlot( xvalue );
    int ypos = Origin.y - YUnitToPlot( yvalue ); 

	int to_xpos = Origin.x + XUnitToPlot( xvalue + 1 );  
	int to_ypos = Origin.y - YUnitToPlot( yvalue + 1 );  
	
	// draw repeatedly across and down to cover full area of 
	do{
		int x = xpos;
		do{
		//	pDC->SetPixelV(x, ypos, colour );
			pDC->SetPixel(x, ypos, colour );
		}while( ++x < to_xpos ); 
	}while( ++ypos < to_ypos );

}

void 
ImageGraph::DrawMarker( CDC* pDC, int xvalue, int yvalue )
{
    int xpos = Origin.x + XUnitToPlot( xvalue );
    int ypos = Origin.y - YUnitToPlot( yvalue ); 
    
   	CRect rect( xpos - 4 , ypos -  4, xpos + 4, ypos + 4);
	pDC->Rectangle( rect );
}

////////////////////////////////////////////////////////
// convert a plot unit to a offset from the origin
int ImageGraph::XUnitToPlot( long xunit )
{ 
 	if( xunit > XRange ) xunit = XRange;
 	if( xunit < 0 ) xunit = 0;
	
 	return( (int) ((double)xunit / XScaleFactor) );
}

////////////////////////////////////////////////////////
// convert a plot unit to an offset from the origin 
int ImageGraph::YUnitToPlot( long yunit )
{ 
 	if( yunit > YRange ) yunit = YRange;				// stop overflow
 	if( yunit < 0 ) yunit = 0;

 	return( (int) ((double)yunit / YScaleFactor) );
}

/////////////////////////////////////////////////////////////////
//	plot line graph
void
ImageGraph::DrawLine( CDC* pDC, ImagePoint& from, ImagePoint& to, BOOL xaxis )
{
        CPoint cfrom;
		CPoint cto;
	   
	   if( xaxis )	// the default x scale
	   {
			cfrom.x = Origin.x + XUnitToPlot( from.x );
			cto.x   = Origin.x + XUnitToPlot( to.x );
    
    		cfrom.y = Origin.y - YUnitToPlot( from.y );
			cto.y   = Origin.y - YUnitToPlot( to.y );
       }
	   else	 // plot on the y axis
	   {
	 		cfrom.x = Origin.x + XUnitToPlot( from.y );
			cto.x   = Origin.x + XUnitToPlot( to.y );
    
    		cfrom.y = Origin.y - YUnitToPlot( from.x );
			cto.y   = Origin.y - YUnitToPlot( to.x );
     	}
        
        // draw it 
       	pDC->MoveTo( cfrom );
   		pDC->LineTo( cto );
}


////////////////////////////////////////////////////////////
// convert number to text string formated
BOOL
ImageGraph::XScaleToString( CString& string, long value )
{
	char buffer[20];
	value++;
	
	if( value > 1000 ) 
	{
		float number = ( float)(value/1000);
		sprintf(  buffer,"%.2fk", number );
	}
	else
	{
		sprintf(  buffer,"%d", value);
	}
	string = buffer;

	return TRUE;

}

BOOL
ImageGraph::YScaleToString( CString& string, long value )
{
	char buffer[20];

	if( value > 1000 ) 
	{
		float number = (float)(value / 1000);
		sprintf(  buffer,"%.2fk", number );
	}
	else
	{
		sprintf(  buffer,"%d", value);
	}
	string = buffer;

	return TRUE;
}
