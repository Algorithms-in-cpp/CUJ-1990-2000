//	File: ihist.hpp
//	Description: histogram class description 
//
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//



#ifndef IMAGELIB_HISTOGRAM
#define IMAGELIB_HISTOGRAM

#include "istat.hpp"
#include "ilut.hpp"
#include "image.hpp"
#include "iarea.hpp"

#include <memory.h> // for memset

class ImageHist : public ImageHistStat 
{
   public:
   
   enum HistType
   {
    HIST_NOADD,
    HIST_ADD 
   };

    ImageHist( void );                               // default constructor
    ImageHist( const ImageHist& ihist );                   // copy constructor
    ImageHist( unsigned long* histogram, int nopoints );      // pre initilised
    
    ~ImageHist( void );
	
	void Copy( const ImageHist& ihist );
	ImageHist& operator=( const ImageHist& ihist );

    // collect image stats 
    BOOL histogram( Image* rimage, int band, HistType flags = HIST_NOADD );
	BOOL histogram( Image* rimage, int band, ImageArea* area, HistType flags = HIST_NOADD);
	BOOL histogram( unsigned char* buffer, int length, HistType flags = HIST_ADD);
	
	void Convert( const ImageLut& lut );
	void Clear( void );

	unsigned int getRange( void ) const;  	                  // get stats of histogram	
	unsigned long getFrequency( unsigned int value ) const;    // get values from histogram
    
	ImageLut* Sort( void ) const;

    private:
	const unsigned int range;		// number of points in the histogram
	unsigned long hist[256];    // histogram
};

///////////////////////////////////////////////////////////////
// inline functions

// old compatiblitity
inline void
ImageHist::Copy( const ImageHist& ihist ) 
{
	*this = ihist;
}

inline ImageHist&
ImageHist::operator=( const ImageHist& ihist ) 
{
	IASSERT(  range == ihist.getRange() );
	int i = (int)range;

	// copy data across
	while( i-- )	hist[i] = ihist.getFrequency( i );

	return( *this );
}

inline void
ImageHist::Clear( void )
{
	memset( hist, 0, sizeof( long ) * range);
}

inline BOOL 
ImageHist::histogram( unsigned char* buffer, int length, HistType flags)
{
   if( flags == HIST_NOADD) Clear();
   while( length-- ) hist[*buffer++]++; // histogram it
   return( TRUE );
}

#endif // IMAGELIB_HISTOGRAM
