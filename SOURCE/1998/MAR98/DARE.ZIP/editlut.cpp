// editlut.cpp : implementation file
//

#include "stdafx.h"
#include "Display.h"

#include "DsplyDoc.h"
#include "editlut.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// EditLut

IMPLEMENT_DYNCREATE(EditLut, CFormView)	

EditLut::EditLut()
	: CFormView(EditLut::IDD)
{
	//{{AFX_DATA_INIT(EditLut)
	m_editcol = 0;
	m_xval = 0;
	m_yval = 0;
	//}}AFX_DATA_INIT

	//back_brush.CreateSolidBrush( BACKGROUND_COLOUR );

}

EditLut::~EditLut()
{
	if( m_linecontrol ) delete m_linecontrol;
}

void EditLut::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(EditLut)
	DDX_CBIndex(pDX, IDC_EDLUT_COL, m_editcol);
	DDX_Text(pDX, IDC_EDLUT_XVAL, m_xval);
	DDV_MinMaxUInt(pDX, m_xval, 0, 255);
	DDX_Text(pDX, IDC_EDLUT_YVAL, m_yval);
	DDV_MinMaxUInt(pDX, m_yval, 0, 255);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(EditLut, CFormView)
	//{{AFX_MSG_MAP(EditLut)
	ON_BN_CLICKED(IDC_EDLUT_UPDATE, OnEdlutUpdate)
	ON_CBN_SELCHANGE(IDC_EDLUT_COL, OnSelchangeEdlutCol)
	ON_BN_CLICKED(IDC_EDLUT_DELETE, OnEdlutDelete)
	ON_BN_CLICKED(IDC_EDLUT_NEXT, OnEdlutNext)
	ON_BN_CLICKED(IDC_EDLUT_PREV, OnEdlutPrev)
	ON_EN_KILLFOCUS(IDC_EDLUT_XVAL, OnKillfocusEdlutXval)
	ON_EN_CHANGE(IDC_EDLUT_XVAL, OnChangeEdlutXval)
	ON_EN_CHANGE(IDC_EDLUT_YVAL, OnChangeEdlutYval)
	ON_WM_KEYDOWN()
	ON_WM_CTLCOLOR()
	ON_EN_KILLFOCUS(IDC_EDLUT_YVAL, OnKillfocusEdlutXval)
	ON_BN_CLICKED(IDC_LBUT_DEFAULT, OnLbutDefault)
	ON_BN_CLICKED(IDC_LBUT_EQUAL, OnLbutEqual)
	ON_BN_CLICKED(IDC_LBUT_EXP, OnLbutExp)
	ON_BN_CLICKED(IDC_LBUT_INVERT, OnLbutInvert)
	ON_BN_CLICKED(IDC_LBUT_LOG, OnLbutLog)
	ON_BN_CLICKED(IDC_LBUT_MINMAX, OnLbutMinmax)
	ON_BN_CLICKED(IDC_LBUT_OPTO, OnLbutOpto)
	ON_BN_CLICKED(IDC_LBUT_UNDO, OnLbutUndo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

HBRUSH EditLut::OnCtlColor( CDC* pDC, CWnd* pWnd, UINT nCtlColor )
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}


/////////////////////////////////////////////////////////////////////////////
// EditLut diagnostics

#ifdef _DEBUG
void EditLut::AssertValid() const
{
	CFormView::AssertValid();
}

void EditLut::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// EditLut message handlers

void EditLut::OnInitialUpdate() 
{
	// TODO: Add your specialized code here and/or call the base class
	CFormView::OnInitialUpdate();
	CDisplayDoc* doc = GetDocument();
	
	m_edit_xval.SubclassEdit(IDC_EDLUT_XVAL, this, PES_NUMBERS);
	m_edit_yval.SubclassEdit(IDC_EDLUT_YVAL, this, PES_NUMBERS);

	m_linecontrol = new LineControl(IDC_EDLUT_LUT  ,this);
	
	///////////////////// add grey scale channel control
 	CString	Greystring;
 	Greystring.LoadString( IDS_GREYCHANNEL );
 	((CComboBox*) GetDlgItem( IDC_EDLUT_COL ))->AddString( Greystring );

	////////////////// intialise luts
	if( doc->isPseudoCol() )
	{
		m_editcol = 0; // red band
		SetColourMode( TRUE );
	}
	else
	{
    	m_editcol = 3; // grey band
	    ((CComboBox*) GetDlgItem( IDC_EDLUT_COL ))->SetCurSel( 3 );
		SetColourMode( FALSE );
	}

	Update();
	
	GetParent()->SetWindowText( doc->GetTitle() + ": Edit Lut" );
	CScrollView::ResizeParentToFit();
}


void EditLut::SetColourMode( BOOL flag )
{
 CDisplayDoc* doc = GetDocument();

 if( flag )	 // set internal luts to RGB
 {
		col_mode = 1;  // change into colour mode
	    // change edit colour if greyscale selected
	    if( m_editcol >= 3 )  m_editcol =0;

		m_luts[0] = (doc->getBitmap())->GetBandLut(0);
		m_luts[1] = (doc->getBitmap())->GetBandLut(1);
		m_luts[2] = (doc->getBitmap())->GetBandLut(2);
 }
 else		// set internal luts to grey scale
 {
 		col_mode = 0;	// change into grey scale mode
	    m_editcol= 3;	// changed edit colour to greyscale

		m_luts[0] = (doc->getBitmap())->GetBandLut(3);
		m_luts[1] = (doc->getBitmap())->GetBandLut(3);
		m_luts[2] = (doc->getBitmap())->GetBandLut(3);
 }

 // set colour selection box to look at correct band
 CComboBox* colourbox = ((CComboBox*) GetDlgItem( IDC_EDLUT_COL ));
 if( colourbox )	colourbox->SetCurSel( m_editcol );

}


void EditLut::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class
   
	if(lHint == UPDATE_BITMAP )
	{
		CDisplayDoc* doc = GetDocument();

		SetColourMode( !doc->isGreyScale() );  // reload lookup tables
		Update();							  // reload controls
	}
}


// bitmap changed reload and update controls
void EditLut::Update() 
{
	if( m_linecontrol->isOpen() ) // is line control
	{
		m_linecontrol->OnUpdate( GetCurrentLut() );
		m_linecontrol->OnUpdate( GetCurrentHist() );
	}
}

/////////////////////////////////////////////////////////
// update image with new lookup tables
void EditLut::OnEdlutUpdate() 
{
	// TODO: Add your control notification handler code here
	CDisplayDoc* doc = GetDocument();
   	m_luts[ GetColour() ]=  m_linecontrol->GetUpdate();
	
	if( GetColourMode() ) 		 // colour rgb update
	{
		(doc->getBitmap())->UpdateLut(m_luts[0], 0);
		(doc->getBitmap())->UpdateLut(m_luts[1], 1);
		(doc->getBitmap())->UpdateLut(m_luts[2], 2);
		doc->SetColourMode( CDisplayDoc::PSEUDOCOL );

	}        
	else //greyscale
	{
		(doc->getBitmap())->UpdateLut(m_luts[0], 3);
		doc->SetColourMode( CDisplayDoc::GREYSCALE );
	}
		
	doc->UpdateBitmap();
}

// get current histogram with different modes
const ImageHist& EditLut::GetCurrentHist( void )
{
	CDisplayDoc* doc = GetDocument();
	return doc->getHist();
}

// get correct lookup tables 
const ImagePointLut& EditLut::GetCurrentLut( void ) const
{
	return( m_luts[ GetColour() ] );
}

// get colour number or lut number 0 to 2
int 
EditLut::GetColour( void ) const
{
	if( GetColourMode() ) return m_editcol ;
	else return 0;	  // red defualt
}

// are we in colour mode yes or no
BOOL 
EditLut::GetColourMode( void ) const
{
	return( col_mode );
}


// colour band has changed
void EditLut::OnSelchangeEdlutCol() 
{
	// TODO: Add your control notification handler code here
	int selection = ((CComboBox*) GetDlgItem( IDC_EDLUT_COL ))->GetCurSel();
	
	// if a valid selection
	if( selection >= 0 && selection <= 3 )
	{
		// update any changes
	   	if(GetColourMode()) m_luts[ GetColour() ] = m_linecontrol->GetUpdate();

		// if select greyscale and in colour mode change colour mode
		if( selection == 3  && col_mode == 1) SetColourMode( FALSE );
		else col_mode = 1;	 // else colour mode in on
			
		// change band or colour mode
		m_editcol = selection;	 // colour band
		
		// and load new lut into editor
		Update();
	}
	
	
}

// delete button
void EditLut::OnEdlutDelete() 
{
	// TODO: Add your control notification handler code here
	m_linecontrol->DeleteItem();
}

// on help button
void EditLut::OnEDLUTHelp() 
{
	// TODO: Add your control notification handler code here
	WinHelp(0L);   // jump to our win help id
}

// on next >> button
void EditLut::OnEdlutNext() 
{
	// TODO: Add your control notification handler code here
	m_linecontrol->GetNextItem();
}

// on prev ious button <<
void EditLut::OnEdlutPrev() 
{
	// TODO: Add your control notification handler code here
	m_linecontrol->GetPrevItem();
}

// on foucus changed update point values
void EditLut::OnKillfocusEdlutXval() 
{
	// TODO: Add your control notification handler code here
	if( m_edit_xval.GetModify() || m_edit_yval.GetModify()  )
	{
		ImagePoint point;	

		point.x = GetDlgItemInt( IDC_EDLUT_XVAL); 
		point.y = GetDlgItemInt( IDC_EDLUT_YVAL); 
	
		if( point.x < 0 ) point.x = 0;
		if( point.x > 255 ) point.x = 255;
		if( point.y < 0 ) point.x = 0;
		if( point.y > 255 ) point.x = 255;
	
		m_linecontrol->MoveItem( point );
	
		m_edit_xval.SetModify( FALSE );
		m_edit_yval.SetModify( FALSE );
	}
	
}

void EditLut::OnKillfocusEdlutYval() 
{
	OnKillfocusEdlutXval();	
}

void EditLut::OnChangeEdlutXval() 
{
	// TODO: Add your control notification handler code here
	
}

void EditLut::OnChangeEdlutYval() 
{
	// TODO: Add your control notification handler code here
	
}

void EditLut::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	CFormView::OnKeyDown(nChar, nRepCnt, nFlags);
}

BOOL EditLut::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if( pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN )
	{
		OnKillfocusEdlutXval();	
	}
	
	return CFormView::PreTranslateMessage(pMsg);
}

// f1 help key 
void EditLut::WinHelp(DWORD dwData, UINT nCmd) 
{
	// TODO: Add your specialized code here and/or call the base class
	CWinApp* pApp;
	if( (pApp =AfxGetApp()) != NULL  ) pApp->WinHelp( 0 ); 

	//CFormView::WinHelp(dwData, nCmd);
}

void EditLut::OnLbutDefault() 
{
	// TODO: Add your control notification handler code here
	CDisplayDoc* doc = GetDocument();
	
	int luttype = 0; 
	if( doc->isPseudoCol() ) luttype = m_editcol;

	ImagePointLut lut = GetCurrentLut();
	lut.SetMinToMax( 0,255, (ImagePointLut::colour)luttype );

	m_luts[ GetColour() ] = lut;
	Update();
}

void EditLut::OnLbutEqual() 
{
	// TODO: Add your control notification handler code here
	ImagePointLut lut = GetCurrentLut();
	lut.Equalise( GetCurrentHist() );

	m_luts[ GetColour() ] = lut;
	Update();
}

void EditLut::OnLbutExp() 
{
	// TODO: Add your control notification handler code here
	ImagePointLut lut = GetCurrentLut();
	lut.SetExp( GetCurrentHist() );

	m_luts[ GetColour() ] = lut;
	Update();
}

void EditLut::OnLbutInvert() 
{
	// TODO: Add your control notification handler code here
	ImagePointLut lut = m_linecontrol->GetUpdate(); 
	lut.Invert();

	m_luts[ GetColour() ] = lut;
	Update();
}

void EditLut::OnLbutLog() 
{
	// TODO: Add your control notification handler code here
	ImagePointLut lut = GetCurrentLut();
	lut.SetLog( GetCurrentHist() );

	m_luts[ GetColour() ] = lut;
	Update();
	
}

void EditLut::OnLbutMinmax() 
{
	// TODO: Add your control notification handler code here
	CDisplayDoc* doc = GetDocument();
	
	///////////////////////// check for special psueudo col modes
	int luttype = 0; 
	if( doc->isPseudoCol() ) luttype = m_editcol;

	ImagePointLut lut = GetCurrentLut();
	lut.SetMinToMax( GetCurrentHist(), (ImagePointLut::colour)luttype );

	m_luts[ GetColour() ] = lut;
	Update();

}

void EditLut::OnLbutOpto() 
{
	// TODO: Add your control notification handler code here
	CDisplayDoc* doc = GetDocument();
	
	///////////////////////// check for special psueudo col modes
	int luttype = 0; 
	if( doc->isPseudoCol() ) luttype = m_editcol;

	ImagePointLut lut = GetCurrentLut();
	lut.Optimise( GetCurrentHist(), (ImagePointLut::colour)luttype );

	m_luts[ GetColour() ] = lut;
	Update();

}

void EditLut::OnLbutUndo() 
{
	// TODO: Add your control notification handler code here
	SetColourMode( col_mode );
	Update();
}
