//	File: ihistplt.hpp
//	Description: plot histograms and luts on a CDC object 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards   1997
//

#include "stdafx.h"

#ifndef IMAGELIB_IMAGEHISTPLOT
#define IMAGELIB_IMAGEHISTPLOT


#include "ihist.hpp"
#include "iplut.hpp"
#include "ipoint.hpp"
#include "igraph.hpp"


class ImageHistPlot: public ImageGraph
	{
	 public:

	 // intialise restangle and internal varibles	 
	 ImageHistPlot ( CDC* pDC, CRect& plotarea );
	 ImageHistPlot ( CRect& plotarea );
	 ~ImageHistPlot( void );
	 	 
	 // actual plotting routine
	 void PlotBarGraph     ( CDC* pDC, const ImageHist& histogram, COLORREF colour = PLOT_GREY, BOOL xaxis = TRUE );

	 // setscaleing functions
	 void SetScaleing( float percent ) { scaleing_percent = percent; };
	 void SetScaleing( const ImageHist& histogram );	// auto scaleing
	 void YPlotPercent( BOOL plt_per) { plot_percent = plt_per; };

	 // conversion routines
	 float ComputeScaleingFactor( const ImageHist& histogram );
	 
	 virtual BOOL YScaleToString( CString& string, long value );
	 virtual BOOL XScaleToString( CString& string, long value );

	 private:
	 float scaleing_percent;
	 BOOL plot_percent;
};   


/////////////////////// over ride x and y scale functions
class ImageLutPlot: public ImageHistPlot
{
	 public:
	 
	 ImageLutPlot( CRect& plotarea );

	 virtual BOOL YScaleToString( CString& string, long value ){ return FALSE ; };
	 virtual BOOL XScaleToString( CString& string, long value ){ return FALSE ; };
};

#endif	// IMAGELIB_IMAGEHISTPLOT
