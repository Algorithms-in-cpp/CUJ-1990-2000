// DisplayView.cpp : implementation of the CDisplayView class
//

#include "stdafx.h"
#include "Display.h"

#include "DsplyDoc.h"
#include "DplyView.h"

#include "image.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDisplayView

IMPLEMENT_DYNCREATE(CDisplayView, CScrollView)

BEGIN_MESSAGE_MAP(CDisplayView, CScrollView)
	//{{AFX_MSG_MAP(CDisplayView)
	ON_MESSAGE(WM_DOREALIZE, OnDoRealize)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDisplayView construction/destruction

CDisplayView::CDisplayView()
{
}

CDisplayView::~CDisplayView()
{
}

BOOL CDisplayView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDisplayView drawing

void CDisplayView::OnDraw(CDC* pDC)
{
	CDisplayDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	 // get a copy of the bitmap pointer
	 ImagePsColourDib* bitmap = pDoc->getBitmap();
	 
	 if( bitmap == NULL ) // bomb out if no bitmap
		{  ASSERT( bitmap ); return; }	

	// get size of bitmap
	CSize sizeTotal;

	sizeTotal.cx  = ((ImageDib*)bitmap)->getWidth();
	sizeTotal.cy  = ((ImageDib*)bitmap)->getHeight();
	

	// default full dc
	CRect rcDest(CPoint(0,0), sizeTotal);	   // full dc
	CRect rcDIB;	// dib area

	// setup dib area 
	rcDIB.top =  0;	
	rcDIB.left = 0;
	rcDIB.right = (int) bitmap->getWidth();    // Size of DIB - x
	rcDIB.bottom = (int) bitmap->getHeight();  // Size of DIB - y
	
	// if printer dc resize and centre dib area	
	if (pDC->IsPrinting())   // printer DC
	{
		Image* image=  pDoc->getImage();
		
		if( image == NULL )
			{  ASSERT( bitmap ); return; }	
		
		int width = image->getWidth();
		int height = image->getHeight();
		
		// get size of printer page (in pixels)
		int cxPage = pDC->GetDeviceCaps(HORZRES);
		int cyPage = pDC->GetDeviceCaps(VERTRES);
		
		// get printer pixels per inch
		double cxInch = pDC->GetDeviceCaps(LOGPIXELSX);
		double cyInch = pDC->GetDeviceCaps(LOGPIXELSY);

		// defualt 0 position
		rcDest.top  = 0;
		rcDest.left = 0;
		
		// adjust height for aspect ratio
		height = (int)(((double)height) * (cxInch / cyInch));
		//width  = (int)(((double)width ) * (cyInch / cxPage));

		double width_ratio  = cxPage / width;
		double height_ratio = cyPage / height;

		// scale width and height to fit page
		if( width_ratio < height_ratio )
		{	// width is the bounding side so scale to fit that
			rcDest.bottom = (int)(width_ratio * (double)height);
			rcDest.right  = (int)(width_ratio * (double)width);
		}
		else
		{	// height is the bounding side so scale to fit that
			rcDest.bottom = (int)(height_ratio * (double)height);
			rcDest.right  = (int)(height_ratio * (double)width);
		}
		
		// now centre output area on the page
		if( rcDest.bottom <	cyPage ) // centre vericaly in page
		{
		 	int bottom = rcDest.bottom;
			rcDest.top = (cyPage/2) - (bottom/2);
		 	rcDest.bottom = rcDest.top + bottom;
		}

		if( rcDest.left <	cxPage ) // centre horozontaly in page
		{
		 	int right = rcDest.right;
			rcDest.left = (cxPage/2) - (right /2);
		 	rcDest.right = rcDest.left + right;
		}


	}
		
	// and paint it
	bitmap->Stretch( pDC, rcDest, rcDIB );
}

/////////////////////////////////////////////////////////////////////////////
// CDisplayView printing

BOOL CDisplayView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	pInfo->SetMaxPage( 1 );
	return DoPreparePrinting(pInfo);
}

void CDisplayView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CDisplayView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// CDisplayView diagnostics

#ifdef _DEBUG
void CDisplayView::AssertValid() const
{
	CView::AssertValid();
}

void CDisplayView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDisplayDoc* CDisplayView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDisplayDoc)));
	return (CDisplayDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDisplayView message handlers

void CDisplayView::OnInitialUpdate() 
{
	CScrollView::OnInitialUpdate();

	// get document
	CDisplayDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
   
	// get a copy of the bitmap pointer
	ImagePsColourDib* bitmap = pDoc->getBitmap();
	 
	if( bitmap == NULL ) // bomb out if no bitmap
		{  ASSERT( bitmap ); return; }	


	CSize sizeTotal;

	sizeTotal.cx  = ((ImageDib*)bitmap)->getWidth();
	sizeTotal.cy  = ((ImageDib*)bitmap)->getHeight();
	
	// set scrolling ranges
	SetScrollSizes(MM_TEXT, sizeTotal);

	// resize window
	if( !GetParent()->IsZoomed() ) 
		 ResizeParentToFit( );   // Default bShrinkOnly argument

	/// punch out palette to the newly open window
	OnDoRealize((WPARAM)m_hWnd, 1L );   // same as SendMessage(WM_DOREALIZE);
}

void CDisplayView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView) 
{
	// TODO: Add your specialized code here and/or call the base class
	CScrollView::OnActivateView(bActivate, pActivateView, pDeactiveView);

	// if we are getting control reset the palette
	if ( bActivate )
	{
		ASSERT(pActivateView == this);
		OnDoRealize((WPARAM)m_hWnd, 1L );   // same as SendMessage(WM_DOREALIZE);
	}
}


LRESULT 
CDisplayView::OnDoRealize(WPARAM wParam, LPARAM lParam)
{
	ASSERT(wParam != NULL);
	CDisplayDoc* pDoc = GetDocument();
    
    ASSERT_VALID( pDoc );
      
	// check that we are not the active window and its a palette changed message
	if( lParam == 0L && wParam == (WPARAM)m_hWnd ) return FALSE;

	// get bitmap and test pointer
	ImagePsColourDib* bitmap =  pDoc->getBitmap();
	if( bitmap == NULL ) return(FALSE);	// bomb out
    
	CClientDC* appDC = new CClientDC(this);	// create a dc for this view
	if( appDC == NULL )  return FALSE;

	BOOL FullRedraw = FALSE;	// we need to do a full redraw
	BOOL ActiveWnd = TRUE;		// we are the avtive window

	// lParam == 2L	 activate window imediate redraw
	// lParam == 1L	 palette changed ours to control  ONPALETTECHANGED
	// lParam == 0L update our window without changeing the palette QUERRYNEWPALETTE

	if( lParam == 2L ){	 FullRedraw = TRUE;	ActiveWnd = FALSE; }
	else if( lParam == 1L ) ActiveWnd = FALSE ;

	CPalette* oldPalette = appDC->SelectPalette(bitmap->GetPalette(), ActiveWnd );
	int i = appDC->RealizePalette();	  // apply my new palette
	
	if( FullRedraw ) 			// imediate redraw
	{
			Invalidate();	    // invalidate all 
			UpdateWindow();		// redraw all
	}
	else if( i ) Invalidate( );	   // else send a WM_PAINT message

	// re select old palette
	if (oldPalette != NULL ) appDC->SelectPalette(oldPalette, TRUE);
	
	delete appDC;
	return TRUE;
}

void CDisplayView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class
	if( lHint == UPDATE_BITMAP )
	{
		OnDoRealize((WPARAM)m_hWnd, 1L ); // change the palette
		Invalidate(); // repaint all
	}
	
}
