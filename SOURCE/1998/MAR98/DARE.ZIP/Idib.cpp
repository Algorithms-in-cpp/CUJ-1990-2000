//	File: idib.cpp
//	Description: windows device independant bitmp 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997

#include "stdafx.h"
#include "isystem.hpp"

#include <windowsx.h>   
#include <memory.h>	   // for memcpy functions

#include "idib.hpp"    

#ifdef _DEBUG         // debugging 
#define new DEBUG_NEW
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

///////////////////////////////////////////////////////////////////
// ImageDib( void );
// defualt constructor
// initialize varibles to NULL to avoid errors
ImageDib::ImageDib( void )
{
	// everything to NULL
    m_pBuffer    = NULL;
	m_palette = NULL;
    m_bits    = 0;
   	m_haspalette = FALSE;
   	m_palettechanged = FALSE;
    m_length = 0L;
}

////////////////////////////////////////////////////////////////////
// ImageDib( ImageDib& dib );
// copy constructor
// do nothing do not copy since this would cause pointer probs later 
ImageDib::ImageDib( ImageDib& dib )
{
	// everything to NULL
    m_pBuffer    = NULL;
	m_palette = NULL;
    m_bits    = 0;
   	m_haspalette = FALSE;
   	m_palettechanged = FALSE;
    m_length = 0L;
 
}

///////////////////////////////////////////////////////////////////
// ~ImageDib()
// Destructor delete allocated and palette memory
ImageDib::~ImageDib( void )
{
    if( m_palette ) delete m_palette;

    if ( m_pBuffer != NULL ) 
    {
        GlobalFreePtr(m_pBuffer);  // free the memory DIB
    }
}

///////////////////////////////////////////////////////////////////
// BOOL Create( int depth, int width, int height )
// depth - 8 or 24 bits per pixel
// width and height - width and heigth of bitmap in pixels
//  returns	- TRUE if all ok else FALSE
BOOL
ImageDib::CreateDib(int depth, int width, int height )
{
    // assert arguments are correct
	IASSERT( m_pBuffer == NULL );
    IASSERT( width > 0 );
	IASSERT( height > 0 );
    IASSERT( depth == 8 ); // currently fixed a 8

	m_bits = depth;

	//set intalize flags
   	m_haspalette = TRUE;
   	m_palettechanged = TRUE;
    m_paletteSize = 256;
    		  
    // length of row to 4 byte boundry
    unsigned long bytes = ((unsigned long) width * m_bits) / 32;
    
	// round up to next whole long
	if (((unsigned long) width * m_bits) % 32)
	{
        bytes ++;
    }
    bytes *= 4; // compute bytes
    m_lineLength = bytes;	// set length
    
    // total size of the image
    m_length = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) +
                 sizeof(RGBQUAD) * m_paletteSize;
    m_length += bytes * height; // + the size of the image
    
    // and allocate it
    if (Allocate() == FALSE )
    {
	 	IPOSTERROR( ERR_MEM_ALLOC ); 
		return( FALSE );
    }

	// setup header
	m_pBMData = (LPSTR) m_pBMInfoHeader + sizeof(BITMAPINFOHEADER) +
             sizeof(RGBQUAD) * m_paletteSize;

	m_pBMFileHeader->bfOffBits = (char *) m_pBMData - m_pBuffer;

    m_pBMInfoHeader->biSize        = sizeof(BITMAPINFOHEADER);
    m_pBMInfoHeader->biWidth       = width;
    m_pBMInfoHeader->biHeight      = height;
    m_pBMInfoHeader->biPlanes      = 1;
    m_pBMInfoHeader->biBitCount    = depth; 
    m_pBMInfoHeader->biCompression = BI_RGB;
	m_pBMFileHeader->bfType        = 0x4d42;
    m_pBMFileHeader->bfSize        = m_length;
    
	//and the rest to 0
	m_pBMFileHeader->bfReserved1   = 0;
    m_pBMFileHeader->bfReserved2   = 0;
    m_pBMInfoHeader->biSizeImage   = 0;
    m_pBMInfoHeader->biXPelsPerMeter = 0;
    m_pBMInfoHeader->biYPelsPerMeter = 0;
    m_pBMInfoHeader->biClrUsed       = 0;
    m_pBMInfoHeader->biClrImportant  = 0;
    
	return( TRUE ); //and return
}

//////////////////////////////////////////////////////////////////////
// BOOL SetBits( unsigned char buffer, int line, int numlines );
// paste buffer into image
// buffer length determined by  (GetWidth * GetColourBits) / 8
//
// unsigned char buffer - bufer of data to copy into image
// int line - line to copy buffer into    0 to GetHeight-1
// int numlines - number of lines in buffer  1 to n

BOOL 
ImageDib::SetBits( unsigned char* buffer, int line, int numlines )
{
 	if( m_pBuffer != NULL )
 	{
 	   if( ( line + numlines ) >  getHeight() )
 	   {
		    IASSERT(FALSE);
 	   		return( FALSE );
 	   }

   	   int width = (int)((getWidth()*getColourBits())/8L);  // only for 8 bit and 24 bit imagery
 	   line      = (int)getHeight() - (line+1);          // invert origin
        m_pdata = m_pBMData;
              
  	   while( numlines-- > 0 )
 	   {
 	    	unsigned long linepos = line - numlines;
 	    	memcpy( &m_pdata[ m_lineLength * linepos],
 	    				&buffer[ numlines* width ], width); 
 	   }
 		return( TRUE );
 	}	
    else
    {
 	   IASSERT(FALSE);
	  	return( FALSE );
    }
}

//////////////////////////////////////////////////////////////////////
// BOOL GetBits( unsigned char buffer, int width, int line, int numlines );
// copy image into buffer 
// buffer length determined by  (GetWidth * GetColourBits) / 8
//
// unsigned char buffer - bufer of data to image into
// int line - line to copy buffer into    0 to GetHeight-1
// int numlines - number of lines in buffer  1 to n

BOOL 
ImageDib::GetBits( unsigned char* buffer,  int line, int numlines )
{                                                  
 	if( m_pBuffer != NULL )
 	{
 	   if( ( line + numlines ) >  getHeight() )
 	   {
		   IASSERT(FALSE);
		   return( FALSE );
 	   }

   	   int width = ((int)getWidth() * getColourBits()) / 8;  // only for 8 bit and 24 bit imagery
 	   line = (int)getHeight() - (line + 1);                 // invert origin
    
	
 	   while( numlines-- > 0 )
 	   {
	 	   unsigned long linepos = (line-numlines);

		   memcpy(&buffer[ numlines* width ], 
 	    		   &m_pBMData[linepos * m_lineLength], width); 
 	   }
 		return( TRUE );
 
 	}	
    else
    {
 	    IASSERT(FALSE);
     	return( FALSE );
    }
}

/////////////////////////////////////////////////////////////////
// CPalette* GetPalette( void );
// return the current palette if it has changed create a new one
// returns cpalette* or NULL on error
// do store the palette pointer or delete it when finished
 
CPalette*
ImageDib::GetPalette( void )
{
   if( m_palettechanged || m_palette == NULL)
   {
		if( m_palette ) delete m_palette;
		m_palette = CreatePalette();
   }

   return( m_palette );		// don't delete this item 
}

///////////////////////////////////////////////////////////////////////////
// void SetPalette( int color, int red, int green, int blue)
// set colour of the palette at a position
//	colour = position 0 -255 at present
//  red, green and blue = colour components 0 - 255

void
ImageDib::SetPalette( int color, int red, int green, int blue)
{
    	if(m_pBuffer == NULL || color >= m_paletteSize || color < 0 )
    	{
   			IASSERT( FALSE );
			return;
       	}
    	
	   	m_palettechanged = TRUE;


		m_pBMInfo->bmiColors[color].rgbRed =(unsigned char)red;
		m_pBMInfo->bmiColors[color].rgbGreen =(unsigned char)green;
		m_pBMInfo->bmiColors[color].rgbBlue =(unsigned char)blue;
}

////////////////////////////////////////////////////////////////////////////
// void ClearPalette( void )
// clear all entries to black
void 
ImageDib::ClearPalette( void )
{
 	for( int x =0; x < getPaletteSize(); x ++ )
 	{
 	 	SetPalette( x, 0,0,0 );
 	}

   	m_palettechanged = TRUE;

}

///////////////////////////////////////////////////////////////////////////
// CPalette* CreatePalette ( void )
// create a palette from the entries created by set palette
// returns a cpalette*  

CPalette* 
ImageDib::CreatePalette ( void )
{
   CPalette *hPal;
   LPLOGPALETTE lpPal;
   
   if( m_pBuffer == NULL )
   {
		IASSERT( FALSE ); // invalid memory
	   return( NULL );
   }
   
   // allocate new palette object
   if(( hPal = new ( CPalette )) == NULL )
   {
	 	IPOSTERROR( ERR_MEM_ALLOC ); 
   		return( NULL );
   }
   
   // allocate a logpalette structure
   if(( lpPal = (LPLOGPALETTE) GlobalAllocPtr (GHND, sizeof (LOGPALETTE) +
                             sizeof (PALETTEENTRY) * m_paletteSize) ) == NULL )
   {
   	 	IPOSTERROR( ERR_MEM_ALLOC ); 
      	return( NULL );
   }
   
   // initialise palette 
   lpPal->palVersion    = 0x300;
   lpPal->palNumEntries = m_paletteSize;
            
   // copy colours across
   for (int i = 0;  i < m_paletteSize;  i++)
   {
    	lpPal->palPalEntry[i].peRed = m_pBMInfo->bmiColors[i].rgbRed;
		lpPal->palPalEntry[i].peGreen = m_pBMInfo->bmiColors[i].rgbGreen;
		lpPal->palPalEntry[i].peBlue = m_pBMInfo->bmiColors[i].rgbBlue;
		lpPal->palPalEntry[i].peFlags = NULL; //PC_NOCOLLAPSE;
   }

   // call create palette
   if( hPal->CreatePalette (lpPal) == 0 )
   {
      	delete hPal;
      	hPal = NULL;
   }
      
   // clear all allocated mem
   GlobalFreePtr (lpPal);

   // return CPalette class
   return hPal;
}

////////////////////////////////////////////////////////////////////
// BOOL Stretch(CDC* pDC, CRect output, CRect input )
// paste this dib onto a dc
// pDC = dc to paste onto
// output = rectangle to paste into resizeing to fit
// input = cropped rectangle to use 

BOOL ImageDib::Stretch(CDC* pDC, CRect output, CRect input )
{
    BOOL bSuccess = FALSE;
    
    ASSERT(m_pBuffer);		// Assert that we have an image
    if(  m_pBuffer == NULL ) return FALSE;

	// create a new palette
	CPalette* oldPalette = NULL;

	if( this->hasPalette() )
	{
		// select palette into dc
		// all ready realized if needed
		oldPalette = pDC->SelectPalette(GetPalette(), TRUE );
		pDC->RealizePalette();
	}

  	// set COLORONCOLOR MODE
  	pDC->SetStretchBltMode(COLORONCOLOR /*STRETCH_DELETESCANS*/);

	// actualy paste it to the screen
    bSuccess = ::StretchDIBits(
    	pDC->GetSafeHdc(),	  		// the dc
    	output.left,					// DestX
    	output.top,				// DestY
        output.Width(),						// dest width
        output.Height(),					// dest height
        input.left,							// dib left
        input.top, 						// dib right
        input.Width(),
        input.Height(),
        m_pBMData,
        m_pBMInfo,
        DIB_RGB_COLORS,
        SRCCOPY);	
    
	// reselect old palette
	if( oldPalette )
	{
	 	pDC->SelectPalette(oldPalette, TRUE);
    }
    return bSuccess;
}


///////////////////////////////////////////////////////////////////
// BOOL Allocate( void ) 
// allocate the memory needed by the DIB bitmap
//
// returns true if successful

BOOL ImageDib::Allocate( void ) 
{
   IASSERT( m_pBuffer == NULL );

    m_pBuffer = (char *) GlobalAllocPtr(GHND, m_length);
   
    if( m_pBuffer == NULL ) 
	{
        m_bits = 0;
        m_length = 0L;
        return FALSE;
    }
 
	m_pBMInfoHeader = (LPBITMAPINFOHEADER) (m_pBuffer + sizeof(BITMAPFILEHEADER));
    m_pBMFileHeader = (LPBITMAPFILEHEADER) m_pBuffer;
    m_pBMInfo = (LPBITMAPINFO) m_pBMInfoHeader;
    return TRUE;
}
