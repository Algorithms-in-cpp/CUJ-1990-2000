//	File: igraph.hpp
//	Description: plot histograms and luts on a CDC object 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//


#include "stdafx.h"

#ifndef IMAGELIB_IMAGEGRAPH
#define IMAGELIB_IMAGEGRAPH

#include "ipoint.hpp"

#define PLOT_RED ((COLORREF)RGB(196,9,51))
#define PLOT_GREEN ((COLORREF)RGB(22,202,2))
#define PLOT_BLUE ((COLORREF)RGB(9,3,201))
#define PLOT_GREY ((COLORREF)RGB(192,192,192))
#define PLOT_BLACK ((COLORREF)RGB(0,0,0))
#define PLOT_YELLOW ((COLORREF)RGB(202,192,2))
#define PLOT_DRKBLUE ((COLORREF)RGB(48,51,186))
#define PLOT_DRKRED ((COLORREF)RGB(128,0,40))
#define PLOT_DRKGREEN ((COLORREF)RGB(0,128,0))
#define PLOT_WHITE ((COLORREF)RGB(255,255,255))

// definitions
#define MARKER_LENGTH	5	 // length of marker in pixels

class ImageGraph
	{
	 public:
	 
	 // intialise restangle and internal varibles	 
	 ImageGraph ( CDC* pDC, CRect& plotarea, long xrange, long yrange, char* text_size = NULL );
	 ImageGraph( CRect& plotarea, long xrange, long yrange, char* text_size = NULL);

	 ~ImageGraph( void );

	 // Actual ploting functions
	 void DrawBar  ( CDC* pDC, int xvalue, int yvalue, BOOL xaxis = TRUE );
	 void DrawLine ( CDC* pDC, ImagePoint& from, ImagePoint& to, BOOL xaxis = TRUE );
	 void DrawScale( CDC* pDC ); 
	 void DrawPoint( CDC* pDC, int xvalue, int yvalue, COLORREF colour );
	 void DrawMarker( CDC* pDC, int xvalue, int yvalue );


	 // set colours
	 void SetPlotColour( const COLORREF new_plotcolour   ) { plot_colour   = new_plotcolour; };
	 void SetScaleColour( const COLORREF new_scalecolour ) { scale_colour = new_scalecolour; };
	 void SetBarColour( const COLORREF new_barcolour     ) { bar_colour    = new_barcolour; };

	 // conversion routines
	 int YUnitToPlot( long yunit );
	 int XUnitToPlot( long xunit );

	 // overidable string conversions
	 virtual BOOL XScaleToString( CString& string, long value );
	 virtual BOOL YScaleToString( CString& string, long value );

	 void ClearPlot(  CDC* pDC, COLORREF colour	 = PLOT_WHITE );

	 protected:
	 COLORREF plot_colour;
	 COLORREF scale_colour;
	 COLORREF bar_colour;
	 
	 CPoint Origin;     // origin of the plot
	 CRect area; 		// full drawing area
	 double XScaleFactor, YScaleFactor;	// scaling factors	 	
     long  XRange, YRange; // graph ranges
     CSize StringSize;
     
};   

#endif	// IMAGELIB_IMAGEGRAPH
