//	File: iplut.hpp
//	Description: ImagePoinLut - point look up table 
//
//	Author: C Dare-Edwards
//	
//  Copyright Conrad Dare-Edwards 1997  
//



#ifndef IMAGELIB_IMAGEPOINTLUT
#define IMAGELIB_IMAGEPOINTLUT

////////////////////////////////////////////
// ImagePointLut
// drived from ImageLut and ImagePointList 
// combines them to create 
// a point based lookup table

#include "isystem.hpp"
#include "ipoint.hpp"
#include "ilut.hpp"
#include "ihist.hpp"
#include "itlist.hpp"	// template list 

typedef  ImageTList<ImagePoint> ImagePList;

class ImagePointLut : public ImageLut
{
  	public:
   	enum colour { RED, GREEN, BLUE };
  
	// constructors
  	ImagePointLut( void );                        
  	ImagePointLut( const ImagePointLut& newlut );	
  	ImagePointLut( const ImagePList& newpoints  );	
  
    // copy operators	
	ImagePointLut& operator=( const ImagePointLut& copy );
	ImagePointLut& operator=( const ImageLut& newlut ); 
   
	 // histogram equalisation ( produces a lot of points )	
  	void Equalise( const ImageHist& hist );	 
  
	 // invert the y and or the x  axis
  	void Invert( BOOL xaxis = FALSE, BOOL yaxis = TRUE ); 
  	void SwapAxis( void );	

  	// Minimum to Maximum routines
 	void SetMinToMax( int min, int max,  colour type = RED);    
  	void SetMinToMax( const ImageHist& hist, colour type =RED); 

	// optomise the mimimum and maximum 
	void OptimiseMinMax(const ImageHist& hist,int& min,int& max); 
  	
	// 3 point optomised lookup table
	void Optimise( const ImageHist& hist, colour type =RED);    
	
	// logorithmic curve between points
  	void SetLog( const ImageHist& hist );       
  	void SetLog( int min, int max );      

	 // exponential curve between points
  	void SetExp( const ImageHist& hist );      
  	void SetExp( int min, int max );    
	
	// compute new table from list
  	void Update( BOOL tidy = FALSE);  

  	// point and list routines	  
 	BOOL AddPoint( const ImagePoint& point );    
 	BOOL Replace( const ImagePoint& point, int position );  

	const ImagePList& getPointList( void ) const;
	void BuildPointList( void );

  	private:
	// check and sort list
	void SortPointList( void ); 
  	// tidy up list removing redundant points 
	void TidyPointList( void );        
 
	// the point list
  	ImagePList m_PointList; 
};

////////////////////////////////////////////////////
// inline functions 

// getPointList - return constant point list
inline const ImagePList&
ImagePointLut::getPointList( void )	const
{
	return m_PointList;
}

// operator = copy list 
inline ImagePointLut& 
ImagePointLut::operator=( const ImagePointLut& copy)
{
	m_PointList = copy.getPointList(); // copy list
	ImageLut* lut = this;
	(*lut) = copy;	// pass down no need to update
	return *this;	// return this
}
 
                                      
#endif	// IMAGELIB_IMAGEPOINTLUT

