//	File: iinfo.cpp
//	Description: Image information class 
//
//	Author: C Dare-Edwards
//	
//	
//  Copyright Conrad Dare-Edwards  1997 
//

#include "stdafx.h"


#include "isystem.hpp"
#include "iinfo.hpp"
#include <string.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

ImageInfo::ImageInfo()				  // defualt constructor every thing set to 0
{
    getWidth()   = 0;				   // set every thing to null
	getHeight()  = 0;
    getNoBand() = 0;
    getHeaderSize() = 0;
	getBytesPerLine()  = 0;	
	getBytesPerBand()  = 0;	

	m_filename = NULL;

    getFormat()   = F_NONE;
	getFileType() = R_NONE;
	getStorage()  = S_NONE;	
}

ImageInfo::ImageInfo( const ImageInfo& info )		// copy constructor
{
    getWidth()   = info.getWidth();				 // copy everything 
	getHeight()  = info.getHeight();
    getNoBand() = info.getNoBand();
    getHeaderSize() = info.getHeaderSize();
	getBytesPerLine()  = info.getBytesPerLine();	
	getBytesPerBand()  = info.getBytesPerBand();	

	m_filename = NULL;	  // intalise pointer
	setFilename( info.getFilename() );

    getFormat()   = info.getFormat();
	getFileType() = info.getFileType();
	getStorage()  = info.getStorage();	
}
  	
ImageInfo::~ImageInfo()				  // destructor
{
 	if( m_filename) delete[] m_filename;
}

BOOL ImageInfo::isEqual(const ImageInfo& info ) const // are these equal
{
	if( ( getWidth()    != info.getWidth()    ) ||	
	    ( getHeight()   != info.getHeight()   ) ||
        ( getNoBand()  != info.getNoBand()  ) ||
     	( getHeaderSize() != info.getHeaderSize() ) ||
    	( getBytesPerLine() != info.getBytesPerLine()) ||	
		( getBytesPerBand() != info.getBytesPerBand()) ||	
     	( getFormat()   != info.getFormat()   )	||
		( getFileType() != info.getFileType() )	||
		( getStorage()  != info.getStorage()  )	 )
     {
      	return FALSE;
     } 
     
	if( getFilename() != NULL && info.getFilename() != NULL )
	{
		if( strcmp( getFilename() , info.getFilename() ) != 0 )
			return FALSE;
	}
	// we are equal 
	return TRUE;
}

void 
ImageInfo::operator=( const ImageInfo& info )   // copy object
{
    getWidth()   = info.getWidth();			  // copy every thing
	getHeight()  = info.getHeight();
    getNoBand() = info.getNoBand();
    getHeaderSize() = info.getHeaderSize();
	getBytesPerLine()  = info.getBytesPerLine();	
	getBytesPerBand()  = info.getBytesPerBand();	

	setFilename( info.getFilename() );

    getFormat()   = info.getFormat();
	getFileType() = info.getFileType();
	getStorage()  = info.getStorage();	

}


void 
ImageInfo::setFilename( const char* string )   // set filename
{
 	if( m_filename ) delete[] m_filename;	   // free memory
	if( string == NULL ){ m_filename = NULL; return; }

	m_filename = new ( char[ strlen( string )+ 2]	);	 // allocate more
	if( m_filename ) strcpy( m_filename, string );	 // copy string
}


// remove path from filename and return string
// scan back in string for the last \ or :
const char* 
ImageInfo::getClipFilename( void ) const
{
	IASSERT( m_filename	!= NULL );
	int length = strlen( m_filename );

	while( length-- > 0)
	{
		if( m_filename[length] == '\\'|| m_filename[length] == ':' )
		{
			length++; break;  
		}
	}
	
	return &m_filename[length]; 
}

