// Display.h : main header file for the DISPLAY application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


#define UPDATE_BITMAP 1

// update palette message sent internaly
#define WM_DOREALIZE   (WM_USER + 0x101 )   // realise palette

/////////////////////////////////////////////////////////////////////////////
// CDisplayApp:
// See Display.cpp for the implementation of this class
//

class CDisplayApp : public CWinApp
{
public:
	CDisplayApp();
	~CDisplayApp();

	// templates
	CMultiDocTemplate* m_pEditLutTemplate;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDisplayApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDisplayApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
