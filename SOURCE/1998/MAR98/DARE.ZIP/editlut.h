// editlut.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// EditLut form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "paredit.h"
#include "iconline.hpp"
#include "linecont.h"
#include "ihist.hpp"

class EditLut : public CFormView
{
protected:
	EditLut();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(EditLut)

// Form Data
public:
	//{{AFX_DATA(EditLut)
	enum { IDD = IDD_EDITLUT };
	int		m_editcol;
	UINT	m_xval;
	UINT	m_yval;
	//}}AFX_DATA

// Attributes
public:
    LineControl* m_linecontrol;

	// edit controls
   	CParsedEdit m_edit_xval;
	CParsedEdit m_edit_yval;

	ImagePointLut m_luts[3];
	BOOL col_mode;			// 1 for colour and 0 for single band grey

	void SetColourMode( BOOL flag = FALSE );
	
	const ImagePointLut& GetCurrentLut( void ) const;
	int GetColour( void ) const;
	BOOL GetColourMode( void ) const;

	const ImageHist& GetCurrentHist( void );

// Operations
public:
	
	void Update();
    CDisplayDoc* GetDocument()   { return (CDisplayDoc*)m_pDocument; };

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(EditLut)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void WinHelp(DWORD dwData, UINT nCmd = HELP_CONTEXT);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~EditLut();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(EditLut)
	afx_msg void OnEdlutUpdate();
	afx_msg void OnSelchangeEdlutCol();
	afx_msg void OnEdlutDelete();
	afx_msg void OnEDLUTHelp();
	afx_msg void OnEdlutNext();
	afx_msg void OnEdlutPrev();
	afx_msg void OnKillfocusEdlutXval();
	afx_msg void OnKillfocusEdlutYval();
	afx_msg void OnChangeEdlutXval();
	afx_msg void OnChangeEdlutYval();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
 	afx_msg HBRUSH OnCtlColor( CDC* pDC, CWnd* pWnd, UINT nCtlColor );
	afx_msg void OnLbutDefault();
	afx_msg void OnLbutEqual();
	afx_msg void OnLbutExp();
	afx_msg void OnLbutInvert();
	afx_msg void OnLbutLog();
	afx_msg void OnLbutMinmax();
	afx_msg void OnLbutOpto();
	afx_msg void OnLbutUndo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
