// linecont.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// LineControl window

#include "iplut.hpp"

class LineControl : public CWnd
{

// Construction
public:
	LineControl(UINT id, CWnd* Parent);

	void OnUpdate( const ImagePointLut& lut );    // update lut and redraw 
	void OnUpdate( const ImageHist& hist, BOOL plotflag = TRUE); // update histogram and redraw 

	const ImagePointLut& GetUpdate( void ); // retrive internal lut 
	void UpdateControls( ImageDragPoint* dpoint);

	BOOL hasChanged( void ) { return( m_lineupdate ); };
	BOOL isOpen( void ) { return( m_isopen ); };
	BOOL PtOnClient( CPoint& point );
	
	void OnImediatePaint( void );

	void PaintControl( CDC* dc );
	void PaintBackDrop( void );

	void SetLineColour( COLORREF colour ) { m_linecolour = colour; };

	// point editing funtions
	void GetNextItem( void );	// select next item in the list
	void GetPrevItem( void );	// select next item in the list
	void DeleteItem( void );	// delete selected item
	void MoveItem( const ImagePoint& point ); // move item to new position
	void PointMove( ImageDragPoint* dpoint);

	CPoint m_initpoint;				// windowing start point

	CRect m_clientarea;				// active area
	CRect m_fullclientarea;			// full window area
	ImageControlLine* m_line; 		// iconline class
	ImagePointLut m_lut;			// current lookup table
	BOOL m_lineupdate; 				// current status
	BOOL m_mousebuttondown;			// current mouse status

	// lut table line colour
	COLORREF m_linecolour;
	BOOL m_isopen;		// open and valid flag

	// histogram objects
	ImageHist m_hist;
	BOOL m_plothist;	 // plot histogram or not

	///////////// back drop contorl information
	CBitmap m_bitmap;
	BOOL CreateBackDrop( void );

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(LineControl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~LineControl();

	// Generated message map functions
public:
	//{{AFX_MSG(LineControl)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
