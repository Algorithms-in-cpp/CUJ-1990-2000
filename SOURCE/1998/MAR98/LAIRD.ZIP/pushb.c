#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>


void bye(Widget w, XtPointer clientdata, XtPointer calldata);


int main(int argc, char **argv)
{
    Arg args[5];
    Widget aButton, top;
    XtAppContext app;
        /* Initialize an X application. */
    top = XtAppInitialize(&app, "KBH", NULL, 0, (Cardinal *) &argc, 
            argv, NULL, args, 0);

        /* Create a single button. */
    aButton = XtVaCreateManagedWidget("Push me", 
            xmPushButtonWidgetClass, top, XmNheight, 40, XmNwidth, 
            100, NULL);

        /* Associate a callback to the button. */
    XtAddCallback(aButton, XmNactivateCallback, bye, 
             (XtPointer) NULL);

        /* Realize the application, that is, form and display all its 
           graphical elements. */
    XtRealizeWidget(top);
        /* Begin listening for all X events of interest to this 
           application. */
    XtAppMainLoop(app);
    return(0);
}


void bye(Widget w, XtPointer clientdata, XtPointer calldata)
{
    puts("All done.");
    exit(0);
}
