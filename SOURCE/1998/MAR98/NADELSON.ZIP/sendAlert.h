class sendAlert
{
        static int sockfd;
        static struct sockaddr_in servAddr;
        static struct sockaddr_in cliAddr;
        problemMessage theProblem;
        static RWTPtrSlist<problemMessage>problemMessageList;
        static sigjmp_buf threadEnv;
        static pthread_mutex_t queueLock;
        int status;
public:
        sendAlert(char *_applicationName, int timeoutCount);
        sendMessage(int _severity, char *_msg);
        static void *processMessageQueueThread(void *_null);
        static void  alarmHandler(int _location);
        operator int() { return status; }
};

