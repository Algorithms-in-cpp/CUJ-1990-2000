main()
{
    int sockfd;                  // Socket Id
    struct sockaddr_in servAddr; // Holds server socket address
    struct sockaddr_in cliAddr;  // Holds client socket address
    int ret;                     // Generic return value
    int clilen;                  // Length of the client socket 
                                 // address structure
    problemMessage aProb;        // The error message received

    // Create a datagram (UDP) socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        cerr << "Could not open datagram socket" << endl;
        return 1;
    }

    // Set up a structure to accept socket messages from clients 
    // on the network
    memset((char *)&servAddr, 0, sizeof(servAddr));

    servAddr.sin_family = AF_INET;
    servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servAddr.sin_port = htons(6543);

    // Bind this structure to the socket identifier
    if (bind(sockfd, (struct sockaddr *)&servAddr, 
        sizeof(servAddr)) < 0)
    {
        cerr << "Could not bind to socket" << endl;
        return 1;
    }

    clilen = sizeof(cliAddr);

    for(;;)
    {
        //  Wait for a message on the socket
        ret = recvfrom(sockfd, (char *)&aProb, sizeof(problemMessage), 
            0, (struct sockaddr *)&cliAddr, &clilen);
        if (ret < 0)
        {
            cerr << "Error receiving message from socket" << endl;
            continue;
        }

        // Return the message identifier directly back to the client 
        // for acknowlegement
        int retval = aProb.getMessageId();
        if (sendto(sockfd, (char *)&retval, sizeof(retval), 0, 
            (struct sockaddr *)&cli_addr, clilen) != sizeof(retval))
                cerr << "Error sending to socket" << endl;

        // Display the values of the error message
        cout << "**** New Message Received ****" << endl;
        cout << "App Name: " << aProb.getApplicationName() << endl;
        cout << "PID     : " << aProb.getProcessId() << endl;
        cout << "Message : " << aProb.getProblemMessage() << endl;
        cout << "Severity: " << aProb.getSeverity() << endl;
        cout << "Msg Num : " << aProb.getMessageId() << endl << endl;
    }

    return 0;
}
