sendAlert::sendAlert(char *_applicationName, int timeoutCount) : theProblem(_application_name, 
timeoutCount)
{
        pthread_t threadId;
        sigset_t signalSet;
        
        sigemptyset(&signalSet);                // Initialize the signal set to contain no signals
        sigaddset(&signalSet, SIGALRM);                        // Add SIGALRM to the signal set
        sigprocmask(SIG_BLOCK, &signalSet, NULL);        // Block the SIGALRM from the main 
process thread
        
        status = 1;

        // Create a datagram (UDP) socket
        if (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
        {
                cerr << "Could not open datagram socket";
                status = 0;
                return;
        }

        memset((char *)&servAddr, 0, sizeof(servAddr));

        servAddr.sin_family = AF_INET;                
        servAddr.sin_addr.s_addr = inet_addr("555.555.555.0");        // Set the appropriate subnet 
address of the server
        servAddr.sin_port = htons(6543);                                // Set the appropriate port of the 
server

        memset((char *)&cliAddr, 0, sizeof(cliAddr));

        cliAddr.sin_family = AF_INET;
        cliAddr.sin_addr.s_addr = htonl(INADDR_ANY);                // Accept acknowledgment from 
the server from any address in the network
        cli_addr.sin_port = htons(0);

        // Bind the socket to receive acknowledgment from any server in the network.
        // This allows flexibility with regardless to the placement of the server in the network
        if (bind(sockfd, (struct sockaddr *)&cliAddr, sizeof(cliAddr)) < 0)
        {
                cerr << "Could not bind to socket";
                status = 0;
                return;
        }

        // Create the processMessageQueueThread
        if (pthread_create(&threadId, 0, processMessageQueueThread, (void *)NULL) != 0)
        {
                cerr << "Could not create processMessageQueueThread";
                status = 0;
                return;
        }
        // It is not necessary to wait for the thread to complete since the thread is contained within an 
        // endless loop.
}

int sendAlert::sendMessage(int severity, char *msg)
{
        theProblem.setSeverity(severity);                // Set the serverity level
        theProblem.newProblem(msg);                // Set the error message text and increment the 
message id number

        pthread_mutex_lock(&queueLock);        // Lock access to the problemMessageQueue

        // Create an instance of the problemMsg to place on the queue
        problemMsg *newProblem = new problemMsg(theProblem);
        if (!newProblem)
        {
                cerr << "Could not allocate memory for an instance of problemMsg" << endl;
                pthread_mutex_unlock(&queueLock);
                return 0;
        }
        problemMessageList.insert(newProblem);        // Insert the message on the queue
        pthread_mutex_unlock(&queueLock);        // Unlock access to the problemMessageQueue
        
        return 1;
}


// The alarm signal handler
void sendAlert::alarmHandler(int num)
{
        cout << "I caught an SIGALRM!" << endl;

        // Jump to the location in the thread set by sigsetjmp
        siglongjmp(threadEnv, num);
}

void *sendAlert::processMessageQueueThread(void *not_used)
{
        RWTPtrSlist<problemMessage> localProblemMessageList;        // Local queue to hold error 
messages transferred by the problemMessageList
        sigset_t threadSignalSet;                                        // Threads signal set
        int size;                                                        // Return value from sendto and 
recvfrom
        int savemask = 1;                                                // Value used by sigsetjmp
        int returned_from_longjmp;                                // Return value of sigsetjmp
        int clilen;                                                // Size of cliAddr

        clilen = sizeof(cliAddr);

        sigemptyset(&threadSignalSet);                                // Empty the threads signal set
        sigaddset(&threadSignalSet, SIGALRM);                        // Add SIGALRM to the signal set

        // Start the threads infinite loop
        for(;;)
        {
                sleep(1);                                                // Execute the loop every 1 second
                
                pthread_mutex_lock(&queueLock);                        // Lock access to 
problemMessageList
                
                // If the have been error messages added to the queue transfer them to
                // the local queue
                if (!sendAlert::problemMessageList.isEmpty())
                {
                        RWTPtrSlistIterator<probleMessage> 
problemMessageListIterator(sendAlert::problemMessageList);
                        while(problemMessageListIterator())
                        {
                                problemMessage *aMessage = problemMesageListIterator.key();
                                localProblemMessageList.insert(new problemMessage(*aMessage));
                        }
                        sendAlert::problemMessageList.clear();        // Remove all entries within the 
problemMessageList
                }
                pthread_mutex_unlock(&queueLock);                // Unlock the queue
                
                // If the local message queue is empty there is no need to continue processing
                if (localProblemMessageList.isEmpty())
                        continue;
                
                // Unblock the SIGALRM signal so that the thread can receive it
                pthread_sigmask(SIG_UNBLOCK, &threadSignalSet, NULL);
                
RWTPtrSlistIterator<problemMessage> 
localProblemMessageListIterator(localProblemMessageList);
                
                // Iterate over the error message queue.
                while(localProblemMessageListIterator())
                {
                        problemMessage *aMessage = loclProblemMessageListIterator.key();
                        
                        // Decrement the message timeout counter
                        aMessage->decrementCountDown();

                        // If the message has expired remove it from the queue
                        if (aMessage->getCountDown == 0)
                        {
                                localProblemMessageList.remove(aMessage);
                                continue;
                        }
                                
                        // Set the socket to broadcast mode
                        setsockopt(sendAlert::sockfd, SOL_SOCKET, SO_BROADCAST, (const char 
*)aMessage, sizeof(problemMessage));

                        // Send the error message over the socket
                        if ((size = sendto(sendAlert::sockfd, (char *)aMessage, sizeof(problemMessage), 
0, (struct socaddr *)&servAddr, sizeof(servAddr))) != sizeof(problemMessage))
                        {
                                cerr << "Error Sending Error Message to Socket.  Size of Message 
Sent: " << size << " Correct Size of Message: " << sizeof(problemMessage) << endl;
                                continue;
                        }

                        // Set up an environment to return to if the SIGALRM signal is caught before
                        // the acknowlegement is received from the server
                        if ((returned_from_longjmp = sigsetjmp(threadEnv, savemask)) != 0)
                        {
                                cerr << "Alarm went off before acknowlegement was received" << 
endl;
                                continue;
                        }

                        // Setup the signal handler to receive SIGALRM signals
                        signal(SIGALRM, sendAlert::alarmHandler);

                        // Set an alarm to go off after 3 seconds
                        alarm(3);

                        // Receive the acknowlegement from the server
                        size = recvfrom(sendAlert::sockfd, (char *)acknowledgment, 
sizeof(acknowledgment), 0, (struct sockaddr *)&sendAlert::cliAddr, &clilen);
                        
                        // Turn the alarm off if the ack was received
alarm(0);

                        if (size < 0)
                        {
                                cout << "Error receiving response from server:<< endl;
                                continue;
                        }

                        // If the acknowledgment matches the message sent then remove the message from 
the queue
                        if (acknowlegement == aMessage->getMsgId())
                                localProblemMessageList.remove(aMessage);
                }
        }
        return 1;                // This should never be reached but is need by the compiler since threads return a 
value
}                          
