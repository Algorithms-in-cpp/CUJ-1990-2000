class problemMessage
{
    int msgId;               // Message id
    int severity;            // Severity level
    int processId;            
    int countDown;           // Time-out indicator
    char problemText[256];   // Error message: Expand if 256 bytes 
                             // is not large enough
    char appicationName[50]; // Process name: Expand if 50 bytes 
                             // is not large enough
public:
    // Initialize all values to 0
    problemMessage() { memset(this, 0, sizeof(problemMessage); }  
    
    // Set the application name and expiration count down value
    problemMessage(char *_appName, int _timeOut)
    {
        msgId = 0;
        processId = getpid();
        countDown = _timeOut;
        strcpy(applicationName, _appName);
    }
    
    // Copy constructor
    problemMessage(const problemMessage &copy)
    {
        msgId = copy.msgId;
        severity = copy.severity;
        processId = copy.processId;
        strcpy(problemText, copy.problemtext);
        strcpy(applicationName, copy.applicationName);
        countDown = copy.countDown);
    }

    // Add a new error message
    void newProblem(char *_problem)
    {
        msgId++;    // Increment the message id number
        strcpy(problemText, _problem);     // Store the error message
    }

    // Set the severity level
    void setSeverity(int _severity) { serverity = _severity; }  
    // Decrement the time-out counter
    void decrementCountDown() { countDown--; } 
    
    // The following methods are used to retrieve values of the 
    // private members
    int getMessageId() { return msgId; }
    int getSeverity() { return serverity; }
    int getProcessId() { return processId; }
    int getCountDown() { return countDown; }
    char *getProblemMessage { return problemText; }
    char *getApplicationName() { return getApplicationName; }
};

