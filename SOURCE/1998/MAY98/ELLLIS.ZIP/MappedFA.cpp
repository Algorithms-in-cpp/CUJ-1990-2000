//  MappedFA.cpp
//
//  Implementation for mapped FA

#include "mappedfa.h"

MappedFA::MappedFA()
  : m_ntrans(0)
   ,m_accState(invalidState)
   ,m_nstates(1) // start state always present
   ,finalised(FALSE)
{
}

MappedFA::~MappedFA()
{
    // Go through map destroying lists and contents of lists
    CPtrList *stateTrans;
    WORD key;
    for (POSITION p1 = transByFromState.GetStartPosition(); p1 != NULL; )
    {
        transByFromState.GetNextAssoc(p1, key, (CObject *&)stateTrans);

        STrans *trans;
        while (!stateTrans->IsEmpty())
        {
            trans = (STrans *)stateTrans->RemoveHead();
            delete trans;
        }
        delete stateTrans;
    }
    // Now tidy up the transition storage
    for (int i = 0; i < m_nstates; i++)
    {
        if (transArr[i].size) delete[] transArr[i].trans;
    }
    delete[] transArr;
}

int MappedFA::NewState()
{
  return(m_nstates++);
}

// Add new transition for a particular event
// between two state nodes
void MappedFA::AddTransition(int sourceState
				, char event, int targetState)
{
  STrans *trans = new STrans();
  trans->m_ch = event;
  trans->m_to = targetState;
  // Look for list in map
  CPtrList *stateTrans;
  if (!transByFromState.Lookup(sourceState, (CObject *&)stateTrans))
  {
    // None found - create a new one
    stateTrans = new CPtrList;
    transByFromState.SetAt(sourceState, stateTrans);
  }
  stateTrans->AddTail(trans);
}

// Add empty transition between two state nodes
void MappedFA::AddEmptyTransition
                          (int sourceState,
                           int targetState)
{
  AddTransition(sourceState,
                emptyEvent,
                targetState);
}

// Record what the accept state is.
void MappedFA::SetAcceptState(int a_acceptState)
{
  m_accState = a_acceptState;
}

// Searches for all state nodes reachable from
// the given from state for the passed event.
// returns true if at least one 
// target state is found.
bool MappedFA::ToStatesForEvent(int i_from
			, char i_oninput, CFasterIntSet& o_toset)
{
  bool retval = false;

  if (finalised)
  {
      // Copy the states from the array into the int set
      STransList *tList = &(transArr[i_from]);
      for (int i = 0; i < tList->size; i++)
      {
        if (tList->trans[i].m_ch == i_oninput
         || (i_oninput && tList->trans[i].m_ch == anyEvent))
	    {
	      o_toset.Append(tList->trans[i].m_to);
	    }
      }
      retval = !o_toset.IsEmpty();
  }
  else
  {
      // Find list corresponding to from state
      CPtrList *stateTrans;
      if (transByFromState.Lookup(i_from, (CObject *&)stateTrans))
      {
        // walk through attached list looking for transitions which have an event
        // corresponding to that passed
        STrans *trans;
        for (POSITION p = stateTrans->GetHeadPosition(); p != NULL; )
        {
            trans = (STrans *)stateTrans->GetNext(p);
            if (trans->m_ch == i_oninput)
	        {
	          o_toset.Append(trans->m_to);
	          retval = true;
	        }
        }
      }
  }
  return retval;
}

int MappedFA::GetAcceptState()
{
  return m_accState;
}

void MappedFA::Dump(ostream &out)
{
  // Dump all the transitions in the storage set
  out << "+++ MappedFA transitions -\n";
  for (int i = 0; i < m_nstates; i++)
  {
    out << i << ": ";
    if (transArr[i].size)
    {
        // walk through attached list dumping the transition contents
        for (int j = 0; j < transArr[i].size; j++)
        {
            out << (transArr[i].trans[j].m_ch == emptyEvent
                                ? CString("null")
                                : transArr[i].trans[j].m_ch == anyEvent
                                    ? CString("any")
                                    :CString(transArr[i].trans[j].m_ch))
                         << " -> " << transArr[i].trans[j].m_to << "; ";
        }
    }
    else
    {
        out << "none";
    }
    out << "\n";
  }
  out << endl;
}

int MappedFA::GetMaxState()
{
    return m_nstates;
}

struct SFrom
{
    char m_ch; int m_from;
};
struct SFromList
{
    SFrom *froms;
    int size;
    SFromList() { froms = 0; size = 0; }
};

void MappedFA::Finalise()
{
    // Iterate through the map storage compiling the to and from links
    transArr = new STransList[m_nstates];
    SFromList *fromsArr = new SFromList[m_nstates];
    for (int i = 0; i < m_nstates; i++)
    {
        CPtrList *stateTrans;
        if (transByFromState.Lookup(i, (CObject *&)stateTrans))
        {
            transArr[i].size = stateTrans->GetCount();
            transArr[i].trans = new STrans[m_nstates];//[transArr[i].size];
            // walk through attached list dumping the transition contents
            STrans *trans;
            int j = 0;
            for (POSITION p = stateTrans->GetHeadPosition(); p != NULL; j++)
            {
                // to transitions (ie the ones used in traversal)
                trans = (STrans *)stateTrans->GetNext(p);
                transArr[i].trans[j].m_ch = trans->m_ch;
                transArr[i].trans[j].m_to = trans->m_to;

                // from transitions (ie used in checking only)
                if (fromsArr[trans->m_to].froms == 0)
                {
                    fromsArr[trans->m_to].froms = new SFrom[m_nstates];
                }
                fromsArr[trans->m_to].froms[fromsArr[trans->m_to].size].m_ch = trans->m_ch;
                fromsArr[trans->m_to].froms[fromsArr[trans->m_to].size].m_from = i;
                fromsArr[trans->m_to].size++;
            }
        }
        else
        {
            transArr[i].size = 0;
        }
    }

    // Iterate through the state storages looking for states which only one
    // input transition and one output transition, both null.
    int deadStates;
    do {
        deadStates = 0;
        for (int i = 0; i < m_nstates; i++)
        {
            // Are both to and from lists short?
            if (transArr[i].size == 1 && fromsArr[i].size == 1)
            {
                if (transArr[i].trans[0].m_ch == 0
                 && fromsArr[i].froms[0].m_ch == 0)
                {
                    // Yes, so eliminate the state
                    // Look for the forward transition in the source state
                    for (int j = 0;
                            j < transArr[fromsArr[i].froms[0].m_from].size
                                    && transArr[fromsArr[i].froms[0].m_from].trans[j].m_to != i;
                                j++)
                    { }
                    // Got it - so excise the bugger by pointing the found
                    // 'from' transition at the 'to' with a null transition
                    transArr[fromsArr[i].froms[0].m_from].trans[j].m_to = transArr[i].trans[0].m_to;

                    // Simlarly, look for this state in the source set of the
                    // target 
                    for (j = 0;
                            j < fromsArr[transArr[i].trans[0].m_to].size
                                    && fromsArr[transArr[i].trans[0].m_to].froms[j].m_from != i;
                                j++)
                    { }
                    // Got it - so excise the bugger by pointing the found
                    // 'from' transition at the 'to' with a null transition
                    fromsArr[transArr[i].trans[0].m_to].froms[j].m_from = fromsArr[i].froms[0].m_from;

                    // Eliminate the unnecessary storage.
                    if (fromsArr[i].size)
                    {
                        delete[] fromsArr[i].froms;
                        fromsArr[i].size = 0;
                    }
                    if (transArr[i].size)
                    {
                        delete[] transArr[i].trans;
                        transArr[i].size = 0;
                    }


                    // ... and finally add the deleted state to the count.
                    deadStates++;
                }
            }
        }
    } while (deadStates);

    // Iterate through the state storages looking for state pairs which only
    // have one transition (and that one null) between them.
    int *counters = new int[m_nstates];
    do {
        deadStates = 0;
        for (int i = 0; i < m_nstates; i++)
        {
            // Count the number of transitions between this state and the
            // target states
            memset(counters, 0, sizeof(int) * m_nstates);  // clear it out first!
            for (int j = 0; j < transArr[i].size; j++)
            {
                counters[transArr[i].trans[j].m_to]++;
            }
            for (int k = 0; k < m_nstates; k++)
            {
                // Look for target states with a single transition
                if (counters[k] == 1)
                {
                    // Verify that the transition is null
                    for (int m = 0;
                            m < transArr[i].size
                                    && transArr[i].trans[m].m_to != k;
                                m++)
                    { }
                    if (transArr[i].trans[m].m_ch == emptyEvent)
                    {
                        // Check that the target state does not itself have a
                        // transition back here
                        for (int n = 0; n < transArr[k].size
                                    && transArr[k].trans[n].m_to != i;
                                n++)
                        { }
                        if (n >= transArr[k].size)
                        {
                            // There isn't one, so eliminate the superfluous
                            // state:
                            //  1. add all the transitions from state k to
                            //      state i
                            //  2. for each of those transitions which is
                            //      copied, modify to and from data in the
                            //      target state which refers to state k to
                            //      point at state i. Record those states
                            //      which are modified.
                            //  3. add all from data held by state k to state
                            //      i.
                            //  4. for each element of from data which is
                            //      copied and for which the source state has
                            //      not been updated, modify to data in the
                            //      source state to point at state i instead
                            //      of k.
                            //      Note: this may strictly be unnecessary
                            //      depending on the nature of the automata
                            //      being generated, but I'd rather be sure.
                            //  5. overwrite the null transition that is
                            //      being eliminated (index m) with the last
                            //      transition held by state i, and reduce
                            //      the size
                            //  6. delete the dead state
                            
                            // 1. add k's transitions to i
                            CFasterIntSet touched(m_nstates);
                            for (n = 0; n < transArr[k].size; n++)
                            {
                                transArr[i].trans[transArr[i].size].m_to = transArr[k].trans[n].m_to;
                                transArr[i].trans[transArr[i].size].m_ch = transArr[k].trans[n].m_ch;
                                transArr[i].size++;

                                // 2. modify to and from data in the target state
                                if (touched.Find(transArr[k].trans[n].m_to) == -1)
                                {
                                    for (int z = 0; z < transArr[transArr[k].trans[n].m_to].size; z++)
                                    {
                                        if (transArr[transArr[k].trans[n].m_to].trans[z].m_to == k)
                                            transArr[transArr[k].trans[n].m_to].trans[z].m_to = i;
                                    }
                                    for (z = 0; z < fromsArr[transArr[k].trans[n].m_to].size; z++)
                                    {
                                        if (fromsArr[transArr[k].trans[n].m_to].froms[z].m_from == k)
                                            fromsArr[transArr[k].trans[n].m_to].froms[z].m_from = i;
                                    }
                                    touched.Append(transArr[k].trans[n].m_to);
                                }   // End of (2)
                            }   // End of (3)

                            // 3. add k's sources to i (apart from the one
                            //      from i, of course)
                            for (n = 0; n < fromsArr[k].size; n++)
                            {
                                if (fromsArr[k].froms[n].m_from != i)
                                {
                                    if (fromsArr[i].froms == 0)
                                    {
                                        fromsArr[i].froms = new SFrom[m_nstates];
                                    }
                                    fromsArr[i].froms[fromsArr[i].size].m_from = fromsArr[k].froms[n].m_from;
                                    fromsArr[i].froms[fromsArr[i].size].m_ch = fromsArr[k].froms[n].m_ch;
                                    fromsArr[i].size++;

                                    // 4. modify to data in the source state
                                    if (touched.Find(fromsArr[k].froms[n].m_from) == -1)
                                    {
                                        for (int z = 0; z < transArr[fromsArr[k].froms[n].m_from].size; z++)
                                        {
                                            if (transArr[fromsArr[k].froms[n].m_from].trans[z].m_to == k)
                                                transArr[fromsArr[k].froms[n].m_from].trans[z].m_to = i;
                                        }
                                        touched.Append(fromsArr[k].froms[n].m_from);
                                    }
                                }   // End of (4)
                            }   // End of (3)

                            // 5. delete the null transition we've replaced
                            transArr[i].size--;
                            transArr[i].trans[m].m_to = transArr[i].trans[transArr[i].size].m_to;
                            transArr[i].trans[m].m_ch = transArr[i].trans[transArr[i].size].m_ch;

                            // 6. delete the state we've unhooked.
                            if (fromsArr[k].size)
                            {
                                delete[] fromsArr[k].froms;
                                fromsArr[k].size = 0;
                            }
                            if (transArr[k].size)
                            {
                                delete[] transArr[k].trans;
                                transArr[k].size = 0;
                            }

                            // 7. Check if we've just moved the end state!
                            if (k == m_accState) m_accState = i;

                            // ... and finally add the deleted state to the count.
                            deadStates++;
                        }
                    }
                }
            }
        }   // End of i loop
    } while (deadStates);

    // Tidy up!
    delete[] counters;
    // Now tidy up the transition and from storage
    for (i = 0; i < m_nstates; i++)
    {
        if (fromsArr[i].size) delete[] fromsArr[i].froms;
    }
    delete[] fromsArr;

    finalised = TRUE;
}
