Optimised Regular Expression Classes
====================================

These are a set of regular expression classes which are an optimised
version of those published with the article "" in the May 1998 issue of
CUJ. This file explains what's changed in these classes.

As with the the original article classes, these were developed using MFC
classes.

Bug Fixes
---------

As published in May 1998, the article contained an inconsistency between
the behaviour of '?' as described in the text and as implemented in the
example code: the text explained '?' as matching any character, whereas
the example code implemented '?' as matching 0 or 1 occurrence of the
preceding expression.

The version of regexp.cpp here is implemented to be consistent with the
text. This has been achieved by introducing a special 'any' event and to
insert that as a character transition when '?' is met in the expression.
Thus there is something to traverse when trying to match an arbitrary
character.

Optimisations
-------------

As a test harness for optimising these regular expression classes, I
wrote a noddy grep tool called minigrep. It takes arguments of the
regular expression, the file to be searched, and a 'debug' argument
which turns on timing routines and a dump of the regular expression
finite automaton.

Just as a reminder, the following is the regular expression set
currently recognised:

  Char  Meaning
------------------------------------------------------------------------
    ?   matches a single arbitrary character eg "a?b" would match "a2b"
        but not "ab" or "a24b"
    |   OR operator - matches either of the subexpressions to either
        side of it eg "a|b" would match "a" or "b".
        Note that a single character is a complete
        subexpression, so if you want to apply the OR operator to
        complete words you must use parentheses.
    [<characters>]
        set delimiters - matches any of the characters contained by the
        suqare brackets eg "[0123]" would match "1" but not "5"
    *   zero or more of the preceding subexpression eg "a*b" will match
        "ab", "aaaab", or "b" but will not match "axb".
        Note that this does _not_ work the same as the DOS command line
        '*', which matches any number of characters after a prefix. To
        achieve a similar effect here use "?*" ie zero or more arbitrary
        characters.
    +   one or more of the preceding subexpression eg "a+b" will match
        "ab" or "aaaab", but will not match "b"
    (<subexpr>)
        delimits a (usually compound) subexpression. As noted above, a
        single character is a valid subexpression but if you want to
        treat whole words or more complex subexpressions as a single
        entity then they need to be parenthesised. eg "chicken|egg"
        would match "chickengg" or "chickeegg" since the OR operator is
        working between the 'n' and 'e' characters to either side of it;
        "(chicken)|(egg)" is what is required.

The following are the optimisations which were applied:

1 - SimpleFA - this was a structure based upon a fixed size array of
    transition elements. I replaced this with a two-phase storage class
    which used a map and list form to build the automaton, then switched
    to an array-based form for traversal. The aim in the new form was to
    remove the primary lookup loop, where the traversal code was looking
    for all the transitions relating to a particular state, by making the
    state the key valuse either for map lookup or as the index into the
    transition array.

2 - CIntSet - replaced this with an array based form called
    CFasterIntSet. The original was a structure based on the MFC
    CDwordArray, and is now a two part structure based on one array to
    hold the values in sequence (because this sequencing element is
    very important in optimising the traversal code) and another array
    to hold flags for each possible value to avoid duplication (rather
    than using a linear search as before).

3 - temporary objects - two prongs here: short lived locals (eg when
    traversing the FA from a particular state several CIntSet instances
    are used); doomed state iterators (ie AutomatonState instances which
    were going to be deleted immediately because there was no way the
    current position would satisfy the expression).

    I dealt with the first by rescoping some of the locals, making them
    class level instead and resetting them after use. Not very OO, but
    effective.

    The second was tackled by only instantiating the base state once
    and cloning it for each new input character, and then by adding a
    lookahead function which checked to see whether it was worth
    creating a new state iterator for the current input character.

    There was also a bit of custom memory management in there, using
    object pools in preference to global new and delete, but that's not
    very interesting and so is not described here.

4 - FiniteAutomaton - stopped using this wrapper class entirely.

5 - finite automaton optimisation - after I'd done 1-4 (with the help of
    a profiler) the main problem remaining was simply that there were too
    many transitions: all those null transitions which are so crucial for
    building the regexp automaton in the first place just get in the way
    in a tight loop. So, I decided to try some post-generation
    optimisation.

    The rules I struck upon were:
    a:  any state which only has one input transition and one output
        transition and where both of those transitions are null can be
        eliminated.
    b:  any two states which are connected only by a single forward null
        transition can be considered to be the same state and as such
        can be combined.

    Applying these rules brought the number of states in my test
    expression down from 50 to 15, and basically meant that there was
    that much less to traverse (especially on closure) and as such
    dramatically improved the performance.

    _Note_ The above FA optimisation rules cannot be applied to all
    NDFAs. It appears that they are safe for those automata generated
    by the RegularExpression class, but it is easy to construct a
    general NDFA which will be broken if these rules are applied to it.


Source Files
------------

For an explanation of the various source files, the reader is referred
to the original article in the May 1998 issue of CUJ. However, the
minigrep test harness may be taken as an example of use. This list is
just here to document what should be in this file.

    COMMDEFS.H      Common definitions file
    FABUILD.H       Interface for transition storage
    FAQUERY.H       Interface for querying the finite automaton, and
                    definition of integer set class
    FAQUERY.CPP     Implementation of integer set class
    REGEXP.H        Interface for regular expression conversion class
    REGEXP.CPP      Implementation of regular expression conversion
                    class
    FINAUTO.H       Interface for FA iterator
    FINAUTO.CPP     Implementation for FA iterator AutomatonState
    MINIGREP.CPP    Test harness implementing a trivial grep utility
    MAPPEDFA.H      Definition for two phase finite automaton
                    implementation
    MAPPEDFA.CPP    Implementation of two phase finite automaton
                    implementation


