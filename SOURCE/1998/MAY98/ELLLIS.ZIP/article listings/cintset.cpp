#include "faquery.h"
     
CIntSet::CIntSet(int initDim)
{
   // Do presizing if real dimension passed
   if (initDim > 0)
      SetSize(initDim);
}
     
// Looks for given value from passed index 
// Returns index if found, -1 if not
int CIntSet::Find(int value, int start) 
{
   if (start >= 0 && start < GetSize()) 
   {
      for (; start < GetSize(); start++)
      {
         if (GetAt(start) == value)
            return(start);
      }
   }
   return(-1);
}
     
// Adds a new value into the set, 
// if not already present
void CIntSet::Append(int value)
{
   if (Find(value) < 0)
   {
      Add(value);
   }
}
     
// Append the set but ensuring there are 
// no repititions 
void CIntSet::Append(CIntSet& iset)
{
  for(int i = 0;i < iset.GetSize();i++) 
  {
   Append(iset.GetAt(i));
  }
}
     
CIntSet::CIntSet(const CIntSet &src) 
{
   *this = src;
}
     
CIntSet &
CIntSet::operator=(const CIntSet &src) 
{
   if (this != &src)
   {
      RemoveAll();
      for (int i = 0; i < src.GetSize(); i++)
         Add(src[i]);
   }
   return(*this);
}
     
