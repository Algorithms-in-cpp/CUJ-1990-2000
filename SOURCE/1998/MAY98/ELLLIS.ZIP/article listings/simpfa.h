#ifndef _SIMPFA_H
#define _SIMPFA_H
     
#include "faquery.h"
#include "fabuild.h"
     
#define MAXTRANS  4096
     
class SimpleFA : public CFAQuery, public CFABuild 
{
public: 
  //Constructor
  SimpleFA();
     
  //overridden from CFAQuery 
  virtual bool 
  ToStatesForEvent(int i_from, char i_oninput, CIntSet& o_toset);
  virtual int GetAcceptState(); 
     
  //overridden from CFABuild
  virtual int NewState();
  virtual void 
  AddTransition(int sourceState, char event, int targetState);
  virtual void 
  AddEmptyTransition(int sourceState, int targetState);
  virtual void SetAcceptState(int a_acceptState);
     
private:
  //the tuple that defines a single transition. 
  struct STrans
  {
   int m_from; int m_to; char m_ch;
  };
     
  //the number of states in the FA.
  int m_nstates;
     
  //the array of transitions.
  STrans m_trans[MAXTRANS];
     
  //the number of transitions in the FA. 
  int m_ntrans;
     
  // the accepting state.
  int m_accState;
     
};
     
#endif //_SIMPFA_H
