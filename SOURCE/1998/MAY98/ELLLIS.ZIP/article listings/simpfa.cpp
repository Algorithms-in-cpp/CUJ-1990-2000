// Example of providing user defined storage for 
// finite automaton.
     
#include "simpfa.h"
     
SimpleFA::SimpleFA()
  : m_ntrans(0), 
    m_accState(invalidState),
    m_nstates(1) // start state always present
{
}
     
int SimpleFA::NewState()
{
  return(m_nstates++);
}
     
// Add new transition for a particular event 
// between two state nodes
void SimpleFA::AddTransition(
   int sourceState, char event, int targetState)
{
  m_trans[m_ntrans].m_from = sourceState; 
  m_trans[m_ntrans].m_ch = event;
  m_trans[m_ntrans].m_to = targetState; 
  m_ntrans++;
}
     
// Add empty transition between two state nodes 
void 
SimpleFA::AddEmptyTransition(int sourceState, int targetState)
{
  AddTransition(sourceState, emptyEvent, targetState);
}
     
// Record what the accept state is.
void SimpleFA::SetAcceptState(int a_acceptState) 
{
  m_accState = a_acceptState;
}
     
// Searches for all state nodes reachable from the given from 
// state for the passed event. returns true if at least one 
// target state is found.
bool SimpleFA::ToStatesForEvent(
   int i_from, char i_oninput, CIntSet& o_toset)
{
  bool retval = false;
  // do a simple linear search of the transitions array.
  for(int i = 0;i < m_ntrans;i++)
  {
    if(m_trans[i].m_from == i_from && 
       m_trans[i].m_ch == i_oninput)
    {
      o_toset.Append(m_trans[i].m_to);
      retval = true;
    }
  }
  return retval;
}
     
int SimpleFA::GetAcceptState()
{
  return m_accState;
}
     
