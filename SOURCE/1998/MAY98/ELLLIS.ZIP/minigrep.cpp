//  minigrep.cpp
//
//  Program to accept and check and FA against a given filename

#include <afx.h>
#include <fstream.h>
#include <time.h>

#include "mappedfa.h"
#include "regexp.h"
#include "finauto.h"

int main(int argc, char **argv)
{
    // Need two command line arguments, otherwise the deal's off!
    if (argc < 3 || argc > 4)
    {
        cout << "Usage:\tminigrep <regexp> <filename> [-d]\n"
             << "where -d activates debugging information";
        return 1;
    }

    CString regexp(argv[1]);
    CString filename(argv[2]);
    BOOL debug = (argc == 4 && strcmp(argv[3], "-d") == 0);

    // Construct the RE automaton
    MappedFA fa;
    RegularExpression re(fa);
    clock_t reStart = clock();
    re.ConvertToFiniteAutomaton(regexp);
    fa.Finalise();
    clock_t rePeriod(clock() - reStart);
    if (debug)
    {
        re.Dump(cout);
        cout << "+++ RE parsing took " << (double)(rePeriod) / CLOCKS_PER_SEC << "s\n";
    }

    // Open the file and read it in line by line, searching for the RE in the
    // text
    clock_t searchStart = clock();
    ifstream file;
    file.open(filename, ios::in | ios::nocreate);
    if (!file.is_open())
    {
        cout << "*** Could not open file " << filename << " for input.\n";
        return 1;
    }
    char buffer[512];   // bland assumption that no line exceeds 512 bytes
    const char *cp;
    int line = 0;
    CPtrList itList;    // list of automaton iterators
    AutomatonState *it;
    int startAt = 0;    //re.getStartState();
    AutomatonState::setMaxState(fa.GetMaxState() + 1);
    AutomatonState baseState(&fa, startAt);
    if (debug) fa.Dump(cout);
    while (line++, !file.eof())
    {
        file.getline(buffer, 512);

        BOOL found = FALSE;
        for (cp = buffer; *cp && !found; cp++)
        {
            if (baseState.Lookahead(*cp))
            {
                // Add a new RE iterator starting at the current character pos
                it = new AutomatonState(baseState);
                itList.AddTail(it);
            }

            // Whizz through the set of iterators feeding the new character
            // into each one. For each iterator:
            //  - if it is an invalid state, remove it
            //  - if it is an accept state, flag completion
            // Note: it is assumed that we are seeking the first match, not
            // the longest.
            // It is also assumed that we don't really care where exactly the
            // match is found.
            POSITION oldp;
            for (POSITION p = itList.GetHeadPosition(); p != NULL; )
            {
                oldp = p;   // need to maintain trailing pointer for deletion
                it = (AutomatonState *)itList.GetNext(p);
                BOOL val = it->NextState(*cp);
                if (!val)
                {
                    if (it->IsValid())
                    {
                        // Hurrah!
                        found = it->IsAccept();
                    }
                    else
                    {
                        // Failed match - delete
                        itList.RemoveAt(oldp);
                        delete it;
                    }

                }
            }
        }

        // If the found flag is true, output the line with its number
        if (found)
        {
            cout << line << " : " << buffer << "\n";
        }

        // Destroy all iterators remaining in the list
        while (!itList.IsEmpty())
        {
            it = (AutomatonState *)itList.RemoveHead();
            delete it;
        }
    }
    clock_t searchPeriod(clock() - searchStart);
    if (debug)
        cout << "+++ File search took " << (double)(searchPeriod) / CLOCKS_PER_SEC << "s\n" << endl;

    // Clear out everything
    AutomatonState::free();
    CFasterIntSet::free();

    return 0;
}

