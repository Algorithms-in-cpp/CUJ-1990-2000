//  MappedFA.h
//
//  Implementation of storage class based on a map for building (having no
//  defined maximum and reasonable lookup characteristics) and allocated
//  array structures for the real job.

#ifndef _MAPPEDFA_H
#define _MAPPEDFA_H

#include "faquery.h"
#include "fabuild.h"

class MappedFA : public CFAQuery, public CFABuild
{
public: 
  //Constructor
  MappedFA();
  ~MappedFA();

  //overridden from CFAQuery 
  virtual bool ToStatesForEvent(int i_from,
                                char i_oninput,
                                CFasterIntSet& o_toset);
  virtual int GetAcceptState(); 

  void Dump(ostream &out);
  int GetMaxState();

  //overridden from CFABuild
  virtual int NewState();
  virtual void AddTransition(int sourceState,
                      char event,
                      int targetState);
  virtual void AddEmptyTransition(int sourceState,
                           int targetState);
  virtual void SetAcceptState(int a_acceptState);
  virtual void Finalise(); // method to freeze FA state
                           // (which for us means copy to a faster structure)

private:
  //the tuple that defines a single transition (from state is implicit in key)
  struct STrans
  {
    char m_ch; int m_to;
  };

  //the number of states in the FA.
  int m_nstates;

  // the transition storage (optimised for building)
  CMapWordToOb transByFromState;    // from -> list of ch/to pairs

  // the other transition storage (optimised for lookup)
  struct STransList
  {
    STrans *trans;
    int size;
  };
  STransList *transArr; // indexed by state

  //the number of transitions in the FA.
  int m_ntrans;

  // the accepting state.
  int m_accState;

  // Flag indicating which structure to use
  BOOL finalised;
};

#endif //_MAPPEDFA_H
