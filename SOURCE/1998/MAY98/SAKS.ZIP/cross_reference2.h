namespace cross_reference
    {
    struct tree_node;
     
    extern tree_node *xr;
     
    tree_node *add_tree
        (tree_node *t, char const *w, unsigned n);
    void put_tree(tree_node const *t);
     
    void add(char const *w, unsigned n); 
    void put();
    }
     
inline
void cross_reference::add(char const *w, unsigned n)
    {
    xr = add_tree(xr, w, n);
    }
     
inline
void cross_reference::put()
    {
    put_tree(xr);
    }
