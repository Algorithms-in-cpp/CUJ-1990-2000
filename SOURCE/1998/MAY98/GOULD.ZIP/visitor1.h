class Event // our "Visitor"
{
public:
    virtual visitWidget(Widget&)               
    { /* default visitation */ }

    virtual visitDerivedWidget(DerivedWidget&) 
    { /* default visitation */ }
};

class DerivedEvent
{
public:
    virtual visitWidget(Widget&) { /* overridden */ }
    virtual visitDerivedWidget(DerivedWidget&) { /* overridden */ }
};

class Widget // our "Element"
{
public:
    virtual accept(Event& e) { e.visitWidget(*this); }
};

class DerivedWidget : public Widget
{
public:
    virtual accept(Event& e) { e.visitDerived(*this); }
};


