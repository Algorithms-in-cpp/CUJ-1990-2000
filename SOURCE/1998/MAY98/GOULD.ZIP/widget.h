///////// widget.h

#include <iostream.h>

class Event;
class EventA;
class EventB;
class EventC;

class Widget
{
public:
    virtual void handleEvent(Event&)
    { cerr << "Widget, Event" << endl;  }
    virtual void handleEvent(EventA&)
    { cerr << "Widget, EventA" << endl; }
    virtual void handleEvent(EventB&)
    { cerr << "Widget, EventB" << endl; }
    virtual void handleEvent(EventC& c)
    { cerr << "Widget, EventC" << endl;
      handleEvent((EventB&)c);      }
};

class WidgetA : public Widget
{
public:
    void handleEvent(EventA&) { cerr << "WidgetA, EventA" << endl; }
    void handleEvent(EventB&) { cerr << "WidgetA, EventB" << endl; }
};

class WidgetB : public Widget
{
public:
    void handleEvent(EventB&) { cerr << "WidgetB, EventB" << endl; }
    void handleEvent(EventC&) { cerr << "WidgetB, EventC" << endl; }
};

class WidgetC : public WidgetB
{
public:
    void handleEvent(EventB&)
    { cerr << "WidgetC, EventB" << endl; }
    // void handleEvent(EventC&)
    // { cerr << "WidgetC, EventC" << endl; }
};
