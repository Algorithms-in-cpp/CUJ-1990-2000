////////// event.h

#include <iostream.h>
#include "widget.h"

class Event
{
public:
    virtual void visit(Widget& w) { w.handleEvent(*this); }
};

class EventA : public Event
{
public:
    void visit(Widget& w) { w.handleEvent(*this); }
};

class EventB : public Event
{
public:
    void visit(Widget& w) { w.handleEvent(*this); }
};

class EventC : public EventB
{
public:
    void visit(Widget& w) { w.handleEvent(*this); }
};
