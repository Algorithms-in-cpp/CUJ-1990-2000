Dear PJP:
     
As a long time reader to <i>CUJ,<r> I am able to keep informed on the 
progress of the C++ standard, and am excited about power offered by the 
STL. Unfortunatly, until IBM releases the new version of Visual Age 
C++, I can't turn excited into code. I am in the early stages of 
development of a system (dare I say framework) that I expect to be 
building on for the next several years. I would like to base this early 
design work on the C++ Standard. Since I hear that IBM plans to use your 
Standard library implementation, who better to ask for a suggestion? 
Could you recommend a public domain (or cheap) source for STL that I 
can use until I can get yours from IBM?
     
Eric Raaen
Hughes STX
eric.raaen@gsfc.nasa.gov

<i>There are lots of free or cheap STL versions out there --
a web search will get you to several -- but few
come close to matching the C++ Standard. Microsoft Visual C++ is your
best bet until IBM ships, if you can afford to invest in yet another
compiler. -- pjp<r>


Dear Mr. Plauger:
     
Since you wrote much of the code for the Standard C++ libraries used in 
VC++ 5.0, I thought I'd run this one by you for your opinion.
Listing 1 shows a code sample that
will not compile unless the <f>foo<d> stream 
insertion operator is written to take
a <f>const foo&<d> instead of the usual <f>foo&<d> parameter. This appears to be 
because of the call to <f>copy<d> which is insisting, somewhere within the 
templates, on an insertion operator with that signature.
     
Is this a bug in STL, a bug in Microsoft's implementation thereof, or 
unavoidable standard operating procedure? No reference I have seen 
mentions the need for an insertion operator requiring const parameters, 
although Nelson's book <i>C++ Programmer's Guide to the Standard Template 
Library<r> mentions an opposite problem of violations of const within STL. 
It doesn't pose any real problem to do it that way since an <f>ostream<d> 
insertion would seem usually to be logically const on the object being 
inserted anyway. But I want to hear it from the horse's mouth.
     
Thank you.
Sincerely,
Steve Cohen

<i>Template <f>set<d> stores only const elements, so you can't destroy
the order of the set by altering a stored value in place. I believe that
is the source of the constness that you're running afoul of. On the other
hand, it's generally good style and good hygiene to make a reference
parameter const if the called function does not alter the stored value,
so what the heck. -- pjp


---------------- Listing 1 --------------

#include <algorithm>
#include <iostream>
#include <set>
#include <iterator>
using namespace std;
#pragma warning(disable: 4786)
     
class foo
{
public:
    foo(int x_=0, int y_=0) : x(x_),y(y_){} 
    bool operator< (const foo& rhs) const
        {return ((x==rhs.x) ? (y < rhs.y) : (x < rhs.x));}
private:
    int x;
    int y;
     
    //this won't compile when used with an ostream iterator 
    //friend ostream& operator << (ostream& os, foo& f) 
    //{return os << f.x << " " << f.y << " ";}
     
    // this is okay.
    friend ostream& operator << (ostream& os, const foo& f); 
    {return os << f.x << " " << f.y << " ";}
};
     
typedef set<foo> fooSet;
     
void main()
{
    fooSet foos;
    for (int i=0; i < 10; i++)
        foos.insert(foo(i,i+1));
    ostream_iterator<foo> outFoo(cout);
    // this line won't compile unless the insertion operator takes a 
    // const foo&
    copy(foos.begin(),  foos.end(),  outFoo);
}
</code>
     

Dear P.J.,
     
Coincidentally, the week that I made my first real foray into using the STL, 
I read the letter by Chris Ahlstrom in the February 1998
issue complaining about 
the lack of readability and comments in the STL code shipping with Microsoft 
VC++ 5.0. I'd like to second his comments but add one of my own.
     
I always compile with the warning level on the compiler set to 4 
(Microsoft's highest) to give the compiler the best chance of indicating 
problems with my code. I always fix the warnings so that when warnings 
appear in the compiler output I know it's associated with the latest changes 
I've made. I was somewhat dismayed when I added an STL header to clean 
compiling code and the compiler produced a huge stream of warnings. It 
turns out that fixing the warnings in the STL headers I was using was simple 
but I feel I shouldn't have to do this. If component software is to be 
successful, libraries must engender users with confidence in their quality 
and robustness. Headers that generate huge flows of warnings don't do it 
for me.
     
Thank you,
     
Tim Craig

<i>Nor for me. On the other hand, I also can't abide compilers that issue
warnings for usage that I consider perfectly acceptable. The problem is
made worse by the ever wider use of templates, which often generate code
for special cases that would be nonsense if hand coded.<r>

<i>I write code that
is highly portable. When I feed it to a new compiler, I read all the warning
messages. In response to any sensible warnings, I change the code so it
gets even more portable and more robust -- and avoids the warnings, of
course. But every compiler still ends up issuing a slew of silly messages
that I have to turn off by hand or just live with. The VC++ headers turn
off all the warnings they can, unless you override the pragmas that do so.
I don't like it either. -- pjp<r>

     
Mr Plauger,
     
I'm hoping to accomplish two objectives with this letter. 
First I would like to thank you for your continued excellent 
work as Senior Editor of <i>The C/C++ Users Journal.<r> It is an 
extremely rare month that I do not find the magazine to be
a source of accurate, timely information that can be used 
in my work the very next day. My subscription has been one
of the best educational investments I have ever made. Thank you.
Second, I was hoping you could clear up a small 
interpretation issue with the C Standard, or point me to 
someone who can.
     
The area in which I work develops embedded C applications 
for use in automotive audio systems. Recently we have
begun working with a new microprocessor and compiler vendor. 
For obvious reasons, I would rather not identify them. The 
microprocessor that they are supplying has a limited number of 
operations in its instruction set that allow manipulation of
the systen stack pointer. As a result of this, the only compiler 
available for the micro uses an ``overlap'' segment of global
RAM to store local variables and to pass parameters. The 
system stack is not used for either of these operations.
     
At link time, the linker generates a call tree for the entire 
application.  This information is then used to allocate addresses 
in the overlap segment to local variables and parameters.
The call tree information is used in such a way as to insure 
that the local variables of a function never destroy the locals
of its calling function. Storage for locals will be shared between 
functions, but not between two functions in the same branch of
the call tree.
     
This has some obvious implications. Functions are not 
reentrant. The compiler does not support recursion. And, 
since interrupts are asynchronous, their service routine 
call trees must be completely disjoint from the foreground
logic call tree. Otherwise, a function called from a service 
routine could destroy the local variables of a previous 
instance of itself, if it is called from the foreground logic.
     
I am maintaining that this behavior violates the reentrancy 
requirement of section 5.2.3. The compiler vendor disagrees, 
claiming that a hardware interrupt is not the same as a signal, 
and that a signal handler is not the equivalent of an interrupt 
service routine. I'm pretty certain that I am correct on this
issue, but I would like a more ``official'' interpretation of section 
5.2.3 than my own to help support my case.
     
Thank you for your time and any answer you may be able to give.
     
David P. Wright
Visteon Automotive Systems
dwrigh11@ford.com
     
<i>The C Standard requires that all function calls be reentrant,
so this implementation does not conform. The vendor is correct
in asserting that interrupts are not necessarily the same as signals,
and hence not addressed by the C Standard. Every conforming implementation
that I know of, however, does support nested reentrancy for interrupt
routines. So I'd say that the vendor is once again on shaky ground.
-- pjp<r>

