#ifndef _DOG_TAG_H_
#define _DOG_TAG_H_

#include <assert.h>

#ifdef NDOG_TAG

#undef DECL_DOG_TAG
#undef CHECK_DOG_TAG

#define DECL_DOG_TAG(dogTag)
#define CHECK_DOG_TAG(dogTag) ((void)0)

#else

#define DECL_DOG_TAG(dogTag) DogTag dogTag;
#define CHECK_DOG_TAG(dogTag) assert((dogTag).isValid());

#endif


class DogTag {
public:
   //-------------------------
   // constructors, destructor
   //-------------------------
   DogTag();
   DogTag(const DogTag& rhs);
  ~DogTag();

   //--------------------
   // assignment operator
   //--------------------
   DogTag& operator=(const DogTag& rhs);

   //--------------------------
   // look for corrupted memory
   //--------------------------
   bool isValid() const;

private:
   //----------
   // data area
   //----------
   const DogTag *_this;
};


//+==============================================================
//|
//| DESCRIPTION:
//|    Default constructor.
//|
//+==============================================================
inline DogTag::DogTag():
   _this(this)
{}


//+==============================================================
//|
//| DESCRIPTION:
//|    Copy constructor.  Uses assertion to verify rhs is valid.
//|    Note rhs._this must not be copied.
//|
//+==============================================================
inline DogTag::DogTag(const DogTag& rhs):
   _this(this)
{
   assert(rhs.isValid());
}


//+==============================================================
//|
//| DESCRIPTION:
//|    Destructor.  Uses assertion to verify the object is valid,
//|    then makes the object invalid.  If the object is invalid,
//|    it has already been destructed, it was never constructed,
//|    or it was overwritten sometime during its lifetime.
//|
//+==============================================================
inline DogTag::~DogTag()
{
   assert(isValid());
   _this=0;
}


//+==============================================================
//|
//| DESCRIPTION:
//|    Assignment operator.  Uses assertion to verify both ob-
//|    jects are valid.  Note, rhs._this must not be copied.
//|
//+==============================================================
inline DogTag& DogTag::operator=(const DogTag& rhs)
{
   assert(isValid());
   assert(rhs.isValid());

   return *this;
}

inline bool DogTag::isValid() const
{
  return _this == this;
}

#endif                                             //!_DOG_TAG_H_

