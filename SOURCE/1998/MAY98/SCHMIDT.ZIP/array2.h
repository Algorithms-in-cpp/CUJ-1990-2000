template<class T, ptrdiff_t N>
class Array
    {
public:
    ~Array()
        {
        }
    Array()
        {
        }
    operator T *()
        {
        return array_;
        }
    operator T const *() const
        {
        return array_;
        }
    T &operator[](ptrdiff_t const i)
        {
        return array_[i];
        }
    T const &operator[]
      (ptrdiff_t const i) const
        {
        return array_[i];
        }
private:
    T array_[N];
    Array(Array const &);
    Array &operator=(Array const &);
    };
     
     
     
     
