Author:  "Eric Gufford" <eric-gufford@home.com> at Internet
Date:    5/21/98  10:29 AM
Priority: Normal
TO: marc briand at MFI-Lawrence
Subject: RE: An undocumented heuristic
------------------------------- Message Contents -------------------------------
/*******************************************************************************
***************************************
                                                                                
                        Registry.h
PURPOSE:        DECLARATION OF THE Registry_c CLASS.

AUTHOR:         ERIC GUFFORD

CREATED:        10/97

COPYRIGHT 1997 - 1998, TRIAD Systems Inc. 
This source code may be used and modified without resitriction as long as the
copyright and author data remains intact.
********************************************************************************
***************************************
USE OF THIS SOURCE CODE IS AT THE USER'S SOLE DISCRETION.  TRIAD Systems Inc.
MAKES NO WARRANTY, EXPRESSED OR IMPLIED,
REGARDING THE APPROPRIATNESS OR MERCHANTABILITY OF THIS SOURCE CODE.  TRIAD
Systems Inc. WILL NOT BE RESPONSIBLE FOR ANY
DAMAGES, MONETARY OR OTHERWISE, ARISING FROM THE USE OF THIS SOURCE CODE.  USE
OF THIS SOURCE CODE, IN ANY WAY, IN WHOLE
OR IN FRAGMENT, CONSTITUES ACCEPTANCE OF THESE TERMS AND CONDITIONS.
********************************************************************************
***************************************
NOTES:
********************************************************************************
**************************************/
#ifndef __REGISTRY_H__
#define __REGISTRY_H__

class EXRegistry_c; // FORWARD DECLARATION

class Registry_c
        {
         public:
                typedef enum KeyType_e { KeyVolatile = 0,KeyPermanent };
         private:
                HKEY                    m_hKey;
         protected:
         public:
                                 Registry_c(HKEY const&) throw();
                virtual ~Registry_c() throw();
         public:
                bool AddKey(string const&,KeyType_e const);
                bool DeleteKey(string const&);
                bool FindKey(string const&,bool bOpen);
                bool OpenKey(string const&);
         public:
                bool            AddValue(string const&,string&);
                bool            AddValue(string const&,DWORD const);
                bool            DeleteValue(string const&);
                bool            FindValue(string const&);
                _variant_t      GetValue(string const&);
        };

#endif // __REGISTRY_H__
