Author:  "Eric Gufford" <eric-gufford@home.com> at Internet
Date:    5/21/98  10:29 AM
Priority: Normal
TO: marc briand at MFI-Lawrence
Subject: RE: An undocumented heuristic
------------------------------- Message Contents -------------------------------
/*******************************************************************************
***************************************
                                                                                
                        EXBase.h
PURPOSE:        DECLARATION OF THE EXBase_c CLASS.

AUTHOR:         ERIC GUFFORD

CREATED:        10/97

COPYRIGHT 1997 - 1998, TRIAD Systems Inc. 
This source code may be used and modified without resitriction as long as the
copyright and author data remains intact.
********************************************************************************
***************************************
USE OF THIS SOURCE CODE IS AT THE USER'S SOLE DISCRETION.  TRIAD Systems Inc.
MAKES NO WARRANTY, EXPRESSED OR IMPLIED,
REGARDING THE APPROPRIATNESS OR MERCHANTABILITY OF THIS SOURCE CODE.  TRIAD
Systems Inc. WILL NOT BE RESPONSIBLE FOR ANY
DAMAGES, MONETARY OR OTHERWISE, ARISING FROM THE USE OF THIS SOURCE CODE.  USE
OF THIS SOURCE CODE, IN ANY WAY, IN WHOLE
OR IN FRAGMENT, CONSTITUES ACCEPTANCE OF THESE TERMS AND CONDITIONS.
********************************************************************************
***************************************
NOTES:  A) THIS CLASS IS THE BASE OF ALL EXCEPTIONS IN THE EXCEPTION LIBRARY
                B) THIS CLASS WILL HANDLE ALL HEAVY LIFTING WITH RESPECT TO
LOGGING AND NETWORK ALERTS (I.E.: SNMP TRAPS)
                C) EXCEPTION SPECIFICATIONS IN MEMBER FUNCTION DEFINITIONS CAUSE
CLASS VIEW NOT TO SEE THESE FUNCTIONS
                D) THEREFORE, THESE SPECIFICATIONS HAVE BEEN COMMENTED IN ALL
MEMBER FUNCTION DEFINITIONS.
                E) SANITY CHECKS THROW logic_error INSTEAD OF EXSanity_c.
                F) SINCE EXSanity_c IS A CHILD OF EXBase_c, SANITY FUNCTIONS
CAN'T THROW IT. logic_error SEEMED THE BEST BET.
                G) CONSUMER OBJECTS DON'T NEED TO CARE SINCE, IF logic_error IS
THROWN, AN UNEXPECTED EXCEPTION FAULT OCCURS.
                H) THIS HAS THE NET EFFECT OF CALLING THE UNEXPECTED HANDLER (IN
THIS CLASS) AND TERMINATING THE APP.
                I) IN SHORT, THEN, DON'T WORRY ABOUT logic_error THROWS IN
PRODUCTION, ONLY WHILE DEBUGGING.
********************************************************************************
**************************************/
#ifndef __EXBASE_H__
#define __EXBASE_H__
#include <stdexcept>
#include <utility>
#include <vector>
#include <windows.h>
#include <winnt.h>
using namespace std;

#ifdef _USRDLL
        #define SCOPE __declspec(dllexport)
#else
        #define SCOPE __declspec(dllimport)
#endif

#pragma warning(disable:4251) // CLIENTS HAVE NO ACCESS TO PRIVATE STATIC
MEMBERS, THEREFORE THIS WARNING IS MEANINGLESS

class SCOPE EXBase_c //: public exception
        { // EXCEPTION CLASSES CAN'T THROW EXCEPTIONS!
         public: // TYPDEFS, ENUMERATIONS AND SUCH
                typedef pair<int,HMODULE>       ModulePair_t;
                typedef vector<ModulePair_t>    Modules_t;
                typedef enum Severity_e { EXNone =
0,EXTrace,EXWarning,EXError,EXFatal };
                #define SEVERITY_MASK 0xC0000000
                #define FACILITY_MASK 0x0FFF0000
                #define MSG_ID_MASK 0x0000FFFF
         private: // SANITY CHECKING FUNCTIONS AND VARIABLES
                static  const   long    sm_clSerialNumber;      // CLASS WIDE
VALUE
                                mutable long    m_clSerialNumber;       //
INSTANCE LEVEL VALUE
                                                void    SanityCheck()   const
throw(logic_error);
                                                void    SetSanity()            
const throw(logic_error);
                                                void    ClearSanity()   const
throw(logic_error);
         private: // MEMBER VARIABLES
                string          m_Message;
                string          m_UserMessage;
                DWORD           m_dwError;
                Severity_e      m_eSeverity;
                string          m_Source;
                string          m_File;
                int                     m_iLine;
         private: // USED BY THE STATIC FUNCTIONS FOR SYSTEMIC EXCEPTION
HANDLING
                static  Modules_t                                      
m_RegisteredApps;
                static  _se_translator_function         m_OldSEHandler;
                static  terminate_function                     
m_OldTerminationHandler;
                static  unexpected_function                    
m_OldUnexpectedHandler;
         protected:
                void                    Log(string const&) throw();
                bool                    IsSystemError() throw();
                string                  BuildHeader(string const&) throw();
                bool                    IsAppError() throw();
                bool                    GetErrorMessage(int const, HMODULE
hModule = NULL) throw();
                bool                    LogError(string const& header);
                string  const&  Source(string const&) throw();
         private: // CAN ONLY BE USED BY THIS CLASS
                                 EXBase_c() throw(); // ONLY USE FOR UNEXPECTED
EXCEPTIONS (I.E.: WITHIN AN EXCEPTION CLASS)
         protected: // THIS CLASS CAN'T BE INSTANTIATED DIRECTLY.
                                 EXBase_c(int iLine,string const& Source,string
const& Msg,Severity_e eSeverity,type_info const& Type) throw();
                                 EXBase_c(int iLine,string const& Source,long
lErr,Severity_e eSeverity,type_info const& Type) throw();
                                 EXBase_c(int iLine,string const& Source,long
lErr,string const& Msg,Severity_e eSeverity,type_info const& Type) throw();
         public: // OTHERWISE WE CAN'T DESTROY THESE OBJECTS
                virtual ~EXBase_c() throw();
         public: // MEMBER ACCESS FUNCTIONS
                string          const&  Message() const throw();
                string          const&  Source() const throw();
                DWORD           const   Error() const throw();
                Severity_e      const   Severity() const throw();
         public: // ONE TIME CALL PER THREAD - SETS AND RESETS REROUTING
MECHANISMS, RESPECTIVELY
                static void Initialize() throw();                               
               // REROUTES ERROR HANDLING ROUTINES
                static void DeInitialize() throw();                             
               // RESETS THE ORIGINAL FUNCTIONS
         public: // ONE TIME CALL PER APP OR LIBRARY - ADDS AND DELETES MESSAGE
TABLES FROM THE LIST, RESPECTIVELY
                static bool Register(string const&,DWORD const dwFacility = 0)
throw(); // ADDS THIS MESSAGE TABLE
                static bool UnRegister(DWORD const) throw();                    
                               // REMOVES THIS MESSAGE TABLES
         private: // EXCEPTION REDIRECTION FUNCTIONS
                static void WinException(unsigned int,EXCEPTION_POINTERS*);     
                       // REROUTES STRUCTURED EXCEPTIONS
                static void Bail();                                             
                                                               // TERMINATION
HANDLER
                static void Unexpected();                                       
                                                       // UNEXPECTED EXCEPTION
HANDLER
         private: // LOOKUP AND MANIPULATION FUNCTION OF REGISTRATION VECTOR
                static  Find(long const) throw();
        };

#endif // __EXBASE_H__


