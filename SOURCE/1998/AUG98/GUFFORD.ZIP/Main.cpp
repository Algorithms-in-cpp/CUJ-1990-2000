Author:  "Eric Gufford" <eric-gufford@home.com> at Internet
Date:    5/21/98  10:29 AM
Priority: Normal
TO: marc briand at MFI-Lawrence
Subject: RE: An undocumented heuristic
------------------------------- Message Contents -------------------------------
/*******************************************************************************
***************************************
                                                                                
                        Main.cpp
PURPOSE:        DLL ENTRY POINT

AUTHOR:         ERIC GUFFORD

CREATED:        10/97

COPYRIGHT 1997 - 1998, TRIAD Systems Inc. 
This source code may be used and modified without resitriction as long as the
copyright and author data remains intact.
********************************************************************************
***************************************
USE OF THIS SOURCE CODE IS AT THE USER'S SOLE DISCRETION.  TRIAD Systems Inc.
MAKES NO WARRANTY, EXPRESSED OR IMPLIED,
REGARDING THE APPROPRIATNESS OR MERCHANTABILITY OF THIS SOURCE CODE.  TRIAD
Systems Inc. WILL NOT BE RESPONSIBLE FOR ANY
DAMAGES, MONETARY OR OTHERWISE, ARISING FROM THE USE OF THIS SOURCE CODE.  USE
OF THIS SOURCE CODE, IN ANY WAY, IN WHOLE
OR IN FRAGMENT, CONSTITUES ACCEPTANCE OF THESE TERMS AND CONDITIONS.
********************************************************************************
***************************************
NOTES:
********************************************************************************
**************************************/
#pragma warning(disable:4786)
#include <utility>
#include <string>
#include <xstring>
//#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <windows.h>
#include <winnt.h>
using namespace std;
#include "Exceptions.h"

BOOL APIENTRY DllMain(HANDLE hModule,DWORD dwReason,LPVOID lpReserved)
{
 switch(dwReason)
        {
         case DLL_PROCESS_ATTACH:
                {
                 string Module(BUFSIZ,'\0');
                 GetModuleFileName(hModule,const_cast<char*>(Module.c_str()),Mod
ule.size());
                 EXBase_c::Initialize();
                 EXBase_c::Register(Module,FACILITY_EXCEPTIONS);
                }
                break;
         case DLL_THREAD_ATTACH:
                EXBase_c::Initialize();
                break;
         case DLL_THREAD_DETACH:
                EXBase_c::DeInitialize();
                break;
         case DLL_PROCESS_DETACH:
                EXBase_c::UnRegister(FACILITY_EXCEPTIONS);
                break;
        }
 return TRUE;
}
