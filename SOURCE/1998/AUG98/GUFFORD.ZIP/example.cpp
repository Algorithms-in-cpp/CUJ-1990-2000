#pragma warning(disable:4786) // TURN OFF THE 'BROWSER OUTPUT 
                              // TRUNCATED TO 255' WARNING.  
                              // IT'S MEANINGLESS.
#include <string>
#include <sstream>
#include <windows.h>
#include <winnt.h>
using namespace std;
#include "EXExceptions.h"
#include "TestMessages.h"
void main()
{
  // REGISTER THE MESSAGE TABLE - SIMULATE BY REGISTERING THE APP.
  string Module(BUFSIZ,'\0');
  // THIS APP RUNS AS A CONSOLE APP.  IT DOESN'T HAVE AN 
  // INSTANCE HANDLE. SO LET'S GET AN INSTANCE HANDLE
  HMODULE hModule = GetModuleHandle("Tester.exe");
  // THIS IS THE IMPORTANT CALL - GETS THE FULLY QUALIFIED PATH 
  // NAME OF THE COMPONENT.
  GetModuleFileName(hModule,const_cast<char*>(Module.c_str()),
    Module.size());
  EXBase_c::Register(Module,FACILITY_TESTER); // REGISTERS THIS APP 
                                              // WITH THE LIBRARY
 
  // VARIOUS EXCEPTIONS AND LOGGING CAPABILITIES ARE EXERCIZED HERE
  try
  { // PRIVATE EXCEPTION DEFINED IN THE APP'S MC FILE
    throw EXSystem_c(__LINE__, __FILE__, TEST_EXCEPTION,
      EXBase_c::EXTrace);
  }
  catch(EXBase_c& e)
  {
    MessageBox(GetActiveWindow(), e.Message().c_str(),
      "EXBase exception detected", MB_ICONSTOP | MB_OK);
  }
  try
  { // THIS WILL PRODUCE TWO IDENTICAL ENTRIES IN THE LOG - SHOWS 
    // THAT YOU DON'T HAVE TO THROW TO LOG!
    EXSanity_c(__LINE__, __FILE__, PROGRAM_ABORTED,
      EXBase_c::EXError); // JUST LOG THE ERROR
    throw EXSanity_c(__LINE__, __FILE__, PROGRAM_ABORTED,
      EXBase_c::EXError); // NOW THROW THE SAME THING
  }
  catch(EXBase_c& e)
  {
    MessageBox(GetActiveWindow(), e.Message().c_str(),
      "EXBase exception detected",MB_ICONSTOP | MB_OK);
  }
 
  try
  { // FORCE AN ACCESS VIOLATION ON A WRITE
    char* pTest = NULL;
    strcpy(pTest,"Yahoo!");
  }
  catch(EXBase_c& e)
  {
    MessageBox(GetActiveWindow(), e.Message().c_str(),
      "EXBase exception detected",MB_ICONSTOP | MB_OK);
  }

  try
  { // FORCE AN ACCESS VIOLATION ON A READ
    char* pTest = NULL;
    char x = *pTest;
  }
  catch(EXBase_c& e)
  {
    MessageBox(GetActiveWindow(), e.Message().c_str(),
      "EXBase exception detected",MB_ICONSTOP | MB_OK);
  }

  try
  { // FORCE A DIVIDE BY ZERO FAULT
    int a = 0,x = 5 / a;
  }
  catch(EXBase_c& e)
  {
    MessageBox(GetActiveWindow(), e.Message().c_str(),
      "EXBase exception detected",MB_ICONSTOP | MB_OK);
  }

  try
  { // SIMULATE AN OS EXCEPTION - THE VALUE WOULD BE REPLACED 
    // BY GetLastError()
    throw EXSystem_c(__LINE__, __FILE__, ERROR_REGISTRY_RECOVERED,
      EXBase_c::EXWarning);
  }
  catch(EXBase_c& e)
  {
    MessageBox(GetActiveWindow(), e.Message().c_str(),
      "EXBase exception detected",MB_ICONSTOP | MB_OK);
  }

  // UNSET THE EXCEPTION HANDLERS.
  EXBase_c::DeInitialize();
}
