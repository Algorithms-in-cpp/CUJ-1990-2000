Author:  "Eric Gufford" <eric-gufford@home.com> at Internet
Date:    5/21/98  10:29 AM
Priority: Normal
TO: marc briand at MFI-Lawrence
Subject: RE: An undocumented heuristic
------------------------------- Message Contents -------------------------------
/*******************************************************************************
***************************************
                                                                                
                        Exceptions.h
PURPOSE:        DECLARATION OF ALL CLASSES IN THE EXCEPTION LIBRARY

AUTHOR:         ERIC GUFFORD

CREATED:        10/97

COPYRIGHT 1997 - 1998, TRIAD Systems Inc. 
This source code may be used and modified without resitriction as long as the
copyright and author data remains intact.
********************************************************************************
***************************************
USE OF THIS SOURCE CODE IS AT THE USER'S SOLE DISCRETION.  TRIAD Systems Inc.
MAKES NO WARRANTY, EXPRESSED OR IMPLIED,
REGARDING THE APPROPRIATNESS OR MERCHANTABILITY OF THIS SOURCE CODE.  TRIAD
Systems Inc. WILL NOT BE RESPONSIBLE FOR ANY
DAMAGES, MONETARY OR OTHERWISE, ARISING FROM THE USE OF THIS SOURCE CODE.  USE
OF THIS SOURCE CODE, IN ANY WAY, IN WHOLE
OR IN FRAGMENT, CONSTITUES ACCEPTANCE OF THESE TERMS AND CONDITIONS.
********************************************************************************
***************************************
NOTES:  A) ALL EXCEPTION CLASSES INHERIT FROM EXBase_c.
                B) THIS CLASS WILL HANDLE ALL HEAVY LIFTING WITH RESPECT TO
LOGGING AND NETWORK ALERTS (I.E.: SNMP TRAPS)
                C) THE EXCEPTION CLASSES THEMSELVES ARE PLACEHOLDERS WHICH ALLOW
FOR VERY FINE GRAINED EXCEPTION HANDLING.
                D) WHILE ALSO MAINTAINING SIMPLICITY IN THE ACTUAL LOGGING OF
EXCEPTIONS.
********************************************************************************
**************************************/
#ifndef __EXCEPTIONS_H__
#define __EXCEPTIONS_H__
#include <stdexcept>                    // ANSI EXCPEITON INCLUDE
#include <utility>                              // DEFINITION OF pair<>
#include <vector>                               // DEFINITION OF vector<>
#include "EXBase.h"                             // BASE EXCEPTION CLASS
#include "ExceptionMessages.h"  // UNIVERSAL ERROR CODES

#ifdef _USRDLL
        #define SCOPE __declspec(dllexport)
#else
        #define SCOPE __declspec(dllimport)
#endif

/*******************************************************************************
******************************************
EXSanity_c CLASS - SINGLETON CLASS USED FOR OBJECT REGISTRATION
********************************************************************************
*****************************************/
class SCOPE EXSanity_c : public EXBase_c
        {
         public:
                                 EXSanity_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,Msg,eSeverity,typeid(EXSanity_c)) {}
                                 EXSanity_c(int iLine,string const& Source,long
lErr,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,lErr,eSeverity,typeid(EXSanity_c)) {}
                                 EXSanity_c(int iLine,string const& Source,long
lErr,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,lErr,Msg,eSeverity,typeid(EXSanity_c)) {}
                virtual ~EXSanity_c() throw() {}
        };

/*******************************************************************************
******************************************
EXTrace_c CLASS - SINGLETON CLASS USED FOR CODE TRACING
********************************************************************************
*****************************************/
class SCOPE EXTrace_c : public EXBase_c
        {
         public:
                                 EXTrace_c(int iLine,string const& Source,string
const& Msg,Severity_e eSeverity = EXTrace) throw()
                                  :
EXBase_c(iLine,Source,Msg,eSeverity,typeid(EXTrace_c)) {}
                                 EXTrace_c(int iLine,string const& Source,long
lErr,Severity_e eSeverity = EXTrace) throw()
                                  :
EXBase_c(iLine,Source,lErr,eSeverity,typeid(EXTrace_c)) {}
                                 EXTrace_c(int iLine,string const& Source,long
lErr,string const& Msg,Severity_e eSeverity = EXTrace) throw()
                                  :
EXBase_c(iLine,Source,lErr,Msg,eSeverity,typeid(EXTrace_c)) {}
                virtual ~EXTrace_c() throw() {}
        };

/*******************************************************************************
******************************************
EXSystem_c CLASS AND ITS CHILDREN
********************************************************************************
*****************************************/

class SCOPE EXSystem_c : public EXBase_c
        {
         public:
                                 EXSystem_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,Msg,eSeverity,typeid(EXSystem_c)) {}
                                 EXSystem_c(int iLine,string const& Source,long
lErr,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,lErr,eSeverity,typeid(EXSystem_c)) {}
                                 EXSystem_c(int iLine,string const& Source,long
lErr,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,lErr,Msg,eSeverity,typeid(EXSystem_c)) {}
                virtual ~EXSystem_c() throw() {}
         protected:
                                 EXSystem_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity,type_info const& Type) throw()
                                  : EXBase_c(iLine,Source,Msg,eSeverity,Type) {}
                                 EXSystem_c(int iLine,string const& Source,long
lErr,Severity_e eSeverity,type_info const& Type) throw()
                                  : EXBase_c(iLine,Source,lErr,eSeverity,Type)
{}
                                 EXSystem_c(int iLine,string const& Source,long
lErr,string const& Msg,Severity_e eSeverity,type_info const& Type) throw()
                                  :
EXBase_c(iLine,Source,lErr,Msg,eSeverity,Type) {}
        };




class SCOPE EXRegistry_c : public EXSystem_c
        {
         public:
                                 EXRegistry_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXSystem_c(iLine,Source,Msg,eSeverity,typeid(EXRegistry_c)) {}
                                 EXRegistry_c(int iLine,string const&
Source,long lErr,Severity_e eSeverity) throw()
                                  :
EXSystem_c(iLine,Source,lErr,eSeverity,typeid(EXRegistry_c)) {}
                                 EXRegistry_c(int iLine,string const&
Source,long lErr,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXSystem_c(iLine,Source,lErr,Msg,eSeverity,typeid(EXRegistry_c)) {}
                virtual ~EXRegistry_c() throw() {}
         protected:
                                 EXRegistry_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity,type_info const& Type) throw()
                                  : EXSystem_c(iLine,Source,Msg,eSeverity,Type)
{}
                                 EXRegistry_c(int iLine,string const&
Source,long lErr,Severity_e eSeverity,type_info const& Type) throw()
                                  : EXSystem_c(iLine,Source,lErr,eSeverity,Type)
{}
                                 EXRegistry_c(int iLine,string const&
Source,long lErr,string const& Msg,Severity_e eSeverity,type_info const& Type)
throw()
                                  :
EXSystem_c(iLine,Source,lErr,Msg,eSeverity,Type) {}
        };

/*******************************************************************************
******************************************
EXNetwork_c CLASS AND ITS CHILDREN
********************************************************************************
*****************************************/

class SCOPE EXNetwork_c : public EXBase_c
        {
         public:
                                 EXNetwork_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,Msg,eSeverity,typeid(EXNetwork_c)) {}
                                 EXNetwork_c(int iLine,string const& Source,long
lErr,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,lErr,eSeverity,typeid(EXNetwork_c)) {}
                                 EXNetwork_c(int iLine,string const& Source,long
lErr,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,lErr,Msg,eSeverity,typeid(EXNetwork_c)) {}
                virtual ~EXNetwork_c() throw() {}
         protected:
                                 EXNetwork_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity,type_info const& Type) throw()
                                  : EXBase_c(iLine,Source,Msg,eSeverity,Type) {}
                                 EXNetwork_c(int iLine,string const& Source,long
lErr,Severity_e eSeverity,type_info const& Type) throw()
                                  : EXBase_c(iLine,Source,lErr,eSeverity,Type)
{}
                                 EXNetwork_c(int iLine,string const& Source,long
lErr,string const& Msg,Severity_e eSeverity,type_info const& Type) throw()
                                  :
EXBase_c(iLine,Source,lErr,Msg,eSeverity,Type) {}
        };

class SCOPE EXSocket_c : public EXNetwork_c
        {
         public:
                                 EXSocket_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXNetwork_c(iLine,Source,Msg,eSeverity,typeid(EXSocket_c)) {}
                                 EXSocket_c(int iLine,string const& Source,long
lErr,Severity_e eSeverity) throw()
                                  :
EXNetwork_c(iLine,Source,lErr,eSeverity,typeid(EXSocket_c)) {}
                                 EXSocket_c(int iLine,string const& Source,long
lErr,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXNetwork_c(iLine,Source,lErr,Msg,eSeverity,typeid(EXSocket_c)) {}
                virtual ~EXSocket_c() throw() {}
         protected:
                                 EXSocket_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity,type_info const& Type) throw()
                                  : EXNetwork_c(iLine,Source,Msg,eSeverity,Type)
{}
                                 EXSocket_c(int iLine,string const& Source,long
lErr,Severity_e eSeverity,type_info const& Type) throw()
                                  :
EXNetwork_c(iLine,Source,lErr,eSeverity,Type) {}
                                 EXSocket_c(int iLine,string const& Source,long
lErr,string const& Msg,Severity_e eSeverity,type_info const& Type) throw()
                                  :
EXNetwork_c(iLine,Source,lErr,Msg,eSeverity,Type) {}
        };
/*******************************************************************************
******************************************
EXApplication_c CLASS AND ITS CHILDREN
********************************************************************************
*****************************************/

class SCOPE EXApplication_c : public EXBase_c
        {
         public:
                                 EXApplication_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,Msg,eSeverity,typeid(EXApplication_c)) {}
                                 EXApplication_c(int iLine,string const&
Source,long lErr,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,lErr,eSeverity,typeid(EXApplication_c)) {}
                                 EXApplication_c(int iLine,string const&
Source,long lErr,string const& Msg,Severity_e eSeverity) throw()
                                  :
EXBase_c(iLine,Source,lErr,Msg,eSeverity,typeid(EXApplication_c)) {}
                virtual ~EXApplication_c() throw() {}
         protected:
                                 EXApplication_c(int iLine,string const&
Source,string const& Msg,Severity_e eSeverity,type_info const& Type) throw()
                                  : EXBase_c(iLine,Source,Msg,eSeverity,Type) {}
                                 EXApplication_c(int iLine,string const&
Source,long lErr,Severity_e eSeverity,type_info const& Type) throw()
                                  : EXBase_c(iLine,Source,lErr,eSeverity,Type)
{}
                                 EXApplication_c(int iLine,string const&
Source,long lErr,string const& Msg,Severity_e eSeverity,type_info const& Type)
throw()
                                  :
EXBase_c(iLine,Source,lErr,Msg,eSeverity,Type) {}
        };


#endif // __EXCEPTIONS_H__


