// COPYRIGHT (c) 1997, TRIAD Systems, Inc. Permission is granted
// to use this code as long as this copyright notice appears in
// all source files

void EXBase_c::WinException(unsigned int u,
  EXCEPTION_POINTERS* pExp)
{
  stringstream What;
  string Where(BUFSIZ,'\0');
  HMODULE hModule = GetModuleHandle(NULL);
  GetModuleFileName(hModule,const_cast<char*>(Where.c_str()),
    Where.size());
  long lError = 0;
  switch(pExp->ExceptionRecord->ExceptionCode)
  {
    case EXCEPTION_ACCESS_VIOLATION:
         if(pExp->ExceptionRecord->ExceptionInformation[0])
           lError = ACCESS_VIOLATION_WRITE;
         else
           lError = ACCESS_VIOLATION_READ;
         break;
    case EXCEPTION_DATATYPE_MISALIGNMENT:
         lError = DATATYPE_MISALIGNMENT;
         break;
    case EXCEPTION_ARRAY_BOUNDS_EXCEEDED:
         lError = ARRAY_BOUNDS_EXCEEDED;
         break;
    case EXCEPTION_FLT_DENORMAL_OPERAND:
         lError = FLOAT_DENORMAL_OPERAND;
         break;
    case EXCEPTION_FLT_DIVIDE_BY_ZERO:
         lError = FLOAT_DIVIDE_BY_ZERO;
         break;
    case EXCEPTION_FLT_INVALID_OPERATION:
         lError = FLOAT_INVALID_OPERATION;
         break;
    case EXCEPTION_FLT_OVERFLOW:
         lError = FLOAT_OVERFLOW;
         break;
    case EXCEPTION_FLT_STACK_CHECK:
         lError = FLOAT_STACK_CHECK;
         break;
    case EXCEPTION_FLT_UNDERFLOW:
         lError = FLOAT_UNDERFLOW;
         break;
    case EXCEPTION_INT_DIVIDE_BY_ZERO:
         lError = INT_DIVIDE_BY_ZERO;
         break;
    case EXCEPTION_INT_OVERFLOW:
         lError = INT_OVERFLOW;
         break;
    case EXCEPTION_PRIV_INSTRUCTION:
         lError = PRIV_INSTRUCTION;
         break;
    case EXCEPTION_IN_PAGE_ERROR:
         lError = IN_PAGE_ERROR;
         break;
    case EXCEPTION_ILLEGAL_INSTRUCTION:
         lError = ILLEGAL_INSTRUCTION;
         break;
    case EXCEPTION_NONCONTINUABLE_EXCEPTION:
         lError = NONCONTINUABLE_EXCEPTION;
         break;
    case EXCEPTION_STACK_OVERFLOW:
         lError = STACK_OVERFLOW;
         break;
    case EXCEPTION_INVALID_DISPOSITION:
         lError = INVALID_DISPOSITION;
         break;
    case EXCEPTION_GUARD_PAGE:
         lError = GUARD_PAGE;
         break;
    case EXCEPTION_INVALID_HANDLE:
         lError = INVALID_HANDLE;
         break;
    default:
         EXSystem_c(__LINE__,__FILE__,UNKNOWN_EXCEPTION,EXFatal);
         m_OldSEHandler(u,pExp); // CALL THE PREVIOUS HANDLER, 
                                 // SINCE WE REALLY DON'T CARE 
                                 // ABOUT THESE
         break;
  }
  What << "The error occurred at address " 
       << pExp->ExceptionRecord->ExceptionAddress << " of file " 
       << Where;
  if(pExp->ExceptionRecord->ExceptionFlags == 
      EXCEPTION_NONCONTINUABLE)
  { // THIS INDICATES THAT THE PROCESS MUST DIE. ANYTHING ELSE WILL 
    // CAUSE AN EXCEPTION CASCADE!!!
    What << " this process will be terminated";
    EXSystem_c(__LINE__, __FILE__, lError, What.str(),
      (EXCEPTION_NONCONTINUABLE) ? 
         EXBase_c::EXFatal : EXBase_c::EXError);
    terminate(); // AND NAIL THE PROCESS, SINCE NT SAYS 
                 // WE CAN'T GO ON.
  }
  throw EXSystem_c(__LINE__, __FILE__, lError, What.str(),
    (EXCEPTION_NONCONTINUABLE) ? 
       EXBase_c::EXFatal : EXBase_c::EXError);
}
