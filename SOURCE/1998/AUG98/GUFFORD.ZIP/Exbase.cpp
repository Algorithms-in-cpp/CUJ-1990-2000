/**********************************************************************************************************************
                                                                                                        EXBase.cpp
PURPOSE:        DEFINITION OF THE EXBase_c CLASS.

AUTHOR:         ERIC GUFFORD

CREATED:        10/97

COPYRIGHT 1997 - 1998, TRIAD Systems Inc. 
This source code may be used and modified without resitriction as long as the copyright and author data remains intact.
***********************************************************************************************************************
USE OF THIS SOURCE CODE IS AT THE USER'S SOLE DISCRETION.  TRIAD Systems Inc. MAKES NO WARRANTY, EXPRESSED OR IMPLIED,
REGARDING THE APPROPRIATNESS OR MERCHANTABILITY OF THIS SOURCE CODE.  TRIAD Systems Inc. WILL NOT BE RESPONSIBLE FOR ANY
DAMAGES, MONETARY OR OTHERWISE, ARISING FROM THE USE OF THIS SOURCE CODE.  USE OF THIS SOURCE CODE, IN ANY WAY, IN WHOLE
OR IN FRAGMENT, CONSTITUES ACCEPTANCE OF THESE TERMS AND CONDITIONS.
***********************************************************************************************************************
NOTES:  A) THIS CLASS IS THE BASE OF ALL EXCEPTIONS IN THE EXCEPTION LIBRARY
                B) THIS CLASS WILL HANDLE ALL HEAVY LIFTING WITH RESPECT TO LOGGING AND NETWORK ALERTS (I.E.: SNMP TRAPS)
                C) ALL SUBORDINATE CLASSES DO NOTHING OTHER THAN CALL PROTECTED CONSTRUCTORS IN THIS CLASS
                D) EXCEPTION SPECIFICATIONS IN MEMBER FUNCTION DEFINITIONS CAUSE CLASS VIEW NOT TO SEE THESE FUNCTIONS
                E) THEREFORE, THESE SPECIFICATIONS HAVE BEEN COMMENTED IN ALL MEMBER FUNCTION DEFINITIONS.
**********************************************************************************************************************/
#pragma warning(disable:4786)
#include <utility>
#include <string>
#include <xstring>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <winsock2.h>
#include <windows.h>
#include <winnt.h>
#include <comdef.h>
using namespace std;
#include "Registry.h"
#include "Exceptions.h"

const long                              EXBase_c::sm_clSerialNumber = 0xC0001000;
_se_translator_function EXBase_c::m_OldSEHandler = NULL;
terminate_function              EXBase_c::m_OldTerminationHandler = NULL;
unexpected_function             EXBase_c::m_OldUnexpectedHandler = NULL;
EXBase_c::Modules_t             EXBase_c::m_RegisteredApps;

/**********************************************************************************************************************
                                                                                                SetSanity
PURPOSE: SETS THE INTEGRITY OF THIS OBJECT
***********************************************************************************************************************
NOTES:  A) m_clSerialNumber IS MUTABLE, SO IT CAN BE CHANGED HERE.
                B) THIS FUNCTION IS DECLARED const SO IT CAN BE CALLED FROM ANYWHERE, REGARDLESS OF CV QUALIFIERS.
**********************************************************************************************************************/
inline void EXBase_c::SetSanity() const //throw(Something)
{
 m_clSerialNumber = sm_clSerialNumber;
}
/**********************************************************************************************************************
                                                                                                ClearSanity
PURPOSE: CLEARS THE INTEGRITY OF THIS OBJECT
***********************************************************************************************************************
NOTES:  A) m_clSerialNumber IS MUTABLE, SO IT CAN BE CHANGED HERE.
**********************************************************************************************************************/
inline void EXBase_c::ClearSanity() const //throw(Something)
{
 SanityCheck();
 m_clSerialNumber = 0L;
}
/**********************************************************************************************************************
                                                                                                ClearSanity
PURPOSE: CHECKS THE INTEGRITY OF THIS OBJECT
***********************************************************************************************************************
NOTES:  A) IF THE CHECK FAILS, THIS FUNCTION WILL THROW
**********************************************************************************************************************/
inline void EXBase_c::SanityCheck() const //throw(Something)
{ 
  if((this == NULL) || (m_clSerialNumber != sm_clSerialNumber))
        throw logic_error("Object integrity has been compromised!!");
}
/**********************************************************************************************************************
                                                                                                EXBase_c
PURPOSE: DEFAULT CONSTRUCTOR
***********************************************************************************************************************
NOTES:  A) THIS SHOULD NOT BE USED BY ANYTHING OUTSIDE OF THIS CLASS
**********************************************************************************************************************/
EXBase_c::EXBase_c() // throw()
{
 m_dwError = 0;
}
/**********************************************************************************************************************
                                                                                                EXBase_c
PURPOSE: OPTIONAL CONSTRUCTOR
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
EXBase_c::EXBase_c(int iLine,string const& Source,string const& Msg,Severity_e eSeverity,type_info const& Type) // throw()
 : m_iLine(iLine),m_File(Source.c_str()),m_Message(Msg.c_str()),m_eSeverity(eSeverity),m_dwError(0)
{ 
 Log(Type.name());
}
/**********************************************************************************************************************
                                                                                                EXBase_c
PURPOSE: OPTIONAL CONSTRUCTOR
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
EXBase_c::EXBase_c(int iLine,string const& Source,long lError,Severity_e eSeverity,type_info const& Type) // throw()
 : m_iLine(iLine),m_File(Source.c_str()),m_eSeverity(eSeverity),m_dwError(lError)
{
 Log(Type.name());
}
/**********************************************************************************************************************
                                                                                                EXBase_c
PURPOSE: OPTIONAL CONSTRUCTOR
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
EXBase_c::EXBase_c(int iLine,string const& Source,long lError,string const& Msg,Severity_e eSeverity,type_info const& Type) // throw()
 : m_iLine(iLine),m_File(Source.c_str()),m_UserMessage(Msg.c_str()),m_eSeverity(eSeverity),m_dwError(lError)
{
 Log(Type.name());
}
/**********************************************************************************************************************
                                                                                                ~EXBase_c
PURPOSE: CLASS DESTRUCTOR
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
EXBase_c::~EXBase_c() // throw()
{
}
/**********************************************************************************************************************
                                                                                                Message
PURPOSE: 'GETS' THE VALUE OF THIS MEMBER VARIABLE
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
string const& EXBase_c::Message() const // throw()
{
 return m_Message;
}
/**********************************************************************************************************************
                                                                                                Source
PURPOSE: 'GETS' THE VALUE OF THIS MEMBER VARIABLE
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
string const& EXBase_c::Source() const // throw()
{
 return m_Source;
}
/**********************************************************************************************************************
                                                                                                Source
PURPOSE: 'SETS' THE VALUE OF THIS MEMBER VARIABLE
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
string const& EXBase_c::Source(string const& x) // throw()
{
 return m_Source = x;
}
/**********************************************************************************************************************
                                                                                                Error
PURPOSE: 'GETS' THE VALUE OF THIS MEMBER VARIABLE
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
DWORD const EXBase_c::Error() const // throw()
{
 return m_dwError;
}
/**********************************************************************************************************************
                                                                                                Severity
PURPOSE: 'GETS' THE VALUE OF THIS MEMBER VARIABLE
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
EXBase_c::Severity_e const EXBase_c::Severity() const // throw()
{ 
 return m_eSeverity;
}
/**********************************************************************************************************************
                                                                                                Log
PURPOSE: LOGS THE ERROR IN THE EVENT LOG AND SETS AN INTERNAL MESSAGE STRING
***********************************************************************************************************************
NOTES:  A) IF THE ERROR HAS NO MESSAGE TEXT, IT IS ASSUMED TO BE IN A MESSAGE TABLE
                B) IF SO, HELPER FUNCTIONS ARE CALLED TO SET UP MEMBER VARIABLES
                C) IF THE HELPER FUNCTIONS CAN'T FIND IT, A GENERIC ERROR IS POSTED.
                D) IF THE ERROR DOES HAVE MESSAGE TEXT, THIS TEXT IS LOGGED AND NO LOOKUP IS PERFORMED.
**********************************************************************************************************************/
void EXBase_c::Log(string const& Type) // throw()
{
 string Header = BuildHeader(Type);
 if(m_dwError != 0)
        {
         if((!IsAppError()) && (!IsSystemError()))
                {
                 m_Message = "An unknown error has occurred - this is probably a bug in the component that threw";
                 GetErrorMessage(FORMAT_MESSAGE_FROM_STRING);
                }
        }
 else
         GetErrorMessage(FORMAT_MESSAGE_FROM_STRING);
 bool bIsLogged = LogError(Header);
}
/**********************************************************************************************************************
                                                                                                IsSystemError
PURPOSE: DETERMINES IF THE ERROR CODE BELONGS TO THE OS OR NOT.
***********************************************************************************************************************
NOTES:  A) THE FIRST 256 FACILITY CODES BELONG TO NT.
                B) 257 BELONGS TO THIS LIBRARY
                C) THE REST ARE APP DEFINED.
                D) THEREFORE, ANY FACILITY LESS THAN THIS LIBRARY MUST BELONG TO THE SYSTEM!
**********************************************************************************************************************/
bool EXBase_c::IsSystemError() // throw()
{
 if(((m_dwError & FACILITY_MASK) >> 16)  >= FACILITY_EXCEPTIONS)
        return false;
 if(!GetErrorMessage(FORMAT_MESSAGE_FROM_SYSTEM)) // SOME SYSTEM ERRORS (I.E.: WINSOCK) HAVE NO MESSAGE TEXT & NO MESSAGE TABLE
        if(m_UserMessage.empty())
                {
                 stringstream Msg;
                 Msg << "System error '" << m_dwError << "' has been detected.  The operating system has no message for this error";
                 m_Message = Msg.str();
                }
        else
                m_Message = "";
 return true;
}
/**********************************************************************************************************************
                                                                                                BuildHeader
PURPOSE: BUILDS A DESCRIPTIVE HEADER FOR THE ERROR
***********************************************************************************************************************
NOTES:  A) THIS HEADER IS ONLY LOGGED TO THE EVENT LOG.
                B) THE INTERNAL MESSAGE TEXT REMAINS UNTOUCHED.
                C) THE INTENT IS TO PROVIDE A MORE USER-FRIENDLY ERROR LOG.
                D) WHILE LEAVING OFF THE FLUFF FOR DEBUGGING.
**********************************************************************************************************************/
string EXBase_c::BuildHeader(string const& Type) // throw()
{
 stringstream Header;
 string Class = Type.substr(Type.find_first_not_of("class "));
 Header << "An '" << Class << "' exception, indicating ";
 // TO DEAL WITH SEVERITY LEVELS FROM THE ERROR CODE, USE THE FOLLOWING
 //dwCode = (m_dwError & SEVERITY_MASK) >> 30;
 switch(Severity())
        {
         case EXTrace:
                Header << "a program trace";
                break;
         case EXWarning:
                Header << "a warning";
                break;
         case EXError:
                Header << "an eror";
                break;
         case EXFatal:
                Header << "a serious eror";
                break;
         default:
                Header << "an eror of unknown consequence";
                break;
        }
 Header << ", was detected at line " << m_iLine << " of file '" << m_File << "'";
 return string(Header.str());
}
/**********************************************************************************************************************
                                                                                                GetErrorMessage
PURPOSE: LOOKS UP THE ERROR CODE AND FORMATS THE ERROR MESSAGE
***********************************************************************************************************************
NOTES:  A) FORMAT MESSAGE IS USED FOR THE LOOKUP.
                B) THIS FUNCTION WILL LOOK IN EITHER THE SYSTEM MESSAGE TABLE, OR THE APP MESSAGE TABLE.
                C) THE LATTER IS BASED ON HMODULE, WHICH IS WHY APPS MUST REGISTER THEIR MESSAGE TABLE!
                D) CONTENTS OF THE SECOND PARAMETER TO FormatMessage() WILL VARY BASED ON FLAG SETTINGS
**********************************************************************************************************************/
bool EXBase_c::GetErrorMessage(int const iFlags,HMODULE hModule) // throw()
{
 LPCVOID lpMsgBuf = NULL,lpOutput = NULL;
 DWORD dwRetVal = 0,dwLanguage = MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT);
 if(iFlags & FORMAT_MESSAGE_FROM_HMODULE)
        lpMsgBuf = hModule;
 else if(iFlags & FORMAT_MESSAGE_FROM_STRING)
        lpMsgBuf = m_Message.c_str();
 string Output(2048,'\0'); // A 2K BUFFER SHOULD BE BIG ENOUGH
 if(m_UserMessage.empty())
        {
         if((dwRetVal = FormatMessage(iFlags | FORMAT_MESSAGE_IGNORE_INSERTS,lpMsgBuf,m_dwError,dwLanguage,
                                                                  const_cast<char*>(Output.c_str()),Output.size(),NULL)) == 0)
                dwRetVal = GetLastError();
        }
 else
        {
         char* pStrings[2];
         pStrings[0] = "";
         pStrings[1] = const_cast<char*>(m_UserMessage.c_str());
         if((dwRetVal = FormatMessage(iFlags,lpMsgBuf,m_dwError,dwLanguage,
                                                                  const_cast<char*>(Output.c_str()),Output.size(),&pStrings[0])) == 0)
                 dwRetVal = GetLastError(); // USEFUL FOR DEBUGGING
        }
 if(Output[0] == NULL)
        return false; // IF THE BUFFER ISN'T SET, THE CALL FAILED.
 m_Message = Output;
 return true;
}
/**********************************************************************************************************************
                                                                                                Message
PURPOSE: 'GETS' THE VALUE OF THIS MEMBER VARIABLE
***********************************************************************************************************************
NOTES:  A) THIS FUNCTION WILL CHECK WHETHER THE map<> IS EMPTY PRIOR TO SEARCHING.
                B) THIS IS BECAUSE, AT LEAST IN VC 5.0, m_RegisteredApps.begin() CRASHES THE IDE.
                C) THIS WILL ONLY HAPPEN IF THE map<> IS EMPTY.  ALSO, STEPPING INTO begin() CRAHSES THE IDE.
**********************************************************************************************************************/
bool EXBase_c::IsAppError() // throw()
{
 if(m_RegisteredApps.empty())
        return false;
 DWORD dwFacility = (m_dwError & FACILITY_MASK) >> 16;
 for(Modules_t::iterator i = m_RegisteredApps.begin();i != m_RegisteredApps.end();i++)
        if((*i).first == dwFacility)
                {
                 string Name(BUFSIZ,'\0');
                 GetModuleFileName((*i).second,const_cast<char*>(Name.c_str()),Name.size());
                 Name = Name.substr(Name.find_last_of('\\')+1);
                 Name.resize(Name.find_last_of('.'));
                 Source(Name);
                 return GetErrorMessage(FORMAT_MESSAGE_FROM_HMODULE,(*i).second);
                }
 return false;
}
/**********************************************************************************************************************
                                                                                                Message
PURPOSE: 'GETS' THE VALUE OF THIS MEMBER VARIABLE
***********************************************************************************************************************
NOTES:  
**********************************************************************************************************************/
bool EXBase_c::LogError(string const& Header)
{
 HANDLE hEventLog = RegisterEventSource(NULL,(Source().empty()) ? "Exceptions" : Source().c_str());
 int iType = 0;
 switch(m_eSeverity)
        {
         case EXTrace:
                iType = EVENTLOG_INFORMATION_TYPE;
                break;
         case EXWarning:
                iType = EVENTLOG_WARNING_TYPE;
                break;
         case EXError:
         case EXFatal:
                iType = EVENTLOG_ERROR_TYPE;
                break;
         default:
                iType = 0;
                break;
        }
 string ThisMessage = Header;
 if(!IsAppError()) 
        ThisMessage += " The message is : " + m_Message + " ";
 if(!m_UserMessage.empty())
        ThisMessage += m_UserMessage;
 char const* lpszMessages = ThisMessage.c_str();
 bool bRetVal = (ReportEvent(hEventLog,iType,0,(DWORD) m_dwError,NULL,1,0,&lpszMessages,NULL) == 0) ? false : true;
 DeregisterEventSource(hEventLog);
 return bRetVal;
}
/**********************************************************************************************************************
                                                                                                Initialize
PURPOSE: SETS UP SYSTEM-LEVEL EXCEPTION REDIRECTION
***********************************************************************************************************************
NOTES:  A) THIS IS A STATIC MEMBER FUNCTION THAT IS ONLY CALLED ONCE PER THREAD.
                B) STRUCTURED EXCEPTIONS ARE ROUTED THROUGH ANOTHER STATIC MEMBER FUNCTION
                C) AS ARE TERMINATION HANDLING AND UNEXPECTED HANDLING.
                D) SINCE THIS WILL BE CALLED ONCE PER THREAD, WE NEED TO ENSURE THAT THE ORIGINAL HANDLER IS REACHABLE
                E) THIS IS BECAUSE, FOR EXCEPTIONS WE DON'T CARE ABOUT, WE NEED TO PASS 'EM THROUGH
**********************************************************************************************************************/
void EXBase_c::Initialize() // throw()
{
 _se_translator_function OldSEHandler                   = _set_se_translator(WinException);
 terminate_function              OldTerminationHandler  = set_terminate(Bail);
 unexpected_function     OldUnexpectedHandler   = set_unexpected(Unexpected);
 if(OldSEHandler != WinException)               // THIS IS THE FIRST TIME WE'VE REROUTED
        m_OldSEHandler = OldSEHandler;          // SO LET'S HANG ON TO THE FUNCTION POINTER
 if(OldTerminationHandler != Bail)              // SAME
        m_OldTerminationHandler = OldTerminationHandler;
 if(OldUnexpectedHandler != Unexpected) // SAME
        m_OldUnexpectedHandler = OldUnexpectedHandler;
}
/**********************************************************************************************************************
                                                                                                Register
PURPOSE: 'REGISTERS' A MESSAGE TABLE WITH THE EVENT LOGGER
***********************************************************************************************************************
NOTES:  A) USED FOR LOOKING UP ERRORS PRIOR TO LOGGING.
                B) THE MESSAGE TABLE SHOULD BE THE SAME AS THAT USED BY THE EVENT LOGGER.
                C) TO ENSURE THIS, THE FUNCTION WILL ADD THE APPROPRIATE REGISTRY KEY AND VALUES FOR THE EVENT LOGGER.
                D) THEREFORE, THIS FUNCTION SHOULD ONLY BE CALLED ONCE PER APP.
**********************************************************************************************************************/
bool EXBase_c::Register(string const& Library,DWORD dwFacility) // throw()
{
 // LOAD THE REQUESTED LIBRARY AS A RESOURCE-ONLY DLL
 HMODULE hModule = LoadLibraryEx(Library.c_str(),NULL,DONT_RESOLVE_DLL_REFERENCES);
 if(hModule == NULL)
        return false;
 // THE NAME PROVIDED MAY NOT BE FULLY QUALIFIED.  WE NEED FULL QUALIFIACTION FOR THE EVENT LOG
 string FullName(BUFSIZ,'\0');
 DWORD dwSize = GetModuleFileName(hModule,const_cast<char*>(FullName.c_str()),FullName.size());
 FullName.resize(dwSize); // GET RID OF ALL TRAILING NULLS
 // WITH THAT DONE, WE CAN NOW ADD THIS STUFF TO THE REGISTRY
 Registry_c Registry(HKEY_LOCAL_MACHINE);
 Registry.OpenKey("SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application");
 string Name = Library.substr(Library.find_last_of('\\')+1);
 Name.resize(Name.find_last_of('.'));
 Registry.AddKey(Name,Registry_c::KeyPermanent);
 Registry.OpenKey(Name);
 Registry.AddValue("EventMessageFile",FullName);
 Registry.AddValue("TypesSupported",7);
 m_RegisteredApps.push_back(ModulePair_t(dwFacility,hModule));
 return true;
}
/**********************************************************************************************************************
                                                                                                UnRegister
PURPOSE: 'REGISTERS' A MESSAGE TABLE DLL WITH THIS CLASS
***********************************************************************************************************************
NOTES:  A) USED FOR LOOKING UP ERRORS PRIOR TO LOGGING.
                B) THE DLL SHOULD BE THE SAME AS THAT USED BY THE EVENT LOGGER.
                C) IF THIS IS NOT DONE, GENERIC ERROR MESSAGES WILL BE LOGGED INSTEAD OF THE ONES YOU WANT!
                D) THIS FUNCTION SHOULD ONLY BE CALLED ONCE PER APP.
**********************************************************************************************************************/
bool EXBase_c::UnRegister(DWORD const dwFacility) // throw()
{
 for(Modules_t::iterator i = m_RegisteredApps.begin();i != m_RegisteredApps.end();i++)
        if((*i).first == dwFacility)
                {
                 FreeLibrary((*i).second);
                 m_RegisteredApps.erase(i);
                 break;
                }
 return true;
}
/**********************************************************************************************************************
                                                                                                DeInitialize
PURPOSE: REVERTS SYSTEM-LEVEL EXCEPTION REDIRECTION TO ITS ORIGINAL STATE
***********************************************************************************************************************
NOTES:  A) THIS IS A STATIC MEMBER FUNCTION THAT IS ONLY CALLED ONCE PER THREAD.
                B) EACH THREAD SHOULD CALL THIS FUNCTION PRIOR TO DYING.
                C) THIS IS NOT NECCESSARY, BUT IT IS GOOD FORM.
**********************************************************************************************************************/
void EXBase_c::DeInitialize() // throw()
{
 _set_se_translator(m_OldSEHandler);
 set_terminate(m_OldTerminationHandler);
 set_unexpected(m_OldUnexpectedHandler);
}
/**********************************************************************************************************************
                                                                                                WinException
PURPOSE: REDIRECTOR FOR STRUCTURED EXCEPTIONS
***********************************************************************************************************************
NOTES:  A) VERSY SIMPLE - IT JUST THROWS A WELL KNOWN EXCEPTION FROM THIS LIBRARY
                B) A BENEFICIAL SIDE EFFECT IS THAT THE ERROR CODE WILL BE LOOKED UP AND A MESSAGE WRITTEN TO THE LOG.
                C) THIS MESSAGE WILL ALSO BE IN THE EXCEPTION OBJECT THAT IS GENERATED.
**********************************************************************************************************************/
void EXBase_c::WinException(unsigned int u,EXCEPTION_POINTERS* pExp)
{
 stringstream What;
 string Where(BUFSIZ,'\0');
 HMODULE hModule = GetModuleHandle(NULL);
 GetModuleFileName(hModule,const_cast<char*>(Where.c_str()),Where.size());
 long lError = 0;
 switch(pExp->ExceptionRecord->ExceptionCode)
        {
         case EXCEPTION_ACCESS_VIOLATION:
                if(pExp->ExceptionRecord->ExceptionInformation[0])
                        lError = ACCESS_VIOLATION_WRITE;
                else
                        lError = ACCESS_VIOLATION_READ;
                break;
         case EXCEPTION_DATATYPE_MISALIGNMENT:
                lError = DATATYPE_MISALIGNMENT;
                break;
         case EXCEPTION_ARRAY_BOUNDS_EXCEEDED:
                lError = ARRAY_BOUNDS_EXCEEDED;
                break;
         case EXCEPTION_FLT_DENORMAL_OPERAND:
                lError = FLOAT_DENORMAL_OPERAND;
                break;
         case EXCEPTION_FLT_DIVIDE_BY_ZERO:
                lError = FLOAT_DIVIDE_BY_ZERO;
                break;
         case EXCEPTION_FLT_INVALID_OPERATION:
                lError = FLOAT_INVALID_OPERATION;
                break;
         case EXCEPTION_FLT_OVERFLOW:
                lError = FLOAT_OVERFLOW;
                break;
         case EXCEPTION_FLT_STACK_CHECK:
                lError = FLOAT_STACK_CHECK;
                break;
         case EXCEPTION_FLT_UNDERFLOW:
                lError = FLOAT_UNDERFLOW;
                break;
         case EXCEPTION_INT_DIVIDE_BY_ZERO:
                lError = INT_DIVIDE_BY_ZERO;
                break;
         case EXCEPTION_INT_OVERFLOW:
                lError = INT_OVERFLOW;
                break;
         case EXCEPTION_PRIV_INSTRUCTION:
                lError = PRIV_INSTRUCTION;
                break;
         case EXCEPTION_IN_PAGE_ERROR:
                lError = IN_PAGE_ERROR;
                break;
         case EXCEPTION_ILLEGAL_INSTRUCTION:
                lError = ILLEGAL_INSTRUCTION;
                break;
         case EXCEPTION_NONCONTINUABLE_EXCEPTION:
                lError = NONCONTINUABLE_EXCEPTION;
                break;
         case EXCEPTION_STACK_OVERFLOW:
                lError = STACK_OVERFLOW;
                break;
         case EXCEPTION_INVALID_DISPOSITION:
                lError = INVALID_DISPOSITION;
                break;
         case EXCEPTION_GUARD_PAGE:
                lError = GUARD_PAGE;
                break;
         case EXCEPTION_INVALID_HANDLE:
                lError = INVALID_HANDLE;
                break;
         default:
                EXSystem_c(__LINE__,__FILE__,UNKNOWN_EXCEPTION,EXFatal);
                m_OldSEHandler(u,pExp); // CALL THE PREVIOUS HANDLER, SINCE WE REALLY DON'T CARE ABOUT THESE
                break;
        }
 What << "The error occurred at address " << pExp->ExceptionRecord->ExceptionAddress << " of file " << Where;
 if(pExp->ExceptionRecord->ExceptionFlags == EXCEPTION_NONCONTINUABLE)
        { // THIS INDICATES THAT THE PROCESS MUST DIE. ANYTHING ELSE WILL CAUSE AN EXCEPTION CASCADE!!!
         What << " this process will be terminated";
         EXSystem_c(__LINE__,__FILE__,lError,What.str(),(EXCEPTION_NONCONTINUABLE) ? EXBase_c::EXFatal : EXBase_c::EXError);
         terminate(); // AND NAIL THE PROCESS, SINCE NT SAYS WE CAN'T GO ON.
        }
 throw EXSystem_c(__LINE__,__FILE__,lError,What.str(),(EXCEPTION_NONCONTINUABLE) ? EXBase_c::EXFatal : EXBase_c::EXError);
}
/**********************************************************************************************************************
                                                                                                Bail
PURPOSE: REDIRECTOR FOR TERMINATION HANDLING.
***********************************************************************************************************************
NOTES:  A) IT JUST LOGS AN ERROR INTO THE EVENT LOG AND ABORTS THE PROGRAM.
                B) USEFUL FOR DEBUGGING APP SHUTDOWN BUGS LIKE HeapAbort() CALLS.
**********************************************************************************************************************/
void EXBase_c::Bail()
{
 //EXSystem_c(__LINE__,__FILE__,PROGRAM_ABORTED,EXBase_c::EXFatal);
 abort();
}
/**********************************************************************************************************************
                                                                                                Unexpected
PURPOSE: REDIRECTOR FOR UNEXPECTED EXCEPTIONS
***********************************************************************************************************************
NOTES:  A) IT JUST LOGS THE SITUATION TO THE EVENT LOG AND CALLS THE TERMINATION HANDLER TO ABORT THE PROCESS.
                B) USEFUL FOR DEBUGGING UNEXPECTED EXCEPTIONS AND SUCH.
                C) WILL ONLY BE TRIGGERED WHEN AN EXCEPTION THROWS AN EXCEPTION (I.E.: ACCESS VIOLATION).
**********************************************************************************************************************/
void EXBase_c::Unexpected()
{
 //EXSystem_c(__LINE__,__FILE__,UNEXPECTED_EXCEPTION,EXBase_c::EXFatal);
 Bail();
}

