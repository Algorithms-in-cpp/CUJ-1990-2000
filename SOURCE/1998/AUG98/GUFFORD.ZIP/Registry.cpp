Author:  "Eric Gufford" <eric-gufford@home.com> at Internet
Date:    5/21/98  10:29 AM
Priority: Normal
TO: marc briand at MFI-Lawrence
Subject: RE: An undocumented heuristic
------------------------------- Message Contents -------------------------------
/*******************************************************************************
***************************************
                                                                                
                        Registry.cpp
PURPOSE:        DEFINITION OF THE Registry_c CLASS.

AUTHOR:         ERIC GUFFORD

CREATED:        10/97

COPYRIGHT 1997 - 1998, TRIAD Systems Inc. 
This source code may be used and modified without resitriction as long as the
copyright and author data remains intact.
********************************************************************************
***************************************
USE OF THIS SOURCE CODE IS AT THE USER'S SOLE DISCRETION.  TRIAD Systems Inc.
MAKES NO WARRANTY, EXPRESSED OR IMPLIED,
REGARDING THE APPROPRIATNESS OR MERCHANTABILITY OF THIS SOURCE CODE.  TRIAD
Systems Inc. WILL NOT BE RESPONSIBLE FOR ANY
DAMAGES, MONETARY OR OTHERWISE, ARISING FROM THE USE OF THIS SOURCE CODE.  USE
OF THIS SOURCE CODE, IN ANY WAY, IN WHOLE
OR IN FRAGMENT, CONSTITUES ACCEPTANCE OF THESE TERMS AND CONDITIONS.
********************************************************************************
***************************************
NOTES:  
********************************************************************************
**************************************/
#pragma warning(disable:4786) // DISBALE THE 'BROWSER OUTPUT TRUNCATED TO 255'
WARNING
#include <utility>
#include <string>
#include <xstring>
#include <vector>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <winsock2.h>
#include <windows.h>
#include <winnt.h>
#include <comdef.h>
using namespace std;
#include "Registry.h"
//#include "Exceptions.h"

/*******************************************************************************
***************************************
                                                                                
                Registry_c
PURPOSE: CLASS CONSTRUCTOR
********************************************************************************
***************************************
NOTES:  
********************************************************************************
**************************************/
Registry_c::Registry_c(HKEY const& hWhichKey)
 : m_hKey(hWhichKey)
{
}
/*******************************************************************************
***************************************
                                                                                
                ~Registry_c
PURPOSE: CLASS DESTRUCTOR
********************************************************************************
***************************************
NOTES:  
********************************************************************************
**************************************/
Registry_c::~Registry_c()
{
 RegCloseKey(m_hKey);
}
/*******************************************************************************
***************************************
                                                                                
                OpenKey
PURPOSE: OPENS THE REQUESTED KEY 
********************************************************************************
***************************************
NOTES:  A) USES THE CURRENT REGISTRY HIVE
********************************************************************************
**************************************/
bool Registry_c::OpenKey(string const& ThisHive)
{
 long lRetVal = 0;
 if((lRetVal = RegOpenKeyEx(m_hKey,ThisHive.c_str(),0,KEY_ALL_ACCESS,&m_hKey))
!= ERROR_SUCCESS)
         ;// EXRegistry_c(__LINE__,__FILE__,lRetVal,EXError);
 return (lRetVal == ERROR_SUCCESS) ? true : false;
}
/*******************************************************************************
***************************************
                                                                                
                AddKey
PURPOSE: ADDS THE REQUESTED KEY 
********************************************************************************
***************************************
NOTES:  A) USES THE CURRENT REGISTRY HIVE
********************************************************************************
**************************************/
bool Registry_c::AddKey(string const& WhichKey,KeyType_e const eType)
throw(EXRegistry_c)
{
 HKEY   hKey = NULL;
 DWORD  dwDisposition = 0;
 long   lRetVal = 0;
 if((lRetVal = RegCreateKeyEx(m_hKey,WhichKey.c_str(),0,"",
                                                          (eType ==
KeyPermanent) ? REG_OPTION_NON_VOLATILE : REG_OPTION_VOLATILE,
                                                          KEY_ALL_ACCESS,NULL,&h
Key,&dwDisposition)) != ERROR_SUCCESS)
        ;// EXRegistry_c(__LINE__,__FILE__,lRetVal,EXWarning);
 return (lRetVal == ERROR_SUCCESS) ? true : false;
}
/*******************************************************************************
***************************************
                                                                                
                DeleteKey
PURPOSE: DELETES THE REQUESTED KEY 
********************************************************************************
***************************************
NOTES:  A) USES THE CURRENT REGISTRY HIVE
********************************************************************************
**************************************/
bool Registry_c::DeleteKey(string const& WhichKey) throw(EXRegistry_c)
{
 HKEY   hKey = NULL;
 DWORD  dwDisposition = 0;
 long   lRetVal = 0;
 if((lRetVal = RegDeleteKey(m_hKey,WhichKey.c_str())) != ERROR_SUCCESS)
        ;// EXRegistry_c(__LINE__,__FILE__,lRetVal,EXWarning);
 return (lRetVal == ERROR_SUCCESS) ? true : false;
}
/*******************************************************************************
***************************************
                                                                                
                FindKey
PURPOSE: FINDS THE REQUESTED KEY 
********************************************************************************
***************************************
NOTES:  A) USES THE CURRENT REGISTRY HIVE
********************************************************************************
**************************************/
bool Registry_c::FindKey(string const& WhichKey,bool bOpen)
{
 string ThisKey(BUFSIZ,'\0');
 DWORD dwIndex = 0,dwLength = ThisKey.size()+1;
 FILETIME ftLastWritten;
 while(RegEnumKeyEx(m_hKey,dwIndex++,const_cast<char*>(ThisKey.c_str()),&dwLengt
h,NULL,NULL,NULL,&ftLastWritten) != ERROR_NO_MORE_ITEMS)
        {
         if(WhichKey != ThisKey)
                continue;
         return (bOpen) ? OpenKey(WhichKey) : true;;
        }
 return false;
}
/*******************************************************************************
***************************************
                                                                                
                FindKey
PURPOSE: ADDS THE REQUESTED VALUE
********************************************************************************
***************************************
NOTES:  A) USES THE CURRENT REGISTRY KEY
********************************************************************************
**************************************/
bool Registry_c::AddValue(string const& ValueName,string& Value)
{
 long lRetVal = 0;
 //Value.resize(Value.length()+1,'\0'); // STRINGS NEED TWO TERMINATING NULLS TO
WORK RIGHT
 lRetVal = RegSetValueEx(m_hKey,ValueName.c_str(),0,REG_SZ,(BYTE*)
Value.c_str(),Value.length()+1);
 return (lRetVal == ERROR_SUCCESS) ? true : false;
}
/*******************************************************************************
***************************************
                                                                                
                FindKey
PURPOSE: ADDS THE REQUESTED VALUE
********************************************************************************
***************************************
NOTES:  A) USES THE CURRENT REGISTRY KEY
********************************************************************************
**************************************/
bool Registry_c::AddValue(string const& ValueName,DWORD const Value)
{
 long lRetVal = 0;
 lRetVal = RegSetValueEx(m_hKey,ValueName.c_str(),0,REG_DWORD,(BYTE*)
&Value,sizeof(DWORD));
 return (lRetVal == ERROR_SUCCESS) ? true : false;
}
/*******************************************************************************
***************************************
                                                                                
                DeleteValue
PURPOSE: DELETES THE REQUESTED VALUE
********************************************************************************
***************************************
NOTES:  A) USES THE CURRENT REGISTRY KEY
********************************************************************************
**************************************/
bool Registry_c::DeleteValue(string const& ValueName)
{
 long lRetVal = 0;
 if((lRetVal = RegDeleteValue(m_hKey,ValueName.c_str())) != ERROR_SUCCESS)
        ;// EXRegistry_c(__LINE__,__FILE__,lRetVal,EXWarning);
 return (lRetVal == ERROR_SUCCESS) ? true : false;
}
/*******************************************************************************
***************************************
                                                                                
                FindValue
PURPOSE: FINDS THE REQUESTED VALUE
********************************************************************************
***************************************
NOTES:  A) USES THE CURRENT REGISTRY KEY
********************************************************************************
**************************************/
bool Registry_c::FindValue(string const& ValueName)
{
 _variant_t ThisValue = GetValue(ValueName);
 return (ThisValue == _variant_t("")) ? false : true;
}
/*******************************************************************************
***************************************
                                                                                
                GetValue
PURPOSE: GETS THE REQUESTED VALUE
********************************************************************************
***************************************
NOTES:  A) USES THE CURRENT REGISTRY KEY
********************************************************************************
**************************************/
_variant_t Registry_c::GetValue(string const& WhichValue) throw(EXRegistry_c)
{
 string Value(BUFSIZ,'\0');
 DWORD dwValueType = 0,dwValueSize = Value.size();
 long lRetVal = 0;
 if((lRetVal =
RegQueryValueEx(m_hKey,WhichValue.c_str(),NULL,&dwValueType,(LPBYTE)
Value.c_str(),&dwValueSize)) != ERROR_SUCCESS)
         throw ;// EXRegistry_c(__LINE__,__FILE__,lRetVal,EXError);
 Value.resize(dwValueSize);
 _variant_t Result;
 switch(dwValueType)
        {
         case REG_DWORD:
                Result = *((long*) Value.c_str());
                break;
         case REG_EXPAND_SZ:
                {
                 string Output; // 4K BUFFER FOR EXPANSION STRINGS.
                 DWORD  dwSize =
ExpandEnvironmentStrings(Value.c_str(),const_cast<char*>(Output.c_str()),0); //
GET THE CORRECT SIZE FIRST.
                 Output.resize(dwSize);
                                dwSize =
ExpandEnvironmentStrings(Value.c_str(),const_cast<char*>(Output.c_str()),Output.
size()); // GET THE STRINGS NOW.
                 Result = Output.c_str();
                }
                break;
         case REG_SZ:
                Result = Value.c_str();
         default:
                break;
        }
 return _variant_t(Result);
}

