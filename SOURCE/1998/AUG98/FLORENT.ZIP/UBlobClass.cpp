// UBlobClass.cpp  Listing 5
// simple object I/O for Paradox Blob fields implementation
//---------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include <strstrea.h>
#include "UBlobClass.h"
TBlobClassBase::CreateMap* TBlobClassBase::pCreateMap = 0;
//---------------------------------------------------------------
streampos TMemStr::Size()
{
       streampos savePos = tellg();
       streampos size =
            rdbuf()->seekoff(0, ios::end, ios::in | ios::out);
       seekg(savePos);
       return size;
}
//---------------------------------------------------------------
void TMemStr::ToTMemoryStream(TMemoryStream * bstr)
{
     streampos size = Size();
     bstr->Write(str(), size);
     rdbuf()->freeze(0);
}
//---------------------------------------------------------------
void TMemStr::FromTMemoryStream(TMemoryStream * bstr)
{
     streampos size = bstr->Size;
     if (size) {
     	char * buf = new char[size];
     	bstr->Read(buf, size);
     	write(buf, size);
     	delete[] buf;
     }
}
//---------------------------------------------------------------
void TMemStr::FromBlob(TBlobField* blob)
{
     TMemoryStream * bmem = new TMemoryStream;
     blob->SaveToStream(bmem);
     if (bmem->Size > 0) {
     	bmem->Position = 0;
     	FromTMemoryStream(bmem);
     }
     else  {
        bmem->Free();
     	throw new TBlobClassBase::EEmptyBlob("����� �������");
     }
     bmem->Free();
}
//---------------------------------------------------------------
void TBlobClassBase::write(TBlobField* aBlobField)
{
    ostrstream ostr;
    TIOObjectBase::write(ostr);
    TMemoryStream * bmem = new TMemoryStream;
    bmem->Write(ostr.str(), ostr.pcount());
    ostr.rdbuf()->freeze(0);
    aBlobField->LoadFromStream(bmem);
    bmem->Free();
}
//---------------------------------------------------------------
string TBlobClassBase::readClassName(TBlobField* aBlobField)
{
    TMemStr mem;
    mem.FromBlob(aBlobField);
    return TIOObjectBase::readClassName(mem);
}
//---------------------------------------------------------------
TBlobClassBase* TBlobClassBase::Create (TBlobField* aBlobField)
{
    string name = readClassName(aBlobField);
    CreateMap::const_iterator it =
               TBlobClassBase::pCreateMap->find(name);
    TBlobClassBase* pBlobClassBase=0;
    if (it != pCreateMap->end())
    	pBlobClassBase = (*it).second(aBlobField);
    else
    	throw new EUnknownClass(name.c_str());
    return pBlobClassBase;
}
//---------------------------------------------------------------
void TBlobClassBase::reset()
{
    if (pCreateMap)
        delete pCreateMap;
}
// end of file
