// UBlobClass.h     Listing 4
// simple object I/O for Paradox Blob fields implementation
/*  class TIOObjectBase and
    template <class T> class TIOObject : public TIOObjectBase
    Can store and retrieve/reconstruct any simple
    class objects to a Paradox TBlobField
    USE THIS WAY
    your classes:
    [ code
    struct structType1 {      // MUST have default ctor
    	int i;
        // ...
    }
    class structType2 {
    	double i;
        // ...
    }
    // other classes ...

    end code ]
    reading:
    [code
        // register before use with all expected classes
    	TBlobClass<structType1>::Register();
    	TBlobClass<structType2>::Register();
        // etc...
        // read from TBlobField* aBlobField
    	TBlobClassBase* p = TBlobClassBase::Create(aBlobField);
        // get a pointer to a struct,
        // or 0 if not this struct in blob
        if ( (structType1 *st1 =
              TBlobClass<structType1>::PtrData(p))!=0)
        	// use st1
        )
        // try other structures the same way
    end code]
    Storage
    [code
     	SomeTable->Edit();
        structType1 d;
        // update d ...
        TBlobClass<structType1>(d).write(SomeBlobField);
        // ...
     	SomeTable->Post();
    end code]
*/
//---------------------------------------------------------------
#ifndef UBlobClassH
#define UBlobClassH
#include "UIOObj.h"
//---------------------------------------------------------------
// interfaces strstream with C++ Builder TMemoryStream type
class TMemStr : public strstream
{
      public:
      streampos Size() ;
      void ToTMemoryStream(TMemoryStream * bstr) ;
      void FromTMemoryStream(TMemoryStream * bstr) ;
      void FromBlob(TBlobField* blob);
};
//---------------------------------------------------------------
//---------------------------------------------------------------
class TBlobClassBase : public virtual TIOObjectBase  {
	protected:
        static string readClassName(TBlobField* );
		typedef  TBlobClassBase* (*pfCreate)(TBlobField*);
		typedef map<string, pfCreate, less<string> >  CreateMap;
        static CreateMap* pCreateMap;
    public:
        struct EInvalidBlobName : public Exception
	    {EInvalidBlobName(const char * mess): Exception(mess){}};
        struct EEmptyBlob : public Exception
	    {EEmptyBlob(const char * mess=NULL): Exception(mess){}};
        void write(TBlobField* );
        static TBlobClassBase* Create(TBlobField* );
        static void reset();
};
//---------------------------------------------------------------
template <class T>
class TBlobClass : public virtual TIOObject<T>,
                   public virtual TBlobClassBase
{
        static TBlobClassBase* Create(TBlobField* aBlobField);
        static string Name(void){return typeid(TBlobClass).name();}
        //static  pair<const string, pfCreate> mapPair();
        string name(void) const {return Name();}
	public:
        TBlobClass(const T& _data = T()) : TIOObject<T>(_data) {}
        static void Register();
};
//---------------------------------------------------------------
// 		********  TEMPLATE FUNCTION DEFINITIONS**********
//---------------------------------------------------------------
template <class T>
TBlobClassBase* TBlobClass<T>::Create(TBlobField* aBlobField)
{
    TMemStr mem;
    mem.FromBlob(aBlobField);
    string blobName =  TIOObjectBase::readClassName(mem);
    if (string(typeid(TBlobClass<T>).name()) == blobName) {
    	TBlobClass* ptr = new TBlobClass ;
        mem.read((char*)ptr->dataStart(), ptr->dataSize());
     	return ptr;
    }
    else
       throw EInvalidBlobName(blobName.c_str());
}
//---------------------------------------------------------------
template <class T>
void TBlobClass<T>::Register()
{
     if (!TBlobClassBase::pCreateMap)
        TBlobClassBase::pCreateMap = new CreateMap();
     (*TBlobClassBase::pCreateMap)[Name()] = Create;
}
#endif

//---------------------------------------------------------------

