#ifndef _myserve_h_
#define _myserve_h_

#define LOGGING

#include "ntservice.h"
#include "tapplog.h"

class TAppLog;

class MyService : public NTService
{
#ifdef LOGGING
	TAppLog*	m_log;
#endif	
	HANDLE		mhOutfile;
	HANDLE		mhMailslot;
	boolean		m_running;

private:
	MyService( void );
	MyService( MyService& );
	
protected:
//== override these functions from the parent class
	DWORD	Init( DWORD argc, LPTSTR* argv );
	int		Run();
	
#ifdef LOGGING
	void	InstallAid( void );
	void	LogEvent( LOG_LEVEL, char*, ... );
	void	Error( long line );
#endif

//== only support service control Stop
	void	OnStop( void );

public:
	MyService( const char* name, LPSERVICE_MAIN_FUNCTION, LPHANDLER_FUNCTION );
	~MyService( void );
};

#endif
