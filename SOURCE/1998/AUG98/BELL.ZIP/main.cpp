#include <windows.h>

#include "myserve.h"
#include "mcmsg.h"

NTService *ntService = NULL;

static const char SERVICE_NAME[] = "MyServe";

void WINAPI serviceMain( DWORD ac, LPTSTR *av )
{
	ntService->Service( ac, av );
}

void WINAPI serviceControl( DWORD opcode )
{
	ntService->Control( opcode );
}

DWORD main( int argc, char *argv[] )
{
	ntService = new MyService( SERVICE_NAME, serviceMain, serviceControl );
	
	if( argc <= 1)
		ntService->Startup();
	else if( stricmp( argv[1], "-i") == 0 )
		ntService->Install();
	else if( stricmp( argv[1], "-u") == 0 )
		ntService->UnInstall();

	DWORD exitcode = ntService->GetExitCode();

	delete ntService;

	return exitcode;
}