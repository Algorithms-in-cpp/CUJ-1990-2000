#ifndef _TAPPLOG_H_
#define _TAPPLOG_H_

#include <stdarg.h>

enum LOG_LEVEL 
{ 
	LOG_NONE, 
	LOG_ERROR, 
	LOG_WARNING,
	LOG_INFORM, 
	LOG_ALL,
	LOG_DEBUG
};

class TAppLog
{
	HANDLE		m_hEventLog;
	LOG_LEVEL	m_loglevel;
	char		m_srcname[36];

//======================================================================
protected:
	TAppLog( void );
	TAppLog( TAppLog& );

	bool IsInstalled( void );

public:
	TAppLog( LPTSTR src_name, LOG_LEVEL loglevel = LOG_ALL );
	virtual ~TAppLog( void );

	virtual bool	Install( void );
	virtual bool	Uninstall( void );

	virtual bool LogEvent( LOG_LEVEL, char*, ...);
	virtual bool LogEventVL( LOG_LEVEL, char*, va_list );

	virtual LOG_LEVEL SetLogLevel( LOG_LEVEL loglevel );
};

inline LOG_LEVEL TAppLog::SetLogLevel( LOG_LEVEL loglevel )
{ 
	return (m_loglevel = loglevel);
}

#endif