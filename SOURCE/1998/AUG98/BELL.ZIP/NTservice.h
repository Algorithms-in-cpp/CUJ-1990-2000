#ifndef _ntservice_h_
#define _ntservice_h_

#include <windows.h>

class NTService
{
private:
	bool					m_isStarted;
	bool					m_isPaused;

protected:
	char					m_name[36];
	DWORD					m_err;

	LPSERVICE_MAIN_FUNCTION mfpSrvMain;
	LPHANDLER_FUNCTION		mfpSrvControl;

	SERVICE_TABLE_ENTRY		mDispatchTable[2];
	SERVICE_STATUS			mStat;
	SERVICE_STATUS_HANDLE	mh_Stat;

public:
//============================================================
//============================================================
//	static ServiceMain( DWORD ac, LPTSTR *av );
//	static ServiceControl( DWORD opCode );
//============================================================
//============================================================
private:
	NTService();				//== prevent a default constructor
	NTService( NTService& );	//== prevent a copy constructor

protected:

	virtual void	SetAcceptedControls( DWORD controls );
	virtual	void	ChangeStatus
					( 
						DWORD state, 
						DWORD checkpoint = (DWORD)0, 
						DWORD waithint = (DWORD)0
					);
	
//== the protected functions below this line should be overridden as needed
	virtual DWORD	Init( DWORD argc, LPTSTR* argv );
	virtual int		Run() = 0;
	
	virtual void	InstallAid( void );
	virtual void	UnInstallAid( void );

//== these are the 6 service control actions
	virtual DWORD	OnPause( void );
	virtual DWORD	OnContinue( void );

	virtual void	OnStop( void );
	virtual void	OnShutdown( void );

	virtual void	OnInquire( void );
	virtual void	OnUserControl( DWORD usercmd );

public:
//== it should not be necessary to overload these public functions
	NTService( const char *name, LPSERVICE_MAIN_FUNCTION, LPHANDLER_FUNCTION );
	virtual			~NTService( void );

	virtual DWORD	Startup( void );
	virtual int		Service( DWORD argc, LPTSTR* argv );	
	virtual void	Control( DWORD opcode );

	virtual bool	IsInstalled( void );
	virtual bool	Install( void );
	virtual bool	UnInstall( void );

	virtual DWORD	GetLastError( void );	
	virtual DWORD	GetExitCode( void );	
};

inline DWORD NTService::GetExitCode( void )
{
	return mStat.dwWin32ExitCode;
}
#endif