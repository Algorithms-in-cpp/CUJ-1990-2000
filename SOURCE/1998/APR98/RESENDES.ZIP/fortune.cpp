//
// File: fortune.cpp
//

#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "fortune.h"

// Init static value
int
Teller_impl::_tcount = 0;

// Constructor
Teller_impl::Teller_impl(const char* s)
  : _msg(0), _num(0)
{
   assert(s != NULL);
   _msg = new char[strlen(s)+1];
   assert(_msg != NULL);
   strcpy(_msg, s);  

   _num = ++_tcount;
}

// Destructor
Teller_impl::~Teller_impl()
{
   if(_msg) delete [] _msg;
}

// getMessage
char* Teller_impl::getMessage()
{
   return _msg;
}

// getLuckyNumber
int Teller_impl::getLuckyNumber()
{
   return _num;
}

// Array of fortune messages
static char* 
fortunes[] = {
 "Jan: Your day will be glorious.",
 "Feb: You are going to be very rich.",
 "Mar: Finish up old tasks.",   
 "Apr: Your hard work will pay off.",
 "May: You will live a long life.",
 "Jun: You are going in new directions.",
 "Jul: Good fortune will come to you.",
 "Aug: You are full of wit and energy.",
 "Sep: Trust your instincts.",
 "Oct: Ask and you shall receive.",
 "Nov: Success is headed your way.",
 "Dec: You can accomplish anything.",
};

// Constructor
Factory_impl::Factory_impl()
{
   _mcount = sizeof(fortunes)/sizeof(char*);

   _list = new Teller_impl*[_mcount];
   assert(_list);
   for (int i=0; i<_mcount; i++) {
      _list[i] = new Teller_impl(fortunes[i]);
      assert(_list[i]);
   } 
}

// Destructor
Factory_impl::~Factory_impl()
{
   for (int i=0; i<_mcount; i++) {
      if(_list[i]) delete _list[i]; 
   } 
   if (_list) delete [] _list;
}

// getFortune
Teller_impl*
Factory_impl::getFortune(int month)
{
   if((month <= 0) || (month > _mcount)) 
      throw outOfBounds();

   return _list[month-1];
}
