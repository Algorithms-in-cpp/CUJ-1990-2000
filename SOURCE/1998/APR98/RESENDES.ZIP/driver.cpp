//
// File driver.cpp
//

#include <stdlib.h>
#include <iostream.h>

#include "fortune.h"

int main(int argc, char* argv[] )
{
  // Check for arguments
  if (argc < 2) {
     cerr << "\tusage: driver <month>"
          << endl;
     return 1;
  }

  // Create factory 
  Factory_impl* f = 
     new Factory_impl();

  try {
    // Get fortune server
    Teller_impl* t = 
      f->getFortune(atoi(argv[1]));
    
    // Display results
    cout << "Fortune for " 
         << t->getMessage() << endl;
    cout << "Lucky # is: " 
         << t->getLuckyNumber() << endl;
  }
  // Check for error conditions
  catch(Factory_impl::outOfBounds) {
    cerr << "Month value was out "
         << "of bounds ... try again."
         << endl;
    delete f;
    return 1;
  }
  catch(...){
    cerr << "Caught unknown exception" 
         << endl;
    delete f;
    return 1;
  }
   
  delete f;
  return 0;
}
