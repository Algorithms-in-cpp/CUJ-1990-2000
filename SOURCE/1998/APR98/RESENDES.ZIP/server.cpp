//
// File: server.cpp
//

#include <OB/CORBA.h>
#include <fstream>

#include "fortune_impl.h"

int 
main (int argc, char* argv[]) 
{
  try {
   // Init ORB and OA
   CORBA_ORB_var orb = CORBA_ORB_init(argc, argv);
   CORBA_BOA_var boa = orb->BOA_init(argc, argv);

   // Create implementation object
   Fortune_Factory_var p = new Factory_impl();
   
   // Externalize an object reference
   CORBA_String_var s = orb->object_to_string(p);
   const char* refFile = "factory.ior";
   ofstream outstr(refFile);
   if(outstr.fail()){
      cerr << "Can't open " << refFile << " for writing." << endl;
      return 1;
   }
   outstr << s << endl; outstr.close();

   // Enter main (infinite) loop
   boa->impl_is_ready(CORBA_ImplementationDef::_nil());
  }
  catch(CORBA_COMM_FAILURE& ex) { 
     cerr << &ex;
     return 1;
  }
  
  return 0;
}
