//
// File: fortune.h
// 

//
// Class: Teller_impl
//
class Teller_impl 
{
 public:
    // Constructor & Destructor
    Teller_impl(const char* s);
    ~Teller_impl(void);

    // Returns fortune msg
    char*
    getMessage(void);

    // Returns lucky #
    int 
    getLuckyNumber(void);

 private:
    static int _tcount;
    char* _msg;
    int _num;
};

//
// Class: Factory_impl
//
class Factory_impl 
{
 public:
   // Constructor & Destructor
   Factory_impl(void);
   ~Factory_impl(void);
 
   // User exception
   class outOfBounds {};

   // Returns a Teller_impl for the given month
   Teller_impl*
   getFortune(int month); 
      /* throws outOfBounds */

 private:
   int _mcount;
   Teller_impl** _list;
}; 
  
