//
// File: fortune_impl.cpp
//

#include <OB/CORBA.h>

#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "fortune_impl.h"

// Init static value
int Teller_impl::_tcount = 0;

// Constructor
Teller_impl::Teller_impl(const char* s)
  : _msg(0), _num(0)
{
   assert(s != NULL);
   _msg = 
      CORBA_string_alloc(strlen(s));
   assert(_msg != NULL);
   _msg = CORBA_string_dup(s);  

   _num = ++_tcount;
}

// Destructor
Teller_impl::~Teller_impl()
{
   if(_msg) 
      CORBA_string_free(_msg);
}

char* Teller_impl::getMessage()
{
   return CORBA_string_dup(_msg);
}

CORBA_Long Teller_impl::getLuckyNumber()
{
   return _num;
}

static char* 
fortunes[] = {
 "Jan: Your day will be glorious.",
 "Feb: You are going to be very rich.",
 "Mar: Finish up old tasks.",   
 "Apr: Your hard work will pay off.",
 "May: You will live a long life.",
 "Jun: You are going in new directions.",
 "Jul: Good fortune will come to you.",
 "Aug: You are full of wit and energy.",
 "Sep: Trust your instincts.",
 "Oct: Ask and you shall receive.",
 "Nov: Success is headed your way.",
 "Dec: You can accomplish anything.",
};

Factory_impl::Factory_impl()
{
   _mcount = 
      sizeof(fortunes)/sizeof(char*);

   _list = new Teller_impl*[_mcount];
   assert(_list);
   for (int i=0; i<_mcount; i++) {
      _list[i] = 
         new Teller_impl(fortunes[i]);
      assert(_list[i]);
   } 
}

Factory_impl::~Factory_impl()
{
   for (int i=0; i<_mcount; i++) {
      if(_list[i]) 
         CORBA_release(_list[i]); 
   } 
   if (_list) delete [] _list;
}

Fortune_Teller_ptr
Factory_impl::getFortune(CORBA_Short m)
{
   if((m <= 0) || (m > _mcount)) 
      throw outOfBounds();

   return Fortune_Teller::
          _duplicate(_list[m-1]);
}
