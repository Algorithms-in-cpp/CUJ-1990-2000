//
// File: fortune_impl.h
//

#include "fortune_skel.h"

//
// Class: Teller_impl
//
class Teller_impl:
   public Fortune_Teller_skel 
{
 public:
    // Constructor & Destructor
    Teller_impl(const char* s);
    ~Teller_impl(void);

    // Returns fortune msg
    char*
    getMessage(void);

    // Returns lucky #
    CORBA_Long 
    getLuckyNumber(void);

 private:
    static int _tcount;
    char* _msg;
    CORBA_Long _num;
};

//
// Class: Factory_impl
//
class Factory_impl :
   public Fortune_Factory_skel 
{
 public:
   // Constructor & Destructor
   Factory_impl(void);
   ~Factory_impl(void);
 
   // Returns a Teller_impl for the given month
   Fortune_Teller_ptr
   getFortune(CORBA_Short month);
      /* throws outOfBounds */

 private:
   int _mcount;
   Teller_impl** _list;
}; 
  
