//
// File: client.cpp
//
#include <OB/CORBA.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>

#include "fortune.h"

int
main(int argc, char* argv[]) {

 try {
   // Init ORB
   CORBA_ORB_var orb = CORBA_ORB_init(argc, argv);

   // Obtain externalized Factory object reference.
   const char* refFile = "factory.ior";
   ifstream in; in.open(refFile);
   if(in.fail()){
      cerr << "Can't open " << refFile << " for reading." << endl;
      return 1;
   }

   char s[1000]; in >> s;
   CORBA_Object_var obj = orb -> string_to_object(s);
   assert(!CORBA_is_nil(obj));

   // Narrow object reference
   Fortune_Factory_var fv = Fortune_Factory::_narrow(obj);
   assert(!CORBA_is_nil(fv));

   int month = 0;
   int done = 0;
   cout << "Enter month value (1 to 12" << ", 0 to quit)" << endl;

   // Loop
   while (done == 0) {
      cout << "\nMonth: ";
      cin >> month;
      if (month != 0) {
       // Get fortune server
       Fortune_Teller_var tv = fv->getFortune(month);
       assert(!CORBA_is_nil(tv));
      
       // Display results
       cout << "Fortune for " << tv->getMessage() << endl;
       cout << "Lucky # is: " << tv->getLuckyNumber() << endl;
      }
      else { done = 1; }
    }
  }
  // Check for error conditions
  catch(Fortune_Factory::outOfBounds&)
  {
    cerr << "Month value was out "
         << "of bounds ... exiting."
         << endl;
    return 1;
  }
  catch(CORBA_SystemException& ex)
  { 
    cerr << "Communications failure:" << endl;
    cerr << "\t" << ex.reason(); 
    return 1;
  }
   
  return 0;
}
