void cross_reference_add(char const *w, unsigned n);
void cross_reference_put();
