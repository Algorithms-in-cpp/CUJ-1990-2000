#include <stdio.h>
#include <string.h>

#include "cross_reference2.h"

namespace cross_reference
    {

    tree_node *xr = NULL;

    tree_node *
    add_tree(tree_node *t, char const *w, unsigned n)
        {
        ... same as in Listing 2 ...
        }

    void put_tree(tree_node const *t)
        {
        ... same as in Listing 2 ...
        }

    }
