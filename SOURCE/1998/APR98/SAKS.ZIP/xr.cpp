// xr.cpp - generate a cross-reference of words
#include <ctype.h>
#include <stdio.h>
#include <string.h>

#include "cross_reference.h"

int get_token(char *s, size_t n);

#define MAX_TOKEN 256

int main()
  {
  char token[MAX_TOKEN];
  unsigned ln = 1;
  while (get_token(token, MAX_TOKEN) != EOF)
    if (isalpha(token[0]) || token[0] == '_')
      cross_reference_add(token, ln);
    else if (token[0] == '\n')
      ++ln;
  cross_reference_put();
  return 0;
  }

int get_token(char *s, size_t n)
  {
  ... same as in Listing 2 ...
  }
