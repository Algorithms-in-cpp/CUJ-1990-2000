#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct list_node list_node;
struct list_node
    {
    unsigned number;
    list_node *next;
    };

typedef struct tree_node tree_node;
struct tree_node
    {
    char *word;
    list_node *first, *last;
    tree_node *left, *right;
    };

tree_node *
add_tree(tree_node *t, char const *w, unsigned n)
    {
    ... same as in Listing 2 ...
    }

void put_tree(tree_node const *t)
    {
    ... same as in Listing 2 ...
    }

static tree_node *xr = NULL;

void
cross_reference_add(char const *w, unsigned n)
    {
    xr = add_tree(xr, w, n);
    }

void cross_reference_put()
    {
    put_tree(xr);
    }
