template<class T, size_t N>
class Array
    {
public:
    ~Array()
        {
        }
    Array()
        {
        }
    Array(Array const &)
        {
        // currently unimplemented
        }
    Array &operator=(Array const &)
        {
        // currently unimplemented
        return *this;
        }
    operator T *()
        {
        return array_;
        }
    operator T const *() const
        {
        return array_;
        }
    T &operator[](size_t const i)
        {
        return array_[i];
        }
    T const &operator[](size_t const i) const
        {
        return array_[i];
        }
private:
    T array_[N];
        };

 
 
