/*
 *  dfile.h
 *  Direct File i/o for Disk-based Container Objects
 *
 *  Copyright (C) T.W. Nelson. Permission is hereby granted to use this 
 *  code in any manner provided this copyright notice is displayed 
 *  appropriately.
 */
#ifndef __DFILE__H
#define __DFILE__H

#include <stdio.h>  /* tmpnam() */
#include "fhelp.h"

class DirectFile : public FileHelper
{
    const char *_fname;  /* file, path name */
    char _tmpbuf[ L_tmpnam ];  /* temp file name */
    int     _use_temp;   /* used temporary file */
    unsigned _size;  /* sizeof data objects */
    void init();

  public:
    DirectFile( int, unsigned sz,
                const char *path = 0, int=0 )
      : _size(sz),_fname(path) { init(); }
    ~DirectFile() {     Close();
                        if( _use_temp )
                            remove( _fname );  }
    const char *fname() const { return _fname; }
    int tempused() const { return _use_temp; }
    virtual int ReadNode( void * dest, ulong pos )
        { return ReadAt( pos, dest, _size );  }
    virtual int WriteNode(const void * src, ulong pos)
        { return WriteAt( pos, src, _size ); }
};

inline void DirectFile::init()
{
    if( !_fname || !(*_fname) )   {
        _use_temp = 1;   /* use temp file name */
        _fname = tmpnam(_tmpbuf);
        Create(_fname);     /* create temporary */
    } else {
        _use_temp = 0;   /* assume persistent */
        if( Open( _fname ) )  /* if doesn't exist, */
            Create( _fname );   /* create it */
    }
}
#endif  // EOF
