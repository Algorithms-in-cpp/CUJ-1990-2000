/*
 *  fhelp.c
 *  Simple interface for handle-based binary files
 *
 *  Copyright (C) T.W. Nelson. Permission is hereby granted to use this 
 *  code in any manner provided this copyright notice is displayed 
 *  appropriately.
 */
#ifndef __FHELP_H
#define __FHELP_H

#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>

typedef unsigned long ulong;

class FileHelper    {
    int _fh;
  public:
    FileHelper(): _fh(-1) {}
    ~FileHelper() { Close(); }
    int Fh() const { return _fh;    }
    virtual int Open( const char *fn )  {
        _fh = open( fn, O_RDWR|O_BINARY );
        return _fh == -1 ? -1 : 0;      //0 if OK
        }
    virtual int Create( const char *fn )    {
        _fh = open( fn, O_CREAT|O_BINARY,
                            S_IREAD|S_IWRITE );
        return _fh == -1 ? -1 : 0;      //0 if OK
        }
    virtual int ReadAt( ulong pos,
                         void *buf, unsigned len) {
        lseek( _fh, pos, SEEK_SET );
        return read( _fh, buf, len );
        }
    virtual int WriteAt( ulong pos, const void *buf,
                                    unsigned len ) {
        lseek( _fh, pos, SEEK_SET );
        return write( _fh, buf, len );
        }
    virtual int Close() { return close( _fh );  }
};
#endif  // EOF
