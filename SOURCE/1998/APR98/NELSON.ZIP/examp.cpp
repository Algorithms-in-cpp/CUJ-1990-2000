/*
 *  examp.cpp
 *  Example Packed Object Format for Derived Classes
 *
 *  Copyright (C) T.W. Nelson. Permission is hereby granted to use this 
 *  code in any manner provided this copyright notice is displayed 
 *  appropriately.
 */
#include <iostream.h>
#include "vector.h"

struct PData {      /* "Packed" data format */
  //Base class data:
    int i;
    int j;
  //Derived class data:
    int ii;
    int jj;
};

class Base {
  public:
    int i;
    int j;
    char *pbuf;     /* buffer pointer (not saved) */
    Base(): i(1), j(2), pbuf(0) {}
    void Save( PData & p )
        { p.i = i; p.j = j; }
    void Restore( PData & p )
        { i = p.i; j = p.j; }
};

class Derived : public Base  {
  public:
    int ii;
    int jj;
    void *pb;     /* another pointer, (not saved) */
    Derived(): ii(3), jj(4), pb(0) {}
    void Save ( PData & p) {
        p.ii = ii;
        p.jj = jj;
        Base::Save(p);
    }
    void Restore ( PData & p) {
        ii = p.ii;
        jj = p.jj;
        Base::Restore(p);
    }
};

int main()
{
    TDVector<PData> vect( "examp.dat" );
    TDVectorIterator<PData> vi( vect );
    PData Pd;       /* Packed data object */
    Derived d;      /* Working object */

    d.j = 'a';
    d.jj = -1;
    for( int i = 1; i <= 10; i++ )   {
        d.i = i;
        d.ii = i + 100;
        d.Save(Pd);     /* Save in packed format */
        vect.Add( Pd );     /* Add to container */
    }
    for( vi.Restart(); vi; vi++ )     {
        Pd = vi.Current();  /* get next object */
        d.Restore( Pd );    /* unpack */
        cout << d.i << endl;  /* display */
    }
    return 0;
}   // EOF
