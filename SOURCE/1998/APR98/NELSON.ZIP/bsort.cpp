/*
 *  bsort.cpp
 *  Binary-tree sort example, sorts words in text file
 *
 *  Copyright (C) T.W. Nelson. Permission is hereby granted to use this 
 *  code in any manner provided this copyright notice is displayed 
 *  appropriately.
 */
#include <iostream.h>
#include <string.h>
#include "bintree.h"

#define MAXLINE     132 /* max line length */
#define MAXWORD 40    /* maximum word length */
#define DELIMCHARS  " .!@#$%&*()+=?,`\"[]{}:;<>-\r\n"

class WordSort {
    char tok[MAXWORD];  /* word string (key) */
    int zero;   /* ensures tok is asciiz */
    streampos t_ofst;  /* offset into text file */
  public:
    void Sort();
    friend int operator< ( const WordSort &lh,
                           const WordSort &rh )  {
        return( strcmp(lh.tok, rh.tok) < 0 );
        }
    friend int output( WordSort& rec, void *arg )
        {
        cout << rec.tok << " " << rec.t_ofst << endl;
        return 0;   /* no updates */
        }
};

void WordSort::Sort()   {
    TDBinarySearchTree<WordSort> Bt;
    char  linebuf[MAXLINE];
    WordSort rec;
    streampos  pos;
    char  *ptok;
    rec.zero = 0;

    while( 1 )  {
        pos = cin.tellg();
        ptok = NULL;
        cin.getline( linebuf, MAXLINE );
        if( cin.gcount() == 0 )
                break;     /* end of file */
        while( 1 ) {
            ptok = strtok( ptok ? NULL : linebuf,
                                        DELIMCHARS );
            if( ptok == NULL )
                    break;  /* end of line */
            strncpy( rec.tok, ptok, MAXWORD );
            rec.t_ofst = pos + (ptok - linebuf);
            //Bt.Add( rec );  /* save-n-sort record */
            Bt << rec;  /* like iostreams */
        }
    }

    Bt.ForEach( output, 0 );   /* print results */
}

int main()
{  /* Use redirection symbols '<' and '>' to specify
    * input and output files. Default uses cin, cout.
    */
    WordSort    ws;
    ws.Sort();
    return 0;
}
// EOF
