/*
 *  vectman.h
 *  Disk-based Container Vector Manager
 *
 *  Copyright (C) T.W. Nelson. Permission is hereby granted to use this 
 *  code in any manner provided this copyright notice is displayed 
 *  appropriately.
 */
#ifndef __VECTMAN_H
#define __VECTMAN_H
#include <string.h>
#include "dfile.h"

typedef ulong filepos;     /* file position */

template <class T, class FM> class TDVectorManager
{
    FM *_Fm;   /* -> file manager */
    #define MAXID   16
    struct header {
        char IdString[MAXID];   /* vector ID */
        int Zero;     /* ensures IdString is ASCIIZ */
        filepos Start;   /* offset to 1st (0th) cell */
        ulong CellCount;   /* logical (active) size */
        } _Hdr;

    #define HDRSIZE  sizeof(header)

   /* #define BEG_OFFSET before #including vectman.h
    * to start 1st vector cell at selected offset
    * into file. Default places 1st cell immediately
    * after the header.
    */
    #ifndef BEG_OFFSET
    #define BEG_OFFSET  HDRSIZE
    #endif

    filepos index_to_offset( ulong cell )
        { return (cell * sizeof(T)) + BEG_OFFSET;  }

  public:
    TDVectorManager(const char *fname, int nn, int m) {
        _Fm = new FM( nn, sizeof(T), fname, m );
        SetId( "VECTOR" );  /* set default */
        _Hdr.Start = BEG_OFFSET;
        _Hdr.Zero = 0;
        _Hdr.CellCount = 0;
        _Fm->ReadAt( 0, (void *) &_Hdr, HDRSIZE );
    }
    ~TDVectorManager() { WriteHeader();
                         delete _Fm; }
    void GetId(char *s) const
        { strcpy(s, _Hdr.IdString); }
    void SetId(char *s)
        { strncpy( _Hdr.IdString, s, MAXID ); }
    ulong CellCount() const        /* get count */
        { return _Hdr.CellCount; }
    void CellCount( ulong cnt )     /* set count */
        { _Hdr.CellCount = cnt; }
    int WriteHeader();
    virtual int ReadCell( T& t, ulong cell )
        { return _Fm->ReadNode( (void *) &t,
                      index_to_offset(cell) ); }
    virtual int WriteCell( const T& t, ulong cell )
        { return _Fm->WriteNode((const void *) &t,
                      index_to_offset(cell) ); }
};

template <class T,class FM>
int TDVectorManager<T,FM>::WriteHeader()
{   if( _Fm->tempused() )
        return 1;
    return _Fm->WriteAt( 0, (void *) &_Hdr, HDRSIZE );
}
#endif  // EOF
