/*
 *  vector.h
 *  Disk-based Vector implementation
 *
 *  Copyright (C) T.W. Nelson. Permission is hereby granted to use this 
 *  code in any manner provided this copyright notice is displayed 
 *  appropriately.
 */
#ifndef __VECTOR_H
#define __VECTOR_H
#include "vectman.h"

/* Select file management scheme */
#ifndef FM
#define FM   DirectFile
#endif

template <class T> class TDVectorIterator; //forward

template <class T> class TDVector
{
    TDVectorManager<T,FM> *_Vm;

  public:
    TDVector( const char *fname = 0 ) {
        _Vm = new TDVectorManager
               <T,FM> (fname, 0, 0);
    }

    ~TDVector() { delete _Vm;  }
    friend TDVectorIterator<T>;

    ulong CellCount() const     /* get count */
        { return _Vm->CellCount(); }
    void CellCount( ulong cnt )     /* set count */
        { _Vm->CellCount(cnt); }
    int Add( const T& item )
        { return ReplaceAt( item, CellCount() ); }
    int ReplaceAt( const T&, ulong );
    int ItemAt( T&, ulong ) const;
    void ForEach( int (*)(T&, void *), void * );
    void Flush() { CellCount( 0 ); }
    int operator() ( const T& t, ulong cell )
        { return ReplaceAt( t, cell ); }  //poke item
    T operator() ( ulong ) const;   //peek item
};

template <class T>
T TDVector<T>::operator () ( ulong cell ) const
{   T item;
    ItemAt(item, cell);
    return item;
}

template <class T>
int TDVector<T>::ReplaceAt( const T& item, ulong cell)
{  /* Replace an item at the specified index. Extends
    * vector to any distance beyond current
    * End of Vector if necessary ......
    */
    if( cell >= CellCount() )  /* if beyond end, */
        CellCount( cell+1 );      /* extend it */
    _Vm->WriteCell( item, cell );
    return 1;   /* ok */
}

template <class T>
int TDVector<T>::ItemAt( T& item, ulong cell ) const
{  /* Access item at specified cell index. Returns !0
    * if successful, 0 at end of vector or other error.
    */
    if( cell >= CellCount() )
        return 0;   /* beyond end of vector */
    int rv = _Vm->ReadCell( item, cell );
    return !(rv == 0 || rv == -1);
}

template <class T> void TDVector<T>::
ForEach( int (*ifn)(T&, void *), void *args )
{   /* ifn() returns !0 if cell was modified */
    T item;
    ulong cnt = 0;
    while( ItemAt( item, cnt ) )  {
        if( ifn( item, args ) )    /* if modified, */
            ReplaceAt( item, cnt );  /* update item */
        cnt++;
    }
}

template <class T> class TDVectorIterator   {
    const TDVector<T> *Vect;
    ulong Cur;  /* current vector index */
  public:
    TDVectorIterator( const TDVector<T>& vect )
        {   Vect = &vect;
            Restart();    }
    /* Returns 0 at end of vector...... */
    operator int() const
        { return( Cur < Vect->CellCount() );    }
    T Current() const   {  return (*Vect)(Cur); }
    void Restart() { Cur = 0; }
    /* pre- and post-increment operators ... */
    void operator ++ () { Cur++; }
    void operator ++ (int) { Cur++; }
};

template <class T>
class TDStackAsVector : public TDVector<T>  {
  public:
    TDStackAsVector( const char *fname = 0 )
         : TDVector<T> ( fname ) { }
    int Push( const T& t ) { return Add(t);  }
    int Pop( T& );
};

template <class T> int TDStackAsVector<T>::Pop(T& t)
{   /* Remove item at top of stack */
    ulong top = CellCount();
    if( (long) top <= 0 )
        return 0;       /* return empty */
    ItemAt( t, --top );
    CellCount( top );
    return 1;       /* got it */
}
#endif  // EOF
