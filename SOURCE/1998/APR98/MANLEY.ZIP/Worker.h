// File: Worker.h

#ifndef __WORKER_THREAD_H__
#define __WORKER_THREAD_H__

#define WIN32_EXTRA_LEAN
#include <windows.h>

class CThreadPool ;

typedef unsigned ( __stdcall * PFNTHREAD )( void * );

const int STOP_WORKER_THREAD = 1;

class CWorkerThread  {
public:

	CWorkerThread( CThreadPool* pPool );
	virtual ~CWorkerThread();

	CThreadPool* GetThreadPool() const
		{ return m_pThreadPool; }

	BOOL Start();

	BOOL IsThreadRunning() const
		{ return m_bRunning; }

	HANDLE GetThreadHandle() const
		{ return m_hThread; }

	DWORD GetThreadID() const
		{ return m_dwThreadID; }

	virtual void OnReceivedCompletionPacket(
						BOOL bResult,
						DWORD dwNumberOfBytesTransferred,
                        DWORD dwKey,
						LPOVERLAPPED lpOverlapped ) = 0;


protected:
	static int ThreadEntryProc( LPVOID pPooledThread );
	void Reset();
	virtual void ThreadMain();

 protected:
 	CThreadPool* m_pThreadPool ;
	HANDLE	m_hThread;
	HANDLE	m_hStartEvent;
	DWORD	m_dwThreadID ;
	BOOL	m_bRunning;
};

#endif	// __WORKER_THREAD_H__