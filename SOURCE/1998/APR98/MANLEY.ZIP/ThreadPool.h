// ThreadPool.h

#ifndef __THREADPOOL_H__
#define __THREADPOOL_H__

#define WIN32_EXTRA_LEAN
#include <windows.h>

class CWorkerThread;

class CThreadPool {
public:

	CThreadPool( DWORD numThreads = 0, DWORD threadConcurrency = 0 );
	virtual ~CThreadPool(); 

	void Start(); 
	void Stop(); 
	BOOL IsStarted() const 
		{ return m_bStarted; } 
	void WaitForThreadCompletion(); 

	virtual CWorkerThread* CreateWorkerThread( CThreadPool* pPool ) = 0 ; 
	virtual void DestroyWorkerThread( CWorkerThread* pThread ); 

	BOOL GetQueuedCompletionStatus( LPDWORD lpNumberOfBytesTransferred, 
									LPDWORD lpdwKey,					
									LPOVERLAPPED *lpOverlapped,			
									DWORD dwTimeout = INFINITE );		

	BOOL AssociateFile( HANDLE hFile, DWORD dwKey ); 

	BOOL PostQueuedCompletionStatus( DWORD dwKey, 
									 DWORD dwBytesTransferred=0,			
									 LPOVERLAPPED lpOverlapped=NULL );	

protected:
	void createWorkerThreads();
	void destroyWorkerThreads();
	void startWorkerThreads();
	void stopWorkerThreads();

protected:
	BOOL	m_bStarted ;
	DWORD	m_NumThreads ;
	DWORD	m_ThreadConcurrency ;
	HANDLE  m_hCompletionPort ;
	CWorkerThread** m_ThreadArray ;
}; 


#endif	// __THREADPOOL_H__