// Worker.cpp
#include <assert.h>
#include <process.h>
#include "Worker.h"
#include "ThreadPool.h"


CWorkerThread::CWorkerThread( CThreadPool* pPool ) :
 	m_pThreadPool( pPool ),
	m_hThread( INVALID_HANDLE_VALUE ),
	m_hStartEvent( INVALID_HANDLE_VALUE ),
	m_dwThreadID( 0 ),
	m_bRunning( FALSE )
{
	assert( pPool != NULL );
}


CWorkerThread::~CWorkerThread()
{
	assert( ! IsThreadRunning() );
	Reset();
}


void CWorkerThread::Reset(void)
{
	if( m_hStartEvent != INVALID_HANDLE_VALUE ) {
		CloseHandle( m_hStartEvent );
		m_hStartEvent = INVALID_HANDLE_VALUE;
	} // if

	if( m_hThread != INVALID_HANDLE_VALUE ) {
		CloseHandle( m_hThread );
		m_hThread = INVALID_HANDLE_VALUE ;
	} // if

	m_dwThreadID = 0 ;
}


BOOL CWorkerThread::Start(void)
{
	if( IsThreadRunning() ) {
		return FALSE ;
	} // if

	assert( m_hStartEvent == INVALID_HANDLE_VALUE );
	m_hStartEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	m_hThread = reinterpret_cast<HANDLE>(
					_beginthreadex( NULL, 0, (PFNTHREAD) (CWorkerThread::ThreadEntryProc),
									this, 0, reinterpret_cast<unsigned int*>(&m_dwThreadID) ));

	WaitForSingleObject( m_hStartEvent, INFINITE );

	return TRUE ;
}


int CWorkerThread::ThreadEntryProc( LPVOID pThreadClass )
{
	assert(pThreadClass != NULL);

	ULONG nResult = 0;
	CWorkerThread* pThread = static_cast<CWorkerThread*>(pThreadClass);

	assert( pThread->m_hStartEvent != INVALID_HANDLE_VALUE );
	pThread->m_bRunning = TRUE;
	SetEvent( pThread->m_hStartEvent );

	try {
		pThread->ThreadMain();
	} catch(...) {
		nResult = 1;
	} // catch

	pThread->m_bRunning = FALSE;
	_endthreadex( nResult );

	return 0 ;
}



void CWorkerThread::ThreadMain()
{
	while( TRUE ) {
		DWORD dwNumBytesTransferred = 0 ;
        DWORD dwKey = 0 ;
	    LPOVERLAPPED lpOverlapped = NULL ;

        BOOL bResult = GetThreadPool()->GetQueuedCompletionStatus(
							&dwNumBytesTransferred,
                            &dwKey,
							&lpOverlapped,
							INFINITE );

        if( bResult == TRUE && dwKey == STOP_WORKER_THREAD ) {
			break ;
        } else {
            OnReceivedCompletionPacket( bResult, dwNumBytesTransferred, dwKey, lpOverlapped );
		} // else
    } // while
}