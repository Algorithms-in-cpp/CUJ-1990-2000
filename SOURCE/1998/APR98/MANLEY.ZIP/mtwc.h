// mtwc.h
#include <iostream.h>
#include <string.h>
#include <assert.h>
#include "Worker.h"
#include "ThreadPool.h"

const int NUM_WORKER_THREADS = 0 ;	// use default, 2 * #CPUs + 2
const int THREAD_CONCURRENCY = 0 ;	// use default, 1 per CPU
const int READ_BUFFER_SIZE	 = 4096 ;

class CWordCountContext {
public:
	CWordCountContext();

	enum enState {
		STATE_UNOPENED,
		STATE_OPENED,
		STATE_CLOSED,
		STATE_ERROR_OPENING,
		STATE_ERROR_READING
	};

public:
	LPSTR		lpszFilename ;
	HANDLE		hFile ;
	OVERLAPPED	overlapped ;
	char		buffer[ READ_BUFFER_SIZE ];
	enState		state;
	int			spaceState ;
	DWORD		dwNumChars ;
	DWORD		dwNumWords ;
	DWORD		dwNumLines ;
};



class CWorkerThread ;

class CWordCountThreadPool : public CThreadPool {
public:

	CWordCountThreadPool( DWORD numThreads, DWORD threadConcurrency, DWORD numFiles );
	~CWordCountThreadPool();

	CWorkerThread* CreateWorkerThread( CThreadPool* pPool );

	void WaitUntilDone();
	void ProcessedFile();

protected:
	long	m_NumFiles ;
	HANDLE	m_hDone ;

};



class CWordCountWorker : public CWorkerThread {
public:

	CWordCountWorker( CWordCountThreadPool* pPool ) :
		CWorkerThread( pPool ) {}

	void OnReceivedCompletionPacket( BOOL bResult,
									 DWORD dwNumberOfBytesTransferred,
                                     DWORD dwKey,
									 LPOVERLAPPED lpOverlapped );
protected:
	void readFile( CWordCountContext* aCtx );
	void closeFile( CWordCountContext* aCtx );
};