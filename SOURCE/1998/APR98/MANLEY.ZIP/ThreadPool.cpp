// ThreadPool.cpp
#include <assert.h>
#include <process.h>
#include "ThreadPool.h"
#include "Worker.h"


CThreadPool::CThreadPool( DWORD numWorkerThreads, DWORD threadConcurrency ) :
	m_bStarted( FALSE ),
	m_NumThreads( numWorkerThreads ),
	m_ThreadConcurrency( threadConcurrency ), 
	m_hCompletionPort( INVALID_HANDLE_VALUE ),
	m_ThreadArray( NULL )
{
	assert( numWorkerThreads >= 0 && numWorkerThreads <= 64 ); 

	if( m_NumThreads == 0 ) {
		// if default value of 0 was used, create n
		// threads where n = 2 * number of processors + 2
		SYSTEM_INFO sysinfo ;
		GetSystemInfo( &sysinfo ) ;
		m_NumThreads = sysinfo.dwNumberOfProcessors * 2 + 2;
	} // if

	m_ThreadArray = new CWorkerThread*[ m_NumThreads ];
}


CThreadPool::~CThreadPool()
{
	Stop();
	delete [] m_ThreadArray ;
}


void CThreadPool::Start()
{
	if( ! m_bStarted ) {

		m_hCompletionPort = CreateIoCompletionPort( INVALID_HANDLE_VALUE, 
											NULL, 0, m_ThreadConcurrency );
		assert( m_hCompletionPort != NULL );
		createWorkerThreads();
		startWorkerThreads();
		m_bStarted = TRUE ;
	} // if
}



void CThreadPool::Stop()
{
	if( m_bStarted ) {
		stopWorkerThreads();
		destroyWorkerThreads(); 
		CloseHandle( m_hCompletionPort ); 
		m_bStarted = FALSE ;
	} // if
}



BOOL CThreadPool::AssociateFile( HANDLE hFile, DWORD dwKey )
{
	// Associate the file handle with our existing completion port
    HANDLE hResult = CreateIoCompletionPort( hFile, m_hCompletionPort, dwKey, m_ThreadConcurrency ); 
	return (hResult != NULL );
}



BOOL CThreadPool::PostQueuedCompletionStatus( DWORD dwKey,
											  DWORD dwBytesTransferred,
											  LPOVERLAPPED lpOverlapped )
{
	BOOL bResult = ::PostQueuedCompletionStatus( m_hCompletionPort,	dwBytesTransferred,
													dwKey, lpOverlapped );
	return bResult ;
}



BOOL CThreadPool::GetQueuedCompletionStatus( LPDWORD lpNumberOfBytesTransferred,	
									LPDWORD lpdwKey, LPOVERLAPPED *lpOverlapped, 
									DWORD dwTimeout )
{
	BOOL bResult = ::GetQueuedCompletionStatus(
			m_hCompletionPort,
			lpNumberOfBytesTransferred,
			lpdwKey,
			lpOverlapped,
			dwTimeout );

	return bResult ;
}


void CThreadPool::createWorkerThreads()
{
	// Instantiate threads by calling virtual function in derived class
	for( DWORD i=0; i<m_NumThreads; i++ ) {
		m_ThreadArray[ i ] = CreateWorkerThread( this );
		assert( m_ThreadArray[ i ] != NULL );
	} // for
}



void CThreadPool::destroyWorkerThreads()
{
	for( DWORD i=0; i<m_NumThreads; i++ ) {
		DestroyWorkerThread( m_ThreadArray[i] ); 
		m_ThreadArray[ i ] = NULL ;
	} // for
}



void CThreadPool::startWorkerThreads()
{
	for( DWORD i=0; i<m_NumThreads; i++ ) {
		m_ThreadArray[i]->Start(); 
	} // for
}



void CThreadPool::stopWorkerThreads()
{
	for( DWORD i=0; i<m_NumThreads; i++ ) {
		BOOL bResult = PostQueuedCompletionStatus( STOP_WORKER_THREAD ); 
		assert( bResult == TRUE ); 
	} // while

	WaitForThreadCompletion(); 
}



void CThreadPool::WaitForThreadCompletion()
{
	HANDLE* aHandles = new HANDLE[ m_NumThreads ]; 
	for( DWORD i=0; i<m_NumThreads; i++ ) {
		aHandles[i] = m_ThreadArray[i]->GetThreadHandle(); 
	} // for

	// Wait for all threads to finish
	WaitForMultipleObjects( m_NumThreads, aHandles, TRUE, INFINITE ); 
	delete [] aHandles ;
}



void CThreadPool::DestroyWorkerThread( CWorkerThread* pThread )
{
	assert( pThread != NULL ); 
	delete pThread;
}