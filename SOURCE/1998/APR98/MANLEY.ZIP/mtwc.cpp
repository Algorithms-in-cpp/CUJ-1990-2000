// mtwc.cpp
#include "mtwc.h"


CWordCountContext::CWordCountContext() :
	lpszFilename( NULL ),
	hFile( INVALID_HANDLE_VALUE ),
	state( STATE_UNOPENED ),
	spaceState( 0 ),
	dwNumChars( 0 ),
	dwNumWords( 0 ),
	dwNumLines( 0 )
{
	ZeroMemory( &overlapped, sizeof( overlapped ) );
	ZeroMemory( &buffer, sizeof( buffer ) );
}



void CWordCountWorker::OnReceivedCompletionPacket( BOOL bResult,
												   DWORD dwNumberOfBytesTransferred,
                                                   DWORD dwKey,
												   LPOVERLAPPED lpOverlapped )
{
    CWordCountContext* pContext = reinterpret_cast<CWordCountContext*>(dwKey);

	if( pContext->state == CWordCountContext::STATE_UNOPENED ) {
		pContext->hFile = CreateFile( pContext->lpszFilename, GENERIC_READ, FILE_SHARE_READ,
										NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED | FILE_FLAG_SEQUENTIAL_SCAN, NULL );

		if( pContext->hFile == INVALID_HANDLE_VALUE ) {
			pContext->state = CWordCountContext::STATE_ERROR_OPENING ;
			closeFile( pContext );
		} else {
			// Associate overlapped operations on this file with our I/O completion port
			m_pThreadPool->AssociateFile( pContext->hFile, reinterpret_cast<DWORD>(pContext) );
			pContext->state = CWordCountContext::STATE_OPENED ;
			readFile( pContext ); // kick off first read...
		} // else
	} else if( pContext->state == CWordCountContext::STATE_OPENED ) {
		if( dwNumberOfBytesTransferred == 0 ) {
			// we are at end of file
			closeFile( pContext );
		} else {
			// This is the guts of the word-counting...
			for( DWORD i=0; i<dwNumberOfBytesTransferred; i++ ) {
				char c = pContext->buffer[i];
				if( c == '\n' ) {
					pContext->dwNumLines++ ;
				} else if( isspace( c ) ) {
					pContext->spaceState = 0;
				} else if( pContext->spaceState == 0 ) {
					pContext->spaceState = 1 ;
					pContext->dwNumWords++ ;
				} // else
            } // for

			pContext->dwNumChars += dwNumberOfBytesTransferred ;
			lpOverlapped->Offset += dwNumberOfBytesTransferred ;
			readFile( pContext );
		} // else
	} else {
		// unknown state--should never happen
		assert(0);
	} // else
}



void CWordCountWorker::readFile( CWordCountContext* pContext )
{
	BOOL bResult = ReadFile( pContext->hFile, &(pContext->buffer), READ_BUFFER_SIZE,
									NULL, &(pContext->overlapped) );
	if( bResult == FALSE ) {
		DWORD dwLastError = GetLastError();
		if( dwLastError == ERROR_IO_PENDING ) {
			// asynchronous read was queued, this is normal result...
		} else if( dwLastError == ERROR_HANDLE_EOF ) {
			closeFile( pContext );
		} else {
			pContext->state = CWordCountContext::STATE_ERROR_READING ;
			closeFile( pContext );
		} // else
	} // if
}


void CWordCountWorker::closeFile( CWordCountContext* pContext )
{
	pContext->state = CWordCountContext::STATE_CLOSED ;
	if( pContext->hFile != INVALID_HANDLE_VALUE ) {
		CloseHandle( pContext->hFile );
	} // if
	dynamic_cast<CWordCountThreadPool*>(m_pThreadPool)->ProcessedFile();
}



CWordCountThreadPool::CWordCountThreadPool( DWORD numThreads, DWORD threadConcurrency, DWORD numFiles ) :
	CThreadPool( numThreads, threadConcurrency ),
	m_NumFiles( numFiles )
{
	assert( numFiles > 0 );
	m_hDone = CreateEvent( NULL, TRUE, FALSE, NULL );
}


CWordCountThreadPool::~CWordCountThreadPool()
{
	CloseHandle( m_hDone );
}


CWorkerThread* CWordCountThreadPool::CreateWorkerThread( CThreadPool* )
{
	return new CWordCountWorker( this );
}



void CWordCountThreadPool::WaitUntilDone()
{
	WaitForSingleObject( m_hDone, INFINITE );
}


void CWordCountThreadPool::ProcessedFile()
{
	InterlockedDecrement( &m_NumFiles );
	if( m_NumFiles == 0 ) {
		SetEvent( m_hDone );
	} // if
}



void reportResultLine( LPSTR lpszFilename, DWORD numChars, DWORD numWords, DWORD numLines )
{
	cout << lpszFilename ;

	cout.width(56-strlen( lpszFilename ) );
	cout << numChars ;

	cout.width(11);
	cout << numWords ;

	cout.width(11);
	cout << numLines << endl ;

}


void reportResults( CWordCountContext* aCtx, int numItems )
{
	DWORD totalChars = 0, totalWords = 0, totalLines = 0 ;

	cout << "File                                               Chars     Words       Lines" << endl ;
	cout << "--------------------------------------------- ---------- ---------- ----------" << endl ;
	for( int i=0; i<numItems; i++ ) {
		if( aCtx[i].state == CWordCountContext::STATE_ERROR_OPENING ) {
			cout << "Error opening file '" << aCtx[i].lpszFilename << "'" << endl;
		} else if( aCtx[i].state == CWordCountContext::STATE_ERROR_READING ) {
			cout << "Error reading file '" << aCtx[i].lpszFilename << "'" << endl;
		} else {
			reportResultLine( aCtx[i].lpszFilename, aCtx[i].dwNumChars,
								aCtx[i].dwNumWords, aCtx[i].dwNumLines );
			totalChars += aCtx[i].dwNumChars ;
			totalWords += aCtx[i].dwNumWords ;
			totalLines += aCtx[i].dwNumLines ;
		} // else
	} // for

	cout << "--------------------------------------------- ---------- ---------- ----------" << endl ;
	reportResultLine( "TOTAL", totalChars, totalWords, totalLines );
}


int main( int argc, char* argv[] )
{
	CWordCountContext* aCtx = NULL ;

	try {
		if( argc < 2 ) {
			cerr << "Usage: mtwc <file1> [ <file2> ... <filen> ]" << endl
				 << "Counts lines, words, chars in files and reports results" << endl;
			return 0 ;
		} // if

		int numFiles = argc-1 ; // -1 since program name is first argument
		aCtx = new CWordCountContext[ numFiles ];

		CWordCountThreadPool threadPool( NUM_WORKER_THREADS, THREAD_CONCURRENCY, numFiles );
		threadPool.Start();

		for( int i=0; i<numFiles; i++ ) {
			aCtx[i].lpszFilename = argv[i+1]; // assign file name to context
			// kick off a worker thread
			threadPool.PostQueuedCompletionStatus( reinterpret_cast<DWORD>( &(aCtx[i]) ) );
		} // for

		// wait for threads to complete...
		threadPool.WaitUntilDone();
		threadPool.Stop();

		reportResults( aCtx, numFiles );

	} catch( ... ) {
		cerr << "Unhandled exception" << endl ;
	} // catch

	if( aCtx != NULL ) {
		delete [] aCtx ;
	} // if

	return 0 ;
}