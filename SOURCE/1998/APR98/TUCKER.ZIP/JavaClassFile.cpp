/*
	C++ Class for reading info from a Java Class file

	AST 9/97
*/

#include <fstream>
#include "JavaClassFile.h"

// constructors/destructor

JavaClassFile::JavaClassFile()
{
	m_pConstPool = new JavaConstPool(this);
	m_pbClassData = NULL;
	m_bLoadedCP = false;
}

JavaClassFile::JavaClassFile( const string &crstrFile )
{
	m_pConstPool = new JavaConstPool(this);
	m_pbClassData = NULL;
	m_bLoadedCP = false;
	Open(crstrFile);
}

JavaClassFile::~JavaClassFile()
{
	Close();
}

// public methods

bool JavaClassFile::Open( const string &crstrFile )
{
	bool		bRetVal = false;
	ifstream	infile(crstrFile.c_str(), ios::in | ios::binary );

	try
	{
		if ( infile.is_open() )
		{
			long lFileSize = 0;

			// get the file length
			infile.seekg(0,ios::end);
			lFileSize = infile.tellg();
			infile.seekg(0,ios::beg);

			// get the file's data
			m_pbClassData = new BYTE[lFileSize];
			infile.read((char*)m_pbClassData, lFileSize);

			// make sure that this is a valid class file
			bRetVal = IsValidClassFile();
			if ( bRetVal == false )
			{
				delete [] m_pbClassData;
				m_pbClassData = NULL;
			}
		}
	}
	catch(...)
	{
		if ( m_pbClassData )
		{
			delete [] m_pbClassData;
			m_pbClassData = NULL;
		}
		bRetVal = false;
	}

	return bRetVal;
}

bool JavaClassFile::IsOpen() const
{
	return IsValidClassFile();
}

bool JavaClassFile::Close()
{
	bool bRetVal = false;

	if ( IsOpen() )
	{
		delete [] m_pbClassData;
		m_pbClassData = NULL;
		bRetVal = true;
	}

	return bRetVal;
}

WORD JavaClassFile::GetMinorVersion() const
{
	WORD wMinorVer = 0;

	if ( IsOpen() )
	{
		// minor version is a word starting at offset 4
		wMinorVer =  ReadWORD(4);
	}

	return wMinorVer;
}

WORD JavaClassFile::GetMajorVersion() const
{
	WORD wMajorVer = 0;

	if ( IsOpen() )
	{
		// major version is a word starting at offset 6
		wMajorVer =  ReadWORD(6);
	}

	return wMajorVer;
}

WORD JavaClassFile::GetConstantPoolCount() const
{
	return m_pConstPool->GetCount();
}

wstring  JavaClassFile::GetConstantPoolEntry( WORD wIndex )
{
	wstring	wstrEntry;
	WORD	wCPMax = GetConstantPoolCount();

	// index 0 is reserved for historical reasons, 
	// so don't allow access to it

	if ( IsOpen() && wIndex > 0 && wIndex < wCPMax )
	{
		// load the constant pool if it isn't already
		if ( m_bLoadedCP == false )
		{
			m_pConstPool->LoadConstantPool();
			m_bLoadedCP = true;
		}
		
		wstrEntry = m_pConstPool->GetEntry(wIndex);
	}

	return wstrEntry;
}

WORD JavaClassFile::GetClassAccess()
{
	WORD wAccess = 0;

	if ( IsOpen() )
	{
		DWORD dwDataIndex;
		
		dwDataIndex = GetHeaderSize();
		dwDataIndex += GetConstPoolSize();

		wAccess = ReadWORD(dwDataIndex);
	}

	return wAccess;
}

wstring	JavaClassFile::GetClassName()
{
	wstring wstrClassName;

	if ( IsOpen() )
	{
		DWORD dwDataIndex;
		
		dwDataIndex = GetHeaderSize();
		dwDataIndex += GetConstPoolSize();

		dwDataIndex += sizeof(WORD);

		// read the string index and return the CP entry
		WORD wIndex = ReadWORD(dwDataIndex);
		wstrClassName = GetConstantPoolEntry(wIndex);
	}

	return wstrClassName;
}


wstring JavaClassFile::GetSuperClassName()
{
	wstring wstrClassName;

	if ( IsOpen() )
	{
		DWORD dwDataIndex;
		
		dwDataIndex = GetHeaderSize(); 
		dwDataIndex += GetConstPoolSize();
		// skip previous entries
		dwDataIndex += (sizeof(WORD) * 2);

		WORD wIndex = ReadWORD(dwDataIndex);
		wstrClassName = GetConstantPoolEntry(wIndex);
	}

	return wstrClassName;
}


WORD JavaClassFile::GetInterfaceCount()
{
	WORD wCount = 0;

	if ( IsOpen() )
	{
		DWORD dwDataIndex;
		
		dwDataIndex = GetHeaderSize();
		dwDataIndex += GetConstPoolSize();
		// skip previous entries
		dwDataIndex += (sizeof(WORD) * 3);

		wCount = ReadWORD(dwDataIndex);
	}

	return wCount;
}

wstring JavaClassFile::GetInterfaceName( WORD wIndex )
{
	wstring wstrIFace;

	if ( IsOpen() && ( wIndex >=0 && wIndex < GetInterfaceCount()) )
	{
		DWORD dwDataIndex;
		
		dwDataIndex = GetHeaderSize();
		dwDataIndex += GetConstPoolSize();
		// skip previous entries
		dwDataIndex += (sizeof(WORD) * 3);

		// skip the iface count
		dwDataIndex += sizeof(WORD);

		// move to the iface we're looking for
		dwDataIndex += (wIndex * sizeof(WORD));

		WORD wCPIndex = ReadWORD(dwDataIndex);
		wstrIFace = GetConstantPoolEntry(wCPIndex);
	}

	return wstrIFace;
}


WORD JavaClassFile::GetFieldCount()
{
	WORD wCount = 0;

	//NOTE: GetFieldDataIndex calls this routine so calling
	// it here will result in infinite recursion 

	if ( IsOpen() )
	{
		DWORD dwDataIndex;

		dwDataIndex = GetHeaderSize();
		dwDataIndex += GetConstPoolSize();
		// skip previous entries
		dwDataIndex += (sizeof(WORD) * 3);

		// skip the iface count and data
		dwDataIndex += sizeof(WORD);
		dwDataIndex += (GetInterfaceCount() * sizeof(WORD));

		wCount = ReadWORD(dwDataIndex);
	}		

	return wCount;
}

wstring JavaClassFile::GetFieldName( WORD wIndex )
{
	wstring wstrName;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetFieldCount() )
	{
		DWORD dwDataIndex = GetFieldDataIndex(wIndex);
		WORD wCPIndex = ReadWORD(dwDataIndex+sizeof(WORD));

		wstrName = GetConstantPoolEntry( wCPIndex );
	}

	return wstrName;
}

wstring JavaClassFile::GetFieldType( WORD wIndex )
{
	wstring wstrType;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetFieldCount() )
	{
		DWORD dwDataIndex = GetFieldDataIndex(wIndex);
		WORD wCPIndex = ReadWORD(dwDataIndex+sizeof(WORD)+sizeof(WORD));

		wstrType = DecodeDataType(GetConstantPoolEntry( wCPIndex ));
	}

	return wstrType;
}

WORD	JavaClassFile::GetFieldAccess( WORD wIndex )
{
	WORD wAccess = 0;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetFieldCount() )
	{
		DWORD dwDataIndex = GetFieldDataIndex(wIndex);

		wAccess = ReadWORD(dwDataIndex);
	}

	return wAccess;
}

WORD JavaClassFile::GetMethodCount()
{
	WORD wCount = 0;

	//NOTE: GetMethodDataIndex calls this routine so calling
	// it here will result in infinite recursion 

	if ( IsOpen() )
	{
		DWORD dwDataIndex;
		WORD  wFieldCount = GetFieldCount();

		if ( wFieldCount )
		{
			dwDataIndex = GetFieldDataIndex( wFieldCount-1 );

			// skip header fields
			dwDataIndex += (sizeof(WORD) * 3);
			// skip attribute count and data
			WORD wAttribCount = ReadWORD(dwDataIndex);
			dwDataIndex += sizeof(WORD) + (wAttribCount * 8);
		}
		else
		{
			dwDataIndex = GetHeaderSize();
			dwDataIndex += GetConstPoolSize();
			// skip previous entries
			dwDataIndex += (sizeof(WORD) * 3);

			// skip the iface count and data
			dwDataIndex += sizeof(WORD) + (GetInterfaceCount() * sizeof(WORD));

			// skip the field count
			dwDataIndex += sizeof(WORD);
		}

		wCount = ReadWORD(dwDataIndex);
	}		

	return wCount;
}

wstring JavaClassFile::GetMethodName( WORD wIndex )
{
	wstring wstrName;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetMethodCount() )
	{
		DWORD dwDataIndex = GetMethodDataIndex( wIndex );

		wstrName = GetConstantPoolEntry( ReadWORD(dwDataIndex+sizeof(WORD)) );
	}

	return wstrName;
}

wstring JavaClassFile::GetMethodReturnType( WORD wIndex )
{
	wstring wstrType;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetMethodCount() )
	{
		DWORD dwDataIndex = GetMethodDataIndex( wIndex );

		dwDataIndex += (sizeof(WORD)*2);
		wstrType = GetConstantPoolEntry( ReadWORD(dwDataIndex) );
		wstrType = DecodeDataType( wstrType.substr(wstrType.find(_U(')'))+1) );
	}

	return wstrType;
}

WORD	JavaClassFile::GetMethodAccess( WORD wIndex )
{
	WORD wAccess = 0;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetMethodCount() )
	{
		DWORD dwDataIndex = GetMethodDataIndex( wIndex );

		wAccess = ReadWORD(dwDataIndex);
	}

	return wAccess;
}

WORD JavaClassFile::GetMethodArgCount( WORD wIndex )
{
	WORD wCount = 0;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetMethodCount() )
	{
		DWORD dwDataIndex = GetMethodDataIndex( wIndex );
		dwDataIndex += (sizeof(WORD)*2);


		wstring wstrType = GetConstantPoolEntry( ReadWORD(dwDataIndex) );

		// remove (, ), and return type
		wstrType = wstrType.substr( 1, wstrType.find(_U(')'))-1);

		while ( wstrType.size() )
		{
			WORD wSize = DataTypeLength(wstrType);
			wstrType = wstrType.substr( wSize );
			wCount++;
		}
	}

	return wCount;
}

wstring JavaClassFile::GetMethodArgType( WORD wIndex, WORD wArgIndex )
{
	wstring wstrArgType;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetMethodCount() )
	{
		if ( wArgIndex >= 0 && wArgIndex < GetMethodArgCount(wIndex) )
		{
			DWORD dwDataIndex = GetMethodDataIndex( wIndex );
			dwDataIndex += (sizeof(WORD)*2);


			wstrArgType = GetConstantPoolEntry( ReadWORD(dwDataIndex) );

			// remove (, ), and return type
			wstrArgType = wstrArgType.substr( 1, wstrArgType.find(_U(')'))-1);

			while ( wArgIndex-- )
			{
				wstrArgType = wstrArgType.substr( DataTypeLength(wstrArgType) );
			}

			wstrArgType = DecodeDataType(wstrArgType);
		}
	}

	return wstrArgType;
}



// implementation details

bool JavaClassFile::IsValidClassFile() const
{
	bool bRetVal = false;

	if ( m_pbClassData )
	{
		DWORD dwSig = ReadDWORD(0);
		bRetVal = ( dwSig == 0xCAFEBABE );
	}

	return bRetVal;
}

/*
	Return data index of wIndex'th field
*/
DWORD JavaClassFile::GetFieldDataIndex(WORD wIndex)
{
	DWORD dwDataIndex = 0;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetFieldCount() )
	{
		dwDataIndex = GetHeaderSize();
		dwDataIndex += GetConstPoolSize();
		// skip previous entries
		dwDataIndex += (sizeof(WORD) * 3);

		// skip the iface count and data
		dwDataIndex += sizeof(WORD) + (GetInterfaceCount() * sizeof(WORD));

		// skip the field count
		dwDataIndex += sizeof(WORD);

		// iterate through the fields before this one
		while ( wIndex-- )
		{
			// skip header fields
			dwDataIndex += (sizeof(WORD) * 3);
			// skip attribute count and data
			WORD wAttribCount = ReadWORD(dwDataIndex);
			dwDataIndex += sizeof(WORD) + (wAttribCount * 8);
		}
	}

	return dwDataIndex;
}

/*
	Return data index of wIndex'th method	
*/
DWORD JavaClassFile::GetMethodDataIndex(WORD wIndex)
{
	DWORD dwDataIndex = 0;

	if ( IsOpen() && wIndex >= 0 && wIndex < GetMethodCount() )
	{
		WORD  wFieldCount = GetFieldCount();

		if ( wFieldCount )
		{
			dwDataIndex = GetFieldDataIndex( wFieldCount-1 );

			// skip header fields
			dwDataIndex += (sizeof(WORD) * 3);
			// skip attribute count and data
			WORD wAttribCount = ReadWORD(dwDataIndex);
			dwDataIndex += sizeof(WORD) + (wAttribCount * 8);
		}
		else
		{
			dwDataIndex = GetHeaderSize();
			dwDataIndex += GetConstPoolSize();
			// skip previous entries
			dwDataIndex += (sizeof(WORD) * 3);

			// skip the iface count and data
			dwDataIndex += sizeof(WORD) + (GetInterfaceCount() * sizeof(WORD));

			// skip the field count
			dwDataIndex += sizeof(WORD);
		}

		// skip method count
		dwDataIndex += sizeof(WORD);

		// skip previous methods
		while ( wIndex-- )
		{
			// skip header fields
			dwDataIndex += (sizeof(WORD) * 3);

			WORD wAttribCount = ReadWORD(dwDataIndex);

			// skip attrib count
			dwDataIndex += sizeof(WORD);

			while ( wAttribCount-- )
			{
				dwDataIndex += sizeof(WORD);
				DWORD dwAttribSize = ReadDWORD(dwDataIndex);

				dwDataIndex += sizeof(DWORD)+dwAttribSize;
			}
		}
	}

	return dwDataIndex;
}



/*
	Read a DWORD from the byte array starting at the dwIndex'th byte
	Can't just cast to DWORD* because of byte ordering
*/
DWORD JavaClassFile::ReadDWORD(DWORD dwIndex) const
{
	DWORD dw = 0 ;
	int	  iSize = sizeof(DWORD);
	BYTE	*pb = &m_pbClassData[dwIndex];


	while ( iSize-- )
	{
		dw = ( dw << 8 ) | *pb;
		pb++;
	}

	return dw;
}

/*
	Read a WORD from the byte array starting at the dwIndex'th byte
	Can't just cast to WORD* because of byte ordering
*/
WORD JavaClassFile::ReadWORD(DWORD dwIndex) const
{
	WORD	word = 0 ;
	int		iSize = sizeof(WORD);
	BYTE	*pb = &m_pbClassData[dwIndex];

	while ( iSize-- )
	{
		word = ( word << 8 ) | *pb;
		pb++;
	}

	return word;
}


/*
	Return description of Java data type descriptor
*/
wstring JavaClassFile::DecodeDataType( const wstring &crwstrRawType )
{

	wstring wstrType;


	switch( crwstrRawType[0] )
	{
		case _U('B'):
			wstrType = _U("byte");
			break;

		case _U('C'):
			wstrType = _U("char");
			break;

		case _U('D'):
			wstrType = _U("double");
			break;

		case _U('F'):
			wstrType = _U("float");
			break;

		case _U('I'):
			wstrType = _U("int");
			break;

		case _U('J'):
			wstrType = _U("long");
			break;

		case _U('S'):
			wstrType = _U("short");
			break;

		case _U('Z'):
			wstrType = _U("boolean");
			break;

		case _U('V'):
			wstrType = _U("void");
			break;

		case _U('L'):
			wstrType = crwstrRawType.substr( 1, crwstrRawType.find(_U(";"))-1);
			break;

		case _U('['):
			// call recursively to and append the array brackets
			wstrType = DecodeDataType( crwstrRawType.substr(1) );
			wstrType += _U("[]");
			break;

		default:
			wstrType = _U("<unknown>");

	}

	return wstrType;

}

/*
	Return length of first Java data type descriptor in string
*/
WORD JavaClassFile::DataTypeLength( const wstring &crwstrType )
{
	WORD wIndex = 0;

	// skip array chars
	if ( crwstrType[wIndex] == _U('[') )
	{
		// skip all ]
		while ( crwstrType[wIndex] == _U('[') )
			wIndex++;
	}

	// skip class string, 
	if ( crwstrType[wIndex] == _U('L') )
	{
		wIndex += crwstrType.find(_U(';'));
		// trim off trailing ; if necessary
		if ( wIndex < crwstrType.size() )
			wIndex++;
	}
	else
	{
		// skip single char type
		wIndex++;
	}

	return wIndex;
}
