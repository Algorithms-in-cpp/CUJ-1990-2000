/*
	C++ Class for reading info from a Java Class file

	AST 9/97
*/

#ifndef __JAVACLASSFILE_H__
#define __JAVACLASSFILE_H__

#include "CommonTypes.h"
#include "JavaConstPool.h"

class JavaClassFile
{
	public:
		// constructors/destructor
		JavaClassFile();
		JavaClassFile( const string &crstrFile );
		virtual ~JavaClassFile();

		// public methods
		bool Open( const string &crstrFile );
		bool Close();
		bool IsOpen() const ;	

		WORD	GetMinorVersion() const;
		WORD	GetMajorVersion() const;

		wstring	GetClassName();
		wstring GetSuperClassName();
		WORD	GetClassAccess();

		WORD	GetInterfaceCount();
		wstring GetInterfaceName( WORD wIndex );

		enum 
		{ 
			ACC_PUBLIC		= 0x01, 
			ACC_PRIVATE		= 0x02, 
			ACC_PROTECTED	= 0x04,
			ACC_STATIC		= 0x08,
			ACC_FINAL		= 0x10,
			ACC_SYNCHRONIZED= 0x20,
			ACC_VOLATILE	= 0x40,
			ACC_TRANSIENT	= 0x80,
			ACC_NATIVE		= 0x100,
			ACC_INTERFACE	= 0x200,
			ACC_ABSTRACT	= 0x400
		};

		WORD	GetFieldCount();
		wstring GetFieldName( WORD wIndex );
		wstring GetFieldType( WORD wIndex );
   		WORD	GetFieldAccess( WORD wIndex );

		WORD	GetMethodCount();
		wstring GetMethodName( WORD wIndex );
		WORD    GetMethodArgCount( WORD wIndex );
   		wstring GetMethodArgType( WORD wIndex, WORD wArgIndex );
		wstring GetMethodReturnType( WORD wIndex );
		WORD	GetMethodAccess( WORD wIndex );

	protected:
		// implementation details
		bool IsValidClassFile() const;

		DWORD	ReadDWORD(DWORD dwIndex) const;
	    WORD	ReadWORD(DWORD dwIndex) const;
		BYTE	*m_pbClassData;

		// constant pool
		bool			m_bLoadedCP;
		JavaConstPool	*m_pConstPool;
		friend class JavaConstPool;

		WORD	GetConstantPoolCount() const;
		wstring GetConstantPoolEntry( WORD wIndex );
	  
		// index helper functions
		DWORD	GetFieldDataIndex(WORD wIndex);
		DWORD	GetMethodDataIndex(WORD wIndex);

		inline DWORD	GetHeaderSize()	   { return (sizeof(DWORD) + (sizeof(WORD) * 3)); }	
		inline DWORD	GetConstPoolSize() { return m_pConstPool->GetSize(); }	

		// datatype helper functions
		wstring DecodeDataType( const wstring &crwstrRawType );
		WORD	DataTypeLength( const wstring &crwstrType );

};		

#endif