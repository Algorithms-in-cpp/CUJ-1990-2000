/*
	This is a utility for extracting class declaration information
	from a Java Class file.

	AST 9/97
*/

#include <iostream>
#include "JavaClassFile.h"


using namespace std;

wstring MassageType( const wstring &wstrType );


int main(int argc, char **argv)
{

	if ( argc < 2 )
	{
		wcerr << _U("syntax: ClassDump <filename>") << endl;
		exit(0);
	}

	JavaClassFile cfile(argv[1]);

	if ( cfile.IsOpen() )
	{
		WORD wAccess;
		WORD wCount;

		wAccess = cfile.GetClassAccess();


		if ( wAccess & JavaClassFile::ACC_PUBLIC) 
			wcout << _U("public ");
		if ( wAccess & JavaClassFile::ACC_FINAL) 
			wcout << _U("final ");
		if ( wAccess & JavaClassFile::ACC_ABSTRACT) 
			wcout << _U("abstract ");
		if ( wAccess & JavaClassFile::ACC_INTERFACE) 
			wcout << _U("interface ");
		else
			wcout << _U("class ");

		wcout << MassageType(cfile.GetClassName()) << _U(" ");

		wCount = cfile.GetInterfaceCount();
		if ( wCount )
		{
		wcout << _U("implements ");

			for ( WORD wCur = 0; wCur < wCount; wCur++ )
			{
				wcout << MassageType(cfile.GetInterfaceName(wCur));

				if ( wCur == wCount-1 )
					wcout << _U(" ");
				else
					wcout << _U(", ");
			}
		}

		wcout << _U("extends ") << MassageType(cfile.GetSuperClassName()) << endl;
		wcout << _U("{") << endl << endl;


		wCount = cfile.GetFieldCount();
		if ( wCount )
		{

			wcout << _U("\t// Fields") << endl;

			for ( WORD wCur = 0; wCur < wCount; wCur++ )
			{
				wcout << _U("\t");

				WORD wAccess = cfile.GetFieldAccess(wCur);

				if ( wAccess & JavaClassFile::ACC_PUBLIC) 
					wcout << _U("public ");
				if ( wAccess & JavaClassFile::ACC_PRIVATE) 
					wcout << _U("private ");
				if ( wAccess & JavaClassFile::ACC_PROTECTED) 
					wcout << _U("protected ");
				if ( wAccess & JavaClassFile::ACC_STATIC) 
					wcout << _U("static ");
				if ( wAccess & JavaClassFile::ACC_FINAL) 
					wcout << _U("final ");
				if ( wAccess & JavaClassFile::ACC_VOLATILE) 
					wcout << _U("volatile ");
				if ( wAccess & JavaClassFile::ACC_TRANSIENT) 
					wcout << _U("transient ");

				wcout << MassageType(cfile.GetFieldType(wCur)) << _U(" ");
				wcout << cfile.GetFieldName(wCur) << _U(";") << endl;
			}

			wcout << endl;
		}

		wCount = cfile.GetMethodCount();
		if ( wCount )
		{

			wcout << _U("\t// Methods") << endl;

			for ( WORD wCur = 0; wCur < wCount; wCur++ )
			{
				wcout << _U("\t"); 

				WORD wAccess = cfile.GetMethodAccess(wCur);

				if ( wAccess & JavaClassFile::ACC_PUBLIC) 
					wcout << _U("public ");
				if ( wAccess & JavaClassFile::ACC_PRIVATE) 
					wcout << _U("private ");
				if ( wAccess & JavaClassFile::ACC_PROTECTED) 
					wcout << _U("protected ");
				if ( wAccess & JavaClassFile::ACC_STATIC) 
					wcout << _U("static ");
				if ( wAccess & JavaClassFile::ACC_FINAL) 
					wcout << _U("final ");
				if ( wAccess & JavaClassFile::ACC_ABSTRACT) 
					wcout << _U("abstract ");
				if ( wAccess & JavaClassFile::ACC_SYNCHRONIZED) 
					wcout << _U("synchronized ");
				if ( wAccess & JavaClassFile::ACC_NATIVE) 
					wcout << _U("native ");

				wcout << MassageType(cfile.GetMethodReturnType(wCur)) << _U(" ");
				wcout << cfile.GetMethodName(wCur) << _U("(");

				WORD wArgCount = cfile.GetMethodArgCount( wCur );
				if ( wArgCount )
				{
					wcout << _U(" ");

					for ( WORD wCurArg = 0; wCurArg < wArgCount; wCurArg++ )
					{
						wcout << MassageType(cfile.GetMethodArgType(wCur, wCurArg));
						if ( wCurArg != (wArgCount-1) )
							wcout << _U(",");
						wcout << _U(" ");
					}
				}

				wcout << _U(");") << endl;
			}

			wcout << endl;
		}


		wcout << _U("}");
	}
	else
	{
		cout << argv[1] << " is not a valid class file" << endl;
	}

	return 0;
}

wstring MassageType( const wstring &crwstrType )
{
	wstring wstrT = crwstrType;

	int nIndex = wstrT.find(_U('/'));
	while ( nIndex != wstring::npos )
	{
		wstrT[nIndex] = _U('.');
		nIndex = wstrT.find(_U('/'));
	}

	return wstrT;
}
