/*
	Class to encapsulate Java Class file constant pool I/O

	AST 9/97
*/


#ifndef __JAVACONSTPOOL_H__
#define __JAVACONSTPOOL_H__

#include "CommonTypes.h"

// forward delcarations
class JavaClassFile;

class JavaConstPool
{
	public:
		JavaConstPool( JavaClassFile *pClassFile );
		virtual ~JavaConstPool();

	private:

		JavaClassFile	*m_pClassFile;
		friend class JavaClassFile;

		WORD	GetCount() const;
		wstring GetEntry( WORD wIndex ) const;
		
		enum
		{
			CONSTANT_Utf8 =			1,
			CONSTANT_Integer =		3,
			CONSTANT_Float=			4,
			CONSTANT_Long =			5,
			CONSTANT_Double =		6,
			CONSTANT_String =		7,
			CONSTANT_Class =		8,
			CONSTANT_Fieldref =		9,
			CONSTANT_Methodref =	10,
			CONSTANT_InterfaceMethodref =	11,
			CONSTANT_NameAndType =			12,
		};

		void LoadConstantPool();


		struct ConstPoolEntry
		{
			BYTE	chType;
			//wstring can't be in a union because of copy constructor
			wstring	wstrData;	
			union
			{
				struct Indexes
				{
					WORD wIndex1;
					WORD wIndex2;
				} index;
				int		intData;
				INT64	longData;
				float	floatData;
				double	doubleData;
			};
		}; 

		ConstPoolEntry	*m_pConstPool;

		WORD	ReadUtf8Entry( WORD wStartIndex, WORD wEntryIndex);
		WORD	ReadIntegerEntry( WORD wStartIndex, WORD wEntryIndex);
		WORD	ReadFloatEntry( WORD wStartIndex, WORD wEntryIndex);
		WORD	ReadLongEntry( WORD wStartIndex, WORD wEntryIndex);
		WORD	ReadDoubleEntry( WORD wStartIndex, WORD wEntryIndex);
		WORD	ReadOneRefEntry( WORD wStartIndex, WORD wEntryIndex);
		WORD	ReadTwoRefEntry( WORD wStartIndex, WORD wEntryIndex);

		DWORD	m_dwSize;
		DWORD	GetSize();

};

#endif