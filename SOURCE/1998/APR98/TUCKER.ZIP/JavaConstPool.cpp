/*
	Class to encapsulate Java Class file constant pool I/O

	AST 9/97
*/

#include "JavaClassFile.h"
#include "JavaConstPool.h"

// constructors/destructor

JavaConstPool::JavaConstPool( JavaClassFile *pClassFile )
{
	m_pClassFile = pClassFile;
	m_pConstPool = NULL;
	m_dwSize = 0;
}												  

JavaConstPool::~JavaConstPool()
{
	if ( m_pConstPool )
	{
		delete [] m_pConstPool;
		m_pConstPool = NULL;
	}
}

// implementation details

/*
	Retrieve the number of constant pool entries
	Return 0 if file is not open
*/
WORD JavaConstPool::GetCount() const
{
	WORD wCount = 0;

	if ( m_pClassFile && m_pClassFile->IsOpen() )
	{
		// pool count is a word starting at offset 8
		wCount =  m_pClassFile->ReadWORD(8);
	}

	return wCount;
}

/*
	Return the size of the constant pool in bytes
*/
DWORD JavaConstPool::GetSize()
{
	// make sure we have calculated it
	if ( m_dwSize == 0 )
		LoadConstantPool();

	return m_dwSize;
}

/*
	Return the const pool wIndex'th entry as a string
*/
wstring JavaConstPool::GetEntry( WORD wIndex ) const
{
	wstring		wstrData;

	if ( m_pConstPool && wIndex > 0 && wIndex < GetCount() )
	{
		wstringstream strstrBuf;

		switch( m_pConstPool[wIndex].chType )
		{
			case CONSTANT_Utf8:
				strstrBuf << m_pConstPool[wIndex].wstrData;
				break;

			case CONSTANT_Integer:
				strstrBuf << m_pConstPool[wIndex].intData;
				break;

			case CONSTANT_Float:
				strstrBuf << m_pConstPool[wIndex].floatData;
				break;

			case CONSTANT_Long:
				strstrBuf << m_pConstPool[wIndex].longData;
				break;

			case CONSTANT_Double:
				strstrBuf << m_pConstPool[wIndex].doubleData;
				break;

			case CONSTANT_String:
			case CONSTANT_Class:
				{
					WORD wUtf8Index = m_pConstPool[wIndex].index.wIndex1;
					strstrBuf << m_pConstPool[wUtf8Index].wstrData;
				}
				break;

			case CONSTANT_Fieldref:
			case CONSTANT_Methodref:
			case CONSTANT_InterfaceMethodref:
			case CONSTANT_NameAndType:
				strstrBuf << _U("(") << m_pConstPool[wIndex].index.wIndex1;
				strstrBuf << _U(",") << m_pConstPool[wIndex].index.wIndex2 << _U(")");
				break;
		}


		wstrData = strstrBuf.str();
	}
	else
	{
		// error
	}

	return wstrData;
}

/*
	Load the constant pool into a class local data structure
*/
void JavaConstPool::LoadConstantPool()
{
	if ( m_pClassFile && m_pConstPool == NULL )
	{
		WORD	wMaxCPEntries = GetCount();

		try
		{
			m_pConstPool = new ConstPoolEntry[wMaxCPEntries];
		}
		catch(...)
		{
			m_pConstPool = NULL;
			return;
		}

		// first CP entry starts at offset 10
		const DWORD CP_START_INDEX = 10;

		DWORD		dwDataIndex = CP_START_INDEX;
		const BYTE	*pcbData = m_pClassFile->m_pbClassData;


		// Note that we start the index at 1.  
		// Index 0 is reserved for historical reasons

		for( int iEntryIndex = 1; iEntryIndex < wMaxCPEntries; iEntryIndex++ )
		{
			m_pConstPool[iEntryIndex].chType = pcbData[dwDataIndex++];

			switch ( m_pConstPool[iEntryIndex].chType )
			{
				case CONSTANT_Utf8:
					dwDataIndex += ReadUtf8Entry(dwDataIndex, iEntryIndex);
					break;

				case CONSTANT_Integer:
					dwDataIndex += ReadIntegerEntry(dwDataIndex, iEntryIndex);
					break;

				case CONSTANT_Float:
					dwDataIndex += ReadFloatEntry(dwDataIndex, iEntryIndex);
					break;

				case CONSTANT_Long:
					dwDataIndex += ReadLongEntry(dwDataIndex, iEntryIndex);

					// longs take up 2 entries for historical reasons
					// so duplicate the CP data
					iEntryIndex++;
					m_pConstPool[iEntryIndex].chType = CONSTANT_Long;
					m_pConstPool[iEntryIndex].longData = m_pConstPool[iEntryIndex-1].longData;
					break;

				case CONSTANT_Double:
					dwDataIndex += ReadDoubleEntry(dwDataIndex, iEntryIndex);

					// doubles take up 2 entries for historical reasons
					// so duplicate the CP data
					iEntryIndex++;
					m_pConstPool[iEntryIndex].chType = CONSTANT_Double;
					m_pConstPool[iEntryIndex].doubleData = m_pConstPool[iEntryIndex-1].doubleData;
					break;

				case CONSTANT_String:
				case CONSTANT_Class:
					dwDataIndex += ReadOneRefEntry(dwDataIndex, iEntryIndex);
					break;

				case CONSTANT_Fieldref:
				case CONSTANT_Methodref:
				case CONSTANT_InterfaceMethodref:
				case CONSTANT_NameAndType:
					dwDataIndex += ReadTwoRefEntry(dwDataIndex, iEntryIndex);
					break;
			}
		}


		// fill in the size of the constant pool
		m_dwSize = dwDataIndex - CP_START_INDEX;
	}
}

/*
	Read const pool Utf8 Entry from the class data starting at
	wStartIndex and store data in the wIndex'th entry of m_pConstPool.  
	Return the number of bytes that we consumed.
*/
WORD JavaConstPool::ReadUtf8Entry( WORD wStartIndex, WORD wEntryIndex)
{

	// convenient constants for checking and masking bits
	const BYTE	HIGH_BIT = 0x80;
	const BYTE	HIGH_2_BITS = 0xC0;
	const BYTE	HIGH_3_BITS = 0xE0;
	const BYTE	LOW_4_BITS = 0x0F;
	const BYTE	LOW_5_BITS = 0x1F;
	const BYTE	LOW_6_BITS = 0x3F;

	BYTE 		*pbData = &m_pClassFile->m_pbClassData[wStartIndex];
	WORD		wDataLen = m_pClassFile->ReadWORD(wStartIndex);
	WORD		wDataIndex = 0;

	// skip the length
	pbData += sizeof(WORD);

	while ( wDataIndex < wDataLen )
	{
		if ( (pbData[wDataIndex] & HIGH_BIT) == 0 )
		{
			m_pConstPool[wEntryIndex].wstrData += (wchar_t)pbData[wDataIndex++];
		}
		else if ( (pbData[wDataIndex] & HIGH_2_BITS) == HIGH_2_BITS )
		{
			wchar_t wchT;
			
			wchT = pbData[wDataIndex] & LOW_5_BITS;
			wchT += pbData[wDataIndex+1] & LOW_6_BITS;

			m_pConstPool[wEntryIndex].wstrData += wchT;
			wDataIndex += 2;
		}
		else 
		{
			wchar_t wchT;

			wchT = pbData[wDataIndex] & LOW_4_BITS;
			wchT += pbData[wDataIndex+1] & LOW_6_BITS;
			wchT += pbData[wDataIndex+2] & LOW_6_BITS;

			m_pConstPool[wEntryIndex].wstrData += wchT;
			wDataIndex += 3;
		}
	}

	return sizeof(WORD) + wDataLen;
}


/*
	Read const pool Integer Entry from the class data starting at
	wStartIndex and store data in the wIndex'th entry of m_pConstPool.  
	Return the number of bytes that we consumed.
*/
WORD JavaConstPool::ReadIntegerEntry( WORD wStartIndex, WORD wEntryIndex)
{
	m_pConstPool[wEntryIndex].intData = (int)m_pClassFile->ReadDWORD(wStartIndex);

	return sizeof(DWORD);
}

/*
	Read const pool Float Entry from the class data starting at
	wStartIndex and store data in the wIndex'th entry of m_pConstPool.  
	Return the number of bytes that we consumed.
*/
WORD JavaConstPool::ReadFloatEntry( WORD wStartIndex, WORD wEntryIndex)
{
	BYTE *pbFloat = (BYTE*)&m_pConstPool[wEntryIndex].floatData;

	// have to stuff in bytes in reverse order because 
	// of endian mismatch
	pbFloat[0] = m_pClassFile->m_pbClassData[wStartIndex+3];
	pbFloat[1] = m_pClassFile->m_pbClassData[wStartIndex+2];
	pbFloat[2] = m_pClassFile->m_pbClassData[wStartIndex+1];
	pbFloat[3] = m_pClassFile->m_pbClassData[wStartIndex+0];
	
	return sizeof(DWORD);
}

/*
	Read const pool Long Entry from the class data starting at
	wStartIndex and store data in the wIndex'th entry of m_pConstPool.  
	Return the number of bytes that we consumed.
*/
WORD JavaConstPool::ReadLongEntry( WORD wStartIndex, WORD wEntryIndex)
{
	INT64 llHi = m_pClassFile->ReadDWORD(wStartIndex);
	INT64 llLo = m_pClassFile->ReadDWORD(wStartIndex+sizeof(DWORD));

	m_pConstPool[wEntryIndex].longData = ((llHi << 32) | llLo);

	return sizeof(DWORD) + sizeof(DWORD);
}

/*
	Read const pool Double Entry from the class data starting at
	wStartIndex and store data in the wIndex'th entry of m_pConstPool.  
	Return the number of bytes that we consumed.
*/
WORD JavaConstPool::ReadDoubleEntry( WORD wStartIndex, WORD wEntryIndex)
{
	BYTE *pbDouble = (BYTE*)&m_pConstPool[wEntryIndex].doubleData;

	// have to stuff in bytes in reverse order because 
	// of endian mismatch
	pbDouble[0] = m_pClassFile->m_pbClassData[wStartIndex+7];
	pbDouble[1] = m_pClassFile->m_pbClassData[wStartIndex+6];
	pbDouble[2] = m_pClassFile->m_pbClassData[wStartIndex+5];
	pbDouble[3] = m_pClassFile->m_pbClassData[wStartIndex+4];
	pbDouble[4] = m_pClassFile->m_pbClassData[wStartIndex+3];
	pbDouble[5] = m_pClassFile->m_pbClassData[wStartIndex+2];
	pbDouble[6] = m_pClassFile->m_pbClassData[wStartIndex+1];
	pbDouble[7] = m_pClassFile->m_pbClassData[wStartIndex+0];

	return sizeof(DWORD) + sizeof(DWORD);
}

/*
	Read const pool Entry that contains one WORD index from the class 
	data starting at wStartIndex and store data in the wIndex'th entry 
	of m_pConstPool.  Return the number of bytes that we consumed.
*/
WORD JavaConstPool::ReadOneRefEntry( WORD wStartIndex, WORD wEntryIndex)
{
	m_pConstPool[wEntryIndex].index.wIndex1 = m_pClassFile->ReadWORD(wStartIndex);

	return sizeof(WORD);
}

/*
	Read const pool Entry that contains two WORD indexes from the class 
	data starting at wStartIndex and store data in the wIndex'th entry 
	of m_pConstPool.  Return the number of bytes that we consumed.
*/
WORD JavaConstPool::ReadTwoRefEntry( WORD wStartIndex, WORD wEntryIndex)
{
	m_pConstPool[wEntryIndex].index.wIndex1 = m_pClassFile->ReadWORD(wStartIndex);
	m_pConstPool[wEntryIndex].index.wIndex2 = m_pClassFile->ReadWORD(wStartIndex+sizeof(WORD));

	return sizeof(WORD) + sizeof(WORD);
}



