
#ifndef __COMMONTYPES_H__
#define __COMMONTYPES_H__

#include <string>
#include <sstream>

using namespace std;

typedef unsigned char BYTE;
typedef unsigned long DWORD;
typedef unsigned short WORD;

typedef __int64 INT64;


#define _U(x)	L##x


/*
	This function is necessary to overcome the fact that an 
	ostream operator<< is not supplied for the built in type 
	__int64.
*/
template <class _E, class _Tr>
inline  basic_ostream<_E, _Tr>& __cdecl operator<<(
  basic_ostream<_E, _Tr>& _O, __int64 i64Val)
{
	wchar_t wchBuf[32];

	// VC5BUG: _i64tow cannot handle negative numbers
	if (i64Val < 0)
	{
		_O << _U("-");
		i64Val *= -1;
	}

	return (_O << _i64tow(i64Val, wchBuf, 10)) ;	
}


#endif

